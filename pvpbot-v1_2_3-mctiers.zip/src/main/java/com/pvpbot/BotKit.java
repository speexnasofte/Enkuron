package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;

/**
 * BotKit — система китов для PVP-бота.
 * Киты соответствуют стандартным раскладкам MCTiers (mctiers.com).
 *
 * Доступные киты:
 *   SWORD    — Diamond Prot4, Diamond меч (Unbreaking3), без оффхенда — Sword PvP
 *   AXE      — Diamond без зачар, Diamond топор mainhand + щит offhand — Axe PvP
 *   MACE     — Netherite Prot4, Mace mainhand, тотем offhand, элитры нагрудник — Mace PvP
 *   UHC      — Diamond Prot3/Prot2, меч Sharp3, лук offhand — UHC
 *   NETHOP   — Netherite Prot4+Mending, меч Sharp5, тотем offhand — NethOP
 *   POT      — Diamond Prot4, Diamond меч Sharp5, сплэш-зелье offhand — Diamond Pot
 *   SMP      — Netherite полный, меч Sharp5+KB1+FA2, тотем offhand — SMP
 *   CRYSTAL  — Netherite BlastProt4 на ногах/ботах, меч KB1+Sharp5, тотем — Crystal PvP
 *
 * Использование: /bot kit <название>
 */
public enum BotKit {

    // ── Sword PvP (MCTiers) ───────────────────────────────────────
    // Kit: Diamond Prot4 Unbreaking3, Diamond Sword Unbreaking3
    // Нет оффхенда в базовом MCTiers Sword kit (только меч + броня)
    SWORD("sword", "Sword PvP — алмазная броня Prot4, меч Unbreaking3 (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            null,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "pvp"
    ),

    // ── Axe PvP (MCTiers) ────────────────────────────────────────
    // Kit: Diamond броня БЕЗ зачар, топор + меч + лук + арбалет + щит
    // Бот: топор mainhand, щит offhand
    AXE("axe", "Axe PvP — алмазная броня без зачар, топор + щит (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_AXE,
            Items.SHIELD,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "axe"
    ),

    // ── Mace PvP (MCTiers 1.21+) ─────────────────────────────────
    // Kit: Netherite Prot4, Mace (Breach4 и Density5+WindBurst1 варианты)
    // Sword Sharp5+Unbreaking3, Axe Sharp5+Unbreaking3, энд жемчуг 16
    // Голд яблоки 64, wind charges 64, Elytra, щит Mending+Unbreaking3, тотем
    // Бот: булава mainhand, тотем offhand
    MACE("mace", "Mace PvP — нетерит Prot4, булава Breach4/Density5, тотем (MCTiers)",
        new KitEquipment(
            Items.MACE,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── UHC (MCTiers) ─────────────────────────────────────────────
    // Kit: Diamond Prot3 (шлем/боты), Prot2 (нагрудник/поножи)
    // Sword Sharp3, Axe Efficiency3, 8x Golden Apple, 2x Golden Head
    // Crossbow Piercing1 (заряжен), Bow Power1, дерево 64, вёдра, паутина 8, щит
    // Бот: меч mainhand, лук offhand
    UHC("uhc", "UHC — алмаз Prot3/Prot2, меч Sharp3, голд яблоки, арбалет (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            Items.BOW,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "uhc"
    ),

    // ── Netherite OP / NethOP (MCTiers) ───────────────────────────
    // Kit: Netherite Prot4+Mending+Unbreaking3
    // Sword Sharp5+SweepingEdge3+Unbreaking3
    // 5x Splash Healing II + 1x Strength II + 1x Speed II в хотбаре
    // 64x Golden Apple, тотем offhand; инвентарь: ещё зелья + тотем
    NETHOP("nethop", "NethOP — нетерит Prot4+Mending, меч Sharp5, зелья, тотем (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "nethpot"
    ),

    // ── Diamond Pot / Pot (MCTiers) ────────────────────────────────
    // Kit: Diamond Prot4+Unbreaking3, Diamond Sword Sharp5+SweepingEdge3+Unbreaking3
    // Хотбар: 8x Splash Healing II, offhand: 5x Cooked Beef
    // Инвентарь: ещё зелья хила + Speed II + Strength II + Regen (long)
    // Бот: меч mainhand, сплэш-зелье offhand
    POT("pot", "Diamond Pot — алмаз Prot4, меч Sharp5+Sweep3, зелья хила (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            Items.SPLASH_POTION,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "nethpot"
    ),

    // ── SMP (MCTiers) ─────────────────────────────────────────────
    // Kit: Netherite шлем Resp3+Mend+AquaAffinity+Prot4+Unb3
    //   нагрудник Mend+Prot4+Unb3
    //   поножи SwiftSneak3+Mend+Prot4+Unb3
    //   боты FF4+Mend+Prot4+SoulSpeed3+DepthStrider3+Unb3
    // Sword Sharp5+KB1+SweepEdge3+FireAspect2+Unb3
    // Топор Sharp5+Eff5+Unb3, Эндер жемчуг 16, Голд яблоки 64
    // Зелья: Strength II, Speed II, FireResistance (long); тотем, щит Mend+Unb3
    SMP("smp", "SMP — нетерит полный, меч Sharp5+KB1+FA2, жемчуг, тотем (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "smp"
    ),

    // ── Mace + Elytra (тренировочный) ─────────────────────────────
    // Элитры в нагрудник для пике, Wind Charge + фейерверки для подъёма
    MACE_ELYTRA("mace_elytra", "Mace+Elytra — пике с элитр, Wind Charge, булава-смэш",
        new KitEquipment(
            Items.MACE,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.ELYTRA,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── Crystal PvP (MCTiers) ─────────────────────────────────────
    // Kit: Netherite шлем/нагрудник Prot4+Mend+Unb3
    //   поножи BlastProt4+Mend+Unb3 (вместо Prot!)
    //   боты BlastProt4+FF4+Mend+Unb3 (вместо Prot!)
    // Sword KB1+Mend+Sharp5+SweepEdge3+Unb3
    // Respawn Anchor x64, Glowstone x64, End Crystal x64, Obsidian x64
    // Эндер жемчуг 16, Голд яблоки 64, тотемы x7+, щит, топор, арбалет, элитры
    CRYSTAL("crystal", "Crystal PvP — нетерит BlastProt4 ноги/боты, кристаллы, тотемы (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "crystal"
    );


    // ─────────────────────────────────────────────────────────────
    public final String id;
    public final String displayName;
    public final KitEquipment equipment;
    public final String profileName;

    BotKit(String id, String displayName, KitEquipment equipment, String profileName) {
        this.id          = id;
        this.displayName = displayName;
        this.equipment   = equipment;
        this.profileName = profileName;
    }

    /** Найти кит по строке (регистронезависимо). Null если не найден. */
    public static BotKit byId(String id) {
        for (BotKit kit : values()) {
            if (kit.id.equalsIgnoreCase(id)) return kit;
        }
        return null;
    }

    /** Список всех ID через запятую для подсказок. */
    public static String listIds() {
        StringBuilder sb = new StringBuilder();
        for (BotKit kit : values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(kit.id);
        }
        return sb.toString();
    }

    // ── Внутренний класс снаряжения ───────────────────────────────
    public static class KitEquipment {
        public final Item mainhand;
        public final Item offhand;
        public final Item helmet;
        public final Item chestplate;
        public final Item leggings;
        public final Item boots;

        public KitEquipment(Item mainhand, Item offhand,
                            Item helmet, Item chestplate,
                            Item leggings, Item boots) {
            this.mainhand   = mainhand;
            this.offhand    = offhand;
            this.helmet     = helmet;
            this.chestplate = chestplate;
            this.leggings   = leggings;
            this.boots      = boots;
        }

        /** Применить снаряжение к боту. */
        public void applyTo(BotEntity bot) {
            if (mainhand != null)
                bot.setItemSlot(EquipmentSlot.MAINHAND,   new ItemStack(mainhand));
            if (offhand != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND,    new ItemStack(offhand));
            if (helmet != null)
                bot.setItemSlot(EquipmentSlot.HEAD,       new ItemStack(helmet));
            if (chestplate != null)
                bot.setItemSlot(EquipmentSlot.CHEST,      new ItemStack(chestplate));
            if (leggings != null)
                bot.setItemSlot(EquipmentSlot.LEGS,       new ItemStack(leggings));
            if (boots != null)
                bot.setItemSlot(EquipmentSlot.FEET,       new ItemStack(boots));
        }
    }
}
