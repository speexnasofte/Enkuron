package com.pvpbot;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * UhcLogic v4.0 — MCTiers UHC.
 *
 * Тактика:
 *  1. Стреляет из арбалета/лука на дистанции
 *  2. Кидает паутину под ноги цели
 *  3. Когда цель в паутине — льёт лаву сверху
 *  4. Если БОТ сам попал в паутину — льёт воду чтобы выбраться
 *  5. Ест Golden Apple при низком HP
 *  6. Блокирует щитом входящие атаки
 */
public class UhcLogic {

    private static final double BOW_RANGE    = 16.0;
    private static final double XBOW_RANGE   = 12.0;
    private static final double TRAP_RANGE   = 4.0;
    private static final double MELEE_RANGE  = 2.8;
    private static final double LAVA_RANGE   = 2.5;
    private static final int    BOW_CD       = 20;
    private static final int    XBOW_CD      = 35;
    private static final int    TRAP_CD      = 100;
    private static final int    GAP_CD       = 220;
    private static final int    LAVA_CD      = 80;
    private static final int    WATER_CD     = 60;
    private static final int    SHIELD_TICKS = 40;
    private static final int    WEB_LIFE     = 70;

    private enum State { RANGING, TRAPPING, LAVA_POUR, MELEING, GAPPING, SELF_STUCK }
    private State state = State.RANGING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;

    private int bowCd     = 0;
    private int xbowCd    = 0;
    private int trapCd    = 0;
    private int gapCd     = 0;
    private int lavaCd    = 0;
    private int waterCd   = 0;
    private int shieldTick = 0;
    private int webLife   = 0;

    private boolean webPlaced  = false;
    private boolean lavaPlaced = false;
    private BlockPos webPos    = null;
    private BlockPos lavaPos   = null;

    public UhcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.RETREAT);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(sw); return; }

        if (bowCd    > 0) bowCd--;
        if (xbowCd   > 0) xbowCd--;
        if (trapCd   > 0) trapCd--;
        if (gapCd    > 0) gapCd--;
        if (lavaCd   > 0) lavaCd--;
        if (waterCd  > 0) waterCd--;
        if (shieldTick > 0) shieldTick--;
        if (webLife  > 0) webLife--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Паутина истекла — убираем ──────────────────────────────
        if (webPlaced && webLife <= 0) removeWeb(sw);

        // ── Лаву тоже убираем после таймера ───────────────────────
        if (lavaPlaced && lavaCd <= 0) removeLava(sw);

        // ── БОТ сам застрял в паутине — приоритет выбраться ───────
        if (botInWeb(sw)) {
            state = State.SELF_STUCK;
        }
        // ── Низкое HP → еда ───────────────────────────────────────
        else if (myHp < 8.0f && gapCd <= 0) {
            state = State.GAPPING;
        }
        // ── Цель в паутине + лава ещё не стоит ────────────────────
        else if (webPlaced && isInWeb(target) && !lavaPlaced && lavaCd <= 0) {
            state = State.LAVA_POUR;
        }
        // ── Цель в паутине → ближний бой ──────────────────────────
        else if (webPlaced && isInWeb(target)) {
            state = State.MELEING;
        }
        // ── Паутина кулдаун → дальняя атака ───────────────────────
        else if (dist < TRAP_RANGE && trapCd <= 0 && !webPlaced) {
            state = State.TRAPPING;
        }
        else if (state != State.GAPPING && state != State.SELF_STUCK) {
            state = State.RANGING;
        }

        switch (state) {
            case RANGING    -> doRanging(sw, target, dist);
            case TRAPPING   -> doTrapping(sw, target);
            case LAVA_POUR  -> doLavaPour(sw, target);
            case MELEING    -> doMeleing(sw, target);
            case GAPPING    -> doGapping(sw, target);
            case SELF_STUCK -> doSelfStuck(sw);
            default -> {}
        }

        // ── Щит при входящем уроне ────────────────────────────────
        autoShield(target, dist);
    }

    // ── Дальний бой: арбалет + лук ────────────────────────────────
    private void doRanging(ServerLevel sw, LivingEntity target, double dist) {
        // Держим дистанцию
        if (dist < 6.0) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 7, bot.getY(), bot.getZ() + away.z * 7, 1.1
            );
        } else if (dist > BOW_RANGE) {
            bot.getNavigation().moveTo(target, 1.0);
        }
        strafe.tick(target);

        // Арбалет (более мощный, приоритет на средней дистанции)
        if (dist <= XBOW_RANGE && xbowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
            bot.getLookControl().setLookAt(target, 60f, 60f);
            if (target != null && target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), 9.0f);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 4, 0.2,0.2,0.2,0.1);
            xbowCd = XBOW_CD;
            return;
        }

        // Лук на дальней дистанции
        if (dist <= BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
            bot.getLookControl().setLookAt(target, 60f, 60f);
            float dmg = (float) Math.max(2.0, 9.5 - dist * 0.3);
            if (target != null && target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            bowCd = BOW_CD;
        }
    }

    // ── Кидаем паутину ────────────────────────────────────────────
    private void doTrapping(ServerLevel sw, LivingEntity target) {
        BlockPos feet = BlockPos.containing(target.position());
        BlockPos above = feet.above();
        // Кладём паутину туда где стоит цель, и над ней тоже
        if (sw.getBlockState(feet).isAir() && sw.getBlockState(feet.below()).isSolid()) {
            sw.setBlock(feet, Blocks.COBWEB.defaultBlockState(), 3);
            if (sw.getBlockState(above).isAir())
                sw.setBlock(above, Blocks.COBWEB.defaultBlockState(), 3);
            webPlaced = true;
            webPos    = feet;
            webLife   = WEB_LIFE;
            bot.playSound(net.minecraft.sounds.SoundEvents.WOOL_PLACE, 1.0f, 0.8f);
        }
        trapCd = TRAP_CD;
        state  = State.LAVA_POUR;
    }

    // ── Льём лаву на цель в паутине ──────────────────────────────
    private void doLavaPour(ServerLevel sw, LivingEntity target) {
        if (!isInWeb(target)) { state = State.RANGING; return; }

        BlockPos pourPos = webPos != null ? webPos.above(2) : BlockPos.containing(target.position()).above(2);

        if (sw.getBlockState(pourPos).isAir()) {
            sw.setBlock(pourPos, Blocks.LAVA.defaultBlockState(), 3);
            lavaPlaced = true;
            lavaPos    = pourPos;
            lavaCd     = LAVA_CD;
            bot.playSound(net.minecraft.sounds.SoundEvents.BUCKET_EMPTY_LAVA, 1.0f, 1.0f);
        }

        // Пока цель горит — добиваем мечом
        state = State.MELEING;
    }

    // ── Ближний бой (цель в паутине) ─────────────────────────────
    private void doMeleing(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));

        if (bot.distanceTo(target) > MELEE_RANGE)
            bot.getNavigation().moveTo(target, 1.1);

        if (bot.distanceTo(target) <= MELEE_RANGE + 0.5) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
        }

        // Цель выбралась из паутины → назад в RANGING
        if (!isInWeb(target)) {
            webPlaced  = false;
            lavaPlaced = false;
            removeLava(sw);
            state = State.RANGING;
        }
    }

    // ── Едим Golden Apple при низком HP ──────────────────────────
    private void doGapping(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 6, bot.getY(), bot.getZ() + away.z * 6, 1.2
        );
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
        gapCd = GAP_CD;
        state = State.RANGING;
    }

    // ── Бот сам застрял в паутине — выливаем воду ────────────────
    private void doSelfStuck(ServerLevel sw) {
        if (waterCd > 0) return;

        BlockPos botPos = BlockPos.containing(bot.position());
        // Выливаем воду рядом с ботом чтобы смыть паутину
        for (BlockPos candidate : new BlockPos[]{
            botPos, botPos.north(), botPos.south(), botPos.east(), botPos.west()
        }) {
            if (sw.getBlockState(candidate).is(Blocks.COBWEB)) {
                sw.setBlock(candidate, Blocks.WATER.defaultBlockState(), 3);
                bot.playSound(net.minecraft.sounds.SoundEvents.BUCKET_EMPTY, 1.0f, 1.0f);
                // Вода смоет паутину — через тик будет воздух
                break;
            }
        }
        waterCd = WATER_CD;
        // Если выбрались — продолжаем бой
        if (!botInWeb(sw)) {
            state = State.RANGING;
        }
    }

    // ── Авто-щит ──────────────────────────────────────────────────
    private void autoShield(LivingEntity target, double dist) {
        if (dist < 4.0 && shieldTick <= 0) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            shieldTick = SHIELD_TICKS;
        }
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private void removeWeb(ServerLevel sw) {
        if (webPos != null && sw.getBlockState(webPos).is(Blocks.COBWEB))
            sw.setBlock(webPos, Blocks.AIR.defaultBlockState(), 3);
        BlockPos above = webPos != null ? webPos.above() : null;
        if (above != null && sw.getBlockState(above).is(Blocks.COBWEB))
            sw.setBlock(above, Blocks.AIR.defaultBlockState(), 3);
        webPlaced = false; webPos = null;
    }

    private void removeLava(ServerLevel sw) {
        if (lavaPos != null && sw.getBlockState(lavaPos).is(Blocks.LAVA))
            sw.setBlock(lavaPos, Blocks.AIR.defaultBlockState(), 3);
        lavaPlaced = false; lavaPos = null;
    }

    private boolean isInWeb(LivingEntity t) {
        if (webPos == null) return false;
        BlockPos tp = BlockPos.containing(t.position());
        return (tp.equals(webPos) || tp.equals(webPos.above()))
            && bot.level().getBlockState(tp).is(Blocks.COBWEB);
    }

    private boolean botInWeb(ServerLevel sw) {
        BlockPos bp = BlockPos.containing(bot.position());
        return sw.getBlockState(bp).is(Blocks.COBWEB)
            || sw.getBlockState(bp.above()).is(Blocks.COBWEB);
    }

    private void reset(ServerLevel sw) {
        state = State.RANGING;
        removeWeb(sw);
        removeLava(sw);
    }
}
