package com.pvpbot.gui.render;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.ResourceLocation;

/**
 * IconRenderer — рисует иконки модулей через текстуры.
 * Текстуры лежат в: assets/pvpbot/textures/gui/icons/<name>.png
 *
 * Если текстура не найдена — рисуется Unicode-символ (fallback).
 */
public class IconRenderer {

    // Все иконки мода
    private static final String[] ICON_NAMES = {
        "auto_attack", "auto_dodge", "auto_heal", "auto_eat",
        "auto_gap", "auto_sprint", "auto_totem", "auto_armor",
        "auto_bow", "kite", "w_tap", "s_tap", "esp",
        "radar", "auto_crystal", "stats", "hud", "auto_block",
        "anti_knockback", "auto_log", "auto_pearl", "tracers",
        // ── Иконки китов MCTiers ──────────────────────────────────
        "kit_sword", "kit_axe", "kit_mace", "kit_uhc",
        "kit_pot", "kit_nethop", "kit_smp", "kit_crystal",
        "kit_ltm", "kit_vanilla", "kit_nethpot", "kit_tpc",
        "kit_snowball", "kit_trident", "kit_crossbow", "kit_elytra"
    };

    /**
     * Возвращает id иконки для кита по его строковому названию.
     * Используется в HUD и GUI для отображения активного кита.
     */
    public static String kitIconId(String kitName) {
        if (kitName == null) return "kit_sword";
        return switch (kitName.toLowerCase()) {
            case "sword"                      -> "kit_sword";
            case "axe"                        -> "kit_axe";
            case "mace", "mace_elytra"        -> "kit_mace";
            case "uhc"                        -> "kit_uhc";
            case "pot"                        -> "kit_pot";
            case "nethop", "nethpot", "nethp" -> "kit_nethop";
            case "smp"                        -> "kit_smp";
            case "crystal", "tpc"             -> "kit_crystal";
            case "ltm", "ltms"               -> "kit_ltm";
            case "vanilla"                    -> "kit_vanilla";
            case "snowball"                   -> "kit_snowball";
            case "trident"                    -> "kit_trident";
            case "crossbow"                   -> "kit_crossbow";
            default                           -> "kit_sword";
        };
    }

    /**
     * Рисует иконку модуля по её id.
     * Сначала пробует текстуру, при ошибке — символ.
     */
    public static void draw(GuiGraphicsExtractorExtractor ctx, String moduleId, int x, int y, int size) {
        try {
            ResourceLocation tex = ResourceLocation.fromNamespaceAndPath("pvpbot", "textures/gui/icons/" + moduleId + ".png");
            ctx.blit(net.minecraft.client.renderer.RenderType::guiTextured, tex, x, y, 0, 0, size, size, size, size);
        } catch (Exception e) {
            // fallback: Unicode символ посередине
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc != null && mc.font != null) {
                String sym = getFallbackSymbol(moduleId);
                int sw = mc.font.width(sym);
                ctx.drawString(mc.font, sym, x + (size - sw) / 2, y + (size / 2) - 4, 0xCCCCCC, true);
            }
        }
    }

    /** Unicode fallback когда нет PNG. */
    public static String getFallbackSymbol(String id) {
        return switch (id) {
            case "auto_attack"    -> "\u2694"; // ⚔
            case "auto_dodge"     -> "\u26A1"; // ⚡
            case "auto_heal"      -> "\u2764"; // ❤
            case "auto_eat"       -> "\u2615"; // ☕
            case "auto_gap"       -> "\u2B50"; // ⭐
            case "auto_sprint"    -> "\u25B6"; // ▶
            case "auto_totem"     -> "\u26E8"; // ⛨
            case "auto_armor"     -> "\u1F6E1"; // 🛡
            case "auto_bow"       -> "\u27B9"; // ➹
            case "kite"           -> "\u2605"; // ★
            case "w_tap"          -> "\u26A1"; // ⚡
            case "s_tap"          -> "\u21C4"; // ⇄
            case "esp"            -> "\u25CE"; // ◎
            case "radar"          -> "\u25CC"; // ◌
            case "auto_crystal"   -> "\u25C6"; // ◆
            case "stats"          -> "\u25A0"; // ■
            case "hud"            -> "\u2630"; // ☰
            case "auto_block"     -> "\u25A3"; // ▣
            case "anti_knockback" -> "\u21D5"; // ⇕
            case "auto_log"       -> "\u23CF"; // ⏏
            case "auto_pearl"     -> "\u25CB"; // ○
            case "tracers"        -> "\u25B3"; // △
            // ── Иконки китов MCTiers ──────────────────────────────
            case "kit_sword"      -> "\u2694"; // ⚔  Sword PvP
            case "kit_axe"        -> "\uD83E\uFA93"; // 🪓  Axe PvP
            case "kit_mace"       -> "\uD83D\uDD28"; // 🔨  Mace PvP
            case "kit_uhc"        -> "\uD83D\uDC80"; // 💀  UHC
            case "kit_pot"        -> "\uD83E\uDDEA"; // 🧪  Diamond Pot
            case "kit_nethop"     -> "\u2744"; // ❄  NethOP / NethPot
            case "kit_smp"        -> "\uD83C\uDFE0"; // 🏠  SMP
            case "kit_crystal"    -> "\uD83D\uDCAE"; // 💎  Crystal
            case "kit_ltm"        -> "\u2694"; // ⚔  LTMs (crossed swords)
            case "kit_vanilla"    -> "\u2665"; // ♥  Vanilla
            case "kit_nethpot"    -> "\uD83E\uDDEA"; // 🧪  NethPot
            case "kit_tpc"        -> "\uD83D\uDD2E"; // 🔮  TPC
            case "kit_snowball"   -> "\u2745"; // ❅  Snowball
            case "kit_trident"    -> "\uD83D\uDD31"; // 🔱  Trident
            case "kit_crossbow"   -> "\u2694"; // ⚔  Crossbow
            case "kit_elytra"     -> "\uD83E\uDD85"; // 🦅  Elytra/Mace
            default               -> "\u2022"; // •
        };
    }

    /**
     * Рисует иконку кита с цветным кругом-фоном (стиль MCTiers).
     * @param ctx      GuiGraphics
     * @param kitName  строка кита ("sword", "axe" и т.д.)
     * @param x, y    позиция
     * @param size    размер (рекомендуется 12–16)
     * @param color   цвет фона кружка (ARGB)
     */
    public static void drawKitBadge(GuiGraphicsExtractorExtractor ctx, String kitName, int x, int y, int size, int color) {
        // Фон-кружок
        int half = size / 2;
        ctx.fill(x, y, x + size, y + size, color);
        // Иконка поверх
        draw(ctx, kitIconId(kitName), x + 1, y + 1, size - 2);
    }
}
