package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.ResourceLocation;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.Optional;

/**
 * ClientSounds — модуль звуков тогла в стиле чит-клиентов.
 *
 * Звуки взяты из ShayTanClient (exosware):
 *   Type-1 : akron / akroff      — металлический "акрон"
 *   Type-2 : celon / celoff      — лёгкий "сел"
 *   Type-3 : nuron / nuroff      — нур (как в Meteor)
 *   Type-4 : enableold/disableold— классика старых клиентов
 *   Bell   : bell / bell         — колокол (один звук)
 *   Bubble : bubble / bubble     — пузырь
 *   Bonk   : bonk / bonk        — bonk
 *   Metallic: metallic/metallic  — металл
 *
 * Использование:
 *   ClientSounds.INSTANCE.playEnable();   // при включении модуля
 *   ClientSounds.INSTANCE.playDisable();  // при выключении модуля
 *   ClientSounds.INSTANCE.setMode("Type-1"); // сменить режим
 */
public class ClientSounds {

    public static final ClientSounds INSTANCE = new ClientSounds();

    // ── Режимы звука ─────────────────────────────────────────────
    public enum SoundMode {
        TYPE1   ("Type-1",    "akron",      "akroff"),
        TYPE2   ("Type-2",    "celon",      "celoff"),
        TYPE3   ("Type-3",    "nuron",      "nuroff"),
        TYPE4   ("Type-4",    "enableold",  "disableold"),
        BELL    ("Bell",      "bell",       "bell"),
        BUBBLE  ("Bubble",    "bubble",     "bubble"),
        BONK    ("Bonk",      "bonk",       "bonk"),
        METALLIC("Metallic",  "metallic",   "metallic"),
        NONE    ("None",      null,         null);

        public final String label;
        public final String enableSound;
        public final String disableSound;

        SoundMode(String label, String on, String off) {
            this.label        = label;
            this.enableSound  = on;
            this.disableSound = off;
        }
    }

    // ── Настройки ─────────────────────────────────────────────────
    private SoundMode mode   = SoundMode.TYPE1;
    private float     volume = 0.7f;   // 0.0 – 1.0

    private ClientSounds() {}

    public SoundMode getMode()              { return mode; }
    public void      setMode(SoundMode m)   { this.mode = m; }
    public float     getVolume()            { return volume; }
    public void      setVolume(float v)     { this.volume = Math.max(0f, Math.min(1f, v)); }

    /** Возвращает все доступные режимы (для GUI). */
    public static SoundMode[] modes() { return SoundMode.values(); }

    // ── Публичный API ─────────────────────────────────────────────

    /** Воспроизвести звук включения модуля. */
    public void playEnable() {
        if (mode == SoundMode.NONE || mode.enableSound == null) return;
        playSoundAsync(mode.enableSound);
    }

    /** Воспроизвести звук выключения модуля. */
    public void playDisable() {
        if (mode == SoundMode.NONE || mode.disableSound == null) return;
        playSoundAsync(mode.disableSound);
    }

    /** Воспроизвести звук входа на сервер. */
    public void playJoin() {
        playSoundAsync("join");
    }

    // ── Внутреннее ───────────────────────────────────────────────

    /**
     * Асинхронное воспроизведение WAV-файла из ресурсов мода.
     * Путь: assets/pvpbot/sounds/<name>.wav
     */
    private void playSoundAsync(String name) {
        byte[] data = loadSoundBytes(name);
        if (data == null) return;
        float vol = volume;
        Thread t = new Thread(() -> playSoundFromBytes(data, vol), "pvpbot-sound");
        t.setDaemon(true);
        t.start();
    }

    /** Загружает WAV-файл из ресурсов в байтовый массив. */
    private byte[] loadSoundBytes(String name) {
        Minecraft mc = Minecraft.getInstance();
        ResourceLocation loc = ResourceLocation.fromNamespaceAndPath("pvpbot", "sounds/" + name + ".wav");
        try {
            Optional<?> resOpt = mc.getResourceManager().getResource(loc);
            if (resOpt.isEmpty()) {
                System.err.println("[PVPBot ClientSounds] Sound not found: " + loc);
                return null;
            }
            // ResourceManager возвращает net.minecraft.server.packs.resources.Resource
            Object res = resOpt.get();
            // Получаем InputStream через рефлексию (совместимо с разными маппингами)
            InputStream is = null;
            try {
                is = (InputStream) res.getClass().getMethod("open").invoke(res);
            } catch (Exception e) {
                try {
                    is = (InputStream) res.getClass().getMethod("getInputStream").invoke(res);
                } catch (Exception e2) {
                    System.err.println("[PVPBot ClientSounds] Cannot open resource: " + e2.getMessage());
                    return null;
                }
            }
            try (InputStream stream = is) {
                return stream.readAllBytes();
            }
        } catch (Exception e) {
            System.err.println("[PVPBot ClientSounds] Error loading sound '" + name + "': " + e.getMessage());
            return null;
        }
    }

    /** Воспроизводит WAV из байтового массива через javax.sound.sampled. */
    private void playSoundFromBytes(byte[] data, float vol) {
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(
                new BufferedInputStream(new java.io.ByteArrayInputStream(data))
            );
            Clip clip = AudioSystem.getClip();
            clip.open(ais);

            // Устанавливаем громкость через MASTER_GAIN
            try {
                FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                // Конвертируем 0..1 в dB
                float dB = (float) (20.0 * Math.log10(Math.max(vol, 0.0001f)));
                dB = Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB));
                gain.setValue(dB);
            } catch (Exception ignored) {}

            // Закрываем клип после завершения
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    clip.close();
                }
            });

            clip.start();
        } catch (Exception e) {
            System.err.println("[PVPBot ClientSounds] Error playing sound: " + e.getMessage());
        }
    }
}
