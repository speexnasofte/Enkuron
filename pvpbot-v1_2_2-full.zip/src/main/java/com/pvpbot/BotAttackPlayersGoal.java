package com.pvpbot;

import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

/**
 * BotAttackPlayersGoal v1.3 — атака игроков.
 * Уважает standbyMode: если боты в режиме ожидания — не выбирают цель.
 */
public class BotAttackPlayersGoal extends NearestAttackableTargetGoal<Player> {

    private final BotEntity bot;

    public BotAttackPlayersGoal(BotEntity bot) {
        super(bot, Player.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canUse() {
        // В standby режиме не атакуем
        if (PVPBotConfig.INSTANCE.standbyMode) return false;

        Player owner = bot.getOwner();
        return super.canUse() && (owner == null || target == null || !target.equals(owner));
    }

    @Override
    public boolean canContinueToUse() {
        if (PVPBotConfig.INSTANCE.standbyMode) return false;
        return super.canContinueToUse();
    }
}
