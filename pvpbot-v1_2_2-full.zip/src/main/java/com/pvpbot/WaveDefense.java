package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * WaveDefense — режим волновой обороны.
 *
 * Активация: /bot squad wavedefense [start|stop]
 *
 * Механика:
 *  - Боты встают по периметру (кольцо вокруг владельца)
 *  - Каждые WAVE_INTERVAL тиков появляется новая волна мобов/ботов-врагов
 *  - Сложность волны растёт с каждым раундом
 *  - Статистика: убито, выжило, раунд
 *  - После последней волны — победа и запись в BattleHistory
 */
public class WaveDefense {

    public static final WaveDefense INSTANCE = new WaveDefense();

    private static final int TOTAL_WAVES    = 10;
    private static final int WAVE_INTERVAL  = 600;  // тиков (30 сек)
    private static final double SPAWN_RADIUS = 32.0;
    private static final double RING_RADIUS  = 8.0;

    private boolean active      = false;
    private int currentWave     = 0;
    private int waveTimer       = 0;
    private int totalKills      = 0;
    private final List<BotEntity> enemies = new ArrayList<>();

    private WaveDefense() {}

    // ── API ──────────────────────────────────────────────────────

    public void start(ServerPlayer owner, SquadManager.Squad squad) {
        active      = true;
        currentWave = 0;
        waveTimer   = 0;
        totalKills  = 0;
        enemies.clear();

        // Расставить бойцов по периметру
        positionDefenders(squad, owner);

        owner.sendSystemMessage(Component.literal(
            "§a§l[Волновая оборона] §fНачинается! §7Всего волн: §c" + TOTAL_WAVES));
        CasualtyTracker.INSTANCE.startBattle(squad, "WAVE_DEFENSE");
    }

    public void stop(ServerPlayer owner) {
        if (!active) return;
        active = false;
        killAllEnemies();
        CasualtyTracker.INSTANCE.endBattle(false, owner);
        owner.sendSystemMessage(Component.literal("§c[Волновая оборона] §fОстановлена."));
    }

    public boolean isActive() { return active; }

    public void tick(ServerPlayer owner, SquadManager.Squad squad) {
        if (!active || !(owner.level() instanceof ServerLevel level)) return;

        // Проверить убитых врагов
        enemies.removeIf(e -> {
            if (!e.isAlive()) { totalKills++; return true; }
            return false;
        });

        // Обновить потери своих
        CasualtyTracker.INSTANCE.tick(squad, owner);

        // Проверить поражение (все свои мертвы)
        if (squad.aliveSoldiers() == 0 && (squad.commander == null || !squad.commander.isAlive())) {
            active = false;
            CasualtyTracker.INSTANCE.endBattle(false, owner);
            owner.sendSystemMessage(Component.literal(
                "§c§l[Волновая оборона] §cОтряд уничтожен на волне §f" + currentWave));
            return;
        }

        waveTimer++;

        // Следующая волна
        if (waveTimer >= WAVE_INTERVAL || (currentWave > 0 && enemies.isEmpty())) {
            // Победа проверяется ДО инкремента волны
            if (currentWave >= TOTAL_WAVES) {
                active = false;
                CasualtyTracker.INSTANCE.endBattle(true, owner);
                owner.sendSystemMessage(Component.literal(
                    "§a§l[Волновая оборона] §aПОБЕДА! §7Убито врагов: §c" + totalKills));
                return;
            }

            currentWave++;
            waveTimer = 0;
            spawnWave(owner, squad, level);
        }
    }

    // ── Волны ────────────────────────────────────────────────────

    private void spawnWave(ServerPlayer owner, SquadManager.Squad squad, ServerLevel level) {
        int count = 3 + currentWave * 2; // 5, 7, 9 ... на каждой волне больше
        Vec3 center = owner.position();

        owner.sendSystemMessage(Component.literal(
            "§c§l⚔ Волна " + currentWave + "/" + TOTAL_WAVES +
            " §7(§c" + count + " §7врагов)"));

        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            double x = center.x + Math.cos(angle) * SPAWN_RADIUS;
            double z = center.z + Math.sin(angle) * SPAWN_RADIUS;

            // Спавн вражеского бота
            spawnEnemyBot(level, x, owner.getY(), z, squad);
        }
    }

    private void spawnEnemyBot(ServerLevel level, double x, double y, double z,
                                SquadManager.Squad friendlySquad) {
        BotEntity enemy = new BotEntity(com.pvpbot.PVPBotMod.BOT_TYPE, level);
        enemy.setPos(x, y, z);

        // Режим AGGRESSIVE — бот атакует ближайшего живого
        enemy.setBotMode(BotEntity.BotMode.AGGRESSIVE);

        // Назначить тип кита по волне
        BotKit kit = currentWave > 6 ? BotKit.CRYSTAL :
                     currentWave > 3 ? BotKit.AXE :
                                       BotKit.NETHPOT;
        kit.equipment.applyTo(enemy);

        level.addFreshEntity(enemy);

        // После спавна — выдать первичную цель: командира или ближайшего союзника
        if (friendlySquad.commander != null && friendlySquad.commander.isAlive()) {
            enemy.setTarget(friendlySquad.commander);
        } else if (!friendlySquad.soldiers.isEmpty()) {
            friendlySquad.soldiers.stream()
                .filter(net.minecraft.world.entity.LivingEntity::isAlive)
                .findFirst()
                .ifPresent(enemy::setTarget);
        }

        enemies.add(enemy);
    }

    private void positionDefenders(SquadManager.Squad squad, ServerPlayer owner) {
        List<BotEntity> all = squad.allBots();
        Vec3 center = owner.position();
        for (int i = 0; i < all.size(); i++) {
            double angle = (2 * Math.PI / all.size()) * i;
            double x = center.x + Math.cos(angle) * RING_RADIUS;
            double z = center.z + Math.sin(angle) * RING_RADIUS;
            all.get(i).moveTo(x, center.y, z);
        }
    }

    private void killAllEnemies() {
        for (BotEntity e : enemies) if (e.isAlive()) e.discard();
        enemies.clear();
    }

    public int getCurrentWave()  { return currentWave; }
    public int getTotalKills()   { return totalKills; }
    public int getEnemyCount()   { return enemies.size(); }
}
