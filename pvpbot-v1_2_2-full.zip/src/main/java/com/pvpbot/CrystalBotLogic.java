package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * CrystalBotLogic — серверная логика кристального PvP для NPC-бота.
 *
 * v1.3:
 *  - Размещение обсидиана под ногами цели (через ObsidianPlacer)
 *  - Размещение кристалла на обсидиане/бедроке
 *  - Подрыв кристалла если цель рядом
 *  - Усиленный урон когда цель В ВОЗДУХЕ (target.onGround() == false)
 *  - Постановка кристалла сзади цели для combo-взрыва
 */
public class CrystalBotLogic {

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int placeTimer   = 0;
    private int explodeTimer = 0;
    private int obsidianTimer = 0;

    private final ObsidianPlacer obsidianPlacer = new ObsidianPlacer();

    /** Минимальная дистанция до цели для размещения кристалла */
    private static final double PLACE_RANGE = 5.5;
    /** Cooldown взрыва в тиках */
    private static final int EXPLODE_CD = 6;
    /** Cooldown установки кристалла */
    private static final int PLACE_CD   = 8;

    public CrystalBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(net.minecraft.server.level.ServerLevel sw, LivingEntity target) {
        if (sw == null) return;
        if (target == null || !target.isAlive()) return;

        placeTimer--;
        explodeTimer--;
        obsidianTimer--;

        double dist = bot.distanceTo(target);

        // 1. Кладём обсидиан под цель
        if (obsidianTimer <= 0) {
            obsidianPlacer.tick(sw, bot, target);
            obsidianTimer = 8;
        }

        // 2. Взрываем ближайший кристалл рядом с целью
        if (explodeTimer <= 0) {
            boolean targetInAir = !target.onGround();
            explodeCrystalNear(sw, target, targetInAir);
            explodeTimer = EXPLODE_CD;
        }

        // 3. Ставим новый кристалл рядом с целью
        if (placeTimer <= 0 && dist <= PLACE_RANGE) {
            placeCrystalNear(sw, target);
            placeTimer = PLACE_CD;
        }
    }

    /**
     * Взрываем кристалл ближайший к цели.
     * Если цель в воздухе — урон увеличен (fallDamage combo).
     */
    private void explodeCrystalNear(ServerLevel sw, LivingEntity target, boolean targetInAir) {
        AABB searchBox = target.getBoundingBox().inflate(cfg.crystalPlaceRange);
        List<EndCrystal> crystals = sw.getEntitiesOfClass(EndCrystal.class, searchBox, e -> true);

        crystals.stream()
            .min(Comparator.comparingDouble(c -> c.distanceToSqr(target)))
            .ifPresent(crystal -> {
                float damage = targetInAir
                    ? cfg.diffCrystalDamage * 1.4f   // +40% урона если цель в воздухе
                    : cfg.diffCrystalDamage;

                // Урон цели
                target.hurt(sw.damageSources().explosion(bot, bot), damage);
                // Knockback
                Vec3 kb = target.position().subtract(crystal.position()).normalize().scale(1.4);
                target.setDeltaMovement(target.getDeltaMovement().add(kb.x, 0.5, kb.z));

                // Удаляем кристалл
                crystal.discard();

                // Эффекты взрыва
                sw.sendParticles(ParticleTypes.EXPLOSION, crystal.getX(), crystal.getY(), crystal.getZ(),
                    3, 0.5, 0.5, 0.5, 0.1);
                bot.playSound(SoundEvents.GENERIC_EXPLODE.value(), 1.0f, 1.0f);
            });
    }

    /**
     * Ставим кристалл на обсидиан/бедрок рядом с целью.
     * Предпочитаем позицию ЗА спиной цели для combo-взрыва.
     */
    private void placeCrystalNear(ServerLevel sw, LivingEntity target) {
        BlockPos targetPos = target.blockPosition();

        // Смотрим куда смотрит цель (ставим кристалл ЗА ней)
        Vec3 lookDir = target.getLookAngle();
        // Позиции: сначала за спиной цели, потом остальные
        int[][] offsets = {
            {(int)-Math.signum(lookDir.x) * 2, -1, (int)-Math.signum(lookDir.z) * 2},
            {0, -1, 0}, {1, -1, 0}, {-1, -1, 0}, {0, -1, 1}, {0, -1, -1},
            {2, -1, 0}, {-2, -1, 0}, {0, -1, 2}, {0, -1, -2}
        };

        for (int[] off : offsets) {
            BlockPos basePos = targetPos.offset(off[0], off[1], off[2]);
            BlockPos placePos = basePos.above(); // верх блока

            var baseBlock = sw.getBlockState(basePos).getBlock();
            boolean validBase = (baseBlock == Blocks.OBSIDIAN || baseBlock == Blocks.BEDROCK);
            if (!validBase) continue;

            boolean airHere  = sw.getBlockState(placePos).isAir();
            boolean airAbove = sw.getBlockState(placePos.above()).isAir();
            if (!airHere || !airAbove) continue;

            double distToPlace = bot.position().distanceTo(Vec3.atCenterOf(placePos));
            if (distToPlace > PLACE_RANGE + 1.5) continue;

            // Нет ли уже кристалла тут
            AABB crystalBox = new AABB(placePos).inflate(0.5);
            if (!sw.getEntitiesOfClass(EndCrystal.class, crystalBox, e -> true).isEmpty()) continue;

            // Спавним кристалл через сервер
            EndCrystal crystal = net.minecraft.world.entity.EntityType.END_CRYSTAL.create(
                sw, net.minecraft.world.entity.EntitySpawnReason.TRIGGERED);
            if (crystal == null) return;
            crystal.moveTo(placePos.getX() + 0.5, placePos.getY(), placePos.getZ() + 0.5);
            crystal.setBeamTarget(null);
            sw.addFreshEntity(crystal);
            return; // один кристалл за тик
        }
    }
}
