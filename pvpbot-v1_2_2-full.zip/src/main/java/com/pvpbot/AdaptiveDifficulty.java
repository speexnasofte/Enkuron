package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.*;

/**
 * AdaptiveDifficulty v1.0 — автоматическое регулирование сложности бота.
 *
 * Принцип работы:
 *   - Следит за соотношением побед/поражений бота
 *   - Если игрок убивает бота слишком легко → повышаем сложность
 *   - Если бот постоянно побеждает → понижаем (чтобы не было читов)
 *   - Оценка каждые EVAL_WINDOW убийств (по умолчанию 5)
 *
 * Метрики для оценки:
 *   - Win rate бота (сколько раз бот "убил" / всего боёв)
 *   - Средняя длительность боя (слишком быстро → игрок слишком слаб)
 *   - Средний оставшийся HP бота после победы (много HP → слишком лёгкий)
 *
 * Команды:
 *   /bot adaptive [on|off|status|reset]
 *
 * Связь с BotDifficultyAI:
 *   AdaptiveDifficulty.INSTANCE → BotDifficultyAI.setDifficulty(...)
 */
public class AdaptiveDifficulty {

    public static final AdaptiveDifficulty INSTANCE = new AdaptiveDifficulty();

    // ── Параметры ─────────────────────────────────────────────────
    /** Количество боёв в одном окне оценки */
    private static final int EVAL_WINDOW = 5;
    /** Win rate выше этого → повышаем сложность */
    private static final float RAISE_THRESHOLD = 0.7f;
    /** Win rate ниже этого → понижаем сложность */
    private static final float LOWER_THRESHOLD = 0.3f;
    /** Средний HP бота при победе выше этого → слишком лёгко */
    private static final float EASY_HP_RATIO = 0.7f;
    /** Средний HP бота при победе ниже этого → слишком сложно */
    private static final float HARD_HP_RATIO = 0.3f;

    // ── Состояние ─────────────────────────────────────────────────
    private boolean enabled = true;
    private final Deque<BattleResult> history = new ArrayDeque<>();

    // Текущая сложность (отдельно от PVPBotConfig чтобы не ломать ручные настройки)
    private PVPBotConfig.Difficulty currentDifficulty = PVPBotConfig.Difficulty.MEDIUM;

    public static class BattleResult {
        public final boolean botWon;        // бот побил игрока (игрок умер)
        public final float botHpRemaining;  // HP бота после боя
        public final int durationTicks;     // длительность боя

        public BattleResult(boolean botWon, float botHpRemaining, int durationTicks) {
            this.botWon = botWon;
            this.botHpRemaining = botHpRemaining;
            this.durationTicks = durationTicks;
        }
    }

    private AdaptiveDifficulty() {}

    // ── API ───────────────────────────────────────────────────────

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { enabled = v; }
    public PVPBotConfig.Difficulty getCurrentDifficulty() { return currentDifficulty; }

    /**
     * Записать результат боя.
     * Вызывать: из BotEntity при смерти или смерти игрока-владельца.
     */
    public void recordBattle(boolean botWon, float botHpRemaining, int durationTicks, ServerPlayer owner) {
        if (!enabled) return;

        history.addLast(new BattleResult(botWon, botHpRemaining, durationTicks));
        while (history.size() > EVAL_WINDOW * 2) history.pollFirst(); // скользящее окно

        if (history.size() >= EVAL_WINDOW) {
            evaluate(owner);
        }
    }

    /** Оценить статистику и при необходимости изменить сложность. */
    private void evaluate(ServerPlayer owner) {
        List<BattleResult> recent = new ArrayList<>(history);
        recent = recent.subList(Math.max(0, recent.size() - EVAL_WINDOW), recent.size());

        long botWins = recent.stream().filter(r -> r.botWon).count();
        float winRate = (float) botWins / recent.size();
        float avgHpRatio = (float) recent.stream()
            .filter(r -> r.botWon)
            .mapToDouble(r -> r.botHpRemaining / PVPBotConfig.INSTANCE.botMaxHealth)
            .average().orElse(0.5);

        PVPBotConfig.Difficulty newDiff = currentDifficulty;

        // Слишком легко для бота — повышаем
        if (winRate >= RAISE_THRESHOLD || (winRate >= 0.5f && avgHpRatio >= EASY_HP_RATIO)) {
            newDiff = raise(currentDifficulty);
        }
        // Слишком сложно — понижаем
        else if (winRate <= LOWER_THRESHOLD || (winRate <= 0.5f && avgHpRatio <= HARD_HP_RATIO)) {
            newDiff = lower(currentDifficulty);
        }

        if (newDiff != currentDifficulty) {
            currentDifficulty = newDiff;
            applyDifficulty(newDiff, owner);
        }
    }

    private PVPBotConfig.Difficulty raise(PVPBotConfig.Difficulty d) {
        return switch (d) {
            case EASY   -> PVPBotConfig.Difficulty.MEDIUM;
            case MEDIUM -> PVPBotConfig.Difficulty.HARD;
            case HARD   -> PVPBotConfig.Difficulty.EXPERT;
            case EXPERT -> PVPBotConfig.Difficulty.EXPERT;
            default     -> null;
        };
    }

    private PVPBotConfig.Difficulty lower(PVPBotConfig.Difficulty d) {
        return switch (d) {
            case EXPERT -> PVPBotConfig.Difficulty.HARD;
            case HARD   -> PVPBotConfig.Difficulty.MEDIUM;
            case MEDIUM -> PVPBotConfig.Difficulty.EASY;
            case EASY   -> PVPBotConfig.Difficulty.EASY;
            default     -> null;
        };
    }

    private void applyDifficulty(PVPBotConfig.Difficulty diff, ServerPlayer owner) {
        PVPBotConfig.INSTANCE.difficulty = diff;
        PVPBotConfig.INSTANCE.applyDifficulty();
        BotConfig.save();

        String msg = switch (diff) {
            case EASY   -> "§7📉 Сложность понижена до §fEASY";
            case MEDIUM -> "§e📊 Сложность §fMEDIUM";
            case HARD   -> "§c📈 Сложность повышена до §fHARD";
            case EXPERT -> "§4§l⚠ Максимальная сложность §lEXPERT!";
            default     -> "?";
        };
        if (owner != null && PVPBotConfig.INSTANCE.notificationsEnabled) {
            owner.sendSystemMessage(Component.literal("§e[AdaptiveDifficulty] " + msg));
        }
    }

    public void reset() {
        history.clear();
        currentDifficulty = PVPBotConfig.Difficulty.MEDIUM;
    }

    /** Форматировать статус для чата. */
    public String formatStatus() {
        int total = history.size();
        long wins = history.stream().filter(r -> r.botWon).count();
        float wr = total > 0 ? (float) wins / total * 100 : 0;

        String diffColor = switch (currentDifficulty) {
            case EASY   -> "§7";
            case MEDIUM -> "§e";
            case HARD   -> "§c";
            case EXPERT -> "§4§l";
            default     -> "?";
        };

        return "§e§lAdaptiveDifficulty:\n" +
            "§7Статус:     §f" + (enabled ? "§aВКЛ" : "§cВЫКЛ") + "\n" +
            "§7Сложность:  " + diffColor + currentDifficulty.name() + "\n" +
            "§7Боёв:       §f" + total + "\n" +
            "§7Win rate бота: §f" + String.format("%.0f", wr) + "%\n" +
            "§7(окно оценки: " + EVAL_WINDOW + " боёв)\n" +
            "§7/bot adaptive reset — сброс";
    }
}
