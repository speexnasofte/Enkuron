package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * BotRegroup v10 — экстренный сбор всех ботов к владельцу.
 *
 * Три режима сбора:
 *   TELEPORT  — мгновенный телепорт (аналог /bot tp, но через API)
 *   PATHFIND  — боты идут к игроку через BotPathfindGoal (не убивают цель)
 *   FORMATION — сбор + выстраивание в текущее построение BotFormations
 *
 * Триггер:
 *   /bot regroup [teleport|pathfind|formation]
 *   По умолчанию — PATHFIND.
 *
 * Интеграция:
 *   1. Добавить в SpawnBotCommand.registerCommands() ветку "regroup".
 *   2. BotRegroup.INSTANCE.regroup(bots, player, mode, world).
 *
 * Также BotRegroup автоматически активируется если бот застрял
 * (stuckTimer > REGROUP_THRESHOLD в BotPathfindGoal) — вместо
 * телепорта можно вызвать мягкий regroup.
 */
public class BotRegroup {

    public static final BotRegroup INSTANCE = new BotRegroup();

    public enum RegroupMode {
        TELEPORT,
        PATHFIND,
        FORMATION
    }

    private BotRegroup() {}

    /**
     * Собирает всех ботов к игроку.
     *
     * @param bots   список ботов игрока
     * @param player владелец
     * @param mode   режим сбора
     * @param world  серверный мир
     * @return число обработанных ботов
     */
    public int regroup(List<BotEntity> bots, Player player,
                       RegroupMode mode, ServerLevel world) {
        if (bots == null || bots.isEmpty()) return 0;

        int count = 0;
        for (int i = 0; i < bots.size(); i++) {
            BotEntity bot = bots.get(i);
            if (bot.isRemoved()) continue;

            // Сбрасываем текущую цель — бот перестаёт драться
            bot.setTarget(null);

            switch (mode) {
                case TELEPORT -> teleportToPlayer(bot, player, i, bots.size());
                case PATHFIND -> pathfindToPlayer(bot, player);
                case FORMATION -> formationRegroup(bot, player, i, bots.size());
            default: break;
            }
            count++;
        }
        return count;
    }

    // ── Телепорт ─────────────────────────────────────────────────

    private void teleportToPlayer(BotEntity bot, Player player, int index, int total) {
        // Смещаем по кругу чтобы не стакаться
        double angle = (2.0 * Math.PI / Math.max(total, 1)) * index;
        double radius = 1.5;
        double dx = Math.cos(angle) * radius;
        double dz = Math.sin(angle) * radius;
        bot.teleportTo(player.getX() + dx, player.getY(), player.getZ() + dz);
    }

    // ── Pathfind (мягкий сбор) ───────────────────────────────────

    private void pathfindToPlayer(BotEntity bot, Player player) {
        // BotPathfindGoal сам начнёт двигаться когда цель = null
        // и расстояние > minDist. Форсируем старт навигации:
        Vec3 target = BotFormations.INSTANCE.getTargetPos(
            bot, 0, 1, player  // для pathfind используем позицию без смещения
        );
        bot.getNavigation().moveTo(target.x, target.y, target.z, 1.2);
    }

    // ── Построение + pathfind ────────────────────────────────────

    private void formationRegroup(BotEntity bot, Player player, int index, int total) {
        Vec3 target = BotFormations.INSTANCE.getTargetPos(bot, index, total, player);
        double dist = bot.distanceTo(player);

        if (dist > 32.0) {
            // Далеко — телепорт
            bot.teleportTo(target.x, target.y, target.z);
        } else {
            // Близко — идём
            bot.getNavigation().moveTo(target.x, target.y, target.z, 1.2);
        }
    }

    // ── Парсер строки в enum ─────────────────────────────────────

    public static RegroupMode fromString(String s) {
        return switch (s.toLowerCase()) {
            case "teleport", "tp" -> RegroupMode.TELEPORT;
            case "formation", "form" -> RegroupMode.FORMATION;
            default -> RegroupMode.PATHFIND;
        };
    }
}
