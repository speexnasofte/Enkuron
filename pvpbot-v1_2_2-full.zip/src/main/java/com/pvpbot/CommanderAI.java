package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.chat.Component;

import java.util.*;

/**
 * CommanderAI v2.0 — адаптивный ИИ командира отряда.
 *
 * Новые фичи:
 *  1. Адаптация к врагу:
 *     - Враг использует кристаллы → переключить отряд на CRYSTAL кит
 *     - Враг на дальней дистанции → выслать SNIPER/SCOUT вперёд
 *  2. Засада:
 *     - /bot squad ambush → боты прячутся (стоят за блоками, не двигаются)
 *     - Атакуют при приближении врага или по команде /bot squad attack
 *  3. Ротация раненых:
 *     - Раненых бойцов (HP < ROTATE_HP) ставит в резерв, достаёт свежих
 *
 * Встраивается в SquadManager.tick() как отдельный слой ИИ.
 */
public class CommanderAI {

    public static final CommanderAI INSTANCE = new CommanderAI();

    private static final double ENEMY_SCAN_RANGE = 48.0;
    private static final double AMBUSH_TRIGGER   = 12.0;  // враг ближе → атака из засады
    private static final float  ROTATE_HP        = 8.0f;  // ниже → в резерв
    private static final int    ADAPT_INTERVAL   = 60;    // тиков между проверками адаптации

    // Состояние засады
    private boolean ambushMode = false;
    private int     adaptTimer = 0;

    private final Set<BotEntity> reserve = new java.util.LinkedHashSet<>(); // раненые в резерве

    private CommanderAI() {}

    // ── Засада ──────────────────────────────────────────────────

    public void enableAmbush(SquadManager.Squad squad, ServerPlayer owner) {
        ambushMode = true;
        // Остановить всех бойцов
        for (BotEntity bot : squad.allBots()) {
            bot.getNavigation().stop();
        }
        squad.currentOrder = SquadManager.CommanderOrder.STAND;
        if (owner != null)
            owner.sendSystemMessage(Component.literal("§6[Командир] §fОтряд в засаде. Ждём врага..."));
    }

    public void disableAmbush(SquadManager.Squad squad) {
        ambushMode = false;
        squad.currentOrder = SquadManager.CommanderOrder.ATTACK;
    }

    public boolean isAmbushMode() { return ambushMode; }

    // ── Основной тик ─────────────────────────────────────────────

    public void tick(SquadManager.Squad squad, ServerPlayer owner) {
        if (!(owner.level() instanceof ServerLevel level)) return;

        adaptTimer++;

        // Проверить засаду — враг вошёл в зону?
        if (ambushMode) {
            List<Player> enemies = scanEnemies(owner, level);
            if (!enemies.isEmpty()) {
                double nearest = enemies.stream()
                    .mapToDouble(squad.commander != null
                        ? e -> squad.commander.distanceTo(e)
                        : e -> owner.distanceTo(e))
                    .min().orElse(Double.MAX_VALUE);
                if (nearest < AMBUSH_TRIGGER) {
                    disableAmbush(squad);
                    if (owner != null)
                        owner.sendSystemMessage(Component.literal("§c[Командир] §fВраг в засаде! АТАКА!"));
                }
            }
            // adaptTimer продолжает накапливаться во время засады —
            // адаптация сработает сразу после выхода из неё
            return;
        }

        // Адаптация к врагу
        if (adaptTimer >= ADAPT_INTERVAL) {
            adaptTimer = 0;
            adaptToEnemy(squad, owner, level);
            rotateWounded(squad, owner);
        }
    }

    // ── Адаптация к врагу ────────────────────────────────────────

    private void adaptToEnemy(SquadManager.Squad squad, ServerPlayer owner, ServerLevel level) {
        List<Player> enemies = scanEnemies(owner, level);
        if (enemies.isEmpty()) return;

        Player nearest = enemies.get(0);

        // Анализ снаряжения врага
        boolean enemyHasCrystal = hasItem(nearest, "end_crystal");
        boolean enemyHasBow     = hasItem(nearest, "bow") || hasItem(nearest, "crossbow");
        boolean enemyFarAway    = owner.distanceTo(nearest) > 20.0;

        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        if (enemyHasCrystal && cfg.mode != PVPBotConfig.Mode.CRYSTAL) {
            // Враг использует кристаллы — переключить на CRYSTAL
            cfg.mode = PVPBotConfig.Mode.CRYSTAL;
            BotConfig.save();
            notify(owner, "§6[Командир] §fВраг на кристаллах — переключаю отряд на CRYSTAL кит!");

            // Перевооружить бойцов
            for (BotEntity bot : squad.allBots()) {
                if (bot.getSquadRole() == BotRole.SOLDIER || bot.getSquadRole() == BotRole.TANKER) {
                    BotKit.CRYSTAL.equipment.applyTo(bot);
                }
            }
        }

        if (enemyFarAway) {
            // Враг далеко — снайперы вперёд
            for (BotEntity bot : squad.soldiers) {
                if (bot.getSquadRole() == BotRole.SNIPER) {
                    bot.getNavigation().moveTo(nearest.getX(), nearest.getY(), nearest.getZ(), 1.0);
                }
            }
        }
    }

    // ── Ротация раненых ──────────────────────────────────────────

    /**
     * Раненых (HP < ROTATE_HP) выводим в "резерв" (стоят сзади, не атакуют).
     * Восстановившихся (HP > 15) возвращаем в строй.
     */
    private void rotateWounded(SquadManager.Squad squad, ServerPlayer owner) {
        boolean anyRotated = false;

        for (BotEntity bot : squad.soldiers) {
            if (!bot.isAlive()) continue;

            boolean inReserve = reserve.contains(bot);

            if (!inReserve && bot.getHealth() < ROTATE_HP) {
                // Вывести в резерв
                reserve.add(bot);
                bot.getNavigation().stop();
                anyRotated = true;
            } else if (inReserve && bot.getHealth() > 15.0f) {
                // Восстановился — вернуть в строй
                reserve.remove(bot);
                anyRotated = true;
            }
        }

        // Чистим мёртвых из резерва
        reserve.removeIf(b -> !b.isAlive());

        if (anyRotated && owner != null) {
            notify(owner, "§6[Командир] §fРотация — раненых в резерв (" + reserve.size() + ")");
        }
    }

    // ── Helpers ──────────────────────────────────────────────────

    private List<Player> scanEnemies(ServerPlayer owner, ServerLevel level) {
        AABB box = owner.getBoundingBox().inflate(ENEMY_SCAN_RANGE);
        return level.getEntitiesOfClass(Player.class, box,
            p -> p != owner && !p.isSpectator() && !p.isCreative() && p.isAlive());
    }

    private boolean hasItem(Player p, String itemId) {
        return p.getInventory().items.stream().anyMatch(stack ->
            !stack.isEmpty() &&
            net.minecraft.core.registries.BuiltInRegistries.ITEM
                .getKey(stack.getItem()).getPath().equals(itemId));
    }

    private void notify(ServerPlayer owner, String msg) {
        if (owner != null)
            owner.sendSystemMessage(Component.literal(msg));
    }

    public Set<BotEntity> getReserve() { return java.util.Collections.unmodifiableSet(reserve); }
}
