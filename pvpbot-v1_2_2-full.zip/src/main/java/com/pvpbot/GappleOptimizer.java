package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.food.FoodProperties;

import java.util.*;

/**
 * GappleOptimizer v1.0 — интеллектуальный расчёт оптимального момента
 * использования Golden Apple / Notch Apple.
 *
 * Логика принятия решения:
 *   1. Анализирует текущий HP бота/игрока
 *   2. Учитывает DPS входящего урона (скорость потери HP)
 *   3. Прогнозирует HP через N тиков без гапла
 *   4. Учит оптимальный порог из BotLearning (когда игрок пил гапл)
 *   5. Учитывает cooldown гапла (30с = 600 тиков)
 *   6. Нотч: только при HP < NOTCH_THRESHOLD и если нет гапла
 *
 * Интеграция:
 *   GappleOptimizer.INSTANCE.shouldUseGapple(bot) → true/false
 *   GappleOptimizer.INSTANCE.recordGappleEvent(hp) — вызывать из BotLearning
 *
 * Команды (добавить в SpawnBotCommand):
 *   /bot gapple [on|off|hp <val>|notch <val>]
 */
public class GappleOptimizer {

    public static final GappleOptimizer INSTANCE = new GappleOptimizer();

    // ── Пороги по умолчанию ───────────────────────────────────────
    /** HP при котором пьём гапл (по умолчанию) */
    public float defaultGappleHp = 12.0f;
    /** HP при котором пьём нотч-апл (абсолютный минимум) */
    public float notchAppleHp = 6.0f;
    /** Прогнозируем урон на N тиков вперёд */
    private static final int PREDICT_TICKS = 40;
    /** Cooldown гапла в тиках (30 секунд) */
    private static final int GAPPLE_COOLDOWN = 600;
    /** Минимальный HP, при котором нотч нужен всегда */
    private static final float CRITICAL_HP = 4.0f;

    private boolean enabled = true;

    // ── Cooldown tracker ─────────────────────────────────────────
    /** UUID бота → тик когда последний раз пил гапл */
    private final Map<java.util.UUID, Long> lastGappleTick = new HashMap<>();
    private long globalTick = 0;

    // ── Обучение на игроке (из BotLearning) ───────────────────────
    /** Список HP значений когда игрок использовал гапл */
    private final List<Float> learnedGappleHps = new ArrayList<>();
    /** Вычисленный "умный" порог */
    private float learnedThreshold = -1;

    // ── DPS трекер (последний урон) ───────────────────────────────
    private final Map<java.util.UUID, Float> prevHpMap = new HashMap<>();
    private final Map<java.util.UUID, Float> incomingDpsMap = new HashMap<>();

    private GappleOptimizer() {}

    public void globalTick() { globalTick++; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { enabled = v; }

    // ── BotLearning интеграция ────────────────────────────────────

    /** Вызывается из BotLearning когда игрок использовал гапл. */
    public void recordGappleEvent(float hp) {
        learnedGappleHps.add(hp);
        recalcLearnedThreshold();
    }

    private void recalcLearnedThreshold() {
        if (learnedGappleHps.size() < 3) return;
        // Берём 75-й перцентиль (пьём чуть пораньше)
        List<Float> sorted = new ArrayList<>(learnedGappleHps);
        Collections.sort(sorted);
        int idx = (int) (sorted.size() * 0.75);
        learnedThreshold = sorted.get(Math.min(idx, sorted.size() - 1));
    }

    // ── Основной метод ────────────────────────────────────────────

    /**
     * Решить, должен ли бот использовать гапл ПРЯМО СЕЙЧАС.
     * @param bot бот
     * @return true = нужно использовать гапл
     */
    public boolean shouldUseGapple(BotEntity bot) {
        if (!enabled) return false;
        if (!isOnCooldown(bot)) return false; // cooldown не истёк

        float hp = bot.getHealth();
        float maxHp = bot.getMaxHealth();
        updateDps(bot, hp);

        float threshold = getEffectiveThreshold();

        // Критически низкое HP — пьём всегда
        if (hp <= CRITICAL_HP) return true;

        // Прогноз: хватит ли HP через PREDICT_TICKS тиков без гапла?
        float dps = incomingDpsMap.getOrDefault(bot.getUUID(), 0.0f);
        float predictedHp = hp - dps * (PREDICT_TICKS / 20.0f);
        if (predictedHp <= threshold * 0.5f) return true;

        // Стандартный порог
        if (hp <= threshold) return true;

        return false;
    }

    /**
     * Решить, должен ли бот использовать НОТЧ.
     */
    public boolean shouldUseNotch(BotEntity bot) {
        if (!enabled) return false;
        float hp = bot.getHealth();
        return hp <= notchAppleHp && isOnCooldown(bot);
    }

    /**
     * Вызывать после использования гапла чтобы запустить cooldown.
     */
    public void onGappleUsed(BotEntity bot) {
        lastGappleTick.put(bot.getUUID(), globalTick);
        prevHpMap.put(bot.getUUID(), bot.getHealth() + 8.0f); // гапл дал HP
    }

    // ── Вспомогательные ──────────────────────────────────────────

    private boolean isOnCooldown(BotEntity bot) {
        Long last = lastGappleTick.get(bot.getUUID());
        if (last == null) return true; // ни разу не пил = доступен
        return (globalTick - last) >= GAPPLE_COOLDOWN;
    }

    private float getEffectiveThreshold() {
        if (learnedThreshold > 0) {
            // Смешиваем: 60% умный порог + 40% дефолт
            return learnedThreshold * 0.6f + defaultGappleHp * 0.4f;
        }
        return defaultGappleHp;
    }

    private void updateDps(BotEntity bot, float currentHp) {
        Float prev = prevHpMap.get(bot.getUUID());
        if (prev != null) {
            float hpLost = prev - currentHp;
            if (hpLost > 0) {
                // Экспоненциальное сглаживание DPS
                float prevDps = incomingDpsMap.getOrDefault(bot.getUUID(), 0.0f);
                float newDps = prevDps * 0.7f + (hpLost * 20.0f) * 0.3f; // DPS = урон/сек
                incomingDpsMap.put(bot.getUUID(), newDps);
            }
        }
        prevHpMap.put(bot.getUUID(), currentHp);
    }

    /** Получить предполагаемый тип предмета для использования. */
    public net.minecraft.world.item.Item getBestHealItem(BotEntity bot, boolean hasNotch, boolean hasGapple) {
        if (shouldUseNotch(bot) && hasNotch) return Items.ENCHANTED_GOLDEN_APPLE;
        if (shouldUseGapple(bot) && hasGapple) return Items.GOLDEN_APPLE;
        return null;
    }

    /** Форматировать статус для чата. */
    public String formatStatus() {
        return "§e§lGappleOptimizer:\n" +
            "§7Статус:    §f" + (enabled ? "§aВКЛ" : "§cВЫКЛ") + "\n" +
            "§7Гапл HP:   §f" + defaultGappleHp + "\n" +
            "§7Нотч HP:   §f" + notchAppleHp + "\n" +
            "§7Умный порог: §f" + (learnedThreshold > 0
                ? String.format("%.1f", getEffectiveThreshold()) + " (из " + learnedGappleHps.size() + " замеров)"
                : "§7(нет данных — нужен /bot learn)") + "\n" +
            "§7Cooldown:  §f30с (600 тиков)";
    }
}
