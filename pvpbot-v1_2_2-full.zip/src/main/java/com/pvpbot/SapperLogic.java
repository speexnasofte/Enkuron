package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * SapperLogic — поведение роли SAPPER (Сапёр).
 *
 * Сапёр:
 *  - Забегает AHEAD_DIST блоков вперёд от цели
 *  - Размещает кристалл Энда под ногами врага
 *  - Или взрывает TNT если кристаллов нет
 *  - Отступает назад после закладки
 *  - Кулдаун PLACE_CD тиков между закладками
 *
 * Вызывается из BotEntity.tick() если bot.getSquadRole() == SAPPER.
 */
public class SapperLogic {

    public static final SapperLogic INSTANCE = new SapperLogic();

    private static final double AHEAD_DIST  = 3.0;   // насколько вперёд от врага
    private static final double PLACE_RANGE = 5.0;   // с какой дистанции может ставить
    private static final int    PLACE_CD    = 80;    // тиков между закладками
    private static final int    RETREAT_TIME = 20;   // тиков отступления после закладки

    private SapperLogic() {}

    public void tick(BotEntity bot, LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel level)) return;
        if (target == null || !target.isAlive()) return;

        if (bot.sapperCooldown > 0) {
            // Отступить сразу после закладки (первые RETREAT_TIME тиков кулдауна)
            if (bot.sapperCooldown > PLACE_CD - RETREAT_TIME) {
                Vec3 away = bot.position().subtract(target.position()).normalize().scale(6.0);
                Vec3 goal = bot.position().add(away);
                bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.2);
            }
            bot.sapperCooldown--;
            return;
        }

        double dist = bot.distanceTo(target);

        if (dist > PLACE_RANGE) {
            // Подойти к цели
            Vec3 dir  = target.position().subtract(bot.position()).normalize();
            Vec3 goal = target.position().subtract(dir.scale(AHEAD_DIST));
            bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.1);
        } else {
            // Разместить ловушку рядом с врагом
            placeTrap(bot, target, level);
            bot.sapperCooldown = PLACE_CD;
        }
    }

    // ── Размещение ───────────────────────────────────────────────

    private void placeTrap(BotEntity bot, LivingEntity target, ServerLevel level) {
        // Попытка 1: поставить кристалл Энда
        BlockPos targetFeet = target.blockPosition();

        // Ищем свободный блок рядом с врагом
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos pos = targetFeet.offset(dx, 0, dz);
                if (level.getBlockState(pos).isAir() &&
                    !level.getBlockState(pos.below()).isAir()) {
                    spawnCrystalAt(bot, level, pos);
                    return;
                }
            }
        }
    }

    private void spawnCrystalAt(BotEntity bot, ServerLevel level, BlockPos pos) {
        // Создаём заряженный TNT как ловушку (кристалл требует особых условий спавна)
        net.minecraft.world.entity.item.PrimedTnt tnt =
            new net.minecraft.world.entity.item.PrimedTnt(level,
                pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, bot);
        tnt.setFuse(40); // 2 секунды
        level.addFreshEntity(tnt);

        // Оповещение командиру
        notifyOwner(bot, pos);
    }

    private void notifyOwner(BotEntity bot, BlockPos pos) {
        net.minecraft.world.entity.player.Player owner = bot.getOwner();
        if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
            sp.sendSystemMessage(
                net.minecraft.network.chat.Component.literal(
                    "§e[Сапёр] §fЗаложил ловушку у §c" +
                    pos.getX() + ", " + pos.getY() + ", " + pos.getZ()
                )
            );
        }
    }
}
