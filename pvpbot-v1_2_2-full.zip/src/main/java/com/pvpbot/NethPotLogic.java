package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * NethPotLogic v3.0 — умный Potion PvP.
 * ИСПРАВЛЕНО:
 *  - Движение через Navigation
 *  - Страф через StrafeAI
 *  - Invis + отход через navigation, не deltaMovement
 */
public class NethPotLogic {

    private static final double SPLASH_RANGE   = 4.5;
    private static final double MELEE_RANGE    = 3.0;
    private static final double OPTIMAL_SPLASH = 2.8;
    private static final int    HARMING_CD     = 35;
    private static final int    HEALING_CD     = 40;
    private static final int    SPEED_CD       = 400;
    private static final int    FIRE_RES_CD    = 600;
    private static final int    INVIS_CD       = 300;
    private static final int    MELEE_CD       = 8;
    private static final int    CRIT_EVERY     = 4;

    private final BotEntity bot;
    private final StrafeAI  strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int harmingCd = 0, healingCd = 0, speedCd = 0, fireResCd = 0, invisCd = 0, meleeCd = 0;
    private int hitCount  = 0;
    private boolean critPending = false;

    public NethPotLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (harmingCd > 0) harmingCd--;
        if (healingCd > 0) healingCd--;
        if (speedCd   > 0) speedCd--;
        if (fireResCd > 0) fireResCd--;
        if (invisCd   > 0) invisCd--;
        if (meleeCd   > 0) meleeCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // Speed II в начале
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }

        // Fire Resistance
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }

        // Критическое HP — Invis + отход через navigation
        if (myHp < 6.0f && invisCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 600, 0));
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 8, bot.getY(), bot.getZ() + away.z * 8, 1.3
            );
            bot.setSprinting(true);
            invisCd = INVIS_CD;
            return;
        }

        // Healing II
        if (myHp < 10.0f && healingCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 1));
            healingCd = HEALING_CD;
        }

        // Страф + navigation
        if (dist < OPTIMAL_SPLASH + 1.0) {
            strafe.tick(target);
        } else {
            bot.getNavigation().moveTo(target, 1.0);
        }

        // Harming на врага
        if (dist <= SPLASH_RANGE && harmingCd <= 0) {
            boolean slow = target.getDeltaMovement().horizontalDistanceSqr() < 0.04;
            if (dist <= OPTIMAL_SPLASH || slow) {
                throwHarming(sw, target);
                harmingCd = HARMING_CD;
            }
        }

        // Меч между разливами (с критами)
        if (dist <= MELEE_RANGE && meleeCd <= 0 && harmingCd > 5) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; meleeCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                equipSword(); bot.doHurtTarget(sw, target);
                sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 5,0.2,0.2,0.2,0.1);
                hitCount++; critPending = false; meleeCd = MELEE_CD;
            } else {
                equipSword(); bot.doHurtTarget(sw, target); hitCount++; critPending = false; meleeCd = MELEE_CD;
            }
        }
    }

    private void throwHarming(ServerLevel sw, LivingEntity target) {
        target.hurt(sw.damageSources().magic(), 12.0f);
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(target.position(),target.position()).inflate(2.0),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().magic(), 6.0f));
        sw.sendParticles(ParticleTypes.INSTANT_EFFECT, target.getX(), target.getY()+1, target.getZ(), 16,0.5,0.5,0.5,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 1.0f, 1.2f);
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }
}
