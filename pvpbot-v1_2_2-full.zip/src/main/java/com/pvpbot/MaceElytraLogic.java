package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * MaceElytraLogic v3.0 — умный MACE+ELYTRA.
 * ИСПРАВЛЕНО:
 *  - В IDLE: navigation к цели (не стоит на месте)
 *  - ASCEND: импульс вверх только один раз через setDeltaMovement Y (не накапливается)
 *  - GLIDE_AIM: управление через navigation.stop() + прямой deltaMovement (элитра)
 *  - После SMASH: не setDeltaMovement нулём, а плавное гашение
 */
public class MaceElytraLogic {

    private static final double ASCEND_HEIGHT = 12.0;
    private static final double SMASH_DIST    = 3.5;
    private static final int    FULL_CD       = 50;
    private static final int    FW_INTERVAL   = 22;
    private static final int    MAX_FW        = 2;
    private static final float  BASE_DAMAGE   = 8.0f;
    private static final float  VEL_MULT      = 6.0f;
    private static final float  MAX_DAMAGE    = 28.0f;

    private enum Phase { IDLE, ASCEND, GLIDE_AIM, DIVE_SMASH, COOLDOWN }
    private Phase phase = Phase.IDLE;

    private int cdTimer = 0, fwTimer = 0, fwUsed = 0, diveTimeout = 0;
    private double speedAtHit = 0;
    private double ascendTargetY = 0;

    private final BotEntity bot;

    public MaceElytraLogic(BotEntity bot) { this.bot = bot; }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { phase = Phase.IDLE; return; }

        if (cdTimer  > 0) cdTimer--;
        if (fwTimer  > 0) fwTimer--;

        switch (phase) {
            case IDLE       -> tickIdle(sw, target);
            case ASCEND     -> tickAscend(sw, target);
            case GLIDE_AIM  -> tickGlide(sw, target);
            case DIVE_SMASH -> tickSmash(sw, target);
            case COOLDOWN   -> { if (cdTimer <= 0) phase = Phase.IDLE; }
            default: break;
        }
    }

    private void tickIdle(ServerLevel sw, LivingEntity target) {
        if (cdTimer > 0) return;
        equipKit();
        double dist = bot.distanceTo(target);
        if (dist > 20.0) { bot.getNavigation().moveTo(target, 1.2); return; }
        // Начинаем подъём
        ascendTargetY = target.getY() + ASCEND_HEIGHT;
        fwUsed = 0; fwTimer = 0;
        phase  = Phase.ASCEND;
        bot.getNavigation().stop();
    }

    private void tickAscend(ServerLevel sw, LivingEntity target) {
        equipKit();
        double y    = bot.getY();
        double left = ascendTargetY - y;

        // Фейерверк для тяги вверх
        if (fwTimer <= 0 && fwUsed < MAX_FW && left > 2.0) {
            launchFW(sw);
            fwTimer = FW_INTERVAL;
            fwUsed++;
        }

        // Движение к цели XZ + вверх
        if (y < ascendTargetY - 0.5) {
            Vec3 vel = bot.getDeltaMovement();
            Vec3 xz  = new Vec3(target.getX()-bot.getX(), 0, target.getZ()-bot.getZ()).normalize().scale(0.25);
            bot.setDeltaMovement(
                clamp(vel.x + xz.x, -0.8, 0.8),
                Math.max(vel.y, 0.2),
                clamp(vel.z + xz.z, -0.8, 0.8)
            );
        } else {
            phase = Phase.GLIDE_AIM; diveTimeout = 120;
        }

        if (bot.tickCount % 4 == 0)
            sw.sendParticles(ParticleTypes.CLOUD, bot.getX(), bot.getY(), bot.getZ(), 2,0.2,0.1,0.2,0.04);
    }

    private void tickGlide(ServerLevel sw, LivingEntity target) {
        diveTimeout--;
        if (diveTimeout <= 0) { phase = Phase.COOLDOWN; cdTimer = FULL_CD / 2; return; }

        double dist = bot.distanceTo(target);
        Vec3 toTarget = target.getEyePosition().subtract(bot.position()).normalize();
        Vec3 vel      = bot.getDeltaMovement();

        // Разгоняемся к цели
        if (vel.length() < 1.2) {
            bot.setDeltaMovement(
                clamp(vel.x + toTarget.x * 0.35, -2.5, 2.5),
                vel.y + toTarget.y * 0.35 - 0.08,
                clamp(vel.z + toTarget.z * 0.35, -2.5, 2.5)
            );
        }
        bot.getLookControl().setLookAt(target, 180, 80);

        if (dist <= SMASH_DIST) {
            equipChestForSmash(); phase = Phase.DIVE_SMASH; tickSmash(sw, target);
        } else if (bot.onGround() && diveTimeout < 80) {
            phase = Phase.COOLDOWN; cdTimer = FULL_CD;
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        Vec3 vel  = bot.getDeltaMovement();
        speedAtHit = vel.length();
        float dmg = Math.min(MAX_DAMAGE, BASE_DAMAGE + (float)(speedAtHit * VEL_MULT));

        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        bot.doHurtTarget(sw, target);

        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(kb.x * 2.0, 1.5, kb.z * 2.0);

        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 20,0.6,0.6,0.6,0.3);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.8f);

        // Плавное гашение (не обнуляем)
        bot.setDeltaMovement(vel.x*0.2, Math.max(vel.y*0.1, 0), vel.z*0.2);

        notifyOwner(String.format("§6[MaceElytra] §cSmash! §e%.1f dmg §7(spd: %.2f)", dmg, speedAtHit));
        equipKit();
        phase = Phase.COOLDOWN; cdTimer = FULL_CD;
    }

    private void launchFW(ServerLevel sw) {
        FireworkRocketEntity fw = new FireworkRocketEntity(sw, bot, bot.getX(), bot.getY(), bot.getZ(), new ItemStack(Items.FIREWORK_ROCKET));
        fw.setDeltaMovement(0, 1.8, 0);
        sw.addFreshEntity(fw);
        sw.sendParticles(ParticleTypes.FIREWORK, bot.getX(), bot.getY()-0.5, bot.getZ(), 6,0.2,0.1,0.2,0.15);
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
    }

    private void equipKit() {
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        equipMace();
    }

    private void equipChestForSmash() {
        bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
    }

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    private double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    public String getStateLabel() {
        return switch (phase) {
            case IDLE       -> "ME:IDLE";
            case ASCEND     -> "ME:ASCEND";
            case GLIDE_AIM  -> "ME:DIVE";
            case DIVE_SMASH -> "ME:SMASH!";
            case COOLDOWN   -> "ME:CD";
            default     -> "?";
        };
    }
    public double getLastHitSpeed() { return speedAtHit; }
    public boolean isActive() { return phase == Phase.GLIDE_AIM || phase == Phase.DIVE_SMASH; }
}
