package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * PVPBotLogic — серверная PvP-логика для NPC-бота (BotEntity).
 *
 * Переписано в v1.2: убран весь Minecraft / client.options.
 * Теперь работает только на серверной стороне через BotEntity API.
 *
 * Вызывается из BotEntity.tick() когда есть цель.
 *
 * Что делает:
 *   - Находит ближайшего врага (не владельца, не своих ботов)
 *   - Крит-прыжок перед атакой (BotCritMeleeGoal уже делает это,
 *     PVPBotLogic дополняет логикой кулдауна и DPS-записи)
 *   - AutoHeal — NPC ест золотое яблоко когда HP низкое
 *   - AutoSprint — NPC всегда спринтует к цели
 *   - Dodge — уклонение velocity-импульсом в сторону
 *   - Strafe — навигация по дуге вокруг цели
 *   - FightAnalyzer / KillDeathTracker интеграция
 */
public class PVPBotLogic {

    private final PVPBotConfig cfg     = PVPBotConfig.INSTANCE;
    private final BotEntity    bot;

    private int     attackTimer   = 0;
    private int     dodgeTimer    = 0;
    private int     strafeTimer   = 0;
    private int     strafeDir     = 1;
    private boolean jumpedForCrit = false;

    // Отслеживаем смену цели для DPS
    private UUID lastTargetUUID = null;

    // ── OPT v8: кэш поиска врага — сканируем не каждый тик ──────
    private LivingEntity cachedEnemy      = null;
    private int          enemyCacheTicks  = 0;
    private static final int ENEMY_CACHE_LIFE = 10; // тиков кэша

    public PVPBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик — вызывать из BotEntity.tick()
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        if (attackTimer > 0) attackTimer--;
        if (dodgeTimer  > 0) dodgeTimer--;
        if (strafeTimer > 0) strafeTimer--;

        // ── AutoHeal: NPC ест гэпл при низком HP ─────────────────
        if (cfg.autoHeal) {
            tickAutoHeal(sw);
        }

        // ── AutoSprint — только при движении к цели ──────────────
        // (не спринтуем постоянно — это выглядит как чит)

        // ── Цель (с кэшем — не сканируем каждый тик) ─────────────
        enemyCacheTicks--;
        if (enemyCacheTicks <= 0 || cachedEnemy == null || !cachedEnemy.isAlive()) {
            cachedEnemy     = findNearestEnemy(sw);
            enemyCacheTicks = ENEMY_CACHE_LIFE;
        }
        LivingEntity target = cachedEnemy;

        if (target != null) {
            // DPS: отслеживаем смену цели
            UUID targetUUID = target.getUUID();
            if (!targetUUID.equals(lastTargetUUID)) {
                DpsMeter.INSTANCE.onTargetChanged(targetUUID);
                lastTargetUUID = targetUUID;
            }

            lookAtTarget(target);
            double dist = bot.distanceTo(target);

            // ── Кайтинг (если включён) ────────────────────────────
            if (cfg.kiteEnabled) {
                bot.getBotKiteLogic().tick(target);
                return;
            }

            // ── Dodge: уклонение когда враг слишком близко ────────
            if (cfg.autoDodge && dist < cfg.dodgeRange && dodgeTimer <= 0) {
                dodge(target);
                dodgeTimer = 15;
            }

            // ── v8: SmokeBomb — снежок в убегающего врага ────────
            SmokeBombLogic.INSTANCE.tick(bot, target);

            // ── Атака или движение ────────────────────────────────
            if (cfg.autoAttack && dist <= cfg.attackRange && attackTimer <= 0) {
                // Спринт только при сближении
                if (dist > cfg.attackRange * 0.7 && !bot.isSprinting()) {
                    bot.setSprinting(true);
                } else if (dist < cfg.attackRange * 0.5 && bot.isSprinting()) {
                    bot.setSprinting(false);
                }
                tickAttack(sw, target);
            } else if (dist > cfg.attackRange) {
                // Спринтуем к цели
                if (!bot.isSprinting()) bot.setSprinting(true);
                tickMoveWithStrafe(target);
                // FightAnalyzer — атака не состоялась (цель вне дистанции)
                if (cfg.statsEnabled && attackTimer <= 0) {
                    FightAnalyzer.INSTANCE.onMiss();
                }
            }

            // FightAnalyzer: отслеживаем бой
            if (cfg.statsEnabled) {
                FightAnalyzer.INSTANCE.onFightStart(target.getName().getString());
            }

        } else {
            lastTargetUUID = null;
            jumpedForCrit  = false;
            // Нет цели — останавливаем навигацию если BotHunt не активен
            if (!cfg.huntEnabled) {
                bot.getNavigation().stop();
            }
        }
    }

    // ── Крит-атака ────────────────────────────────────────────────
    private void tickAttack(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Не прыгаем для крита если враг убегает быстро — просто бьём
        boolean targetFleeing = target.getDeltaMovement().horizontalDistanceSqr() > 0.06
            && target.distanceTo(bot) > cfg.attackRange * 0.8;

        if (bot.onGround() && !jumpedForCrit && !targetFleeing) {
            bot.getJumpControl().jump();
            jumpedForCrit = true;
        } else if (jumpedForCrit && !bot.onGround() && bot.getDeltaMovement().y < 0) {
            // Падаем вниз — это и есть крит (fallDistance > 0 && !onGround && yVel < 0)
            bot.doHurtTarget(sw, target);
            jumpedForCrit = false;

            float estimatedDamage = 7.0f;
            if (cfg.statsEnabled) {
                KillDeathTracker.recordHit(target.getUUID());
                DpsMeter.INSTANCE.recordDamage(target, estimatedDamage);
                FightAnalyzer.INSTANCE.onHit(estimatedDamage);
            }

            attackTimer = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown()
                : cfg.attackCooldown;

        } else if (jumpedForCrit && bot.onGround()) {
            // Прыжок не получился — бьём без крита
            bot.doHurtTarget(sw, target);
            jumpedForCrit = false;

            float estimatedDamage = 5.0f;
            if (cfg.statsEnabled) {
                KillDeathTracker.recordHit(target.getUUID());
                DpsMeter.INSTANCE.recordDamage(target, estimatedDamage);
                FightAnalyzer.INSTANCE.onHit(estimatedDamage);
            }

            attackTimer = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown()
                : cfg.attackCooldown;

        } else if (!jumpedForCrit && targetFleeing) {
            // Враг убегает — бьём сразу без крита
            bot.doHurtTarget(sw, target);

            float estimatedDamage = 5.0f;
            if (cfg.statsEnabled) {
                KillDeathTracker.recordHit(target.getUUID());
                DpsMeter.INSTANCE.recordDamage(target, estimatedDamage);
                FightAnalyzer.INSTANCE.onHit(estimatedDamage);
            }

            attackTimer = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown()
                : cfg.attackCooldown;
        }
    }

    // ── Движение к цели со страфом (через Navigation, не velocity) ─
    private void tickMoveWithStrafe(LivingEntity target) {
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = 18 + bot.level().getRandom().nextInt(14);
        }

        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 side = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);

        // Целевая точка: чуть сбоку от врага (страф через navigation)
        Vec3 strafeTarget = target.position()
            .add(side.scale(2.0))
            .subtract(toTarget.scale(1.5));

        // Проверяем что точка не в блоке
        net.minecraft.core.BlockPos checkPos = net.minecraft.core.BlockPos.containing(
            strafeTarget.x, strafeTarget.y + 0.1, strafeTarget.z
        );
        boolean blocked = bot.level().getBlockState(checkPos).isSolid();

        if (blocked) {
            // Страф заблокирован — идём прямо к цели
            bot.getNavigation().moveTo(target, 1.3);
        } else {
            bot.getNavigation().moveTo(strafeTarget.x, strafeTarget.y, strafeTarget.z, 1.3);
        }
    }

    // ── Поиск ближайшего врага ────────────────────────────────────
    private LivingEntity findNearestEnemy(ServerLevel sw) {
        AABB searchBox = bot.getBoundingBox().inflate(cfg.attackRange + 4.0);
        List<LivingEntity> entities = sw.getEntitiesOfClass(
            LivingEntity.class, searchBox,
            e -> e != bot
                && e.isAlive()
                && !e.isInvisible()
                // Не атакуем владельца
                && !(e instanceof Player p
                     && bot.getOwner() != null
                     && p.getUUID().equals(bot.getOwner().getUUID()))
                // Не атакуем других ботов того же владельца
                && !(e instanceof BotEntity other
                     && bot.getOwner() != null
                     && bot.getOwner().getUUID().equals(
                         other.getOwner() != null ? other.getOwner().getUUID() : null))
                // Whitelist проверка
                && !isWhitelisted(e)
        );
        return entities.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);
    }

    // ── AutoHeal: NPC ест Golden Apple из инвентаря ───────────────
    private void tickAutoHeal(ServerLevel sw) {
        if (bot.getHealth() > cfg.botHealThreshold) return;

        // Ищем Golden Apple в снаряжении (equipStack)
        ItemStack gap = new ItemStack(Items.GOLDEN_APPLE);
        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);

        // Если уже держим гэпл — «едим» (восстанавливаем HP напрямую,
        // т.к. NPC не может использовать предметы как игрок)
        if (main.is(Items.GOLDEN_APPLE) || main.is(Items.ENCHANTED_GOLDEN_APPLE)) {
            // Применяем эффект вручную: +4 HP мгновенно (Instant Health I)
            bot.heal(4.0f);
            // Снимаем один гэпл из стека
            main.shrink(1);
            if (main.isEmpty()) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            }
            if (cfg.statsEnabled) {
                FightAnalyzer.INSTANCE.onGappleUsed();
            }
            return;
        }

        // Временно экипируем гэпл — текущий предмет вернёт ModeLogicDispatcher
        bot.setItemSlot(EquipmentSlot.MAINHAND, gap);
    }

    // ── Dodge: velocity-импульс в сторону ─────────────────────────
    private void dodge(LivingEntity target) {
        Vec3 toEnemy  = target.position().subtract(bot.position()).normalize();
        Vec3 dodgeDir = new Vec3(-toEnemy.z, 0, toEnemy.x);
        bot.setDeltaMovement(bot.getDeltaMovement().add(
            dodgeDir.x * 0.5, 0.3, dodgeDir.z * 0.5
        ));
    }

    // ── Поворот к цели ────────────────────────────────────────────
    private void lookAtTarget(LivingEntity target) {
        Vec3 diff  = target.getEyePosition().subtract(bot.getEyePosition());
        double hDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(diff.y, hDist));
        bot.setYRot(lerpAngle(bot.getYRot(), yaw, 0.35f));
        bot.setXRot(lerp(bot.getXRot(), pitch, 0.35f));
        bot.setYHeadRot(bot.getYRot());
        bot.setYBodyRot(bot.getYRot());
    }

    // ── Whitelist ─────────────────────────────────────────────────
    private boolean isWhitelisted(LivingEntity e) {
        if (!cfg.whitelistEnabled) return false;
        if (!(e instanceof Player p)) return false;
        return cfg.whitelist.contains(p.getName().getString());
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private float lerpAngle(float a, float b, float t) {
        float diff = ((b - a) % 360 + 540) % 360 - 180;
        return a + diff * t;
    }
}
