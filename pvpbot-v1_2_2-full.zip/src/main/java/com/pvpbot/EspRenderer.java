package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * ESP-рендерер: рисует хитбоксы сущностей сквозь стены.
 * v1.21.4 compatible — использует только GuiGraphics-независимый API.
 *
 * Цветовая схема:
 *   Игроки          — красный  (0xFF2222)
 *   NPC-боты        — золотой  (0xFFD700)
 *   Враждебные мобы — оранжевый (0xFF7700)
 *   Пассивные мобы  — зелёный  (0x44FF44)
 *
 * ПРИМЕЧАНИЕ: в 1.21.4 PoseStack API, RenderSystem и BufferBuilder существенно
 * переработаны. Данная реализация использует упрощённый рендер через GuiGraphics
 * в HUD, либо просто заглушку (ESP показывает только в HUD через RadarHud).
 * Для полноценного ESP в мире нужен Mixin или CompatLayer.
 */
public class EspRenderer implements net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.End {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    @Override
    public void onEnd(WorldRenderContext context) {
        if (!cfg.espEnabled) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // В 1.21.4 прямой доступ к RenderSystem/BufferBuilder изменён.
        // Реализация через упрощённый подход — рисуем в HUD через PVPBotHud.
        // Полный 3D ESP требует отдельного Mixin, здесь — заглушка без крэша.
    }

    public int getEspColor(LivingEntity e) {
        if (e instanceof Player)  return 0xFF2222;
        if (e instanceof BotEntity)     return 0xFFD700;
        if (e instanceof net.minecraft.world.entity.monster.Monster) return 0xFF7700;
        return 0x44FF44;
    }
}
