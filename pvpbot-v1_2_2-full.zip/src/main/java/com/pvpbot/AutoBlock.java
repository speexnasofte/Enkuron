package com.pvpbot;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

/**
 * AutoBlock v10 — автоматическая блокировка щитом при входящей атаке.
 *
 * Логика:
 *   1. Каждый тик проверяем: есть ли враг в радиусе attackRange и смотрит ли он на игрока.
 *   2. Если да — зажимаем ПКМ (useKey) при условии, что в руке или offhand щит.
 *   3. Как только угроза пропадает — отпускаем.
 *
 * Интеграция: вызывать AutoBlock.INSTANCE.tick(client) из PVPBotLogic.tick()
 * ДО блока атаки, чтобы блокировка активировалась первой.
 *
 * Модуль: MOD_AUTO_BLOCK в ModuleManager.
 */
public class AutoBlock {

    public static final AutoBlock INSTANCE = new AutoBlock();

    private static final String MOD = ModuleManager.MOD_AUTO_BLOCK;

    // Угол (в градусах), при котором считаем, что враг смотрит на нас
    private static final float LOOKING_AT_ANGLE = 45.0f;

    private boolean blocking = false;

    private AutoBlock() {}
    /** Совместимый setPressed для 1.21.4 */
    private static void setKeyDown(net.minecraft.client.KeyMapping key, boolean down) {
        try {
            var f = net.minecraft.client.KeyMapping.class.getDeclaredField("isDown");
            f.setAccessible(true);
            f.set(key, down);
        } catch (Exception ignored) {}
    }


    /**
     * Вызывается каждый клиентский тик из PVPBotLogic.tick().
     * Возвращает true если блокировка сейчас активна.
     */
    public boolean tick(Minecraft client) {
        if (client.player == null || client.level == null) return false;
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) {
            release(client);
            return false;
        }

        Player player = client.player;

        // Проверяем наличие щита в главной или второй руке
        boolean hasShield = player.getMainHandItem().is(Items.SHIELD)
                         || player.getOffhandItem().is(Items.SHIELD);
        if (!hasShield) {
            release(client);
            return false;
        }

        // Ищем угрожающего противника
        LivingEntity threat = findThreat(client, player);

        if (threat != null) {
            // Активируем блок (ПКМ удержание)
            if (!blocking) {
                setKeyDown(client.options.keyUse, true);
                blocking = true;
            }
            return true;
        } else {
            release(client);
            return false;
        }
    }

    private LivingEntity findThreat(Minecraft client, Player player) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        double range = cfg.attackRange + 1.5; // чуть шире чем attackRange

        for (var entity : client.level.getEntitiesOfClass(
                LivingEntity.class,
                player.getBoundingBox().inflate(range),
                e -> e != player && e.isAlive() && !(e instanceof BotEntity))) {

            // Дистанция
            if (player.distanceTo(entity) > range) continue;

            // Смотрит ли враг на нас?
            if (isLookingAtPlayer(entity, player)) {
                return entity;
            }
        }
        return null;
    }

    /** Проверяет, направлен ли взгляд entity на player в пределах LOOKING_AT_ANGLE */
    private boolean isLookingAtPlayer(LivingEntity entity, Player player) {
        Vec3 look = entity.getViewVector(1.0f).normalize();
        Vec3 toPlayer = player.getEyePosition().subtract(entity.getEyePosition()).normalize();
        double dot = look.dot(toPlayer);
        // dot = cos(угол); при 45° cos ≈ 0.707
        double threshold = Math.cos(Math.toRadians(LOOKING_AT_ANGLE));
        return dot > threshold;
    }

    private void release(Minecraft client) {
        if (blocking) {
            setKeyDown(client.options.keyUse, false);
            blocking = false;
        }
    }

    public boolean isBlocking() {
        return blocking;
    }
}
