package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * TridentLogic v3.0 — умный TRIDENT.
 * ИСПРАВЛЕНО:
 *  - Riptide: navigation быстрый + импульс (не только deltaMovement)
 *  - Движение через navigation (не только deltaMovement)
 *  - Страф через StrafeAI
 *  - Рекурсия isEntityWet убрана
 */
public class TridentLogic {

    private static final double THROW_RANGE   = 14.0;
    private static final double MELEE_RANGE   = 3.5;
    private static final double RIPTIDE_RANGE = 12.0;
    private static final int    CHANNEL_CD    = 40;
    private static final int    RIPTIDE_CD    = 35;
    private static final int    MELEE_CD      = 15;
    private static final float  TRIDENT_DMG   = 8.0f;
    private static final float  LIGHTNING_DMG = 5.0f;
    private static final float  RIPTIDE_DMG   = 11.0f;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int chanCd = 0, riptideCd = 0, meleeCd = 0, riptideTick = 0;

    public TridentLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (chanCd    > 0) chanCd--;
        if (riptideCd > 0) riptideCd--;
        if (meleeCd   > 0) meleeCd--;
        if (riptideTick > 0) riptideTick--;

        equipTrident();

        double dist     = bot.distanceTo(target);
        boolean tgtWet  = isWet(sw, target);
        boolean botWet  = isWet(sw, bot);
        boolean raining = sw.isRaining() && sw.canSeeSky(bot.blockPosition());

        // После Riptide — добиваем мечом
        if (riptideTick > 0 && dist <= MELEE_RANGE + 1.5 && meleeCd <= 0) {
            doMelee(sw, target); return;
        }

        // Channeling
        if ((tgtWet || raining) && dist <= THROW_RANGE && chanCd <= 0) {
            doChanneling(sw, target); return;
        }

        // Riptide
        if ((botWet || raining) && dist > MELEE_RANGE && dist <= RIPTIDE_RANGE && riptideCd <= 0) {
            doRiptide(sw, target); return;
        }

        // Меле
        if (dist <= MELEE_RANGE && meleeCd <= 0) { doMelee(sw, target); return; }

        // Подход через navigation
        if (dist > MELEE_RANGE) {
            bot.getNavigation().moveTo(target, 1.1);
            if (dist < MELEE_RANGE + 3.0) strafe.tick(target);
        }
    }

    private void doChanneling(ServerLevel sw, LivingEntity target) {
        Vec3 dir = target.getEyePosition().subtract(bot.getEyePosition()).normalize();
        ThrownTrident t3 = new ThrownTrident(sw, bot, new ItemStack(Items.TRIDENT));
        t3.setDeltaMovement(dir.x*2.2, dir.y*2.2, dir.z*2.2);
        t3.setPos(bot.getX(), bot.getEyeY()-0.1, bot.getZ());
        sw.addFreshEntity(t3);

        target.hurt(sw.damageSources().playerAttack(null), TRIDENT_DMG);

        if (isWet(sw, target)) {
            net.minecraft.world.entity.LightningBolt lb = new net.minecraft.world.entity.LightningBolt(
                net.minecraft.world.entity.EntityType.LIGHTNING_BOLT, sw);
            lb.setPos(target.getX(), target.getY(), target.getZ());
            sw.addFreshEntity(lb);
            target.hurt(sw.damageSources().lightningBolt(), LIGHTNING_DMG);
            target.igniteForSeconds(8);
        }

        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 10,0.3,0.3,0.3,0.15);
        bot.playSound(SoundEvents.TRIDENT_THROW.value(), 1.0f, 1.0f);
        chanCd = CHANNEL_CD;
        bot.getNavigation().moveTo(target, 1.2);
    }

    private void doRiptide(ServerLevel sw, LivingEntity target) {
        // Navigation + импульс (не только импульс)
        bot.getNavigation().moveTo(target, 1.5);
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        Vec3 vel = bot.getDeltaMovement();
        bot.setDeltaMovement(dir.x*2.0, vel.y+0.3, dir.z*2.0);
        bot.setSprinting(true);

        double dist = bot.distanceTo(target);
        if (dist <= MELEE_RANGE + 3.0) {
            target.hurt(sw.damageSources().playerAttack(null), RIPTIDE_DMG);
            target.setDeltaMovement(dir.x*1.5, 0.6, dir.z*1.5);
            sw.sendParticles(ParticleTypes.SPLASH, target.getX(), target.getY(), target.getZ(), 16,0.4,0.3,0.4,0.15);
            bot.playSound(SoundEvents.TRIDENT_RIPTIDE_3.value(), 1.0f, 1.0f);
        }
        riptideTick = 20; riptideCd = RIPTIDE_CD;
    }

    private void doMelee(ServerLevel sw, LivingEntity target) {
        bot.getLookControl().setLookAt(target, 30f, 30f);
        bot.doHurtTarget(sw, target);
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(kb.x*0.8, 0.35, kb.z*0.8);
        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 5,0.2,0.2,0.2,0.1);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 0.9f, 1.0f);
        meleeCd = MELEE_CD;
    }

    private void equipTrident() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.TRIDENT))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.TRIDENT));
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    /** Проверяем мокрость без рекурсии */
    private boolean isWet(ServerLevel sw, LivingEntity e) {
        if (e.isUnderWater() || e.isInWater()) return true;
        if (!sw.isRaining()) return false;
        if (!sw.canSeeSky(e.blockPosition())) return false;
        return sw.getBiome(e.blockPosition()).value().hasPrecipitation();
    }

    public String getStateLabel() {
        if (riptideTick > 0) return "TRI:RIPTIDE";
        return "TRI:READY";
    }
}
