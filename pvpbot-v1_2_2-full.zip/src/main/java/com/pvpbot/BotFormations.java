package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * BotFormations v10 — построения ботов вокруг владельца.
 *
 * Поддерживаемые построения:
 *   LINE    — шеренга позади игрока
 *   FLANK   — боты по бокам (левый / правый)
 *   SURROUND — равномерно по кругу вокруг игрока
 *   FOLLOW  — стандартное следование (без особого построения)
 *
 * Построение задаётся командой /bot formation <type>.
 * При активации обновляет BotFollowOwnerGoal / BotPathfindGoal
 * через смещение целевой точки движения (offset-based approach).
 *
 * Интеграция:
 *   1. BotFormations.INSTANCE.applyOffsets(bots, player) вызывается
 *      в SpawnBotCommand (серверный тик) или в BotEntity.tick().
 *   2. BotFollowOwnerGoal и BotPathfindGoal должны вызывать
 *      BotFormations.INSTANCE.getTargetPos(bot, index, owner)
 *      вместо прямого owner.position() для расчёта пункта назначения.
 */
public class BotFormations {

    public static final BotFormations INSTANCE = new BotFormations();

    public enum Formation {
        FOLLOW,    // стандартное следование за владельцем
        LINE,      // шеренга позади
        FLANK,     // боты по бокам
        SURROUND,  // круговое окружение
        SQUAD      // управляется SquadManager (командир впереди, солдаты сзади)
    }

    private Formation current = Formation.FOLLOW;

    /** Радиус / отступ от игрока для построений (блоков) */
    private static final double OFFSET = 2.5;

    private BotFormations() {}

    public Formation getCurrent() { return current; }

    public void setCurrent(Formation f) { current = f; }

    /**
     * Возвращает целевую позицию для бота с данным индексом в списке.
     * Вызывается из BotFollowOwnerGoal.tick() и BotPathfindGoal.tick()
     * вместо owner.position().
     *
     * @param bot   бот
     * @param index порядковый номер бота среди ботов этого владельца (0-based)
     * @param total общее число ботов владельца
     * @param owner игрок-владелец
     * @return точка назначения в мире
     */
    public Vec3 getTargetPos(BotEntity bot, int index, int total, Player owner) {
        if (current == Formation.FOLLOW || total == 0) {
            return owner.position();
        }

        Vec3 ownerPos = owner.position();
        float yaw = owner.getYRot(); // градусы

        return switch (current) {
            case LINE     -> lineOffset(ownerPos, yaw, index, total);
            case FLANK    -> flankOffset(ownerPos, yaw, index, total);
            case SURROUND -> surroundOffset(ownerPos, index, total);
            case SQUAD    -> {
                // Делегируем SquadManager
                if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
                    SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(sp);
                    if (squad != null) yield SquadManager.INSTANCE.getSquadPos(bot, owner, squad);
                }
                yield lineOffset(ownerPos, yaw, index, total);
            }
            default -> {}
        };
    }

    // ── Построение: шеренга позади ──────────────────────────────

    private Vec3 lineOffset(Vec3 base, float yaw, int index, int total) {
        // Вектор "назад" от направления взгляда игрока
        double rad = Math.toRadians(yaw); // yaw: 0=юг, 90=запад
        double backX = Math.sin(rad);
        double backZ = -Math.cos(rad);

        // Боты выстраиваются в линию позади, с шагом OFFSET
        // Центрируем: индекс 0 — ближайший к игроку
        double dist = OFFSET * (index + 1);
        return base.add(backX * dist, 0, backZ * dist);
    }

    // ── Построение: по флангам ───────────────────────────────────

    private Vec3 flankOffset(Vec3 base, float yaw, int index, int total) {
        double rad = Math.toRadians(yaw);
        // Вектор вправо
        double rightX = Math.cos(rad);
        double rightZ = Math.sin(rad);

        // Чётные — левый фланг, нечётные — правый
        int side = (index % 2 == 0) ? -1 : 1;
        int rank = (index / 2) + 1;
        double dist = OFFSET * rank;

        // Также немного назад, чтобы не мешали
        double backX = Math.sin(rad);
        double backZ = -Math.cos(rad);

        return base.add(
            rightX * side * dist + backX * (OFFSET * 0.5),
            0,
            rightZ * side * dist + backZ * (OFFSET * 0.5)
        );
    }

    // ── Построение: окружение (круг) ─────────────────────────────

    private Vec3 surroundOffset(Vec3 base, int index, int total) {
        if (total == 0) return base;
        double angle = (2.0 * Math.PI / total) * index;
        double radius = OFFSET + (total > 4 ? (total - 4) * 0.5 : 0); // увеличиваем радиус при многих ботах
        double dx = Math.cos(angle) * radius;
        double dz = Math.sin(angle) * radius;
        return base.add(dx, 0, dz);
    }

    // ── Утилита: имя построения → enum ───────────────────────────

    public static Formation fromString(String s) {
        return switch (s.toLowerCase()) {
            case "line"    -> Formation.LINE;
            case "flank"   -> Formation.FLANK;
            case "surround"-> Formation.SURROUND;
            case "squad"   -> Formation.SQUAD;
            default        -> Formation.FOLLOW;
        };
    }
}
