package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;

/**
 * ModeLogicDispatcher — v14: добавлены BEEHIVE, FIREWORK, CROSSBOW.
 */
public class ModeLogicDispatcher {

    private final BotEntity bot;

    private SwordLogic   swordLogic;
    private AxeLogic     axeLogic;
    private UhcLogic     uhcLogic;
    private NethPotLogic nethPotLogic;
    private SmpLogic     smpLogic;
    private MaceLogic    maceLogic;
    private TpcLogic     tpcLogic;
    // v14
    private BeehiveLogic  beehiveLogic;
    private FireworkLogic fireworkLogic;
    private CrossbowLogic crossbowLogic;
    private MaceElytraLogic maceElytraLogic;
    private TridentLogic    tridentLogic;
    // v16
    private TotemLogic      totemLogic;
    private SnowballLogic   snowballLogic;
    private CrystalBotLogic crystalBotLogic;

    private PVPBotConfig.Mode lastMode = null;

    public ModeLogicDispatcher(BotEntity bot) {
        this.bot = bot;
    }

    public boolean tick(LivingEntity target) {
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;
        if (mode == null) return false;

        if (mode != lastMode) {
            onModeChanged(mode);
            lastMode = mode;
        }

        switch (mode) {
            case SWORD    -> getSword().tick(target);
            case AXE      -> getAxe().tick(target);
            case UHC      -> getUhc().tick(target);
            case NETHPOT  -> getNethPot().tick(target);
            case SMP      -> getSmp().tick(target);
            case MACE     -> getMace().tick(target);
            case TPC      -> getTpc().tick(target);
            case BEEHIVE  -> getBeehive().tick(target);
            case FIREWORK -> getFirework().tick(target);
            case CROSSBOW -> getCrossbow().tick(target);
            case MACE_ELYTRA -> getMaceElytra().tick(target);
            case TRIDENT     -> getTrident().tick(target);
            case TOTEM       -> getTotem().tick(target);
            case SNOWBALL    -> getSnowball().tick(target);
            case CRYSTAL  -> getCrystal().tick((net.minecraft.server.level.ServerLevel) bot.level(), target);
            default     -> null;
        }
        return true;
    }

    private SwordLogic   getSword()   { if (swordLogic   == null) swordLogic   = new SwordLogic(bot);   return swordLogic;   }
    private AxeLogic     getAxe()     { if (axeLogic     == null) axeLogic     = new AxeLogic(bot);     return axeLogic;     }
    private UhcLogic     getUhc()     { if (uhcLogic     == null) uhcLogic     = new UhcLogic(bot);     return uhcLogic;     }
    private NethPotLogic getNethPot() { if (nethPotLogic == null) nethPotLogic = new NethPotLogic(bot); return nethPotLogic; }
    private SmpLogic     getSmp()     { if (smpLogic     == null) smpLogic     = new SmpLogic(bot);     return smpLogic;     }
    private MaceLogic    getMace()    { if (maceLogic    == null) maceLogic    = new MaceLogic(bot);    return maceLogic;    }
    private TpcLogic     getTpc()     { if (tpcLogic     == null) tpcLogic     = new TpcLogic(bot);     return tpcLogic;     }
    private BeehiveLogic  getBeehive()  { if (beehiveLogic  == null) beehiveLogic  = new BeehiveLogic(bot);  return beehiveLogic;  }
    private FireworkLogic getFirework() { if (fireworkLogic == null) fireworkLogic = new FireworkLogic(bot); return fireworkLogic; }
    private CrossbowLogic getCrossbow() { if (crossbowLogic == null) crossbowLogic = new CrossbowLogic(bot); return crossbowLogic; }
    private MaceElytraLogic getMaceElytra() { if (maceElytraLogic == null) maceElytraLogic = new MaceElytraLogic(bot); return maceElytraLogic; }
    private TridentLogic    getTrident()    { if (tridentLogic    == null) tridentLogic    = new TridentLogic(bot);    return tridentLogic;    }
    private TotemLogic      getTotem()      { if (totemLogic      == null) totemLogic      = new TotemLogic(bot);      return totemLogic;      }
    private SnowballLogic   getSnowball()   { if (snowballLogic   == null) snowballLogic   = new SnowballLogic(bot);   return snowballLogic;   }
    private CrystalBotLogic getCrystal()    { if (crystalBotLogic == null) crystalBotLogic = new CrystalBotLogic(bot); return crystalBotLogic; }

    private void onModeChanged(PVPBotConfig.Mode newMode) {
        // Сбрасываем состояние предыдущего логик-объекта чтобы избежать утечки состояния
        // (например: старый chargeTimer лука не влиял бы на новый режим SWORD)
        if (swordLogic   != null) { swordLogic   = null; }
        if (axeLogic     != null) { axeLogic     = null; }
        if (uhcLogic     != null) { uhcLogic     = null; }
        if (nethPotLogic != null) { nethPotLogic = null; }
        if (smpLogic     != null) { smpLogic     = null; }
        if (maceLogic    != null) { maceLogic    = null; }
        if (tpcLogic     != null) { tpcLogic     = null; }
        if (beehiveLogic  != null) { beehiveLogic  = null; }
        if (fireworkLogic != null) { fireworkLogic = null; }
        if (crossbowLogic != null) { crossbowLogic = null; }
        if (maceElytraLogic != null) { maceElytraLogic = null; }
        if (tridentLogic    != null) { tridentLogic    = null; }
        if (totemLogic      != null) { totemLogic      = null; }
        if (snowballLogic   != null) { snowballLogic   = null; }
        if (crystalBotLogic != null) { crystalBotLogic = null; }
        // Новый экземпляр будет создан лениво при первом tick() в новом режиме
    }

    public String getStatusLabel() {
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;
        return switch (mode) {
            case SWORD    -> "SWORD";
            case AXE      -> "AXE";
            case UHC      -> "UHC";
            case NETHPOT  -> "NETHPOT";
            case SMP      -> "SMP";
            case MACE     -> maceLogic != null ? getMace().getStateLabel() : "MACE:INIT";
            case TPC      -> "TPC";
            case BEEHIVE  -> "BEEHIVE";
            case FIREWORK -> "FIREWORK";
            case CROSSBOW -> "CROSSBOW";
            case MACE_ELYTRA -> maceElytraLogic != null ? getMaceElytra().getStateLabel() : "ME:INIT";
            case TRIDENT     -> tridentLogic    != null ? getTrident().getStateLabel()    : "TRI:INIT";
            case TOTEM       -> totemLogic      != null ? getTotem().getStateLabel()      : "TOTEM:INIT";
            case SNOWBALL    -> snowballLogic   != null ? getSnowball().getStateLabel()   : "SNOW:INIT";
            case CRYSTAL  -> "CRYSTAL";
            default     -> "?";
        };
    }
}
