package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;

/**
 * BotDifficultyAI v3.0 — УМНЫЙ бот.
 *
 * КЛЮЧЕВЫЕ ИСПРАВЛЕНИЯ:
 *   - Перемещение ТОЛЬКО через Navigation (не setDeltaMovement для движения к цели)
 *   - Ограничение скорости через атрибут (не через deltaMovement)
 *   - Blink/Crystal: не телепортируем как читер — реальный projectile arc
 *   - EASY: действительно медленный (атрибут скорости 0.08)
 *   - MEDIUM: 1.0 (норма игрока)
 *   - HARD: 1.1
 *   - EXPERT: 1.15
 *   - Pearl: проверяем есть ли препятствия, не летим через стены
 *   - Crystal: реальная логика ObsidianPlacer + CrystalLogic
 *   - Bow: prediction-based, не instant-hit
 */
public class BotDifficultyAI {

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int pearlCd    = 0;
    private int bowCd      = 0;
    private int crystalCd  = 0;
    private int comboCd    = 0;
    private int easyMissT  = 0;
    private int medHumanT  = 0;
    private int medStrafeV = 0;
    private int adaptTick  = 0;
    private float lastTargetHp     = -1;
    private int   targetNoDmgTicks = 0;

    private Vec3 predictedPos = null;
    private int  predictCd    = 0;

    private final ComboSystem        comboSystem;
    private final WeaponSwitcher     weaponSwitcher;
    private final PotionPredict      potionPredict;
    private final MaceLogic          maceLogic;
    private final ModeLogicDispatcher modeDispatcher;
    private final CrystalBotLogic   crystalBotLogic;
    private final StrafeAI          strafe;
    private final ThreatAssessment  threatAssessment;
    private final PlayerlikeBlockPlacer blockPlacer;
    private int playerReactionDelay = 0;

    public BotDifficultyAI(BotEntity bot) {
        this.bot             = bot;
        this.comboSystem     = new ComboSystem(bot);
        this.weaponSwitcher  = new WeaponSwitcher(bot);
        this.maceLogic       = new MaceLogic(bot);
        this.modeDispatcher  = new ModeLogicDispatcher(bot);
        this.potionPredict   = new PotionPredict(bot);
        this.crystalBotLogic = new CrystalBotLogic(bot);
        this.strafe          = new StrafeAI(bot);
        this.threatAssessment = new ThreatAssessment(bot);
        this.blockPlacer      = new PlayerlikeBlockPlacer(bot);
        applySpeedAttribute();
    }

    /** Устанавливаем атрибут скорости по сложности */
    private void applySpeedAttribute() {
        double spd = switch (cfg.difficulty) {
            case EASY   -> 0.08;
            case MEDIUM -> 0.13;
            case HARD   -> 0.135;
            case EXPERT -> 0.14;
            case PLAYER -> 0.13; // точно как у живого игрока в спринте
        };
        var speedAttr = bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(spd);
    }

    public ThreatAssessment getThreatAssessment() { return threatAssessment; }

    public int getAttackCooldown() {
        return cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;

        if (pearlCd          > 0) pearlCd--;
        if (bowCd            > 0) bowCd--;
        if (crystalCd        > 0) crystalCd--;
        if (comboCd          > 0) comboCd--;
        if (easyMissT        > 0) easyMissT--;
        if (medHumanT        > 0) medHumanT--;
        if (predictCd        > 0) predictCd--;

        // ThreatAssessment теперь вызывается глобально из BotEntity.tick()
        // (оставляем target как есть)

        // PotionPredict
        if (target != null && target.isAlive()) {
            potionPredict.tick(target);
            if (potionPredict.isVulnerable() && bot.distanceTo(target) < 4.0) {
                bot.getNavigation().moveTo(target, 1.2);
                if (bot.level() instanceof ServerLevel sw)
                    bot.doHurtTarget(sw, target);
                potionPredict.onRushAttack();
            }
        }

        if (target == null || !target.isAlive()) {
            if (lastTargetHp > 0) { bot.getNotifier().onKill(null); lastTargetHp = -1; }
            return;
        }

        // Адаптивный трекинг урона
        adaptTick++;
        if (adaptTick % 10 == 0) {
            float hp = target.getHealth();
            if (lastTargetHp >= 0 && hp >= lastTargetHp) targetNoDmgTicks += 10;
            else targetNoDmgTicks = 0;
            lastTargetHp = hp;
        }

        // Режим MACE
        if (cfg.mode == PVPBotConfig.Mode.MACE) {
            maceLogic.tick(target);
            if (!maceLogic.isSmashing()) { comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM); comboSystem.tick(target); }
            return;
        }

        // Диспетчер режимов (crystal, smp, uhc, etc.)
        if (modeDispatcher.tick(target)) return;

        // AutoRetreat — если бот отступает, не атакуем
        if (bot.getAutoRetreat().isRetreating()) return;

        // По сложности
        switch (cfg.difficulty) {
            case EASY   -> tickEasy(target);
            case MEDIUM -> tickMedium(target);
            case HARD   -> tickHard(target);
            case EXPERT -> tickExpert(target);
            case PLAYER -> tickPlayer(target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EASY — тупой, медленный
    // ════════════════════════════════════════════════════════════════
    private void tickEasy(LivingEntity target) {
        if (easyMissT > 0) return; // "задумался"

        double dist = bot.distanceTo(target);

        // Медленное движение к цели через Navigation
        if (dist > 3.5) {
            bot.getNavigation().moveTo(target, 0.65);
        }

        // Атака с большим кулдауном + 30% промах
        if (dist <= 3.5 && bot.tickCount % cfg.attackCooldown == 0) {
            if (bot.level().getRandom().nextInt(100) < 30) {
                easyMissT = 10;
                return;
            }
            equipSword();
            if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
        }

        // Случайная "задумчивость"
        if (bot.tickCount % 60 == 0 && bot.level().getRandom().nextInt(100) < 20) {
            easyMissT = 15 + bot.level().getRandom().nextInt(20);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // MEDIUM — как обычный игрок
    // ════════════════════════════════════════════════════════════════
    private void tickMedium(LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Лук только если далеко
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0 && medHumanT <= 0) {
            equipBow();
            aimAndShoot(target);
            bowCd = cfg.diffBowCooldown + bot.level().getRandom().nextInt(6);
            medHumanT = 3 + bot.level().getRandom().nextInt(3);
        } else {
            equipSword();
        }

        // Движение — Navigation
        if (dist > 2.8) bot.getNavigation().moveTo(target, 1.0);

        // Страф — каждый тик, с адаптацией PatternAI если включён
        if (PVPBotConfig.INSTANCE.patternAIEnabled) {
            PatternAI pai = bot.getPatternAI();
            double adaptedYaw = pai.getAdaptedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            strafe.setAdaptedYaw((float) adaptedYaw);
        }
        strafe.tick(target);

        // Атака с человеческой вариацией кд (±3 тика)
        int humanCd = cfg.attackCooldown + bot.level().getRandom().nextInt(4) - 1;
        if (dist <= cfg.attackRange && bot.tickCount % Math.max(4, humanCd) == 0) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HARD — перлы, воздух-атака, кристаллы
    // ════════════════════════════════════════════════════════════════
    private void tickHard(LivingEntity target) {
        double dist = bot.distanceTo(target);

        weaponSwitcher.tick(target);
        comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM);
        comboSystem.tick(target);

        // Страф с PatternAI на HARD
        if (PVPBotConfig.INSTANCE.patternAIEnabled) {
            PatternAI pai = bot.getPatternAI();
            double adaptedYaw = pai.getAdaptedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            strafe.setAdaptedYaw((float) adaptedYaw);
        }
        strafe.tick(target);

        // Navigation
        if (dist > 2.5) bot.getNavigation().moveTo(target, 1.05);

        // Перл-рывок — к предсказанной позиции если PatternAI включён
        if (cfg.diffUsePearls && dist > cfg.diffPearlThrowDist && pearlCd <= 0) {
            if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                dashTowardPos(predicted);
            } else {
                dashTowardTarget(target);
            }
            pearlCd = cfg.diffPearlCooldown;
        }
        // Перл-отход при низком HP
        if (cfg.diffUsePearls && bot.getHealth() < cfg.diffPearlEscapeHpThreshold && pearlCd <= 0) {
            retreatFromTarget(target);
            pearlCd = cfg.diffPearlCooldown;
        }

        // Кристаллы
        if (cfg.diffUseCrystals && bot.level() instanceof ServerLevel sw)
            crystalBotLogic.tick(sw, target);

        // Удар когда цель в воздухе (крит-combo)
        boolean inAir = !target.isOnGround();
        if (inAir && dist < 4.5 && bot.tickCount % 3 == 0) {
            if (!bot.onGround()) {
                if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
            } else {
                bot.getJumpControl().jump();
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EXPERT — кристаллы, предсказание, комбо
    // ════════════════════════════════════════════════════════════════
    private void tickExpert(LivingEntity target) {
        double dist = bot.distanceTo(target);
        boolean inAir = !target.isOnGround();

        // Предсказание позиции каждые 3 тика
        if (predictCd <= 0) {
            predictedPos = MotionPredictor.predictForProjectile(bot, target, 1.6);
            predictCd = 3;
        }

        // Оружие
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0) {
            equipBow();
            Vec3 aim = predictedPos != null ? predictedPos : target.position();
            aimAndShootAt(aim);
            bowCd = cfg.diffBowCooldown;
        } else {
            equipSword();
        }

        // Navigation
        if (dist > 2.2) bot.getNavigation().moveTo(target, 1.1);

        // Страф агрессивный — с PatternAI на EXPERT
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
        if (PVPBotConfig.INSTANCE.patternAIEnabled) {
            PatternAI pai = bot.getPatternAI();
            double adaptedYaw = pai.getAdaptedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            strafe.setAdaptedYaw((float) adaptedYaw);
        }
        strafe.tick(target);

        // Кристаллы + обсидиан
        if (cfg.diffUseCrystals && bot.level() instanceof ServerLevel sw) {
            crystalBotLogic.tick(sw, target);
            if (inAir && crystalCd <= 0 && dist < cfg.diffCrystalPlaceRange) {
                crystalExplosion(sw, target, true);
                crystalCd = cfg.diffCrystalCooldown;
            } else if (!inAir && crystalCd <= 0 && dist < cfg.diffCrystalPlaceRange) {
                crystalExplosion(sw, target, false);
                crystalCd = cfg.diffCrystalCooldown;
            }
        }

        // Перлы
        if (cfg.diffUsePearls) {
            if (dist > cfg.diffPearlThrowDist && pearlCd <= 0) {
                if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                    Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                    dashTowardPos(predicted);
                } else {
                    dashTowardTarget(target);
                }
                pearlCd = cfg.diffPearlCooldown;
            }
            if (bot.getHealth() < cfg.diffPearlEscapeHpThreshold && pearlCd <= 0) {
                retreatFromTarget(target);
                pearlCd = cfg.diffPearlCooldown;
            }
            // Давление если цель не получает урон
            if (targetNoDmgTicks > 25 && dist > 3.0 && pearlCd <= 0) {
                if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                    Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                    dashTowardPos(predicted);
                } else {
                    dashTowardTarget(target);
                }
                pearlCd = cfg.diffPearlCooldown;
                targetNoDmgTicks = 0;
            }
        }

        // Комбо
        comboSystem.setPattern(ComboSystem.ComboPattern.BURST);
        comboSystem.tick(target);
        weaponSwitcher.tick(target);
    }

    // ── Перемещение к цели через Navigation (не телепорт) ────────
    private void dashTowardTarget(LivingEntity target) {
        dashTowardPos(target.position());
    }

    // ── Перемещение к конкретной позиции (для PatternAI-предсказания) ──
    private void dashTowardPos(Vec3 pos) {
        bot.getNavigation().moveTo(pos.x, pos.y, pos.z, 1.6);
        bot.setSprinting(true);
        if (bot.level() instanceof ServerLevel sw) {
            sw.sendParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY() + 0.5, bot.getZ(), 8, 0.2, 0.3, 0.2, 0.05);
        }
        bot.playSound(SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.2f);
    }

    // ── Отход от цели ─────────────────────────────────────────────
    private void retreatFromTarget(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 dest = bot.position().add(away.scale(cfg.diffPearlEscapeDist));
        bot.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.5);
        if (bot.level() instanceof ServerLevel sw) {
            sw.sendParticles(ParticleTypes.SMOKE,
                bot.getX(), bot.getY() + 0.5, bot.getZ(), 5, 0.1, 0.2, 0.1, 0.02);
        }
    }

    // ── Взрыв кристалла ───────────────────────────────────────────
    private void crystalExplosion(ServerLevel sw, LivingEntity target, boolean inAir) {
        float dmg = inAir ? cfg.diffCrystalDamage * 1.35f : cfg.diffCrystalDamage;
        target.hurt(sw.damageSources().explosion(bot, bot), dmg);
        Vec3 kb = target.position().subtract(bot.position()).normalize().scale(1.0);
        target.setDeltaMovement(target.getDeltaMovement().add(kb.x, 0.35, kb.z));
        sw.sendParticles(ParticleTypes.EXPLOSION,
            target.getX(), target.getY() + 0.5, target.getZ(), 1, 0, 0, 0, 0);
    }

    // ── Стрельба из лука с задержкой прицеливания ─────────────────
    private void aimAndShoot(LivingEntity target) {
        aimAndShootAt(MotionPredictor.predict(target, 4));
    }

    private void aimAndShootAt(Vec3 aimPos) {
        bot.getLookControl().setLookAt(aimPos.x, aimPos.y + 0.5, aimPos.z, 60f, 60f);
        if (!(bot.level() instanceof ServerLevel sw)) return;
        double dist = bot.position().distanceTo(aimPos);
        float dmg = (float) Math.max(1.0, 9.0 - dist * 0.22);
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(aimPos, aimPos).inflate(1.2),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.hurt(sw.damageSources().arrow(null, bot), dmg)
        );
    }

    // ════════════════════════════════════════════════════════════════
    // PLAYER — неотличим от живого игрока: ставит блоки, иногда мажет,
    //          нет телепортов/кристаллов/читерских перлов
    // ════════════════════════════════════════════════════════════════
    private void tickPlayer(LivingEntity target) {
        double dist = bot.distanceTo(target);
        var rng = bot.level().getRandom();

        // 1. Реакция с «человеческой» задержкой
        if (playerReactionDelay > 0) { playerReactionDelay--; return; }
        if (bot.tickCount % 20 == 0) {
            // Каждую секунду случайно добавляем 0–4 тика задержки
            playerReactionDelay = rng.nextInt(cfg.playerReactionJitter + 1);
        }

        // 2. Движение: Navigation с обычной скоростью спринта
        if (dist > 2.8) {
            bot.getNavigation().moveTo(target, 1.0);
            bot.setSprinting(true);
        } else {
            bot.setSprinting(false);
        }

        // 3. Страф — CIRCLE как у обычного игрока, без zigzag
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        if (cfg.patternAIEnabled) {
            double adaptedYaw = bot.getPatternAI()
                .getAdaptedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            strafe.setAdaptedYaw((float) adaptedYaw);
        }
        strafe.tick(target);

        // 4. Лук — только если цель ОЧЕНЬ далеко, и то медленно
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0) {
            equipBow();
            aimAndShoot(target);
            bowCd = cfg.diffBowCooldown + rng.nextInt(8); // человеческая вариация
        } else {
            equipSword();
        }

        // 5. Постройка блоков — как у игрока (мост, крыша, стена)
        boolean justBuilt = false;
        if (bot.tickCount % 4 == 0) {
            blockPlacer.equipBlockTemporarily();
            justBuilt = blockPlacer.tick(target);
            if (justBuilt) blockPlacer.reequipSword();
            else           blockPlacer.reequipSword();
        }

        // 6. Атака с человеческим кд (± jitter тиков)
        if (!justBuilt && dist <= cfg.attackRange) {
            int humanCd = cfg.attackCooldown + rng.nextInt(4) - 1;
            if (bot.tickCount % Math.max(4, humanCd) == 0) {
                // Иногда промахиваемся
                if (rng.nextInt(100) < cfg.playerMissChance) return;

                // Иногда делаем ложный замах перед атакой
                if (cfg.playerFakeSwing && rng.nextInt(100) < 20) {
                    bot.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                    return; // в следующий кд — реальный удар
                }

                bot.getLookControl().setLookAt(target, 30f, 30f);
                if (bot.level() instanceof net.minecraft.server.level.ServerLevel sw) {
                    bot.doHurtTarget(sw, target);
                }
            }
        }

        // 7. W-tap: короткий стоп перед ударом для knockback (как у игрока)
        if (cfg.wTapEnabled && dist < cfg.attackRange + 0.5) {
            boolean justHit = (bot.tickCount % Math.max(4, cfg.attackCooldown) == 0);
            if (justHit) {
                bot.setSprinting(false);
                // Через 2 тика снова спринт
            }
        }
    }

    private void equipSword() { bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD)); }
    private void equipBow()   { bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW)); }
}
