package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * BotLearning v1.0 — обучение бота на поведении реального игрока.
 *
 * Что записывает:
 *   - Паттерны движения (стрейф, zigzag, circle)
 *   - Тайминги атак (когда наносит удар, cooldown)
 *   - Использование гаплов (при каком HP)
 *   - Прыжки при атаке (крит)
 *   - Повторяющиеся последовательности (combo)
 *
 * Как использует PatternAI:
 *   - PatternAI.getLearnedPattern() → берёт топ-паттерн из BotLearning
 *   - Бот начинает повторять эти паттерны в бою
 *
 * Интеграция:
 *   1. BotLearning.INSTANCE.tick(player) — в серверном обработчике тиков
 *   2. PatternAI подписывается: BotLearning.INSTANCE.getTopPattern()
 *
 * Команды:
 *   /bot learn start  — начать запись
 *   /bot learn stop   — остановить
 *   /bot learn reset  — сбросить записанные паттерны
 *   /bot learn status — показать топ-паттерны
 */
public class BotLearning {

    public static final BotLearning INSTANCE = new BotLearning();

    /** Максимальная длина записываемой последовательности */
    private static final int MAX_SEQUENCE_LEN = 64;
    /** Количество топ-паттернов для хранения */
    private static final int TOP_PATTERNS = 8;
    /** Минимум повторений чтобы паттерн считался "выученным" */
    private static final int MIN_REPEAT = 3;

    // ── Типы действий ─────────────────────────────────────────────
    public enum Action {
        MOVE_LEFT,   // A
        MOVE_RIGHT,  // D
        MOVE_BACK,   // S
        MOVE_FORWARD,// W
        ATTACK,      // ЛКМ
        JUMP,        // пробел
        SPRINT,      // sprint
        USE_GAPPLE,  // ПКМ гапл
        STOP         // стоит
    }

    // ── Паттерн (последовательность действий) ────────────────────
    public static class Pattern {
        public final List<Action> actions;
        public int frequency = 1;
        public double avgHpOnGapple = 0;
        public int attackCritRatio = 0; // процент критов

        public Pattern(List<Action> actions) {
            this.actions = new ArrayList<>(actions);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pattern)) return false;
            return actions.equals(((Pattern) o).actions);
        }

        @Override
        public int hashCode() { return actions.hashCode(); }
    }

    // ── Состояние ─────────────────────────────────────────────────
    private boolean recording = false;
    private final List<Action> currentSequence = new ArrayList<>();
    private final Map<Pattern, Integer> patternFreq = new LinkedHashMap<>();
    private int tickCounter = 0;
    private static final int SAMPLE_INTERVAL = 2; // каждые 2 тика

    // Данные о предыдущем тике для определения действий
    private Vec3 lastPos = null;
    private float lastHp = 20.0f;
    private boolean lastOnGround = true;
    private int attackCooldownTracker = 0;

    private BotLearning() {}

    // ── API ───────────────────────────────────────────────────────

    public boolean isRecording() { return recording; }

    public void startRecording() {
        recording = true;
        currentSequence.clear();
        lastPos = null;
    }

    public void stopRecording() {
        recording = false;
        if (!currentSequence.isEmpty()) {
            savePattern(new ArrayList<>(currentSequence));
        }
        currentSequence.clear();
    }

    public void reset() {
        patternFreq.clear();
        currentSequence.clear();
        recording = false;
    }

    /**
     * Тик — записываем действия игрока.
     * Вызывать из ServerTickHandler или аналога.
     */
    public void tick(Player player) {
        if (!recording) return;

        tickCounter++;
        if (tickCounter % SAMPLE_INTERVAL != 0) return;

        Action action = sampleAction(player);
        if (action != null) {
            currentSequence.add(action);
            if (currentSequence.size() >= MAX_SEQUENCE_LEN) {
                // Сохраняем накопленный паттерн и начинаем новый
                savePattern(new ArrayList<>(currentSequence));
                currentSequence.clear();
            }
        }

        // Трекинг использования гапла
        float currentHp = player.getHealth();
        if (currentHp > lastHp + 4.0f) {
            // HP восстановился — использовал гапл/зелье
            recordGappleHp(lastHp);
        }
        lastHp = currentHp;
        lastPos = player.position();
    }

    /** Определить действие игрока в этом тике. */
    private Action sampleAction(Player player) {
        Vec3 pos = player.position();
        if (lastPos == null) { lastPos = pos; return null; }

        Vec3 delta = pos.subtract(lastPos);
        float yaw = player.getYRot();
        double rad = Math.toRadians(yaw);
        double fwdX = -Math.sin(rad), fwdZ = Math.cos(rad);
        double rtX = Math.cos(rad),  rtZ = Math.sin(rad);

        double fwdDot = delta.x * fwdX + delta.z * fwdZ;
        double rtDot  = delta.x * rtX  + delta.z * rtZ;

        // Определяем доминирующее движение
        if (Math.abs(fwdDot) < 0.01 && Math.abs(rtDot) < 0.01) return Action.STOP;
        if (!player.isOnGround() && lastOnGround)               return Action.JUMP;
        if (rtDot > 0.05)  return Action.MOVE_RIGHT;
        if (rtDot < -0.05) return Action.MOVE_LEFT;
        if (fwdDot < -0.05) return Action.MOVE_BACK;
        if (fwdDot > 0.05)  return Action.MOVE_FORWARD;

        lastOnGround = player.isOnGround();
        return null;
    }

    /** Записать паттерн в частотную таблицу. */
    private void savePattern(List<Action> seq) {
        // Разбиваем на подпоследовательности длиной 4–8
        for (int len = 4; len <= Math.min(8, seq.size()); len++) {
            for (int start = 0; start + len <= seq.size(); start++) {
                Pattern pat = new Pattern(seq.subList(start, start + len));
                patternFreq.merge(pat, 1, Integer::sum);
            }
        }
        prunePatterns();
    }

    /** Оставить только топ TOP_PATTERNS наиболее частых паттернов. */
    private void prunePatterns() {
        if (patternFreq.size() <= TOP_PATTERNS * 3) return;
        patternFreq.entrySet().stream()
            .sorted(Map.Entry.<Pattern, Integer>comparingByValue().reversed())
            .limit(TOP_PATTERNS * 2L)
            .forEach(e -> {}); // просто сортируем

        List<Map.Entry<Pattern, Integer>> sorted = new ArrayList<>(patternFreq.entrySet());
        sorted.sort(Map.Entry.<Pattern, Integer>comparingByValue().reversed());
        patternFreq.clear();
        sorted.stream().limit(TOP_PATTERNS * 2L).forEach(e -> patternFreq.put(e.getKey(), e.getValue()));
    }

    private void recordGappleHp(float hp) {
        // Сохраняем для GappleOptimizer
        GappleOptimizer.INSTANCE.recordGappleEvent(hp);
    }

    // ── PatternAI интерфейс ───────────────────────────────────────

    /**
     * Вернуть топ-паттерн для использования в PatternAI.
     * @return список действий или null если нечего повторять
     */
    public List<Action> getTopPattern() {
        return patternFreq.entrySet().stream()
            .filter(e -> e.getValue() >= MIN_REPEAT)
            .max(Map.Entry.comparingByValue())
            .map(e -> e.getKey().actions)
            .orElse(null);
    }

    /** Вернуть топ-N паттернов. */
    public List<Pattern> getTopPatterns(int n) {
        List<Pattern> result = new ArrayList<>();
        patternFreq.entrySet().stream()
            .filter(e -> e.getValue() >= MIN_REPEAT)
            .sorted(Map.Entry.<Pattern, Integer>comparingByValue().reversed())
            .limit(n)
            .forEach(e -> {
                Pattern p = e.getKey();
                p.frequency = e.getValue();
                result.add(p);
            });
        return result;
    }

    /** Форматировать статистику для чата. */
    public String formatStatus() {
        List<Pattern> top = getTopPatterns(5);
        if (top.isEmpty()) return "§7BotLearning: паттернов нет. §f/bot learn start";
        StringBuilder sb = new StringBuilder("§e§lBotLearning — Топ паттерны:\n");
        for (int i = 0; i < top.size(); i++) {
            Pattern p = top.get(i);
            sb.append("§f#").append(i + 1).append(" §7[×").append(p.frequency).append("] §f");
            for (Action a : p.actions) sb.append(actionShort(a));
            sb.append("\n");
        }
        sb.append("§7Всего паттернов: §f").append(patternFreq.size());
        return sb.toString();
    }

    private String actionShort(Action a) {
        return switch (a) {
            case MOVE_LEFT    -> "←";
            case MOVE_RIGHT   -> "→";
            case MOVE_BACK    -> "↓";
            case MOVE_FORWARD -> "↑";
            case ATTACK       -> "⚔";
            case JUMP         -> "↑↑";
            case SPRINT       -> "≫";
            case USE_GAPPLE   -> "🍎";
            case STOP         -> "•";
        };
    }

    public int getPatternCount() { return patternFreq.size(); }
}
