package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * TpcLogic v3.0 — умный TPC (Totem+Crystal+Axe).
 * ИСПРАВЛЕНО:
 *  - Retreat через navigation, не deltaMovement
 *  - Позиционирование через navigation
 *  - Страф через StrafeAI
 */
public class TpcLogic {

    private static final double BOW_RANGE    = 12.0;
    private static final double CRYSTAL_RANGE= 8.0;
    private static final double AXE_RANGE   = 4.0;
    private static final double IDEAL_DIST  = 2.8;
    private static final int    CRYSTAL_CD  = 15;
    private static final int    AXE_CD      = 18;
    private static final int    BOW_CD      = 22;
    private static final int    BURST_CD    = 8;
    private static final int    BURST_COUNT = 3;
    private static final int    RETREAT_CD  = 80;
    private static final int    CRIT_EVERY  = 3;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int crystalCd  = 0, axeCd = 0, bowCd = 0;
    private int burstCd = 0, burstHits = 0, retreatCd = 0, shieldDis = 0;
    private int hitCount = 0;
    private boolean inBurst = false, retreating = false, critPending = false;

    public TpcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { retreating = false; return; }

        if (crystalCd  > 0) crystalCd--;
        if (axeCd      > 0) axeCd--;
        if (bowCd      > 0) bowCd--;
        if (burstCd    > 0) burstCd--;
        if (retreatCd  > 0) retreatCd--;
        if (shieldDis  > 0) shieldDis--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        ensureTotem();

        // Retreat при критическом HP
        if (myHp < 4.0f && retreatCd <= 0) {
            retreating = true; retreatCd = RETREAT_CD;
        }

        if (retreating) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(bot.getX()+away.x*8, bot.getY(), bot.getZ()+away.z*8, 1.3);
            bot.setSprinting(true);
            if (myHp > 10.0f || retreatCd <= 0) retreating = false;
            return;
        }

        // Лук — далеко
        if (dist > BOW_RANGE) {
            equipBow();
            bot.getNavigation().moveTo(target, 1.1);
            if (bowCd <= 0) {
                bot.getLookControl().setLookAt(target, 60f, 60f);
                Vec3 aim = MotionPredictor.predict(target, (int)(dist/3));
                float dmg = (float) Math.max(3.0, Math.min(9.0, 10.0-dist*0.35));
                sw.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(aim,aim).inflate(1.3), e -> e != bot && e.isAlive())
                    .stream().findFirst().ifPresent(e -> e.hurt(sw.damageSources().arrow(null, bot), dmg));
                bowCd = BOW_CD;
            }
            return;
        }

        // Страф
        if (dist < AXE_RANGE + 2.0) strafe.tick(target);

        // Кристалл — средняя дистанция
        if (dist > AXE_RANGE && dist <= CRYSTAL_RANGE && crystalCd <= 0) {
            float dmg = 14.0f;
            target.hurt(sw.damageSources().explosion(bot, bot), dmg);
            Vec3 kb = target.position().subtract(bot.position()).normalize();
            target.setDeltaMovement(kb.x, 0.9, kb.z);
            sw.sendParticles(ParticleTypes.EXPLOSION_EMITTER, target.getX(), target.getY(), target.getZ(), 1,0,0,0,0);
            bot.playSound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE.value(), 0.8f, 1.0f);
            crystalCd = CRYSTAL_CD;
        }

        // Топор — ближний бой
        if (dist <= AXE_RANGE) {
            equipAxe();
            // navigation к идеальной дистанции
            if (dist > IDEAL_DIST + 0.5) bot.getNavigation().moveTo(target, 1.05);
            else if (dist < IDEAL_DIST - 0.4) bot.getNavigation().stop();

            bot.getLookControl().setLookAt(target, 30f, 30f);

            boolean blocking = isBlocking(target);
            if (blocking && axeCd <= 0) {
                doAxeHit(sw, target, 9.0f); shieldDis = 100; inBurst = true; burstHits = 0;
            } else if (shieldDis > 0 && inBurst && burstCd <= 0) {
                if (burstHits < BURST_COUNT) {
                    doAxeHit(sw, target, 8.0f); burstCd = BURST_CD; burstHits++;
                } else { inBurst = false; burstHits = 0; axeCd = AXE_CD; }
            } else if (!blocking && axeCd <= 0) {
                // Крит
                boolean doCrit = (hitCount % CRIT_EVERY == 0);
                if (doCrit && bot.onGround() && !critPending) {
                    bot.getJumpControl().jump(); critPending = true; axeCd = 1;
                } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                    doAxeHit(sw, target, 10.0f); critPending = false;
                } else { doAxeHit(sw, target, 9.0f); critPending = false; }
            }
        }
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, float dmg) {
        bot.doHurtTarget(sw, target);
        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 5,0.3,0.3,0.3,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
        hitCount++;
        axeCd = AXE_CD;
    }

    private boolean isBlocking(LivingEntity t) {
        if (shieldDis > 0) return false;
        return (t.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD) ||
                t.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD)) && t.isBlocking();
    }

    private void ensureTotem() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_AXE));
    }

    private void equipBow() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }
}
