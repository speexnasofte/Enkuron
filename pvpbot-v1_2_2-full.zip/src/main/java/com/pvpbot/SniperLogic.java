package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * SniperLogic — поведение роли SNIPER.
 *
 * Снайпер:
 *  - Держится на дистанции IDEAL_DIST (16-24 блока) от боя
 *  - Стреляет из лука/арбалета каждые BOW_COOLDOWN тиков
 *  - Не лезет в ближний бой (убегает если цель ближе MIN_DIST)
 *  - При потере цели — возвращается на позицию за основным отрядом
 *
 * Вызывается из BotEntity.tick() если bot.getSquadRole() == SNIPER.
 */
public class SniperLogic {

    public static final SniperLogic INSTANCE = new SniperLogic();

    private static final double IDEAL_DIST = 20.0;  // идеальная дистанция
    private static final double MIN_DIST   = 8.0;   // минимальная — ближе → убегать
    private static final double MAX_DIST   = 32.0;  // дальше — двигаться ближе
    private static final int    BOW_CD     = 25;    // тиков между выстрелами

    private SniperLogic() {}

    /**
     * Тик снайпера.
     * @param bot    снайпер
     * @param target текущая цель снайпера (может быть null)
     */
    public void tick(BotEntity bot, LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel level)) return;
        if (target == null || !target.isAlive()) {
            // Нет цели — держаться за отрядом
            retreatBehindSquad(bot);
            return;
        }

        double dist = bot.distanceTo(target);

        // Слишком близко → отступить
        if (dist < MIN_DIST) {
            retreatFromTarget(bot, target);
            return;
        }

        // Слишком далеко → подойти
        if (dist > MAX_DIST) {
            approachTarget(bot, target);
            return;
        }

        // Идеальная позиция → стрелять
        if (dist >= MIN_DIST && dist <= MAX_DIST) {
            if (bot.bowCooldown > 0) {
                bot.bowCooldown--;
            } else {
                shootAt(bot, target, level);
                bot.bowCooldown = BOW_CD;
            }
        }
    }

    // ── Стрельба ─────────────────────────────────────────────────

    private void shootAt(BotEntity bot, LivingEntity target, ServerLevel level) {
        Vec3 from = bot.getEyePosition();
        Vec3 to   = target.getEyePosition();
        Vec3 dir  = to.subtract(from).normalize();

        Arrow arrow = new Arrow(level, bot, new net.minecraft.world.item.ItemStack(Items.ARROW), null);
        arrow.setPos(from.x, from.y, from.z);
        arrow.shoot(dir.x, dir.y + getArcCompensation(bot.distanceTo(target)), dir.z, 3.0f, 0.5f);
        arrow.setCritArrow(true); // снайперы бьют критами
        level.addFreshEntity(arrow);
    }

    /** Поправка траектории для дальних выстрелов (компенсация гравитации). */
    private double getArcCompensation(double dist) {
        // ~0.005 компенсации на каждый блок дальности
        return dist * 0.007;
    }

    // ── Движение ─────────────────────────────────────────────────

    private void retreatFromTarget(BotEntity bot, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(IDEAL_DIST);
        Vec3 goal = target.position().add(away);
        bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.1);
    }

    private void approachTarget(BotEntity bot, LivingEntity target) {
        // Вектор ОТ цели К боту, нормализован, масштабирован до IDEAL_DIST
        // → цель + этот вектор = точка на IDEAL_DIST блоков ОТ цели в сторону бота
        Vec3 dir = bot.position().subtract(target.position()).normalize().scale(IDEAL_DIST);
        Vec3 goal = target.position().add(dir);
        bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.1); // FIX: ускорили до 1.1 (было 0.9 — снайпер никогда не догонял)
    }

    private void retreatBehindSquad(BotEntity bot) {
        // Встать позади командира / центра отряда
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquadOf(bot);
        if (squad != null && squad.commander != null && squad.commander != bot) {
            Vec3 cmdPos  = squad.commander.position();
            Vec3 backDir = squad.commander.getLookAngle().scale(-1).normalize();
            Vec3 goal    = cmdPos.add(backDir.scale(6.0));
            bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 0.9);
        } else {
            bot.getNavigation().stop();
        }
    }
}
