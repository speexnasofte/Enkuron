package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

/**
 * BotKiteLogic — серверный кайтинг для NPC-бота.
 *
 * В отличие от клиентского KiteLogic (работает на игроке через KeyPress),
 * этот класс управляет velocity бота напрямую на сервере.
 *
 * ┌────────────┬──────────────────────────────────────────────────────┐
 * │ FLEE       │ dist < kiteMinDist → отбегаем, стреляем из лука      │
 * │ IDEAL      │ kiteMin..kiteMax   → стрейф + стрельба               │
 * │ CHASE      │ dist > kiteMax     → приближаемся к дистанции стрельбы│
 * └────────────┴──────────────────────────────────────────────────────┘
 *
 * v13: Улучшения:
 *   - Wall-avoidance: бот проверяет блоки и меняет направление
 *   - Predictive strafing: стрейф с учётом движения цели
 *   - HP-адаптация: при низком HP агрессивнее убегает
 *   - Симуляция выстрела из лука с предсказанием позиции
 */
public class BotKiteLogic {

    // ── Конфиг дистанций ─────────────────────────────────────────
    private static final double KITE_MIN_DIST  = 5.0;   // ближе → убегаем
    private static final double KITE_MAX_DIST  = 14.0;  // дальше → приближаемся
    private static final double IDEAL_DIST     = 9.0;   // идеал — центр зоны стрельбы

    // ── Скорости ─────────────────────────────────────────────────
    private static final double FLEE_SPEED     = 0.28;
    private static final double STRAFE_SPEED   = 0.18;
    private static final double CHASE_SPEED    = 0.22;

    // ── Кулдауны ─────────────────────────────────────────────────
    private static final int BOW_COOLDOWN_TICKS   = 25;  // тиков между выстрелами
    private static final int STRAFE_FLIP_MIN      = 12;  // мин тиков до смены стрейфа
    private static final int STRAFE_FLIP_MAX      = 25;

    // ── Состояние ────────────────────────────────────────────────
    private enum KiteState { FLEE, IDEAL, CHASE }
    private KiteState state       = KiteState.IDEAL;

    private int bowCooldown       = 0;
    private int strafeTimer       = 0;
    private int strafeDir         = 1;    // +1 = влево, -1 = вправо
    private int wallAvoidDir      = 0;    // временное направление обхода стены
    private int wallAvoidTicks    = 0;

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public BotKiteLogic(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Главный тик — вызывать каждый тик пока бот в KITE-режиме.
     */
    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (target == null || !target.isAlive()) return;

        if (bowCooldown  > 0) bowCooldown--;
        if (strafeTimer  > 0) strafeTimer--;
        if (wallAvoidTicks > 0) wallAvoidTicks--;

        double dist = bot.distanceTo(target);
        updateState(dist);

        // Экипируем лук
        equipBow();

        switch (state) {
            case FLEE  -> doFlee(target);
            case IDEAL -> doIdeal(target);
            case CHASE -> doChase(target);
        }

        // Стрельба в любом состоянии (если есть кулдаун)
        if (bowCooldown <= 0) {
            shootBow(target);
        }
    }

    // ── Обновление состояния ─────────────────────────────────────
    private void updateState(double dist) {
        // При низком HP — расширяем зону flee (убегаем дальше)
        double fleeBonus = (bot.getHealth() < 8.0f) ? 2.0 : 0.0;
        double minDist   = KITE_MIN_DIST + fleeBonus;

        if      (dist < minDist)         state = KiteState.FLEE;
        else if (dist > KITE_MAX_DIST)   state = KiteState.CHASE;
        else                             state = KiteState.IDEAL;
    }

    // ── FLEE: убегаем от цели ────────────────────────────────────
    private void doFlee(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();

        // Wall-avoidance: если впереди блок — отклоняемся
        if (wallAvoidTicks <= 0) {
            Vec3 checkPos = bot.position().add(away.scale(1.2));
            if (isBlocked(checkPos)) {
                // Пробуем +90° или -90°
                wallAvoidDir   = (bot.level().getRandom().nextBoolean()) ? 1 : -1;
                wallAvoidTicks = 15;
            }
        }

        Vec3 moveDir = away;
        if (wallAvoidTicks > 0) {
            // Поворот на 45° для обхода стены
            double angle = wallAvoidDir * Math.PI / 4.0;
            moveDir = rotateY(away, angle);
        }

        applyVelocityXZ(moveDir, FLEE_SPEED);
    }

    // ── IDEAL: стрейф на хорошей дистанции ───────────────────────
    private void doIdeal(LivingEntity target) {
        // Меняем направление стрейфа через случайный интервал
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = STRAFE_FLIP_MIN + bot.level().getRandom()
                .nextInt(STRAFE_FLIP_MAX - STRAFE_FLIP_MIN);
        }

        // Вектор "к цели"
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        // Перпендикуляр — направление стрейфа
        Vec3 strafe = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);

        // v13: предсказываем движение цели и стрейфуем в противоположную сторону
        Vec3 targetVel = target.getDeltaMovement();
        if (targetVel.horizontalDistanceSqr() > 0.01) {
            // Цель движется — контрстрейф
            Vec3 counterStrafe = new Vec3(-targetVel.z, 0, targetVel.x).normalize();
            strafe = strafe.add(counterStrafe.scale(0.4)).normalize();
        }

        applyVelocityXZ(strafe, STRAFE_SPEED);
    }

    // ── CHASE: приближаемся к идеальной дистанции ────────────────
    private void doChase(LivingEntity target) {
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        applyVelocityXZ(dir, CHASE_SPEED);
    }

    // ── Выстрел из лука ──────────────────────────────────────────
    private void shootBow(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        double dist = bot.distanceTo(target);

        // v13: предсказываем позицию цели для точного выстрела
        Vec3 aimPos = MotionPredictor.predict(target, (int)(dist / 3));

        // Урон: 3–9 в зависимости от дистанции (как ванильный лук)
        float damage = (float) Math.max(3.0, Math.min(9.0, 10.0 - dist * 0.35));

        // Наносим урон ближайшей сущности к прицельной точке
        sw.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(aimPos, aimPos).inflate(1.2),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.hurt(sw.damageSources().arrow(null, bot), damage)
        );

        // Эффект стрелы
        sw.sendParticles(ParticleTypes.CRIT,
            aimPos.x, aimPos.y + 1, aimPos.z,
            4, 0.2, 0.2, 0.2, 0.1
        );

        bowCooldown = BOW_COOLDOWN_TICKS;
    }

    // ── Вспомогательные ──────────────────────────────────────────

    private void applyVelocityXZ(Vec3 dir, double speed) {
        Vec3 cur = bot.getDeltaMovement();
        bot.setDeltaMovement(
            cur.x * 0.6 + dir.x * speed,
            cur.y,
            cur.z * 0.6 + dir.z * speed
        );
    }

    private void equipBow() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.BOW)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        }
    }

    /** Проверяет, есть ли твёрдый блок в позиции (для wall-avoidance). */
    private boolean isBlocked(Vec3 pos) {
        // Проверяем ноги И голову — не пролезаем в 1-блочные щели
        net.minecraft.core.BlockPos foot = new net.minecraft.core.BlockPos(
            (int) Math.floor(pos.x),
            (int) Math.floor(bot.getY() + 0.1),
            (int) Math.floor(pos.z)
        );
        net.minecraft.core.BlockPos head = foot.above();
        boolean footBlocked = !bot.level().getBlockState(foot).isAir()
                           && bot.level().getBlockState(foot).isSolid();
        boolean headBlocked = !bot.level().getBlockState(head).isAir()
                           && bot.level().getBlockState(head).isSolid();
        return footBlocked || headBlocked;
    }

    /** Поворот вектора вокруг оси Y на угол angle (радианы). */
    private Vec3 rotateY(Vec3 v, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        return new Vec3(
            v.x * cos - v.z * sin,
            v.y,
            v.x * sin + v.z * cos
        );
    }

    public KiteState getState() { return state; }
}
