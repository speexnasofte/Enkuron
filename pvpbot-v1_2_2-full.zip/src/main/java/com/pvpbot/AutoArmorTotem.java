package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.equipment.Equippable;

/**
 * AutoArmor  — автоматически экипирует лучшую броню из инвентаря.
 * AutoTotem  — держит тотем бессмертия в левой (offhand) руке.
 *
 * ✅ FIX: API зачарований исправлен для 1.21 (DataComponentTypes.ENCHANTMENTS).
 */
public class AutoArmorTotem {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int checkTimer = 0;

    public void tick(Minecraft mc) {
        if (mc.player == null) return;
        checkTimer--;
        if (checkTimer > 0) return;
        checkTimer = 20;

        if (cfg.autoTotem) equipTotem(mc.player);
        if (cfg.autoArmor) equipBestArmor(mc.player);
    }

    // ── Авто-тотем ──────────────────────────────────────────────
    private void equipTotem(Player player) {
        ItemStack offhand = player.getOffhandItem();
        if (offhand.is(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(Items.TOTEM_OF_UNDYING)) {
                player.getInventory().offhand.set(0, stack.copy());
                player.getInventory().removeItem(i, 1);
                return;
            }
        }
    }

    // ── Авто-броня ──────────────────────────────────────────────
    private void equipBestArmor(Player player) {
        tryEquipSlot(player, EquipmentSlot.HEAD);
        tryEquipSlot(player, EquipmentSlot.CHEST);
        tryEquipSlot(player, EquipmentSlot.LEGS);
        tryEquipSlot(player, EquipmentSlot.FEET);
    }

    private void tryEquipSlot(Player player, EquipmentSlot slot) {
        ItemStack current = player.getItemBySlot(slot);
        int currentProt = armorProtection(current);

        int bestSlot = -1;
        int bestProt = currentProt;

        for (int i = 0; i < player.getInventory().items.size(); i++) {
            ItemStack stack = player.getInventory().items.get(i);
            var equip = stack.get(net.minecraft.core.component.DataComponents.EQUIPPABLE);
            if (equip != null && equip.slot() == slot) {
                int prot = armorProtection(stack);
                if (prot > bestProt) {
                    bestProt = prot;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != -1) {
            ItemStack best = player.getInventory().items.get(bestSlot).copy();
            player.getInventory().items.set(bestSlot, current.isEmpty() ? ItemStack.EMPTY : current.copy());
            player.setItemSlot(slot, best);
        }
    }

    /**
     * ✅ FIX: Используем DataComponentTypes.ENCHANTMENTS (правильный API для 1.21).
     * Старый код stack.getEnchantments().getEnchantments().stream() не компилируется.
     */
    private int armorProtection(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        var eq = stack.get(net.minecraft.core.component.DataComponents.EQUIPPABLE);
        if (eq == null) return 0;
        int base = 0; // protection via attributes

        // Компонент зачарований (новый API компонентов 1.20.5+)
        var enchComp = stack.get(net.minecraft.core.component.DataComponents.ENCHANTMENTS);
        if (enchComp == null) return base;

        int enchBonus = 0;
        for (var enchEntry : enchComp.entrySet()) {
            // Protection даёт +4 за уровень к нашей оценке
            String enchId = enchEntry.getKey().unwrapKey().map(k -> k.location().toString()).orElse("");
            if (enchId.contains("protection")) {
                enchBonus += enchEntry.getIntValue() * 4;
            }
        }
        return base + enchBonus;
    }
}
