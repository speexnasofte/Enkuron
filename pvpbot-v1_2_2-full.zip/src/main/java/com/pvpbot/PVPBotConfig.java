package com.pvpbot;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * PVPBotConfig — v14: 1.21.4 + новые режимы и настройки.
 */
public class PVPBotConfig {

    public boolean enabled = false;

    public enum Mode { SWORD, CRYSTAL, SMP, UHC, NETHPOT, AXE, TPC, MACE, BEEHIVE, FIREWORK, CROSSBOW, MACE_ELYTRA, TRIDENT, TOTEM, SNOWBALL }
    public Mode mode = Mode.SWORD;

    public enum Difficulty { EASY, MEDIUM, HARD, EXPERT, PLAYER }
    public Difficulty difficulty = Difficulty.MEDIUM;

    // Атака
    public boolean autoAttack     = true;
    public double  attackRange    = 3.5;
    public int     attackCooldown = 10;

    // Уклонение
    public boolean autoDodge  = true;
    public double  dodgeRange = 2.5;

    // Лечение
    public boolean autoHeal      = true;
    public float   healThreshold = 8.0f;

    // AutoEat
    public boolean autoEat      = true;
    public int     eatThreshold = 16;

    // AutoGap
    public boolean autoGapEnabled     = true;
    public float   autoGapHpThreshold = 10.0f;

    // W-Tap / S-Tap
    public boolean wTapEnabled      = true;
    public int     wTapReleaseTicks = 2;
    public boolean sTapEnabled      = false;

    // AutoSprint
    public boolean autoSprint = true;

    // Авто-броня / тотем / респавн
    public boolean autoArmor   = true;
    public boolean autoTotem   = true;
    public boolean autoRespawn = true;

    // Кристаллы
    public boolean autoCrystal      = true;
    public double  crystalPlaceRange = 5.0;
    public int     crystalCooldown  = 4;

    // HUD
    public boolean showHud = true;
    public boolean showDps = true;

    // Whitelist
    public boolean      whitelistEnabled = false;
    public List<String> whitelist        = new ArrayList<>();

    // Несколько ботов
    public int maxBots = 5;

    // Лечение NPC-бота
    public float  botHealThreshold = 12.0f;
    public float  botMaxHealth     = 40.0f;  // 20 = как игрок, 40 = двойное HP
    public String botHealItem      = "minecraft:golden_apple";

    // GUI
    public enum GuiTab { SETTINGS, INVENTORY, MODULES }
    public GuiTab activeTab = GuiTab.SETTINGS;

    // Визуал
    public boolean espEnabled   = true;
    public double  espRange     = 48.0;
    public float   espLineWidth = 1.5f;

    public boolean radarEnabled = true;
    public int     radarRadius  = 50;
    public double  radarRange   = 64.0;

    // Статистика
    public boolean statsEnabled = true;

    // AutoBow
    public boolean autoBowEnabled = false;
    public double  bowRange       = 24.0;
    public int     bowCooldown    = 25;

    // Кайтинг
    public boolean kiteEnabled = false;
    public double  kiteMinDist = 6.0;
    public double  kiteMaxDist = 18.0;

    // Pathfinding
    public boolean advPathfind = true;

    // BotDifficultyAI
    public boolean diffUsePearls              = true;
    public double  diffPearlThrowDist         = 12.0;
    public int     diffPearlCooldown          = 160;
    public float   diffPearlEscapeHpThreshold = 8.0f;
    public double  diffPearlEscapeDist        = 16.0;
    public double  diffBowSwitchRange         = 10.0;
    public int     diffBowCooldown            = 30;
    public boolean diffUseCrystals            = true;
    public double  diffCrystalPlaceRange      = 6.0;
    public int     diffCrystalCooldown        = 40;
    public float   diffCrystalDamage          = 14.0f;
    public int     diffComboLength            = 3;
    public int     diffComboPauseTicks        = 12;
    public int     diffPredictTicks           = 4;

    // v11
    public boolean autoLogEnabled     = false;
    public float   autoLogHpThreshold = 6.0f;
    public boolean autoPearlEnabled   = false;
    public boolean tracersEnabled     = false;

    // v14 — PatternAI
    public boolean patternAIEnabled     = true;
    // ThreatAssessment — глобальная оценка угрозы
    public boolean threatAssessEnabled  = true;
    public boolean antiPatternEnabled   = true;

    // v14 — TrainingMode
    public boolean trainingMode = false;

    // v14 — Авто-кит по броне врага
    public boolean autoKitSelect = false;

    // v14 — KitStats
    public boolean kitStatsEnabled = true;

    // v14 — Уведомления в чат
    public boolean notificationsEnabled = true;

    // Скорость движения по сложности (применяется к атрибуту MOVEMENT_SPEED)
    public double diffMoveSpeed = 0.13;

    // ─────────────────────────────────────────────────────────────
    // PLAYER difficulty — параметры "человекоподобного" поведения
    // ─────────────────────────────────────────────────────────────
    /** Шанс (0-100%) поставить блок под ногами при движении/стрейфе */
    public int playerBridgeChance       = 30;
    /** Шанс (0-100%) накрыться блоком сверху (1x1 крыша) */
    public int playerRoofChance         = 15;
    /** Кулдаун между попытками ставить блоки (тики) */
    public int playerBlockPlaceCooldown = 16;
    /** Случайная добавка к реакции «как у человека» (тики) */
    public int playerReactionJitter     = 4;
    /** Иногда делать ложный замах перед ударом */
    public boolean playerFakeSwing      = true;
    /** Шанс промаха (%) — имитирует промахи живого игрока */
    public int playerMissChance         = 8;

    public void applyDifficulty() {
        switch (difficulty) {
            case EASY -> {
                // EASY: медленный, часто промахивается, не использует ничего умного
                attackCooldown     = 24;  attackRange = 2.8;
                dodgeRange         = 0.5; crystalCooldown = 99;
                diffUsePearls      = false;
                diffUseCrystals    = false;
                diffBowSwitchRange = 9999; // не стреляет из лука
                diffMoveSpeed      = 0.08; // заметно медленнее игрока
                wTapEnabled        = false;
                autoDodge          = false;
            }
            case MEDIUM -> {
                // MEDIUM: неотличим от среднего реального игрока
                attackCooldown     = 13;  attackRange = 3.5;
                dodgeRange         = 2.0; crystalCooldown = 5;
                diffUsePearls      = false;
                diffUseCrystals    = false;
                diffBowSwitchRange = 12.0; // лук только очень далеко
                diffBowCooldown    = 35;   // медленный выстрел
                diffMoveSpeed      = 0.13; // ровно как игрок в спринте
                wTapEnabled        = true;
                autoDodge          = true;
            }
            case HARD -> {
                // HARD: перлы, удар когда цель в воздухе, начало кристаллов
                attackCooldown              = 7;   attackRange = 4.0;
                dodgeRange                  = 3.5; crystalCooldown = 4;
                diffUsePearls               = true;
                diffUseCrystals             = true;  // кристаллы + обсидиан
                diffPearlThrowDist          = 12.0;
                diffPearlCooldown           = 140;
                diffBowSwitchRange          = 8.0;
                diffBowCooldown             = 22;
                diffPearlEscapeHpThreshold  = 10.0f;
                diffCrystalCooldown         = 8;
                diffCrystalDamage           = 12.0f;
                diffMoveSpeed               = 0.135;
                wTapEnabled                 = true;
                autoDodge                   = true;
            }
            case PLAYER -> {
                // PLAYER: бот неотличим от живого игрока
                // Никаких читерских телепортов, кристаллов, перлов
                // Ставит блоки, делает w-tap, иногда промахивается
                attackCooldown              = 10 + (int)(Math.random() * 3); // 10-12 тиков (как игрок)
                attackRange                 = 3.5;
                dodgeRange                  = 2.0;
                crystalCooldown             = 99;
                diffUsePearls               = false;
                diffUseCrystals             = false;
                diffBowSwitchRange          = 13.0;
                diffBowCooldown             = 30 + (int)(Math.random() * 8);
                diffMoveSpeed               = 0.13;  // точно как у игрока в спринте
                wTapEnabled                 = true;
                autoDodge                   = true;
                playerBridgeChance          = 30;
                playerRoofChance            = 15;
                playerBlockPlaceCooldown    = 16;
                playerReactionJitter        = 4;
                playerFakeSwing             = true;
                playerMissChance            = 8;
            }
            case EXPERT -> {
                // EXPERT: кристаллы+обсидиан, взрыв в воздухе, предсказание, комбо
                attackCooldown              = 4;   attackRange = 4.5;
                dodgeRange                  = 4.0; crystalCooldown = 2;
                diffUsePearls               = true;
                diffUseCrystals             = true;
                diffPearlThrowDist          = 10.0;
                diffPearlCooldown           = 100;
                diffPearlEscapeHpThreshold  = 14.0f;
                diffBowSwitchRange          = 6.0;
                diffBowCooldown             = 15;
                diffCrystalCooldown         = 4;
                diffCrystalDamage           = 16.0f;
                diffComboLength             = 4;
                diffComboPauseTicks         = 8;
                diffPredictTicks            = 5;
                diffMoveSpeed               = 0.14;
                wTapEnabled                 = true;
                autoDodge                   = true;
            }
            default     -> null;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // v15 — Multi-Owner
    // ─────────────────────────────────────────────────────────────
    /** UUID текущего «главного» владельца (заполняется при первом /bot spawn) */
    public UUID   globalOwnerUUID    = null;
    /** Ник из WebConfig для отложенного добавления совладельца */
    public String pendingCoOwnerAdd  = null;

    // ─────────────────────────────────────────────────────────────
    // v15 — WebConfig
    // ─────────────────────────────────────────────────────────────
    public boolean webConfigEnabled = false;
    public int     webConfigPort    = 7420;

    // ─────────────────────────────────────────────────────────────
    // v15 — BotBunker
    // ─────────────────────────────────────────────────────────────
    public boolean bunkerEnabled      = false;
    public float   bunkerHpThreshold  = 8.0f;

    // ─────────────────────────────────────────────────────────────
    // v16 — FakeAttack
    // ─────────────────────────────────────────────────────────────
    public boolean fakeAttackEnabled  = false;

    // ─────────────────────────────────────────────────────────────
    // v16 — BotHunt
    // ─────────────────────────────────────────────────────────────
    public boolean huntEnabled  = false;
    public double  huntRange    = 128.0;

    // ─────────────────────────────────────────────────────────────
    // v16 — AdaptiveCooldown
    // ─────────────────────────────────────────────────────────────
    public boolean adaptiveCooldownEnabled = true;

    // ─────────────────────────────────────────────────────────────
    // AutoInventory — автодополнение инвентаря
    // ─────────────────────────────────────────────────────────────
    public boolean autoRefill      = false;
    public boolean refillCrystals  = true;
    public boolean refillTotems    = true;
    public boolean refillFood      = true;

    // ─────────────────────────────────────────────────────────────
    // v1.3 — Standby режим (боты стоят до команды /bot attack)
    // ─────────────────────────────────────────────────────────────
    /** Если true — боты стоят в построении и не атакуют */
    public boolean standbyMode = false; // FIX: был true — боты сразу стояли без атаки

    // ─────────────────────────────────────────────────────────────
    // v7.0 — RoleConfig (настройка количества каждой роли)
    // ─────────────────────────────────────────────────────────────
    /**
     * Конфиг ролей.
     * Если все значения -1 → авторежим (старая логика).
     * Иначе — roleCounts[ROLE] = % (usePercent=true) или штуки.
     *
     * Пример: medic=0 → ни одного медика.
     *         medic=100 → все бойцы медики.
     *         medic=20 (percent) → 20% от отряда.
     */
    public BotRole.RoleConfig roleConfig = new BotRole.RoleConfig();

    // ─────────────────────────────────────────────────────────────
    // v7.0 — WaveDefense
    // ─────────────────────────────────────────────────────────────
    public boolean waveDefenseActive = false;

    // ─────────────────────────────────────────────────────────────
    // v7.0 — CommanderAI настройки
    // ─────────────────────────────────────────────────────────────
    public boolean commanderAdaptEnabled  = true;   // адаптация к снаряжению врага
    public boolean commanderRotateEnabled = true;   // ротация раненых
    public boolean commanderAmbushActive  = false;  // режим засады

    // ─────────────────────────────────────────────────────────────
    // v7.0 — Minimap (мини-карта отряда в GUI)
    // ─────────────────────────────────────────────────────────────
    public boolean minimapEnabled = true;

    // ─────────────────────────────────────────────────────────────
    // v7.0 — TrainingVsMode (отряд против отряда)
    // ─────────────────────────────────────────────────────────────
    public boolean trainingVsMode  = false;  // боты vs боты
    public int     trainingVsWins  = 0;      // побед в тренировочном режиме
    public int     trainingVsTotal = 0;      // всего боёв

    // ─────────────────────────────────────────────────────────────
    // v8 — НОВЫЕ ФУНКЦИИ
    // ─────────────────────────────────────────────────────────────

    // SmokeBomb: бот кидает огненный шар/снежок в ноги убегающему врагу
    public boolean smokeBombEnabled   = false;
    public double  smokeBombMinDist   = 10.0;  // минимальная дистанция для броска
    public int     smokeBombCooldown  = 120;   // тиков между бросками

    // AutoChat Taunts: бот пишет в чат фразы при убийстве / низком HP
    public boolean autoChatEnabled    = false;
    public String  chatKillMessage    = "§c[PVPBot] §fGG, ты пал!";
    public String  chatLowHpMessage   = "§e[PVPBot] §fОстановись, я исцеляюсь!";

    // TeleportStuck: если StuckDetector застрял > порога — телепортируем к владельцу
    public boolean teleportIfStuck    = true;
    public int     teleportStuckTicks = 200;  // тиков застревания до телепорта

    // Enchantment Awareness: бот учитывает Sharpness/Smite врага при выборе уклонения
    public boolean enchantAwareness   = true;

    // AutoFireball: бот кидает огненный шар при появлении (если есть огненный заряд)
    public boolean autoFireball       = false;

    public static final PVPBotConfig INSTANCE = new PVPBotConfig();
}
