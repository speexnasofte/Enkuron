package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * SwordLogic v3.0 — УМНЫЙ Sword PvP.
 *
 * ИСПРАВЛЕНО:
 *   - Скорость движения через Navigation (не addDeltaMovement)
 *   - W-Tap через навигацию: кратко стопаем navigation
 *   - Крит только когда bot.fallDistance > 0 (реальное падение)
 *   - Стрейф делегирован в StrafeAI (с ограничением скорости)
 *   - Дистанция: бот ХОДИТ к цели через nav, не телепортируется
 *   - Лук авто-экипируется при дистанции > 6 блоков
 *   - Перл при > 10 блоков (реальный телепорт через BotDifficultyAI)
 *   - AntiKB: принимаем удар, гасим knockback частично
 */
public class SwordLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double MELEE_RANGE   = 3.2;
    private static final double IDEAL_DIST    = 2.4;
    private static final double BOW_RANGE     = 7.0;
    private static final double PEARL_RANGE   = 10.0;
    private static final int    WTAP_TICKS    = 2;
    private static final int    CRIT_EVERY    = 3;  // каждые N ударов — крит
    private static final int    PEARL_CD      = 80;
    private static final int    BOW_CD        = 20;
    private static final double NAV_SPEED     = 1.05; // скорость navigation (1.0 = норма)

    // ── Состояние ─────────────────────────────────────────────────
    private int    attackCd     = 0;
    private int    wTapPause    = 0;
    private int    hitCount     = 0;
    private int    pearlCd      = 0;
    private int    bowCd        = 0;
    private boolean critPending = false;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public SwordLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        // Выбираем стиль стрейфа по сложности
        strafe.setStyle(switch (cfg.difficulty) {
            case EASY   -> StrafeAI.StrafeStyle.RANDOM;
            case MEDIUM -> StrafeAI.StrafeStyle.CIRCLE;
            case HARD   -> StrafeAI.StrafeStyle.ZIGZAG;
            case EXPERT -> StrafeAI.StrafeStyle.ZIGZAG;
        });
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        // Декременты
        if (attackCd  > 0) attackCd--;
        if (wTapPause > 0) wTapPause--;
        if (pearlCd   > 0) pearlCd--;
        if (bowCd     > 0) bowCd--;

        double dist = bot.distanceTo(target);

        // ── 1. Лук на дальней дистанции ───────────────────────────
        if (dist > BOW_RANGE && cfg.autoBowEnabled && bowCd <= 0) {
            equipBow();
            fireArrowAt(sw, target);
            bowCd = BOW_CD + bot.level().getRandom().nextInt(8);
            return; // не страфим пока стреляем
        }

        // ── 2. Меч на ближней дистанции ───────────────────────────
        equipSword();

        // ── 3. Навигация к цели (через Navigation, не setDeltaMovement) ──
        navigateTo(target, dist);

        // ── 4. Страф с PatternAI ──────────────────────────────────
        if (dist < MELEE_RANGE + 3.0) {
            if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                PatternAI pai = bot.getPatternAI();
                double adaptedYaw = pai.getAdaptedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
                strafe.setAdaptedYaw((float) adaptedYaw);
            }
            strafe.tick(target);
        }

        // ── 5. W-Tap пауза → стопаем движение вперёд ─────────────
        if (wTapPause > 0) {
            bot.getNavigation().stop();
            return;
        }

        // ── 6. Атака ──────────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);

            if (doCrit) {
                performCrit(sw, target);
            } else {
                performAttack(sw, target, false);
            }
        }
    }

    // ── Navigation к цели ─────────────────────────────────────────
    private void navigateTo(LivingEntity target, double dist) {
        if (dist > IDEAL_DIST + 0.8) {
            // Идём к цели
            if (!bot.getNavigation().isInProgress() || bot.tickCount % 8 == 0)
                bot.getNavigation().moveTo(target, NAV_SPEED);
            if (!bot.isSprinting() && dist > 4.0) bot.setSprinting(true);
        } else if (dist < IDEAL_DIST - 0.5) {
            // Отступаем чуть назад
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.12);
            Vec3 cur  = bot.getDeltaMovement();
            bot.setDeltaMovement(
                clamp(cur.x + away.x, -0.25, 0.25),
                cur.y,
                clamp(cur.z + away.z, -0.25, 0.25)
            );
            bot.getNavigation().stop();
        } else {
            // На идеальной дистанции — только страф
            bot.getNavigation().stop();
        }
    }

    // ── Крит: ждём реального падения ──────────────────────────────
    private void performCrit(ServerLevel sw, LivingEntity target) {
        if (!bot.onGround() && bot.fallDistance > 0.01f) {
            // Падаем — бьём крит
            performAttack(sw, target, true);
            critPending = false;
        } else if (bot.onGround() && !critPending) {
            // На земле — прыгаем
            bot.getJumpControl().jump();
            critPending = true;
            attackCd = 1; // атакуем в следующий тик при падении
        } else if (critPending) {
            // Ждём падения (макс 10 тиков, потом обычный удар)
            if (bot.tickCount % 1 == 0) attackCd = 0; // разрешаем атаку
            performAttack(sw, target, false);
            critPending = false;
        }
    }

    // ── Удар ──────────────────────────────────────────────────────
    private void performAttack(ServerLevel sw, LivingEntity target, boolean isCrit) {
        // Смотрим на цель перед ударом
        bot.getLookControl().setLookAt(target, 30f, 30f);

        bot.doHurtTarget(sw, target);

        if (isCrit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 0.8, target.getZ(),
                6, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }

        hitCount++;
        attackCd  = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;

        // W-Tap: останавливаем движение на WTAP_TICKS тиков
        if (cfg.wTapEnabled) {
            wTapPause = WTAP_TICKS;
        }
    }

    // ── Выстрел из лука ───────────────────────────────────────────
    private void fireArrowAt(ServerLevel sw, LivingEntity target) {
        bot.getLookControl().setLookAt(target, 60f, 60f);
        Vec3 predicted = MotionPredictor.predict(target, 4);
        double dist = bot.position().distanceTo(predicted);
        float dmg = (float) Math.max(1.0, 9.0 - dist * 0.25);
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(predicted, predicted).inflate(1.3),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.hurt(sw.damageSources().arrow(null, bot), dmg)
        );
    }

    private void equipSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
    }

    private void equipBow() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }

    private double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
