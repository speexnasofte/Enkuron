package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * SmartFlank v1.0 — умное фланкирование цели отрядом ботов.
 *
 * Логика:
 *   1. Анализирует позицию и направление взгляда врага
 *   2. Назначает каждому боту уникальный угол атаки (равномерно по дуге 270°)
 *   3. Двое ботов атакуют с ФЛАНГОВ, остальные с разных углов
 *   4. Командир остаётся ВПЕРЕДИ (лицом к врагу) как приманка
 *   5. Обновляет позиции каждые UPDATE_INTERVAL тиков
 *
 * Интеграция: вызывается из SquadManager.applyOrderToSoldiers(FLANK)
 * и из BotEntity.tick() → SmartFlank.INSTANCE.tick(bot)
 */
public class SmartFlank {

    public static final SmartFlank INSTANCE = new SmartFlank();

    /** Радиус кольца окружения (блоков) */
    private static final double FLANK_RADIUS = 4.5;
    /** Интервал обновления позиций (тиков) */
    private static final int UPDATE_INTERVAL = 15;
    /** Угол сектора для фланка (не атакуем со стороны, куда смотрит враг — там командир) */
    private static final double COMMANDER_ARC = 60.0; // градусов перед врагом = зона командира

    private LivingEntity currentTarget = null;
    private List<BotEntity> flankBots = null;
    private int updateTimer = 0;
    private boolean active = false;

    private SmartFlank() {}

    /**
     * Запустить фланкирование.
     * @param soldiers  рядовые боты (без командира)
     * @param target    цель
     */
    public void startFlank(List<BotEntity> soldiers, LivingEntity target) {
        this.currentTarget = target;
        this.flankBots = soldiers;
        this.active = true;
        this.updateTimer = 0;
        assignFlankPositions();
    }

    public void stop() {
        active = false;
        currentTarget = null;
        flankBots = null;
    }

    public boolean isActive() { return active; }

    /**
     * Тик для конкретного бота — вызывать из BotEntity.tick().
     * Если SmartFlank активен и бот в списке — бот идёт к своей точке фланка.
     */
    public void tick(BotEntity bot) {
        if (!active || currentTarget == null || flankBots == null) return;
        if (!flankBots.contains(bot)) return;
        if (currentTarget.isRemoved() || !currentTarget.isAlive()) {
            stop();
            return;
        }

        updateTimer--;
        if (updateTimer <= 0) {
            updateTimer = UPDATE_INTERVAL;
            assignFlankPositions();
        }

        // Назначить цель для атаки
        if (bot.getTarget() == null || bot.getTarget().isRemoved()) {
            bot.setTarget(currentTarget);
        }
    }

    /** Рассчитать и назначить позиции фланка всем ботам. */
    private void assignFlankPositions() {
        if (currentTarget == null || flankBots == null || flankBots.isEmpty()) return;

        Vec3 enemyPos = currentTarget.position();
        // Угол взгляда врага (радианы)
        float enemyYaw = currentTarget.getYRot();
        double enemyRad = Math.toRadians(enemyYaw);

        // Угол "перед врагом" (куда смотрит) — там командир, обходим
        // Боты равномерно по дуге 270° позади и сбоку врага
        int n = flankBots.size();
        double startAngle = enemyRad + Math.toRadians(COMMANDER_ARC / 2.0);
        double arcRange = Math.toRadians(360.0 - COMMANDER_ARC);
        double step = (n > 1) ? arcRange / (n - 1) : 0;

        for (int i = 0; i < n; i++) {
            BotEntity bot = flankBots.get(i);
            if (bot.isRemoved() || !bot.isAlive()) continue;

            double angle = startAngle + step * i;
            double dx = Math.cos(angle) * FLANK_RADIUS;
            double dz = Math.sin(angle) * FLANK_RADIUS;
            Vec3 targetPos = enemyPos.add(dx, 0, dz);

            // Навигация к позиции фланка (если далеко) или атака (если близко)
            double distToPos = bot.position().distanceTo(targetPos);
            if (distToPos > 2.0) {
                bot.getNavigation().moveTo(targetPos.x, targetPos.y, targetPos.z, 1.2);
            } else {
                // На позиции — атаковать
                bot.setTarget(currentTarget);
            }
        }
    }

    public LivingEntity getTarget() { return currentTarget; }
}
