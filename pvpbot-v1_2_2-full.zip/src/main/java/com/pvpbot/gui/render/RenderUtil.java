package com.pvpbot.gui.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.*;
import org.joml.Matrix4f;

import java.awt.Color;

/**
 * RenderUtil — скруглённые прямоугольники, тени, градиенты, glow.
 * Всё без сторонних библиотек, чистый Fabric 1.21.4.
 */
public class RenderUtil {

    // ─────────────────────────────────────────────────────────────
    //  ROUNDED RECT  (заливка одним цветом, скруглённые углы)
    // ─────────────────────────────────────────────────────────────

    public static void rounded(GuiGraphics ctx, int x, int y, int w, int h, int r, Color color) {
        int c = color.getRGB();
        // центральный крест
        ctx.fill(x + r, y,     x + w - r, y + h,     c);
        ctx.fill(x,     y + r, x + r,     y + h - r, c);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, c);
        // 4 угла — закрашиваем кружок по пикселям (radius ≤ 12)
        fillCorner(ctx, x + r,     y + r,     r, 180, c);
        fillCorner(ctx, x + w - r, y + r,     r, 270, c);
        fillCorner(ctx, x + r,     y + h - r, r,  90, c);
        fillCorner(ctx, x + w - r, y + h - r, r,   0, c);
    }

    /** Только верхние углы скруглены (для topbar). */
    public static void roundedTop(GuiGraphics ctx, int x, int y, int w, int h, int r, Color color) {
        int c = color.getRGB();
        ctx.fill(x + r, y,     x + w - r, y + h, c);
        ctx.fill(x,     y + r, x + r,     y + h, c);
        ctx.fill(x + w - r, y + r, x + w, y + h, c);
        fillCorner(ctx, x + r,     y + r, r, 180, c);
        fillCorner(ctx, x + w - r, y + r, r, 270, c);
    }

    /** Только нижние углы скруглены. */
    public static void roundedBottom(GuiGraphics ctx, int x, int y, int w, int h, int r, Color color) {
        int c = color.getRGB();
        ctx.fill(x + r, y,         x + w - r, y + h,     c);
        ctx.fill(x,     y,         x + r,     y + h - r, c);
        ctx.fill(x + w - r, y,     x + w,     y + h - r, c);
        fillCorner(ctx, x + r,     y + h - r, r,  90, c);
        fillCorner(ctx, x + w - r, y + h - r, r,   0, c);
    }

    // ─────────────────────────────────────────────────────────────
    //  GRADIENT  (вертикальный)
    // ─────────────────────────────────────────────────────────────

    public static void roundedGradient(GuiGraphics ctx, int x, int y, int w, int h, int r,
                                       Color top, Color bot) {
        int ct = top.getRGB();
        int cb = bot.getRGB();
        // центр
        ctx.fillGradient(x + r, y, x + w - r, y + h, ct, cb);
        ctx.fillGradient(x,     y + r, x + r,     y + h - r, ct, cb);
        ctx.fillGradient(x + w - r, y + r, x + w, y + h - r, ct, cb);
        // углы — простая заливка средним цветом
        int cm = blend(ct, cb, 0.5f);
        fillCorner(ctx, x + r,     y + r,     r, 180, ct);
        fillCorner(ctx, x + w - r, y + r,     r, 270, ct);
        fillCorner(ctx, x + r,     y + h - r, r,  90, cb);
        fillCorner(ctx, x + w - r, y + h - r, r,   0, cb);
    }

    // ─────────────────────────────────────────────────────────────
    //  SHADOW  (мягкая многослойная тень)
    // ─────────────────────────────────────────────────────────────

    public static void shadow(GuiGraphics ctx, int x, int y, int w, int h, int blur, Color color) {
        int a = color.getAlpha();
        for (int i = blur; i > 0; i--) {
            int alpha = (int)(a * (1f - (float) i / blur) * 0.4f);
            if (alpha < 4) continue;
            int c = (alpha << 24) | (color.getRGB() & 0x00FFFFFF);
            ctx.fill(x - i, y - i, x + w + i, y + h + i, c);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  OUTLINE  (тонкая рамка)
    // ─────────────────────────────────────────────────────────────

    public static void outline(GuiGraphics ctx, int x, int y, int w, int h, int r, Color color) {
        // рисуем чуть бо́льший rounded поверх — эффект рамки
        rounded(ctx, x - 1, y - 1, w + 2, h + 2, r + 1, color);
    }

    // ─────────────────────────────────────────────────────────────
    //  GLOW  (цветное свечение)
    // ─────────────────────────────────────────────────────────────

    public static void glow(GuiGraphics ctx, int x, int y, int w, int h, int spread, Color color) {
        int r = color.getRed(), g = color.getGreen(), b = color.getBlue();
        for (int i = spread; i > 0; i--) {
            int alpha = (int)(80 * (1f - (float) i / spread));
            if (alpha < 3) continue;
            int c = (alpha << 24) | (r << 16) | (g << 8) | b;
            ctx.fill(x - i, y - i, x + w + i, y + h + i, c);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  SEPARATOR LINE
    // ─────────────────────────────────────────────────────────────

    public static void hline(GuiGraphics ctx, int x, int y, int w, Color color) {
        ctx.fill(x, y, x + w, y + 1, color.getRGB());
    }

    public static void vline(GuiGraphics ctx, int x, int y, int h, Color color) {
        ctx.fill(x, y, x + 1, y + h, color.getRGB());
    }

    // ─────────────────────────────────────────────────────────────
    //  INTERNAL: quarter-circle fill
    // ─────────────────────────────────────────────────────────────

    /**
     * Заполняет пиксели одного из 4 четвертей круга.
     * quadrant: 0=SE, 90=SW, 180=NW, 270=NE
     */
    private static void fillCorner(GuiGraphics ctx, int cx, int cy, int r, int quadrant, int color) {
        for (int dy = 0; dy < r; dy++) {
            int len = (int) Math.sqrt((double) r * r - (double)(r - 1 - dy) * (r - 1 - dy));
            if (len <= 0) continue;
            switch (quadrant) {
                case   0 -> ctx.fill(cx,       cy + dy, cx + len,      cy + dy + 1, color); // SE
                case  90 -> ctx.fill(cx - len, cy + dy, cx,            cy + dy + 1, color); // SW
                case 180 -> ctx.fill(cx - len, cy - dy - 1, cx,        cy - dy,     color); // NW
                case 270 -> ctx.fill(cx,       cy - dy - 1, cx + len,  cy - dy,     color); // NE
            default: break;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  UTILS
    // ─────────────────────────────────────────────────────────────

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF, aa = (a >> 24) & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF, ba = (b >> 24) & 0xFF;
        int rr = (int)(ar + (br - ar) * t);
        int rg = (int)(ag + (bg - ag) * t);
        int rb = (int)(ab + (bb - ab) * t);
        int ra = (int)(aa + (ba - aa) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }
}
