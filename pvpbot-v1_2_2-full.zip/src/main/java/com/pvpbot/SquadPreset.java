package com.pvpbot;

import java.util.*;

/**
 * SquadPreset — сохранённые конфигурации отрядов.
 *
 * /bot squad save <имя>  — сохранить текущий состав + киты + роли
 * /bot squad load <имя>  — загрузить сохранённый отряд
 * /bot squad presets     — список сохранённых пресетов
 *
 * Хранится в памяти (сессионно). Для постоянного хранения
 * вызовите BotConfig.save() — PVPBotConfig сохраняет squadPresets.
 */
public class SquadPreset {

    public static final SquadPreset INSTANCE = new SquadPreset();

    /** Имя → пресет. */
    private final Map<String, SquadSnapshot> presets = new LinkedHashMap<>();

    private SquadPreset() {}

    // ── API ──────────────────────────────────────────────────────

    /**
     * Сохранить текущий отряд под именем.
     * @return true если сохранено впервые, false если перезаписано
     */
    public boolean save(String name, SquadManager.Squad squad, PVPBotConfig cfg) {
        boolean isNew = !presets.containsKey(name);
        SquadSnapshot snap = new SquadSnapshot();
        snap.name        = name;
        snap.size        = squad.size();
        snap.kitMode     = cfg.mode;
        snap.roleConfig  = cloneRoleConfig(cfg.roleConfig);
        snap.savedAtMs   = System.currentTimeMillis();
        presets.put(name, snap);
        return isNew;
    }

    /**
     * Загрузить пресет — применяет настройки к конфигу.
     * Не спавнит ботов — только настройки.
     * @return snapshot или null если не найден
     */
    public SquadSnapshot load(String name, PVPBotConfig cfg) {
        SquadSnapshot snap = presets.get(name);
        if (snap == null) return null;
        cfg.mode       = snap.kitMode;
        cfg.maxBots    = snap.size;
        cfg.roleConfig = cloneRoleConfig(snap.roleConfig);
        return snap;
    }

    public boolean exists(String name)               { return presets.containsKey(name); }
    public void    delete(String name)               { presets.remove(name); }
    public Set<String> listNames()                   { return Collections.unmodifiableSet(presets.keySet()); }
    public SquadSnapshot get(String name)            { return presets.get(name); }

    // ── Snapshot ─────────────────────────────────────────────────

    public static class SquadSnapshot {
        public String name;
        public int    size;
        public PVPBotConfig.Mode kitMode;
        public BotRole.RoleConfig roleConfig;
        public long   savedAtMs;

        /** Краткое описание для GUI / чата. */
        public String summary() {
            return "§f" + name + " §7[" + size + " бойцов, " + kitMode + "]";
        }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private BotRole.RoleConfig cloneRoleConfig(BotRole.RoleConfig src) {
        BotRole.RoleConfig dst = new BotRole.RoleConfig();
        dst.usePercent = src.usePercent;
        dst.roleCounts.putAll(src.roleCounts);
        return dst;
    }
}
