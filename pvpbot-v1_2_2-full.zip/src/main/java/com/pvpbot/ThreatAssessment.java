package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * ThreatAssessment v1.0 — оценка угрозы от нескольких врагов.
 *
 * Вместо "ударь ближайшего" — выбирает самую опасную цель:
 *
 *  Очки угрозы складываются из:
 *   + Низкий HP цели          → +40 (добить выгоднее)
 *   + Цель атакует бота       → +30 (смотрит на нас и близко)
 *   + Цель пьёт зелье         → +25 (уязвима сейчас)
 *   + Цель в воздухе          → +15 (не может уклониться)
 *   + Цель без брони          → +10
 *   + Дистанция (ближе = +)   → до +20
 *   - Цель в щите             → -50 (бесполезно бить)
 *   - Цель высокий HP         → -10
 *
 * Пересчёт каждые REASSESS_INTERVAL тиков.
 */
public class ThreatAssessment {

    private static final int    REASSESS_INTERVAL = 15; // тиков между пересчётом
    private static final double SCAN_RANGE        = 20.0;

    private LivingEntity bestTarget   = null;
    private int          reassessTimer = 0;

    private final BotEntity bot;

    public ThreatAssessment(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Вызывать каждый тик. Возвращает наиболее опасную цель.
     */
    public LivingEntity tick() {
        reassessTimer--;
        if (reassessTimer > 0 && bestTarget != null && bestTarget.isAlive()) {
            return bestTarget;
        }
        reassessTimer = REASSESS_INTERVAL;
        bestTarget = findBestTarget();
        return bestTarget;
    }

    public LivingEntity getBestTarget() { return bestTarget; }

    // ─────────────────────────────────────────────────────────────

    private LivingEntity findBestTarget() {
        if (!(bot.level() instanceof ServerLevel sw)) return null;

        AABB box = bot.getBoundingBox().inflate(SCAN_RANGE);
        List<LivingEntity> candidates = sw.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != bot
              && e.isAlive()
              && !e.isInvisible()
              && !isOwnerOrAlly(e)
              && !isWhitelisted(e)
        );

        if (candidates.isEmpty()) return null;

        LivingEntity best = null;
        float bestScore = Float.NEGATIVE_INFINITY;

        for (LivingEntity e : candidates) {
            float score = computeThreat(e);
            if (score > bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    private float computeThreat(LivingEntity e) {
        float score = 0f;
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        double dist = bot.distanceTo(e);

        // Дистанция: ближе = опаснее (до +20)
        score += Math.max(0, 20f - (float) dist);

        // Низкий HP → добить (+40)
        float hpFraction = e.getHealth() / e.getMaxHealth();
        if (hpFraction < 0.3f) score += 40f;
        else if (hpFraction < 0.5f) score += 20f;
        else score -= 10f * hpFraction; // высокий HP — штраф

        // Цель смотрит на бота и близко → атакует нас (+30)
        if (dist < cfg.attackRange + 2.0 && isLookingAtBot(e)) score += 30f;

        // Цель пьёт зелье → уязвима (+25)
        if (e.isUsingItem() && isUsingPotion(e)) score += 25f;

        // Цель в воздухе → не может уклониться (+15)
        if (!e.onGround()) score += 15f;

        // Цель без брони (+10)
        if (e instanceof Player p) {
            int armorVal = p.getArmorValue();
            if (armorVal < 5) score += 10f;
            else if (armorVal > 15) score -= 5f;

            // Щит → бесполезно атаковать (-50)
            if (p.isBlocking()) score -= 50f;
        }

        return score;
    }

    private boolean isLookingAtBot(LivingEntity e) {
        var look = e.getViewVector(1.0f).normalize();
        var toBot = bot.getEyePosition().subtract(e.getEyePosition()).normalize();
        return look.dot(toBot) > 0.707; // ~45 градусов
    }

    private boolean isUsingPotion(LivingEntity e) {
        var item = e.getUseItem();
        return !item.isEmpty() && (
            item.is(Items.POTION) ||
            item.is(Items.SPLASH_POTION) ||
            item.is(Items.LINGERING_POTION)
        );
    }

    private boolean isOwnerOrAlly(LivingEntity e) {
        Player owner = bot.getOwner();
        if (owner != null && e instanceof Player p && p.getUUID().equals(owner.getUUID())) return true;
        if (e instanceof BotEntity other) {
            Player otherOwner = other.getOwner();
            if (owner != null && otherOwner != null && owner.getUUID().equals(otherOwner.getUUID())) return true;
        }
        return false;
    }

    private boolean isWhitelisted(LivingEntity e) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.whitelistEnabled) return false;
        if (!(e instanceof Player p)) return false;
        return cfg.whitelist.contains(p.getName().getString());
    }
}
