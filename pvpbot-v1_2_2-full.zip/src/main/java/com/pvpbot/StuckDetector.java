package com.pvpbot;

import net.minecraft.world.phys.Vec3;

import java.util.UUID;
import java.util.*;

/**
 * StuckDetector v1.0 — определяет, застрял ли бот, и автоматически обходит.
 *
 * Алгоритм:
 *   1. Каждые CHECK_INTERVAL тиков сравниваем текущую позицию с предыдущей
 *   2. Если бот не переместился на MIN_MOVE и хочет куда-то идти → STUCK
 *   3. Попытка выбраться:
 *      - Прыжок (если блок перед ботом)
 *      - Движение в случайную сторону (обход препятствия)
 *      - Телепортация к владельцу если 3 попытки не помогли
 *   4. После успешного перемещения — сброс счётчика
 *
 * Интеграция:
 *   StuckDetector detector = new StuckDetector(bot); // в BotEntity
 *   detector.tick(); // в BotEntity.tick()
 */
public class StuckDetector {

    // ── Параметры ─────────────────────────────────────────────────
    /** Тиков между проверками */
    private static final int CHECK_INTERVAL = 20;
    /** Минимальное перемещение за CHECK_INTERVAL тиков (блоков) */
    private static final double MIN_MOVE = 0.3;
    /** Максимум попыток выбраться перед ТП к владельцу */
    private static final int MAX_ESCAPE_ATTEMPTS = 4;
    /** Cooldown после успешного выхода (тиков) */
    private static final int ESCAPE_COOLDOWN = 60;

    // ── Состояние ─────────────────────────────────────────────────
    private final BotEntity bot;
    private Vec3 lastCheckPos;
    private int checkTimer = 0;
    private int escapeAttempts = 0;
    private int cooldownTimer = 0;
    private boolean stuck = false;
    private int stuckTicks = 0;
    private final Random rng = new Random();

    public StuckDetector(BotEntity bot) {
        this.bot = bot;
        this.lastCheckPos = bot.position();
    }

    // ── Основной тик ──────────────────────────────────────────────

    public void tick() {
        if (cooldownTimer > 0) { cooldownTimer--; return; }

        checkTimer++;
        if (checkTimer < CHECK_INTERVAL) return;
        checkTimer = 0;

        Vec3 currentPos = bot.position();
        double moved = currentPos.distanceTo(lastCheckPos);

        boolean wantsToMove = bot.getNavigation().isInProgress();

        if (wantsToMove && moved < MIN_MOVE) {
            if (!stuck) {
                stuck = true;
                stuckTicks++;
                escapeAttempts = 0;
            }
            tryEscape();
        } else {
            // Движется нормально
            stuck = false;
            escapeAttempts = 0;
        }

        lastCheckPos = currentPos;
    }

    public boolean isStuck() { return stuck; }
    public int getStuckTicks() { return stuckTicks; }

    // ── Логика выхода ────────────────────────────────────────────

    private void tryEscape() {
        escapeAttempts++;

        if (escapeAttempts > MAX_ESCAPE_ATTEMPTS) {
            // Слишком долго застрял — телепортируемся к владельцу
            teleportToOwner();
            stuck = false;
            escapeAttempts = 0;
            cooldownTimer = ESCAPE_COOLDOWN;
            return;
        }

        switch (escapeAttempts) {
            case 1 -> jumpEscape();    // попробовать прыгнуть
            case 2 -> sideStep();      // шаг в сторону
            case 3 -> randomDirection();// случайное направление
            case 4 -> jumpAndPush();   // прыжок + толчок
            default -> {}
        }

        cooldownTimer = 15; // небольшая пауза между попытками
    }

    /** Попытка прыжком перепрыгнуть препятствие. */
    private void jumpEscape() {
        if (!bot.onGround()) return;
        bot.setDeltaMovement(bot.getDeltaMovement().add(0, 0.42, 0));
        // Продолжить в направлении навигации
    }

    /** Шаг в сторону (перпендикулярно текущему направлению движения). */
    private void sideStep() {
        Vec3 nav = getNavDirection();
        if (nav == null) return;
        // Перпендикуляр
        Vec3 side = new Vec3(-nav.z, 0, nav.x).normalize().scale(2.0);
        if (rng.nextBoolean()) side = side.scale(-1); // рандомная сторона
        Vec3 target = bot.position().add(side);
        bot.getNavigation().moveTo(target.x, target.y, target.z, 1.3);
    }

    /** Случайное направление. */
    private void randomDirection() {
        double angle = rng.nextDouble() * Math.PI * 2;
        double dist = 3.0 + rng.nextDouble() * 3.0;
        Vec3 target = bot.position().add(
            Math.cos(angle) * dist, 0, Math.sin(angle) * dist
        );
        bot.getNavigation().moveTo(target.x, target.y, target.z, 1.3);
    }

    /** Прыжок + рывок в сторону. */
    private void jumpAndPush() {
        if (bot.onGround()) {
            bot.setDeltaMovement(bot.getDeltaMovement().add(
                (rng.nextDouble() - 0.5) * 0.4,
                0.5,
                (rng.nextDouble() - 0.5) * 0.4
            ));
        }
    }

    /** Телепортация к владельцу — последнее средство. */
    private void teleportToOwner() {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer owner) {
            // Телепортируем рядом с владельцем, со смещением
            double angle = rng.nextDouble() * Math.PI * 2;
            bot.teleportTo(
                owner.getX() + Math.cos(angle) * 2.0,
                owner.getY(),
                owner.getZ() + Math.sin(angle) * 2.0
            );
            // Уведомить (тихо)
            if (PVPBotConfig.INSTANCE.notificationsEnabled) {
                owner.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§7[PVPBot] §fБот застрял — телепортирован к тебе."
                ));
            }
        }
    }

    private Vec3 getNavDirection() {
        var path = bot.getNavigation().getPath();
        if (path == null) return null;
        var next = path.getNextNode();
        if (next == null) return null;
        return new Vec3(next.x - bot.getX(), 0, next.z - bot.getZ()).normalize();
    }
}
