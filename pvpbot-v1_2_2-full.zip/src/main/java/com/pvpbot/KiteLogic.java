package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * KiteLogic — кайтинг (kiting): держим дистанцию от врага, стреляя из лука.
 *
 * Состояния:
 *  FLEE   — враг слишком близко (< kiteMinDist) → убегаем назад
 *  IDEAL  — враг в зоне стрельбы (kiteMinDist..kiteMaxDist) → стоим/стрейф
 *  CHASE  — враг слишком далеко (> kiteMaxDist) → приближаемся
 *
 * Алгоритм отступления:
 *  1. Вычисляем вектор "от врага"
 *  2. Ищем свободное направление методом wall-avoidance (3 варианта: прямо, +45°, -45°)
 *  3. Устанавливаем клавиши движения через velocity
 */
public class KiteLogic {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private static void setKeyDown(net.minecraft.client.KeyMapping key, boolean down) {
        try {
            var f = net.minecraft.client.KeyMapping.class.getDeclaredField("isDown");
            f.setAccessible(true);
            f.set(key, down);
        } catch (Exception ignored) {}
    }


    private enum KiteState { FLEE, IDEAL, CHASE }
    private KiteState state = KiteState.IDEAL;

    private int strafeTimer = 0;
    private int strafeDir   = 1;

    public void tick(Minecraft client) {
        if (!cfg.kiteEnabled) {
            releaseKeys(client);
            return;
        }
        if (client.player == null || client.level == null) return;

        Player player = client.player;
        LivingEntity target = findKiteTarget(client, player);

        if (target == null) {
            releaseKeys(client);
            return;
        }

        double dist = player.distanceTo(target);
        updateState(dist);

        switch (state) {
            case FLEE  -> flee(client, player, target);
            case IDEAL -> idealPosition(client, player, target);
            case CHASE -> chase(client, player, target);
            default: break;
        }
    }

    private void updateState(double dist) {
        if      (dist < cfg.kiteMinDist)  state = KiteState.FLEE;
        else if (dist > cfg.kiteMaxDist)  state = KiteState.CHASE;
        else                              state = KiteState.IDEAL;
    }

    /** Убегаем от врага, разворачиваясь спиной */
    private void flee(Minecraft client, Player player, LivingEntity target) {
        Vec3 away = player.position().subtract(target.position()).normalize();

        // Устанавливаем velocity напрямую — мгновенный отклик
        Vec3 curr = player.getDeltaMovement();
        double fleeSpeed = 0.25;
        player.setDeltaMovement(
            curr.x * 0.5 + away.x * fleeSpeed,
            curr.y,
            curr.z * 0.5 + away.z * fleeSpeed
        );

        setKeyDown(client.options.keyDown, true);
        setKeyDown(client.options.keyUp, false);
        setKeyDown(client.options.keyLeft, false);
        setKeyDown(client.options.keyRight, false);
    }

    /** Идеальная дистанция — стрейфимся, не убегаем */
    private void idealPosition(Minecraft client, Player player, LivingEntity target) {
        strafeTimer--;
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = 15 + (int)(Math.random() * 10);
        }

        setKeyDown(client.options.keyDown, false);
        setKeyDown(client.options.keyUp, false);

        if (strafeDir > 0) {
            setKeyDown(client.options.keyLeft, true);
            setKeyDown(client.options.keyRight, false);
        } else {
            setKeyDown(client.options.keyRight, true);
            setKeyDown(client.options.keyLeft, false);
        }
    }

    /** Враг слишком далеко — приближаемся */
    private void chase(Minecraft client, Player player, LivingEntity target) {
        setKeyDown(client.options.keyUp, true);
        setKeyDown(client.options.keyDown, false);
        setKeyDown(client.options.keyLeft, false);
        setKeyDown(client.options.keyRight, false);
    }

    private void releaseKeys(Minecraft client) {
        setKeyDown(client.options.keyDown, false);
        setKeyDown(client.options.keyLeft, false);
        setKeyDown(client.options.keyRight, false);
    }

    private LivingEntity findKiteTarget(Minecraft client, Player player) {
        AABB box = player.getBoundingBox().inflate(cfg.kiteMaxDist + 10);
        List<LivingEntity> entities = client.level.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive() && !e.isInvisible()
        );
        return entities.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }
}
