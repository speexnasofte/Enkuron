package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.*;

/**
 * CasualtyTracker — счётчик потерь отряда.
 *
 * Следит за смертями бойцов и пишет в чат:
 *   "§c[Отряд] Потеряли 3 из 20 бойцов"
 *
 * А также ведёт историю боёв (BattleHistory) для GUI вкладки ИСТОРИЯ БОЁВ:
 *   { дата, тип отряда, кол-во бойцов, потери, победа/поражение }
 */
public class CasualtyTracker {

    public static final CasualtyTracker INSTANCE = new CasualtyTracker();

    // ── История боёв ─────────────────────────────────────────────

    public static class BattleRecord {
        public final long   timestamp;
        public final String squadKit;
        public final int    initialSize;
        public       int    casualties;
        public       boolean victory;
        public final Map<BotRole, Integer> roleSnapshot;

        public BattleRecord(String squadKit, int size, Map<BotRole, Integer> roles) {
            this.timestamp   = System.currentTimeMillis();
            this.squadKit    = squadKit;
            this.initialSize = size;
            this.casualties  = 0;
            this.victory     = false;
            this.roleSnapshot = new LinkedHashMap<>(roles);
        }

        public String dateStr() {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd.MM HH:mm");
            return sdf.format(new java.util.Date(timestamp));
        }

        public String summary() {
            String result = victory ? "§aПобеда" : "§cПоражение";
            return dateStr() + "  §f" + squadKit + "  §7" + initialSize + " бойцов  " +
                   "§cПотери: " + casualties + "  " + result;
        }
    }

    private final List<BattleRecord> history = new ArrayList<>();
    private BattleRecord current = null;
    private int lastAlive = 0;

    private CasualtyTracker() {}

    // ── API ──────────────────────────────────────────────────────

    /** Начать новый бой. */
    public void startBattle(SquadManager.Squad squad, String kitName) {
        Map<BotRole, Integer> roles = new LinkedHashMap<>();
        for (BotEntity bot : squad.allBots()) {
            BotRole r = bot.getSquadRole();
            roles.merge(r != null ? r : BotRole.SOLDIER, 1, Integer::sum);
        }
        current = new BattleRecord(kitName, squad.size(), roles);
        lastAlive = squad.size();
    }

    /** Вызывать каждый тик / при проверке живых бойцов. */
    public void tick(SquadManager.Squad squad, ServerPlayer owner) {
        if (current == null) return;

        int alive = (int) squad.aliveSoldiers() + (squad.commander != null && squad.commander.isAlive() ? 1 : 0);
        int losses = current.initialSize - alive;

        if (losses > current.casualties) {
            int newDeaths = losses - current.casualties;
            current.casualties = losses;
            // Оповещение в чат
            announcecasualties(owner, alive, current.initialSize, newDeaths);
            lastAlive = alive;
        }
    }

    /** Завершить бой (победа / поражение). */
    public void endBattle(boolean victory, ServerPlayer owner) {
        if (current == null) return;
        current.victory = victory;
        history.add(0, current); // новые записи в начало
        if (history.size() > 50) history.remove(history.size() - 1);

        String msg = victory
            ? "§a§l[Бой завершён] §aПобеда! §7Потери: §c" + current.casualties + " из " + current.initialSize
            : "§c§l[Бой завершён] §cПоражение. §7Потери: §c" + current.casualties + " из " + current.initialSize;
        if (owner != null) owner.sendSystemMessage(Component.literal(msg));
        current = null;
    }

    public List<BattleRecord> getHistory() { return Collections.unmodifiableList(history); }
    public BattleRecord getCurrent()       { return current; }

    // ── Внутреннее ───────────────────────────────────────────────

    private void announcecasualties(ServerPlayer owner, int alive, int total, int newDeaths) {
        if (owner == null) return;
        String msg = "§c[Отряд] §fПотеряли §c" + (total - alive) + " §fиз §c" + total +
                     " §fбойцов" + (newDeaths > 1 ? " §7(-" + newDeaths + ")" : "");
        owner.sendSystemMessage(Component.literal(msg));
    }
}
