package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * MedicLogic — поведение роли MEDIC (Медик).
 *
 * Медик:
 *  - Сканирует союзников в радиусе HEAL_RANGE
 *  - Лечит ближайшего раненого (HP < HEAL_THRESHOLD): Regeneration II + 5 HP
 *  - Даёт баффы всему отряду раз в BUFF_INTERVAL тиков: Strength I, Fire Resistance
 *  - Держится за основным отрядом, не атакует первым
 *  - Отступает если враг ближе FLEE_RANGE
 *
 * Вызывается из BotEntity.tick() если bot.getSquadRole() == MEDIC.
 */
public class MedicLogic {

    public static final MedicLogic INSTANCE = new MedicLogic();

    private static final double HEAL_RANGE   = 16.0;
    private static final float  HEAL_THRESH  = 12.0f;  // лечим ниже этого HP
    private static final int    HEAL_CD      = 60;     // тиков между лечениями
    public static final int BUFF_INTERVAL = 400;   // тиков между глобальными баффами (20 сек)
    private static final double FLEE_RANGE   = 5.0;

    private MedicLogic() {}

    public void tick(BotEntity bot, SquadManager.Squad squad, LivingEntity nearestEnemy) {
        if (!(bot.level() instanceof ServerLevel level)) return;

        // Убегать от врага
        if (nearestEnemy != null && bot.distanceTo(nearestEnemy) < FLEE_RANGE) {
            fleeFrom(bot, nearestEnemy);
        }

        // Кулдауны
        if (bot.medicHealCooldown > 0) bot.medicHealCooldown--;
        if (bot.medicBuffCooldown > 0) bot.medicBuffCooldown--;

        // Глобальный бафф отряда (инициализация: medicBuffCooldown стартует с BUFF_INTERVAL,
        // поэтому первый бафф произойдёт не раньше чем через 400 тиков после спавна медика)
        if (bot.medicBuffCooldown <= 0 && squad != null) {
            buffSquad(bot, squad, level);
            bot.medicBuffCooldown = BUFF_INTERVAL;
        }

        // Лечение раненых
        if (bot.medicHealCooldown <= 0 && squad != null) {
            BotEntity wounded = findMostWounded(bot, squad);
            if (wounded != null && wounded.getHealth() < HEAL_THRESH) {
                healBot(bot, wounded);
                bot.medicHealCooldown = HEAL_CD;
            } else {
                // Попробовать вылечить игрока-владельца
                healNearbyPlayers(bot, level);
            }
        }
    }

    // ── Лечение ──────────────────────────────────────────────────

    private void healBot(BotEntity medic, BotEntity target) {
        // Мгновенное лечение
        target.heal(6.0f);
        // Регенерация на 5 секунд
        target.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1, false, false));
        // Поглощение на 10 секунд
        target.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 0, false, false));

        if (medic.level() instanceof ServerLevel) {
            Player owner = medic.getOwner();
            if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
                sp.sendSystemMessage(Component.literal(
                    "§a[Медик] §fВылечил " + target.getName().getString() + " §7(+6 HP)"));
            }
        }
    }

    private void healNearbyPlayers(BotEntity medic, ServerLevel level) {
        AABB box = medic.getBoundingBox().inflate(HEAL_RANGE);
        List<Player> players = level.getEntitiesOfClass(Player.class, box,
            p -> p.isAlive() && p.getHealth() < HEAL_THRESH);
        if (!players.isEmpty()) {
            Player p = players.get(0);
            p.heal(4.0f);
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 1, false, false));
        }
    }

    // ── Баффы отряда ─────────────────────────────────────────────

    private void buffSquad(BotEntity medic, SquadManager.Squad squad, ServerLevel level) {
        for (BotEntity bot : squad.allBots()) {
            if (!bot.isAlive()) continue;
            // Сила I на 15 секунд
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 0, false, false));
            // Огнестойкость на 30 секунд
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 600, 0, false, false));
        }

        // Оповещение только владельцу
        Player owner = medic.getOwner();
        if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
            sp.sendSystemMessage(Component.literal("§a[Медик] §fВыдал баффы всему отряду!"));
        }
    }

    // ── Helpers ──────────────────────────────────────────────────

    private BotEntity findMostWounded(BotEntity medic, SquadManager.Squad squad) {
        BotEntity target = null;
        float minHp = Float.MAX_VALUE;
        for (BotEntity bot : squad.soldiers) {
            if (bot == medic || !bot.isAlive()) continue;
            if (bot.getHealth() < minHp && medic.distanceTo(bot) < HEAL_RANGE) {
                minHp = bot.getHealth();
                target = bot;
            }
        }
        return target;
    }

    private void fleeFrom(BotEntity bot, LivingEntity threat) {
        net.minecraft.world.phys.Vec3 away =
            bot.position().subtract(threat.position()).normalize().scale(12.0);
        net.minecraft.world.phys.Vec3 goal = bot.position().add(away);
        bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.2);
    }
}
