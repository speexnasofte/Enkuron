package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * PlayerlikeBlockPlacer v1.0 — имитация ставления блоков живым игроком.
 *
 * PLAYER-сложность: бот должен быть неотличим от реального игрока.
 * Реальный игрок в PvP:
 *   1. Бриджует — ставит блоки под ногами при движении над пропастью
 *   2. Накрывается сверху (1x1 крыша) если враг пытается залезть сверху
 *   3. Ставит блок между собой и врагом (defensively places a block)
 *   4. Всё это с «человеческой» задержкой и редкими промахами
 *
 * Используется только при difficulty == PLAYER.
 * Вызывать: placer.tick(target) каждый тик из tickPlayer().
 */
public class PlayerlikeBlockPlacer {

    private final BotEntity bot;
    private int cooldown = 0;

    // Действия, которые бот может предпринять
    private enum PlaceAction { BRIDGE, ROOF, WALL, NONE }

    public PlayerlikeBlockPlacer(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Основной тик — решает, нужно ли ставить блок прямо сейчас.
     * Возвращает true если блок был поставлен.
     */
    public boolean tick(LivingEntity target) {
        if (cooldown > 0) { cooldown--; return false; }
        if (!(bot.level() instanceof ServerLevel sw)) return false;

        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        // Выбираем блок из инвентаря (или используем дефолтный cobblestone)
        ItemStack block = findBuildingBlock();
        if (block.isEmpty()) return false;

        PlaceAction action = decideAction(sw, target, cfg);
        if (action == PlaceAction.NONE) return false;

        boolean placed = switch (action) {
            case BRIDGE -> tryBridge(sw, block);
            case ROOF   -> tryRoof(sw, block);
            case WALL   -> tryWall(sw, target, block);
            default     -> false;
        };

        if (placed) {
            // Человеческая задержка после постройки
            cooldown = cfg.playerBlockPlaceCooldown
                     + bot.level().getRandom().nextInt(cfg.playerReactionJitter + 1);
        }
        return placed;
    }

    /** Решаем что делать: бридж, крышу или стену? */
    private PlaceAction decideAction(ServerLevel sw, LivingEntity target, PVPBotConfig cfg) {
        var rng = bot.level().getRandom();

        // Приоритет: стена если враг прямо перед нами и близко
        if (target != null && target.isAlive()) {
            double dist = bot.distanceTo(target);
            if (dist < 3.5 && rng.nextInt(100) < 25) {
                // Иногда ставим стену между собой и врагом
                return PlaceAction.WALL;
            }
            // Крыша — если враг выше бота (прыгает сверху)
            if (target.getY() > bot.getY() + 1.5 && rng.nextInt(100) < cfg.playerRoofChance) {
                return PlaceAction.ROOF;
            }
        }

        // Бридж — если под ногами пустота
        BlockPos underFeet = bot.blockPosition().below();
        BlockState under = sw.getBlockState(underFeet);
        if (under.isAir() || under.liquid()) {
            if (rng.nextInt(100) < cfg.playerBridgeChance) {
                return PlaceAction.BRIDGE;
            }
        }

        return PlaceAction.NONE;
    }

    // ── Bridge: ставим блок под ногами при движении ───────────────
    private boolean tryBridge(ServerLevel sw, ItemStack block) {
        BlockPos under = bot.blockPosition().below();
        if (!sw.getBlockState(under).isAir()) return false;

        // Ищем опорную поверхность рядом — соседний блок сбоку снизу
        for (Direction dir : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos neighbor = under.relative(dir);
            if (!sw.getBlockState(neighbor).isAir()) {
                placeBlock(sw, under, block);
                return true;
            }
        }
        // Попробуем поставить прямо под ноги если есть место
        BlockPos twoBelow = under.below();
        if (!sw.getBlockState(twoBelow).isAir()) {
            placeBlock(sw, under, block);
            return true;
        }
        return false;
    }

    // ── Roof: ставим блок над головой (защита от прыжков сверху) ──
    private boolean tryRoof(ServerLevel sw, ItemStack block) {
        BlockPos above = bot.blockPosition().above(2); // над головой
        if (!sw.getBlockState(above).isAir()) return false;

        // Нужна опора — боковой блок на уровне above
        for (Direction dir : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos support = above.relative(dir);
            if (!sw.getBlockState(support).isAir()) {
                placeBlock(sw, above, block);
                return true;
            }
        }
        return false;
    }

    // ── Wall: ставим блок между ботом и целью (временная стенка) ──
    private boolean tryWall(ServerLevel sw, LivingEntity target, ItemStack block) {
        if (target == null) return false;

        // Позиция блока — между ботом и целью на уровне ног
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        BlockPos wallPos = bot.blockPosition().offset(
            (int) Math.round(toTarget.x),
            0,
            (int) Math.round(toTarget.z)
        );

        if (!sw.getBlockState(wallPos).isAir()) return false;
        // Нужна поддержка снизу
        if (sw.getBlockState(wallPos.below()).isAir()) return false;

        placeBlock(sw, wallPos, block);
        return true;
    }

    // ── Непосредственная установка блока ────────────────────────
    private void placeBlock(ServerLevel sw, BlockPos pos, ItemStack blockStack) {
        BlockState state = Blocks.COBBLESTONE.defaultBlockState();

        // Если в стеке есть BlockItem — берём его state
        if (blockStack.getItem() instanceof BlockItem bi) {
            state = bi.getBlock().defaultBlockState();
        }

        sw.setBlock(pos, state, 3); // 3 = UPDATE_ALL

        // Бот смотрит на место установки — «как игрок»
        bot.getLookControl().setLookAt(
            pos.getX() + 0.5,
            pos.getY() + 0.5,
            pos.getZ() + 0.5,
            30f, 30f
        );

        // Анимация руки (swing)
        bot.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
    }

    // ── Поиск строительного блока в «инвентаре» бота ─────────────
    /**
     * PathfinderMob не имеет настоящего инвентаря как Player,
     * поэтому мы даём боту в руку cobblestone для постройки,
     * а после — возвращаем меч.
     *
     * В реальной реализации с Forge/Fabric inventory API
     * можно искать Block-стеки из BotInventory.
     */
    private ItemStack findBuildingBlock() {
        // Смотрим offhand
        ItemStack off = bot.getOffhandItem();
        if (!off.isEmpty() && off.getItem() instanceof BlockItem) return off;

        // Смотрим mainhand
        ItemStack main = bot.getMainHandItem();
        if (!main.isEmpty() && main.getItem() instanceof BlockItem) return main;

        // Нет блока — дать cobblestone из «невидимого запаса»
        // (бот всегда имеет материалы, как у игрока в хардкор-пвп)
        return new ItemStack(Items.COBBLESTONE);
    }

    /**
     * Временно взять в руку блок для постройки, потом вернуть меч.
     * Вызывается из tickPlayer() вокруг вызова tick().
     */
    public void equipBlockTemporarily() {
        ItemStack main = bot.getMainHandItem();
        if (main.isEmpty() || !(main.getItem() instanceof BlockItem)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.COBBLESTONE));
        }
    }

    public void reequipSword() {
        ItemStack main = bot.getMainHandItem();
        if (main.getItem() instanceof BlockItem) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        }
    }
}
