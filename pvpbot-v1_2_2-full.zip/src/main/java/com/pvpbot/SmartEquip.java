package com.pvpbot;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;

import java.util.*;


/**
 * SmartEquip v10 — умная экипировка бота из инвентаря.
 *
 * Расширяет /bot equip: вместо жёсткой выдачи неритовского сета
 * анализирует инвентарь бота и надевает лучшее из доступного.
 *
 * Логика:
 *   1. Для каждого слота брони (HEAD/CHEST/LEGS/FEET) выбираем предмет
 *      с максимальным показателем защиты (ArmorItem.getProtection()).
 *   2. Для MAINHAND выбираем оружие с максимальным attack_damage.
 *   3. Учитываем зачарования: добавляем Protection/Sharpness к базовым значениям.
 *   4. Если в инвентаре ничего нет — выдаём неритовский дефолт (старое поведение).
 *
 * Интеграция:
 *   - SmartEquip.equip(bot, world) вызывается в SpawnBotCommand.equipBot()
 *     вместо giveDefaultEquipment(bot).
 *   - Команда /bot equip [smart] — если параметр указан, использует SmartEquip,
 *     иначе — старый дефолт (обратная совместимость).
 */
public class SmartEquip {

    private SmartEquip() {}

    // ── Слот → подходящие типы предметов ────────────────────────

    private static final Map<EquipmentSlot, Class<?>> SLOT_TYPES = new LinkedHashMap<>();
    static {
        SLOT_TYPES.put(EquipmentSlot.HEAD,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.CHEST,     ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.LEGS,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.FEET,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.MAINHAND,  null); // weapons — отдельная логика
    }

    /**
     * Основной метод. Берёт предметы из инвентаря бота или создаёт дефолтные.
     *
     * @param bot   целевой бот
     * @param world серверный мир (нужен для EnchantmentHelper)
     */
    public static void equip(BotEntity bot, ServerLevel world) {
        net.minecraft.world.entity.Mob mob = bot;
        // Собираем предметы из слотов снаряжения бота
        List<ItemStack> available = new ArrayList<>();
        for (EquipmentSlot sl : EquipmentSlot.values()) {
            ItemStack s = bot.getItemBySlot(sl);
            if (!s.isEmpty()) available.add(s.copy());
        }

        // Броня
        for (EquipmentSlot slot : new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack best = bestArmorFor(slot, available, world);
            if (best != null) {
                bot.setItemSlot(slot, best);
            } else {
                bot.setItemSlot(slot, defaultArmor(slot));
            }
        }

        // Оружие
        ItemStack bestWeapon = bestWeapon(available, world);
        if (bestWeapon != null) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, bestWeapon);
        } else {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                new ItemStack(Items.NETHERITE_SWORD));
        }
    }

    // ── Выбор лучшей брони ───────────────────────────────────────

    private static ItemStack bestArmorFor(EquipmentSlot slot,
                                          List<ItemStack> pool,
                                          ServerLevel world) {
        ItemStack best = null;
        double bestScore = -1;

        for (ItemStack s : pool) {
            var eqComp = s.get(net.minecraft.core.component.DataComponents.EQUIPPABLE);
            if (eqComp == null) continue;
            if (eqComp.slot() != slot) continue;

            // Estimate protection from item type
            double score = s.getItem() instanceof ArmorItem ? 1 : 0;
            // Добавляем бонус Protection
            score += enchantBonus(s, world, "protection") * 0.5;

            if (score > bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    // ── Выбор лучшего оружия ─────────────────────────────────────

    private static ItemStack bestWeapon(List<ItemStack> pool, ServerLevel world) {
        ItemStack best = null;
        double bestScore = -1;

        for (ItemStack s : pool) {
            Item item = s.getItem();
            // Принимаем мечи, топоры и трезубцы
            if (!(item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem)) continue;

            // Базовый урон через атрибуты
            double base = getBaseDamage(s);
            double score = base + enchantBonus(s, world, "sharpness") * 0.8;

            if (score > bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    // ── Базовый урон ─────────────────────────────────────────────

    private static double getBaseDamage(ItemStack stack) {
        // Используем стандартный атрибут attack_damage
        var attrs = stack.get(net.minecraft.core.component.DataComponents.ATTRIBUTE_MODIFIERS);
        double base = 1.0;
        if (attrs != null) {
            for (var entry : attrs.modifiers()) {
                if (entry.attribute().is(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)) {
                    base += entry.modifier().amount();
                }
            }
        }
        return base;
    }

    // ── Бонус зачарования ────────────────────────────────────────

    private static int enchantBonus(ItemStack stack, ServerLevel world, String enchantId) {
        try {
            var reg = world.registryAccess().lookup(Registries.ENCHANTMENT).orElse(null);
            if (reg == null) return 0;
            for (var entry : reg.listElements().toList()) {
                if (entry.key().location().getPath().equals(enchantId)) {
                    return EnchantmentHelper.getItemEnchantmentLevel(entry, stack);
                }
            }
        } catch (Exception ignored) {}
        return 0;
    }

    // ── Дефолтное снаряжение (fallback) ─────────────────────────

    private static ItemStack defaultArmor(EquipmentSlot slot) {
        return new ItemStack(switch (slot) {
            case HEAD  -> Items.NETHERITE_HELMET;
            case CHEST -> Items.NETHERITE_CHESTPLATE;
            case LEGS  -> Items.NETHERITE_LEGGINGS;
            case FEET  -> Items.NETHERITE_BOOTS;
            default    -> Items.AIR;
        });
    }
}
