package com.pvpbot;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Главный класс мода v6 — добавлено:
 *   ESP хитбоксы       (EspRenderer)
 *   Radar HUD          (RadarHud)
 *   K/D статистика     (KillDeathTracker)
 *   AutoBow            (AutoBow, в PVPBotLogic)
 *   Кайтинг            (KiteLogic, в PVPBotLogic)
 *   Улучшенный pathfind (BotPathfindGoal, в BotEntity)
 */
public class PVPBotMod implements ModInitializer, ClientModInitializer {

    public static KeyMapping toggleKey;
    public static KeyMapping settingsKey;

    // v1.2: PVPBotLogic теперь живёт в BotEntity, не здесь
    private final PVPBotConfig cfg        = PVPBotConfig.INSTANCE;
    private final AutoRespawn autoRespawn = new AutoRespawn();
    private final PVPBotHud pvpBotHud = new PVPBotHud();

    // ── Серверная инициализация ──────────────────────────────────
    @Override
    public void onInitialize() {
        BotConfig.load(); // загружает конфиг и синхронизирует ModuleManager
        BotEntityType.register();
        FabricDefaultAttributeRegistry.register(
            BotEntityType.BOT_ENTITY,
            BotEntity.createAttributes()
        );
        SpawnBotCommand.register();
        ChatCommand.register(); // v17: !attack / !retreat / !stand / !flank

        // v16: DuelTimer — тикаем на сервере
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            DuelTimer.INSTANCE.tick(server);
            // OPT v8: GappleOptimizer.globalTick() перенесён сюда из BotEntity.tick()
            // — вызывается 1 раз в тик на весь сервер, а не N раз (по числу ботов)
            GappleOptimizer.INSTANCE.globalTick();
            // OPT v8: BotSyncAttack.serverTick() — тоже глобальная операция,
            // вызываем один раз для каждого онлайн-игрока (не для каждого бота)
            for (net.minecraft.server.level.ServerPlayer sp : server.getPlayerList().getPlayers()) {
                var bots = com.pvpbot.SpawnBotCommand.getBotsFor(sp);
                if (!bots.isEmpty()) {
                    BotSyncAttack.INSTANCE.serverTick(bots);
                }
            }
        });

        // ── FIX v8: onHurtCustom() теперь реально вызывается ────
        // Без этой регистрации ComboBreaker, FightAnalyzer и totem-pop были мертвы.
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DAMAGE.register(
            (entity, source, baseDamage, damage, blocked) -> {
                if (entity instanceof BotEntity bot) {
                    bot.onHurtCustom(source, damage);
                }
            }
        );
    }

    // ── Клиентская инициализация ─────────────────────────────────
    @Override
    public void onInitializeClient() {
        // Клавиши
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.pvpbot.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.pvpbot"
        ));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.pvpbot.settings", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.pvpbot"
        ));

        // HUD (основная панель + радар)
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            pvpBotHud.onHudRender(ctx, ticker); // FIX: переиспользуем экземпляр вместо new каждый кадр
        });
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            var mc = net.minecraft.client.Minecraft.getInstance();
            radarHud.render(ctx, mc);                 // радар
        });

        // ESP — рендер в мире (сквозь стены)
        WorldRenderEvents.END.register(new EspRenderer());

        // K/D трекер
        KillDeathTracker.register();
        DpsMeter.INSTANCE.register(); // v9
        BotSkinManager.INSTANCE.register(); // v9

        // Тик-цикл
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            autoRespawn.tick(client);

            while (toggleKey.consumeClick()) {
                cfg.enabled = !cfg.enabled;
                BotConfig.save();
                if (client.player != null) {
                    client.gui.getChat().addMessage(Component.literal(cfg.enabled ? "§a[PVPBot] §fВключён!" : "§c[PVPBot] §fВыключен!"));
                }
            }

            while (settingsKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new PVPBotScreen(null));
                }
            }

            // v1.2: логика бота тикается в BotEntity.tick() на сервере
        });
    }
}
