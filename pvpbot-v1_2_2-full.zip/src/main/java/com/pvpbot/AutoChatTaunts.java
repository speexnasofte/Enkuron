package com.pvpbot;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * AutoChatTaunts — v8: новая функция.
 *
 * Бот пишет в чат фразы при:
 *  - Убийстве врага    (onKill)
 *  - Низком собственном HP (onLowHp — не чаще раза в 60 сек)
 *
 * Настройка: cfg.autoChatEnabled, cfg.chatKillMessage, cfg.chatLowHpMessage.
 * Активация: /bot module autochat on
 *
 * Сообщение отправляется от имени бота в общий чат сервера через
 * broadcastSystemMessage(). Не требует игрового подключения.
 */
public class AutoChatTaunts {

    public static final AutoChatTaunts INSTANCE = new AutoChatTaunts();

    /** Кулдаун между low-HP сообщениями: 1200 тиков = 60 сек */
    private static final int LOW_HP_CHAT_CD = 1200;

    private int lowHpChatTimer = 0;

    private AutoChatTaunts() {}

    /** Вызывать из BotEntity.die() или KillDeathTracker при фиксации убийства */
    public void onKill(BotEntity bot, LivingEntity killed) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.autoChatEnabled) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;

        String name = killed.getName().getString();
        String msg  = cfg.chatKillMessage.replace("{victim}", name);
        sw.getServer().getPlayerList().broadcastSystemMessage(
            Component.literal(msg), false
        );
    }

    /** Вызывать из BotEntity.onHurtCustom() когда HP < порога */
    public void onLowHp(BotEntity bot) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.autoChatEnabled) return;
        if (lowHpChatTimer > 0) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;

        sw.getServer().getPlayerList().broadcastSystemMessage(
            Component.literal(cfg.chatLowHpMessage), false
        );
        lowHpChatTimer = LOW_HP_CHAT_CD;
    }

    /** Тик кулдауна — вызывать из BotEntity.tick() */
    public void tick() {
        if (lowHpChatTimer > 0) lowHpChatTimer--;
    }
}
