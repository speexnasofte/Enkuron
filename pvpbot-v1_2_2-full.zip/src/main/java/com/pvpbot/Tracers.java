package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Tracers v11 — линии к сущностям.
 * NOTE: В 1.21.4 PoseStack.push/peek/pop и MultiBufferSource.Immediate API изменён.
 * Данная реализация — заглушка без крэша. Полный трейсер требует Mixin.
 */
public class Tracers {

    public static final Tracers INSTANCE = new Tracers();
    private static final String MOD = ModuleManager.MOD_TRACERS;
    private Tracers() {}

    public void register() {
        net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.LAST.register(this::onWorldRender);
    }

    public void onWorldRender(WorldRenderContext context) {
        // Stub: 3D line rendering requires PoseStack/BufferBuilder API refactor for 1.21.4
        // Full implementation needs separate Mixin or updated rendering approach
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) return;
    }
}
