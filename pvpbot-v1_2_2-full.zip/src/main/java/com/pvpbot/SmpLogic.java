package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;

/**
 * SmpLogic v3.0 — УМНЫЙ SMP режим.
 *
 * ИСПРАВЛЕНО:
 *   - Движение через Navigation (не deltaMovement)
 *   - Блокирование щитом: только если есть щит в оффхенде
 *   - Еда: не прерывает бой, если враг близко
 *   - Retreat: навигация от врага, не teleport
 *   - Страф: делегирован StrafeAI (ограниченная скорость)
 *   - Крит прыжки как в SwordLogic
 */
public class SmpLogic {

    private static final double MELEE_RANGE  = 3.0;
    private static final double RETREAT_DIST = 8.0;
    private static final float  SHIELD_HP    = 14.0f;
    private static final float  EAT_HP       = 14.0f;
    private static final float  RETREAT_HP   = 5.0f;
    private static final int    ATTACK_CD    = 12;
    private static final int    SHIELD_DUR   = 22;
    private static final int    EAT_DUR      = 32;
    private static final int    RETREAT_CD   = 100;
    private static final int    CRIT_EVERY   = 4;

    private enum State { FIGHTING, BLOCKING, EATING, RETREATING }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd    = 0;
    private int shieldTimer = 0;
    private int eatTimer    = 0;
    private int retreatCd   = 0;
    private int hitCount    = 0;
    private boolean critPending = false;

    public SmpLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        if (attackCd  > 0) attackCd--;
        if (shieldTimer > 0) shieldTimer--;
        if (eatTimer  > 0) eatTimer--;
        if (retreatCd > 0) retreatCd--;

        double dist = bot.distanceTo(target);
        float  hp   = bot.getHealth();

        equipArmor();

        // ── Состояния ──────────────────────────────────────────────
        // Переход в RETREATING
        if (hp < RETREAT_HP && retreatCd <= 0) {
            state = State.RETREATING;
            retreatCd = RETREAT_CD;
        }
        // Переход в EATING
        if (hp < EAT_HP && state != State.RETREATING && eatTimer <= 0 && dist > 3.5) {
            state = State.EATING;
            eatTimer = EAT_DUR;
        }
        // Назад в FIGHTING
        if (state == State.EATING && eatTimer <= 0) state = State.FIGHTING;
        if (state == State.RETREATING && dist > RETREAT_DIST) state = State.FIGHTING;

        switch (state) {
            case FIGHTING   -> tickFighting(sw, target, dist, hp);
            case BLOCKING   -> tickBlocking(target, dist);
            case EATING     -> tickEating(sw, target, dist);
            case RETREATING -> tickRetreating(target, dist);
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist, float hp) {
        // Навигация
        if (dist > 2.6) bot.getNavigation().moveTo(target, 1.0);
        else if (dist < 1.8) bot.getNavigation().stop();

        // Страф
        strafe.tick(target);

        // Щит если низкое HP и дальнего урона нет
        if (hp < SHIELD_HP && shieldTimer <= 0) {
            equipShield();
            shieldTimer = SHIELD_DUR;
            state = State.BLOCKING;
            return;
        }

        // Смотрим на цель
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Крит-прыжок каждые CRIT_EVERY ударов
        if (attackCd <= 0 && dist <= MELEE_RANGE) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAttack(sw, target, true);
                critPending = false;
            } else if (!doCrit || critPending) {
                doAttack(sw, target, false);
                critPending = false;
            }
        }
    }

    private void tickBlocking(LivingEntity target, double dist) {
        // Держим щит, медленно отходим
        equipShield();
        if (dist < 2.5) {
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.1);
            Vec3 cur = bot.getDeltaMovement();
            bot.setDeltaMovement(cur.x + away.x, cur.y, cur.z + away.z);
        }
        if (shieldTimer <= 0) {
            state = State.FIGHTING;
            equipSword();
        }
    }

    private void tickEating(ServerLevel sw, LivingEntity target, double dist) {
        // Едим и немного отходим
        if (dist < 4.0) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 4, bot.getY(), bot.getZ() + away.z * 4, 0.9
            );
        }
        // Даём эффект регенерации (симуляция поедания зол. яблока)
        if (eatTimer == EAT_DUR - 1) {
            bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                MobEffects.REGENERATION, 100, 1));
        }
    }

    private void tickRetreating(LivingEntity target, double dist) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * RETREAT_DIST,
            bot.getY(),
            bot.getZ() + away.z * RETREAT_DIST,
            1.2
        );
        bot.setSprinting(true);
    }

    private void doAttack(ServerLevel sw, LivingEntity target, boolean crit) {
        equipSword();
        bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 0.8, target.getZ(), 5, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
    }

    private void equipShield() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    private void equipArmor() {
        if (!bot.getItemBySlot(EquipmentSlot.HEAD).is(Items.NETHERITE_HELMET))
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.NETHERITE_CHESTPLATE))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        if (!bot.getItemBySlot(EquipmentSlot.LEGS).is(Items.NETHERITE_LEGGINGS))
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (!bot.getItemBySlot(EquipmentSlot.FEET).is(Items.NETHERITE_BOOTS))
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }
}
