package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * ComboSystem — система комбо-атак для бота (v12).
 *
 * Комбо — серия ударов с микропаузами между ними,
 * имитирующая игру живого PvP-игрока.
 *
 * Паттерны (выбираются случайно или по режиму):
 *   BURST   — 3-5 быстрых ударов подряд, потом долгая пауза
 *   RHYTHM  — удар, маленькая пауза, удар — равномерный ритм
 *   FEINT   — ложный замах (отход) потом резкий рывок с ударом
 *
 * Интегрируется в BotDifficultyAI и вызывается каждый тик.
 */
public class ComboSystem {

    public enum ComboPattern { BURST, RHYTHM, FEINT }

    // ── Настройки ─────────────────────────────────────────────────
    private static final int BURST_HITS       = 4;   // ударов в BURST
    private static final int BURST_PAUSE      = 30;  // тиков паузы после BURST
    private static final int RHYTHM_INTERVAL  = 8;   // тиков между ударами в RHYTHM
    private static final int FEINT_BACKOFF    = 10;  // тиков отхода при FEINT
    private static final int FEINT_RUSH_SPEED = 2;   // множитель скорости рывка

    // ── Состояние ─────────────────────────────────────────────────
    private ComboPattern pattern   = ComboPattern.RHYTHM;
    private int  hitCount          = 0;
    private int  pauseTimer        = 0;
    private int  rhythmTimer       = 0;
    private boolean feintBackingOff = false;
    private int  feintTimer        = 0;

    private final BotEntity bot;

    public ComboSystem(BotEntity bot) {
        this.bot = bot;
    }

    // ─────────────────────────────────────────────────────────────

    public void setPattern(ComboPattern p) { this.pattern = p; }
    public ComboPattern getPattern()       { return pattern; }

    /**
     * Главный тик. Вызывается из BotDifficultyAI каждый тик при наличии цели.
     * Возвращает true если сейчас нужно нанести удар.
     */
    public boolean tick(LivingEntity target) {
        if (pauseTimer > 0) {
            pauseTimer--;
            return false;
        }

        double dist = bot.distanceTo(target);
        boolean inRange = dist <= PVPBotConfig.INSTANCE.attackRange + 0.5;

        return switch (pattern) {
            case BURST  -> tickBurst(target, inRange);
            case RHYTHM -> tickRhythm(target, inRange);
            case FEINT  -> tickFeint(target, inRange);
            default     -> null;
        };
    }

    /** Сброс состояния (смена цели). */
    public void reset() {
        hitCount = 0;
        pauseTimer = 0;
        rhythmTimer = 0;
        feintBackingOff = false;
        feintTimer = 0;
    }

    // ─────────────────────────────────────────────────────────────
    //  Паттерны
    // ─────────────────────────────────────────────────────────────

    private boolean tickBurst(LivingEntity target, boolean inRange) {
        if (!inRange) return false;

        hitCount++;
        if (hitCount >= BURST_HITS) {
            hitCount = 0;
            pauseTimer = BURST_PAUSE;
            // Уклонение в конце комбо
            applyEvade(target);
            return true; // последний удар комбо
        }
        return true;
    }

    private boolean tickRhythm(LivingEntity target, boolean inRange) {
        if (!inRange) { rhythmTimer = 0; return false; }

        rhythmTimer++;
        if (rhythmTimer >= RHYTHM_INTERVAL) {
            rhythmTimer = 0;
            return true;
        }
        return false;
    }

    private boolean tickFeint(LivingEntity target, boolean inRange) {
        if (feintBackingOff) {
            feintTimer--;
            // Отступаем от цели
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.2);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0, away.z));

            if (feintTimer <= 0) {
                feintBackingOff = false;
                // Рывок вперёд — ускорение к цели
                Vec3 rush = target.position().subtract(bot.position()).normalize().scale(0.4);
                bot.setDeltaMovement(rush.x, bot.getDeltaMovement().y, rush.z);
            }
            return false;
        }

        if (inRange) {
            hitCount++;
            if (hitCount >= 2) {
                // После 2 ударов — фейнт
                hitCount = 0;
                feintBackingOff = true;
                feintTimer = FEINT_BACKOFF;
            }
            return true;
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────
    //  Уклонение после комбо
    // ─────────────────────────────────────────────────────────────

    private void applyEvade(LivingEntity target) {
        // Случайный страф в сторону от цели
        boolean left = bot.level().getRandom().nextBoolean();
        double yawRad = Math.toRadians(bot.getYRot() + (left ? -90 : 90));
        double sx = Math.sin(yawRad) * 0.35;
        double sz = -Math.cos(yawRad) * 0.35;
        bot.setDeltaMovement(sx, bot.getDeltaMovement().y + 0.15, sz);
    }
}
