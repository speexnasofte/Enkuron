package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * W-Tap / S-Tap — сброс кулдауна атаки микродвижением вперёд/назад.
 *
 * Механика:
 *   За 1 тик до удара — отпускаем forward (W), что сбрасывает скорость
 *   и иногда позволяет заново набрать кулдаун атаки чуть быстрее.
 *   Сразу после удара — зажимаем forward снова.
 *
 *   S-Tap: на 1 тик зажимаем back после удара (быстрый откат).
 *   Это снижает входящий knockback и даёт время для следующего удара.
 *
 * Вызывается из PVPBotLogic.tick() при autoAttack.
 */
public class WTapLogic {
    private static void setKeyDown(net.minecraft.client.KeyMapping key, boolean down) {
        try {
            var f = net.minecraft.client.KeyMapping.class.getDeclaredField("isDown");
            f.setAccessible(true);
            f.set(key, down);
        } catch (Exception ignored) {}
    }


    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int wTapPhase  = 0; // 0 = ждём, 1 = W отпущен, 2 = S-tap
    private int phaseTimer = 0;

    /**
     * Вызывать ПОСЛЕ успешного удара по цели.
     * Запускает W-tap / S-tap последовательность.
     */
    public void onAttack(Minecraft client) {
        if (!cfg.wTapEnabled) return;
        wTapPhase  = 1;
        phaseTimer = cfg.wTapReleaseTicks; // обычно 1-2 тика
        setKeyDown(client.options.keyUp, false);
        if (cfg.sTapEnabled) {
            setKeyDown(client.options.keyDown, true);
        }
    }

    /**
     * Тик W-tap: вызывать каждый тик из PVPBotLogic перед основным движением.
     * @return true если W-tap сейчас управляет клавишами (не трогать forward!)
     */
    public boolean tick(Minecraft client) {
        if (!cfg.wTapEnabled || wTapPhase == 0) return false;

        phaseTimer--;
        if (phaseTimer <= 0) {
            if (wTapPhase == 1) {
                // Фаза 2: отпускаем S, возвращаем W
                setKeyDown(client.options.keyDown, false);
                wTapPhase = 0;
            }
        }
        return wTapPhase > 0;
    }

    public void reset(Minecraft client) {
        wTapPhase = 0;
        setKeyDown(client.options.keyDown, false);
    }
}
