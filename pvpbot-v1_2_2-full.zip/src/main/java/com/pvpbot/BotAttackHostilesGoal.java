package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;

/**
 * Бот атакует враждебных мобов (зомби, скелеты и т.д.) в режимах GUARD и AGGRESSIVE.
 */
public class BotAttackHostilesGoal extends NearestAttackableTargetGoal<Monster> {

    private final BotEntity bot;

    public BotAttackHostilesGoal(BotEntity bot) {
        super(bot, Monster.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canUse() {
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        return super.canUse();
    }
}
