package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

/**
 * BotNotifier — единая система уведомлений бота в чат владельца.
 *
 * ══════════════════════════════════════════════════════════════
 *  Все события бота проходят через этот класс:
 *    - Нашёл цель
 *    - Убил игрока
 *    - Умер
 *    - Низкое HP
 *    - Combo-прерыватель активировался
 *    - Smash-атака (Mace/MaceElytra)
 *    - Произвольное сообщение
 *
 *  Защита от спама: каждое событие имеет cooldown в тиках.
 *  Формат: §6[Bot §e<имя бота>§6] §<цвет><сообщение>
 * ══════════════════════════════════════════════════════════════
 *
 * Использование:
 *   BotNotifier.get(bot).notify(BotNotifier.Event.KILL, target);
 *   BotNotifier.get(bot).send("§aПривет!");
 */
public class BotNotifier {

    // ── Типы событий ──────────────────────────────────────────────
    public enum Event {
        TARGET_FOUND   (40,  "§e⚔ Цель: §f%s"),
        KILL           (0,   "§a✔ Убил §f%s §7(%.1f HP осталось у меня)"),
        DEATH          (0,   "§c✘ Я умер! Убийца: §f%s"),
        LOW_HP         (100, "§c⚠ Низкое HP: §f%.0f/%.0f"),
        COMBO_BREAK    (60,  "§e⚡ Combo Break! Разрываю дистанцию"),
        SMASH          (0,   "§6⚒ Smash! §c%.1f урона §7(speed: %.2f)"),
        TARGET_LOST    (60,  "§7✦ Цель потеряна"),
        RETREAT        (80,  "§e↩ Отступаю (HP < %.0f)"),
        MODE_CHANGE    (0,   "§b▶ Режим: §f%s"),
        PEARL_ESCAPE   (80,  "§d⬛ Перл-отрыв!"),
        CUSTOM         (0,   "%s");

        public final int cooldownTicks;
        public final String format;

        Event(int cooldownTicks, String format) {
            this.cooldownTicks = cooldownTicks;
            this.format        = format;
        }
    }

    // ── Состояние ─────────────────────────────────────────────────
    private final BotEntity bot;
    private final int[]     cooldowns = new int[Event.values().length];

    // Синглтон на бота (хранится в BotEntity через поле)
    private BotNotifier(BotEntity bot) {
        this.bot = bot;
    }

    /** Получить notifier для бота. */
    public static BotNotifier of(BotEntity bot) {
        // BotEntity держит ссылку через поле notifier (инициализируется там)
        return bot.getNotifier();
    }

    /** Тикаем кулдауны. Вызывать из BotEntity.tick(). */
    public void tick() {
        for (int i = 0; i < cooldowns.length; i++) {
            if (cooldowns[i] > 0) cooldowns[i]--;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /**
     * Отправить событие с аргументами (String.format-стиль).
     * Соблюдает cooldown.
     */
    public void notify(Event event, Object... args) {
        if (!PVPBotConfig.INSTANCE.notificationsEnabled) return;
        int idx = event.ordinal();
        if (cooldowns[idx] > 0) return;
        cooldowns[idx] = event.cooldownTicks;

        String msg = String.format(event.format, args);
        send(msg);
    }

    /** Отправить произвольное сообщение без cooldown. */
    public void send(String coloredMessage) {
        if (!PVPBotConfig.INSTANCE.notificationsEnabled) return;
        Player owner = bot.getOwner();
        if (!(owner instanceof ServerPlayer sp)) return;

        String botName = bot.getName().getString();
        String prefix  = "§6[Bot §e" + botName + "§6] ";
        sp.sendSystemMessage(Component.literal(prefix + coloredMessage));
    }

    /** Короткий хелпер: уведомление о находке цели. */
    public void onTargetFound(LivingEntity target) {
        notify(Event.TARGET_FOUND, target.getName().getString());
    }

    /** Уведомление о убийстве. */
    public void onKill(LivingEntity killed) {
        String name = killed != null ? killed.getName().getString() : "цель";
        notify(Event.KILL, name, bot.getHealth());
    }

    /** Уведомление о смерти бота. */
    public void onDeath(LivingEntity killer) {
        String killerName = killer != null ? killer.getName().getString() : "неизвестно";
        notify(Event.DEATH, killerName);
    }

    /** Уведомление о низком HP. */
    public void onLowHp() {
        notify(Event.LOW_HP, bot.getHealth(), bot.getMaxHealth());
    }

    /** Уведомление о Combo Break. */
    public void onComboBreak() {
        notify(Event.COMBO_BREAK);
    }

    /** Уведомление о Smash-атаке (Mace/MaceElytra). */
    public void onSmash(float damage, double speed) {
        notify(Event.SMASH, damage, speed);
    }

    /** Уведомление о потере цели. */
    public void onTargetLost() {
        notify(Event.TARGET_LOST);
    }

    /** Уведомление об отступлении. */
    public void onRetreat() {
        notify(Event.RETREAT, bot.getHealth());
    }

    /** Уведомление о смене режима. */
    public void onModeChange(String modeName) {
        notify(Event.MODE_CHANGE, modeName);
    }

    // ── Фабрика (вызывается из BotEntity конструктора) ────────────
    public static BotNotifier create(BotEntity bot) {
        return new BotNotifier(bot);
    }
}
