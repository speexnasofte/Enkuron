package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;

import java.util.*;

/**
 * SquadManager v2.0 — умный командир с расширенными приказами.
 *
 * НОВЫЕ ПРИКАЗЫ v2.0:
 *   SURROUND  — окружить цель со всех сторон
 *   FOCUS     — все солдаты бьют одну цель (фокус)
 *   HEAL      — прикрыть раненого солдата
 *   COVER     — 2 прикрывают владельца, остальные атакуют
 *   PUSH      — синхронная волна — все одновременно на цель
 *   BAIT      — командир приманивает, солдаты заходят с тыла
 *   SPLIT     — 2 группы против 2 разных врагов
 *
 * AI v2.0:
 *   - Анализирует HP всех солдат и HP владельца
 *   - Считает количество врагов и выбирает тактику
 *   - Реагирует на потери немедленно
 *   - Кулдаун смены приказа (не мечется)
 *   - PUSH-таймер: синхронная волна на 2 секунды, потом ATTACK
 */
public class SquadManager {

    public static final SquadManager INSTANCE = new SquadManager();

    public static final double COMMANDER_FRONT_DIST = 3.0;
    public static final double FIRST_RANK_DIST      = 2.5;
    public static final double SPACING              = 2.2;
    public static final int    MAX_SQUAD_SIZE       = 30;
    public static final double ALERT_RANGE          = 24.0;
    public static final int    THINK_INTERVAL       = 30;

    private static final float RETREAT_HP     = 8.0f;
    private static final float OWNER_COVER_HP = 12.0f;
    private static final float SOLDIER_LOW_HP = 10.0f;

    public enum CommanderOrder {
        STAND, ATTACK, RETREAT, FLANK,
        SURROUND, FOCUS, HEAL, COVER, PUSH, BAIT, SPLIT
    }

    public static class Squad {
        public final String name;
        public BotEntity commander;
        public final List<BotEntity> soldiers = new ArrayList<>();
        public CommanderOrder currentOrder    = CommanderOrder.STAND;

        int thinkTimer     = 0;
        int orderCooldown  = 0;
        int pushTimer      = 0;
        public LivingEntity lastTarget  = null;
        public LivingEntity secondTarget = null;
        int lastAliveCount = 0;

        public Squad(String name) { this.name = name; }

        public int size() { return (commander != null ? 1 : 0) + soldiers.size(); }

        public List<BotEntity> allBots() {
            List<BotEntity> all = new ArrayList<>();
            if (commander != null) all.add(commander);
            all.addAll(soldiers);
            return all;
        }

        public long aliveSoldiers() {
            return soldiers.stream().filter(b -> !b.isRemoved() && b.isAlive()).count();
        }

        public BotEntity getMostWounded() {
            return soldiers.stream()
                .filter(b -> !b.isRemoved() && b.isAlive())
                .min(Comparator.comparingDouble(BotEntity::getHealth))
                .orElse(null);
        }
    }

    private final Map<UUID, Squad> squadByOwner = new HashMap<>();
    private SquadManager() {}

    // ── API ───────────────────────────────────────────────────────

    public Squad getOrCreate(ServerPlayer owner, String name) {
        return squadByOwner.computeIfAbsent(owner.getUUID(), k -> new Squad(name));
    }

    public Squad getSquad(ServerPlayer owner) {
        return squadByOwner.get(owner.getUUID());
    }

    public void disband(ServerPlayer owner) {
        squadByOwner.remove(owner.getUUID());
    }

    public void assignBots(ServerPlayer owner, List<BotEntity> bots) {
        if (bots.isEmpty()) return;
        Squad squad = getOrCreate(owner, "Squad-1");
        squad.commander = null;
        squad.soldiers.clear();
        int count = Math.min(bots.size(), MAX_SQUAD_SIZE);
        for (int i = 0; i < count; i++) {
            if (i == 0) { squad.commander = bots.get(i); markAsCommander(bots.get(i)); }
            else         { squad.soldiers.add(bots.get(i)); markAsSoldier(bots.get(i), i); }
        }
        squad.lastAliveCount = (int) squad.aliveSoldiers();

        // ── Счётчик потерь ──────────────────────────────────────
        CasualtyTracker.INSTANCE.startBattle(squad, PVPBotConfig.INSTANCE.mode.name());

        // ── Роли: если отряд >= 20 бойцов — назначаем специализации
        if (squad.size() >= 20) {
            BotRole.autoAssign(squad.soldiers, PVPBotConfig.INSTANCE.roleConfig);
            // Командир тоже получает кит элиты (топор)
            if (squad.commander != null) {
                squad.commander.setSquadRole(BotRole.ELITE);
                BotKit.AXE.equipment.applyTo(squad.commander);
            }
        }
    }

    private void markAsCommander(BotEntity bot) {
        if (PVPBotConfig.INSTANCE.difficulty == PVPBotConfig.Difficulty.PLAYER) {
            bot.setCustomNameVisible(false);
        } else {
            bot.setCustomName(Component.literal("§c⚔ Командир"));
            bot.setCustomNameVisible(true);
        }
    }

    private void markAsSoldier(BotEntity bot, int rank) {
        if (PVPBotConfig.INSTANCE.difficulty == PVPBotConfig.Difficulty.PLAYER) {
            bot.setCustomNameVisible(false);
        } else {
            bot.setCustomName(Component.literal("§7Солдат §f#" + rank));
            bot.setCustomNameVisible(true);
        }
    }

    // ── Позиционирование ─────────────────────────────────────────

    public Vec3 getSquadPos(BotEntity bot, Player owner, Squad squad) {
        Vec3 ownerPos = owner.position();
        double rad = Math.toRadians(owner.getYRot());
        double fwdX =  Math.sin(rad), fwdZ = -Math.cos(rad);
        double bkX  = -fwdX,          bkZ  = -fwdZ;
        double rtX  =  Math.cos(rad), rtZ  =  Math.sin(rad);

        if (bot == squad.commander)
            return ownerPos.add(fwdX * COMMANDER_FRONT_DIST, 0, fwdZ * COMMANDER_FRONT_DIST);

        int idx = squad.soldiers.indexOf(bot);
        if (idx < 0) return ownerPos;

        Vec3 cmdPos  = ownerPos.add(fwdX * COMMANDER_FRONT_DIST, 0, fwdZ * COMMANDER_FRONT_DIST);
        Vec3 base    = cmdPos.add(bkX * FIRST_RANK_DIST, 0, bkZ * FIRST_RANK_DIST);
        int  row     = idx / 2;
        int  side    = (idx % 2 == 0) ? -1 : 1;
        double col   = side * ((row + 1) * SPACING / 2.0);
        double rowOff = row * SPACING * 0.5;
        return base.add(rtX * col + bkX * rowOff, 0, rtZ * col + bkZ * rowOff);
    }

    // ── AI Командира ──────────────────────────────────────────────

    public void tickCommander(BotEntity commander, Squad squad, Player owner) {
        if (commander == null || squad == null) return;

        // ── v7.0: CommanderAI + CasualtyTracker + WaveDefense ────
        if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
            if (PVPBotConfig.INSTANCE.commanderAdaptEnabled)
                CommanderAI.INSTANCE.tick(squad, sp);
            CasualtyTracker.INSTANCE.tick(squad, sp);
            if (WaveDefense.INSTANCE.isActive())
                WaveDefense.INSTANCE.tick(sp, squad);
        }

        // Реагируем на потери солдат сразу
        int nowAlive = (int) squad.aliveSoldiers();
        if (nowAlive < squad.lastAliveCount) { squad.thinkTimer = 0; }
        squad.lastAliveCount = nowAlive;

        if (squad.orderCooldown > 0) squad.orderCooldown--;

        // PUSH-таймер
        if (squad.currentOrder == CommanderOrder.PUSH) {
            squad.pushTimer--;
            if (squad.pushTimer <= 0)
                executeChange(squad, CommanderOrder.ATTACK, commander, owner);
        }

        squad.thinkTimer--;
        if (squad.thinkTimer > 0) return;
        squad.thinkTimer = THINK_INTERVAL;

        CommanderOrder newOrder = decide(commander, squad, owner);
        if (newOrder != squad.currentOrder && squad.orderCooldown <= 0)
            executeChange(squad, newOrder, commander, owner);
    }

    private void executeChange(Squad squad, CommanderOrder order,
                               BotEntity commander, Player owner) {
        squad.currentOrder = order;
        squad.orderCooldown = 25;
        broadcastOrder(commander, squad, owner, order);
        applyOrderToSoldiers(squad, order, owner);
    }

    private CommanderOrder decide(BotEntity commander, Squad squad, Player owner) {
        float cmdHP  = commander.getHealth();
        long  alive  = squad.aliveSoldiers();
        int   total  = squad.soldiers.size();
        float ownerHP = owner.getHealth();

        // Критические ситуации
        if (cmdHP < RETREAT_HP) return CommanderOrder.RETREAT;
        if (ownerHP < OWNER_COVER_HP && alive >= 2) return CommanderOrder.COVER;
        if (total > 0 && alive < total / 2 && alive <= 2) return CommanderOrder.RETREAT;

        List<LivingEntity> enemies = findEnemies(commander, ALERT_RANGE);
        if (enemies.isEmpty()) { squad.lastTarget = null; squad.secondTarget = null; return CommanderOrder.STAND; }

        squad.lastTarget = enemies.get(0);
        double dist = commander.distanceTo(squad.lastTarget);

        // Раненый солдат — выделить охрану
        BotEntity wounded = squad.getMostWounded();
        if (wounded != null && wounded.getHealth() < SOLDIER_LOW_HP && alive >= 3)
            return CommanderOrder.HEAL;

        // Несколько врагов + много солдат
        if (enemies.size() >= 2 && alive >= 4) {
            squad.secondTarget = enemies.get(1);
            return CommanderOrder.SPLIT;
        }

        // Один враг
        if (dist > 12.0 && alive >= 3) {
            squad.pushTimer = 40;
            return CommanderOrder.PUSH;
        }
        if (isEnemyFacingAway(commander, squad.lastTarget) && alive >= 2)
            return CommanderOrder.BAIT;
        if (alive >= 4) return CommanderOrder.SURROUND;
        if (alive >= 2 && isFlankOpportunity(commander, squad.lastTarget))
            return CommanderOrder.FLANK;
        return CommanderOrder.ATTACK;
    }

    // ── Применение приказов ───────────────────────────────────────

    public void applyOrderToSoldiers(Squad squad, CommanderOrder order, Player owner) {
        List<BotEntity> alive = squad.soldiers.stream()
            .filter(b -> !b.isRemoved() && b.isAlive()).toList();

        switch (order) {

            case STAND -> {
                alive.forEach(s -> { s.setTarget(null); s.getNavigation().stop(); });
                PVPBotConfig.INSTANCE.standbyMode = true;
            }

            case ATTACK -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                for (BotEntity s : alive) {
                    if (squad.lastTarget != null && !squad.lastTarget.isRemoved()) {
                        s.setTarget(squad.lastTarget);
                        s.getTargetPriority().setForcedTarget(squad.lastTarget.getUUID());
                    }
                }
            }

            case RETREAT -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                Vec3 ownerPos = owner.position();
                alive.forEach(s -> { s.setTarget(null); s.getNavigation().moveTo(ownerPos.x, ownerPos.y, ownerPos.z, 1.4); });
            }

            case FLANK -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                if (squad.lastTarget != null)
                    SmartFlank.INSTANCE.startFlank(squad.soldiers, squad.lastTarget);
            }

            case SURROUND -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                if (squad.lastTarget == null) break;
                Vec3 ep = squad.lastTarget.position();
                int n = alive.size();
                for (int i = 0; i < n; i++) {
                    double ang = (2 * Math.PI / n) * i;
                    alive.get(i).getNavigation().moveTo(
                        ep.x + Math.cos(ang) * 3.5, ep.y, ep.z + Math.sin(ang) * 3.5, 1.3);
                    alive.get(i).setTarget(squad.lastTarget);
                }
            }

            case FOCUS -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                for (BotEntity s : alive) {
                    if (squad.lastTarget != null) {
                        s.setTarget(squad.lastTarget);
                        s.getTargetPriority().setForcedTarget(squad.lastTarget.getUUID());
                        s.getNavigation().moveTo(squad.lastTarget, 1.4);
                    }
                }
            }

            case HEAL -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                BotEntity wounded = squad.getMostWounded();
                if (wounded == null) break;
                Vec3 safe = owner.position();
                for (int i = 0; i < alive.size(); i++) {
                    BotEntity s = alive.get(i);
                    if (i < 2) {
                        // Охрана раненого
                        s.setTarget(null);
                        s.getNavigation().moveTo(wounded.getX(), wounded.getY(), wounded.getZ(), 1.2);
                    } else {
                        if (squad.lastTarget != null) s.setTarget(squad.lastTarget);
                    }
                }
                // Раненый — к владельцу
                wounded.setTarget(null);
                wounded.getNavigation().moveTo(safe.x, safe.y, safe.z, 1.3);
            }

            case COVER -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                Vec3 ownerPos = owner.position();
                for (int i = 0; i < alive.size(); i++) {
                    BotEntity s = alive.get(i);
                    if (i < 2) {
                        s.setTarget(null);
                        s.getNavigation().moveTo(ownerPos.x, ownerPos.y, ownerPos.z, 1.3);
                        // Если враг близко к владельцу — бьём его
                        if (squad.lastTarget != null && owner.distanceTo(squad.lastTarget) < 5.0)
                            s.setTarget(squad.lastTarget);
                    } else {
                        if (squad.lastTarget != null) {
                            s.setTarget(squad.lastTarget);
                            s.getTargetPriority().setForcedTarget(squad.lastTarget.getUUID());
                        }
                    }
                }
            }

            case PUSH -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                for (BotEntity s : alive) {
                    if (squad.lastTarget != null) {
                        s.setTarget(squad.lastTarget);
                        s.setSprinting(true);
                        s.getNavigation().moveTo(squad.lastTarget, 1.6);
                    }
                }
            }

            case BAIT -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                if (squad.lastTarget == null) break;
                Vec3 cmdPos   = squad.commander != null ? squad.commander.position() : owner.position();
                Vec3 ep       = squad.lastTarget.position();
                Vec3 dir      = ep.subtract(cmdPos).normalize();
                Vec3 behind   = ep.add(dir.scale(3.5));
                for (int i = 0; i < alive.size(); i++) {
                    double side = (i % 2 == 0 ? 1 : -1) * (i / 2 + 1) * 1.2;
                    Vec3 dest   = behind.add(-dir.z * side, 0, dir.x * side);
                    alive.get(i).getNavigation().moveTo(dest.x, dest.y, dest.z, 1.4);
                    alive.get(i).setTarget(squad.lastTarget);
                }
            }

            case SPLIT -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                int half = alive.size() / 2;
                for (int i = 0; i < alive.size(); i++) {
                    LivingEntity tgt = (i < half || squad.secondTarget == null)
                        ? squad.lastTarget : squad.secondTarget;
                    if (tgt != null && !tgt.isRemoved()) {
                        alive.get(i).setTarget(tgt);
                        alive.get(i).getTargetPriority().setForcedTarget(tgt.getUUID());
                    }
                }
            }
            default: break;
        }
    }

    // ── Чат сообщения ─────────────────────────────────────────────

    private void broadcastOrder(BotEntity commander, Squad squad, Player owner, CommanderOrder order) {
        if (!(owner instanceof ServerPlayer sp)) return;
        long alive = squad.aliveSoldiers();
        String msg = switch (order) {
            case STAND    -> "§7[Командир] §fДержать позицию.";
            case ATTACK   -> "§c[Командир] §fАтакуем! Вперёд!";
            case RETREAT  -> "§e[Командир] §fОтступаем к командиру!";
            case FLANK    -> "§b[Командир] §fФланк! Обходим с фланга!";
            case SURROUND -> "§d[Командир] §fОкружаем! Берём в кольцо!";
            case FOCUS    -> "§4[Командир] §fФокус! Все на одну цель!";
            case HEAL     -> "§a[Командир] §fПрикрыть раненого! Двое — охрана!";
            case COVER    -> "§6[Командир] §fПрикрыть командира! §e" + alive + " §6в бой!";
            case PUSH     -> "§c§l[Командир] §r§cВолна! Все на прорыв!";
            case BAIT     -> "§5[Командир] §fПриманка! Захожу с фронта, обходите с тыла!";
            case SPLIT    -> "§3[Командир] §fРазделиться! Группа 1 и 2 — разные цели!";
            default     -> "?";
        };
        sp.sendSystemMessage(Component.literal(msg));
    }

    // ── Принудительный приказ от игрока ──────────────────────────

    public void issueOrder(ServerPlayer owner, CommanderOrder order) {
        Squad squad = getSquad(owner);
        if (squad == null) return;
        squad.currentOrder  = order;
        squad.orderCooldown = 0;
        broadcastOrder(squad.commander, squad, owner, order);
        applyOrderToSoldiers(squad, order, owner);
    }

    // ── Helpers ───────────────────────────────────────────────────

    private List<LivingEntity> findEnemies(BotEntity bot, double range) {
        if (bot.level() == null) return List.of();
        UUID ownerUUID = bot.getOwnerUUID();
        return bot.level().getEntitiesOfClass(
            net.minecraft.world.entity.player.Player.class,
            bot.getBoundingBox().inflate(range),
            p -> {
                if (!(p instanceof ServerPlayer sp)) return false;
                if (ownerUUID != null && sp.getUUID().equals(ownerUUID)) return false;
                return !sp.isSpectator() && !sp.isCreative();
            }
        ).stream().map(e -> (LivingEntity) e)
         .sorted(Comparator.comparingDouble(e -> e.distanceTo(bot))).toList();
    }

    private boolean isEnemyFacingAway(BotEntity bot, LivingEntity enemy) {
        Vec3 toBot = bot.position().subtract(enemy.position()).normalize();
        return toBot.dot(enemy.getLookAngle()) < -0.4;
    }

    private boolean isFlankOpportunity(BotEntity bot, LivingEntity enemy) {
        Vec3 toBot = bot.position().subtract(enemy.position()).normalize();
        return toBot.dot(enemy.getLookAngle()) < -0.5;
    }

    public boolean isCommander(BotEntity bot) {
        for (Squad s : squadByOwner.values()) if (bot == s.commander) return true;
        return false;
    }

    public Squad getSquadOf(BotEntity bot) {
        for (Squad s : squadByOwner.values())
            if (bot == s.commander || s.soldiers.contains(bot)) return s;
        return null;
    }

    public Map<UUID, Squad> getAllSquads() {
        return Collections.unmodifiableMap(squadByOwner);
    }
}
