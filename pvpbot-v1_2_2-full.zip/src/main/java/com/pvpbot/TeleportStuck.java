package com.pvpbot;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * TeleportStuck — v8: новая функция.
 *
 * Если StuckDetector сообщает что бот застрял дольше cfg.teleportStuckTicks тиков —
 * телепортируем его к владельцу вместо бесконечного ожидания pathfind.
 *
 * Интеграция: вызывается из BotEntity.tick() после stuckDetector.tick().
 *
 * Условия телепорта:
 *  1. cfg.teleportIfStuck = true
 *  2. Владелец онлайн
 *  3. StuckDetector.getStuckTicks() > cfg.teleportStuckTicks
 *  4. Бот не в бою (нет цели) — не прерываем бой телепортом
 *
 * После телепорта выводит сообщение владельцу.
 */
public class TeleportStuck {

    public static final TeleportStuck INSTANCE = new TeleportStuck();

    private TeleportStuck() {}

    /**
     * Вызывать из BotEntity.tick() после stuckDetector.tick().
     * @return true если телепортировал (бот телепортирован, дальнейший тик прерывать не нужно)
     */
    public boolean tick(BotEntity bot) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.teleportIfStuck) return false;

        // Не телепортируем во время боя
        if (bot.getTarget() != null && bot.getTarget().isAlive()) return false;

        StuckDetector sd = bot.getStuckDetector();
        if (sd.getStuckTicks() < cfg.teleportStuckTicks) return false;

        Player owner = bot.getOwner();
        if (owner == null) return false;

        // Телепортируем рядом с владельцем (1 блок в сторону)
        double tpX = owner.getX() + 1.0;
        double tpY = owner.getY();
        double tpZ = owner.getZ() + 1.0;
        bot.teleportTo(tpX, tpY, tpZ);
        bot.getNavigation().stop();

        // Уведомляем владельца
        if (owner instanceof ServerPlayer sp) {
            sp.sendSystemMessage(Component.literal(
                "§e[PVPBot] §fБот застрял и телепортирован к тебе."
            ));
        }
        return true;
    }
}
