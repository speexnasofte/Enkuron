package com.pvpbot;

import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

/**
 * Регистрация типа сущности бота.
 */
public class BotEntityType {

    public static final EntityType<BotEntity> BOT_ENTITY;

    static {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("pvpbot", "pvp_bot");
        ResourceKey<EntityType<?>> key = ResourceKey.create(
            net.minecraft.core.registries.Registries.ENTITY_TYPE, id);
        BOT_ENTITY = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            key,
            EntityType.Builder.<BotEntity>of(BotEntity::new, MobCategory.MISC)
                .sized(0.6f, 1.95f)
                .build(key)
        );
    }

    public static void register() {
        // Вызов этого метода инициализирует static-блок
    }
}
