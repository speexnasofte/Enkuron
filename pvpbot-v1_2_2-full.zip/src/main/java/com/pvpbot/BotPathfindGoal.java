package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * BotPathfindGoal v3.0 — УМНЫЙ pathfinding.
 *
 * ИСПРАВЛЕНО:
 *   - Телепорт только при > 64 блоков (не 48)
 *   - unstuck: сначала 3 попытки прыжка, потом телепорт
 *   - jump-assist: плавный — только если нет пути вперёд
 *   - Не обновляем путь каждые 10 тиков (вызывает рывки)
 *     — обновляем только если цель сильно переместилась
 *   - Formations: корректно берём смещение
 *   - Спринт: включаем только при dist > 6 (не всегда)
 */
public class BotPathfindGoal extends Goal {

    private final BotEntity bot;
    private final double    speed;
    private final float     maxDist;
    private final float     minDist;

    private Player owner;

    // Unstuck
    private Vec3    lastPos       = null;
    private int     stuckTimer    = 0;
    private int     jumpAttempts  = 0;
    private static final int STUCK_THRESHOLD = 20;  // было 35 — быстрее реагируем
    private static final int MAX_JUMP_TRIES  = 2;   // было 3 — быстрее телепортируем

    // Последняя позиция цели для перепрокладки пути
    private Vec3    lastOwnerPos  = null;
    private int     jumpCooldown  = 0;

    public BotPathfindGoal(BotEntity bot, double speed, float maxDist, float minDist) {
        this.bot     = bot;
        this.speed   = speed;
        this.maxDist = maxDist;
        this.minDist = minDist;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override public boolean canUse() {
        if (bot.getTarget() != null) return false;
        owner = bot.getOwner();
        return owner != null && owner.distanceToSqr(bot) > (minDist * minDist);
    }

    @Override public boolean canContinueToUse() {
        if (bot.getTarget() != null) return false;
        if (owner == null) return false;
        double d = owner.distanceToSqr(bot);
        return d > (minDist * minDist) && d < (maxDist * 20 * maxDist * 20);
    }

    @Override public void start() {
        stuckTimer   = 0;
        jumpAttempts = 0;
        lastPos      = bot.position();
        lastOwnerPos = owner != null ? owner.position() : null;
        navigate();
    }

    @Override public void stop() {
        bot.getNavigation().stop();
    }

    @Override public void tick() {
        if (owner == null) return;
        bot.getLookControl().setLookAt(owner, 10f, bot.getMaxHeadXRot());
        if (jumpCooldown > 0) jumpCooldown--;

        double dist = bot.distanceTo(owner);

        // Спринт только если далеко (не рядом с владельцем)
        if (dist > 6.0 && !bot.isSprinting())  bot.setSprinting(true);
        if (dist < 4.0 && bot.isSprinting())   bot.setSprinting(false);

        // Перепрокладываем путь только если владелец сильно сместился (> 2 блока)
        Vec3 ownerPos = owner.position();
        if (lastOwnerPos == null || ownerPos.distanceToSqr(lastOwnerPos) > 4.0) {
            navigate();
            lastOwnerPos = ownerPos;
        }

        // Jump-assist
        if (jumpCooldown <= 0 && bot.onGround()) {
            tickJumpAssist();
        }

        // Unstuck
        Vec3 curr = bot.position();
        if (lastPos != null) {
            double moved = curr.distanceToSqr(lastPos);
            if (moved < 0.005) {
                stuckTimer++;
                if (stuckTimer > STUCK_THRESHOLD) {
                    unstuck();
                    stuckTimer = 0;
                }
            } else {
                stuckTimer   = 0;
                jumpAttempts = 0;
            }
        }
        lastPos = curr;
    }

    private void navigate() {
        if (owner == null) return;
        double dist = bot.distanceTo(owner);

        Vec3 target = BotFormations.INSTANCE.getTargetPos(bot, 0, 1, owner);

        if (dist > 64.0) {
            bot.teleportTo(target.x, target.y, target.z);
        } else {
            bot.getNavigation().moveTo(target.x, target.y, target.z, speed);
        }
    }

    /**
     * Прыгаем через 1-блочное препятствие впереди.
     * Проверяем ноги И голову чтобы не застрять.
     */
    private void tickJumpAssist() {
        Vec3 vel = bot.getDeltaMovement();
        // Также учитываем направление навигации если velocity = 0
        Vec3 dir;
        if (vel.horizontalDistanceSqr() > 0.001) {
            dir = new Vec3(vel.x, 0, vel.z).normalize();
        } else if (owner != null) {
            dir = owner.position().subtract(bot.position()).multiply(1, 0, 1).normalize();
        } else {
            return;
        }

        Level world = bot.level();

        // Проверяем блок на уровне ног и головы на 0.7 блока вперёд
        BlockPos aheadFoot = BlockPos.containing(
            bot.getX() + dir.x * 0.7,
            bot.getY() + 0.1,
            bot.getZ() + dir.z * 0.7
        );
        BlockPos aheadHead = aheadFoot.above();
        BlockPos aboveHead = aheadFoot.above(2);

        BlockState stFoot = world.getBlockState(aheadFoot);
        BlockState stHead = world.getBlockState(aheadHead);
        BlockState stAbove = world.getBlockState(aboveHead);

        // Прыгаем только если: ноги заблокированы, голова свободна, над головой свободно
        boolean footBlocked = stFoot.isSolid() && !stFoot.isAir();
        boolean headFree    = stHead.isAir() || !stHead.isSolid();
        boolean aboveFree   = stAbove.isAir() || !stAbove.isSolid();

        if (footBlocked && headFree && aboveFree) {
            bot.getJumpControl().jump();
            jumpCooldown = 10;
        }
    }

    /**
     * Unstuck: 3 попытки прыжка, потом телепорт.
     */
    private void unstuck() {
        if (owner == null) return;

        if (jumpAttempts < MAX_JUMP_TRIES) {
            // Прыжок с толчком к владельцу
            Vec3 toOwner = owner.position().subtract(bot.position()).normalize();
            bot.setDeltaMovement(toOwner.x * 0.3, 0.5, toOwner.z * 0.3);
            bot.getJumpControl().jump();
            jumpAttempts++;
        } else {
            // Телепорт рядом с владельцем
            double angle = bot.level().getRandom().nextDouble() * Math.PI * 2;
            double r = 1.5;
            bot.teleportTo(
                owner.getX() + Math.cos(angle) * r,
                owner.getY(),
                owner.getZ() + Math.sin(angle) * r
            );
            jumpAttempts = 0;
        }
        navigate();
    }
}
