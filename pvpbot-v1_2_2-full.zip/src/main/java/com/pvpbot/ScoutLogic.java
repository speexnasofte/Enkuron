package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * ScoutLogic — поведение роли SCOUT (Разведчик).
 *
 * Разведчик:
 *  - Движется быстро, использует элитры
 *  - Сканирует врагов в радиусе SCAN_RANGE
 *  - Каждые REPORT_INTERVAL тиков пишет координаты врагов в чат
 *  - Не вступает в ближний бой, только убегает
 *  - При обнаружении врага — командует отряду ATTACK на эту цель
 *
 * Вызывается из BotEntity.tick() если bot.getSquadRole() == SCOUT.
 */
public class ScoutLogic {

    public static final ScoutLogic INSTANCE = new ScoutLogic();

    private static final double SCAN_RANGE      = 64.0;
    private static final double FLEE_RANGE      = 6.0;    // ближе → убежать
    private static final int    REPORT_INTERVAL = 100;    // тиков между репортами (5 сек)
    private static final int    PATROL_RADIUS   = 32;     // радиус патруля

    private ScoutLogic() {}

    public void tick(BotEntity bot, Player owner) {
        if (!(bot.level() instanceof ServerLevel level)) return;

        if (bot.scoutReportTimer > 0) bot.scoutReportTimer--;

        // Сканируем врагов
        List<Player> enemies = scanEnemies(bot, level, owner);

        if (!enemies.isEmpty()) {
            Player nearest = enemies.get(0);
            double dist = bot.distanceTo(nearest);

            // Убегать если враг близко
            if (dist < FLEE_RANGE) {
                fleFrom(bot, nearest);
                return;
            }

            // Репорт в чат
            if (bot.scoutReportTimer <= 0) {
                reportEnemies(bot, owner, enemies, level);
                bot.scoutReportTimer = REPORT_INTERVAL;

                // Скомандовать отряду атаковать
                SquadManager.Squad squad = getSquad(bot, owner);
                if (squad != null && squad.currentOrder == SquadManager.CommanderOrder.STAND) {
                    squad.currentOrder = SquadManager.CommanderOrder.ATTACK;
                    squad.lastTarget   = nearest;
                }
            }

            // Держаться на безопасной дистанции
            keepSafeDistance(bot, nearest);
        } else {
            // Патрулировать
            patrol(bot, owner);
        }
    }

    // ── Сканирование ─────────────────────────────────────────────

    private List<Player> scanEnemies(BotEntity bot, ServerLevel level, Player owner) {
        AABB box = bot.getBoundingBox().inflate(SCAN_RANGE);
        List<Player> players = level.getEntitiesOfClass(Player.class, box,
            p -> p != owner && !p.isSpectator() && !p.isCreative() && p.isAlive());
        // Сортируем по дистанции
        players.sort((a, b) -> Double.compare(bot.distanceTo(a), bot.distanceTo(b)));
        return players;
    }

    // ── Репорт ────────────────────────────────────────────────────

    private void reportEnemies(BotEntity bot, Player owner, List<Player> enemies, ServerLevel level) {
        if (!(owner instanceof ServerPlayer sp)) return;

        StringBuilder sb = new StringBuilder();
        sb.append("§d[Разведчик] §fОбнаружено §c").append(enemies.size()).append(" §fврагов:\n");
        int shown = Math.min(enemies.size(), 3);
        for (int i = 0; i < shown; i++) {
            Player e = enemies.get(i);
            Vec3 pos = e.position();
            sb.append("  §c").append(e.getName().getString())
              .append(" §7→ §f")
              .append((int)pos.x).append(", ")
              .append((int)pos.y).append(", ")
              .append((int)pos.z)
              .append(" §7(").append((int)bot.distanceTo(e)).append("б)\n");
        }
        if (enemies.size() > 3) {
            sb.append("  §7...и ещё ").append(enemies.size() - 3).append("\n");
        }

        sp.sendSystemMessage(Component.literal(sb.toString()));
    }

    // ── Движение ─────────────────────────────────────────────────

    private void fleFrom(BotEntity bot, LivingEntity threat) {
        Vec3 away = bot.position().subtract(threat.position()).normalize().scale(16.0);
        Vec3 goal = bot.position().add(away);
        bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.3);
    }

    private void keepSafeDistance(BotEntity bot, LivingEntity target) {
        double dist = bot.distanceTo(target);
        if (dist < 12.0) {
            fleFrom(bot, target);
        } else if (dist > 48.0) {
            bot.getNavigation().moveTo(target.getX(), target.getY(), target.getZ(), 1.1);
        }
        // 12-48 → стоим, наблюдаем
    }

    private void patrol(BotEntity bot, Player owner) {
        // Патрулирование: каждый бот имеет уникальный угловой офсет по своему ID,
        // чтобы скауты не шли в одну точку
        if (!bot.getNavigation().isDone()) return;
        double timePhase   = (System.currentTimeMillis() / 5000.0) % (Math.PI * 2);
        double botOffset   = (bot.getId() * 2.399963) % (Math.PI * 2); // ~золотое сечение угол
        double angle       = (timePhase + botOffset) % (Math.PI * 2);
        double gx = owner.getX() + Math.cos(angle) * PATROL_RADIUS;
        double gz = owner.getZ() + Math.sin(angle) * PATROL_RADIUS;
        bot.getNavigation().moveTo(gx, owner.getY(), gz, 1.0);
    }

    // ── Helpers ──────────────────────────────────────────────────

    private SquadManager.Squad getSquad(BotEntity bot, Player owner) {
        if (!(owner instanceof ServerPlayer sp)) return null;
        return SquadManager.INSTANCE.getSquad(sp);
    }
}
