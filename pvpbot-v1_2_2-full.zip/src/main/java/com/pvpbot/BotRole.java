package com.pvpbot;

import java.util.*;

/**
 * BotRole v3.0 — роли бойцов в отряде с полной настройкой процентов.
 *
 * РОЛИ:
 *   SOLDIER  — обычный боец (меч/кристалл)
 *   ELITE    — элитный топорщик, снимает щиты
 *   MEDIC    — медик, кидает зелья лечения союзникам
 *   TANKER   — танкер, принимает урон на себя
 *   SNIPER   — снайпер, стреляет с дальней дистанции (лук/арбалет)
 *   SAPPER   — сапёр, ставит кристаллы/TNT перед врагами
 *   SCOUT    — разведчик на элитрах, докладывает координаты врагов
 *
 * Настройка через RoleConfig:
 *   - roleCounts[ROLE] = 0..100 — кол-во (0 = отключить роль полностью)
 *   - usePercent = true → воспринимать как % от отряда
 *   - usePercent = false → абсолютное число
 */
public enum BotRole {

    /** Обычный боец — меч/кристал по умолчанию. */
    SOLDIER("§7Солдат",      null,           3, 0xFF_888888),

    /** Элитный топорщик — нетерит топор + щит. */
    ELITE  ("§6§lЭлита",     BotKit.AXE,     1, 0xFF_FFB300),

    /**
     * Медик — зелья лечения II на союзников, держится сзади.
     * Не атакует первым, приоритет — поддержка раненых.
     */
    MEDIC  ("§a§lМедик",     BotKit.NETHPOT, 4, 0xFF_44FF44),

    /**
     * Танкер — нетерит броня + щит, AntiKnockback.
     * Встаёт перед командиром, принимает урон на себя.
     */
    TANKER ("§c§lТанкер",    BotKit.CRYSTAL, 2, 0xFF_FF4444),

    /**
     * Снайпер — арбалет/лук + хорошая броня.
     * Держится на 16-24 блоках от боя, стреляет, не лезет в ближний бой.
     */
    SNIPER ("§b§lСнайпер",   BotKit.AXE,     5, 0xFF_00CCFF),

    /**
     * Сапёр — ставит кристаллы/TNT перед врагами перед атакой.
     * Работает в паре с TANKER — пока танкер держит, сапёр закладывает.
     */
    SAPPER ("§e§lСапёр",     BotKit.CRYSTAL, 2, 0xFF_FFDD00),

    /**
     * Разведчик — элитры + скорость.
     * Постоянно сканирует врагов, пишет координаты в чат командиру.
     * Не вступает в ближний бой без приказа.
     */
    SCOUT  ("§d§lРазведчик", null,           6, 0xFF_FF55FF);

    public final String displayName;
    /** Кит снаряжения (null = не менять текущий). */
    public final BotKit kit;
    /** Приоритет позиции (меньше = ближе к командиру). */
    public final int priority;
    /** Цвет роли для мини-карты (ARGB). */
    public final int mapColor;

    BotRole(String displayName, BotKit kit, int priority, int mapColor) {
        this.displayName = displayName;
        this.kit         = kit;
        this.priority    = priority;
        this.mapColor    = mapColor;
    }

    // ═══════════════════════════════════════════════════════════════
    //  RoleConfig — настройка количества каждой роли
    // ═══════════════════════════════════════════════════════════════

    /**
     * Конфигурация распределения ролей.
     * Хранится в PVPBotConfig.roleConfig.
     *
     * usePercent=true  → roleCounts[R] = % от отряда (0..100)
     * usePercent=false → roleCounts[R] = абсолютное кол-во (0..MAX_SQUAD_SIZE)
     *
     * Пример: медиков 0% → ни одного медика; 100% → все медики.
     */
    public static class RoleConfig {
        /** Единицы: проценты или штуки. */
        public boolean usePercent = true;

        /** Значение для каждой роли (по умолчанию авторежим = -1). */
        public final Map<BotRole, Integer> roleCounts = new LinkedHashMap<>();

        public RoleConfig() {
            // -1 = авто (по старой логике)
            roleCounts.put(SOLDIER, -1);
            roleCounts.put(ELITE,   -1);
            roleCounts.put(MEDIC,   -1);
            roleCounts.put(TANKER,  -1);
            roleCounts.put(SNIPER,  -1);
            roleCounts.put(SAPPER,  -1);
            roleCounts.put(SCOUT,   -1);
        }

        /** Сброс на авто-распределение. */
        public void resetToAuto() {
            for (BotRole r : BotRole.values()) roleCounts.put(r, -1);
        }

        /** Включена ли роль? (0 = выключена, -1 или >0 = включена) */
        public boolean isRoleEnabled(BotRole role) {
            Integer v = roleCounts.get(role);
            return v == null || v != 0;
        }

        /**
         * Рассчитать сколько бойцов каждой роли выдать при данном размере отряда.
         * Если все роли в авто (-1) — используется старая логика.
         */
        public Map<BotRole, Integer> resolve(int soldierCount) {
            boolean allAuto = roleCounts.values().stream().allMatch(v -> v == null || v == -1);
            if (allAuto) return autoResolve(soldierCount);

            Map<BotRole, Integer> result = new LinkedHashMap<>();
            for (BotRole r : BotRole.values()) result.put(r, 0);

            int assigned = 0;
            // Сначала роли с фиксированным значением
            for (BotRole r : BotRole.values()) {
                if (r == SOLDIER) continue;
                Integer v = roleCounts.get(r);
                if (v == null || v == -1) continue;
                int count = usePercent
                    ? Math.round(soldierCount * v / 100f)
                    : Math.min(v, soldierCount);
                count = Math.min(count, soldierCount - assigned);
                if (count < 0) count = 0;
                result.put(r, count);
                assigned += count;
            }
            // Остаток → солдаты
            result.put(SOLDIER, Math.max(0, soldierCount - assigned));
            return result;
        }

        /** Авто-распределение (старая логика + новые роли). */
        private Map<BotRole, Integer> autoResolve(int n) {
            Map<BotRole, Integer> r = new LinkedHashMap<>();
            for (BotRole role : BotRole.values()) r.put(role, 0);

            int tanker = n >= 20 ? 1 : 0;
            int elite  = n >= 30 ? 3 : (n >= 20 ? 2 : 0);
            int medic  = n >= 25 ? 2 : (n >= 20 ? 1 : 0);
            int sniper = n >= 15 ? Math.max(1, n / 10) : 0;
            int sapper = n >= 20 ? 1 : 0;
            int scout  = n >= 10 ? 1 : 0;

            r.put(TANKER, tanker);
            r.put(ELITE,  elite);
            r.put(MEDIC,  medic);
            r.put(SNIPER, sniper);
            r.put(SAPPER, sapper);
            r.put(SCOUT,  scout);
            int leftover = n - tanker - elite - medic - sniper - sapper - scout;
            r.put(SOLDIER, Math.max(0, leftover));
            return r;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  autoAssign — назначение ролей отряду
    // ═══════════════════════════════════════════════════════════════

    /**
     * Назначает роли бойцам по конфигу.
     *
     * @param soldiers список солдат (без командира)
     * @param cfg      конфиг ролей (из PVPBotConfig.roleConfig)
     */
    public static void autoAssign(List<BotEntity> soldiers, RoleConfig cfg) {
        int total = soldiers.size();
        Map<BotRole, Integer> dist = cfg.resolve(total);

        int idx = 0;
        // Порядок назначения: по приоритету (меньше = раньше)
        BotRole[] order = { TANKER, SAPPER, ELITE, SOLDIER, MEDIC, SNIPER, SCOUT };
        for (BotRole role : order) {
            int count = dist.getOrDefault(role, 0);
            for (int i = 0; i < count && idx < total; i++, idx++) {
                assignRole(soldiers.get(idx), role, idx + 1);
            }
        }
        // Если остались — солдаты
        for (; idx < total; idx++) {
            assignRole(soldiers.get(idx), SOLDIER, idx + 1);
        }
    }

    /** Backward-compat перегрузка (авто-режим). */
    public static void autoAssign(List<BotEntity> soldiers) {
        autoAssign(soldiers, new RoleConfig());
    }

    // ═══════════════════════════════════════════════════════════════
    //  assignRole — применить роль к одному боту
    // ═══════════════════════════════════════════════════════════════

    public static void assignRole(BotEntity bot, BotRole role, int number) {
        bot.setSquadRole(role);

        if (PVPBotConfig.INSTANCE.difficulty != PVPBotConfig.Difficulty.PLAYER) {
            bot.setCustomName(net.minecraft.network.chat.Component.literal(
                role.displayName + " §f#" + number
            ));
            bot.setCustomNameVisible(true);
        }

        if (role.kit != null) role.kit.equipment.applyTo(bot);

        switch (role) {
            case TANKER -> {
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
                   .setBaseValue(20.0);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
                   .setBaseValue(0.8);
            }
            case ELITE -> {
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.145);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)
                   .setBaseValue(8.0);
            }
            case MEDIC -> {
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)
                   .setBaseValue(60.0);
                bot.setHealth(60.0f);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.12);
            }
            case SNIPER -> {
                // Снайпер держится далеко — скорость средняя, дальность атаки высокая
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.125);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE)
                   .setBaseValue(48.0);
            }
            case SAPPER -> {
                // Сапёр — быстрый, но хлипкий
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.14);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
                   .setBaseValue(12.0);
            }
            case SCOUT -> {
                // Разведчик — максимальная скорость, минимальная броня
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.18);
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE)
                   .setBaseValue(64.0);
            }
            case SOLDIER -> {
                bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                   .setBaseValue(0.13);
            }
        }
    }
}
