package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.FireworkRocketItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.component.DataComponents;

/**
 * FireworkLogic — v14: режим FIREWORK.
 *
 * Механика:
 *   1. Бот надевает элитры (CHEST слот) и использует их для уклонения.
 *   2. Запускает фейерверки-ракеты направленно в цель (взрывной урон).
 *   3. Dash-уклонение через элитры + фейерверк-ускоритель.
 *   4. Чередует: залп фейерверков → dash-уклонение → снова залп.
 *
 * Совместимость: 1.21.4
 */
public class FireworkLogic {

    private static final int FIREWORK_COOLDOWN = 25;  // тиков между ракетами
    private static final int BURST_COUNT       = 3;   // ракет в залпе
    private static final int BURST_INTERVAL    = 4;   // тиков между ракетами залпа
    private static final double LAUNCH_RANGE   = 12.0;
    private static final int DASH_COOLDOWN     = 60;

    private int fireworkTimer = 0;
    private int dashTimer     = 0;
    private int burstLeft     = 0;
    private int burstTick     = 0;
    private LivingEntity burstTarget = null;

    private final BotEntity bot;

    public FireworkLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (fireworkTimer > 0) fireworkTimer--;
        if (dashTimer > 0)     dashTimer--;

        equipFireworkKit();

        double dist = bot.distanceTo(target);

        // ── Burst залп ────────────────────────────────────────────
        if (burstLeft > 0) {
            burstTick--;
            if (burstTick <= 0) {
                launchFireworkAt(sw, burstTarget);
                burstLeft--;
                burstTick = BURST_INTERVAL;
            }
            return;
        }

        // ── Запустить новый залп ──────────────────────────────────
        if (dist <= LAUNCH_RANGE && fireworkTimer <= 0) {
            burstLeft  = BURST_COUNT;
            burstTick  = 1;
            burstTarget = target;
            fireworkTimer = FIREWORK_COOLDOWN;
        }

        // ── Элитра-даш для уклонения ──────────────────────────────
        if (dashTimer <= 0 && bot.getHealth() < bot.getMaxHealth() * 0.6) {
            elytraDash(sw, target);
            dashTimer = DASH_COOLDOWN;
        }

        // ── Движение ──────────────────────────────────────────────
        if (dist > 6.0) {
            bot.getNavigation().moveTo(target, 1.2);
        } else if (dist < 4.0) {
            // Держим дистанцию — отходим чуть назад
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.4);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0, away.z));
        }
    }

    private void launchFireworkAt(ServerLevel sw, LivingEntity target) {
        // Создаём ItemStack фейерверка с зарядом
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        // Вектор направления к цели
        Vec3 dir = target.getEyePosition().subtract(bot.getEyePosition()).normalize();

        // Спавним снаряд фейерверка
        FireworkRocketEntity firework = new FireworkRocketEntity(
            sw, bot, bot.getX(), bot.getEyeY(), bot.getZ(), rocket
        );
        // Задаём скорость в сторону цели
        firework.setDeltaMovement(dir.x * 1.5, dir.y * 1.5, dir.z * 1.5);
        sw.addFreshEntity(firework);

        // Эффекты
        sw.sendParticles(ParticleTypes.FIREWORK,
            bot.getX(), bot.getY() + 1, bot.getZ(),
            5, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
    }

    private void elytraDash(ServerLevel sw, LivingEntity target) {
        // Импульс уклонения — в сторону от цели + вверх
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 sideDir  = new Vec3(-toTarget.z, 0.4, toTarget.x).normalize().scale(0.8);
        bot.setDeltaMovement(bot.getDeltaMovement().add(sideDir));

        sw.sendParticles(ParticleTypes.CLOUD,
            bot.getX(), bot.getY(), bot.getZ(),
            8, 0.3, 0.1, 0.3, 0.05);
    }

    private void equipFireworkKit() {
        // Элитры в нагрудник
        ItemStack chest = bot.getItemBySlot(EquipmentSlot.CHEST);
        if (!chest.is(Items.ELYTRA)) {
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        }
        // Меч в руку
        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (main.isEmpty()) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        }
        // Шлем/ноги/ботинки
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }
}
