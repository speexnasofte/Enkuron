package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

/**
 * AutoGap — автоматически ест Golden Apple / Enchanted Golden Apple
 * при HP ниже заданного порога (отдельно от обычного autoHeal/autoEat).
 *
 * Приоритет: Enchanted Golden Apple > Golden Apple
 * Не конкурирует с autoEat — проверяет тип предмета явно.
 *
 * Вызывается из PVPBotLogic.tick().
 */
public class AutoGapLogic {
    private static void setKeyDown(net.minecraft.client.KeyMapping key, boolean down) {
        try {
            var f = net.minecraft.client.KeyMapping.class.getDeclaredField("isDown");
            f.setAccessible(true);
            f.set(key, down);
        } catch (Exception ignored) {}
    }

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private boolean isGapping = false;

    /**
     * @return true если активно ест гэп (захватил useKey)
     */
    public boolean tick(Minecraft client) {
        if (!cfg.autoGapEnabled) {
            if (isGapping) release(client);
            return false;
        }

        Player player = client.player;
        if (player == null) return false;

        float hp = player.getHealth();
        if (hp > cfg.autoGapHpThreshold) {
            if (isGapping) release(client);
            return false;
        }

        // Ищем Enchanted Golden Apple сначала, потом обычный
        int gapSlot  = -1;
        int egapSlot = -1;

        for (int i = 0; i < 9; i++) {
            var stack = player.getInventory().getItem(i);
            if (stack.is(Items.ENCHANTED_GOLDEN_APPLE) && egapSlot < 0) egapSlot = i;
            else if (stack.is(Items.GOLDEN_APPLE) && gapSlot < 0) gapSlot = i;
        }

        int slot = egapSlot >= 0 ? egapSlot : gapSlot;
        if (slot < 0) {
            if (isGapping) release(client);
            return false;
        }

        player.getInventory().selected = slot;
        setKeyDown(client.options.keyUse, true);
        isGapping = true;
        return true;
    }

    private void release(Minecraft client) {
        setKeyDown(client.options.keyUse, false);
        isGapping = false;
    }
}
