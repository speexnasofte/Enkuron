package com.pvpbot;

/**
 * AdaptiveCooldown — v16: подстройка кулдауна атаки под ping/lag сервера.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Идея:
 * ══════════════════════════════════════════════════════════════════
 *
 *  На лагающих серверах (TPS < 20) атаки бота срабатывают «в пустоту»,
 *  потому что сервер ещё не успел обработать предыдущий удар.
 *  AdaptiveCooldown следит за реальным TPS сервера и масштабирует
 *  attackCooldown в PVPBotConfig.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Алгоритм:
 * ══════════════════════════════════════════════════════════════════
 *
 *  1. Каждые SAMPLE_INTERVAL тиков фиксируем System.nanoTime().
 *  2. Из разницы времён вычисляем «реальный» TPS:
 *       realTPS = SAMPLE_INTERVAL / (elapsed_sec)
 *  3. EMA-сглаживание (exponential moving average, α=0.2)
 *  4. Если TPS < 18 → увеличиваем кулдаун на LAG_PENALTY тиков.
 *     Если TPS > 19.5 → возвращаем к базовому значению.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Использование:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В BotEntity.tick() добавить:
 *    adaptiveCooldown.tick();
 *
 *  В атакующей логике вместо PVPBotConfig.INSTANCE.attackCooldown
 *  использовать adaptiveCooldown.getEffectiveCooldown().
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class AdaptiveCooldown {

    // ── Константы ─────────────────────────────────────────────────
    private static final int    SAMPLE_INTERVAL  = 40;
    private static final float  EMA_ALPHA        = 0.20f;
    private static final float  LAG_THRESHOLD    = 18.0f;
    private static final float  OK_THRESHOLD     = 19.5f;
    private static final int    LAG_PENALTY      = 6;
    private static final int    MAX_PENALTY      = 20;
    /** Дисперсия TPS выше этого = джиттер/нестабильность сервера */
    private static final float  JITTER_THRESHOLD = 1.5f;
    /** Штраф за джиттер (тиков) */
    private static final int    JITTER_PENALTY   = 3;

    // ── Состояние ─────────────────────────────────────────────────
    private float smoothedTPS    = 20.0f;
    private float tpsVariance    = 0f;   // EMA дисперсии
    private int   sampleTimer    = 0;
    private long  lastNanos      = System.nanoTime();
    private int   lagPenalty     = 0;
    private int   jitterPenalty  = 0;

    private final BotEntity bot;

    public AdaptiveCooldown(BotEntity bot) {
        this.bot = bot;
    }

    public void tick() {
        sampleTimer++;
        if (sampleTimer < SAMPLE_INTERVAL) return;
        sampleTimer = 0;

        long nowNanos  = System.nanoTime();
        double elapsed = (nowNanos - lastNanos) / 1_000_000_000.0;
        lastNanos      = nowNanos;

        if (elapsed <= 0) return;

        float measuredTPS = (float) Math.min(SAMPLE_INTERVAL / elapsed, 20.0);

        // Дисперсия (EMA отклонения от сглаженного значения)
        float tpsDiff = Math.abs(measuredTPS - smoothedTPS);
        tpsVariance   = 0.3f * tpsDiff + 0.7f * tpsVariance;

        // EMA TPS
        smoothedTPS = EMA_ALPHA * measuredTPS + (1.0f - EMA_ALPHA) * smoothedTPS;

        // Лаг-пенальти
        if (smoothedTPS < LAG_THRESHOLD) {
            lagPenalty = Math.min(lagPenalty + LAG_PENALTY, MAX_PENALTY);
        } else if (smoothedTPS > OK_THRESHOLD) {
            lagPenalty = Math.max(lagPenalty - 2, 0);
        }

        // Джиттер-пенальти (нестабильный TPS даже если средний норм)
        if (tpsVariance > JITTER_THRESHOLD) {
            jitterPenalty = Math.min(jitterPenalty + JITTER_PENALTY, 10);
        } else {
            jitterPenalty = Math.max(jitterPenalty - 1, 0);
        }
    }

    public int getEffectiveCooldown() {
        int base = PVPBotConfig.INSTANCE.attackCooldown;
        return base + lagPenalty + jitterPenalty;
    }

    public float getSmoothedTPS()  { return smoothedTPS;   }
    public int   getLagPenalty()   { return lagPenalty;    }
    public int   getJitterPenalty(){ return jitterPenalty; }
    public float getTpsVariance()  { return tpsVariance;   }

    public boolean isLagging()   { return smoothedTPS < LAG_THRESHOLD; }
    public boolean isJittering() { return tpsVariance  > JITTER_THRESHOLD; }

    public String getLabel() {
        if (lagPenalty == 0 && jitterPenalty == 0) return "";
        String lag    = lagPenalty    > 0 ? String.format("§eLAG:+%dt", lagPenalty)    : "";
        String jitter = jitterPenalty > 0 ? String.format("§6JIT:+%dt", jitterPenalty) : "";
        return (lag + " " + jitter).trim()
             + String.format(" §7(TPS=%.1f±%.1f)", smoothedTPS, tpsVariance);
    }
}
