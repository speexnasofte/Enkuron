package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/**
 * SnowballLogic v3.0 — умный SNOWBALL.
 * ИСПРАВЛЕНО:
 *  - Kite через navigation (не только deltaMovement)
 *  - Rush через navigation
 *  - Страф через StrafeAI
 *  - Броски: реальный Snowball projectile с arc
 */
public class SnowballLogic {

    private static final double THROW_RANGE  = 12.0;
    private static final double RUSH_RANGE   = 3.8;
    private static final double KITE_DIST    = 7.0;
    private static final int    SNOW_CD      = 15;
    private static final int    RUSH_CD      = 10;
    private static final int    COOLDOWN_T   = 30;
    private static final int    SHIELD_BURST = 3;
    private static final float  SNOW_SPEED   = 1.5f;
    private static final int    LEAD_TICKS   = 4;

    private enum State { STRAFE, SHIELD_BREAK, RUSH, COOLDOWN }
    private State state = State.STRAFE;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int snowCd = 0, rushCd = 0, cdTimer = 0, burstCount = 0;

    public SnowballLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (snowCd > 0) snowCd--;
        if (rushCd > 0) rushCd--;

        switch (state) {
            case STRAFE       -> tickStrafe(sw, target);
            case SHIELD_BREAK -> tickShieldBreak(sw, target);
            case RUSH         -> tickRush(sw, target);
            case COOLDOWN     -> { if (--cdTimer <= 0) state = State.STRAFE; }
            default -> {}
        }
    }

    private void tickStrafe(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Кайт через navigation
        if (dist < KITE_DIST - 1.0) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(bot.getX()+away.x*5, bot.getY(), bot.getZ()+away.z*5, 1.2);
        } else if (dist > THROW_RANGE) {
            bot.getNavigation().moveTo(target, 1.0);
        } else {
            bot.getNavigation().stop();
            strafe.tick(target);
        }

        // Бросок
        if (dist <= THROW_RANGE && snowCd <= 0) {
            throwSnowball(sw, target); snowCd = SNOW_CD;
        }

        if (isHoldingShield(target)) { state = State.SHIELD_BREAK; burstCount = 0; }
        if (snowCd <= 0 && Math.random() < 0.007 && dist <= RUSH_RANGE + 1.0) state = State.RUSH;
    }

    private void tickShieldBreak(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);
        if (dist > 6.0) bot.getNavigation().moveTo(target, 1.2);

        if (dist <= THROW_RANGE && snowCd <= 0) {
            throwSnowball(sw, target); snowCd = 8; burstCount++;
        }
        if (burstCount >= SHIELD_BURST || !isHoldingShield(target)) {
            state = State.RUSH; burstCount = 0;
        }
    }

    private void tickRush(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);
        if (dist > RUSH_RANGE) {
            bot.getNavigation().moveTo(target, 1.45);
            bot.setSprinting(true);
        } else if (rushCd <= 0) {
            equipSword();
            bot.getLookControl().setLookAt(target, 30f, 30f);
            bot.doHurtTarget(sw, target);
            rushCd   = RUSH_CD;
            state    = State.COOLDOWN;
            cdTimer  = COOLDOWN_T;
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(bot.getX()+away.x*4, bot.getY(), bot.getZ()+away.z*4, 1.3);
        }
    }

    private void throwSnowball(ServerLevel sw, LivingEntity target) {
        Vec3 lead = target.position()
            .add(target.getDeltaMovement().scale(LEAD_TICKS))
            .add(0, target.getBbHeight()*0.5, 0);
        Vec3 from = bot.position().add(0, bot.getEyeHeight(bot.getPose()), 0);
        Vec3 dir  = lead.subtract(from).normalize();

        bot.getLookControl().setLookAt(target, 60f, 60f);

        Snowball sb = new Snowball(net.minecraft.world.entity.EntityType.SNOWBALL, sw);
        sb.setOwner(bot);
        sb.setPos(from.x, from.y, from.z);
        sb.setDeltaMovement(dir.x*SNOW_SPEED, dir.y*SNOW_SPEED+0.05, dir.z*SNOW_SPEED);
        sw.addFreshEntity(sb);

        sw.playSound(null, bot.getX(), bot.getY(), bot.getZ(),
            SoundEvents.SNOWBALL_THROW, SoundSource.NEUTRAL, 0.5f,
            0.4f / (sw.random.nextFloat()*0.4f+0.8f));
    }

    private boolean isHoldingShield(LivingEntity t) {
        return t.getMainHandItem().is(Items.SHIELD) || t.getOffhandItem().is(Items.SHIELD);
    }

    private void equipSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.DIAMOND_SWORD) && !cur.is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }

    public String getStateLabel() {
        return switch (state) {
            case STRAFE       -> "SNOW:KITE";
            case SHIELD_BREAK -> "SNOW:BURST x" + burstCount;
            case RUSH         -> "SNOW:RUSH";
            case COOLDOWN     -> "SNOW:CD " + cdTimer + "t";
            default     -> "?";
        };
    }
}
