package com.pvpbot;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * UhcLogic v3.0 — умный UHC режим.
 * ИСПРАВЛЕНО:
 *  - Лук: navigation + strafe, не addDeltaMovement
 *  - Paутина: кладём только на AIR, не телепорт
 *  - Finishing/Retreat: navigation
 *  - Страф: StrafeAI
 */
public class UhcLogic {

    private static final double BOW_RANGE   = 14.0;
    private static final double TRAP_RANGE  = 4.5;
    private static final double MELEE_RANGE = 2.8;
    private static final int    BOW_CD      = 22;
    private static final int    TRAP_CD     = 90;
    private static final int    GAP_CD      = 200;
    private static final int    WEB_LIFE    = 60; // тиков жизни паутины

    private enum State { RANGING, TRAPPING, MELEING, GAPPING }
    private State state = State.RANGING;

    private final BotEntity bot;
    private final StrafeAI  strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int bowCd    = 0;
    private int trapCd   = 0;
    private int gapCd    = 0;
    private int webLife  = 0;
    private boolean webPlaced = false;
    private BlockPos webPos   = null;

    public UhcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.RETREAT);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (bowCd  > 0) bowCd--;
        if (trapCd > 0) trapCd--;
        if (gapCd  > 0) gapCd--;
        if (webLife > 0) webLife--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();
        float  tgHp = target.getHealth();

        // Паутина: убираем если вышло время
        if (webPlaced && webLife <= 0) removeWeb(sw);

        // Переходы состояний
        if (myHp < 8.0f && gapCd <= 0)          state = State.GAPPING;
        else if (dist < TRAP_RANGE && trapCd <= 0 && !webPlaced) state = State.TRAPPING;
        else if (webPlaced && isInWeb(target))    state = State.MELEING;
        else if (state != State.GAPPING)          state = State.RANGING;

        switch (state) {
            case RANGING  -> doRanging(sw, target, dist);
            case TRAPPING -> doTrapping(sw, target);
            case MELEING  -> doMeleing(sw, target);
            case GAPPING  -> doGapping(sw, target);
            default -> {}
        }
    }

    private void doRanging(ServerLevel sw, LivingEntity target, double dist) {
        equipBow();

        // Держим дистанцию через navigation
        if (dist < 6.0) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 6, bot.getY(), bot.getZ() + away.z * 6, 1.1
            );
        } else if (dist > BOW_RANGE) {
            bot.getNavigation().moveTo(target, 1.0);
        }

        strafe.tick(target);

        if (bowCd <= 0 && dist <= BOW_RANGE) {
            bot.getLookControl().setLookAt(target, 60f, 60f);
            Vec3 aim = MotionPredictor.predict(target, (int)(dist / 3));
            float dmg = (float) Math.max(3.0, Math.min(9.0, 10.5 - dist * 0.35));
            sw.getEntitiesOfClass(LivingEntity.class,
                new net.minecraft.world.phys.AABB(aim,aim).inflate(1.3),
                e -> e != bot && e.isAlive()
            ).stream().findFirst().ifPresent(e -> e.hurt(sw.damageSources().arrow(null, bot), dmg));
            sw.sendParticles(ParticleTypes.CRIT, aim.x, aim.y+1, aim.z, 3, 0.2,0.2,0.2,0.1);
            bowCd = BOW_CD;
        }
    }

    private void doTrapping(ServerLevel sw, LivingEntity target) {
        BlockPos feet = BlockPos.containing(target.position());
        if (sw.getBlockState(feet).isAir() && sw.getBlockState(feet.below()).isSolid()) {
            sw.setBlock(feet, Blocks.COBWEB.defaultBlockState(), 3);
            webPlaced = true;
            webPos    = feet;
            webLife   = WEB_LIFE;
            bot.playSound(net.minecraft.sounds.SoundEvents.WOOL_PLACE, 1.0f, 0.8f);
        }
        trapCd = TRAP_CD;
        state  = State.MELEING;
    }

    private void doMeleing(ServerLevel sw, LivingEntity target) {
        equipSword();

        // Идём к цели через navigation
        if (bot.distanceTo(target) > MELEE_RANGE)
            bot.getNavigation().moveTo(target, 1.1);

        if (bot.distanceTo(target) <= MELEE_RANGE + 0.5) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            bot.doHurtTarget(sw, target);
        }

        if (!isInWeb(target)) {
            webPlaced = false;
            state = bot.distanceTo(target) > TRAP_RANGE ? State.RANGING : State.TRAPPING;
        }
    }

    private void doGapping(ServerLevel sw, LivingEntity target) {
        // Отходим и едим
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 5, bot.getY(), bot.getZ() + away.z * 5, 1.2
        );
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 0));
        gapCd = GAP_CD;
        state = State.RANGING;
    }

    private void removeWeb(ServerLevel sw) {
        if (webPos != null && sw.getBlockState(webPos).is(Blocks.COBWEB)) {
            sw.setBlock(webPos, Blocks.AIR.defaultBlockState(), 3);
            sw.sendParticles(ParticleTypes.SPLASH, webPos.getX()+0.5, webPos.getY()+0.5, webPos.getZ()+0.5, 8, 0.2,0.2,0.2,0.08);
        }
        webPlaced = false; webPos = null;
    }

    private boolean isInWeb(LivingEntity t) {
        if (webPos == null) return false;
        BlockPos tp = BlockPos.containing(t.position());
        return tp.equals(webPos) && bot.level().getBlockState(webPos).is(Blocks.COBWEB);
    }

    private void reset() { state = State.RANGING; webPlaced = false; webPos = null; }

    private void equipBow() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }
    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }
}
