package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

/**
 * StrafeAI v4.0 — страф без застревания в блоках.
 *
 * ИСПРАВЛЕНИЯ v4.0:
 *   - Не применяем setDeltaMovement если впереди блок (навигация вместо velocity)
 *   - isSideBlocked проверяет ноги И голову (2 уровня)
 *   - Wall-slide: если заблокировано — пробуем скользить вдоль стены
 *   - Страф через navigation.moveTo вместо прямого velocity (нет застревания)
 *   - applySmoothedStrafe применяется только если путь чист
 *   - Кулдаун на смену направления при блоке
 */
public class StrafeAI {

    public enum StrafeStyle { CIRCLE, RANDOM, ZIGZAG, RETREAT }

    // ── Константы ─────────────────────────────────────────────────
    private static final double MAX_STRAFE_SPEED = 0.18;
    private static final double STRAFE_ACCEL     = 0.04;
    private static final double STRAFE_DECEL     = 0.85;
    private static final int    DIR_CHANGE_MIN   = 14;
    private static final int    DIR_CHANGE_MAX   = 28;
    private static final int    HIGH_GROUND_CD   = 40;

    // ── Состояние ─────────────────────────────────────────────────
    private StrafeStyle style      = StrafeStyle.CIRCLE;
    private boolean     strafeLeft = true;
    private int         dirTimer   = 0;
    private int         retreatTimer = 0;
    private boolean     retreating = false;
    private int         highGroundCd = 0;
    private double      strafeVX   = 0;
    private double      strafeVZ   = 0;
    /** Тики блокировки смены направления после столкновения */
    private int         blockCooldown = 0;

    private final BotEntity bot;

    public StrafeAI(BotEntity bot) {
        this.bot = bot;
        this.dirTimer = DIR_CHANGE_MIN + bot.level().getRandom().nextInt(DIR_CHANGE_MAX - DIR_CHANGE_MIN);
    }

    public void setStyle(StrafeStyle s) { this.style = s; }
    public StrafeStyle getStyle()       { return style; }

    /** Текущее направление страфа (для PatternAI-адаптации). */
    public boolean isStrafeLeft() { return strafeLeft; }

    /** Адаптированный yaw-offset от PatternAI. */
    private float adaptedYawOffset = 0f;
    public void setAdaptedYaw(float yaw) { this.adaptedYawOffset = yaw; }

    public void tick(LivingEntity target) {
        if (target == null || !target.isAlive()) { decelerate(); return; }
        if (bot.level().isClientSide) return;

        if (blockCooldown > 0) blockCooldown--;

        dirTimer--;
        if (dirTimer <= 0 && blockCooldown <= 0) {
            boolean blocked = isSideBlocked(!strafeLeft, target);
            if (blocked) {
                // Сторона заблокирована — разворачиваем сразу
                strafeLeft    = !strafeLeft;
                blockCooldown = 8;
                dirTimer      = 4;
            } else {
                strafeLeft = !strafeLeft;
                dirTimer   = DIR_CHANGE_MIN + bot.level().getRandom().nextInt(DIR_CHANGE_MAX - DIR_CHANGE_MIN);
            }
        }

        if (highGroundCd > 0) highGroundCd--;
        tickHighGround(target);

        switch (style) {
            case CIRCLE  -> tickCircle(target);
            case RANDOM  -> tickRandom(target);
            case ZIGZAG  -> tickZigzag(target);
            case RETREAT -> tickRetreat(target);
            default     -> null;
        }

        applySmoothedStrafe(target);
    }

    // ── Стили ─────────────────────────────────────────────────────

    private void tickCircle(LivingEntity target) {
        Vec3 side = getSideVector(target, strafeLeft);
        accelerate(side, STRAFE_ACCEL);
    }

    private void tickRandom(LivingEntity target) {
        if (dirTimer % 6 == 0) {
            boolean rnd = bot.level().getRandom().nextBoolean();
            Vec3 side = getSideVector(target, rnd);
            accelerate(side, STRAFE_ACCEL * 0.7);
        }
    }

    private void tickZigzag(LivingEntity target) {
        Vec3 side = getSideVector(target, strafeLeft);
        accelerate(side, STRAFE_ACCEL * 1.2);
        if (dirTimer <= 0) dirTimer = 6 + bot.level().getRandom().nextInt(6);
    }

    private void tickRetreat(LivingEntity target) {
        double dist = bot.distanceTo(target);
        if (retreating) {
            retreatTimer--;
            Vec3 away = bot.position().subtract(target.position()).normalize();
            accelerate(away, STRAFE_ACCEL * 1.1);
            if (retreatTimer <= 0) retreating = false;
        } else {
            tickCircle(target);
            if (bot.getHealth() < bot.getMaxHealth() * 0.45 && dist < 3.5) {
                retreating   = true;
                retreatTimer = 20 + bot.level().getRandom().nextInt(10);
            }
        }
    }

    // ── Применение скорости (с проверкой коллизии) ────────────────
    private void accelerate(Vec3 dir, double amt) {
        strafeVX += dir.x * amt;
        strafeVZ += dir.z * amt;
    }

    private void decelerate() {
        strafeVX *= STRAFE_DECEL;
        strafeVZ *= STRAFE_DECEL;
        if (Math.abs(strafeVX) < 0.001) strafeVX = 0;
        if (Math.abs(strafeVZ) < 0.001) strafeVZ = 0;
    }

    /**
     * Применяем страф только если путь в нужном направлении чист.
     * Если заблокировано — пробуем wall-slide (убираем одну ось).
     */
    private void applySmoothedStrafe(LivingEntity target) {
        // Clamp горизонтальная скорость
        double horiz = Math.sqrt(strafeVX * strafeVX + strafeVZ * strafeVZ);
        if (horiz > MAX_STRAFE_SPEED) {
            double scale = MAX_STRAFE_SPEED / horiz;
            strafeVX *= scale;
            strafeVZ *= scale;
        }

        double applyX = strafeVX;
        double applyZ = strafeVZ;

        // Проверяем блок в направлении страфа (ноги и голова)
        Vec3 futurePos = bot.position().add(applyX * 4, 0, applyZ * 4);
        if (isPositionBlocked(futurePos)) {
            // Пробуем только X
            Vec3 tryX = bot.position().add(applyX * 4, 0, 0);
            Vec3 tryZ = bot.position().add(0, 0, applyZ * 4);
            if (!isPositionBlocked(tryX)) {
                applyZ = 0; // wall-slide по X
            } else if (!isPositionBlocked(tryZ)) {
                applyX = 0; // wall-slide по Z
            } else {
                // Полностью заблокировано — форсируем смену направления
                applyX = 0; applyZ = 0;
                strafeLeft    = !strafeLeft;
                blockCooldown = 10;
                dirTimer      = 4;
            }
        }

        Vec3 cur = bot.getDeltaMovement();
        double newX = clamp(cur.x + applyX, -MAX_STRAFE_SPEED * 1.5, MAX_STRAFE_SPEED * 1.5);
        double newZ = clamp(cur.z + applyZ, -MAX_STRAFE_SPEED * 1.5, MAX_STRAFE_SPEED * 1.5);
        bot.setDeltaMovement(newX, cur.y, newZ);

        strafeVX *= 0.78;
        strafeVZ *= 0.78;
    }

    // ── Векторы ───────────────────────────────────────────────────
    private Vec3 getSideVector(LivingEntity target, boolean left) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 side = left
            ? new Vec3(-toTarget.z, 0,  toTarget.x)
            : new Vec3( toTarget.z, 0, -toTarget.x);
        // PatternAI адаптация: вращаем вектор страфа на adaptedYawOffset градусов
        if (adaptedYawOffset != 0f) {
            double rad = Math.toRadians(adaptedYawOffset);
            double cos = Math.cos(rad), sin = Math.sin(rad);
            side = new Vec3(side.x * cos - side.z * sin, 0, side.x * sin + side.z * cos);
        }
        return side;
    }

    // ── Проверка блока (ноги + голова) ────────────────────────────
    private boolean isSideBlocked(boolean left, LivingEntity target) {
        Vec3 side = getSideVector(target, left).scale(1.2);
        return isPositionBlocked(bot.position().add(side));
    }

    /**
     * Проверяем ноги (Y+0) и голову (Y+1) — чтобы не пролезать в щели.
     */
    private boolean isPositionBlocked(Vec3 pos) {
        BlockPos foot = BlockPos.containing(pos.x, bot.getY() + 0.1, pos.z);
        BlockPos head = BlockPos.containing(pos.x, bot.getY() + 1.0, pos.z);
        BlockState stFoot = bot.level().getBlockState(foot);
        BlockState stHead = bot.level().getBlockState(head);
        return (stFoot.isSolid() && !stFoot.isAir())
            || (stHead.isSolid() && !stHead.isAir());
    }

    // ── HighGround v2 ─────────────────────────────────────────────
    private void tickHighGround(LivingEntity target) {
        if (highGroundCd > 0) return;
        if (bot.getY() >= target.getY() - 0.4) return;

        BlockPos botPos = bot.blockPosition();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (Math.sqrt(dx*dx + dz*dz) > 2.2) continue;
                BlockPos up = botPos.offset(dx, 1, dz);
                if (!bot.level().getBlockState(up).isAir()) continue;
                if (!bot.level().getBlockState(up.below()).isSolid()) continue;
                if (!bot.level().getBlockState(up.above()).isAir()) continue;
                bot.getNavigation().moveTo(up.getX() + 0.5, up.getY(), up.getZ() + 0.5, 1.2);
                if (bot.onGround() && bot.distanceTo(target) < 5)
                    bot.getJumpControl().jump();
                highGroundCd = HIGH_GROUND_CD;
                return;
            }
        }
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
