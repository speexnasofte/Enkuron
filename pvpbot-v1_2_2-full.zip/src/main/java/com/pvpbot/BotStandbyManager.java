package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * BotStandbyManager — система ожидания перед атакой.
 *
 * По умолчанию боты стоят в построении и НЕ атакуют.
 * Команда /bot attack — начинают атаковать.
 * Команда /bot standby — снова встают в ряд и ждут.
 *
 * Использование:
 *   /bot standby         — боты выстраиваются в линию и стоят
 *   /bot attack          — боты начинают атаковать
 *   /bot attack <nick>   — атаковать конкретного игрока
 */
public class BotStandbyManager {

    public static final BotStandbyManager INSTANCE = new BotStandbyManager();

    /** true = боты стоят и ждут команды. false = боты атакуют */
    private boolean standby = true;

    /** UUID принудительной цели (из /bot attack <nick>) */
    private UUID forcedTargetUUID = null;

    private BotStandbyManager() {}

    public boolean isStandby() { return standby; }

    public void setStandby(boolean value) {
        this.standby = value;
        if (value) {
            forcedTargetUUID = null;
            // При уходе в standby — сбрасываем построение в LINE
            BotFormations.INSTANCE.setCurrent(BotFormations.Formation.LINE);
        }
    }

    public UUID getForcedTargetUUID() { return forcedTargetUUID; }

    public void startAttack(UUID targetUUID) {
        this.standby = false;
        this.forcedTargetUUID = targetUUID;
    }

    public void startAttack() {
        this.standby = false;
        this.forcedTargetUUID = null;
    }
}
