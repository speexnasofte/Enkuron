package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * SmokeBombLogic — v8: новая функция.
 *
 * Бот бросает снежок в ноги убегающему врагу когда:
 *  1. Враг движется прочь быстрее cfg.smokeBombMinDist блоков/тик
 *  2. Дистанция до врага > cfg.smokeBombMinDist
 *  3. Кулдаун истёк
 *
 * Снежок не наносит урона но сбивает спринт и создаёт эффект "дымовой бомбы"
 * через частицы снега. Интегрируется в PVPBotLogic.tick() после блока dodge.
 *
 * Активация: /bot module smokebomb on
 */
public class SmokeBombLogic {

    public static final SmokeBombLogic INSTANCE = new SmokeBombLogic();

    private int cooldownTimer = 0;

    private SmokeBombLogic() {}

    /**
     * Вызывается из PVPBotLogic.tick() при наличии цели.
     * @return true если бросил снежок в этом тике
     */
    public boolean tick(BotEntity bot, LivingEntity target) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.smokeBombEnabled) return false;
        if (!(bot.level() instanceof ServerLevel level)) return false;

        if (cooldownTimer > 0) {
            cooldownTimer--;
            return false;
        }

        double dist = bot.distanceTo(target);
        if (dist < cfg.smokeBombMinDist) return false;

        // Проверяем: враг убегает (его скорость направлена ОТ бота)
        Vec3 toBot   = bot.position().subtract(target.position()).normalize();
        Vec3 vel     = target.getDeltaMovement();
        double fleeDot = vel.dot(toBot); // отрицательное = убегает от бота
        boolean fleeing = fleeDot < -0.05 && vel.horizontalDistanceSqr() > 0.01;

        if (!fleeing) return false;

        throwSnowball(bot, target, level);
        cooldownTimer = cfg.smokeBombCooldown;
        return true;
    }

    private void throwSnowball(BotEntity bot, LivingEntity target, ServerLevel level) {
        Vec3 from = bot.getEyePosition();
        Vec3 to   = target.position(); // целимся в ноги, не в глаза

        Vec3 dir = to.subtract(from).normalize();

        Snowball ball = new Snowball(level, bot, new ItemStack(Items.SNOWBALL));
        ball.setPos(from.x, from.y, from.z);
        // Небольшой угол вверх для дальних бросков (компенсация гравитации)
        double dist = bot.distanceTo(target);
        double arcUp = dist * 0.025;
        ball.shoot(dir.x, dir.y + arcUp, dir.z, 1.5f, 1.0f);

        level.addFreshEntity(ball);
    }

    public void reset() {
        cooldownTimer = 0;
    }
}
