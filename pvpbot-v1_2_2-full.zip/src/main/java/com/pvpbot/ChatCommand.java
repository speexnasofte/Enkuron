package com.pvpbot;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * ChatCommand v1.0 — управление ботами через чат-команды.
 *
 * Команды (пишутся в чат, без слэша):
 *   !attack [ник]   — приказать атаковать (всем или конкретного)
 *   !retreat        — отступить к игроку
 *   !stand          — стоять, ждать
 *   !flank          — фланкировать цель
 *   !follow         — следовать за мной
 *   !surround       — окружить ближайшего врага
 *   !bots           — показать статус ботов
 *   !help           — показать список команд
 *
 * Поддерживает Squad-систему: приказ идёт через CommanderAI
 * если отряд создан, иначе напрямую всем ботам.
 *
 * Интеграция:
 *   ChatCommand.register() вызывать из PVPBotMod.onInitialize()
 */
public class ChatCommand {

    private static final String PREFIX = "!";

    private ChatCommand() {}

    /** Зарегистрировать слушатель чат-сообщений. */
    public static void register() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.decoratedContent().getString().trim();
            if (text.startsWith(PREFIX)) {
                handleCommand(sender, text.substring(PREFIX.length()).trim());
            }
        });
    }

    private static void handleCommand(ServerPlayer player, String raw) {
        String[] parts = raw.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String arg = parts.length > 1 ? parts[1].trim() : null;

        List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);

        switch (cmd) {
            case "attack" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.ATTACK);
                } else {
                    PVPBotConfig.INSTANCE.standbyMode = false;
                    if (arg != null) {
                        setForcedTargetByName(player, bots, arg);
                    }
                }
                feedback(player, "§c⚔ Атаковать!");
            }
            case "retreat" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.RETREAT);
                } else {
                    for (BotEntity bot : bots) {
                        bot.setTarget(null);
                        bot.getNavigation().stop();
                    }
                    PVPBotConfig.INSTANCE.standbyMode = true;
                }
                feedback(player, "§e🏃 Отступить!");
            }
            case "stand" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.STAND);
                } else {
                    for (BotEntity bot : bots) {
                        bot.setTarget(null);
                        bot.getNavigation().stop();
                    }
                    PVPBotConfig.INSTANCE.standbyMode = true;
                    BotFormations.INSTANCE.setCurrent(BotFormations.Formation.LINE);
                }
                feedback(player, "§7🛡 Стоять!");
            }
            case "flank" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.FLANK);
                } else {
                    feedback(player, "§c! Создай отряд: §f/bot squad create");
                    return;
                }
                feedback(player, "§b🏹 Фланкировать!");
            }
            case "follow" -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                BotFormations.INSTANCE.setCurrent(BotFormations.Formation.FOLLOW);
                for (BotEntity bot : bots) bot.setTarget(null);
                feedback(player, "§a👣 Следовать за мной!");
            }
            case "surround" -> {
                BotFormations.INSTANCE.setCurrent(BotFormations.Formation.SURROUND);
                // Найти ближайшего врага и атаковать
                net.minecraft.world.entity.LivingEntity enemy = findNearestEnemy(player, 30.0);
                if (enemy != null) {
                    PVPBotConfig.INSTANCE.standbyMode = false;
                    for (BotEntity bot : bots) {
                        bot.setTarget(enemy);
                        bot.getTargetPriority().setForcedTarget(enemy.getUUID());
                    }
                    feedback(player, "§6🔄 Окружить цель!");
                } else {
                    BotFormations.INSTANCE.setCurrent(BotFormations.Formation.SURROUND);
                    feedback(player, "§7🔄 Построение окружение (врагов нет рядом)");
                }
            }
            case "bots" -> {
                StringBuilder sb = new StringBuilder("§e§l⚔ Боты:\n");
                for (int i = 0; i < bots.size(); i++) {
                    BotEntity bot = bots.get(i);
                    boolean isCmd = squad != null && bot == squad.commander;
                    String role = isCmd ? "§c[CMD]" : "§7[PVT]";
                    sb.append(role).append(" §f#").append(i + 1)
                      .append(" HP:").append((int) bot.getHealth()).append("/").append((int) bot.getMaxHealth())
                      .append(bot.getTarget() != null ? " §cАТАКА" : " §7ожидание")
                      .append("\n");
                }
                if (squad != null) sb.append("§7Приказ: §f").append(squad.currentOrder.name());
                player.sendSystemMessage(Component.literal(sb.toString()));
            }
            case "help" -> {
                player.sendSystemMessage(Component.literal(
                    "§e§l⚔ ChatCommands (PVPBot):\n" +
                    "§f!attack [ник]  §7— атаковать (всех / конкретного)\n" +
                    "§f!retreat       §7— отступить\n" +
                    "§f!stand         §7— стоять, держать позицию\n" +
                    "§f!flank         §7— фланкировать цель\n" +
                    "§f!follow        §7— следовать за мной\n" +
                    "§f!surround      §7— окружить ближайшего врага\n" +
                    "§f!bots          §7— статус ботов\n" +
                    "§f!help          §7— эта справка"
                ));
            }
            default -> {
                // Неизвестная команда — игнорируем (не спамим чат)
            }
        }
    }

    private static void setForcedTargetByName(ServerPlayer player, List<BotEntity> bots, String nick) {
        if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
        net.minecraft.world.entity.player.Player target = sw.getPlayers(
            p -> p.getName().getString().equalsIgnoreCase(nick)
        ).stream().findFirst().orElse(null);
        if (target == null) {
            feedback(player, "§cИгрок не найден: §f" + nick);
            return;
        }
        for (BotEntity bot : bots) bot.getTargetPriority().setForcedTarget(target.getUUID());
    }

    private static net.minecraft.world.entity.LivingEntity findNearestEnemy(ServerPlayer player, double range) {
        if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return null;
        return sw.getPlayers(p ->
            !p.getUUID().equals(player.getUUID()) && !p.isSpectator() && !p.isCreative()
        ).stream()
         .filter(p -> p.distanceTo(player) <= range)
         .min(java.util.Comparator.comparingDouble(p -> p.distanceTo(player)))
         .orElse(null);
    }

    private static void feedback(ServerPlayer player, String msg) {
        player.sendSystemMessage(Component.literal("§e[PVPBot] " + msg));
    }
}
