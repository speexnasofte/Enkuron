package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * BotHunt — v16: активный поиск игроков по серверу.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Поведение:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В обычном режиме бот пассивно ждёт пока цель войдёт в диапазон.
 *  BotHunt делает бота «охотником»:
 *
 *  1. Каждые SCAN_INTERVAL тиков сканирует всех игроков на сервере
 *     в радиусе huntRange.
 *  2. Выбирает приоритетную цель (ближайшая, не в вайтлисте).
 *  3. Строит путь к цели через pathfind и бежит к ней.
 *  4. Если цель убежала за LOST_RANGE → сканируем снова.
 *  5. Если цели нет — бот патрулирует случайные точки вокруг себя.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Управление:
 * ══════════════════════════════════════════════════════════════════
 *
 *  /bot hunt on         — включить охоту
 *  /bot hunt off        — выключить
 *  /bot hunt range <N>  — радиус охоты в блоках
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class BotHunt {

    // ── Константы ─────────────────────────────────────────────────
    /** Тиков между сканированиями (~3 сек) */
    private static final int    SCAN_INTERVAL  = 60;
    /** Дистанция «потеряли цель» */
    private static final double LOST_RANGE     = 48.0;
    /** Радиус патруля если цели нет (блоков) */
    private static final double PATROL_RADIUS  = 16.0;
    /** Скорость движения при охоте */
    private static final double HUNT_SPEED     = 1.4;

    // ── Состояния ─────────────────────────────────────────────────
    public enum State { IDLE, HUNTING, CHASING, PATROL }
    private State state       = State.IDLE;
    private int   scanTimer   = 0;
    private int   patrolTimer = 0;

    private final BotEntity bot;

    public BotHunt(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик. Вызывать когда у бота нет текущей цели.
    //  @return true если бот занят охотой (продолжать тик навигации)
    // ══════════════════════════════════════════════════════════════
    public boolean tick() {
        if (!PVPBotConfig.INSTANCE.huntEnabled)            return false;
        if (!(bot.level() instanceof ServerLevel sw))   return false;

        // Если уже есть цель в BotEntity — охота не нужна
        if (bot.getTarget() != null && bot.getTarget().isAlive()) {
            state = State.CHASING;
            return false;
        }

        scanTimer++;

        switch (state) {
            case IDLE    -> { state = State.HUNTING; scanTimer = SCAN_INTERVAL; }
            case HUNTING -> tickHunting(sw);
            case CHASING -> tickChasing(sw);
            case PATROL  -> tickPatrol(sw);
            default: break;
        }

        return state != State.IDLE;
    }

    // ── HUNTING: сканируем и выбираем цель ────────────────────────
    private void tickHunting(ServerLevel sw) {
        if (scanTimer < SCAN_INTERVAL) return;
        scanTimer = 0;

        double range = PVPBotConfig.INSTANCE.huntRange;
        List<? extends Player> players = sw.getPlayers(p ->
            !p.isCreative() && !p.isSpectator()
            && bot.distanceTo(p) <= range
            && isValidTarget(p)
        );

        if (players.isEmpty()) {
            // Нет игроков — патрулируем
            state = State.PATROL;
            patrolTimer = 0;
            return;
        }

        // Ближайший игрок
        Player closest = players.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);

        if (closest != null) {
            // Устанавливаем как цель BotEntity
            bot.setTarget(closest);
            state = State.CHASING;
            bot.getNotifier().send("§c🎯 Охота: нашёл " + closest.getName().getString()
                + " [" + (int) bot.distanceTo(closest) + "м]");
        }
    }

    // ── CHASING: движемся к цели ──────────────────────────────────
    private void tickChasing(ServerLevel sw) {
        var target = bot.getTarget();
        if (target == null || !target.isAlive()) {
            state = State.HUNTING;
            return;
        }

        double dist = bot.distanceTo(target);

        if (dist > LOST_RANGE) {
            // Потеряли цель
            bot.setTarget(null);
            state = State.HUNTING;
            scanTimer = SCAN_INTERVAL;
            bot.getNotifier().send("§7🎯 Цель потеряна — продолжаю охоту");
            return;
        }

        if (dist > 4.0) {
            bot.getNavigation().moveTo(target, HUNT_SPEED);
        }
        // Когда dist <= 4 — основная боевая логика в BotEntity.tick() возьмёт управление
    }

    // ── PATROL: бродим рандомно ───────────────────────────────────
    private void tickPatrol(ServerLevel sw) {
        patrolTimer--;

        // Каждые ~4 сек выбираем новую патрульную точку
        if (patrolTimer <= 0) {
            double angle = Math.random() * Math.PI * 2;
            double r     = PATROL_RADIUS * (0.5 + Math.random() * 0.5);
            double tx = bot.getX() + Math.cos(angle) * r;
            double tz = bot.getZ() + Math.sin(angle) * r;
            double ty = bot.getY();

            bot.getNavigation().moveTo(tx, ty, tz, 1.0);
            patrolTimer = 80 + (int) (Math.random() * 40);
        }

        // Каждые SCAN_INTERVAL тиков — сканируем снова
        if (scanTimer >= SCAN_INTERVAL) {
            state = State.HUNTING;
        }
    }

    // ── Проверить цель ────────────────────────────────────────────
    private boolean isValidTarget(Player p) {
        // Проверяем вайтлист
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (cfg.whitelistEnabled && cfg.whitelist.contains(p.getName().getString())) {
            return false;
        }
        // Не атакуем владельца и совладельцев
        if (bot.getOwnerUUID() != null) {
            if (p.getUUID().equals(bot.getOwnerUUID())) return false;
            if (MultiOwner.INSTANCE.canControl(bot.getOwnerUUID(), p.getUUID())) return false;
        }
        return true;
    }

    // ── Геттеры ───────────────────────────────────────────────────
    public State  getState()  { return state; }
    public boolean isActive() { return state != State.IDLE; }

    public void reset() {
        state     = State.IDLE;
        scanTimer = 0;
    }

    public String getStateLabel() {
        return switch (state) {
            case IDLE    -> "";
            case HUNTING -> "HUNT:SCAN";
            case CHASING -> "HUNT:CHASE";
            case PATROL  -> "HUNT:PATROL";
            default     -> "?";
        };
    }
}
