package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * ObsidianPlacer — размещает обсидиан (базу под кристаллы) вокруг цели.
 *
 * Используется CrystalBotLogic: сначала кладём обсидиан, потом ставим кристалл сверху.
 * Работает на серверной стороне через ServerLevel.setBlock().
 */
public class ObsidianPlacer {

    private int placeCooldown = 0;
    private static final int PLACE_INTERVAL = 8; // тиков между укладкой обсидиана

    public void tick(ServerLevel level, LivingEntity bot, LivingEntity target) {
        if (placeCooldown-- > 0) return;
        placeCooldown = PLACE_INTERVAL;

        BlockPos targetBase = target.blockPosition().below();
        BlockState obsidian  = Blocks.OBSIDIAN.defaultBlockState();
        BlockState air       = Blocks.AIR.defaultBlockState();

        // Ищем 4 позиции вокруг ног цели (крест) и кладём обсидиан
        int[] dxs = {0, 1, -1, 0};
        int[] dzs = {1, 0,  0, -1};

        double botDist = bot.position().distanceTo(Vec3.atCenterOf(targetBase));
        if (botDist > 7.0) return; // слишком далеко — не тянемся

        for (int i = 0; i < 4; i++) {
            BlockPos obsPos = targetBase.offset(dxs[i], 0, dzs[i]);
            // Если уже обсидиан или бедрок — пропускаем
            var existing = level.getBlockState(obsPos).getBlock();
            if (existing == Blocks.OBSIDIAN || existing == Blocks.BEDROCK) continue;
            // Ставим обсидиан если блок воздушный или заменяемый
            if (level.getBlockState(obsPos).isAir() || level.getBlockState(obsPos).canBeReplaced()) {
                level.setBlock(obsPos, obsidian, 3);
                break; // в один тик — один блок, естественно
            }
        }
    }

    /** Проверить, есть ли хотя бы 1 обсидиан рядом с целью (для размещения кристалла). */
    public static boolean hasObsidianNear(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition().below();
        int[] dxs = {0, 1, -1, 0, 0};
        int[] dzs = {0, 1, -1, 0, 0}; // включая под ногами
        for (int i = 0; i < 5; i++) {
            BlockPos p = base.offset(dxs[i], 0, dzs[i]);
            if (level.getBlockState(p).getBlock() == Blocks.OBSIDIAN
             || level.getBlockState(p).getBlock() == Blocks.BEDROCK) {
                return true;
            }
        }
        return false;
    }
}
