package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * AxeLogic v3.0 — умный Axe PvP.
 * ИСПРАВЛЕНО:
 *  - Движение через Navigation (не deltaMovement)
 *  - Страф через StrafeAI (ограниченная скорость)
 *  - Перл → dashToTarget через Navigation
 *  - Щит в оффхенд всегда
 */
public class AxeLogic {

    private static final double MELEE_RANGE   = 3.2;
    private static final double IDEAL_DIST    = 2.6;
    private static final int    AXE_CD        = 20;
    private static final int    SHIELD_DIS_DUR= 100;
    private static final int    BURST_CD      = 8;
    private static final int    BURST_COUNT   = 3;
    private static final int    DASH_CD       = 70;
    private static final int    CRIT_EVERY    = 3;

    private final BotEntity bot;
    private final StrafeAI  strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd      = 0;
    private int dashCd        = 0;
    private int shieldDisabled= 0;
    private int burstHits     = 0;
    private int burstCd       = 0;
    private int hitCount      = 0;
    private boolean inBurst   = false;
    private boolean critPending= false;

    public AxeLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (attackCd      > 0) attackCd--;
        if (shieldDisabled> 0) shieldDisabled--;
        if (burstCd       > 0) burstCd--;
        if (dashCd        > 0) dashCd--;

        double dist = bot.distanceTo(target);
        equipAxe();
        equipShieldOffhand();

        // Сближение через navigation
        if (dist > IDEAL_DIST + 1.0) {
            bot.getNavigation().moveTo(target, 1.05);
            if (dist > 8 && dashCd <= 0) {
                bot.getNavigation().moveTo(target, 1.4);
                bot.setSprinting(true);
                dashCd = DASH_CD;
            }
        } else if (dist < IDEAL_DIST - 0.5) {
            bot.getNavigation().stop();
        }

        // Страф
        if (dist < MELEE_RANGE + 2.0) strafe.tick(target);

        if (dist > MELEE_RANGE) return;

        bot.getLookControl().setLookAt(target, 30f, 30f);

        boolean blocking = isTargetBlocking(target);

        // Shield break
        if (blocking && attackCd <= 0) {
            doAxeHit(sw, target, 9.0f, false);
            shieldDisabled = SHIELD_DIS_DUR;
            inBurst = true; burstHits = 0;
        } else if (shieldDisabled > 0 && inBurst) {
            doBurst(sw, target);
        } else if (!blocking && attackCd <= 0) {
            // Крит каждые CRIT_EVERY ударов
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAxeHit(sw, target, 9.0f, true); critPending = false;
            } else {
                doAxeHit(sw, target, 9.0f, false); critPending = false;
            }
        }
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, float dmg, boolean crit) {
        bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 6, 0.3,0.3,0.3,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.85f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
            bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled ? bot.getAdaptiveCooldown().getEffectiveCooldown() : AXE_CD;
    }

    private void doBurst(ServerLevel sw, LivingEntity target) {
        if (burstCd > 0) return;
        if (burstHits < BURST_COUNT) {
            doAxeHit(sw, target, 8.0f, false);
            burstCd = BURST_CD; burstHits++;
        } else {
            inBurst = false; burstHits = 0; attackCd = AXE_CD;
        }
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled > 0) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_AXE));
    }

    private void equipShieldOffhand() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }
}
