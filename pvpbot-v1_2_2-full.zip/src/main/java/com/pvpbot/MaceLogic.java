package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * MaceLogic v3.0 — умная булава.
 * ИСПРАВЛЕНО:
 *  - Dash через navigation (не setDeltaMovement для горизонтального движения)
 *  - Прыжок только через jumpControl (не setDeltaMovement Y)
 *  - После Smash гасим deltaMovement плавно, не обнуляем
 */
public class MaceLogic {

    private static final double SMASH_DIST     = 3.2;
    private static final double DASH_RANGE     = 7.0;
    private static final int    SMASH_CD       = 30;
    private static final int    DASH_CD        = 25;
    private static final float  SMASH_BASE     = 8.0f;
    private static final float  FALL_BONUS     = 1.5f;
    private static final float  MAX_DAMAGE     = 30.0f;

    private enum State { IDLE, JUMP_UP, FALLING, SMASH, COOLDOWN }
    private State state = State.IDLE;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int   smashCd   = 0;
    private int   dashCd    = 0;
    private double jumpStartY = 0;
    private double peakY      = 0;

    public MaceLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { state = State.IDLE; return; }

        if (smashCd > 0) smashCd--;
        if (dashCd  > 0) dashCd--;

        double dist = bot.distanceTo(target);
        equipMace();

        switch (state) {
            case IDLE     -> tickIdle(target, dist);
            case JUMP_UP  -> tickJumpUp();
            case FALLING  -> tickFalling(sw, target);
            case SMASH    -> tickSmash(sw, target);
            case COOLDOWN -> { if (smashCd <= 0) state = State.IDLE; }
            default: break;
        }

        // Dash через navigation если цель убегает
        if (state == State.IDLE && dist > DASH_RANGE && dashCd <= 0) {
            bot.getNavigation().moveTo(target, 1.3);
            bot.setSprinting(true);
            dashCd = DASH_CD;
        }

        // Страф в IDLE и после COOLDOWN
        if ((state == State.IDLE || state == State.COOLDOWN) && dist < SMASH_DIST + 3.0) {
            strafe.tick(target);
        }
    }

    private void tickIdle(LivingEntity target, double dist) {
        if (smashCd > 0) {
            // Пока кулдаун — идём к цели
            if (dist > 3.0) bot.getNavigation().moveTo(target, 1.0);
            return;
        }
        if (dist <= SMASH_DIST && bot.onGround()) {
            jumpStartY = bot.getY();
            peakY      = jumpStartY;
            // Прыжок через jumpControl (не setDeltaMovement)
            bot.getJumpControl().jump();
            state = State.JUMP_UP;
            bot.getNavigation().stop();
        } else {
            bot.getNavigation().moveTo(target, 1.0);
        }
    }

    private void tickJumpUp() {
        double y = bot.getY();
        if (y > peakY) peakY = y;
        // Начали падать → переходим в FALLING
        if (y < peakY - 0.15 || (!bot.onGround() && bot.getDeltaMovement().y < -0.05)) {
            state = State.FALLING;
        }
    }

    private void tickFalling(ServerLevel sw, LivingEntity target) {
        double dist    = bot.distanceTo(target);
        double vertDiff = bot.getY() - target.getY();
        if (vertDiff <= 1.8 && dist <= SMASH_DIST + 1.0) {
            state = State.SMASH; tickSmash(sw, target);
        } else if (bot.onGround()) {
            // Промахнулись
            state = State.COOLDOWN; smashCd = SMASH_CD / 2;
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        double fallBlocks = Math.max(0, peakY - bot.getY());
        float  damage     = Math.min(MAX_DAMAGE, SMASH_BASE + (float)(fallBlocks * FALL_BONUS));

        bot.getLookControl().setLookAt(target, 30f, 30f);
        bot.doHurtTarget(sw, target);

        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(kb.x * 1.5, 1.2, kb.z * 1.5);

        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 12,0.4,0.4,0.4,0.2);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);

        // Плавное торможение (не обнуляем)
        Vec3 v = bot.getDeltaMovement();
        bot.setDeltaMovement(v.x * 0.3, Math.max(v.y, 0), v.z * 0.3);

        smashCd = SMASH_CD; state = State.COOLDOWN;
    }

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
    }

    public boolean isSmashing() { return state == State.JUMP_UP || state == State.FALLING || state == State.SMASH; }
    public String getStateLabel() {
        return switch (state) {
            case IDLE     -> "MACE:IDLE";
            case JUMP_UP  -> "MACE:JUMP";
            case FALLING  -> "MACE:FALL";
            case SMASH    -> "MACE:SMASH";
            case COOLDOWN -> "MACE:CD";
            default     -> "?";
        };
    }
}
