package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * NethPotLogic v4.0 — MCTiers Diamond Pot И Netherite OP.
 *
 * Diamond Pot kit:  Diamond Prot4, Diamond Sword Sharp5+Sweep3
 *   Хотбар: 8x Splash Healing II + Strength II + Speed II + Regen(long)
 *
 * NethOP kit:       Netherite Prot4+Mend, Netherite Sword Sharp5+Sweep3
 *   Хотбар: 5x Splash Healing II + Strength II + Speed II, Golden Apple 64, Totem
 *
 * Тактика:
 *  - Бросает зелья лечения под себя когда < 10 HP
 *  - Бросает зелье вреда/harming на цель
 *  - Strength II + Speed II в начале боя
 *  - Рег/Абсорбция при критически низком HP
 *  - Крит-удары мечом между разливами
 */
public class NethPotLogic {

    private static final double SPLASH_RANGE   = 4.5;
    private static final double MELEE_RANGE    = 3.0;
    private static final double OPTIMAL_SPLASH = 2.8;
    private static final int    HARMING_CD     = 35;
    private static final int    HEALING_CD     = 40;
    private static final int    SPEED_CD       = 400;
    private static final int    STR_CD         = 400;
    private static final int    REGEN_CD       = 500;
    private static final int    FIRE_RES_CD    = 600;
    private static final int    RETREAT_CD     = 200;
    private static final int    MELEE_CD       = 8;
    private static final int    CRIT_EVERY     = 4;

    // Режим: true = NethOP (нетерит), false = Diamond Pot
    private final boolean isNethOP;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int harmingCd = 0, healingCd = 0, speedCd = 0, strCd = 0;
    private int regenCd   = 0, fireResCd = 0, retreatCd = 0, meleeCd = 0;
    private int hitCount  = 0;
    private boolean critPending = false;

    public NethPotLogic(BotEntity bot) {
        this.bot = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        // Определяем режим по текущему киту
        BotKit kit = cfg.currentKit;
        this.isNethOP = (kit == BotKit.NETHOP);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (harmingCd > 0) harmingCd--;
        if (healingCd > 0) healingCd--;
        if (speedCd   > 0) speedCd--;
        if (strCd     > 0) strCd--;
        if (regenCd   > 0) regenCd--;
        if (fireResCd > 0) fireResCd--;
        if (retreatCd > 0) retreatCd--;
        if (meleeCd   > 0) meleeCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Speed II в начале ─────────────────────────────────────
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }

        // ── Strength II ───────────────────────────────────────────
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1));
            strCd = STR_CD;
        }

        // ── Fire Resistance ───────────────────────────────────────
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }

        // ── Лечимся (Healing II + Regen при критическом HP) ───────
        if (myHp < 10.0f && healingCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 1)); // Instant Health II
            healingCd = HEALING_CD;
            throwHealingParticles(sw);
        }
        if (myHp < 6.0f && regenCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 0));
            regenCd = REGEN_CD;
            // Отступаем чтобы не получить урон во время лечения
            if (retreatCd <= 0) {
                Vec3 away = bot.position().subtract(target.position()).normalize();
                bot.getNavigation().moveTo(
                    bot.getX() + away.x * 7, bot.getY(), bot.getZ() + away.z * 7, 1.3
                );
                bot.setSprinting(true);
                retreatCd = RETREAT_CD;
                return;
            }
        }

        // ── Навигация + страф ─────────────────────────────────────
        if (dist < OPTIMAL_SPLASH + 1.0) strafe.tick(target);
        else bot.getNavigation().moveTo(target, 1.0);

        // ── Зелье вреда на врага ──────────────────────────────────
        if (dist <= SPLASH_RANGE && harmingCd <= 0) {
            boolean slow = target.getDeltaMovement().horizontalDistanceSqr() < 0.04;
            if (dist <= OPTIMAL_SPLASH || slow) {
                throwHarming(sw, target);
                harmingCd = HARMING_CD;
            }
        }

        // ── Меч между разливами ───────────────────────────────────
        if (dist <= MELEE_RANGE && meleeCd <= 0 && harmingCd > 5) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            equipSword();
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; meleeCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                if (target != null && target.isAlive()) bot.doHurtTarget(target);
                sw.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY()+1, target.getZ(), 5,0.2,0.2,0.2,0.1);
                hitCount++; critPending = false; meleeCd = MELEE_CD;
            } else {
                if (target != null && target.isAlive()) bot.doHurtTarget(target);
                hitCount++; critPending = false; meleeCd = MELEE_CD;
            }
        }
    }

    private void throwHarming(ServerLevel sw, LivingEntity target) {
        if (target != null && target.isAlive()) target.hurt(sw.damageSources().magic(), 12.0f);
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(target.position(), target.position()).inflate(2.0),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().magic(), 6.0f));
        sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
            target.getX(), target.getY()+1, target.getZ(), 16, 0.5,0.5,0.5,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 1.0f, 1.2f);
    }

    private void throwHealingParticles(ServerLevel sw) {
        sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
            bot.getX(), bot.getY()+1, bot.getZ(), 10, 0.3,0.3,0.3,0.05);
        bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 0.8f, 1.4f);
    }

    private void equipSword() {
        // Diamond Pot → Diamond Sword; NethOP → Netherite Sword
        var sword = isNethOP ? Items.NETHERITE_SWORD : Items.DIAMOND_SWORD;
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(sword))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(sword));
    }
}
