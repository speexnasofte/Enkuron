package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * SwordLogic v4.0 — MCTiers Sword PvP.
 *
 * Kit: Diamond Prot4, Diamond Sword (Unbreaking3)
 *
 * Тактика:
 *  - W-tap + S-tap кринжовые удары
 *  - Критические удары каждые N ударов (прыжок)
 *  - Страф ZIGZAG/CIRCLE
 *  - Лук на дальней дистанции (>7 блоков)
 *  - НЕТ оффхенда (MCTiers Sword нет щита)
 */
public class SwordLogic {

    private static final double MELEE_RANGE = 3.2;
    private static final double IDEAL_DIST  = 2.4;
    private static final double BOW_RANGE   = 7.0;
    private static final int    WTAP_TICKS  = 2;
    private static final int    CRIT_EVERY  = 3;
    private static final int    BOW_CD      = 20;
    private static final double NAV_SPEED   = 1.05;

    private int     attackCd    = 0;
    private int     wTapPause   = 0;
    private int     hitCount    = 0;
    private int     bowCd       = 0;
    private boolean critPending = false;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public SwordLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(switch (cfg.difficulty) {
            case EASY   -> StrafeAI.StrafeStyle.RANDOM;
            case MEDIUM -> StrafeAI.StrafeStyle.CIRCLE;
            case HARD, EXPERT -> StrafeAI.StrafeStyle.ZIGZAG;
            default     -> StrafeAI.StrafeStyle.CIRCLE;
        });
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        if (attackCd  > 0) attackCd--;
        if (wTapPause > 0) wTapPause--;
        if (bowCd     > 0) bowCd--;

        double dist = bot.distanceTo(target);

        // ── Лук на дальней дистанции ──────────────────────────────
        if (dist > BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW, bot.level().registryAccess()).enchant("power", 5).enchant("unbreaking", 3).build());
            bot.getLookControl().setLookAt(target, 60f, 60f);
            float dmg = (float) Math.max(1.5, 9.0 - dist * 0.3);
            if (target != null && target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            bowCd = BOW_CD;
            return;
        }

        // ── Diamond Sword ─────────────────────────────────────────
        equipSword();

        // ── Навигация ─────────────────────────────────────────────
        if (dist > IDEAL_DIST + 0.8)
            bot.getNavigation().moveTo(target, NAV_SPEED);
        else if (dist < IDEAL_DIST - 0.5)
            bot.getNavigation().stop();

        // ── Страф ─────────────────────────────────────────────────
        if (dist < MELEE_RANGE + 3.0) strafe.tick(target);

        // ── W-tap пауза ───────────────────────────────────────────
        if (wTapPause > 0) { bot.getNavigation().stop(); return; }

        // ── Атака ─────────────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAttack(sw, target, true);
                critPending = false;
            } else if (!doCrit) {
                doAttack(sw, target, false);
                critPending = false;
            }
        }
    }

    private void doAttack(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target != null && target.isAlive()) bot.doHurtTarget(target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 6, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;
        if (cfg.wTapEnabled) wTapPause = WTAP_TICKS;
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.DIAMOND_SWORD, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("unbreaking", 3).build());
    }
}
