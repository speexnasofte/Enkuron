package com.pvpbot.client;

import com.pvpbot.BotEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * BotEntityRenderer — совместимая версия для 1.21.1 (без HumanoidRenderState).
 */
@SuppressWarnings("unchecked")
public class BotEntityRenderer extends HumanoidMobRenderer<BotEntity, HumanoidModel<BotEntity>> {

    private static final ResourceLocation STEVE_TEXTURE =
        ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/player/wide/steve.png");

    public BotEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)),
            0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(BotEntity entity) {
        return STEVE_TEXTURE;
    }
}
