package dev.duelforge;

import dev.duelforge.local.BotAction;
import dev.duelforge.local.BotEntity;
import dev.duelforge.local.LocalKit;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Duelforge: common entrypoint. Registers the server-side Controller bot (works in singleplayer and on servers that
 * have the mod). The Lab part (network bots) is client-only and lives in dev.duelforge.client.DuelforgeClient.
 */
public class DuelforgeMod implements ModInitializer {
    public static final String ID = "duelforge";
    public static final int MAX_BOTS = 4;

    private static final ResourceKey<EntityType<?>> BOT_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(ID, "bot"));
    public static final EntityType<BotEntity> BOT = Registry.register(BuiltInRegistries.ENTITY_TYPE, BOT_KEY,
            EntityType.Builder.of(BotEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build(BOT_KEY));

    @Override
    public void onInitialize() {
        dev.duelforge.stepan.StepanBootstrap.init();   // ported PVP Bot (Stepan1411, Unlicense)
        // ATTACK_DAMAGE is not part of Mob.createMobAttributes(): without it MeleeAttackGoal throws on the first hit
        FabricDefaultAttributeRegistry.register(BOT, Mob.createMobAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 3.0)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 32.0));
        PayloadTypeRegistry.playC2S().register(BotAction.TYPE, BotAction.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BotAction.TYPE, (payload, ctx) -> handle(ctx.player(), payload.action()));
    }

    private static void handle(ServerPlayer player, String action) {
        if (!(player.level() instanceof ServerLevel level)) return;
        List<? extends BotEntity> bots = level.getEntities(BOT, bot -> bot.isOwnedBy(player.getUUID()));

        LocalKit kit = LocalKit.byId(action);
        if (kit != null) { bots.forEach(kit::equip); return; }

        switch (action) {
            case "spawn" -> {
                if (bots.size() >= MAX_BOTS) return;
                BotEntity bot = BOT.create(level, EntitySpawnReason.COMMAND);
                if (bot == null) return;
                bot.setOwner(player.getUUID());
                bot.setPersistenceRequired();
                bot.setPos(player.getX() + 2, player.getY(), player.getZ());
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
                bot.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                level.addFreshEntity(bot);
            }
            case "follow" -> bots.forEach(bot -> bot.setFollowing(true));
            case "attack" -> bots.forEach(bot -> { bot.setFollowing(false); bot.setTarget(player); });
            case "clear" -> bots.forEach(bot -> { bot.setFollowing(false); bot.setTarget(null); });
            case "tier_1", "tier_2", "tier_3", "tier_4", "tier_5" -> {
                int tier = action.charAt(action.length() - 1) - '0';
                bots.forEach(bot -> bot.setTier(tier));
            }
            case "despawn" -> bots.forEach(bot -> bot.discard());
            default -> { }
        }
    }
}
