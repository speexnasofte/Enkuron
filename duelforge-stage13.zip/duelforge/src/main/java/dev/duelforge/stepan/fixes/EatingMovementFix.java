package dev.duelforge.stepan.fixes;

import net.minecraft.server.level.ServerPlayer;

import dev.duelforge.stepan.bot.BotUtils;

public class EatingMovementFix {

    public static void apply(ServerPlayer bot) {
        var state = BotUtils.getState(bot.getName().getString());
        if (!state.isEating) return;

        bot.setSprinting(false);

        bot.forwardSpeed *= 0.2f;
        bot.sidewaysSpeed *= 0.2f;

        var vel = bot.getDeltaMovement();
        bot.setDeltaMovement(vel.x * 0.8, vel.y, vel.z * 0.8);
    }
}
