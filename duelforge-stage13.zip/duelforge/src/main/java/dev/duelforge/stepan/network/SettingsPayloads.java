package dev.duelforge.stepan.network;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Settings sync packets of the ported PVP Bot (namespace "duelforge", see BotPayloads). */
public class SettingsPayloads {
    private static Identifier id(String path) { return Identifier.fromNamespaceAndPath("duelforge", path); }

    public record SettingsRequestPayload() implements CustomPacketPayload {
        public static final Type<SettingsRequestPayload> ID = new Type<>(id("pvpbot_settings_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SettingsRequestPayload> CODEC =
                StreamCodec.unit(new SettingsRequestPayload());
        @Override public Type<SettingsRequestPayload> type() { return ID; }
    }

    /** Map is sent as two parallel lists (keys, values). */
    public record SettingsResponsePayload(Map<String, String> settings) implements CustomPacketPayload {
        public static final Type<SettingsResponsePayload> ID = new Type<>(id("pvpbot_settings_response"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SettingsResponsePayload> CODEC = StreamCodec.composite(
                BotPayloads.STRING_LIST, p -> new ArrayList<>(p.settings().keySet()),
                BotPayloads.STRING_LIST, p -> new ArrayList<>(p.settings().values()),
                SettingsResponsePayload::build);

        static SettingsResponsePayload build(List<String> keys, List<String> values) {
            Map<String, String> map = new LinkedHashMap<>();
            for (int i = 0; i < keys.size() && i < values.size(); i++) map.put(keys.get(i), values.get(i));
            return new SettingsResponsePayload(Collections.unmodifiableMap(map));
        }

        @Override public Type<SettingsResponsePayload> type() { return ID; }
    }

    public record SettingsUpdatePayload(String key, String value) implements CustomPacketPayload {
        public static final Type<SettingsUpdatePayload> ID = new Type<>(id("pvpbot_settings_update"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SettingsUpdatePayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.STRING_UTF8, SettingsUpdatePayload::key,
                ByteBufCodecs.STRING_UTF8, SettingsUpdatePayload::value,
                SettingsUpdatePayload::new);
        @Override public Type<SettingsUpdatePayload> type() { return ID; }
    }
}
