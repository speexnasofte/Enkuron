package dev.duelforge.stepan.mixin;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets herobot fake players join a "full" server. Only active when herobot is installed. */
@Mixin(PlayerList.class)
public class ServerConfigHandlerMixin {

    @Inject(method = "getMaxPlayers", at = @At("RETURN"), cancellable = true, require = 0)
    private void duelforge$increaseMaxPlayers(CallbackInfoReturnable<Integer> cir) {
        if (FabricLoader.getInstance().isModLoaded("herobot")) cir.setReturnValue(99999);
    }
}
