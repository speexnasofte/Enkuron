package dev.duelforge.stepan;

import dev.duelforge.stepan.bot.BotCombat;
import dev.duelforge.stepan.bot.BotKits;
import dev.duelforge.stepan.bot.BotPath;
import dev.duelforge.stepan.bot.BotManager;
import dev.duelforge.stepan.bot.BotNavigation;
import dev.duelforge.stepan.bot.BotTicker;
import dev.duelforge.stepan.bot.BotUtils;
import dev.duelforge.stepan.command.BotCommand;
import dev.duelforge.stepan.config.WorldConfigHelper;
import dev.duelforge.stepan.network.BotPayloads;
import dev.duelforge.stepan.network.BotSettingsReader;
import dev.duelforge.stepan.network.BotSettingsUpdater;
import dev.duelforge.stepan.network.SettingsPayloads;
import java.util.ArrayList;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

/**
 * Server-side wiring of the ported PVP Bot (pvp-bot-fabric by Stepan1411, Unlicense).
 * Anonymous stats reporting is deliberately NOT started (StatsReporter.init is not called).
 */
public final class StepanBootstrap {
    private StepanBootstrap() {}

    public static void init() {
        // per-bot state of the AI modules is dropped when a bot is removed
        BotManager.addRemoveListener(BotCombat::removeState);
        BotManager.addRemoveListener(BotUtils::removeState);
        BotManager.addRemoveListener(BotNavigation::removeState);
        BotManager.addRemoveListener(BotNavigation::resetIdle);

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            WorldConfigHelper.init(server);
            BotKits.init(server);
            BotPath.init();
            BotManager.init(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            BotManager.updateBotData(server);
            BotManager.saveBots();
            BotManager.reset(server);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> BotCommand.register(dispatcher));
        registerPayloads();

        BotTicker.register();   // per-bot AI tick, cleanup of dead bots and autosave
    }

    private static void registerPayloads() {
        PayloadTypeRegistry.playC2S().register(SettingsPayloads.SettingsRequestPayload.ID, SettingsPayloads.SettingsRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SettingsPayloads.SettingsUpdatePayload.ID, SettingsPayloads.SettingsUpdatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BotPayloads.BotListRequestPayload.ID, BotPayloads.BotListRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BotPayloads.BotActionPayload.ID, BotPayloads.BotActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SettingsPayloads.SettingsResponsePayload.ID, SettingsPayloads.SettingsResponsePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(BotPayloads.BotListResponsePayload.ID, BotPayloads.BotListResponsePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SettingsPayloads.SettingsRequestPayload.ID, (payload, context) ->
                ServerPlayNetworking.send(context.player(), new SettingsPayloads.SettingsResponsePayload(BotSettingsReader.readAll())));
        ServerPlayNetworking.registerGlobalReceiver(SettingsPayloads.SettingsUpdatePayload.ID, (payload, context) ->
                BotSettingsUpdater.update(payload.key(), payload.value()));
        ServerPlayNetworking.registerGlobalReceiver(BotPayloads.BotListRequestPayload.ID, (payload, context) ->
                ServerPlayNetworking.send(context.player(), new BotPayloads.BotListResponsePayload(new ArrayList<>(BotManager.getAllBots()))));
        ServerPlayNetworking.registerGlobalReceiver(BotPayloads.BotActionPayload.ID, (payload, context) -> {
            var server = context.server();
            var source = server.createCommandSourceStack();
            var dispatcher = server.getCommands().getDispatcher();
            String botName = payload.botName();
            try {
                switch (payload.action()) {
                    case "remove" -> dispatcher.execute("pvpbot remove " + botName, source);
                    case "attack" -> dispatcher.execute("pvpbot bot-management attack " + botName + " " + botName, source);
                    default -> context.player().sendSystemMessage(Component.literal("Unknown action: " + payload.action()));
                }
            } catch (Exception e) {
                System.out.println("[Duelforge/PVP Bot] Failed to execute bot action '" + payload.action() + "' for '" + botName + "': " + e.getMessage());
            }
        });
    }
}
