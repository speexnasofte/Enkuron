package dev.duelforge.stepan.utils;

import net.minecraft.world.entity.player.Inventory;

/**
 * Selected hotbar slot accessors. Plain calls (no reflection): reflection by Mojang names would break on a
 * production game, which runs with intermediary names. Needs Inventory#getSelectedSlot/setSelectedSlot (1.21.5+).
 */
public class InventoryHelper {
    public static void setSelectedSlot(Inventory inventory, int slot) {
        inventory.setSelectedSlot(slot);
    }

    public static int getSelectedSlot(Inventory inventory) {
        return inventory.getSelectedSlot();
    }
}
