package dev.duelforge.stepan.bot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import dev.duelforge.stepan.config.WorldConfigHelper;
import dev.duelforge.stepan.fixes.ProfileLagFix;


import dev.duelforge.stepan.stats.StatsReporter;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BotManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Set<String> bots = new HashSet<>();
    private static final Map<String, BotData> botDataMap = new HashMap<>();
    private static final Map<String, Integer> nullTickCount = new HashMap<>();
    private static final int MAX_NULL_TICKS = 5;
    private static Path savePath;

    /** Listeners (combat / utils / navigation state) that must forget a bot when it is removed. Ported modules register here. */
    private static final java.util.List<java.util.function.Consumer<String>> removeListeners = new java.util.concurrent.CopyOnWriteArrayList<>();

    public static void addRemoveListener(java.util.function.Consumer<String> listener) { removeListeners.add(listener); }

    private static void fireRemoved(String name) {
        for (var l : removeListeners) {
            try { l.accept(name); } catch (Exception ignored) { }
        }
    }

    /** "ResourceKey[minecraft:dimension / minecraft:overworld]" -> "minecraft:overworld" (independent of mapping renames). */
    static String dimensionId(String resourceKeyToString) {
        int i = resourceKeyToString.lastIndexOf(" / ");
        int j = resourceKeyToString.lastIndexOf(']');
        return (i >= 0 && j > i) ? resourceKeyToString.substring(i + 3, j) : resourceKeyToString;
    }
    private static boolean initialized = false;

    public static class BotData {
        public String name;
        public double x, y, z;
        public float yaw, pitch;
        public String dimension;
        public String gamemode;
        
        public BotData() {}
        
        public BotData(ServerPlayer bot) {
            this.name = bot.getName().getString();
            this.x = bot.getX();
            this.y = bot.getY();
            this.z = bot.getZ();
            this.yaw = bot.getYRot();
            this.pitch = bot.getXRot();
            this.dimension = dimensionId(bot.level().dimension().toString());
            this.gamemode = bot.gameMode.getGameModeForPlayer().getName();
        }
    }
    
    public static void init(MinecraftServer server) {
        if (initialized) return;
        

        bots.clear();
        botDataMap.clear();
        
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve("duelforge").resolve("pvpbot");
        try {
            Files.createDirectories(configDir);
        } catch (Exception e) {
            System.out.println("[Duelforge/PVP Bot] Failed to create config directory: " + e.getMessage());
        }
        
        savePath = dev.duelforge.stepan.config.WorldConfigHelper.getWorldConfigDir().resolve("bots.json");
        loadBots();
        BotSettings settings = BotSettings.get();
        if (settings.isBotsRelogs() && !botDataMap.isEmpty()) {
            System.out.println("[Duelforge/PVP Bot] Restoring " + botDataMap.size() + " bots...");
            Map<String, BotData> botsToRestore = new HashMap<>(botDataMap);
            bots.clear();
            botDataMap.clear();
            server.execute(() -> restoreBotsDelayed(server, botsToRestore, 0));
        } else if (!settings.isBotsRelogs()) {
            bots.clear();
            botDataMap.clear();
            saveBots();
        }
        
        initialized = true;
    }
    
    private static void restoreBotsDelayed(MinecraftServer server, Map<String, BotData> botsToRestore, int index) {
        restoreBotsDelayedWithRetry(server, botsToRestore, index, 0);
    }
    
    private static void restoreBotsDelayedWithRetry(MinecraftServer server, Map<String, BotData> botsToRestore, int index, int retryCount) {
        final int MAX_RETRIES = 2;
        
        if (index >= botsToRestore.size()) {
            System.out.println("[Duelforge/PVP Bot] Restored " + bots.size() + " bots");
            return;
        }
        
        String[] names = botsToRestore.keySet().toArray(new String[0]);
        if (index < names.length) {
            String name = names[index];
            BotData data = botsToRestore.get(name);
            ServerPlayer existingPlayer = server.getPlayerList().getPlayerByName(name);
            if (existingPlayer != null && !bots.contains(name)) {
                System.out.println("[Duelforge/PVP Bot] Skipping bot '" + name + "': real player with this name is online");
                final int nextIndex = index + 1;
                server.execute(() -> restoreBotsDelayedWithRetry(server, botsToRestore, nextIndex, 0));
                return;
            }
            var dispatcher = server.getCommands().getDispatcher();
            boolean success = false;
            
            if (BotSettings.get().isProfileLagFix()) ProfileLagFix.preloadProfileCache(server, name);
            try {
                String command = String.format(java.util.Locale.US,
                    "playerspawn %s at %.2f %.2f %.2f facing %.2f %.2f in %s on %s",
                    name, data.x, data.y, data.z, data.yaw, data.pitch,
                    data.gamemode != null ? data.gamemode : "survival",
                    data.dimension
                );
                if (retryCount == 0) {
                    System.out.println("[Duelforge/PVP Bot] Restoring bot: " + name);
                } else {
                    System.out.println("[Duelforge/PVP Bot] Retry #" + retryCount + " for bot: " + name);
                }
                dispatcher.execute(command, server.createCommandSourceStack());
                
                bots.add(name);
                botDataMap.put(name, data);
                success = true;
                System.out.println("[Duelforge/PVP Bot] Successfully restored bot: " + name);
            } catch (Exception e) {

                try {
                    String simpleCommand = String.format(java.util.Locale.US,
                        "playerspawn %s at %.2f %.2f %.2f",
                        name, data.x, data.y, data.z
                    );
                    dispatcher.execute(simpleCommand, server.createCommandSourceStack());
                    bots.add(name);
                    botDataMap.put(name, data);
                    success = true;
                    System.out.println("[Duelforge/PVP Bot] Restored bot with simple command: " + name);
                } catch (Exception e2) {
                    if (retryCount < MAX_RETRIES) {
                        System.out.println("[Duelforge/PVP Bot] Failed to restore bot '" + name + "', will retry... (" + (retryCount + 1) + "/" + MAX_RETRIES + ")");
                    } else {
                        System.out.println("[Duelforge/PVP Bot] Failed to restore bot '" + name + "' after " + (MAX_RETRIES + 1) + " attempts: " + e2.getMessage());
                    }
                }
            }
            

            if (!success && retryCount < MAX_RETRIES) {
                final int currentRetry = retryCount + 1;
                server.execute(() -> {
                    final int[] delay = {0};
                    server.execute(new Runnable() {
                        @Override
                        public void run() {
                            delay[0]++;
                            if (delay[0] < 20) {
                                server.execute(this);
                            } else {
                                restoreBotsDelayedWithRetry(server, botsToRestore, index, currentRetry);
                            }
                        }
                    });
                });
            } else {

                final int nextIndex = index + 1;
                server.execute(() -> {
                    final int[] delay = {0};
                    server.execute(new Runnable() {
                        @Override
                        public void run() {
                            delay[0]++;
                            if (delay[0] < 10) {
                                server.execute(this);
                            } else {
                                restoreBotsDelayedWithRetry(server, botsToRestore, nextIndex, 0);
                            }
                        }
                    });
                });
            }
        }
    }
    
    
    public static void updateBotData(MinecraftServer server) {
        int updated = 0;
        int skipped = 0;
        int missing = 0;
        for (String name : bots) {
            ServerPlayer bot = server.getPlayerList().getPlayerByName(name);
            if (bot != null && bot.isAlive()) {

                botDataMap.put(name, new BotData(bot));
                updated++;
            } else if (!botDataMap.containsKey(name)) {


                missing++;
                System.out.println("[Duelforge/PVP Bot] WARNING: Bot " + name + " in list but has no data!");
            } else {

                skipped++;
            }
        }

    }
    
    
    public static void saveBots() {
        if (savePath == null) return;
        
        try (Writer writer = Files.newBufferedWriter(savePath)) {
            GSON.toJson(botDataMap, writer);
        } catch (Exception e) {
            System.out.println("[Duelforge/PVP Bot] Failed to save bots: " + e.getMessage());
        }
    }
    
    
    private static void loadBots() {
        if (savePath == null || !Files.exists(savePath)) {
            return;
        }
        
        try (Reader reader = Files.newBufferedReader(savePath)) {
            Map<String, BotData> loaded = GSON.fromJson(reader, new TypeToken<Map<String, BotData>>(){}.getType());
            if (loaded != null) {
                botDataMap.putAll(loaded);
                bots.addAll(loaded.keySet());
            }
        } catch (Exception e) {
            System.out.println("[Duelforge/PVP Bot] Failed to load bots: " + e.getMessage());
        }
    }
    
    
    public static void reset(MinecraftServer server) {
        updateBotData(server);
        saveBots();
        initialized = false;
    }
    
    public static void switchWorld(MinecraftServer server) {

        updateBotData(server);
        saveBots();

        bots.clear();
        botDataMap.clear();


        savePath = dev.duelforge.stepan.config.WorldConfigHelper.getWorldConfigDir().resolve("bots.json");


        loadBots();


        BotSettings settings = BotSettings.get();
        if (settings.isBotsRelogs() && !botDataMap.isEmpty()) {
            System.out.println("[Duelforge/PVP Bot] Switching world, restoring " + botDataMap.size() + " bots...");
            Map<String, BotData> botsToRestore = new HashMap<>(botDataMap);
            bots.clear();
            botDataMap.clear();

            server.execute(() -> restoreBotsDelayed(server, botsToRestore, 0));
        }
    }


    public static boolean spawnBot(MinecraftServer server, String name, CommandSourceStack source) {
        return spawnBot(server, name, source, null);
    }

    public static boolean spawnBot(MinecraftServer server, String name, CommandSourceStack source, Vec3 pos) {
        boolean isNewBot = !bots.contains(name);

        ServerPlayer existingPlayer = server.getPlayerList().getPlayerByName(name);
        if (existingPlayer != null && existingPlayer.isAlive()) {

            if (!bots.contains(name)) {
                bots.add(name);
                botDataMap.put(name, new BotData(existingPlayer));
                saveBots();
                System.out.println("[Duelforge/PVP Bot] Added existing bot to list: " + name);
            }
            return false;
        }

        // /pvpbot spawn creates fake players through herobot's `playerspawn` command; without that mod the command does not exist
        if (!net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("herobot")) {
            try { source.sendFailure(net.minecraft.network.chat.Component.literal("Для /pvpbot spawn нужен мод herobot (он создаёт игроков-ботов). Без него используй Контроллер или сетевых ботов Lab.")); } catch (RuntimeException ignored) { }
            System.out.println("[Duelforge/PVP Bot] spawn '" + name + "' skipped: herobot is not installed");
            return false;
        }

        var dispatcher = server.getCommands().getDispatcher();
        if (BotSettings.get().isProfileLagFix()) ProfileLagFix.preloadProfileCache(server, name);
        try {
            String coords = (pos != null)
                ? pos.x + " " + pos.y + " " + pos.z
                : "~ ~ ~";
            dispatcher.execute("playerspawn " + name + " at " + coords + " facing 0 0 in survival", source);
        } catch (Exception e) {

            try {
                dispatcher.execute("playerspawn " + name, source);

                dispatcher.execute("gamemode survival " + name, server.createCommandSourceStack());
            } catch (Exception e2) {

            }
        }



        server.execute(() -> {
            ServerPlayer newBot = server.getPlayerList().getPlayerByName(name);
            if (newBot != null && !bots.contains(name)) {
                bots.add(name);
                botDataMap.put(name, new BotData(newBot));
                saveBots();
                System.out.println("[Duelforge/PVP Bot] Added bot to list (delayed): " + name);
                

            } else if (newBot != null && bots.contains(name)) {

                botDataMap.put(name, new BotData(newBot));
                saveBots();
                System.out.println("[Duelforge/PVP Bot] Updated bot data (delayed): " + name);
            }
        });
        

        ServerPlayer newBot = server.getPlayerList().getPlayerByName(name);
        if (newBot != null) {
            if (!bots.contains(name)) {
                bots.add(name);
                botDataMap.put(name, new BotData(newBot));
                saveBots();
                System.out.println("[Duelforge/PVP Bot] Added bot to list (immediate): " + name);
                StatsReporter.sendSpawn(name);

            }
            return true;
        }
        

        if (!bots.contains(name)) {
            bots.add(name);
            StatsReporter.sendSpawn(name);

            BotData defaultData = new BotData();
            defaultData.name = name;
            defaultData.x = source.getPosition().x;
            defaultData.y = source.getPosition().y;
            defaultData.z = source.getPosition().z;
            defaultData.yaw = source.getRotation().y;
            defaultData.pitch = source.getRotation().x;
            defaultData.dimension = dimensionId(source.getLevel().dimension().toString());
            defaultData.gamemode = "survival";
            botDataMap.put(name, defaultData);
            saveBots();
            System.out.println("[Duelforge/PVP Bot] Added bot to list (default data): " + name);
        }
        
        return true;
    }

    public static boolean removeBot(MinecraftServer server, String name, CommandSourceStack source) {

        boolean wasInList = bots.remove(name);
        botDataMap.remove(name);
        saveBots();
        if (wasInList) StatsReporter.sendKill();
        

        fireRemoved(name);
        
        var dispatcher = server.getCommands().getDispatcher();
        if (BotSettings.get().isClearOnRemove()) {
            try {
                dispatcher.execute("clear " + name, server.createCommandSourceStack());
            } catch (Exception e) { }
        }
        String command = "player " + name + " kill";
        try {
            dispatcher.execute(command, source);
        } catch (Exception e) {

        }
        

        
        return wasInList;
    }

    public static ServerPlayer getBot(MinecraftServer server, String name) {
        return server.getPlayerList().getPlayerByName(name);
    }

    public static void removeAllBots(MinecraftServer server, CommandSourceStack source) {
        var dispatcher = server.getCommands().getDispatcher();
        int count = bots.size();
        boolean clear = BotSettings.get().isClearOnRemove();
        for (String name : new HashSet<>(bots)) {

            fireRemoved(name);
            
            if (clear) {
                try {
                    dispatcher.execute("clear " + name, server.createCommandSourceStack());
                } catch (Exception e) { }
            }

            String command = "player " + name + " kill";
            try {
                dispatcher.execute(command, source);
            } catch (Exception e) {

            }
        }
        bots.clear();
        botDataMap.clear();
        saveBots();
        for (int i = 0; i < count; i++) StatsReporter.sendKill();
        

    }

    public static int getBotCount() {
        return bots.size();
    }

    public static Set<String> getAllBots() {
        return new HashSet<>(bots);
    }
    
    public static void reloadBots() {
        bots.clear();
        botDataMap.clear();
        savePath = dev.duelforge.stepan.config.WorldConfigHelper.getWorldConfigDir().resolve("bots.json");
        loadBots();
    }
    
    
    public static void cleanupDeadBots(MinecraftServer server) {
        boolean changed = false;
        for (String name : new HashSet<>(bots)) {
            ServerPlayer bot = server.getPlayerList().getPlayerByName(name);

            if (bot == null) {
                int ticks = nullTickCount.getOrDefault(name, 0) + 1;
                nullTickCount.put(name, ticks);
                if (ticks >= MAX_NULL_TICKS) {
                    bots.remove(name);
                    botDataMap.remove(name);
                    fireRemoved(name);
                    nullTickCount.remove(name);
                    changed = true;
                    StatsReporter.sendKill();
                    System.out.println("[Duelforge/PVP Bot] Removed dead bot (entity gone): " + name);
                }
                continue;
            }

            nullTickCount.remove(name);
            boolean isDead = !bot.isAlive() || bot.getHealth() <= 0 || bot.isDeadOrDying();
            if (isDead) {
                bots.remove(name);
                botDataMap.remove(name);
                fireRemoved(name);
                StatsReporter.sendKill();


                try {
                    var dispatcher = server.getCommands().getDispatcher();
                    dispatcher.execute("player " + name + " kill", server.createCommandSourceStack());
                } catch (Exception e) {
                    System.err.println("[Duelforge/PVP Bot] Error kicking dead bot: " + e.getMessage());
                }
                
                changed = true;
                System.out.println("[Duelforge/PVP Bot] Removed dead bot: " + name);
            }
        }
        if (changed) {
            saveBots();
        }
    }
}
