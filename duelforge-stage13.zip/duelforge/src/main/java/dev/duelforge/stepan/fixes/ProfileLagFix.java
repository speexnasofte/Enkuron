package dev.duelforge.stepan.fixes;

import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.NameAndId;

/**
 * Pre-fills the server's name->UUID cache for a bot name (offline UUID) so spawning does not stall on a Mojang lookup.
 * If the build complains about NameAndId / MinecraftServer#services(), delete the body: the fix is optional.
 */
public class ProfileLagFix {

    public static void preloadProfileCache(MinecraftServer server, String name) {
        try {
            var cache = server.services().nameToIdCache();
            if (cache != null) {
                UUID offlineUuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                cache.add(new NameAndId(offlineUuid, name));
            }
        } catch (Exception e) {
        }
    }
}
