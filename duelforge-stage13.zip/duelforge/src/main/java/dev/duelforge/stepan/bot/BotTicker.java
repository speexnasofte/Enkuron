package dev.duelforge.stepan.bot;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class BotTicker {

    private static int tickCounter = 0;
    private static int autoSaveCounter = 0;
    private static int heroBotCommandCounter = 0;
    private static int statsReportCounter = 0;
    private static final int AUTO_SAVE_INTERVAL = 1200;
    private static final int HERO_BOT_COMMAND_INTERVAL = 20;
    private static final int STATS_REPORT_INTERVAL = 100;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(BotTicker::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        tickCounter++;
        autoSaveCounter++;
        
        int interval = BotSettings.get().getCheckInterval();
        

        if (tickCounter % 10 == 0) {
            BotManager.cleanupDeadBots(server);

        }
        


        if (autoSaveCounter >= AUTO_SAVE_INTERVAL) {
            BotManager.updateBotData(server);
            BotManager.saveBots();
            autoSaveCounter = 0;
        }
        

        BotPathVisualizer.update(server);
        
        for (String botName : BotManager.getAllBots()) {
            ServerPlayer bot = BotManager.getBot(server, botName);
            if (bot != null && bot.isAlive()) {

                boolean isElytraMacing = BotCombat.isElytraMaceActive(botName);
                boolean isWindBursting = BotCombat.isWindBurstActive(botName);

                if (!isElytraMacing && !isWindBursting) {
                    BotUtils.update(bot, server);
                    dev.duelforge.stepan.fixes.EatingMovementFix.apply(bot);
                }

                boolean isFollowingWithoutAttack = BotPath.isFollowing(botName) && !BotPath.shouldAttack(botName);
                if (!isFollowingWithoutAttack) {
                    BotCombat.update(bot, server);
                }
                

                if (BotPath.isFollowing(botName)) {
                    boolean shouldAttack = BotPath.shouldAttack(botName);
                    var target = BotCombat.getTarget(botName);
                    boolean hasTarget = target != null && target.isAlive();
                    

                    if (shouldAttack && hasTarget) {
                        Vec3 nextPoint = BotPath.getNextPoint(botName);
                        

                        if (!BotPath.isInCombat(botName)) {
                            BotPath.startCombat(botName, nextPoint);
                        }
                        


                        
                    } else {

                        

                        if (BotPath.isInCombat(botName)) {
                            BotPath.endCombat(botName);
                        }
                        

                        Vec3 pausedPoint = BotPath.getPausedPoint(botName);
                        if (pausedPoint != null) {
                            Vec3 botPos = new Vec3(bot.getX(), bot.getY(), bot.getZ());
                            double distanceToPaused = botPos.distanceTo(pausedPoint);
                            

                            if (distanceToPaused < 1.5) {
                                BotPath.clearPausedPoint(botName);
                            } else {

                                BotNavigation.lookAtPosition(bot, pausedPoint);
                                BotNavigation.moveTowardPosition(bot, pausedPoint, 1.0);
                            }
                        } else {

                            Vec3 nextPoint = BotPath.getNextPoint(botName);
                            if (nextPoint != null) {
                                Vec3 botPos = new Vec3(bot.getX(), bot.getY(), bot.getZ());
                                double distance = botPos.distanceTo(nextPoint);
                                

                                if (distance < 1.5) {
                                    BotPath.advanceToNextPoint(botName);
                                } else {

                                    BotNavigation.lookAtPosition(bot, nextPoint);
                                    BotNavigation.moveTowardPosition(bot, nextPoint, 1.0);
                                }
                            }
                        }
                    }
                }
                

                if (tickCounter >= interval) {
                    var utilsState = BotUtils.getState(botName);
                    if (!utilsState.isEating && !BotCombat.isElytraMaceActive(botName) && !BotCombat.isWindBurstActive(botName)) {
                        BotEquipment.autoEquip(bot);
                    }
                }
            }
        }
        
        if (tickCounter >= interval) {
            tickCounter = 0;
        }

        statsReportCounter++;
        if (statsReportCounter >= STATS_REPORT_INTERVAL) {
            statsReportCounter = 0;
        }

        heroBotCommandCounter++;
        if (heroBotCommandCounter >= HERO_BOT_COMMAND_INTERVAL) {
            heroBotCommandCounter = 0;
            try {
                var silent = server.createCommandSourceStack().withSuppressedOutput();
                boolean value = BotSettings.get().isBotLeaveOnDeath();
                server.getCommands().getDispatcher().execute("herobot botLeaveOnDeath " + value, silent);
            } catch (Exception e) {
            }
        }
    }
}
