package dev.duelforge.stepan.config;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;

import java.nio.file.Files;
import java.nio.file.Path;

/** Per-world config directory helper (ported from pvp-bot-fabric, Unlicense, by Stepan1411). */
public class WorldConfigHelper {

    private static MinecraftServer server;
    private static String currentWorldName = null;
    private static Runnable onWorldChangeCallback = null;

    public static void init(MinecraftServer minecraftServer) {
        server = minecraftServer;
        currentWorldName = getWorldName();
    }

    public static void setOnWorldChangeCallback(Runnable callback) {
        onWorldChangeCallback = callback;
    }

    public static Path getWorldConfigDir() {
        checkWorldChange();
        return getWorldConfigDir(getWorldName());
    }

    private static void checkWorldChange() {
        String newWorldName = getWorldName();
        if (currentWorldName != null && !currentWorldName.equals(newWorldName)) {
            System.out.println("[Duelforge] World changed from '" + currentWorldName + "' to '" + newWorldName + "'");
            currentWorldName = newWorldName;
            if (onWorldChangeCallback != null) onWorldChangeCallback.run();
        } else if (currentWorldName == null) {
            currentWorldName = newWorldName;
        }
    }

    public static Path getWorldConfigDir(String worldName) {
        Path dir = FabricLoader.getInstance().getConfigDir()
                .resolve("duelforge").resolve("pvpbot").resolve("worlds").resolve(worldName);
        try {
            Files.createDirectories(dir);
        } catch (Exception e) {
            System.err.println("[Duelforge] Failed to create world config directory: " + e.getMessage());
        }
        return dir;
    }

    public static Path getGlobalConfigDir() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("duelforge").resolve("pvpbot");
        try {
            Files.createDirectories(dir);
        } catch (Exception e) {
            System.err.println("[Duelforge] Failed to create global config directory: " + e.getMessage());
        }
        return dir;
    }

    private static String getWorldName() {
        if (server != null) return server.getWorldData().getLevelName();
        return "world";
    }
}
