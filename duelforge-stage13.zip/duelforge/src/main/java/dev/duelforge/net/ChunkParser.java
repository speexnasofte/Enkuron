package dev.duelforge.net;

import dev.duelforge.ai.BlockTable;
import dev.duelforge.ai.ChunkStore;

/**
 * Reads the block packets of protocol 774 into a {@link ChunkStore}: level_chunk_with_light, block_update,
 * section_blocks_update, forget_level_chunk. Only block classes are kept; light, biomes and block entities are skipped.
 *
 * Two details of the wire format I could not verify offline, so the parser is tolerant instead of guessing:
 *  - whether the long array of a paletted container has a VarInt length in front (older versions) or not (newer ones):
 *    both are tried and the one that consumes the section buffer exactly is remembered;
 *  - heightmaps are a map (varint count, then type + long array) in new versions and a nameless NBT compound in old ones;
 *    the first byte tells them apart (0x0A is the NBT compound tag).
 */
public final class ChunkParser {
    private ChunkParser() {}

    private static final int FIXED = 1, PREFIXED = 2;
    /** 0 = not known yet. */
    private static volatile int mode = 0;

    public static int knownMode() { return mode; }
    public static void resetMode() { mode = 0; }

    /** @return false when the packet could not be understood (the chunk is then simply not stored). */
    public static boolean levelChunk(Wire.In p, ChunkStore store) {
        int cx = p.i32(), cz = p.i32();
        skipHeightmaps(p);
        byte[] buf = p.bytes();
        ChunkStore.Chunk c = decode(buf);
        if (c == null) return false;
        store.put(cx, cz, c);
        return true;
    }

    public static void forgetChunk(Wire.In p, ChunkStore store) {
        long l = p.i64();   // ChunkPos as a long: x in the low 32 bits, z in the high ones
        store.remove((int) l, (int) (l >> 32));
    }

    public static void blockUpdate(Wire.In p, ChunkStore store) {
        long pos = p.i64();
        int state = p.varInt();
        store.setState((int) (pos >> 38), (int) (pos << 52 >> 52), (int) (pos << 26 >> 38), state);
    }

    public static void sectionBlocksUpdate(Wire.In p, ChunkStore store) {
        long sec = p.i64();
        int sx = (int) (sec >> 42), sy = (int) (sec << 44 >> 44), sz = (int) (sec << 22 >> 42);
        int n = p.varInt();
        for (int i = 0; i < n; i++) {
            long v = p.varLong();
            int local = (int) (v & 0xFFF), state = (int) (v >>> 12);
            store.setState(sx * 16 + ((local >> 8) & 15), sy * 16 + (local & 15), sz * 16 + ((local >> 4) & 15), state);
        }
    }

    // ------------------------------------------------------------------ internals

    private static void skipHeightmaps(Wire.In p) {
        if (p.peek() == 0x0A) { p.skipNbt(); return; }
        int n = p.varInt();
        for (int i = 0; i < n; i++) {
            p.varInt();                 // heightmap type
            p.skip(p.varInt() * 8);     // long array
        }
    }

    private static ChunkStore.Chunk decode(byte[] buf) {
        int m = mode;
        int first = m == PREFIXED ? PREFIXED : FIXED, second = first == FIXED ? PREFIXED : FIXED;
        ChunkStore.Chunk c = sections(buf, first == PREFIXED);
        if (c != null) { mode = first; return c; }
        c = sections(buf, second == PREFIXED);
        if (c != null) mode = second;
        return c;
    }

    private static final class Sec { final byte uni; final byte[] arr; Sec(byte u, byte[] a) { uni = u; arr = a; } }

    private static ChunkStore.Chunk sections(byte[] buf, boolean prefixed) {
        try {
            Wire.In in = new Wire.In(buf);
            java.util.ArrayList<Sec> list = new java.util.ArrayList<>();
            while (in.left() > 0) {
                if (list.size() >= 64) return null;
                in.u16();                                                        // non-air block count
                Sec blocks = container(in, prefixed, 4096, 8, true);
                container(in, prefixed, 64, 3, false);                           // biomes: skipped
                list.add(blocks);
            }
            if (list.isEmpty()) return null;
            ChunkStore.Chunk c = new ChunkStore.Chunk(ChunkStore.minSecFor(list.size()), list.size());
            for (int i = 0; i < list.size(); i++) c.setSection(i, list.get(i).uni, list.get(i).arr);
            return c;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** One paletted container. Returns the block classes for the block container, null for biomes. */
    private static Sec container(Wire.In in, boolean prefixed, int entries, int maxIndirect, boolean blocks) {
        int bpe = in.u8();
        if (bpe > 24) throw new IllegalStateException("bits per entry " + bpe);
        int[] palette = null;
        int single = 0;
        if (bpe == 0) single = in.varInt();
        else if (bpe <= maxIndirect) {
            int n = in.varInt();
            if (n <= 0 || n > (1 << bpe)) throw new IllegalStateException("palette size " + n);
            palette = new int[n];
            for (int i = 0; i < n; i++) palette[i] = in.varInt();
        }
        int per = bpe == 0 ? 1 : 64 / bpe;
        int expected = bpe == 0 ? 0 : (entries + per - 1) / per;
        if (prefixed && in.varInt() != expected) throw new IllegalStateException("long array length");
        if (in.left() < expected * 8L) throw new IllegalStateException("short data");
        if (!blocks) { in.skip(expected * 8); return null; }
        if (bpe == 0) return new Sec(BlockTable.classOf(single), null);

        byte[] pc = null;
        if (palette != null) { pc = new byte[palette.length]; for (int i = 0; i < pc.length; i++) pc[i] = BlockTable.classOf(palette[i]); }
        long[] data = new long[expected];
        for (int i = 0; i < expected; i++) data[i] = in.i64();
        long mask = (1L << bpe) - 1;
        byte[] out = new byte[entries];
        for (int i = 0; i < entries; i++) {
            int v = (int) ((data[i / per] >>> ((i % per) * bpe)) & mask);
            if (pc != null) { if (v >= pc.length) throw new IllegalStateException("palette index"); out[i] = pc[v]; }
            else out[i] = BlockTable.classOf(v);
        }
        return new Sec((byte) 0, out);
    }
}
