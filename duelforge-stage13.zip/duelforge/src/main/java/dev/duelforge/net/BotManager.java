package dev.duelforge.net;

import dev.duelforge.ai.DuelManager;
import dev.duelforge.ai.Kit;
import dev.duelforge.ai.KitStore;
import dev.duelforge.ai.Kits;
import dev.duelforge.ai.Layout;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Order;
import dev.duelforge.ai.Tier;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Owns every running bot. Pure Java - no Minecraft classes. */
public final class BotManager {
    public static final BotManager INSTANCE = new BotManager();

    private final List<BotClient> bots = new CopyOnWriteArrayList<>();
    private final ScheduledExecutorService joiner = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "botlab-joiner"); t.setDaemon(true); return t;
    });
    /** Commands every new bot runs ~2s after spawning (e.g. "kit pvp", "login pass"). */
    public final List<String> joinCommands = new CopyOnWriteArrayList<>();
    /** Sends commands from the real player (set by the client mod; queued and paced there). */
    public volatile java.util.function.Consumer<List<String>> kitSender = c -> { };
    /** Delay between bot logins; Paper's connection-throttle defaults to 4000 ms. */
    public volatile int staggerMs = 4200;

    private BotManager() {}

    /** "Bot*20" -> Bot1..Bot20, "A,B,C" -> A,B,C. Names are cut to 16 chars. */
    public static List<String> expandNames(String spec) {
        List<String> out = new ArrayList<>();
        for (String part : spec.split(",")) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int star = part.indexOf('*');
            if (star > 0) {
                String pre = part.substring(0, star);
                int n;
                try { n = Math.min(200, Integer.parseInt(part.substring(star + 1).trim())); } catch (NumberFormatException e) { n = 1; }
                for (int i = 1; i <= n; i++) out.add(clip(pre + i));
            } else out.add(clip(part));
        }
        return out;
    }

    private static String clip(String s) { return s.length() > 16 ? s.substring(0, 16) : s; }

    private static Object[] hostPort(String hostPort) {
        String host = hostPort.trim();
        int port = 25565;
        int c = host.lastIndexOf(':');
        if (c > 0 && host.indexOf(':') == c) {
            try { port = Integer.parseInt(host.substring(c + 1)); host = host.substring(0, c); } catch (NumberFormatException ignored) {}
        }
        return new Object[]{host, port};
    }

    public int join(String hostPort, String nickSpec, Tier tier, Mode mode, String team) {
        return join(hostPort, nickSpec, tier, mode, team, 0);
    }

    /** @param extraDelayMs added to every bot's login time (a second batch must not hit the connection throttle together with the first) */
    public int join(String hostPort, String nickSpec, Tier tier, Mode mode, String team, long extraDelayMs) {
        return join(hostPort, nickSpec, tier, mode, team, extraDelayMs, Order.FIGHT, null, true);
    }

    /** Controller bots: start with an order (follow / stand / fight {@code focus}) and without the automatic kit commands. */
    public int joinControlled(String hostPort, String nick, Tier tier, Mode mode, String team, Order order, String focus) {
        return join(hostPort, nick, tier, mode, team, 0, order, focus, false);
    }

    private int join(String hostPort, String nickSpec, Tier tier, Mode mode, String team, long extraDelayMs, Order order, String focus, boolean kits) {
        Object[] hp = hostPort(hostPort);
        String host = (String) hp[0];
        int port = (Integer) hp[1];
        List<String> names = expandNames(nickSpec);
        // teammates never target each other: same team label + same batch
        Set<String> friends = new HashSet<>();
        for (String n : names) friends.add(n.toLowerCase(Locale.ROOT));
        for (BotClient b : bots) if (b.team.equalsIgnoreCase(team)) friends.add(b.name.toLowerCase(Locale.ROOT));
        List<String> cmds = new ArrayList<>(joinCommands);
        Kit kit = !kits || Opts.selectedKit == null ? null : KitStore.get(Opts.selectedKit);
        if (kit != null && kit.mode != null) mode = kit.mode;
        if (kits && kit == null && cmds.isEmpty() && Opts.autoKit) { String kitCmd = Kits.forMode(mode); if (kitCmd != null) cmds.add(kitCmd); }

        int i = 0;
        for (String n : names) {
            final String h = host; final int p = port;
            BotClient bot = new BotClient(h, p, n, team, tier, mode, kits ? cmds : new ArrayList<>(), friends);
            bot.order = order; bot.focus = focus;
            if (kit != null) { bot.kit = kit; bot.layout = Layout.detect(mode, kit.hotbarItems()); }
            bots.add(bot);
            joiner.schedule(bot::start, extraDelayMs + (long) i * staggerMs, TimeUnit.MILLISECONDS);
            i++;
        }
        return names.size();
    }

    // ------------------------------------------------------------------ NPC dummy

    /** Spawn passive NPC dummies (they get 99 totems in each hand once they are in the game). */
    public int spawnNpc(String hostPort, String nickSpec) {
        Object[] hp = hostPort(hostPort);
        List<String> names = expandNames(nickSpec);
        Set<String> friends = new HashSet<>();
        for (String n : names) friends.add(n.toLowerCase(Locale.ROOT));
        int i = 0;
        for (String n : names) {
            leave(n);
            BotClient bot = new BotClient((String) hp[0], (Integer) hp[1], n, "npc", Tier.HT3, Mode.NPC, new ArrayList<>(), friends);
            bots.add(bot);
            joiner.schedule(bot::start, (long) i * staggerMs, TimeUnit.MILLISECONDS);
            i++;
        }
        return names.size();
    }

    /** Commands that put the totems (and optional armor) on a target ("@s" or a nick). */
    public static List<String> npcGear(String target) {
        int n = Math.max(1, Math.min(99, Opts.npcTotems));
        String totem = "minecraft:totem_of_undying[minecraft:max_stack_size=99] " + n;
        List<String> c = new ArrayList<>();
        c.add("item replace entity " + target + " weapon.mainhand with " + totem);
        c.add("item replace entity " + target + " weapon.offhand with " + totem);
        if (Opts.npcArmor) {
            c.add("item replace entity " + target + " armor.head with minecraft:netherite_helmet");
            c.add("item replace entity " + target + " armor.chest with minecraft:netherite_chestplate");
            c.add("item replace entity " + target + " armor.legs with minecraft:netherite_leggings");
            c.add("item replace entity " + target + " armor.feet with minecraft:netherite_boots");
        }
        return c;
    }

    public void deliverNpcGear(BotClient bot) {
        if (Opts.kitViaBots) bot.queueCommands(npcGear("@s"));
        else kitSender.accept(npcGear(bot.name));
    }

    // ------------------------------------------------------------------ duels

    /** Two new bots fight each other (different teams); first to {@code firstTo} wins. */
    public void startDuelBots(String hostPort, String nickA, String nickB, Tier tA, Tier tB, Mode mode, int firstTo) {
        leave(nickA); leave(nickB);
        DuelManager.INSTANCE.start(nickA, true, nickB, true, firstTo);
        join(hostPort, nickA, tA, mode, "duelA", 0);
        join(hostPort, nickB, tB, mode, "duelB", staggerMs);
    }

    /** One new bot fights you (the real player). */
    public void startDuelVsPlayer(String hostPort, String bot, Tier tier, Mode mode, int firstTo, String playerName) {
        leave(bot);
        DuelManager.INSTANCE.start(bot, true, playerName, false, firstTo);
        join(hostPort, bot, tier, mode, "duelB", 0);
    }

    public int leave(String nick) {
        int n = 0;
        for (BotClient b : bots) {
            if (nick == null || nick.equalsIgnoreCase("all") || b.name.equalsIgnoreCase(nick)) { b.stop(); bots.remove(b); n++; }
        }
        return n;
    }

    /** Put the kit's items on one bot: its own commands (bots are op) or commands from your client. */
    public void deliverKit(BotClient bot, Kit kit) {
        if (Opts.kitViaBots) bot.queueCommands(kit.commands("@s", true));
        else kitSender.accept(kit.commands(bot.name, true));
    }

    /** Load a kit onto live bots ("all" or null = every bot) and switch them to the kit's mode and layout. */
    public int applyKit(Kit kit, String nick) {
        int n = 0;
        for (BotClient b : bots) {
            if (nick == null || nick.equalsIgnoreCase("all") || b.name.equalsIgnoreCase(nick)) { b.applyKit(kit); deliverKit(b, kit); n++; }
        }
        return n;
    }

    public List<BotClient> list() { return List.copyOf(bots); }
}
