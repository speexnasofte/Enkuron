package dev.duelforge.net;

import dev.duelforge.ai.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/** One bot = one real TCP connection speaking the Java Edition protocol (offline-mode and online-mode login). */
public final class BotClient implements Body.Net {
    public enum Status { CONNECTING, LOGIN, CONFIG, PLAYING, KICKED, ERROR, STOPPED }

    public final String host;
    public final int port;
    public final String name;
    public final String team;
    public final Tier tier;
    public volatile Mode mode;
    /** Kit this bot was given (null = none) and the hotbar layout detected from it. */
    public volatile dev.duelforge.ai.Kit kit;
    public volatile dev.duelforge.ai.Layout layout = dev.duelforge.ai.Layout.DEFAULT;
    private final java.util.ArrayDeque<String> cmdQueue = new java.util.ArrayDeque<>();
    private int cmdCd;
    public final List<String> joinCommands;
    public volatile Status status = Status.CONNECTING;
    public volatile String info = "";
    public static volatile boolean debug = false;
    /** How many times this bot died (HUD statistics). */
    public volatile int deaths;

    private final Set<String> friends;
    private final Random rnd = new Random();
    private final World world = new World();
    private final Body body = new Body(this, rnd);
    { body.terrain = world.chunks; }
    private String dimension = "";
    /** Chunk statistics for /botlab diag: parsed, failed. */
    private int chunksOk, chunksBad;
    private Brain brain;
    private Socket sock;
    private DataInputStream in;
    private OutputStream out;
    private javax.crypto.Cipher encCipher;
    private boolean posWarned;
    /** What this bot does: fight (default), follow {@link #focus}, or stand still. Set by the Controller menu. */
    public volatile Order order = Order.FIGHT;
    /** FIGHT: attack only this player (null = anybody). FOLLOW: walk after this player. */
    public volatile String focus;
    private int threshold = -1;
    private int state; // 0 login, 1 config, 2 play
    private int ticks;
    private boolean sentLoaded, ranJoin;
    private int respawnIn = -1;
    private ScheduledExecutorService loop;
    private volatile boolean stop;
    private final Set<Long> seenIds = new HashSet<>();
    private int seenAttacks, lastHitAt = -1000;

    public BotClient(String host, int port, String name, String team, Tier tier, Mode mode, List<String> joinCommands, Set<String> friends) {
        this.host = host; this.port = port; this.name = name; this.team = team;
        this.tier = tier; this.mode = mode; this.joinCommands = joinCommands; this.friends = friends;
    }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        Thread t = new Thread(this::run, "botlab-" + name);
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        stop = true;
        try { if (sock != null) sock.close(); } catch (IOException ignored) {}
        if (loop != null) loop.shutdownNow();
        if (status != Status.KICKED && status != Status.ERROR) status = Status.STOPPED;
    }

    private void run() {
        try {
            sock = new Socket();
            sock.setTcpNoDelay(true);
            sock.connect(new InetSocketAddress(host, port), 8000);
            in = new DataInputStream(new BufferedInputStream(sock.getInputStream()));
            out = new BufferedOutputStream(sock.getOutputStream());
            status = Status.LOGIN;

            // handshake -> login
            raw(Ids.HS_INTENT, o -> o.varInt(Ids.PROTOCOL).str(host).i16(port).varInt(2));
            UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            Auth.Account acc = Auth.find(name);
            String sendName = acc != null ? acc.name : name;
            UUID sendId = acc != null ? acc.uuid : id;
            raw(Ids.LOGIN_SB_HELLO, o -> o.str(sendName).uuid(sendId));

            brain = new Brain(body, world, rnd, tier, mode, team, friends, name);
            brain.setLayout(layout);
            brain.setKit(kit);
            brain.setOrder(order, focus);
            while (!stop) {
                byte[] frame = readFrame();
                Wire.In p = new Wire.In(frame);
                int pid = p.varInt();
                switch (state) {
                    case 0 -> login(pid, p);
                    case 1 -> config(pid, p);
                    default -> play(pid, p, frame.length);
                }
            }
        } catch (EOFException e) {
            if (!stop && status != Status.KICKED) { status = Status.ERROR; info = "соединение закрыто сервером"; }
        } catch (Exception e) {
            if (!stop && status != Status.KICKED) { status = Status.ERROR; info = e.getClass().getSimpleName() + ": " + e.getMessage(); }
        } finally {
            if (loop != null) loop.shutdownNow();
            try { if (sock != null) sock.close(); } catch (IOException ignored) {}
        }
    }

    // ------------------------------------------------------------------ framing

    private int readVarIntStream() throws IOException {
        int v = 0, s = 0;
        while (true) {
            int b = in.readUnsignedByte();
            v |= (b & 0x7F) << s;
            if ((b & 0x80) == 0) return v;
            s += 7;
            if (s > 35) throw new IOException("varint too long");
        }
    }

    private byte[] readFrame() throws IOException {
        int len = readVarIntStream();
        byte[] data = new byte[len];
        in.readFully(data);
        if (threshold < 0) return data;
        Wire.In h = new Wire.In(data);
        int ulen = h.varInt();
        int hdr = data.length - h.left();
        if (ulen == 0) return Arrays.copyOfRange(data, hdr, data.length);
        Inflater inf = new Inflater();
        inf.setInput(data, hdr, data.length - hdr);
        byte[] res = new byte[ulen];
        try {
            int n = 0;
            while (n < ulen) {
                int r = inf.inflate(res, n, ulen - n);
                if (r == 0 && (inf.finished() || inf.needsInput())) break;
                n += r;
            }
        } catch (Exception e) { throw new IOException("inflate failed", e); }
        finally { inf.end(); }
        return res;
    }

    private synchronized void raw(int id, Consumer<Wire.Out> body) throws IOException {
        Wire.Out o = new Wire.Out();
        o.varInt(id);
        body.accept(o);
        byte[] payload = o.bytes();
        Wire.Out f = new Wire.Out();
        if (threshold >= 0) {
            if (payload.length >= threshold) {
                Deflater d = new Deflater();
                d.setInput(payload);
                d.finish();
                byte[] buf = new byte[payload.length + 64];
                int n = d.deflate(buf);
                d.end();
                Wire.Out inner = new Wire.Out().varInt(payload.length).raw(Arrays.copyOf(buf, n));
                byte[] ib = inner.bytes();
                f.varInt(ib.length).raw(ib);
            } else {
                byte[] ib = new Wire.Out().varInt(0).raw(payload).bytes();
                f.varInt(ib.length).raw(ib);
            }
        } else {
            f.varInt(payload.length).raw(payload);
        }
        byte[] frame = f.bytes();
        if (encCipher != null) frame = encCipher.update(frame);
        out.write(frame);
        out.flush();
    }

    @Override
    public void send(int id, Consumer<Wire.Out> body) {
        try { raw(id, body); } catch (IOException e) { if (!stop) { status = Status.ERROR; info = "ошибка отправки: " + e.getMessage(); } }
    }

    // ------------------------------------------------------------------ login / config

    private void login(int pid, Wire.In p) throws IOException {
        switch (pid) {
            case Ids.LOGIN_CB_DISCONNECT -> kicked(p.str());
            case Ids.LOGIN_CB_ENCRYPTION -> encryption(p);
            case Ids.LOGIN_CB_COMPRESSION -> threshold = p.varInt();
            case Ids.LOGIN_CB_FINISHED -> {
                raw(Ids.LOGIN_SB_ACK, o -> {});
                state = 1;
                status = Status.CONFIG;
                raw(Ids.CFG_SB_CLIENT_INFO, o -> o.str("en_us").u8(Opts.botViewDistance).varInt(0).bool(true).u8(0x7F).varInt(1).bool(false).bool(true).varInt(0));
            }
            default -> {}
        }
    }

    /** online-mode: RSA key exchange, Mojang session "join", then AES/CFB8 on the whole stream. */
    private void encryption(Wire.In p) {
        try {
            String serverId = p.str();
            byte[] pub = p.bytes(), verify = p.bytes();
            boolean authenticate = p.left() <= 0 || p.bool();
            Auth.Account acc = Auth.find(name);
            if (acc == null) {
                status = Status.ERROR;
                info = "сервер в online-mode: ник бота должен совпадать с лицензионным аккаунтом. Есть: " + Auth.describe()
                        + ". Добавить аккаунт: /df account add";
                stop = true;
                return;
            }
            byte[] secret = new byte[16];
            new java.security.SecureRandom().nextBytes(secret);
            if (authenticate) Auth.joinServer(acc, Auth.serverHash(serverId, secret, pub));
            java.security.PublicKey key = java.security.KeyFactory.getInstance("RSA")
                    .generatePublic(new java.security.spec.X509EncodedKeySpec(pub));
            javax.crypto.Cipher rsa = javax.crypto.Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsa.init(javax.crypto.Cipher.ENCRYPT_MODE, key);
            byte[] encSecret = rsa.doFinal(secret), encVerify = rsa.doFinal(verify);
            raw(Ids.LOGIN_SB_ENCRYPTION, o -> o.buf(encSecret).buf(encVerify));

            javax.crypto.spec.SecretKeySpec k = new javax.crypto.spec.SecretKeySpec(secret, "AES");
            javax.crypto.Cipher dec = javax.crypto.Cipher.getInstance("AES/CFB8/NoPadding");
            dec.init(javax.crypto.Cipher.DECRYPT_MODE, k, new javax.crypto.spec.IvParameterSpec(secret));
            javax.crypto.Cipher enc = javax.crypto.Cipher.getInstance("AES/CFB8/NoPadding");
            enc.init(javax.crypto.Cipher.ENCRYPT_MODE, k, new javax.crypto.spec.IvParameterSpec(secret));
            // the server sends nothing until it has our answer, so the old input buffer is empty and can be replaced
            in = new DataInputStream(new BufferedInputStream(new CipherIn(sock.getInputStream(), dec)));
            encCipher = enc;
        } catch (Exception e) {
            status = Status.ERROR;
            info = "online-вход: " + e.getMessage();
            stop = true;
        }
    }

    /** Decrypts everything read from the socket (AES/CFB8 keeps the byte count, so it works in place). */
    private static final class CipherIn extends InputStream {
        private final InputStream src;
        private final javax.crypto.Cipher c;
        CipherIn(InputStream src, javax.crypto.Cipher c) { this.src = src; this.c = c; }
        @Override public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n <= 0 ? -1 : one[0] & 0xFF;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            int n = src.read(b, off, len);
            if (n > 0) { try { c.update(b, off, n, b, off); } catch (javax.crypto.ShortBufferException e) { throw new IOException(e); } }
            return n;
        }
        @Override public void close() throws IOException { src.close(); }
    }

    private void config(int pid, Wire.In p) throws IOException {
        switch (pid) {
            case Ids.CFG_CB_DISCONNECT -> kicked(p.nbtStrings());
            case Ids.CFG_CB_KEEPALIVE -> { long k = p.i64(); raw(Ids.CFG_SB_KEEPALIVE, o -> o.i64(k)); }
            case Ids.CFG_CB_PING -> { int k = p.i32(); raw(Ids.CFG_SB_PONG, o -> o.i32(k)); }
            case Ids.CFG_CB_KNOWN_PACKS -> raw(Ids.CFG_SB_KNOWN_PACKS, o -> o.varInt(0));
            case Ids.CFG_CB_CONDUCT -> raw(Ids.CFG_SB_ACCEPT_CONDUCT, o -> {});
            case Ids.CFG_CB_FINISH -> {
                raw(Ids.CFG_SB_FINISH, o -> {});
                state = 2;
            }
            default -> {}
        }
    }

    // ------------------------------------------------------------------ play

    private void play(int pid, Wire.In p, int len) throws IOException {
        if (debug && seenIds.add(((long) pid << 32) | len)) info = "pkt id=" + pid + " len=" + len;
        if (pid == Ids.CB_KEEPALIVE) { long k = p.i64(); raw(Ids.SB_KEEPALIVE, o -> o.i64(k)); return; }
        if (pid == Ids.CB_PING) { int k = p.i32(); raw(Ids.SB_PONG, o -> o.i32(k)); return; }
        if (pid == Ids.CB_DISCONNECT) { kicked(p.nbtStrings()); return; }
        if (pid == Ids.CB_START_CONFIG) {
            raw(Ids.SB_CONFIG_ACK, o -> {});
            state = 1; sentLoaded = false; body.haveFix = false;
            return;
        }
        synchronized (this) {
            try { handlePlay(pid, p); } catch (RuntimeException ex) { if (debug) info = "parse " + pid + ": " + ex.getMessage(); }
        }
    }

    private void handlePlay(int pid, Wire.In p) throws IOException {
        if (pid == Ids.CB_LOGIN) {
            body.entityId = p.i32();
            try {
                p.bool();                                         // hardcore
                int nd = p.varInt();
                for (int i = 0; i < nd; i++) p.str();             // all dimension keys
                p.varInt(); p.varInt(); p.varInt();               // max players, view distance, simulation distance
                p.bool(); p.bool(); p.bool();                     // reduced debug, respawn screen, limited crafting
                p.varInt();                                       // dimension type id
                dimension = p.str();
            } catch (RuntimeException ex) { dimension = ""; }
            world.chunks.clear();
            status = Status.PLAYING;
            if (loop == null) {
                loop = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "botlab-tick-" + name); t.setDaemon(true); return t; });
                loop.scheduleAtFixedRate(this::tickSafe, 50, 50, TimeUnit.MILLISECONDS);
            }
        } else if (pid == Ids.CB_PLAYER_POSITION) {
            int tid = p.varInt();
            double x = p.f64(), y = p.f64(), z = p.f64(), dx = p.f64(), dy = p.f64(), dz = p.f64();
            float yaw = p.f32(), pitch = p.f32();
            int flags = p.i32();
            if ((flags & 1) != 0) x += body.x;
            if ((flags & 2) != 0) y += body.y;
            if ((flags & 4) != 0) z += body.z;
            if ((flags & 8) != 0) yaw += body.yaw;
            if ((flags & 16) != 0) pitch += body.pitch;
            if ((flags & 32) != 0) dx += body.vx;
            if ((flags & 64) != 0) dy += body.vy;
            if ((flags & 128) != 0) dz += body.vz;
            final int t = tid;
            raw(Ids.SB_ACCEPT_TELEPORT, o -> o.varInt(t));
            body.serverPosition(x, y, z, dx, dy, dz, yaw, pitch);
            raw(Ids.SB_MOVE_POS_ROT, o -> o.f64(body.x).f64(body.y).f64(body.z).f32(body.yaw).f32(body.pitch).u8(1));
            if (!sentLoaded) { sentLoaded = true; raw(Ids.SB_PLAYER_LOADED, o -> {}); }
        } else if (pid == Ids.CB_SET_HEALTH) {
            float hp = p.f32();
            body.health = hp;
            if (hp <= 0) { if (!body.dead) { respawnIn = 20 + rnd.nextInt(30); deaths++; DuelManager.INSTANCE.onDeath(name); } body.dead = true; }
            else if (body.dead) { body.dead = false; body.haveFix = false; if (brain != null) brain.onRespawn(); }
        } else if (pid == Ids.CB_LEVEL_CHUNK) {
            if (Opts.readChunks) {
                if (ChunkParser.levelChunk(p, world.chunks)) chunksOk++;
                else if (chunksBad++ == 0 && debug) info = "chunk: не разобран пакет id=" + pid + " (проверь cb.level_chunk_with_light)";
            }
        } else if (pid == Ids.CB_BLOCK_UPDATE) {
            if (Opts.readChunks) ChunkParser.blockUpdate(p, world.chunks);
        } else if (pid == Ids.CB_SECTION_BLOCKS_UPDATE) {
            if (Opts.readChunks) ChunkParser.sectionBlocksUpdate(p, world.chunks);
        } else if (pid == Ids.CB_FORGET_LEVEL_CHUNK) {
            if (Opts.readChunks) ChunkParser.forgetChunk(p, world.chunks);
        } else if (pid == Ids.CB_CHUNK_BATCH_FINISHED) {
            // Vanilla clients acknowledge every batch; without it the server stops sending chunks after the first one.
            raw(Ids.SB_CHUNK_BATCH_RECEIVED, o -> o.f32(10.0f));
        } else if (pid == Ids.CB_RESPAWN) {
            try {
                p.varInt();                       // dimension type id
                String dim = p.str();             // dimension key: chunks stay valid on a respawn in the same dimension
                if (!dim.equals(dimension)) { world.chunks.clear(); dimension = dim; }
            } catch (RuntimeException ex) { world.chunks.clear(); }
            body.dead = false; body.haveFix = false; world.ents.clear();
            sentLoaded = false;
            if (brain != null) brain.onRespawn();
        } else if (pid == Ids.CB_PLAYER_INFO_UPDATE) {
            playerInfo(p);
        } else if (pid == Ids.CB_PLAYER_INFO_REMOVE) {
            int n = p.varInt();
            for (int i = 0; i < n; i++) world.removeName(p.uuid());
        } else if (pid == Ids.CB_ADD_ENTITY) {
            int eid = p.varInt();
            UUID u = p.uuid();
            int type = p.varInt();
            world.add(eid, u, type, p.f64(), p.f64(), p.f64(), ticks);
        } else if (pid == Ids.CB_REMOVE_ENTITIES) {
            int n = p.varInt();
            for (int i = 0; i < n; i++) {
                World.Ent gone = world.ents.remove(p.varInt());
                // a duel against the real player: he vanished right next to us a moment after we hit him -> he died
                if (gone != null && gone.player && ticks - lastHitAt < 100 && !body.dead
                        && Math.hypot(gone.x - body.x, gone.z - body.z) < 9 && DuelManager.INSTANCE.watchesPlayer(gone.name)) {
                    DuelManager.INSTANCE.onPlayerLost(gone.name, name);
                }
            }
        } else if (pid == Ids.CB_MOVE_ENTITY_POS || pid == Ids.CB_MOVE_ENTITY_POS_ROT) {
            World.Ent e = world.ents.get(p.varInt());
            if (e != null) {
                double dx = p.i16() / 4096.0, dy = p.i16() / 4096.0, dz = p.i16() / 4096.0;
                e.moveTo(e.x + dx, e.y + dy, e.z + dz, ticks);
            }
        } else if (pid == Ids.CB_TELEPORT_ENTITY || pid == Ids.CB_ENTITY_POS_SYNC) {
            World.Ent e = world.ents.get(p.varInt());
            if (e != null) { double nx = p.f64(), ny = p.f64(), nz = p.f64(); e.setPos(nx, ny, nz, ticks); }
        } else if (pid == Ids.CB_SET_ENTITY_MOTION) {
            if (p.varInt() == body.entityId) {
                double[] v = lpVec3(p);
                body.serverMotion(v[0], v[1], v[2]);
            }
        }
    }

    /** Low-precision velocity vector (1.21.9+). */
    private static double[] lpVec3(Wire.In p) {
        int lo = p.u8();
        if (lo == 0) return new double[]{0, 0, 0};
        int mid = p.u8();
        long hi = p.i32() & 0xFFFFFFFFL;
        long packed = (hi << 16) | ((long) mid << 8) | lo;
        long scale = packed & 3;
        if ((packed & 4) != 0) scale |= ((long) p.varInt() & 0xFFFFFFFFL) << 2;
        return new double[]{unpack(packed >> 3) * scale, unpack(packed >> 18) * scale, unpack(packed >> 33) * scale};
    }

    private static double unpack(long v) { return Math.min(v & 32767L, 32766L) * 2.0 / 32766.0 - 1.0; }

    private void playerInfo(Wire.In p) {
        int mask = p.u8();
        int n = p.varInt();
        for (int i = 0; i < n; i++) {
            UUID u = p.uuid();
            if ((mask & 0x01) != 0) {
                String nm = p.str();
                int props = p.varInt();
                for (int k = 0; k < props; k++) { p.str(); p.str(); if (p.bool()) p.str(); }
                world.setName(u, nm);
            }
            if ((mask & 0x02) != 0 && p.bool()) { p.uuid(); p.i64(); p.skip(p.varInt()); p.skip(p.varInt()); }
            if ((mask & 0x04) != 0) p.varInt();
            if ((mask & 0x08) != 0) p.bool();
            if ((mask & 0x10) != 0) p.varInt();
            if ((mask & 0x20) != 0 && p.bool()) p.skipNbt();
            if ((mask & 0x40) != 0) p.varInt();
            if ((mask & 0x80) != 0) p.bool();
        }
    }

    // ------------------------------------------------------------------ tick

    private void tickSafe() {
        try {
            synchronized (this) {
                if (stop || state != 2) return;
                ticks++;
                world.now = ticks;
                if (body.dead) {
                    if (respawnIn > 0 && --respawnIn == 0) { body.respawn(); }
                    return;
                }
                if (!ranJoin && body.haveFix && ticks > 40) {
                    ranJoin = true;
                    queueCommands(joinCommands);
                    if (mode == dev.duelforge.ai.Mode.NPC) BotManager.INSTANCE.deliverNpcGear(this);
                    else if (kit != null) BotManager.INSTANCE.deliverKit(this, kit);
                }
                if (!posWarned && !body.haveFix && ticks > 200) {
                    posWarned = true;
                    info = "сервер не прислал позицию за 10 с: проверь версию (нужна 1.21.11, протокол 774) и /botlab debug on";
                }
                if (ticks % 100 == 0 && world.chunks.size() > 0)
                    world.chunks.trim(((int) Math.floor(body.x)) >> 4, ((int) Math.floor(body.z)) >> 4, Math.max(Opts.chunkKeep, 3));
                if (cmdCd > 0) cmdCd--;
                else if (!cmdQueue.isEmpty()) { body.command(cmdQueue.poll()); cmdCd = dev.duelforge.ai.Opts.kitDelay; }
                if (body.attacks != seenAttacks) { seenAttacks = body.attacks; lastHitAt = ticks; }
                brain.tick();
                body.step();
                body.flush();
            }
        } catch (Throwable t) {
            info = "tick: " + t;
        }
    }

    private void kicked(String reason) {
        status = Status.KICKED;
        String low = reason.toLowerCase(Locale.ROOT);
        if (low.contains("another location") || low.contains("already online") || low.contains("already connected"))
            reason += "  (этим аккаунтом уже кто-то играет: бот не может зайти под твоим ником, пока ты на сервере. Добавь второй аккаунт: /df account add)";
        info = reason.length() > 200 ? reason.substring(0, 200) : reason;
        stop = true;
    }

    /** Change what the bot does while it is running (Controller menu). */
    public synchronized void setOrder(Order o, String who) {
        order = o; focus = who;
        if (brain != null) brain.setOrder(o, who);
    }

    /** Commands this bot sends itself, one every few ticks (kit loading, join commands). */
    public synchronized void queueCommands(List<String> cmds) { cmdQueue.addAll(cmds); }

    /** Give the running bot a kit's mode and hotbar layout (the items arrive through the kit commands). */
    public synchronized void applyKit(dev.duelforge.ai.Kit k) {
        kit = k;
        dev.duelforge.ai.Mode m = k.mode != null ? k.mode : mode;
        mode = m;
        layout = dev.duelforge.ai.Layout.detect(m, k.hotbarItems());
        if (brain != null) { brain.setMode(m); brain.setLayout(layout); brain.setKit(k); }
    }

    public synchronized int selectedSlot() { return brain == null ? -1 : brain.selectedSlot(); }

    /** Chunks the bot currently knows (0 when chunk reading is off or the server sent none). */
    public int chunkCount() { return world.chunks.size(); }

    public synchronized String diag() {
        String d = brain == null ? "" : brain.diag();
        return d + (Opts.readChunks ? " чанки " + world.chunks.size() + (chunksBad > 0 ? " (ошибок разбора " + chunksBad + ")" : "") : "");
    }

    /** The bot's own inventory model (null before it joined). */
    public synchronized dev.duelforge.ai.Inventory inventory() { return brain == null ? null : brain.inventory(); }

    public String brainState() { return brain == null ? "-" : brain.mode + "/" + brain.state; }
    public float health() { return body.health; }
    public synchronized int targetId() { return brain == null ? -1 : brain.targetId(); }
    public int hits() { return body.attacks; }
}
