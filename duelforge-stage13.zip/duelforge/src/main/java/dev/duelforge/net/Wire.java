package dev.duelforge.net;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Minimal Minecraft wire-format reader/writer (no Minecraft classes needed). */
public final class Wire {
    private Wire() {}

    public static final class In {
        private final byte[] d;
        private int p;

        public In(byte[] d) { this.d = d; }

        public int left() { return d.length - p; }
        public int u8() { return d[p++] & 0xFF; }
        public int i8() { return d[p++]; }
        public boolean bool() { return d[p++] != 0; }

        public int u16() {
            int hi = d[p++] & 0xFF;
            int lo = d[p++] & 0xFF;
            return (hi << 8) | lo;
        }

        public int i16() { return (short) u16(); }

        public int i32() {
            int v = 0;
            for (int i = 0; i < 4; i++) v = (v << 8) | (d[p++] & 0xFF);
            return v;
        }

        public long i64() {
            long v = 0;
            for (int i = 0; i < 8; i++) v = (v << 8) | (d[p++] & 0xFF);
            return v;
        }

        public float f32() { return Float.intBitsToFloat(i32()); }
        public double f64() { return Double.longBitsToDouble(i64()); }

        public int varInt() {
            int v = 0, s = 0;
            while (true) {
                int b = d[p++];
                v |= (b & 0x7F) << s;
                if ((b & 0x80) == 0) return v;
                s += 7;
                if (s > 35) throw new IllegalStateException("varint too long");
            }
        }

        public long varLong() {
            long v = 0;
            int s = 0;
            while (true) {
                int b = d[p++];
                v |= (long) (b & 0x7F) << s;
                if ((b & 0x80) == 0) return v;
                s += 7;
                if (s > 63) throw new IllegalStateException("varlong too long");
            }
        }

        /** Next byte without consuming it. */
        public int peek() { return d[p] & 0xFF; }
        public int pos() { return p; }
        public void pos(int np) { p = np; }

        public String str() {
            int n = varInt();
            String s = new String(d, p, n, StandardCharsets.UTF_8);
            p += n;
            return s;
        }

        /** Length-prefixed byte array (varint length). */
        public byte[] bytes() {
            int n = varInt();
            byte[] r = java.util.Arrays.copyOfRange(d, p, p + n);
            p += n;
            return r;
        }

        public UUID uuid() {
            long hi = i64();
            long lo = i64();
            return new UUID(hi, lo);
        }

        public void skip(int n) { p += n; }

        /** Network NBT (nameless root, 1.20.2+). Returns all string payloads joined - good enough for kick reasons. */
        public String nbtStrings() {
            StringBuilder sb = new StringBuilder();
            int t = u8();
            if (t != 0) tag(t, sb);
            return sb.toString();
        }

        public void skipNbt() { nbtStrings(); }

        private void tag(int t, StringBuilder sb) {
            switch (t) {
                case 1 -> p += 1;
                case 2 -> p += 2;
                case 3, 5 -> p += 4;
                case 4, 6 -> p += 8;
                case 7 -> { int n = i32(); p += n; }   // NOT `p += i32()`: Java reads p before i32() advances it
                case 8 -> {
                    int n = u16();
                    if (sb != null) sb.append(new String(d, p, n, StandardCharsets.UTF_8)).append(' ');
                    p += n;
                }
                case 9 -> {
                    int et = u8();
                    int n = i32();
                    for (int i = 0; i < n; i++) tag(et, sb);
                }
                case 10 -> {
                    while (true) {
                        int ct = u8();
                        if (ct == 0) break;
                        int nl = u16();
                        p += nl;
                        tag(ct, sb);
                    }
                }
                case 11 -> { int n = i32(); p += n * 4; }
                case 12 -> { int n = i32(); p += n * 8; }
                default -> throw new IllegalStateException("bad nbt tag " + t);
            }
        }
    }

    public static final class Out {
        private final ByteArrayOutputStream o = new ByteArrayOutputStream();

        public Out u8(int v) { o.write(v); return this; }
        public Out bool(boolean v) { o.write(v ? 1 : 0); return this; }
        public Out i16(int v) { o.write(v >> 8); o.write(v); return this; }
        public Out i32(int v) { for (int s = 24; s >= 0; s -= 8) o.write(v >> s); return this; }
        public Out i64(long v) { for (int s = 56; s >= 0; s -= 8) o.write((int) (v >> s)); return this; }
        public Out f32(float v) { return i32(Float.floatToIntBits(v)); }
        public Out f64(double v) { return i64(Double.doubleToLongBits(v)); }

        public Out varInt(int v) {
            while ((v & ~0x7F) != 0) {
                o.write((v & 0x7F) | 0x80);
                v >>>= 7;
            }
            o.write(v);
            return this;
        }

        public Out str(String s) {
            byte[] b = s.getBytes(StandardCharsets.UTF_8);
            varInt(b.length);
            o.write(b, 0, b.length);
            return this;
        }

        public Out uuid(UUID u) { return i64(u.getMostSignificantBits()).i64(u.getLeastSignificantBits()); }
        /** Length-prefixed byte array (varint length). */
        public Out buf(byte[] b) { varInt(b.length); return raw(b); }
        public Out raw(byte[] b) { o.write(b, 0, b.length); return this; }
        public byte[] bytes() { return o.toByteArray(); }
    }

    public static long packPos(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }
}
