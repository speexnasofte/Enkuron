package dev.duelforge.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Accounts for online-mode servers. A bot can only join a licensed server under the name of a real Minecraft account,
 * and it has to prove it to Mojang's session server (the same "join" call the real client makes).
 *
 * Two sources of accounts:
 *  1. the account you are playing with right now (set by the client mod through {@link #sessionSource});
 *  2. extra accounts added with the Microsoft device-code login ({@link #deviceLogin}); only the refresh token is saved,
 *     in config/duelforge/accounts.properties.
 *
 * Pure Java, no Minecraft classes. Endpoints can be redirected for tests with -Dduelforge.sessionUrl=...
 */
public final class Auth {
    private Auth() {}

    /** Public client id used by prismarine-auth / mineflayer for the Microsoft device-code flow. Override: -Dduelforge.msClientId=... */
    private static final String DEFAULT_CLIENT_ID = "389b1b32-b5d5-43b2-bddc-84ce938d6737";
    private static final String MS_BASE = "https://login.microsoftonline.com/consumers/oauth2/v2.0/";
    private static final String SCOPE = "XboxLive.signin offline_access";

    public static final class Account {
        public final String name;
        public final UUID uuid;
        /** true = the account of the running game (token comes from the game session, never saved). */
        public final boolean session;
        volatile String token;
        volatile long expires;
        volatile String refresh;

        Account(String name, UUID uuid, boolean session) { this.name = name; this.uuid = uuid; this.session = session; }

        public boolean ready() { return token != null && !token.isBlank() && !token.equals("0") && !token.equals("FabricMC"); }
    }

    /** Returns {name, uuid, accessToken} of the logged-in game account, or null. Set by the client mod. */
    public static volatile Supplier<String[]> sessionSource = () -> null;

    private static final List<Account> SAVED = new CopyOnWriteArrayList<>();
    private static boolean loaded;
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    public static volatile Path file = Path.of("config", "duelforge", "accounts.properties");

    // ------------------------------------------------------------------ lookup

    private static String clientId() { return System.getProperty("duelforge.msClientId", DEFAULT_CLIENT_ID); }

    private static String sessionUrl() {
        return System.getProperty("duelforge.sessionUrl", "https://sessionserver.mojang.com/session/minecraft/join");
    }

    /** The game account right now (fresh token on every call) or null. */
    public static Account session() {
        String[] s;
        try { s = sessionSource.get(); } catch (RuntimeException e) { return null; }
        if (s == null || s.length < 3 || s[0] == null || s[1] == null) return null;
        try {
            Account a = new Account(s[0], UUID.fromString(s[1]), true);
            a.token = s[2];
            a.expires = Long.MAX_VALUE;
            return a;
        } catch (IllegalArgumentException e) { return null; }
    }

    /** Account with this exact (case-insensitive) name: saved extra accounts first, then the game account. */
    public static synchronized Account find(String name) {
        load();
        for (Account a : SAVED) if (a.name.equalsIgnoreCase(name)) return a;
        Account s = session();
        return s != null && s.name.equalsIgnoreCase(name) ? s : null;
    }

    /** Names of every account a bot may use on an online-mode server. */
    public static synchronized List<String> names() {
        load();
        List<String> out = new ArrayList<>();
        Account s = session();
        if (s != null) out.add(s.name);
        for (Account a : SAVED) if (!out.contains(a.name)) out.add(a.name);
        return out;
    }

    public static synchronized boolean remove(String name) {
        load();
        boolean r = SAVED.removeIf(a -> a.name.equalsIgnoreCase(name));
        if (r) save();
        return r;
    }

    // ------------------------------------------------------------------ persistence (refresh tokens only)

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (!Files.exists(file)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file)) { p.load(in); }
            for (String name : p.stringPropertyNames()) {
                String[] v = p.getProperty(name).split(";", 2);
                if (v.length < 2) continue;
                Account a = new Account(name, UUID.fromString(v[0]), false);
                a.refresh = v[1];
                SAVED.add(a);
            }
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            Files.createDirectories(file.getParent());
            Properties p = new Properties();
            for (Account a : SAVED) if (a.refresh != null) p.setProperty(a.name, a.uuid + ";" + a.refresh);
            try (OutputStream out = Files.newOutputStream(file)) { p.store(out, "Duelforge accounts (refresh tokens - keep this file private)"); }
        } catch (IOException ignored) { }
    }

    // ------------------------------------------------------------------ server join (the part the vanilla client does)

    /** Minecraft's odd signed-hex SHA-1 of serverId + shared secret + server public key. */
    public static String serverHash(String serverId, byte[] secret, byte[] publicKey) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(serverId.getBytes(StandardCharsets.ISO_8859_1));
        md.update(secret);
        md.update(publicKey);
        return new BigInteger(md.digest()).toString(16);
    }

    /** Tell Mojang "this account is joining the server with this hash". Throws with a readable reason on failure. */
    public static void joinServer(Account a, String hash) throws IOException {
        ensureToken(a);
        if (!a.ready()) throw new IOException("у аккаунта " + a.name + " нет лицензионной сессии (пиратский лаунчер?). Добавь аккаунт: /df account add");
        String body = "{\"accessToken\":\"" + a.token + "\",\"selectedProfile\":\"" + a.uuid.toString().replace("-", "")
                + "\",\"serverId\":\"" + hash + "\"}";
        Resp r = post(sessionUrl(), "application/json", body, null);
        if (r.code != 204 && r.code != 200) {
            String hint = r.code == 403 || r.code == 401
                    ? " (токен устарел: перезайди в игру или заново /df account add)" : "";
            throw new IOException("сессия Mojang отклонила вход: HTTP " + r.code + hint);
        }
    }

    // ------------------------------------------------------------------ Microsoft login for extra accounts

    /** Start the device-code login on a background thread; progress goes to {@code say}. */
    public static void deviceLogin(Consumer<String> say) {
        Thread t = new Thread(() -> {
            try { runDeviceLogin(say); }
            catch (Exception e) { say.accept("Вход в аккаунт не удался: " + e.getMessage()); }
        }, "duelforge-login");
        t.setDaemon(true);
        t.start();
    }

    private static void runDeviceLogin(Consumer<String> say) throws Exception {
        Resp d = post(MS_BASE + "devicecode", "application/x-www-form-urlencoded",
                "client_id=" + enc(clientId()) + "&scope=" + enc(SCOPE), null);
        if (d.code != 200) throw new IOException("Microsoft devicecode: HTTP " + d.code + " " + clip(d.body));
        String device = str(d.body, "device_code"), user = str(d.body, "user_code"), uri = str(d.body, "verification_uri");
        long interval = Math.max(2, (long) num(d.body, "interval", 5)), left = (long) num(d.body, "expires_in", 900);
        say.accept("Открой " + (uri == null ? "https://microsoft.com/link" : uri) + " и введи код: " + user + "  (у тебя " + left / 60 + " мин)");

        long until = System.currentTimeMillis() + left * 1000;
        String ms = null, refresh = null;
        while (System.currentTimeMillis() < until) {
            Thread.sleep(interval * 1000);
            Resp t = post(MS_BASE + "token", "application/x-www-form-urlencoded",
                    "grant_type=" + enc("urn:ietf:params:oauth:grant-type:device_code") + "&client_id=" + enc(clientId())
                            + "&device_code=" + enc(device), null);
            if (t.code == 200) { ms = str(t.body, "access_token"); refresh = str(t.body, "refresh_token"); break; }
            String err = str(t.body, "error");
            if ("authorization_pending".equals(err)) continue;
            if ("slow_down".equals(err)) { interval += 5; continue; }
            throw new IOException("Microsoft: " + (err == null ? "HTTP " + t.code : err));
        }
        if (ms == null) throw new IOException("время на ввод кода вышло");

        String[] mc = minecraftToken(ms);                       // {token, expiresIn}
        Resp pr = get("https://api.minecraftservices.com/minecraft/profile", mc[0]);
        if (pr.code != 200) throw new IOException("профиль Minecraft: HTTP " + pr.code + (pr.code == 404 ? " (на аккаунте нет лицензии Java Edition)" : ""));
        String name = str(pr.body, "name"), id = str(pr.body, "id");
        if (name == null || id == null) throw new IOException("профиль Minecraft пустой");
        UUID uuid = UUID.fromString(id.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));

        synchronized (Auth.class) {
            load();
            SAVED.removeIf(a -> a.name.equalsIgnoreCase(name));
            Account a = new Account(name, uuid, false);
            a.token = mc[0];
            a.expires = System.currentTimeMillis() + (long) Double.parseDouble(mc[1]) * 1000;
            a.refresh = refresh;
            SAVED.add(a);
            save();
        }
        say.accept("Аккаунт " + name + " добавлен. Запускай ботов с этим ником.");
    }

    /** Make sure a saved account has a valid Minecraft token (refreshes it through Microsoft when needed). */
    static void ensureToken(Account a) throws IOException {
        if (a.session || (a.token != null && System.currentTimeMillis() < a.expires - 120_000)) return;
        if (a.refresh == null) throw new IOException("у аккаунта " + a.name + " нет refresh-токена, добавь его заново: /df account add");
        Resp t = post(MS_BASE + "token", "application/x-www-form-urlencoded",
                "grant_type=refresh_token&client_id=" + enc(clientId()) + "&refresh_token=" + enc(a.refresh) + "&scope=" + enc(SCOPE), null);
        if (t.code != 200) throw new IOException("обновление токена " + a.name + ": " + str(t.body, "error") + " - добавь аккаунт заново: /df account add");
        String ms = str(t.body, "access_token"), nr = str(t.body, "refresh_token");
        String[] mc = minecraftToken(ms);
        a.token = mc[0];
        a.expires = System.currentTimeMillis() + (long) Double.parseDouble(mc[1]) * 1000;
        if (nr != null) a.refresh = nr;
        synchronized (Auth.class) { save(); }
    }

    /** Microsoft access token -> Xbox Live -> XSTS -> Minecraft access token. Returns {token, expires_in seconds}. */
    private static String[] minecraftToken(String msAccess) throws IOException {
        Resp x = post("https://user.auth.xboxlive.com/user/authenticate", "application/json",
                "{\"Properties\":{\"AuthMethod\":\"RPS\",\"SiteName\":\"user.auth.xboxlive.com\",\"RpsTicket\":\"d=" + msAccess
                        + "\"},\"RelyingParty\":\"http://auth.xboxlive.com\",\"TokenType\":\"JWT\"}", "x-xbl-contract-version: 1");
        if (x.code != 200) throw new IOException("Xbox Live: HTTP " + x.code + " " + clip(x.body));
        String xbl = str(x.body, "Token");
        Resp s = post("https://xsts.auth.xboxlive.com/xsts/authorize", "application/json",
                "{\"Properties\":{\"SandboxId\":\"RETAIL\",\"UserTokens\":[\"" + xbl + "\"]},\"RelyingParty\":\"rp://api.minecraftservices.com/\",\"TokenType\":\"JWT\"}", null);
        if (s.code != 200) throw new IOException("XSTS: HTTP " + s.code + " " + xstsHint(s.body));
        String xsts = str(s.body, "Token"), uhs = str(s.body, "uhs");
        Resp m = post("https://api.minecraftservices.com/authentication/login_with_xbox", "application/json",
                "{\"identityToken\":\"XBL3.0 x=" + uhs + ";" + xsts + "\"}", null);
        if (m.code != 200) throw new IOException("Minecraft login: HTTP " + m.code + " " + clip(m.body));
        return new String[]{str(m.body, "access_token"), String.valueOf(num(m.body, "expires_in", 86400))};
    }

    private static String xstsHint(String body) {
        String x = str(body, "XErr");
        if (x == null) { Matcher m = Pattern.compile("\"XErr\"\\s*:\\s*(\\d+)").matcher(body); if (m.find()) x = m.group(1); }
        if (x == null) return clip(body);
        return switch (x) {
            case "2148916233" -> "у аккаунта нет профиля Xbox: создай на xbox.com";
            case "2148916235" -> "Xbox недоступен в твоём регионе";
            case "2148916236", "2148916237" -> "нужно подтверждение возраста на account.microsoft.com";
            case "2148916238" -> "детский аккаунт: нужно добавить в семью взрослым";
            default -> "XErr " + x;
        };
    }

    // ------------------------------------------------------------------ tiny HTTP / JSON helpers

    private record Resp(int code, String body) {}

    private static Resp post(String url, String type, String body, String extraHeader) throws IOException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20))
                .header("Content-Type", type).header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body));
        if (extraHeader != null) { int c = extraHeader.indexOf(':'); b.header(extraHeader.substring(0, c).trim(), extraHeader.substring(c + 1).trim()); }
        return send(b.build());
    }

    private static Resp get(String url, String bearer) throws IOException {
        return send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20))
                .header("Authorization", "Bearer " + bearer).GET().build());
    }

    private static Resp send(HttpRequest r) throws IOException {
        try {
            HttpResponse<String> res = HTTP.send(r, HttpResponse.BodyHandlers.ofString());
            return new Resp(res.statusCode(), res.body() == null ? "" : res.body());
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("прервано"); }
    }

    private static String enc(String s) { return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8); }

    private static String clip(String s) { return s == null ? "" : s.length() > 160 ? s.substring(0, 160) : s; }

    /** First string value of a JSON key anywhere in the document (enough for these flat token responses). */
    static String str(String json, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json == null ? "" : json);
        return m.find() ? m.group(1).replace("\\/", "/") : null;
    }

    static double num(String json, String key, double def) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"?(\\d+(?:\\.\\d+)?)").matcher(json == null ? "" : json);
        return m.find() ? Double.parseDouble(m.group(1)) : def;
    }

    /** For messages: which accounts exist. */
    public static String describe() {
        List<String> n = names();
        return n.isEmpty() ? "нет аккаунтов" : String.join(", ", n);
    }
}
