package dev.duelforge.net;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Packet IDs for protocol 774 (Minecraft 1.21.11).
 *
 * v2.0.1: ALL play IDs are now checked against the PrismarineJS/minecraft-data table for 1.21.11
 * (data/pc/1.21.11/protocol.json). The v2.0.0 table was shifted by +1 from 0x33 up (player position
 * arrived as 71 instead of 70), so bots never got their spawn position and stood still.
 * If a Play ID is still wrong on your build, override it WITHOUT recompiling in
 * config/pvpbotlab-ids.properties (e.g. "sb.interact=25"). Use /botlab debug on to see unknown ids.
 */
public final class Ids {
    private Ids() {}

    public static final int PROTOCOL = 774;
    private static final Properties P = new Properties();

    static {
        try {
            Path f = Path.of("config", "pvpbotlab-ids.properties");
            if (Files.exists(f)) try (InputStream in = Files.newInputStream(f)) { P.load(in); }
        } catch (Exception ignored) {}
    }

    private static int id(String key, int def) {
        String v = P.getProperty(key);
        if (v == null) return def;
        v = v.trim();
        return v.startsWith("0x") ? Integer.parseInt(v.substring(2), 16) : Integer.parseInt(v);
    }

    // ---- handshake / login ----
    public static final int HS_INTENT = 0x00;
    public static final int LOGIN_SB_HELLO = 0x00, LOGIN_SB_ENCRYPTION = 0x01, LOGIN_SB_ACK = 0x03;
    public static final int LOGIN_CB_DISCONNECT = 0x00, LOGIN_CB_ENCRYPTION = 0x01, LOGIN_CB_FINISHED = 0x02, LOGIN_CB_COMPRESSION = 0x03;

    // ---- configuration ----
    public static final int CFG_SB_CLIENT_INFO = 0x00, CFG_SB_FINISH = 0x03, CFG_SB_KEEPALIVE = 0x04, CFG_SB_PONG = 0x05,
            CFG_SB_KNOWN_PACKS = 0x07, CFG_SB_ACCEPT_CONDUCT = 0x09;
    public static final int CFG_CB_DISCONNECT = 0x02, CFG_CB_FINISH = 0x03, CFG_CB_KEEPALIVE = 0x04, CFG_CB_PING = 0x05,
            CFG_CB_KNOWN_PACKS = 0x0E, CFG_CB_CONDUCT = 0x13;

    // ---- play clientbound ----
    public static final int CB_ADD_ENTITY = id("cb.add_entity", 1);
    // Chunk / block packets. Derived from the verified neighbours above (keep_alive 43, login 48, respawn 80) and the
    // vanilla packet order; NOT checked against a live server. Override in config/pvpbotlab-ids.properties if /botlab debug
    // shows the wrong ones (chunks then simply stay unread and the bot falls back to the flat-floor model).
    public static final int CB_BLOCK_UPDATE = id("cb.block_update", 8);
    public static final int CB_CHUNK_BATCH_FINISHED = id("cb.chunk_batch_finished", 11);
    public static final int CB_FORGET_LEVEL_CHUNK = id("cb.forget_level_chunk", 37);
    public static final int CB_LEVEL_CHUNK = id("cb.level_chunk_with_light", 44);
    public static final int CB_SECTION_BLOCKS_UPDATE = id("cb.section_blocks_update", 82);
    public static final int CB_DISCONNECT = id("cb.disconnect", 32);
    public static final int CB_ENTITY_POS_SYNC = id("cb.entity_position_sync", 35);
    public static final int CB_KEEPALIVE = id("cb.keep_alive", 43);
    public static final int CB_LOGIN = id("cb.login", 48);
    public static final int CB_MOVE_ENTITY_POS = id("cb.move_entity_pos", 51);
    public static final int CB_MOVE_ENTITY_POS_ROT = id("cb.move_entity_pos_rot", 52);
    public static final int CB_PING = id("cb.ping", 59);
    public static final int CB_PLAYER_INFO_REMOVE = id("cb.player_info_remove", 67);
    public static final int CB_PLAYER_INFO_UPDATE = id("cb.player_info_update", 68);
    public static final int CB_PLAYER_POSITION = id("cb.player_position", 70);
    public static final int CB_REMOVE_ENTITIES = id("cb.remove_entities", 75);
    public static final int CB_RESPAWN = id("cb.respawn", 80);
    public static final int CB_SET_ENTITY_MOTION = id("cb.set_entity_motion", 99);
    public static final int CB_SET_HEALTH = id("cb.set_health", 102);
    public static final int CB_START_CONFIG = id("cb.start_configuration", 116);
    public static final int CB_TELEPORT_ENTITY = id("cb.teleport_entity", 123);

    // ---- play serverbound ----
    public static final int SB_ACCEPT_TELEPORT = id("sb.accept_teleportation", 0);
    public static final int SB_CHAT_COMMAND = id("sb.chat_command", 6);
    public static final int SB_CHUNK_BATCH_RECEIVED = id("sb.chunk_batch_received", 10);
    public static final int SB_CLIENT_COMMAND = id("sb.client_command", 11);
    public static final int SB_TICK_END = id("sb.client_tick_end", 12);
    public static final int SB_CONFIG_ACK = id("sb.configuration_acknowledged", 15);
    public static final int SB_INTERACT = id("sb.interact", 25);
    public static final int SB_KEEPALIVE = id("sb.keep_alive", 27);
    public static final int SB_MOVE_POS = id("sb.move_player_pos", 29);
    public static final int SB_MOVE_POS_ROT = id("sb.move_player_pos_rot", 30);
    public static final int SB_MOVE_ROT = id("sb.move_player_rot", 31);
    public static final int SB_MOVE_STATUS = id("sb.move_player_status_only", 32);
    public static final int SB_CONTAINER_CLICK = id("sb.container_click", 17);
    public static final int SB_PLAYER_ACTION = id("sb.player_action", 40);
    public static final int SB_PLAYER_COMMAND = id("sb.player_command", 41);
    public static final int SB_PLAYER_INPUT = id("sb.player_input", 42);
    public static final int SB_PLAYER_LOADED = id("sb.player_loaded", 43);
    public static final int SB_PONG = id("sb.pong", 44);
    public static final int SB_SET_CARRIED = id("sb.set_carried_item", 52);
    public static final int SB_SWING = id("sb.swing", 60);
    public static final int SB_USE_ITEM_ON = id("sb.use_item_on", 63);
    public static final int SB_USE_ITEM = id("sb.use_item", 64);
}
