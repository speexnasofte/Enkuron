package dev.duelforge.vis;

/**
 * Pure maths of the bot HUD (no Minecraft classes, so it is unit-tested with plain javac): colour blending in the "Expensive"
 * palette, smooth health bars and card layout. The look comes from Expensive's widgets (accent 6E74E3, error ED4561, card 151617).
 */
public final class HudMath {
    private HudMath() {}

    public static final int ACCENT = 0xFF6E74E3, WARN = 0xFFFDC95A, ERROR = 0xFFED4561, OK = 0xFF58D68D;
    public static final int CARD = 0xE6151617, CARD_OUTLINE = 0x1FFFFFFF, TEXT = 0xFFF0F1F4, TEXT_DIM = 0xFF868791, TRACK = 0xFF1E1F22;

    public static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int out = 0;
        for (int shift = 24; shift >= 0; shift -= 8) {
            int ca = (a >>> shift) & 0xFF, cb = (b >>> shift) & 0xFF;
            out |= (Math.round(ca + (cb - ca) * t) & 0xFF) << shift;
        }
        return out;
    }

    /** Health bar colour: accent when healthy, through yellow to red when low. */
    public static int hpColor(float frac) {
        frac = Math.max(0f, Math.min(1f, frac));
        if (frac > 0.5f) return lerpColor(WARN, ACCENT, (frac - 0.5f) * 2f);
        return lerpColor(ERROR, WARN, frac * 2f);
    }

    /** Move a displayed value toward its target (frame-rate independent exponential approach; {@code rate} per second). */
    public static float approach(float shown, float target, float dtSeconds, float rate) {
        float k = 1f - (float) Math.exp(-rate * Math.max(0f, dtSeconds));
        float v = shown + (target - shown) * k;
        return Math.abs(target - v) < 0.002f ? target : v;
    }

    /**
     * Top-left corners of {@code count} stacked cards. corner: bit0 = right, bit1 = bottom. Cards that do not fit on the screen are dropped.
     * @return array of {x, y} pairs
     */
    public static int[][] layout(int count, int screenW, int screenH, int corner, int w, int h, int gap, int margin) {
        boolean right = (corner & 1) != 0, bottom = (corner & 2) != 0;
        int x = right ? Math.max(0, screenW - w - margin) : margin;
        int fit = Math.max(0, (screenH - 2 * margin + gap) / (h + gap));
        int n = Math.min(count, fit);
        int[][] out = new int[n][];
        for (int i = 0; i < n; i++) {
            int y = bottom ? screenH - margin - h - i * (h + gap) : margin + i * (h + gap);
            out[i] = new int[]{x, y};
        }
        return out;
    }

    public static String clip(String s, int maxChars) {
        if (s == null) return "";
        return s.length() <= maxChars ? s : s.substring(0, Math.max(0, maxChars - 1)) + "…";
    }

    /** Tier accent: weak tiers cool and dim, strong tiers warm and bright (one colour per card edge). */
    public static int tierColor(int tierOrdinal, int tierCount) {
        float t = tierCount <= 1 ? 1f : Math.max(0, Math.min(tierCount - 1, tierOrdinal)) / (float) (tierCount - 1);
        return t < 0.5f ? lerpColor(0xFF5B8DEF, ACCENT, t * 2f) : lerpColor(ACCENT, ERROR, (t - 0.5f) * 2f);
    }
}
