package dev.duelforge.vis;

/** Points of the rotating target ring (Expensive's TargetESP / JumpCircle look, drawn with particles). Pure maths, unit-tested. */
public final class RingMath {
    private RingMath() {}

    /** {@code points} positions on a horizontal circle around (cx, cy, cz), rotated by {@code phase} radians. */
    public static double[][] ring(double cx, double cy, double cz, double radius, int points, double phase) {
        double[][] p = new double[points][3];
        for (int i = 0; i < points; i++) {
            double a = phase + i * (Math.PI * 2 / points);
            p[i][0] = cx + Math.cos(a) * radius;
            p[i][1] = cy;
            p[i][2] = cz + Math.sin(a) * radius;
        }
        return p;
    }

    /** Height offset 0..1 that moves up and down once per period (ticks), so the ring sweeps the body like a scanner. */
    public static double sweep(long tick, int period) {
        double x = (tick % period) / (double) period;
        return x < 0.5 ? x * 2 : 2 - x * 2;
    }

    /** Ring radius for an entity of the given hitbox width (a little wider than the box). */
    public static double radiusFor(double width) { return Math.max(0.45, width * 0.5 + 0.35); }
}
