package dev.duelforge.local;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server command from the Controller menu (spawn, follow, kit_*, tier_*, ...). */
public record BotAction(String action) implements CustomPacketPayload {
    public static final Type<BotAction> TYPE = new Type<>(Identifier.fromNamespaceAndPath("duelforge", "action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, BotAction> CODEC =
            StreamCodec.composite(ByteBufCodecs.STRING_UTF8, BotAction::action, BotAction::new);

    @Override
    public Type<BotAction> type() { return TYPE; }
}
