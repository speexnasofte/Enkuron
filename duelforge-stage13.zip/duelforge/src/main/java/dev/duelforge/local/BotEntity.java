package dev.duelforge.local;

import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Server-side bot of the Controller mode: owned, can follow its owner, never burns, speed = tier. */
public class BotEntity extends PathfinderMob {
    private UUID owner;
    private boolean following;
    private int followTicks;
    private int tier = 3;

    public BotEntity(EntityType<? extends PathfinderMob> type, Level level) { super(type, level); }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
    }


    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        this.owner = in.read("BotOwner", UUIDUtil.CODEC).orElse(null);
        this.following = in.getBooleanOr("BotFollowing", false);
        this.setTier(in.getIntOr("BotTier", 3));
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        if (this.owner != null) out.store("BotOwner", UUIDUtil.CODEC, this.owner);
        out.putBoolean("BotFollowing", this.following);
        out.putInt("BotTier", this.tier);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.following || this.owner == null || !(this.level() instanceof ServerLevel level)) return;
        if (++this.followTicks < 10) return;
        this.followTicks = 0;
        ServerPlayer player = level.getServer().getPlayerList().getPlayer(this.owner);
        if (player == null || !player.isAlive() || player.level() != level) {
            this.getNavigation().stop();
        } else if (this.distanceToSqr(player) > 9.0) {
            this.getNavigation().moveTo(player, 1.0);
        } else {
            this.getNavigation().stop();
        }
    }

    public void setFollowing(boolean following) {
        this.following = following;
        this.getNavigation().stop();
        if (following) this.setTarget(null);
    }

    /** Tier 1 = fastest (HT1) ... tier 5 = slowest (LT5). */
    public void setTier(int tier) {
        this.tier = Mth.clamp(tier, 1, 5);
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(0.20 + (5 - this.tier) * 0.025);
    }

    public void setOwner(UUID owner) { this.owner = owner; }
    public boolean isOwnedBy(UUID owner) { return owner.equals(this.owner); }
}
