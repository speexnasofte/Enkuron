package dev.duelforge.local;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Data-driven kits for server-side Controller bots (replaces the old if-chain). */
public enum LocalKit {
    CRYSTAL("kit_crystal", "Crystal PvP", Items.END_CRYSTAL, Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING, true),
    POT("kit_pot", "Netherite Pot", Items.SPLASH_POTION, Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING, true),
    SMP("kit_smp", "SMP", Items.NETHERITE_CHESTPLATE, Items.NETHERITE_SWORD, Items.SHIELD, true),
    SWORD("kit_sword", "Sword", Items.DIAMOND_SWORD, Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, false),
    AXE("kit_axe", "Axe & Shield", Items.NETHERITE_AXE, Items.NETHERITE_AXE, Items.SHIELD, true),
    MACE("kit_mace", "Mace", Items.MACE, Items.MACE, Items.TOTEM_OF_UNDYING, true),
    NETHERITE_SWORD("kit_netherite_sword", "Netherite Sword", Items.NETHERITE_SWORD, Items.NETHERITE_SWORD, Items.SHIELD, true),
    DIAMOND("kit_diamond", "Diamond Classic", Items.DIAMOND_CHESTPLATE, Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, false),
    DIAMOND_SMP("kit_diamond_smp", "Diamond SMP", Items.DIAMOND_HELMET, Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, false),
    SOTG("kit_sotg", "SOTG", Items.OBSIDIAN, Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING, true),
    BEDFIGHT("kit_bedfight", "Bedfight", Items.RED_BED, Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, false),
    UHC("kit_uhc", "UHC", Items.GOLDEN_APPLE, Items.DIAMOND_SWORD, Items.SHIELD, false),
    SPEAR_MACE("kit_spear_mace", "Spear & Mace", Items.NETHERITE_SPEAR, Items.NETHERITE_SPEAR, Items.MACE, true),
    BOW("kit_bow", "Bow", Items.BOW, Items.NETHERITE_SWORD, Items.BOW, true),
    ELYTRA("kit_elytra", "Elytra", Items.ELYTRA, Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING, true);

    public final String id, title;
    public final Item icon, weapon, offhand;
    public final boolean netherite;

    LocalKit(String id, String title, Item icon, Item weapon, Item offhand, boolean netherite) {
        this.id = id; this.title = title; this.icon = icon; this.weapon = weapon; this.offhand = offhand; this.netherite = netherite;
    }

    public static LocalKit byId(String id) {
        for (LocalKit k : values()) if (k.id.equals(id)) return k;
        return null;
    }

    public void equip(Mob bot) {
        put(bot, EquipmentSlot.MAINHAND, weapon);
        put(bot, EquipmentSlot.OFFHAND, offhand);
        put(bot, EquipmentSlot.HEAD, netherite ? Items.NETHERITE_HELMET : Items.DIAMOND_HELMET);
        put(bot, EquipmentSlot.CHEST, this == ELYTRA ? Items.ELYTRA : netherite ? Items.NETHERITE_CHESTPLATE : Items.DIAMOND_CHESTPLATE);
        put(bot, EquipmentSlot.LEGS, netherite ? Items.NETHERITE_LEGGINGS : Items.DIAMOND_LEGGINGS);
        put(bot, EquipmentSlot.FEET, netherite ? Items.NETHERITE_BOOTS : Items.DIAMOND_BOOTS);
    }

    private static void put(Mob bot, EquipmentSlot slot, Item item) {
        bot.setItemSlot(slot, new ItemStack(item));
        bot.setDropChance(slot, 0.0F);
    }
}
