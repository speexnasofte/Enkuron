package dev.duelforge.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.blaze3d.platform.InputConstants;
import dev.duelforge.DuelforgeMod;
import dev.duelforge.ai.Combo;
import dev.duelforge.ai.DuelManager;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Tier;
import dev.duelforge.net.Auth;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import dev.duelforge.client.render.BotPlayerRenderer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.Arrays;

/**
 * /botlab gui
 * /botlab join <ip[:port]> <nicks|prefix*N> <tier LT5..HT1> <mode> [team]
 * /botlab cmd <command...>     (command each bot runs after joining, e.g. "kit pvp"; "clear" to reset)
 * /botlab list | leave [nick|all] | debug <on|off> | delay <ms>
 * /botlab obsidian <auto|always|never>   (crystal bots: place obsidian before the crystal)
 * /botlab combo <on|off>                 (w-tap / s-tap / strafe combos after a hit)
 * /botlab totem <on|off>                  (swap a spare totem into the offhand after a pop)
 * /botlab autokit <on|off>                (run "kit <mode>" after login; override in config/pvpbotlab-kits.properties)
 * /botlab kit save|load|give|list|show|rename|delete|mode|use ...   (own kit system, see KitCommands)
 * /botlab kitdelay <ticks> | kitbots <on|off> | spear <reach> <cooldown>
 * /botlab combo list | chain on|off | rate <0.3..1.6> | kind <имя> on|off     (отдельные комбо)
 * /botlab duel ... | /botlab npc ...      (см. ExtraCommands)
 * /botlab nav on|off                      (bots walk round walls / over 1-block ledges)
 * /botlab chunks on|off | terrain on|off  (bots read chunk packets / walk and fall on the real blocks)
 * /botlab modes                           (all modes with the hotbar each one expects)
 * /df account add | list | remove <nick>   (licensed accounts for bots on online-mode servers)
 */
public final class DuelforgeClient implements ClientModInitializer {
    /** Open the menu with a key (Options > Controls > Key Binds > PvP Bot Lab). Default: right Shift. */
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("duelforge", "main"));
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.duelforge.open_menu", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, category));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenuKey.consumeClick()) {
                if (mc.screen == null) Hub.open();   // only from the game, never on top of another screen
            }
        });
        // the account you play with can be used by a bot on online-mode servers (not while you are on the same server)
        Auth.sessionSource = () -> {
            var u = Minecraft.getInstance().getUser();
            return new String[]{u.getName(), u.getProfileId().toString(), u.getAccessToken()};
        };
        // after every mod (modded blocks included) has registered its blocks
        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> BlockTableBuilder.build());
        EntityRendererRegistry.register(DuelforgeMod.BOT, BotPlayerRenderer::new);
        ControllerHud.register();
        LabHud.register();
        TargetRing.register();
        BotManager.INSTANCE.kitSender = KitLoader::queue;
        DuelManager.INSTANCE.sender = KitLoader::queue;
        DuelManager.INSTANCE.announce = msg -> {
            Minecraft mc = Minecraft.getInstance();
            mc.execute(() -> { if (mc.player != null) mc.player.displayClientMessage(Component.literal(msg), false); });
        };
        ClientTickEvents.END_CLIENT_TICK.register(KitLoader::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("botlab");

            root.then(ClientCommandManager.literal("gui").executes(ctx -> {
                Minecraft.getInstance().execute(() -> Hub.open(Hub.Menu.LAB));
                return 1;
            }));

            // hub commands: /duelforge [lab|controller], /df, /botgui, /botconfig
            for (String name : new String[]{"duelforge", "df"}) {
                dispatcher.register(ClientCommandManager.literal(name)
                        .executes(ctx -> { Minecraft.getInstance().execute(Hub::open); return 1; })
                        .then(ClientCommandManager.literal("lab").executes(ctx -> { Minecraft.getInstance().execute(() -> Hub.open(Hub.Menu.LAB)); return 1; }))
                        .then(ClientCommandManager.literal("controller").executes(ctx -> { Minecraft.getInstance().execute(() -> Hub.open(Hub.Menu.CONTROLLER)); return 1; }))
                        .then(ClientCommandManager.literal("gui").executes(ctx -> { Minecraft.getInstance().execute(() -> Minecraft.getInstance().setScreen(new dev.duelforge.client.expa.ExpaScreen())); return 1; }))
                        .then(ClientCommandManager.literal("stepan").executes(ctx -> { Minecraft.getInstance().execute(() -> Hub.open(Hub.Menu.STEPAN)); return 1; }))
                        .then(accountCommands()));
            }
            for (String name : new String[]{"botgui", "botconfig"}) {
                dispatcher.register(ClientCommandManager.literal(name)
                        .executes(ctx -> { Minecraft.getInstance().execute(() -> Hub.open(Hub.Menu.CONTROLLER)); return 1; }));
            }

            root.then(accountCommands());

            root.then(ClientCommandManager.literal("join")
                    .then(ClientCommandManager.argument("ip", StringArgumentType.string())
                            .then(ClientCommandManager.argument("nicks", StringArgumentType.string())
                                    .then(ClientCommandManager.argument("tier", StringArgumentType.word())
                                            .then(ClientCommandManager.argument("mode", StringArgumentType.word())
                                                    .executes(ctx -> join(ctx.getSource(),
                                                            StringArgumentType.getString(ctx, "ip"), StringArgumentType.getString(ctx, "nicks"),
                                                            StringArgumentType.getString(ctx, "tier"), StringArgumentType.getString(ctx, "mode"), "A"))
                                                    .then(ClientCommandManager.argument("team", StringArgumentType.word())
                                                            .executes(ctx -> join(ctx.getSource(),
                                                                    StringArgumentType.getString(ctx, "ip"), StringArgumentType.getString(ctx, "nicks"),
                                                                    StringArgumentType.getString(ctx, "tier"), StringArgumentType.getString(ctx, "mode"),
                                                                    StringArgumentType.getString(ctx, "team")))))))));

            root.then(ClientCommandManager.literal("cmd")
                    .then(ClientCommandManager.argument("command", StringArgumentType.greedyString()).executes(ctx -> {
                        String c = StringArgumentType.getString(ctx, "command");
                        if (c.equalsIgnoreCase("clear")) BotManager.INSTANCE.joinCommands.clear();
                        else BotManager.INSTANCE.joinCommands.add(c);
                        say(ctx.getSource(), "Команды после входа: " + BotManager.INSTANCE.joinCommands);
                        return 1;
                    })));

            root.then(ClientCommandManager.literal("leave").executes(ctx -> leave(ctx.getSource(), "all"))
                    .then(ClientCommandManager.argument("nick", StringArgumentType.word())
                            .executes(ctx -> leave(ctx.getSource(), StringArgumentType.getString(ctx, "nick")))));

            root.then(ClientCommandManager.literal("list").executes(ctx -> {
                var bots = BotManager.INSTANCE.list();
                say(ctx.getSource(), "Ботов: " + bots.size());
                for (BotClient b : bots) {
                    say(ctx.getSource(), b.name + " [" + b.tier + "/" + b.mode + "/" + b.team + "] " + b.status + " hp=" + b.health() + " " + b.brainState()
                            + (b.info.isEmpty() ? "" : " | " + b.info));
                }
                return 1;
            }));

            root.then(ClientCommandManager.literal("debug").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                BotClient.debug = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "debug = " + BotClient.debug + " (смотри /botlab list: последний неизвестный пакет id/len)");
                return 1;
            })));

            root.then(ClientCommandManager.literal("delay").then(ClientCommandManager.argument("ms", StringArgumentType.word()).executes(ctx -> {
                try { BotManager.INSTANCE.staggerMs = Math.max(0, Integer.parseInt(StringArgumentType.getString(ctx, "ms"))); } catch (NumberFormatException ignored) {}
                say(ctx.getSource(), "Пауза между входами ботов: " + BotManager.INSTANCE.staggerMs + " мс");
                return 1;
            })));

            root.then(ClientCommandManager.literal("obsidian").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.obsidian = Opts.Obsidian.parse(StringArgumentType.getString(ctx, "v"));
                say(ctx.getSource(), "Обсидиан для кристаллов: " + Opts.obsidian + " (auto = сам научится, always = всегда, never = пол уже из обсидиана)");
                return 1;
            })));

            root.then(ClientCommandManager.literal("totem").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.totemRefill = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Замена тотема после попа: " + (Opts.totemRefill ? "вкл" : "выкл"));
                return 1;
            })));

            root.then(ClientCommandManager.literal("autokit").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.autoKit = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Авто-кит (команда kit <режим> после входа): " + (Opts.autoKit ? "вкл" : "выкл"));
                return 1;
            })));

            root.then(ClientCommandManager.literal("combo")
                    .then(ClientCommandManager.literal("list").executes(ctx -> {
                        say(ctx.getSource(), "Комбо " + (Opts.combo ? "ВКЛ" : "ВЫКЛ") + " · цепочки " + (Opts.comboChain ? "ВКЛ" : "ВЫКЛ") + " · частота x" + String.format("%.1f", Opts.comboRate));
                        for (Combo.Kind k : Combo.Kind.values()) if (k != Combo.Kind.NONE)
                            say(ctx.getSource(), (Opts.comboOn(k) ? "[x] " : "[ ] ") + k.name().toLowerCase() + " - " + k.label + ": " + k.info);
                        return 1;
                    }))
                    .then(ClientCommandManager.literal("chain").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.comboChain = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Цепочки из двух комбо (LT2 и выше): " + (Opts.comboChain ? "вкл" : "выкл"));
                        return 1;
                    })))
                    .then(ClientCommandManager.literal("rate").then(ClientCommandManager.argument("x", StringArgumentType.word()).executes(ctx -> {
                        try { Opts.comboRate = Math.max(0.3, Math.min(1.6, Double.parseDouble(StringArgumentType.getString(ctx, "x")))); } catch (NumberFormatException ignored) {}
                        say(ctx.getSource(), "Частота комбо: x" + String.format("%.1f", Opts.comboRate));
                        return 1;
                    })))
                    .then(ClientCommandManager.literal("kind").then(ClientCommandManager.argument("name", StringArgumentType.word())
                            .then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                                Combo.Kind k;
                                try { k = Combo.Kind.valueOf(StringArgumentType.getString(ctx, "name").toUpperCase().replace('-', '_')); }
                                catch (IllegalArgumentException e) { say(ctx.getSource(), "Нет такого комбо. Список: /botlab combo list"); return 0; }
                                Opts.comboSet(k, StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on"));
                                say(ctx.getSource(), k.label + ": " + (Opts.comboOn(k) ? "вкл" : "выкл"));
                                return 1;
                            }))))
                    .then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.combo = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Комбо после удара: " + (Opts.combo ? "вкл" : "выкл (только случайный в-тап)") + "  ·  подробности: /botlab combo list");
                        return 1;
                    })));

            root.then(ClientCommandManager.literal("traps")
                    .then(ClientCommandManager.literal("list").executes(ctx -> {
                        say(ctx.getSource(), "Ловушки (UHC, Ловушки): " + (Opts.traps ? "ВКЛ" : "ВЫКЛ") + " · паутина " + (Opts.trapWeb ? "вкл" : "выкл")
                                + " · лава " + (Opts.trapLava ? "вкл" : "выкл") + " · огонь " + (Opts.trapFire ? "вкл" : "выкл") + " · кража воды " + (Opts.waterSteal ? "вкл" : "выкл"));
                        return 1;
                    }))
                    .then(ClientCommandManager.literal("web").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.trapWeb = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Паутина под врага: " + (Opts.trapWeb ? "вкл" : "выкл"));
                        return 1;
                    })))
                    .then(ClientCommandManager.literal("lava").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.trapLava = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Лава рядом с пойманным врагом: " + (Opts.trapLava ? "вкл" : "выкл"));
                        return 1;
                    })))
                    .then(ClientCommandManager.literal("fire").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.trapFire = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Огонь вокруг врага: " + (Opts.trapFire ? "вкл" : "выкл"));
                        return 1;
                    })))
                    .then(ClientCommandManager.literal("steal").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.waterSteal = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Кража воды у убегающего врага: " + (Opts.waterSteal ? "вкл" : "выкл"));
                        return 1;
                    })))
                    .then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                        Opts.traps = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                        say(ctx.getSource(), "Ловушки в UHC/Ловушки: " + (Opts.traps ? "вкл" : "выкл") + "  ·  подробности: /botlab traps list");
                        return 1;
                    })));

            root.then(ClientCommandManager.literal("macefall").then(ClientCommandManager.argument("blocks", StringArgumentType.word()).executes(ctx -> {
                try { Opts.maceMinFall = Math.max(1.5, Math.min(30, Double.parseDouble(StringArgumentType.getString(ctx, "blocks")))); } catch (NumberFormatException ignored) {}
                say(ctx.getSource(), "Булава+: бьёт после падения от " + String.format("%.1f", Opts.maceMinFall) + " блоков (дольше падение = сильнее удар)");
                return 1;
            })));

            root.then(ClientCommandManager.literal("hud").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                String v = StringArgumentType.getString(ctx, "v");
                if (v.equalsIgnoreCase("corner")) Opts.labHudCorner = (Opts.labHudCorner + 1) & 3; else Opts.labHud = v.equalsIgnoreCase("on");
                say(ctx.getSource(), "Карточки ботов: " + (Opts.labHud ? "вкл" : "выкл") + " (угол " + Opts.labHudCorner + "; /botlab hud corner меняет угол)");
                return 1;
            })));
            root.then(ClientCommandManager.literal("ring").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.targetRing = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Кольцо на цели бота: " + (Opts.targetRing ? "вкл" : "выкл"));
                return 1;
            })));
            root.then(ClientCommandManager.literal("smartcrystal").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.smartCrystal = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Кристаллы по урону: " + (Opts.smartCrystal ? "вкл" : "выкл") + " (мин. урон врагу " + Opts.crystalMinDamage + ", запас HP " + Opts.crystalSelfReserve + ")");
                return 1;
            })));
            root.then(ClientCommandManager.literal("hitboxaim").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.hitboxAim = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Прицел по хитбоксу (HT3+): " + (Opts.hitboxAim ? "вкл" : "выкл"));
                return 1;
            })));

            root.then(ClientCommandManager.literal("chunks").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.readChunks = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Чтение чанков ботами: " + (Opts.readChunks ? "вкл" : "выкл (плоский пол)"));
                return 1;
            })));
            root.then(ClientCommandManager.literal("terrain").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.terrainPhysics = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Физика по реальным блокам: " + (Opts.terrainPhysics ? "вкл" : "выкл (плоский пол)"));
                return 1;
            })));

            root.then(ClientCommandManager.literal("nav").then(ClientCommandManager.argument("v", StringArgumentType.word()).executes(ctx -> {
                Opts.pathfinding = StringArgumentType.getString(ctx, "v").equalsIgnoreCase("on");
                say(ctx.getSource(), "Обход стен ботами: " + (Opts.pathfinding ? "вкл" : "выкл"));
                return 1;
            })));

            root.then(ClientCommandManager.literal("modes").executes(ctx -> {
                for (Mode m : Mode.values()) say(ctx.getSource(), m.name() + " - " + m.label + ": " + m.kit);
                return 1;
            }));

            KitCommands.register(root);
            ExtraCommands.register(root);
            dispatcher.register(root);
        });
    }

    /** account add | list | remove <nick> */
    private static LiteralArgumentBuilder<FabricClientCommandSource> accountCommands() {
        return ClientCommandManager.literal("account")
                .then(ClientCommandManager.literal("add").executes(ctx -> {
                    RemoteControl.say("Вход в аккаунт Microsoft для бота: жди код...");
                    Auth.deviceLogin(RemoteControl::say);
                    return 1;
                }))
                .then(ClientCommandManager.literal("list").executes(ctx -> {
                    say(ctx.getSource(), "Аккаунты для online-серверов (ник бота = ник аккаунта): " + Auth.describe());
                    return 1;
                }))
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("nick", StringArgumentType.word()).executes(ctx -> {
                    boolean ok = Auth.remove(StringArgumentType.getString(ctx, "nick"));
                    say(ctx.getSource(), ok ? "Аккаунт удалён." : "Такого сохранённого аккаунта нет.");
                    return ok ? 1 : 0;
                })));
    }

    private static int join(FabricClientCommandSource src, String ip, String nicks, String tier, String mode, String team) {
        Tier t = Tier.parse(tier);
        Mode m = Mode.parse(mode);
        int n = BotManager.INSTANCE.join(ip, nicks, t, m, team);
        say(src, "Запускаю " + n + " бот(ов) → " + ip + " | " + t + " | " + m + " | команда " + team
                + " | вход раз в " + BotManager.INSTANCE.staggerMs + " мс. Статус: /botlab list");
        return n;
    }

    private static int leave(FabricClientCommandSource src, String nick) {
        int n = BotManager.INSTANCE.leave(nick);
        say(src, "Отключено ботов: " + n);
        return n;
    }

    static void say(FabricClientCommandSource src, String msg) { src.sendFeedback(Component.literal(msg)); }

    static String modesHelp() { return Arrays.toString(Mode.values()); }
}
