package dev.duelforge.client;

import dev.duelforge.local.BotAction;
import dev.duelforge.local.LocalKit;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * Controller menu. With the mod on the server (or in singleplayer) it drives server-side bot entities; on any other
 * server the same buttons drive network bots ({@link RemoteControl}), so it works everywhere.
 * Same look and size as the Lab menu, vanilla widgets only. Tabs: Управление · Киты · HUD.
 */
public final class ControllerScreen extends Screen {
    private static final int PW = 336, PH = 336, TAB_W = 104, TAB_STEP = 106;
    private static final int TAB_CONTROL = 0, TAB_KITS = 1, TAB_HUD = 2;
    private static final int C_BG = 0xF0101418, C_BORDER = 0xFF2B343E, C_HEAD = 0xFF171D24, C_ACCENT = 0xFF35E0A1,
            C_TEXT = 0xFFE6EDF3, C_MUTED = 0xFF8B98A5, C_CARD = 0x30FFFFFF, C_OK = 0xFF5BE38A, C_BAD = 0xFFF2605C;

    private static int tab = TAB_CONTROL;
    private int px, py;
    /** true = buttons drive network bots (no mod on the server, or switched on by the player). */
    private boolean network;

    public ControllerScreen() { super(Component.literal("Duelforge Controller")); }

    @Override
    protected void init() {
        px = (this.width - PW) / 2;
        py = Math.max(4, (this.height - PH) / 2);
        network = RemoteControl.forceNetwork || !ClientPlayNetworking.canSend(BotAction.TYPE);
        int x = px + 10, y = py + 30;

        Hub.addSwitch(Hub.Menu.CONTROLLER, px, py, this::addRenderableWidget);

        String[] names = {"Управление", "Киты", "HUD"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Component label = Component.literal(names[i]);
            if (i == tab) label = Component.literal(names[i]).withStyle(ChatFormatting.GREEN);
            addRenderableWidget(Button.builder(label, b -> { tab = idx; this.rebuildWidgets(); })
                    .bounds(x + i * TAB_STEP, y, TAB_W, 18).build());
        }
        int y0 = py + 56;
        switch (tab) {
            case TAB_CONTROL -> initControl(x, y0);
            case TAB_KITS -> initKits(x, y0);
            default -> initHud(x, y0);
        }
    }

    private Button action(int x, int y, int w, String text, String id) {
        Button b = Button.builder(Component.literal(text), p -> send(id)).bounds(x, y, w, 20).build();
        addRenderableWidget(b);
        return b;
    }

    private void send(String id) {
        if (network) RemoteControl.handle(id);
        else if (ClientPlayNetworking.canSend(BotAction.TYPE)) ClientPlayNetworking.send(new BotAction(id));
    }

    private void initControl(int x, int y0) {
        int y = y0;
        action(x, y, 316, "Создать бота (макс. 4)", "spawn");
        action(x, y + 24, 316, "Следовать за мной", "follow");
        action(x, y + 48, 316, "Атаковать меня", "attack");
        action(x, y + 72, 316, "Сбросить цели", "clear");
        action(x, y + 96, 316, "Удалить моих ботов", "despawn");
        String[] t = {"1 быстр.", "2", "3", "4", "5 медл."};
        for (int i = 0; i < 5; i++) action(x + i * 64, y + 146, 60, t[i], "tier_" + (i + 1));
        addRenderableWidget(Button.builder(Component.literal(modeLabel()), b -> {
            RemoteControl.forceNetwork = !RemoteControl.forceNetwork;
            this.rebuildWidgets();
        }).bounds(x, y + 226, 316, 20).build());
    }

    private String modeLabel() {
        if (network && !ClientPlayNetworking.canSend(BotAction.TYPE)) return "Боты: сетевые (на этом сервере нет мода)";
        return network ? "Боты: сетевые, умный ИИ  (нажми: вернуть сущности)" : "Боты: сущности мода  (нажми: умные сетевые боты)";
    }

    private void initKits(int x, int y0) {
        LocalKit[] kits = LocalKit.values();
        for (int i = 0; i < kits.length; i++) {
            int col = i % 2, row = i / 2;
            action(x + col * 160 + 20, y0 + row * 26, 136, kits[i].title, kits[i].id);
        }
    }

    private void initHud(int x, int y0) {
        addRenderableWidget(Button.builder(Component.literal("HUD ботов: " + (ControllerHud.enabled ? "вкл" : "выкл")), b -> {
            ControllerHud.enabled = !ControllerHud.enabled;
            b.setMessage(Component.literal("HUD ботов: " + (ControllerHud.enabled ? "вкл" : "выкл")));
        }).bounds(x, y0, 316, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Позиция: " + ControllerHud.POSITIONS[ControllerHud.position]), b -> {
            ControllerHud.position = (ControllerHud.position + 1) % 4;
            b.setMessage(Component.literal("Позиция: " + ControllerHud.POSITIONS[ControllerHud.position]));
        }).bounds(x, y0 + 24, 316, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Тема: " + ControllerHud.THEMES[ControllerHud.theme]), b -> {
            ControllerHud.theme = (ControllerHud.theme + 1) % 3;
            b.setMessage(Component.literal("Тема: " + ControllerHud.THEMES[ControllerHud.theme]));
        }).bounds(x, y0 + 48, 316, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, C_BORDER);
        g.fill(px, py, px + PW, py + PH, C_BG);
        g.fill(px, py, px + PW, py + 26, C_HEAD);
        g.fill(px, py + 26, px + PW, py + 28, C_ACCENT);
        g.drawString(this.font, Component.literal("Duelforge").withStyle(ChatFormatting.BOLD), px + 10, py + 9, C_TEXT);
        String right = (network ? RemoteControl.mine().size() : ControllerHud.countLoaded()) + " бот.";
        g.drawString(this.font, right, px + PW - 10 - this.font.width(right), py + 9, C_MUTED);
        g.fill(px + 10 + tab * TAB_STEP, py + 48, px + 10 + tab * TAB_STEP + TAB_W, py + 50, C_ACCENT);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int x = px + 10, y0 = py + 56;
        switch (tab) {
            case TAB_CONTROL -> {
                int y = y0;
                g.drawString(this.font, network ? "СКОРОСТЬ НОВЫХ БОТОВ  (1 = сильнее всех)" : "ТИР СКОРОСТИ  (1 = быстрее всех)", x, y + 132, C_MUTED);
                g.fill(x, y + 176, x + 316, y + 218, C_CARD);
                g.fill(x, y + 176, x + 2, y + 218, C_ACCENT);
                if (network) {
                    java.util.List<String> st = RemoteControl.statusLines();
                    if (st.isEmpty()) wrap(g, RemoteControl.lastMessage.isEmpty()
                            ? "Работает на любом сервере: боты заходят как обычные игроки. Online-серверу нужен аккаунт: /df account add. Пусто = нажми «Создать бота»."
                            : RemoteControl.lastMessage, x + 8, y + 180, 304, C_TEXT, 3);
                    else for (int i = 0; i < Math.min(4, st.size()); i++)
                        g.drawString(this.font, this.font.plainSubstrByWidth(st.get(i), 304), x + 8, y + 180 + i * 10, C_TEXT);
                } else {
                    wrap(g, "Боты-сущности мода на сервере (одиночка или сервер с Duelforge). Простая ближняя ИИ. Умные боты (режимы, комбо, дуэли) - кнопка ниже или вкладка «Лаб».", x + 8, y + 180, 304, C_TEXT, 3);
                }
            }
            case TAB_KITS -> {
                LocalKit[] kits = LocalKit.values();
                for (int i = 0; i < kits.length; i++) {
                    int col = i % 2, row = i / 2;
                    g.renderItem(new ItemStack(kits[i].icon), x + col * 160, y0 + row * 26 + 2);
                }
                wrap(g, network ? "Киты выдаются командами /item replace с твоего аккаунта (нужны права оператора) и задают режим ботов."
                        : "Киты меняют экипировку существующих ботов. Скорость задаётся тиром.", x, y0 + 8 * 26 + 4, 316, C_MUTED, 2);
            }
            default -> wrap(g, "Карточки ботов: здоровье, дистанция, прочность брони, тотемы.", x, y0 + 76, 316, C_MUTED, 2);
        }
    }

    private void wrap(GuiGraphics g, String text, int x, int y, int maxW, int color, int maxLines) {
        String rest = text;
        for (int i = 0; i < maxLines && !rest.isEmpty(); i++) {
            String line = this.font.plainSubstrByWidth(rest, maxW);
            if (line.length() < rest.length()) {
                int sp = line.lastIndexOf(' ');
                if (sp > 0) line = line.substring(0, sp);
            }
            g.drawString(this.font, line, x, y + i * 11, color);
            rest = rest.substring(line.length()).trim();
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
