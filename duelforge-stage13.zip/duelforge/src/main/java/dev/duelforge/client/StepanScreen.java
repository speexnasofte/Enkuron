package dev.duelforge.client;

import dev.duelforge.stepan.bot.BotSettings;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Third menu of the hub: settings of the ported PVP Bot (pvp-bot-fabric by Stepan1411, Unlicense, package
 * dev.duelforge.stepan). Same look and size as the Lab / Controller menus. Tabs: Бой · Утилиты · Реализм.
 * Edits BotSettings directly (singleplayer / the server that runs this mod).
 */
public final class StepanScreen extends Screen {
    private static final int PW = 336, PH = 336, TAB_W = 104, TAB_STEP = 106;
    private static final int C_BG = 0xF0101418, C_BORDER = 0xFF2B343E, C_HEAD = 0xFF171D24, C_ACCENT = 0xFF35E0A1,
            C_TEXT = 0xFFE6EDF3, C_MUTED = 0xFF8B98A5;

    private static int tab = 0;
    private int px, py;

    public StepanScreen() { super(Component.literal("Duelforge PVP Bot")); }

    @Override
    protected void init() {
        px = (this.width - PW) / 2;
        py = Math.max(4, (this.height - PH) / 2);
        int x = px + 10, y = py + 30;

        Hub.addSwitch(Hub.Menu.STEPAN, px, py, this::addRenderableWidget);

        String[] names = {"Бой", "Утилиты", "Реализм"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Component label = Component.literal(names[i]);
            if (i == tab) label = Component.literal(names[i]).withStyle(ChatFormatting.GREEN);
            addRenderableWidget(Button.builder(label, b -> { tab = idx; this.rebuildWidgets(); })
                    .bounds(x + i * TAB_STEP, y, TAB_W, 18).build());
        }

        addRenderableWidget(Button.builder(Component.literal("GUI (Prism)"),
                b -> Minecraft.getInstance().setScreen(new dev.duelforge.client.expa.ExpaScreen()))
                .bounds(px + PW - 106, py + PH - 40, 96, 20).build());

        BotSettings s = BotSettings.get();
        int y0 = py + 56;
        switch (tab) {
            case 0 -> {
                toggle(0, y0, 0, "Бой", s::isCombatEnabled, s::setCombatEnabled);
                toggle(1, y0, 0, "Месть", s::isRevengeEnabled, s::setRevengeEnabled);
                toggle(0, y0, 1, "Авто-цель", s::isAutoTargetEnabled, s::setAutoTargetEnabled);
                toggle(1, y0, 1, "Цель: игроки", s::isTargetPlayers, s::setTargetPlayers);
                toggle(0, y0, 2, "Цель: мобы", s::isTargetHostileMobs, s::setTargetHostileMobs);
                toggle(1, y0, 2, "Цель: боты", s::isTargetOtherBots, s::setTargetOtherBots);
                toggle(0, y0, 3, "Криты", s::isCriticalsEnabled, s::setCriticalsEnabled);
                toggle(1, y0, 3, "Лук / арбалет", s::isRangedEnabled, s::setRangedEnabled);
                toggle(0, y0, 4, "Булава", s::isMaceEnabled, s::setMaceEnabled);
                toggle(1, y0, 4, "Crystal PvP", s::isCrystalPvpEnabled, s::setCrystalPvpEnabled);
                toggle(0, y0, 5, "Anchor PvP", s::isAnchorPvpEnabled, s::setAnchorPvpEnabled);
                stepperD(y0, 6, "Дальность ближнего боя", 0.5, s::getMeleeRange, s::setMeleeRange);
                stepperD(y0, 7, "Скорость движения", 0.1, s::getMoveSpeed, s::setMoveSpeed);
            }
            case 1 -> {
                toggle(0, y0, 0, "Авто-броня", s::isAutoEquipArmor, s::setAutoEquipArmor);
                toggle(1, y0, 0, "Авто-оружие", s::isAutoEquipWeapon, s::setAutoEquipWeapon);
                toggle(0, y0, 1, "Авто-тотем", s::isAutoTotemEnabled, s::setAutoTotemEnabled);
                toggle(1, y0, 1, "Авто-щит", s::isAutoShieldEnabled, s::setAutoShieldEnabled);
                toggle(0, y0, 2, "Авто-еда", s::isAutoEatEnabled, s::setAutoEatEnabled);
                toggle(1, y0, 2, "Авто-зелья", s::isAutoPotionEnabled, s::setAutoPotionEnabled);
                toggle(0, y0, 3, "Авто-починка", s::isAutoMendEnabled, s::setAutoMendEnabled);
                toggle(1, y0, 3, "Bhop", s::isBhopEnabled, s::setBhopEnabled);
                toggle(0, y0, 4, "Бродить без цели", s::isIdleWanderEnabled, s::setIdleWanderEnabled);
                toggle(1, y0, 4, "Фракции", s::isFactionsEnabled, s::setFactionsEnabled);
                toggle(0, y0, 5, "Огонь по своим", s::isFriendlyFireEnabled, s::setFriendlyFireEnabled);
            }
            default -> {
                stepperI(y0, 0, "Шанс промаха, %", 5, s::getMissChance, s::setMissChance);
                stepperI(y0, 1, "Шанс ошибки, %", 5, s::getMistakeChance, s::setMistakeChance);
                toggle(0, y0, 2, "Особые ники", s::isUseSpecialNames, s::setUseSpecialNames);
                toggle(1, y0, 2, "Уходит после смерти", s::isBotLeaveOnDeath, s::setBotLeaveOnDeath);
            }
        }
    }

    private void toggle(int col, int y0, int row, String text, BooleanSupplier get, Consumer<Boolean> set) {
        addRenderableWidget(Button.builder(toggleLabel(text, get.getAsBoolean()), b -> {
            boolean v = !get.getAsBoolean();
            set.accept(v);
            b.setMessage(toggleLabel(text, v));
        }).bounds(px + 10 + col * 160, y0 + row * 24, 156, 20).build());
    }

    private static Component toggleLabel(String text, boolean on) {
        return Component.literal(text + ": " + (on ? "вкл" : "выкл")).withStyle(on ? ChatFormatting.GREEN : ChatFormatting.GRAY);
    }

    private void stepperD(int y0, int row, String text, double step, DoubleSupplier get, DoubleConsumer set) {
        int y = y0 + row * 24, x = px + 10;
        Button label = Button.builder(Component.literal(valueD(text, get.getAsDouble())), b -> { })
                .bounds(x + 22, y, 272, 20).build();
        label.active = false;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            set.accept(round(get.getAsDouble() - step));
            label.setMessage(Component.literal(valueD(text, get.getAsDouble())));
        }).bounds(x, y, 20, 20).build());
        addRenderableWidget(label);
        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            set.accept(round(get.getAsDouble() + step));
            label.setMessage(Component.literal(valueD(text, get.getAsDouble())));
        }).bounds(x + 296, y, 20, 20).build());
    }

    private void stepperI(int y0, int row, String text, int step, IntSupplier get, IntConsumer set) {
        int y = y0 + row * 24, x = px + 10;
        Button label = Button.builder(Component.literal(text + ": " + get.getAsInt()), b -> { })
                .bounds(x + 22, y, 272, 20).build();
        label.active = false;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            set.accept(get.getAsInt() - step);   // BotSettings clamps to its own range
            label.setMessage(Component.literal(text + ": " + get.getAsInt()));
        }).bounds(x, y, 20, 20).build());
        addRenderableWidget(label);
        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            set.accept(get.getAsInt() + step);
            label.setMessage(Component.literal(text + ": " + get.getAsInt()));
        }).bounds(x + 296, y, 20, 20).build());
    }

    private static double round(double v) { return Math.round(v * 10.0) / 10.0; }

    private static String valueD(String text, double v) { return text + ": " + round(v); }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, C_BORDER);
        g.fill(px, py, px + PW, py + PH, C_BG);
        g.fill(px, py, px + PW, py + 26, C_HEAD);
        g.fill(px, py + 26, px + PW, py + 28, C_ACCENT);
        g.drawString(this.font, Component.literal("Duelforge").withStyle(ChatFormatting.BOLD), px + 10, py + 9, C_TEXT);
        g.fill(px + 10 + tab * TAB_STEP, py + 48, px + 10 + tab * TAB_STEP + TAB_W, py + 50, C_ACCENT);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        String note = "Настройки PVP Bot (Stepan1411, Unlicense). Спавн ботов: herobot (отдельный мод).";
        g.drawString(this.font, this.font.plainSubstrByWidth(note, 316), px + 10, py + PH - 16, C_MUTED);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
