package dev.duelforge.client.expa;

import top.fpsmaster.prism.theme.Argb;

/**
 * Colour tokens of the "Expensive" menu. The dark values are the tone tables of the original
 * default dark theme (accent 6E74E3, frame 151617, surface 0F1011 ...). The light set is derived.
 */
final class ExpaPalette {
    static final ExpaPalette DARK = new ExpaPalette(false);
    static final ExpaPalette LIGHT = new ExpaPalette(true);

    final boolean light;
    final int accent, accentBright, favorite, error;
    final int windowFill, windowOutline, cardFill, cardOutline, cardOutlineHover;
    final int text50, text100, text200, text300, text400, text500, text600;
    final int chipOutline, inputFill, inputOutline, trackBg;
    final int offFill, offOutline, offKnob, hoverFill, divider, veil;

    private ExpaPalette(boolean light) {
        this.light = light;
        accent = 0xFF6E74E3;
        accentBright = 0xFF8186EA;
        favorite = 0xFFFDC95A;
        error = 0xFFED4561;
        if (!light) {
            windowFill = 0xFF0F1011;
            windowOutline = 0xFF1F2023;
            cardFill = 0xFF151617;
            cardOutline = 0x0FFFFFFF;
            cardOutlineHover = 0x1FFFFFFF;
            text50 = 0xFFF0F1F4;
            text100 = 0xFFE3E4E7;
            text200 = 0xFFDADCE2;
            text300 = 0xFFC5C6C8;
            text400 = 0xFFB4B5BA;
            text500 = 0xFF868791;
            text600 = 0xFF76777E;
            chipOutline = 0xFF222325;
            inputFill = 0xFF1E1F22;
            inputOutline = 0xFF282A2E;
            trackBg = 0xFF26272A;
            offFill = 0xFF1E1F22;
            offOutline = 0xFF282A2E;
            offKnob = 0xFF565659;
            hoverFill = 0x14FFFFFF;
            divider = 0x12FFFFFF;
            veil = 150;
        } else {
            windowFill = 0xFFF3F4F6;
            windowOutline = 0xFFD9DBE0;
            cardFill = 0xFFFFFFFF;
            cardOutline = 0x14000000;
            cardOutlineHover = 0x26000000;
            text50 = 0xFF111215;
            text100 = 0xFF1C1D20;
            text200 = 0xFF2A2C31;
            text300 = 0xFF4A4C53;
            text400 = 0xFF666872;
            text500 = 0xFF868791;
            text600 = 0xFF9C9DA5;
            chipOutline = 0xFFD9DBE0;
            inputFill = 0xFFF1F2F4;
            inputOutline = 0xFFDCDEE3;
            trackBg = 0xFFE3E5E9;
            offFill = 0xFFE6E8EC;
            offOutline = 0xFFD4D6DC;
            offKnob = 0xFFFFFFFF;
            hoverFill = 0x0F000000;
            divider = 0x14000000;
            veil = 90;
        }
    }

    int mix(int a, int b, float t) {
        return Argb.lerp(a, b, t);
    }
}
