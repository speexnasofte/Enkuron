package dev.duelforge.client;

import dev.duelforge.ai.Combo;
import dev.duelforge.ai.DuelManager;
import dev.duelforge.ai.Kit;
import dev.duelforge.ai.KitStore;
import dev.duelforge.ai.Inventory;
import dev.duelforge.ai.Layout;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Tier;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Control panel (open with /botlab gui). Tabs: Запуск (launch), Боты (live list), Киты (own kit system), Опции.
 * Only vanilla widgets are used (Button / EditBox); the dark panel, header, tab underline and all labels are drawn
 * by this class, so the layout does not depend on widget internals that change between Minecraft versions.
 */
public final class BotScreen extends Screen {
    private static final int PW = 336, PH = 336, ROWS = 6, ROW_H = 24, KROWS = 5, KROW_H = 26, TAB_W = 43, TAB_STEP = 45;
    private static final int TAB_LAUNCH = 0, TAB_BOTS = 1, TAB_KITS = 2, TAB_DUEL = 3, TAB_NPC = 4, TAB_COMBO = 5, TAB_OPTS = 6;
    private static final int C_BG = 0xF0101418, C_BORDER = 0xFF2B343E, C_HEAD = 0xFF171D24, C_ACCENT = 0xFF35E0A1,
            C_TEXT = 0xFFE6EDF3, C_MUTED = 0xFF8B98A5, C_CARD = 0x30FFFFFF, C_OK = 0xFF5BE38A, C_WARN = 0xFFF2C14E, C_BAD = 0xFFF2605C;

    // state survives closing and reopening the screen
    private static String ip = "", nicks = "Bot*10", team = "A", cmd = "", kitName = "", kitStatus = "";
    private static String selKit = null, detailBot = null;
    private static int tierIdx = Tier.HT3.ordinal(), tab = 0, page = 0, kitPage = 0;
    private static Mode mode = Mode.SWORD;
    private static String duelA = "DuelA", duelB = "", npcNick = "NPC", duelStatus = "", npcStatus = "";
    private static int duelTierB = Tier.HT3.ordinal();
    private static Combo.Kind comboSel = Combo.Kind.W_TAP;

    private EditBox ipBox, nickBox, teamBox, cmdBox, kitBox, duelABox, duelBBox, npcBox;
    private int px, py, shownBots = -1;
    private String launchKitText = "";

    public BotScreen() { super(Component.literal("Duelforge Lab")); }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        px = (this.width - PW) / 2;
        py = Math.max(4, (this.height - PH) / 2);
        int x = px + 10, y = py + 30;

        Hub.addSwitch(Hub.Menu.LAB, px, py, this::addRenderableWidget);

        String[] names = {"Запуск", "Боты", "Киты", "Дуэль", "NPC", "Комбо", "Опции"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Component label = Component.literal(names[i]);
            if (i == tab) label = Component.literal(names[i]).withStyle(ChatFormatting.GREEN);
            addRenderableWidget(Button.builder(label, b -> { capture(); tab = idx; page = 0; this.rebuildWidgets(); })
                    .bounds(x + i * TAB_STEP, y, TAB_W, 18).build());
        }

        int y0 = py + 56;
        switch (tab) {
            case TAB_LAUNCH -> initLaunch(x, y0);
            case TAB_BOTS -> initBots(x, y0);
            case TAB_KITS -> initKits(x, y0);
            case TAB_DUEL -> initDuel(x, y0);
            case TAB_NPC -> initNpc(x, y0);
            case TAB_COMBO -> initCombo(x, y0);
            default -> initOptions(x, y0);
        }
    }

    private void initLaunch(int x, int y0) {
        ipBox = box(x, y0, 316, 128, ip, "IP сервера (пусто = твой текущий мир / сервер)");
        nickBox = box(x, y0 + 24, 196, 256, nicks, "Ники: A,B,C или Bot*20");
        teamBox = box(x + 200, y0 + 24, 116, 16, team, "Команда");
        cmdBox = box(x, y0 + 48, 316, 128, cmd, "Команда после входа (например kit pvp)");

        Tier[] tiers = Tier.values();
        for (int i = 0; i < tiers.length; i++) {
            final int idx = i;
            String tn = tiers[i].max() ? "MAX" : tiers[i].name();
            Component label = Component.literal(tn);
            if (i == tierIdx) label = Component.literal(tn).withStyle(ChatFormatting.BOLD, ChatFormatting.GREEN);
            else if (tiers[i].max()) label = Component.literal(tn).withStyle(ChatFormatting.GOLD);
            else if (i < 4) label = Component.literal(tn).withStyle(ChatFormatting.GRAY);
            addRenderableWidget(Button.builder(label, b -> { capture(); tierIdx = idx; this.rebuildWidgets(); })
                    .bounds(x + (int) (i * 28.8), y0 + 90, 28, 18).build());
        }

        int gi = 0;
        for (Mode m : Mode.values()) {
            if (m == Mode.NPC) continue;                      // NPC has its own tab
            Component label = Component.literal(m.label);
            if (m == mode) label = Component.literal(m.label).withStyle(ChatFormatting.BOLD, ChatFormatting.GREEN);
            final Mode mm = m;
            addRenderableWidget(Button.builder(label, b -> { capture(); mode = mm; this.rebuildWidgets(); })
                    .bounds(x + (gi % 5) * 63, y0 + 124 + (gi / 5) * 18, 62, 16).build());
            gi++;
        }

        launchKitText = kitCardText();

        addRenderableWidget(Button.builder(Component.literal("Запустить ботов").withStyle(ChatFormatting.GREEN), b -> {
            capture();
            String host = RemoteControl.resolveHost(ip);
            if (host != null && !nicks.isBlank()) {
                if (!cmd.isBlank()) { BotManager.INSTANCE.joinCommands.clear(); BotManager.INSTANCE.joinCommands.add(cmd); }
                BotManager.INSTANCE.join(host, nicks, Tier.values()[tierIdx], mode, team.isBlank() ? "A" : team);
                tab = 1; page = 0;
                this.rebuildWidgets();
            }
        }).bounds(x, y0 + 246, 156, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Отключить всех").withStyle(ChatFormatting.RED),
                b -> { BotManager.INSTANCE.leave("all"); this.rebuildWidgets(); }).bounds(x + 160, y0 + 246, 156, 20).build());
    }

    private String kitCardText() {
        Kit k = Opts.selectedKit == null ? null : KitStore.get(Opts.selectedKit);
        if (k == null) return "Хотбар: " + mode.kit;
        Mode m = k.mode == null ? mode : k.mode;
        return "Кит «" + k.name + "» (вкладка «Киты»): режим " + m.label + ", раскладка: " + Layout.detect(m, k.hotbarItems()).describe();
    }

    private void initBots(int x, int y0) {
        if (detailBot != null) { initDetail(x, y0); return; }
        List<BotClient> bots = BotManager.INSTANCE.list();
        shownBots = bots.size();
        int pages = Math.max(1, (bots.size() + ROWS - 1) / ROWS);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= bots.size()) break;
            final String nick = bots.get(idx).name;
            addRenderableWidget(Button.builder(Component.literal("x").withStyle(ChatFormatting.RED),
                    b -> { BotManager.INSTANCE.leave(nick); this.rebuildWidgets(); })
                    .bounds(x + 316 - 18, y0 + 14 + i * ROW_H + 2, 18, 18).build());
            addRenderableWidget(Button.builder(Component.literal("i"), b -> { detailBot = nick; this.rebuildWidgets(); })
                    .bounds(x + 316 - 40, y0 + 14 + i * ROW_H + 2, 20, 18).build());
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { page = Math.max(0, page - 1); this.rebuildWidgets(); })
                .bounds(x, y0 + 14 + ROWS * ROW_H + 8, 24, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { page++; this.rebuildWidgets(); })
                .bounds(x + 28, y0 + 14 + ROWS * ROW_H + 8, 24, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Отключить всех").withStyle(ChatFormatting.RED),
                b -> { BotManager.INSTANCE.leave("all"); this.rebuildWidgets(); })
                .bounds(x + 316 - 120, y0 + 14 + ROWS * ROW_H + 8, 120, 18).build());
    }

    private void initDetail(int x, int y0) {
        addRenderableWidget(Button.builder(Component.literal("< Назад"), b -> { detailBot = null; this.rebuildWidgets(); })
                .bounds(x, y0, 70, 18).build());
    }

    private void initKits(int x, int y0) {
        List<String> kits = KitStore.names();
        int pages = Math.max(1, (kits.size() + KROWS - 1) / KROWS);
        kitPage = Math.max(0, Math.min(kitPage, pages - 1));
        for (int i = 0; i < KROWS; i++) {
            int idx = kitPage * KROWS + i;
            if (idx >= kits.size()) break;
            final String n = kits.get(idx);
            int ry = y0 + 12 + i * KROW_H;
            Component label = Component.literal(n);
            if (n.equalsIgnoreCase(selKit)) label = Component.literal(n).withStyle(ChatFormatting.BOLD, ChatFormatting.GREEN);
            addRenderableWidget(Button.builder(label, b -> { capture(); selKit = n; kitName = n; KitActions.last = n; this.rebuildWidgets(); })
                    .bounds(x, ry, 196, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Мне"), b -> { kitStatus = KitActions.load(n); })
                    .bounds(x + 200, ry, 56, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Боты"), b -> { kitStatus = KitActions.give(n, "all"); })
                    .bounds(x + 260, ry, 56, 22).build());
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { capture(); kitPage = Math.max(0, kitPage - 1); this.rebuildWidgets(); })
                .bounds(x, y0 + 146, 24, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { capture(); kitPage++; this.rebuildWidgets(); })
                .bounds(x + 28, y0 + 146, 24, 18).build());

        kitBox = box(x, y0 + 172, 200, 32, kitName, "Имя кита");
        addRenderableWidget(Button.builder(Component.literal("Сохранить с меня").withStyle(ChatFormatting.GREEN), b -> {
            capture();
            kitStatus = KitActions.save(kitName);
            String n = KitStore.sanitize(kitName);
            if (KitStore.get(n) != null) selKit = n;
            this.rebuildWidgets();
        }).bounds(x + 204, y0 + 172, 112, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Переименовать"), b -> {
            capture();
            kitStatus = KitActions.rename(selKit, kitName);
            if (KitStore.get(KitStore.sanitize(kitName)) != null) selKit = KitStore.sanitize(kitName);
            this.rebuildWidgets();
        }).bounds(x, y0 + 196, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Удалить").withStyle(ChatFormatting.RED), b -> {
            kitStatus = KitActions.delete(selKit); selKit = null; this.rebuildWidgets();
        }).bounds(x + 106, y0 + 196, 104, 20).build());
        Kit sel = selKit == null ? null : KitStore.get(selKit);
        addRenderableWidget(Button.builder(Component.literal("Режим: " + (sel == null || sel.mode == null ? "-" : sel.mode.label)), b -> {
            kitStatus = KitActions.cycleMode(selKit); this.rebuildWidgets();
        }).bounds(x + 212, y0 + 196, 104, 20).build());

        boolean used = selKit != null && selKit.equalsIgnoreCase(Opts.selectedKit);
        addRenderableWidget(Button.builder(Component.literal("Для запуска ботов: " + (used ? "ДА" : "нет")), b -> {
            kitStatus = KitActions.use(used ? null : selKit); this.rebuildWidgets();
        }).bounds(x, y0 + 220, 316, 20).build());
    }


    // ------------------------------------------------------------------ duel tab

    private void initDuel(int x, int y0) {
        duelABox = box(x, y0 + 12, 154, 16, duelA, "Бот A (ник)");
        duelBBox = box(x + 162, y0 + 12, 154, 16, duelB, "Бот B (пусто = ты)");
        Tier[] tiers = Tier.values();
        String tb = tiers[duelTierB].max() ? "MAX" : tiers[duelTierB].name();
        addRenderableWidget(Button.builder(Component.literal("Тир B: " + tb), b -> {
            capture(); duelTierB = (duelTierB + 1) % tiers.length; this.rebuildWidgets();
        }).bounds(x, y0 + 36, 154, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            capture(); DuelManager.INSTANCE.firstTo = Math.max(1, DuelManager.INSTANCE.firstTo - 1); this.rebuildWidgets();
        }).bounds(x + 162, y0 + 36, 24, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            capture(); DuelManager.INSTANCE.firstTo = Math.min(50, DuelManager.INSTANCE.firstTo + 1); this.rebuildWidgets();
        }).bounds(x + 292, y0 + 36, 24, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Старт дуэли").withStyle(ChatFormatting.GREEN), b -> {
            capture();
            String host = RemoteControl.resolveHost(ip);
            if (host == null) { duelStatus = "Зайди в мир или на сервер, либо введи IP на вкладке «Запуск»."; return; }
            String a = duelA.isBlank() ? "DuelA" : duelA.trim();
            Tier tA = Tier.values()[tierIdx], tB = Tier.values()[duelTierB];
            int first = DuelManager.INSTANCE.firstTo;
            if (duelB.isBlank()) {
                String me = Minecraft.getInstance().getUser().getName();
                BotManager.INSTANCE.startDuelVsPlayer(host, a, tA, mode, first, me);
                duelStatus = "Бот " + a + " (" + tA + ", " + mode.label + ") против тебя. Если твоя смерть не засчиталась - «+1 B».";
            } else {
                BotManager.INSTANCE.startDuelBots(host, a, duelB.trim(), tA, tB, mode, first);
                duelStatus = "Дуэль ботов: " + a + " (" + tA + ") vs " + duelB.trim() + " (" + tB + "), режим " + mode.label + ".";
            }
            this.rebuildWidgets();
        }).bounds(x, y0 + 62, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Стоп").withStyle(ChatFormatting.RED), b -> {
            DuelManager.INSTANCE.stop(); BotManager.INSTANCE.leave(duelA.isBlank() ? "DuelA" : duelA.trim());
            if (!duelB.isBlank()) BotManager.INSTANCE.leave(duelB.trim());
            this.rebuildWidgets();
        }).bounds(x + 160, y0 + 62, 156, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+1 A"), b -> DuelManager.INSTANCE.point(DuelManager.INSTANCE.nameA()))
                .bounds(x, y0 + 214, 76, 18).build());
        addRenderableWidget(Button.builder(Component.literal("+1 B"), b -> DuelManager.INSTANCE.point(DuelManager.INSTANCE.nameB()))
                .bounds(x + 80, y0 + 214, 76, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Реванш"), b -> DuelManager.INSTANCE.rematch())
                .bounds(x + 160, y0 + 214, 76, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Сброс"), b -> { DuelManager.INSTANCE.reset(); duelStatus = ""; })
                .bounds(x + 240, y0 + 214, 76, 18).build());
    }

    private void drawDuel(GuiGraphics g, int x, int y0) {
        DuelManager d = DuelManager.INSTANCE;
        g.drawString(this.font, "Тир A и режим - с вкладки «Запуск»   ·   до " + d.firstTo + " побед", x, y0, C_MUTED);
        g.drawString(this.font, "до " + d.firstTo, x + 214, y0 + 42, C_TEXT);

        int cy = y0 + 88;
        g.fill(x, cy, x + 316, cy + 60, C_CARD);
        g.fill(x, cy, x + 2, cy + 60, d.active ? C_ACCENT : C_MUTED);
        if (!d.has()) {
            g.drawString(this.font, "Дуэли нет. Пустое поле «Бот B» = бот против тебя.", x + 8, cy + 24, C_MUTED);
        } else {
            String l = this.font.plainSubstrByWidth(d.nameA(), 120), r = this.font.plainSubstrByWidth(d.nameB(), 120);
            g.drawString(this.font, l, x + 8, cy + 6, C_TEXT);
            g.drawString(this.font, r, x + 308 - this.font.width(r), cy + 6, C_TEXT);
            String sc = d.scoreA() + "  :  " + d.scoreB();
            g.drawString(this.font, sc, x + 158 - this.font.width(sc) / 2, cy + 20, C_ACCENT);
            g.drawString(this.font, botLine(d.nameA()), x + 8, cy + 20 + 12, C_MUTED);
            String rl = botLine(d.nameB());
            g.drawString(this.font, rl, x + 308 - this.font.width(rl), cy + 32, C_MUTED);
            String st = d.active ? "идёт · раунд " + (d.scoreA() + d.scoreB() + 1) + (d.streakA() >= 2 ? " · серия A " + d.streakA() : "") + (d.streakB() >= 2 ? " · серия B " + d.streakB() : "")
                    : d.winner.isEmpty() ? "остановлена" : "победил " + d.winner;
            g.drawString(this.font, st, x + 158 - this.font.width(st) / 2, cy + 46, d.active ? C_OK : C_WARN);
        }
        List<String> log = d.log();
        for (int i = 0; i < 4; i++) {
            int idx = log.size() - 4 + i;
            if (idx < 0) continue;
            g.drawString(this.font, this.font.plainSubstrByWidth(log.get(idx), 316), x, y0 + 154 + i * 11, C_MUTED);
        }
        if (!duelStatus.isEmpty()) wrap(g, duelStatus, x, y0 + 238, 316, C_TEXT, 2);
    }

    private String botLine(String nick) {
        for (BotClient c : BotManager.INSTANCE.list()) {
            if (c.name.equalsIgnoreCase(nick)) return "HP " + Math.round(c.health()) + " · уд. " + c.hits() + " · смертей " + c.deaths;
        }
        return "(ты или не в игре)";
    }

    // ------------------------------------------------------------------ npc tab

    private void initNpc(int x, int y0) {
        npcBox = box(x, y0 + 12, 316, 64, npcNick, "Ник NPC: NPC или NPC*5");
        addRenderableWidget(Button.builder(Component.literal("Спавн NPC: " + Opts.npcTotems + " тотемов в каждой руке").withStyle(ChatFormatting.GREEN), b -> {
            capture();
            String host = RemoteControl.resolveHost(ip);
            if (host == null) { npcStatus = "Зайди в мир или на сервер, либо введи IP на вкладке «Запуск»."; return; }
            int n = BotManager.INSTANCE.spawnNpc(host, npcNick.isBlank() ? "NPC" : npcNick.trim());
            npcStatus = "NPC: " + n + " шт. Тотемы выдаются командами /item replace - нужны права оператора "
                    + (Opts.kitViaBots ? "у самих ботов (вкладка «Опции»)." : "у тебя.");
            this.rebuildWidgets();
        }).bounds(x, y0 + 38, 316, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Бьёт в ответ: " + (Opts.npcFight ? "ДА" : "нет")), b -> {
            Opts.npcFight = !Opts.npcFight; this.rebuildWidgets();
        }).bounds(x, y0 + 68, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Незерит-броня: " + (Opts.npcArmor ? "ДА" : "нет")), b -> {
            Opts.npcArmor = !Opts.npcArmor; this.rebuildWidgets();
        }).bounds(x + 160, y0 + 68, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> { Opts.npcTotems = Math.max(1, Opts.npcTotems - 10); this.rebuildWidgets(); })
                .bounds(x, y0 + 94, 38, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-1"), b -> { Opts.npcTotems = Math.max(1, Opts.npcTotems - 1); this.rebuildWidgets(); })
                .bounds(x + 42, y0 + 94, 38, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> { Opts.npcTotems = Math.min(99, Opts.npcTotems + 1); this.rebuildWidgets(); })
                .bounds(x + 236, y0 + 94, 38, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> { Opts.npcTotems = Math.min(99, Opts.npcTotems + 10); this.rebuildWidgets(); })
                .bounds(x + 278, y0 + 94, 38, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Убрать всех NPC").withStyle(ChatFormatting.RED), b -> {
            for (BotClient c : BotManager.INSTANCE.list()) if (c.mode == Mode.NPC) BotManager.INSTANCE.leave(c.name);
            this.rebuildWidgets();
        }).bounds(x, y0 + 120, 316, 20).build());
    }

    private void drawNpc(GuiGraphics g, int x, int y0) {
        g.drawString(this.font, "НИК (Name*5 = пять NPC)", x, y0, C_MUTED);
        String t = "тотемов: " + Opts.npcTotems;
        g.drawString(this.font, t, x + 158 - this.font.width(t) / 2, y0 + 100, C_TEXT);
        int n = 0;
        for (BotClient c : BotManager.INSTANCE.list()) if (c.mode == Mode.NPC) n++;
        g.drawString(this.font, "NPC сейчас: " + n, x, y0 + 148, C_MUTED);
        wrap(g, "NPC - бот-манекен: стоит, смотрит на ближнего игрока, не лечится и не меняет предметы. В обеих руках по "
                + Opts.npcTotems + " тотемов (стак поднят компонентом max_stack_size), поэтому он переживает " + (2 * Opts.npcTotems)
                + " смертей подряд. Удобно для теста урона, комбо и кристаллов.", x, y0 + 164, 316, C_MUTED, 5);
        if (!npcStatus.isEmpty()) wrap(g, npcStatus, x, y0 + 224, 316, C_TEXT, 3);
    }

    // ------------------------------------------------------------------ combo tab

    private void initCombo(int x, int y0) {
        addRenderableWidget(Button.builder(Component.literal("Комбо после удара: " + (Opts.combo ? "ВКЛ" : "ВЫКЛ")), b -> {
            Opts.combo = !Opts.combo; this.rebuildWidgets();
        }).bounds(x, y0 + 4, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Цепочки из двух: " + (Opts.comboChain ? "ВКЛ" : "ВЫКЛ")), b -> {
            Opts.comboChain = !Opts.comboChain; this.rebuildWidgets();
        }).bounds(x + 160, y0 + 4, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-0.1"), b -> { Opts.comboRate = Math.max(0.3, Math.round((Opts.comboRate - 0.1) * 10) / 10.0); this.rebuildWidgets(); })
                .bounds(x, y0 + 30, 44, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+0.1"), b -> { Opts.comboRate = Math.min(1.6, Math.round((Opts.comboRate + 0.1) * 10) / 10.0); this.rebuildWidgets(); })
                .bounds(x + 272, y0 + 30, 44, 20).build());
        int i = 0;
        for (Combo.Kind k : Combo.Kind.values()) {
            if (k == Combo.Kind.NONE) continue;
            final Combo.Kind kk = k;
            Component label = Component.literal(k.label + ": " + (Opts.comboOn(k) ? "ВКЛ" : "выкл"));
            if (k == comboSel) label = Component.literal(k.label + ": " + (Opts.comboOn(k) ? "ВКЛ" : "выкл")).withStyle(ChatFormatting.GREEN);
            addRenderableWidget(Button.builder(label, b -> {
                if (comboSel == kk) Opts.comboSet(kk, !Opts.comboOn(kk)); else comboSel = kk;
                this.rebuildWidgets();
            }).bounds(x + (i % 2) * 160, y0 + 58 + (i / 2) * 22, 156, 20).build());
            i++;
        }
        addRenderableWidget(Button.builder(Component.literal("Копьё: отход с разбега после тычка: " + (Opts.spearRunup ? "ВКЛ" : "ВЫКЛ")), b -> {
            Opts.spearRunup = !Opts.spearRunup; this.rebuildWidgets();
        }).bounds(x, y0 + 232, 316, 20).build());
    }

    private void drawCombo(GuiGraphics g, int x, int y0) {
        String r = "частота комбо: x" + String.format("%.1f", Opts.comboRate);
        g.drawString(this.font, r, x + 158 - this.font.width(r) / 2, y0 + 36, C_TEXT);
        g.drawString(this.font, "Нажми на комбо: первый клик выбирает (описание ниже), второй включает/выключает", x, y0 + 146, C_MUTED);
        g.fill(x, y0 + 158, x + 316, y0 + 194, C_CARD);
        g.fill(x, y0 + 158, x + 2, y0 + 194, C_ACCENT);
        wrap(g, comboSel.label + " - " + comboSel.info, x + 8, y0 + 162, 304, C_TEXT, 3);
        wrap(g, "Тиры: до HT4 - в-тап, с-тап, стрейф. LT3+ - прыжок-крит, орбита. LT2+ - двойной тап, приманка и цепочки. MAX крутит все по кругу.",
                x, y0 + 198, 316, C_MUTED, 3);
    }

    private void initOptions(int x, int y0) {
        addRenderableWidget(Button.builder(Component.literal("Обсидиан для кристаллов: " + Opts.obsidian),
                b -> { Opts.obsidian = Opts.obsidian.next(); this.rebuildWidgets(); }).bounds(x, y0, 316, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Замена тотема после попа: " + (Opts.totemRefill ? "ВКЛ" : "ВЫКЛ")),
                b -> { Opts.totemRefill = !Opts.totemRefill; this.rebuildWidgets(); }).bounds(x, y0 + 48, 316, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-500"), b -> { stagger(-500); this.rebuildWidgets(); })
                .bounds(x, y0 + 92, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+500"), b -> { stagger(500); this.rebuildWidgets(); })
                .bounds(x + 44, y0 + 92, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-1"), b -> { Opts.kitDelay = Math.max(1, Opts.kitDelay - 1); this.rebuildWidgets(); })
                .bounds(x, y0 + 118, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> { Opts.kitDelay = Math.min(40, Opts.kitDelay + 1); this.rebuildWidgets(); })
                .bounds(x + 44, y0 + 118, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Отладка: " + (BotClient.debug ? "ВКЛ" : "ВЫКЛ")),
                b -> { BotClient.debug = !BotClient.debug; this.rebuildWidgets(); }).bounds(x, y0 + 144, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Комбо-тапы: " + (Opts.combo ? "ВКЛ" : "ВЫКЛ")),
                b -> { Opts.combo = !Opts.combo; this.rebuildWidgets(); }).bounds(x + 160, y0 + 144, 156, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Авто-кит после входа: " + (Opts.autoKit ? "ВКЛ" : "ВЫКЛ")),
                b -> { Opts.autoKit = !Opts.autoKit; this.rebuildWidgets(); }).bounds(x, y0 + 170, 316, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Кит на ботов грузят: " + (Opts.kitViaBots ? "сами боты (оп)" : "твои команды")),
                b -> { Opts.kitViaBots = !Opts.kitViaBots; this.rebuildWidgets(); }).bounds(x, y0 + 196, 316, 20).build());
        // UHC / «Ловушки» tricks and the mace smash height
        addRenderableWidget(Button.builder(Component.literal("Ловушки: " + (Opts.traps ? "ВКЛ" : "выкл")),
                b -> { Opts.traps = !Opts.traps; this.rebuildWidgets(); }).bounds(x, y0 + 222, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Паутина: " + (Opts.trapWeb ? "ВКЛ" : "выкл")),
                b -> { Opts.trapWeb = !Opts.trapWeb; this.rebuildWidgets(); }).bounds(x + 106, y0 + 222, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Лава: " + (Opts.trapLava ? "ВКЛ" : "выкл")),
                b -> { Opts.trapLava = !Opts.trapLava; this.rebuildWidgets(); }).bounds(x + 212, y0 + 222, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Огонь: " + (Opts.trapFire ? "ВКЛ" : "выкл")),
                b -> { Opts.trapFire = !Opts.trapFire; this.rebuildWidgets(); }).bounds(x, y0 + 246, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Вода: " + (Opts.waterSteal ? "ВКЛ" : "выкл")),
                b -> { Opts.waterSteal = !Opts.waterSteal; this.rebuildWidgets(); }).bounds(x + 106, y0 + 246, 104, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Булава: от " + String.format("%.1f", Opts.maceMinFall) + " бл."),
                b -> { Opts.maceMinFall = Opts.maceMinFall < 2 ? 2.5 : Opts.maceMinFall < 3 ? 4 : Opts.maceMinFall < 5 ? 6 : 1.5; this.rebuildWidgets(); })
                .bounds(x + 212, y0 + 246, 104, 20).build());
    }

    private static void stagger(int d) {
        BotManager.INSTANCE.staggerMs = Math.max(0, Math.min(20000, BotManager.INSTANCE.staggerMs + d));
    }

    private EditBox box(int x, int y, int w, int max, String value, String hint) {
        EditBox e = new EditBox(this.font, x, y, w, 20, Component.literal(hint));
        e.setMaxLength(max);
        e.setValue(value);
        e.setHint(Component.literal(hint));
        addRenderableWidget(e);
        return e;
    }

    /** Copy the text boxes into the static fields before the widgets are rebuilt or the screen closes. */
    private void capture() {
        if (tab == 0 && ipBox != null) { ip = ipBox.getValue(); nicks = nickBox.getValue(); team = teamBox.getValue(); cmd = cmdBox.getValue(); }
        if (tab == 2 && kitBox != null) kitName = kitBox.getValue();
        if (tab == TAB_DUEL && duelABox != null) { duelA = duelABox.getValue(); duelB = duelBBox.getValue(); }
        if (tab == TAB_NPC && npcBox != null) npcNick = npcBox.getValue();
    }

    @Override
    public void removed() { capture(); }

    @Override
    public void tick() {
        if (tab == TAB_BOTS && detailBot == null && BotManager.INSTANCE.list().size() != shownBots) this.rebuildWidgets();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(px - 1, py - 1, px + PW + 1, py + PH + 1, C_BORDER);
        g.fill(px, py, px + PW, py + PH, C_BG);
        g.fill(px, py, px + PW, py + 26, C_HEAD);
        g.fill(px, py + 26, px + PW, py + 28, C_ACCENT);
        g.drawString(this.font, Component.literal("Duelforge").withStyle(ChatFormatting.BOLD), px + 10, py + 9, C_TEXT);
        String right = BotManager.INSTANCE.list().size() + " бот.";
        g.drawString(this.font, right, px + PW - 10 - this.font.width(right), py + 9, C_MUTED);
        g.fill(px + 10 + tab * TAB_STEP, py + 48, px + 10 + tab * TAB_STEP + TAB_W, py + 50, C_ACCENT);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int x = px + 10, y0 = py + 56;
        switch (tab) {
            case TAB_LAUNCH -> drawLaunch(g, x, y0);
            case TAB_BOTS -> drawBots(g, x, y0, mouseX, mouseY);
            case TAB_KITS -> drawKits(g, x, y0);
            case TAB_DUEL -> drawDuel(g, x, y0);
            case TAB_NPC -> drawNpc(g, x, y0);
            case TAB_COMBO -> drawCombo(g, x, y0);
            default -> drawOptions(g, x, y0);
        }
    }

    private void drawLaunch(GuiGraphics g, int x, int y0) {
        g.drawString(this.font, "ТИР  (LT5 слабее ... HT1 сильнее; MAX = без ограничений, без замедления при еде)", x, y0 + 78, C_MUTED);
        g.drawString(this.font, Opts.selectedKit == null ? "РЕЖИМ" : "РЕЖИМ  (берётся из выбранного кита)", x, y0 + 112, C_MUTED);
        g.fill(x, y0 + 216, x + 316, y0 + 240, C_CARD);
        g.fill(x, y0 + 216, x + 2, y0 + 240, C_ACCENT);
        wrap(g, launchKitText, x + 8, y0 + 219, 304, C_TEXT, 2);
    }

    private void drawBots(GuiGraphics g, int x, int y0, int mouseX, int mouseY) {
        if (detailBot != null) { drawDetail(g, x, y0, mouseX, mouseY); return; }
        List<BotClient> bots = BotManager.INSTANCE.list();
        g.drawString(this.font, "БОТ", x, y0, C_MUTED);
        g.drawString(this.font, "ТИР / РЕЖИМ", x + 92, y0, C_MUTED);
        g.drawString(this.font, "HP", x + 196, y0, C_MUTED);
        g.drawString(this.font, "УДАР/СМЕРТЬ", x + 218, y0, C_MUTED);
        if (bots.isEmpty()) {
            g.drawString(this.font, "Ботов нет. Запусти их на вкладке «Запуск».", x, y0 + 24, C_MUTED);
        }
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= bots.size()) break;
            BotClient bt = bots.get(idx);
            int ry = y0 + 14 + i * ROW_H;
            g.fill(x, ry, x + 316, ry + ROW_H - 2, C_CARD);
            g.fill(x, ry, x + 2, ry + ROW_H - 2, statusColor(bt.status));
            g.drawString(this.font, this.font.plainSubstrByWidth(bt.name, 84), x + 6, ry + 3, C_TEXT);
            g.drawString(this.font, bt.tier + " " + bt.mode, x + 92, ry + 3, C_TEXT);
            g.drawString(this.font, String.valueOf(Math.round(bt.health())), x + 196, ry + 3, hpColor(bt.health()));
            g.drawString(this.font, bt.hits() + " / " + bt.deaths, x + 218, ry + 3, C_TEXT);
            String line2 = bt.status == BotClient.Status.PLAYING ? bt.brainState() : statusText(bt.status) + (bt.info.isEmpty() ? "" : ": " + bt.info);
            g.drawString(this.font, this.font.plainSubstrByWidth(line2, 262), x + 6, ry + 13, C_MUTED);
        }
        int pages = Math.max(1, (bots.size() + ROWS - 1) / ROWS);
        g.drawString(this.font, (page + 1) + " / " + pages, x + 60, y0 + 14 + ROWS * ROW_H + 13, C_MUTED);
    }

    /** Bot card: 3D model, hotbar, inventory, armor, offhand, and where the bot spends its time. */
    private void drawDetail(GuiGraphics g, int x, int y0, int mouseX, int mouseY) {
        BotClient bt = null;
        for (BotClient c : BotManager.INSTANCE.list()) if (c.name.equalsIgnoreCase(detailBot)) bt = c;
        if (bt == null) { g.drawString(this.font, "Бот отключён.", x + 80, y0 + 5, C_MUTED); return; }
        g.drawString(this.font, bt.name + "   " + bt.tier + " " + bt.mode + "   hp " + Math.round(bt.health()), x + 78, y0 + 5, C_TEXT);

        g.fill(x, y0 + 22, x + 100, y0 + 178, C_CARD);
        BotPreview.model(g, this.font, x, y0 + 22, x + 100, y0 + 178, mouseX, mouseY, bt.name, bt.kit);

        int x0 = x + 108;
        Inventory inv = bt.inventory();
        Kit kit = bt.kit;
        int sel = bt.selectedSlot();
        g.drawString(this.font, "ХОТБАР", x0, y0 + 22, C_MUTED);
        for (int i = 0; i < 9; i++) {
            String item = inv != null && inv.known() ? inv.hotItem(i) : "";
            BotPreview.slot(g, this.font, x0 + i * 19, y0 + 32, item, inv == null ? 0 : inv.hotCount(i), i == sel);
        }
        g.drawString(this.font, "ИНВЕНТАРЬ", x0, y0 + 54, C_MUTED);
        for (int i = 0; i < 27; i++) {
            String item = inv != null && inv.known() ? inv.invItem(i) : "";
            BotPreview.slot(g, this.font, x0 + (i % 9) * 19, y0 + 64 + (i / 9) * 19, item, inv == null ? 0 : inv.invCount(i), false);
        }
        g.drawString(this.font, "БРОНЯ / ОФФХЕНД", x0, y0 + 124, C_MUTED);
        String[] keys = {"armor.head", "armor.chest", "armor.legs", "armor.feet", "weapon.offhand"};
        for (int i = 0; i < keys.length; i++) {
            Kit.Entry e = kit == null ? null : kit.slots.get(keys[i]);
            BotPreview.slot(g, this.font, x0 + i * 19, y0 + 134, e == null ? "" : e.item(), e == null ? 0 : e.count(), false);
        }
        String note = kit == null ? "Кита нет: инвентарь сервера бот не читает. Выбери кит на вкладке «Киты» и запусти бота заново."
                : "Кит «" + kit.name + "»  ·  раскладка: " + bt.layout.describe();
        wrap(g, note, x0, y0 + 156, 208, C_MUTED, 2);
        wrap(g, bt.brainState() + "  ·  " + bt.diag(), x, y0 + 184, 316, C_TEXT, 3);
    }

    private void drawKits(GuiGraphics g, int x, int y0) {
        List<String> kits = KitStore.names();
        g.drawString(this.font, "КИТЫ (" + kits.size() + ")  ·  «Мне» / «Боты» - загрузить кит", x, y0, C_MUTED);
        if (kits.isEmpty()) g.drawString(this.font, "Пока пусто. Собери инвентарь и жми «Сохранить с меня» (имя можно не вводить).", x, y0 + 24, C_MUTED);
        int pages = Math.max(1, (kits.size() + KROWS - 1) / KROWS);
        g.drawString(this.font, (kitPage + 1) + " / " + pages, x + 58, y0 + 151, C_MUTED);
        Kit sel = selKit == null ? null : KitStore.get(selKit);
        String info = sel == null ? "выбери кит в списке" : sel.summary();
        g.drawString(this.font, this.font.plainSubstrByWidth(info, 250), x + 96, y0 + 151, C_TEXT);
        g.drawString(this.font, "ИМЯ (для сохранения / переименования)", x, y0 + 164, C_MUTED);
        if (!kitStatus.isEmpty()) {
            g.fill(x, y0 + 244, x + 316, y0 + 266, C_CARD);
            g.fill(x, y0 + 244, x + 2, y0 + 266, C_ACCENT);
            wrap(g, kitStatus, x + 8, y0 + 247, 304, C_TEXT, 2);
        }
    }

    private void drawOptions(GuiGraphics g, int x, int y0) {
        wrap(g, "AUTO: сначала кристалл на пол, после двух неудач бот сам начнёт ставить обсидиан. ALWAYS: каждый раз. NEVER: пол уже обсидиановый.",
                x, y0 + 22, 316, C_MUTED, 2);
        wrap(g, "После тотема HP = 1.0: бот берёт запасной тотем в оффхенд.", x, y0 + 70, 316, C_MUTED, 1);
        g.drawString(this.font, "Пауза между входами ботов:  " + BotManager.INSTANCE.staggerMs + " мс", x + 92, y0 + 98, C_TEXT);
        g.drawString(this.font, "Пауза между командами кита:  " + Opts.kitDelay + " тик.", x + 92, y0 + 124, C_TEXT);
        wrap(g, "Ловушки: режимы UHC и «Ловушки». Булава: режим «Булава+».", x, y0 + 268, 316, C_MUTED, 1);
    }

    private void wrap(GuiGraphics g, String text, int x, int y, int maxW, int color, int maxLines) {
        String rest = text;
        for (int i = 0; i < maxLines && !rest.isEmpty(); i++) {
            String line = this.font.plainSubstrByWidth(rest, maxW);
            if (line.length() < rest.length()) {
                int sp = line.lastIndexOf(' ');
                if (sp > 0) line = line.substring(0, sp);
            }
            g.drawString(this.font, line, x, y + i * 11, color);
            rest = rest.substring(line.length()).trim();
        }
    }

    private static int statusColor(BotClient.Status s) {
        return switch (s) {
            case PLAYING -> C_OK;
            case CONNECTING, LOGIN, CONFIG -> C_WARN;
            case KICKED, ERROR -> C_BAD;
            default -> C_MUTED;
        };
    }

    private static String statusText(BotClient.Status s) {
        return switch (s) {
            case PLAYING -> "в игре";
            case CONNECTING -> "подключение";
            case LOGIN -> "логин";
            case CONFIG -> "конфигурация";
            case KICKED -> "кик";
            case ERROR -> "ошибка";
            default -> "остановлен";
        };
    }

    private static int hpColor(float hp) { return hp > 12 ? C_OK : hp > 6 ? C_WARN : C_BAD; }
}
