package dev.duelforge.client;

import dev.duelforge.local.BotEntity;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** On-screen cards for Controller bots (HP, distance, armor durability, offhand totems). */
public final class ControllerHud {
    static boolean enabled = true;
    static int position = 0;   // bit0 = right, bit1 = bottom
    static int theme = 0;
    static final int[] COLORS = {0xFF4FD1C5, 0xFFA78BFA, 0xFFF6C453};
    static final String[] THEMES = {"Бирюза", "Фиолет", "Золото"};
    static final String[] POSITIONS = {"Сверху слева", "Сверху справа", "Снизу слева", "Снизу справа"};

    private ControllerHud() {}

    static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("duelforge", "bots"), (g, tick) -> render(g));
    }

    static int countLoaded() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return 0;
        int n = 0;
        for (Entity e : mc.level.entitiesForRendering()) if (e instanceof BotEntity) n++;
        return n;
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || mc.options.hideGui || mc.level == null || mc.player == null) return;
        int w = 180, h = 56, gap = 60;
        int x = (position & 1) == 0 ? 6 : Math.max(0, g.guiWidth() - w - 6);
        boolean bottom = (position & 2) != 0;
        int y = bottom ? Math.max(6, g.guiHeight() - h - 10) : 6;
        int step = bottom ? -gap : gap;
        int color = COLORS[theme];
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof BotEntity bot)) continue;
            if (y < 0 || y + h > g.guiHeight()) break;
            g.fill(x, y, x + w, y + h, 0xD8182130);
            g.fill(x, y, x + 2, y + h, color);
            g.drawString(mc.font, bot.getDisplayName(), x + 6, y + 4, 0xFFFFFFFF);
            float max = bot.getMaxHealth();
            float frac = max <= 0 ? 0 : Math.max(0f, Math.min(1f, bot.getHealth() / max));
            g.fill(x + 6, y + 15, x + 174, y + 19, 0xFF374151);
            g.fill(x + 6, y + 15, x + 6 + Math.round(168 * frac), y + 19, color);
            String vitals = String.format(Locale.ROOT, "HP %.1f / %.1f  |  %.1f бл.", bot.getHealth(), max, mc.player.distanceTo(bot));
            g.drawString(mc.font, Component.literal(vitals), x + 6, y + 23, 0xFFFFFFFF);
            String armor = "Броня Ш/Н/П/Б: " + dur(bot.getItemBySlot(EquipmentSlot.HEAD)) + " " + dur(bot.getItemBySlot(EquipmentSlot.CHEST))
                    + " " + dur(bot.getItemBySlot(EquipmentSlot.LEGS)) + " " + dur(bot.getItemBySlot(EquipmentSlot.FEET));
            g.drawString(mc.font, Component.literal(armor), x + 6, y + 33, 0xFFD5DFEA);
            ItemStack off = bot.getItemBySlot(EquipmentSlot.OFFHAND);
            int totems = off.is(Items.TOTEM_OF_UNDYING) ? off.getCount() : 0;
            g.drawString(mc.font, Component.literal("Тотемов в оффхенде: " + totems), x + 6, y + 43, 0xFFD5DFEA);
            y += step;
        }
    }

    private static String dur(ItemStack s) {
        if (s.isEmpty()) return "-";
        int max = s.getMaxDamage();
        return max <= 0 ? "-" : Math.round(100f * (max - s.getDamageValue()) / max) + "%";
    }
}
