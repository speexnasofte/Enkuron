package dev.duelforge.client.prism;

import net.minecraft.client.gui.Font;
import top.fpsmaster.prism.canvas.FontHandle;

/** Prism font backed by the vanilla Minecraft font. A "size px" font has a line box of px/2 GUI units. */
final class DuelforgeFont implements FontHandle {
    /** Multiply to make all Prism text bigger/smaller (1.0 = Prism's design size). */
    static final float TEXT_SCALE = 1.0f;
    private static final float VANILLA_LINE = 9f;

    private final Font font;
    private final int px;

    DuelforgeFont(Font font, int px) {
        this.font = font;
        this.px = px;
    }

    float scale() { return lineHeight() / VANILLA_LINE; }

    Font vanilla() { return font; }

    @Override public int size() { return px; }

    @Override public float measure(String text) {
        if (text == null || text.isEmpty()) return 0f;
        return font.width(text) * scale();
    }

    @Override public float lineHeight() { return px * 0.5f * TEXT_SCALE; }
}
