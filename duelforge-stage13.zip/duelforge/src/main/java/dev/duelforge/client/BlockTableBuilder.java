package dev.duelforge.client;

import dev.duelforge.ai.BlockTable;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds the block-state-id -> class table for {@link BlockTable} from the game's own registry, so the ids always match
 * the protocol version this client speaks. Run once after all mods are initialised (modded blocks included).
 *
 * NOT compiled against Minecraft here. Calls most likely to need a rename on the first build: Block.BLOCK_STATE_REGISTRY
 * (IdMapper#size / #byId), BlockState#isCollisionShapeFullBlock, Blocks.COBWEB, FluidTags.LAVA.
 */
public final class BlockTableBuilder {
    private BlockTableBuilder() {}

    public static void build() {
        try {
            var reg = Block.BLOCK_STATE_REGISTRY;
            int n = reg.size();
            byte[] t = new byte[n];
            for (int id = 0; id < n; id++) {
                BlockState s = reg.byId(id);
                t[id] = s == null ? BlockTable.FULL : classify(s);
            }
            BlockTable.set(t);
            System.out.println("[Duelforge] block table ready: " + n + " block states");
        } catch (Throwable e) {
            // without a table every non-air state counts as a full block (see BlockTable): terrain stays usable but crude
            System.out.println("[Duelforge] block table NOT built: " + e);
        }
    }

    private static byte classify(BlockState s) {
        if (s.isAir()) return BlockTable.AIR;
        if (s.is(Blocks.COBWEB)) return BlockTable.WEB;
        if (s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE)) return BlockTable.FIRE;
        if (s.getBlock() instanceof LiquidBlock) return s.getFluidState().is(FluidTags.LAVA) ? BlockTable.LAVA : BlockTable.WATER;
        boolean any, full;
        try {
            any = !s.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO).isEmpty();
            full = s.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
        } catch (Throwable e) {
            return BlockTable.FULL;   // shapes that need a real world: assume solid
        }
        if (full) return s.is(Blocks.OBSIDIAN) || s.is(Blocks.BEDROCK) ? BlockTable.OBSIDIAN : BlockTable.FULL;
        return any ? BlockTable.PARTIAL : BlockTable.PLANT;
    }
}
