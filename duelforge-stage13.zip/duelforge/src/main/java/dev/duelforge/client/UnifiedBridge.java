package dev.duelforge.client;

import dev.duelforge.ai.Combo;
import dev.duelforge.ai.DuelManager;
import dev.duelforge.ai.Kit;
import dev.duelforge.ai.KitStore;
import dev.duelforge.ai.Layout;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Tier;
import dev.duelforge.local.BotAction;
import dev.duelforge.local.LocalKit;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import dev.duelforge.stepan.bot.BotSettings;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import top.fpsmaster.prism.screen.ClickGuiBridge;

/**
 * One GUI for everything: Lab (network bots), Controller (server-side bots) and the ported PVP Bot (Stepan1411).
 * Every feature is a "module" of the Prism ClickGUI; buttons are boolean "triggers" that spring back to off.
 * All state of the old vanilla screens (BotScreen / ControllerScreen) lives here now.
 */
public final class UnifiedBridge implements ClickGuiBridge {
    public static boolean light = false;

    // ------------------------------------------------------------------ state of the Lab panels
    private static String ip = "", nicks = "Bot*10", team = "A", cmd = "", kitName = "", npcNick = "NPC";
    private static String duelA = "DuelA", duelB = "";
    private static String selKit = null;
    private static int tierIdx = Tier.HT3.ordinal(), duelTierB = Tier.HT3.ordinal(), ctlTier = 0;
    private static Mode mode = Mode.SWORD;
    private static String launchStatus = "", kitStatus = "", duelStatus = "", npcStatus = "";

    // ------------------------------------------------------------------ framework
    private static final class St {
        final String id;
        final Supplier<SettingInfo> info;
        Consumer<Boolean> onBool;
        DoubleConsumer onNum;
        Consumer<String> onText;
        IntConsumer onChoice;
        IntConsumer onRemove;
        St(String id, Supplier<SettingInfo> info) { this.id = id; this.info = info; }
    }

    private static final class Mod {
        final String id, cat;
        final Supplier<String> name;
        final BooleanSupplier on;
        final Consumer<Boolean> setOn;
        final Supplier<List<St>> settings;
        Mod(String id, String cat, Supplier<String> name, BooleanSupplier on, Consumer<Boolean> setOn, Supplier<List<St>> settings) {
            this.id = id; this.cat = cat; this.name = name; this.on = on; this.setOn = setOn; this.settings = settings;
        }
    }

    private static St bool(String id, String label, BooleanSupplier get, Consumer<Boolean> set) {
        St s = new St(id, () -> new SettingInfo(id, label, get.getAsBoolean()));
        s.onBool = set;
        return s;
    }

    private static St num(String id, String label, double min, double max, DoubleSupplier get, DoubleConsumer set) {
        St s = new St(id, () -> new SettingInfo(id, label, get.getAsDouble(), min, max));
        s.onNum = v -> set.accept(Math.max(min, Math.min(max, v)));
        return s;
    }

    private static St text(String id, String label, Supplier<String> get, Consumer<String> set) {
        St s = new St(id, () -> new SettingInfo(id, label, get.get()));
        s.onText = set;
        return s;
    }

    private static St choice(String id, String label, Supplier<List<String>> options, IntSupplier selected, IntConsumer set) {
        St s = new St(id, () -> {
            List<String> o = options.get();
            if (o.isEmpty()) o = List.of("—");
            return new SettingInfo(id, label, o, Math.max(0, Math.min(selected.getAsInt(), o.size() - 1)));
        });
        s.onChoice = set;
        return s;
    }

    /** A button: shows as an off switch, runs the action when switched on. */
    private static St action(String id, String label, Runnable run) {
        St s = new St(id, () -> new SettingInfo(id, label, false));
        s.onBool = v -> { if (v) run.run(); };
        return s;
    }

    /** Read-only lines (status, scoreboard, bot list). {@code remove} (nullable) is called with the line index. */
    private static St lines(String id, String label, Supplier<List<String>> get, IntConsumer remove) {
        St s = new St(id, () -> {
            List<String> l = get.get();
            if (l.isEmpty()) return null;
            List<ListItem> items = new ArrayList<>();
            for (String t : l) items.add(new ListItem(t));
            return new SettingInfo(id, label, items, items.size(), false);
        });
        s.onRemove = remove;
        return s;
    }

    private static Supplier<List<String>> one(Supplier<String> s) {
        return () -> { String t = s.get(); return t == null || t.isEmpty() ? List.of() : List.of(t); };
    }

    private final List<Mod> mods = new ArrayList<>();
    private final Runnable close;

    public UnifiedBridge(Runnable close) {
        this.close = close;
        buildLab();
        buildController();
        buildStepan();
    }

    private void mod(String id, String cat, String name, BooleanSupplier on, Consumer<Boolean> setOn, Supplier<List<St>> settings) {
        mods.add(new Mod(id, cat, () -> name, on, setOn, settings));
    }

    // ================================================================== LAB
    private static List<Mode> launchModes() {
        List<Mode> l = new ArrayList<>();
        for (Mode m : Mode.values()) if (m != Mode.NPC) l.add(m);
        return l;
    }

    private static String tierName(Tier t) { return t.max() ? "MAX" : t.name(); }

    private static String kitCardText() {
        Kit k = Opts.selectedKit == null ? null : KitStore.get(Opts.selectedKit);
        if (k == null) return "Хотбар: " + mode.kit;
        Mode m = k.mode == null ? mode : k.mode;
        return "Кит «" + k.name + "»: режим " + m.label + ", раскладка: " + Layout.detect(m, k.hotbarItems()).describe();
    }

    private static String statusText(BotClient.Status s) {
        return switch (s) {
            case PLAYING -> "в игре";
            case CONNECTING -> "подключение";
            case LOGIN -> "логин";
            case CONFIG -> "конфигурация";
            case KICKED -> "кик";
            case ERROR -> "ошибка";
            default -> "остановлен";
        };
    }

    private static String botLine(String nick) {
        for (BotClient c : BotManager.INSTANCE.list()) {
            if (c.name.equalsIgnoreCase(nick)) return "HP " + Math.round(c.health()) + " · уд. " + c.hits() + " · смертей " + c.deaths;
        }
        return "(ты или не в игре)";
    }

    private static String curKit() {
        List<String> names = KitStore.names();
        if (selKit != null && KitStore.get(selKit) != null) return selKit;
        return names.isEmpty() ? null : names.get(0);
    }

    private void buildLab() {
        // ---- launch
        mod("launch", "launch", "Запуск ботов", null, null, () -> List.of(
                text("ip", "IP сервера (пусто = текущий мир)", () -> ip, v -> ip = v),
                text("nicks", "Ники: A,B,C или Bot*20", () -> nicks, v -> nicks = v),
                text("team", "Команда", () -> team, v -> team = v),
                text("cmd", "Команда после входа", () -> cmd, v -> cmd = v),
                choice("tier", "Тир", () -> { List<String> l = new ArrayList<>(); for (Tier t : Tier.values()) l.add(tierName(t)); return l; },
                        () -> tierIdx, i -> tierIdx = i),
                choice("mode", "Режим", () -> { List<String> l = new ArrayList<>(); for (Mode m : launchModes()) l.add(m.label); return l; },
                        () -> launchModes().indexOf(mode), i -> mode = launchModes().get(i)),
                lines("kit", "Хотбар / кит", one(UnifiedBridge::kitCardText), null),
                action("start", "▶ Запустить ботов", () -> {
                    String host = RemoteControl.resolveHost(ip);
                    if (host == null) { launchStatus = "Зайди в мир или на сервер, либо введи IP."; return; }
                    if (nicks.isBlank()) { launchStatus = "Введи ники."; return; }
                    if (!cmd.isBlank()) { BotManager.INSTANCE.joinCommands.clear(); BotManager.INSTANCE.joinCommands.add(cmd); }
                    BotManager.INSTANCE.join(host, nicks, Tier.values()[tierIdx], mode, team.isBlank() ? "A" : team);
                    launchStatus = "Запущено: " + nicks + " → " + host;
                }),
                action("leave", "■ Отключить всех", () -> BotManager.INSTANCE.leave("all")),
                lines("status", "Статус", one(() -> launchStatus), null)));

        // ---- bots
        mods.add(new Mod("bots", "bots", () -> "Боты (" + BotManager.INSTANCE.list().size() + ")", null, null, () -> List.of(
                lines("list", "Подключены (удалить = отключить)", () -> {
                    List<String> l = new ArrayList<>();
                    for (BotClient bt : BotManager.INSTANCE.list()) {
                        String st = bt.status == BotClient.Status.PLAYING ? bt.brainState()
                                : statusText(bt.status) + (bt.info.isEmpty() ? "" : ": " + bt.info);
                        l.add(bt.name + " · " + bt.tier + " " + bt.mode + " · HP " + Math.round(bt.health())
                                + " · " + bt.hits() + "/" + bt.deaths + " · " + st);
                    }
                    return l;
                }, i -> {
                    List<BotClient> bots = BotManager.INSTANCE.list();
                    if (i >= 0 && i < bots.size()) BotManager.INSTANCE.leave(bots.get(i).name);
                }),
                action("leaveAll", "■ Отключить всех", () -> BotManager.INSTANCE.leave("all")))));

        mod("npc", "bots", "NPC-мишени", null, null, () -> List.of(
                text("nick", "Ник NPC: NPC или NPC*5", () -> npcNick, v -> npcNick = v),
                num("totems", "Тотемов в каждой руке", 1, 99, () -> Opts.npcTotems, v -> Opts.npcTotems = (int) Math.round(v)),
                bool("fight", "Бьёт в ответ", () -> Opts.npcFight, v -> Opts.npcFight = v),
                bool("armor", "Незерит-броня", () -> Opts.npcArmor, v -> Opts.npcArmor = v),
                action("spawn", "▶ Спавн NPC", () -> {
                    String host = RemoteControl.resolveHost(ip);
                    if (host == null) { npcStatus = "Зайди в мир или на сервер, либо введи IP в разделе «Запуск»."; return; }
                    int n = BotManager.INSTANCE.spawnNpc(host, npcNick.isBlank() ? "NPC" : npcNick.trim());
                    npcStatus = "NPC: " + n + " шт. Тотемы выдаются командами /item replace - нужны права оператора "
                            + (Opts.kitViaBots ? "у самих ботов." : "у тебя.");
                }),
                action("removeNpc", "■ Убрать всех NPC", () -> {
                    for (BotClient c : BotManager.INSTANCE.list()) if (c.mode == Mode.NPC) BotManager.INSTANCE.leave(c.name);
                }),
                lines("status", "Статус", one(() -> npcStatus), null)));

        mods.add(new Mod("duel", "bots", () -> {
            DuelManager d = DuelManager.INSTANCE;
            return d.has() ? "Дуэль · " + d.nameA() + " " + d.scoreA() + ":" + d.scoreB() + " " + d.nameB() : "Дуэль";
        }, null, null, () -> List.of(
                text("a", "Бот A (ник)", () -> duelA, v -> duelA = v),
                text("b", "Бот B (пусто = ты)", () -> duelB, v -> duelB = v),
                choice("tierB", "Тир B (тир A и режим — из «Запуск»)", () -> { List<String> l = new ArrayList<>(); for (Tier t : Tier.values()) l.add(tierName(t)); return l; },
                        () -> duelTierB, i -> duelTierB = i),
                num("first", "До скольки побед", 1, 50, () -> DuelManager.INSTANCE.firstTo, v -> DuelManager.INSTANCE.firstTo = (int) Math.round(v)),
                action("start", "▶ Старт дуэли", () -> {
                    String host = RemoteControl.resolveHost(ip);
                    if (host == null) { duelStatus = "Зайди в мир или на сервер, либо введи IP в разделе «Запуск»."; return; }
                    String a = duelA.isBlank() ? "DuelA" : duelA.trim();
                    Tier tA = Tier.values()[tierIdx], tB = Tier.values()[duelTierB];
                    int first = DuelManager.INSTANCE.firstTo;
                    if (duelB.isBlank()) {
                        String me = Minecraft.getInstance().getUser().getName();
                        BotManager.INSTANCE.startDuelVsPlayer(host, a, tA, mode, first, me);
                        duelStatus = "Бот " + a + " (" + tA + ", " + mode.label + ") против тебя. Если твоя смерть не засчиталась - «+1 B».";
                    } else {
                        BotManager.INSTANCE.startDuelBots(host, a, duelB.trim(), tA, tB, mode, first);
                        duelStatus = "Дуэль ботов: " + a + " vs " + duelB.trim() + ", режим " + mode.label + ".";
                    }
                }),
                action("stop", "■ Стоп", () -> {
                    DuelManager.INSTANCE.stop();
                    BotManager.INSTANCE.leave(duelA.isBlank() ? "DuelA" : duelA.trim());
                    if (!duelB.isBlank()) BotManager.INSTANCE.leave(duelB.trim());
                }),
                action("pa", "+1 A", () -> DuelManager.INSTANCE.point(DuelManager.INSTANCE.nameA())),
                action("pb", "+1 B", () -> DuelManager.INSTANCE.point(DuelManager.INSTANCE.nameB())),
                action("rematch", "Реванш", () -> DuelManager.INSTANCE.rematch()),
                action("reset", "Сброс", () -> { DuelManager.INSTANCE.reset(); duelStatus = ""; }),
                lines("board", "Табло", () -> {
                    DuelManager d = DuelManager.INSTANCE;
                    List<String> l = new ArrayList<>();
                    if (d.has()) {
                        l.add(d.nameA() + " " + d.scoreA() + " : " + d.scoreB() + " " + d.nameB());
                        l.add("A: " + botLine(d.nameA()));
                        l.add("B: " + botLine(d.nameB()));
                        l.add(d.active ? "идёт · раунд " + (d.scoreA() + d.scoreB() + 1)
                                : d.winner.isEmpty() ? "остановлена" : "победил " + d.winner);
                    }
                    List<String> log = d.log();
                    for (int i = Math.max(0, log.size() - 4); i < log.size(); i++) l.add(log.get(i));
                    if (!duelStatus.isEmpty()) l.add(duelStatus);
                    return l;
                }, null))));

        // ---- kits
        mod("labkits", "kits", "Киты Лаба", null, null, () -> List.of(
                choice("kit", "Кит", KitStore::names, () -> { String c = curKit(); int i = c == null ? 0 : KitStore.names().indexOf(c); return Math.max(i, 0); },
                        i -> { List<String> n = KitStore.names(); if (i >= 0 && i < n.size()) { selKit = n.get(i); kitName = selKit; KitActions.last = selKit; } }),
                text("name", "Имя кита", () -> kitName, v -> kitName = v),
                action("me", "Взять себе", () -> { String c = curKit(); if (c != null) kitStatus = KitActions.load(c); }),
                action("bots", "Выдать ботам", () -> { String c = curKit(); if (c != null) kitStatus = KitActions.give(c, "all"); }),
                action("save", "Сохранить с меня", () -> {
                    kitStatus = KitActions.save(kitName);
                    String n = KitStore.sanitize(kitName);
                    if (KitStore.get(n) != null) selKit = n;
                }),
                action("rename", "Переименовать", () -> {
                    kitStatus = KitActions.rename(curKit(), kitName);
                    if (KitStore.get(KitStore.sanitize(kitName)) != null) selKit = KitStore.sanitize(kitName);
                }),
                action("delete", "Удалить", () -> { kitStatus = KitActions.delete(curKit()); selKit = null; }),
                action("cycle", "Сменить режим кита", () -> kitStatus = KitActions.cycleMode(curKit())),
                bool("use", "Для запуска ботов", () -> { String c = curKit(); return c != null && c.equalsIgnoreCase(Opts.selectedKit); },
                        v -> { String c = curKit(); kitStatus = KitActions.use(v ? c : null); }),
                lines("status", "Статус", one(() -> kitStatus), null)));

        // ---- modes / options
        mod("combo", "modes", "Комбо после удара", () -> Opts.combo, v -> Opts.combo = v, () -> {
            List<St> l = new ArrayList<>();
            l.add(bool("chain", "Цепочки из двух", () -> Opts.comboChain, v -> Opts.comboChain = v));
            l.add(num("rate", "Темп комбо", 0.3, 1.6, () -> Opts.comboRate, v -> Opts.comboRate = Math.round(v * 10) / 10.0));
            for (Combo.Kind k : Combo.Kind.values()) {
                if (k == Combo.Kind.NONE) continue;
                final Combo.Kind kk = k;
                l.add(bool("kind_" + k.name(), k.label, () -> Opts.comboOn(kk), v -> Opts.comboSet(kk, v)));
            }
            l.add(bool("spear", "Копьё: отход с разбега после тычка", () -> Opts.spearRunup, v -> Opts.spearRunup = v));
            return l;
        });

        mod("labopts", "modes", "Опции Лаба", null, null, () -> {
            List<St> l = new ArrayList<>();
            l.add(choice("obsidian", "Обсидиан для кристаллов", () -> { List<String> o = new ArrayList<>(); for (Opts.Obsidian v : Opts.Obsidian.values()) o.add(v.toString()); return o; },
                    () -> Opts.obsidian.ordinal(), i -> Opts.obsidian = Opts.Obsidian.values()[i]));
            l.add(bool("totemRefill", "Замена тотема после попа", () -> Opts.totemRefill, v -> Opts.totemRefill = v));
            l.add(num("stagger", "Задержка между входами ботов, мс", 0, 20000, () -> BotManager.INSTANCE.staggerMs, v -> BotManager.INSTANCE.staggerMs = (int) Math.round(v / 100.0) * 100));
            l.add(num("kitDelay", "Задержка кита", 1, 40, () -> Opts.kitDelay, v -> Opts.kitDelay = (int) Math.round(v)));
            l.add(bool("debug", "Отладка", () -> BotClient.debug, v -> BotClient.debug = v));
            l.add(bool("autoKit", "Авто-кит после входа", () -> Opts.autoKit, v -> Opts.autoKit = v));
            l.add(bool("kitViaBots", "Кит грузят сами боты (нужен оп)", () -> Opts.kitViaBots, v -> Opts.kitViaBots = v));
            l.add(bool("traps", "Ловушки", () -> Opts.traps, v -> Opts.traps = v));
            l.add(bool("web", "Паутина", () -> Opts.trapWeb, v -> Opts.trapWeb = v));
            l.add(bool("lava", "Лава", () -> Opts.trapLava, v -> Opts.trapLava = v));
            l.add(bool("fire", "Огонь", () -> Opts.trapFire, v -> Opts.trapFire = v));
            l.add(bool("water", "Вода", () -> Opts.waterSteal, v -> Opts.waterSteal = v));
            l.add(num("mace", "Булава: от скольки блоков падения", 1.5, 6, () -> Opts.maceMinFall, v -> Opts.maceMinFall = Math.round(v * 2) / 2.0));
            l.add(bool("smartCrystal", "Кристаллы по урону (себе/врагу)", () -> Opts.smartCrystal, v -> Opts.smartCrystal = v));
            l.add(num("crystalMin", "Кристалл: хороший урон врагу от", 0, 15, () -> Opts.crystalMinDamage, v -> Opts.crystalMinDamage = Math.round(v * 2) / 2.0));
            l.add(num("crystalReserve", "Кристалл: запас HP у себя", 0, 10, () -> Opts.crystalSelfReserve, v -> Opts.crystalSelfReserve = Math.round(v * 2) / 2.0));
            l.add(bool("hitboxAim", "Прицел по хитбоксу (HT3 и выше)", () -> Opts.hitboxAim, v -> Opts.hitboxAim = v));
            l.add(bool("readChunks", "Боты читают чанки (рельеф, укрытия от взрыва)", () -> Opts.readChunks, v -> Opts.readChunks = v));
            l.add(bool("terrainPhysics", "Физика по реальным блокам (стены, пол, падение)", () -> Opts.terrainPhysics, v -> Opts.terrainPhysics = v));
            l.add(bool("pathfinding", "Обход стен (поиск пути по известным блокам)", () -> Opts.pathfinding, v -> Opts.pathfinding = v));
            l.add(bool("labHud", "Карточки ботов на экране", () -> Opts.labHud, v -> Opts.labHud = v));
            l.add(num("labHudCorner", "Карточки: угол (0 лв, 1 пв, 2 лн, 3 пн)", 0, 3, () -> Opts.labHudCorner, v -> Opts.labHudCorner = (int) Math.round(v)));
            l.add(bool("targetRing", "Кольцо на цели бота", () -> Opts.targetRing, v -> Opts.targetRing = v));
            l.add(bool("sprintReset", "Крит без спринта (сброс спринта на прыжок)", () -> Opts.sprintReset, v -> Opts.sprintReset = v));
            return l;
        });
    }

    // ================================================================== CONTROLLER
    private static boolean network() {
        return RemoteControl.forceNetwork || !ClientPlayNetworking.canSend(BotAction.TYPE);
    }

    private static void send(String id) {
        if (network()) RemoteControl.handle(id);
        else if (ClientPlayNetworking.canSend(BotAction.TYPE)) ClientPlayNetworking.send(new BotAction(id));
    }

    private void buildController() {
        mod("control", "controller", "Управление ботами", null, null, () -> List.of(
                action("spawn", "Создать бота (макс. 4)", () -> send("spawn")),
                action("follow", "Следовать за мной", () -> send("follow")),
                action("attack", "Атаковать меня", () -> send("attack")),
                action("clear", "Сбросить цели", () -> send("clear")),
                action("despawn", "Удалить моих ботов", () -> send("despawn")),
                choice("tier", "Сложность", () -> List.of("1 быстр.", "2", "3", "4", "5 медл."),
                        () -> ctlTier, i -> { ctlTier = i; send("tier_" + (i + 1)); }),
                bool("net", "Умные сетевые боты (вместо сущностей мода)", () -> RemoteControl.forceNetwork, v -> RemoteControl.forceNetwork = v),
                lines("mode", "Режим", one(() -> network() && !ClientPlayNetworking.canSend(BotAction.TYPE)
                        ? "сетевые боты: на этом сервере нет мода" : network() ? "сетевые боты, умный ИИ" : "сущности мода"), null)));

        mod("ctlkits", "kits", "Киты Контроллера", null, null, () -> {
            List<St> l = new ArrayList<>();
            for (LocalKit k : LocalKit.values()) {
                final String id = k.id;
                l.add(action("k_" + id, k.title, () -> send(id)));
            }
            return l;
        });

        mod("hud", "controller", "HUD ботов", () -> ControllerHud.enabled, v -> ControllerHud.enabled = v, () -> List.of(
                choice("pos", "Позиция", () -> List.of(ControllerHud.POSITIONS), () -> ControllerHud.position, i -> ControllerHud.position = i),
                choice("theme", "Тема", () -> List.of(ControllerHud.THEMES), () -> ControllerHud.theme, i -> ControllerHud.theme = i)));
    }

    // ================================================================== STEPAN PVP BOT
    private void buildStepan() {
        BotSettings s = BotSettings.get();
        mod("sb_combat", "sbattle", "Бой", s::isCombatEnabled, s::setCombatEnabled, () -> List.of(
                bool("revenge", "Месть", s::isRevengeEnabled, s::setRevengeEnabled),
                bool("autotarget", "Авто-цель", s::isAutoTargetEnabled, s::setAutoTargetEnabled),
                bool("tplayers", "Цель: игроки", s::isTargetPlayers, s::setTargetPlayers),
                bool("thostile", "Цель: мобы", s::isTargetHostileMobs, s::setTargetHostileMobs),
                bool("tbots", "Цель: боты", s::isTargetOtherBots, s::setTargetOtherBots),
                bool("crits", "Криты", s::isCriticalsEnabled, s::setCriticalsEnabled),
                bool("ranged", "Лук / арбалет", s::isRangedEnabled, s::setRangedEnabled),
                num("melee", "Дальность ближнего боя", 2, 6, s::getMeleeRange, s::setMeleeRange),
                num("speed", "Скорость движения", 0.5, 2, s::getMoveSpeed, s::setMoveSpeed)));
        mod("sb_mace", "sbattle", "Булава", s::isMaceEnabled, s::setMaceEnabled, List::of);
        mod("sb_crystal", "sbattle", "Crystal PvP", s::isCrystalPvpEnabled, s::setCrystalPvpEnabled, List::of);
        mod("sb_anchor", "sbattle", "Anchor PvP", s::isAnchorPvpEnabled, s::setAnchorPvpEnabled, List::of);

        mod("su_equip", "sutil", "Авто-экипировка", s::isAutoEquipArmor, s::setAutoEquipArmor, () -> List.of(
                bool("weapon", "Авто-оружие", s::isAutoEquipWeapon, s::setAutoEquipWeapon)));
        mod("su_totem", "sutil", "Авто-тотем", s::isAutoTotemEnabled, s::setAutoTotemEnabled, List::of);
        mod("su_shield", "sutil", "Авто-щит", s::isAutoShieldEnabled, s::setAutoShieldEnabled, List::of);
        mod("su_eat", "sutil", "Авто-еда", s::isAutoEatEnabled, s::setAutoEatEnabled, List::of);
        mod("su_potion", "sutil", "Авто-зелья", s::isAutoPotionEnabled, s::setAutoPotionEnabled, List::of);
        mod("su_mend", "sutil", "Авто-починка", s::isAutoMendEnabled, s::setAutoMendEnabled, List::of);
        mod("su_bhop", "sutil", "Bhop", s::isBhopEnabled, s::setBhopEnabled, List::of);
        mod("su_idle", "sutil", "Бродить без цели", s::isIdleWanderEnabled, s::setIdleWanderEnabled, List::of);
        mod("su_factions", "sutil", "Фракции", s::isFactionsEnabled, s::setFactionsEnabled, () -> List.of(
                bool("ff", "Огонь по своим", s::isFriendlyFireEnabled, s::setFriendlyFireEnabled)));
        mod("su_human", "sutil", "Ошибки и промахи", null, null, () -> List.of(
                num("miss", "Шанс промаха, %", 0, 100, s::getMissChance, v -> s.setMissChance((int) Math.round(v))),
                num("mistake", "Шанс ошибки, %", 0, 100, s::getMistakeChance, v -> s.setMistakeChance((int) Math.round(v)))));
        mod("su_names", "sutil", "Особые ники", s::isUseSpecialNames, s::setUseSpecialNames, List::of);
        mod("su_leave", "sutil", "Уходит после смерти", s::isBotLeaveOnDeath, s::setBotLeaveOnDeath, List::of);
    }

    // ================================================================== ClickGuiBridge
    private Mod find(String id) {
        for (Mod m : mods) if (m.id.equals(id)) return m;
        return null;
    }

    private St findSetting(String moduleId, String settingId) {
        Mod m = find(moduleId);
        if (m == null) return null;
        for (St s : m.settings.get()) if (s.id.equals(settingId)) return s;
        return null;
    }

    @Override public String i18n(String key) {
        return switch (key) {
            case "clickgui.search.placeholder" -> "Поиск…";
            case "clickgui.search.noresults" -> "Ничего не найдено";
            case "clickgui.category.meta" -> "%d функций · %d вкл";
            case "clickgui.nav.theme.light" -> "Светлая тема";
            case "clickgui.nav.theme.dark" -> "Тёмная тема";
            default -> key;
        };
    }

    @Override public String brand() { return "Duelforge"; }
    @Override public String edition() { return "PvP"; }
    @Override public String version() { return "2.0.1"; }
    @Override public boolean showExtraNav() { return false; }

    @Override public List<String> categories() {
        return List.of("launch", "bots", "kits", "modes", "controller", "sbattle", "sutil");
    }

    @Override public String categoryLabel(String id) {
        return switch (id) {
            case "launch" -> "Запуск";
            case "bots" -> "Боты и дуэли";
            case "kits" -> "Киты";
            case "modes" -> "Режимы и опции";
            case "controller" -> "Контроллер";
            case "sbattle" -> "PvP бот: бой";
            default -> "PvP бот: утилиты";
        };
    }

    @Override public String categoryIcon(String id) {
        return switch (id) {
            case "launch" -> "globe";
            case "bots" -> "box";
            case "kits" -> "folder";
            default -> "sliders";
        };
    }

    @Override public int moduleCount(String cat) {
        int n = 0;
        for (Mod m : mods) if (m.cat.equals(cat)) n++;
        return n;
    }

    @Override public int enabledCount(String cat) {
        int n = 0;
        for (Mod m : mods) if (m.cat.equals(cat) && m.on != null && m.on.getAsBoolean()) n++;
        return n;
    }

    @Override public List<ModInfo> modules(String cat, String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<ModInfo> out = new ArrayList<>();
        for (Mod m : mods) {
            String name = m.name.get();
            if (q.isEmpty() ? !m.cat.equals(cat) : !name.toLowerCase(Locale.ROOT).contains(q)) continue;
            List<SettingInfo> settings = new ArrayList<>();
            for (St st : m.settings.get()) {
                SettingInfo si = st.info.get();
                if (si != null) settings.add(si);
            }
            out.add(new ModInfo(m.id, name, m.on != null && m.on.getAsBoolean(), m.on != null, settings));
        }
        return out;
    }

    @Override public void toggle(String moduleId) {
        Mod m = find(moduleId);
        if (m != null && m.on != null) m.setOn.accept(!m.on.getAsBoolean());
    }

    @Override public void setNumber(String moduleId, String settingId, double value) {
        St s = findSetting(moduleId, settingId);
        if (s != null && s.onNum != null) s.onNum.accept(value);
    }

    @Override public void setBool(String moduleId, String settingId, boolean value) {
        St s = findSetting(moduleId, settingId);
        if (s != null && s.onBool != null) s.onBool.accept(value);
    }

    @Override public void setText(String moduleId, String settingId, String value) {
        St s = findSetting(moduleId, settingId);
        if (s != null && s.onText != null) s.onText.accept(value);
    }

    @Override public void setChoice(String moduleId, String settingId, int index) {
        St s = findSetting(moduleId, settingId);
        if (s != null && s.onChoice != null) s.onChoice.accept(index);
    }

    @Override public void removeListItem(String moduleId, String settingId, int index) {
        St s = findSetting(moduleId, settingId);
        if (s != null && s.onRemove != null) s.onRemove.accept(index);
    }

    @Override public boolean lightTheme() { return light; }
    @Override public void toggleTheme() { light = !light; }
    @Override public void openMusic() { }
    @Override public void openProfiles() { }
}
