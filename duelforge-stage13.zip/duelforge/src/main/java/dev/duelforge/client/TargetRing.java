package dev.duelforge.client;

import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Tier;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import dev.duelforge.vis.HudMath;
import dev.duelforge.vis.RingMath;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.entity.Entity;

/**
 * Rotating ring that sweeps the body of the enemy each Lab bot is fighting (Expensive's TargetESP / JumpCircle look). Drawn with client-side
 * dust particles, so it needs no custom render code and works on any server where the bot's enemy is visible to you.
 */
public final class TargetRing {
    private static long ticks;

    private TargetRing() {}

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(TargetRing::tick);
    }

    private static void tick(Minecraft mc) {
        if (!Opts.targetRing || mc.level == null || mc.isPaused()) return;
        ticks++;
        if ((ticks & 1) != 0) return;                       // every other tick: enough particles, not a cloud
        for (BotClient b : BotManager.INSTANCE.list()) {
            if (b.status != BotClient.Status.PLAYING) continue;
            int id = b.targetId();
            if (id < 0) continue;
            Entity e = mc.level.getEntity(id);
            if (e == null || !e.isAlive()) continue;
            int rgb = HudMath.tierColor(b.tier.ordinal(), Tier.values().length) & 0xFFFFFF;
            DustParticleOptions dust = new DustParticleOptions(rgb, 0.9f);
            double y = e.getY() + RingMath.sweep(ticks, 40) * e.getBbHeight();
            double phase = ticks * 0.12 + (b.name.hashCode() & 7);
            for (double[] p : RingMath.ring(e.getX(), y, e.getZ(), RingMath.radiusFor(e.getBbWidth()), 6, phase)) {
                mc.level.addParticle(dust, p[0], p[1], p[2], 0, 0, 0);
            }
        }
    }
}
