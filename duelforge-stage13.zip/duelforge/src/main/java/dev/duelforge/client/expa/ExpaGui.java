package dev.duelforge.client.expa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import top.fpsmaster.prism.anim.Anim;
import top.fpsmaster.prism.canvas.Canvas;
import top.fpsmaster.prism.canvas.FontHandle;
import top.fpsmaster.prism.icon.GlyphIcons;
import top.fpsmaster.prism.screen.ClickGuiBridge;
import top.fpsmaster.prism.theme.Argb;
import top.fpsmaster.prism.widget.Chrome;
import top.fpsmaster.prism.widget.Scroll;
import top.fpsmaster.prism.widget.TextBox;
import top.fpsmaster.prism.widget.TextFit;
import top.fpsmaster.prism.widget.UiFrame;

/**
 * Duelforge menu in the visual style of the "Expensive" client: one floating window, a header
 * with the brand and search, category chips, and a masonry grid of module cards that always show
 * their settings. Same entry points as the old Prism click GUI, so the screen is a drop-in swap.
 *
 * <p>All numbers are GUI units. They are the original 920x550 layout divided by two, because one
 * Prism font size unit is half a GUI unit (a "15" font is 7.5 units high).
 */
public final class ExpaGui {
    // window
    static final float W = 460f;
    static final float H = 275f;
    private static final float RADIUS = 4f;
    private static final float HEADER_H = 30f;
    private static final float CHIPS_H = 24f;
    private static final float PAD = 12f;
    // module cards
    private static final float CARD_W = 138f;
    private static final float CARD_GAP_X = 11f;
    private static final float CARD_GAP_Y = 8f;
    private static final float CARD_HEAD = 24f;
    private static final float CARD_PAD = 7f;
    private static final float CARD_RADIUS = 6f;
    // setting rows
    private static final float ROW = 15f;
    private static final float GAP = 4f;
    private static final float GROUP_ROW = 13f;
    private static final float NUMBER_ROW = 22f;
    private static final float TEXT_ROW = 27f;
    private static final float LIST_ROW = 14f;
    private static final float CHIP_H = 11f;
    private static final float PICKER_H = 46f;
    private static final float OPEN_SEC = 0.25f;
    private static final float SLIDE = 17.5f;

    /** Starred modules float to the top of their category (kept for the session). */
    private static final Set<String> FAVORITES = new HashSet<String>();

    public String category;

    private final TextBox search = new TextBox();
    private final Scroll scroll = new Scroll("expa.cards");
    private final Object windowDrag = new Object();
    private final Map<String, Map<String, SettingState>> settingStates = new HashMap<String, Map<String, SettingState>>();
    private final Map<String, float[]> cardState = new HashMap<String, float[]>(); // x, y, init, toggleT, hoverT, starT
    private final Map<String, float[]> chipState = new HashMap<String, float[]>();  // hoverT, selectedT
    private final Map<String, Map<String, Boolean>> collapsedGroups = new HashMap<String, Map<String, Boolean>>();
    private SettingState expandedColor;
    private SettingState expandedChoice;
    private String captureModule;
    private String captureSetting;
    private int captureListIndex = -1;

    private long lastNanos;
    private boolean animateOpen;
    private boolean closing;
    private float openT = 1f;
    private float categoryT = 1f;
    private float dragX, dragY, grabX, grabY;
    private boolean dragging;

    public ExpaGui(String defaultCategory) {
        this.category = defaultCategory;
        search.setPaintBox(false);
        search.setFontSize(12);
        search.setPadLeft(13f);
    }

    /** Call from the host screen's init so the open motion runs. */
    public void onOpen() {
        animateOpen = true;
        closing = false;
        openT = 0f;
        lastNanos = 0L;
    }

    /** Start the close animation. {@link #draw} returns true when it is over. */
    public void beginClose() {
        if (animateOpen) {
            closing = true;
        }
    }

    /** Cancel an active key capture. */
    public boolean cancelKeyCapture() {
        if (captureModule == null) {
            return false;
        }
        captureModule = null;
        captureSetting = null;
        captureListIndex = -1;
        return true;
    }

    /** @return true when the close animation has finished and the host should dismiss the screen */
    public boolean draw(UiFrame ui, ClickGuiBridge bridge) {
        applyCapturedKey(ui, bridge);
        float dt = dt(ui);
        tickOpen(dt);
        ExpaPalette p = bridge.lightTheme() ? ExpaPalette.LIGHT : ExpaPalette.DARK;

        float gw = ui.host().width();
        float gh = ui.host().height();
        float eased = closing ? openT : Anim.cssEase(openT);
        Canvas canvas = ui.canvas();
        canvas.fillRect(0f, 0f, gw, gh, Argb.of(Math.round(p.veil * eased), 0, 0, 0));

        float fit = Math.min(1f, Math.min((gw - 8f) / W, (gh - 8f) / H));
        ui.pushTransform();
        ui.translate(gw * 0.5f, gh * 0.5f);
        ui.scale(fit);
        ui.translate(-gw * 0.5f, -gh * 0.5f);
        ui.translate(0f, (1f - eased) * SLIDE);
        boolean inputWas = ui.inputEnabled();
        if (closing) {
            ui.setInputEnabled(false);
        }
        canvas.pushAlpha(Math.max(0.02f, eased));
        try {
            drawWindow(ui, bridge, p, dt, gw, gh);
        } finally {
            canvas.popAlpha();
            ui.setInputEnabled(inputWas);
            ui.popTransform();
        }
        return closing && openT <= 0f;
    }

    // ------------------------------------------------------------------------------ window

    private void drawWindow(UiFrame ui, ClickGuiBridge b, ExpaPalette p, float dt, float gw, float gh) {
        Canvas c = ui.canvas();
        float baseX = (gw - W) * 0.5f;
        float baseY = (gh - H) * 0.5f;
        float x = baseX + dragX;
        float y = baseY + dragY;

        // surface + soft accent glow along the top edge (the original draws a background texture here)
        panel(c, x, y, W, H, RADIUS, p.windowFill, p.windowOutline);
        c.fillGradientV(x + RADIUS, y + 1f, W - 2f * RADIUS, 46f, Argb.withAlpha(p.accent, p.light ? 18 : 24), Argb.withAlpha(p.accent, 0));

        // --- header: controls first (so they win the click), window drag on the free part after
        float right = x + W - PAD;
        float closeX = right - 13f;
        float themeX = closeX - 19f;
        float searchW = 118f;
        float searchX = themeX - 10f - searchW;
        float searchY = y + (HEADER_H - 16f) / 2f;

        boolean closeHover = ui.hovered(closeX, y + (HEADER_H - 13f) / 2f, 13f, 13f);
        iconButton(c, p, closeX, y + (HEADER_H - 13f) / 2f, closeHover);
        int closeColor = closeHover ? p.text100 : p.text500;
        float cx = closeX + 6.5f, cy = y + HEADER_H / 2f;
        c.line(cx - 2.6f, cy - 2.6f, cx + 2.6f, cy + 2.6f, 0.9f, closeColor);
        c.line(cx - 2.6f, cy + 2.6f, cx + 2.6f, cy - 2.6f, 0.9f, closeColor);
        if (ui.clicked(closeX, y + (HEADER_H - 13f) / 2f, 13f, 13f)) {
            beginClose();
        }

        boolean themeHover = ui.hovered(themeX, y + (HEADER_H - 13f) / 2f, 13f, 13f);
        iconButton(c, p, themeX, y + (HEADER_H - 13f) / 2f, themeHover);
        GlyphIcons.draw(ui, b.lightTheme() ? "sun" : "moon", themeX + 3f, y + (HEADER_H - 7f) / 2f, 7f,
                themeHover ? p.text100 : p.text500);
        if (ui.clicked(themeX, y + (HEADER_H - 13f) / 2f, 13f, 13f)) {
            b.toggleTheme();
        }

        boolean searchHover = ui.hovered(searchX, searchY, searchW, 16f);
        panel(c, searchX, searchY, searchW, 16f, 5f, p.inputFill,
                search.focused() ? p.accent : (searchHover ? p.mix(p.inputOutline, p.text600, 0.35f) : p.inputOutline));
        GlyphIcons.draw(ui, "search", searchX + 4f, searchY + (16f - 6f) / 2f, 6f, search.focused() ? p.accentBright : p.text500);
        search.setPlaceholder(b.i18n("clickgui.search.placeholder"));
        search.draw(ui, searchX, searchY, searchW, 16f);

        // brand
        float logo = 14f;
        float logoX = x + PAD;
        float logoY = y + (HEADER_H - logo) / 2f;
        c.fillRoundRect(logoX, logoY, logo, logo, 4f, p.accent);
        c.fillRoundRect(logoX + 0.5f, logoY + 0.5f, logo - 1f, logo / 2f, 3.5f, Argb.withAlpha(0xFFFFFFFF, 30));
        FontHandle logoFont = ui.font(15);
        String letter = "D";
        c.drawString(logoFont, letter, logoX + (logo - logoFont.measure(letter)) / 2f, Chrome.textY(logoY, logo, logoFont), 0xFFFFFFFF);
        FontHandle brandFont = ui.font(15);
        float brandX = logoX + logo + 6f;
        c.drawString(brandFont, b.brand(), brandX, Chrome.textY(y, HEADER_H, brandFont), p.text100);
        FontHandle subFont = ui.font(11);
        String sub = b.edition() + " \u00B7 " + b.version();
        float subX = brandX + brandFont.measure(b.brand()) + 6f;
        if (subX + subFont.measure(sub) < searchX - 8f) {
            c.drawString(subFont, sub, subX, Chrome.textY(y, HEADER_H, subFont) + 0.5f, p.text600);
        }

        // drag the window by the free part of the header
        float dragW = searchX - 6f - x;
        if (ui.beginDrag(windowDrag, x, y, dragW, HEADER_H)) {
            if (!dragging) {
                dragging = true;
                grabX = ui.localMouseX() - x;
                grabY = ui.localMouseY() - y;
            }
            dragX = clamp(ui.localMouseX() - grabX - baseX, -baseX - W + 60f, gw - baseX - 60f);
            dragY = clamp(ui.localMouseY() - grabY - baseY, -baseY, gh - baseY - 24f);
            if (!ui.input().isButtonDown(0)) {
                ui.input().releaseDrag(windowDrag);
                dragging = false;
            }
        } else {
            dragging = false;
        }
        c.fillRect(x + 1f, y + HEADER_H, W - 2f, 1f, p.divider);

        // --- category chips
        boolean searching = !search.text().trim().isEmpty();
        drawChips(ui, b, p, x + PAD, y + HEADER_H + 4f, W - 2f * PAD, searching, dt);

        // --- module grid
        float viewX = x + PAD;
        float viewY = y + HEADER_H + CHIPS_H + 4f;
        float viewW = W - PAD - 6f;
        float viewH = H - HEADER_H - CHIPS_H - 4f - 6f;
        List<ClickGuiBridge.ModInfo> mods = new ArrayList<ClickGuiBridge.ModInfo>(b.modules(category, search.text()));
        if (!FAVORITES.isEmpty()) {
            List<ClickGuiBridge.ModInfo> starred = new ArrayList<ClickGuiBridge.ModInfo>();
            List<ClickGuiBridge.ModInfo> rest = new ArrayList<ClickGuiBridge.ModInfo>();
            for (ClickGuiBridge.ModInfo m : mods) {
                (FAVORITES.contains(m.id) ? starred : rest).add(m);
            }
            mods = starred;
            mods.addAll(rest);
        }

        int cols = Math.max(1, (int) ((viewW - 6f + CARD_GAP_X) / (CARD_W + CARD_GAP_X)));
        float[] colH = new float[cols];
        float[] cardH = new float[mods.size()];
        float[] cardX = new float[mods.size()];
        float[] cardY = new float[mods.size()];
        for (int i = 0; i < mods.size(); i++) {
            ClickGuiBridge.ModInfo m = mods.get(i);
            cardH[i] = cardHeight(ui, m);
            int col = 0;
            for (int k = 1; k < cols; k++) {
                if (colH[k] < colH[col] - 0.01f) {
                    col = k;
                }
            }
            cardX[i] = col * (CARD_W + CARD_GAP_X);
            cardY[i] = colH[col];
            colH[col] += cardH[i] + CARD_GAP_Y;
        }
        float contentH = 2f;
        for (float h : colH) {
            contentH = Math.max(contentH, h);
        }

        categoryT = Anim.approach(categoryT, 1f, 0.16f, dt);
        c.pushAlpha(0.4f + Anim.cssEase(categoryT) * 0.6f);
        float off = scroll.begin(ui, viewX, viewY, viewW, viewH, contentH);
        for (int i = 0; i < mods.size(); i++) {
            float[] st = cardState(mods.get(i));
            float tx = viewX + cardX[i];
            float ty = viewY + off + cardY[i];
            if (st[2] == 0f) {
                st[0] = tx;
                st[1] = ty;
                st[2] = 1f;
            } else {
                st[0] = Anim.approach(st[0], tx, 0.3f, dt);
                st[1] = Anim.approach(st[1], ty, 0.3f, dt);
            }
            // cards scrolled out of view are skipped, but their animation target is kept above
            if (st[1] + cardH[i] < viewY - 2f || st[1] > viewY + viewH + 2f) {
                continue;
            }
            drawCard(ui, b, p, mods.get(i), st, cardH[i], dt);
        }
        if (searching && mods.isEmpty()) {
            String empty = b.i18n("clickgui.search.noresults");
            FontHandle f = ui.font(14);
            c.drawString(f, empty, viewX + (viewW - f.measure(empty)) / 2f, viewY + viewH / 2f - f.lineHeight() / 2f, p.text600);
        }
        scroll.end(ui);
        c.popAlpha();
    }

    // ------------------------------------------------------------------------------ chips

    private void drawChips(UiFrame ui, ClickGuiBridge b, ExpaPalette p, float x, float y, float w, boolean searching, float dt) {
        Canvas c = ui.canvas();
        List<String> cats = b.categories();
        FontHandle font = ui.font(12);
        float icon = 6f;
        float chipH = 16f;
        float gap = 5f;
        float[] width = new float[cats.size()];
        float total = gap * Math.max(0, cats.size() - 1);
        for (int i = 0; i < cats.size(); i++) {
            width[i] = 7f + icon + 4f + font.measure(b.categoryLabel(cats.get(i))) + 7f;
            total += width[i];
        }
        if (total > w) {
            float k = (w - gap * Math.max(0, cats.size() - 1)) / (total - gap * Math.max(0, cats.size() - 1));
            for (int i = 0; i < width.length; i++) {
                width[i] *= k;
            }
        }
        float cx = x;
        for (int i = 0; i < cats.size(); i++) {
            String id = cats.get(i);
            float[] st = chipState.get(id);
            if (st == null) {
                st = new float[] {0f, id.equals(category) ? 1f : 0f};
                chipState.put(id, st);
            }
            boolean selected = !searching && id.equals(category);
            boolean hover = ui.hovered(cx, y, width[i], chipH);
            st[0] = Anim.approach(st[0], hover ? 1f : 0f, 0.25f, dt);
            st[1] = Anim.approach(st[1], selected ? 1f : 0f, 0.22f, dt);
            if (st[1] > 0.01f) {
                c.fillRoundRect(cx, y, width[i], chipH, chipH / 2f, Argb.mulAlpha(p.light ? 0xFFFFFFFF : p.inputFill, st[1]));
            }
            panel(c, cx, y, width[i], chipH, chipH / 2f, st[1] > 0.01f ? 0x00000000 : 0x00000000,
                    p.mix(p.chipOutline, p.mix(p.chipOutline, p.accent, 0.55f), st[1]));
            int color = p.mix(p.mix(p.text500, p.text300, st[0]), p.text100, st[1]);
            GlyphIcons.draw(ui, b.categoryIcon(id), cx + 7f, y + (chipH - icon) / 2f, icon,
                    p.mix(color, p.accentBright, st[1] * 0.6f));
            String label = TextFit.ellipsize(font, b.categoryLabel(id), width[i] - 7f - icon - 4f - 6f);
            c.drawString(font, label, cx + 7f + icon + 4f, Chrome.textY(y, chipH, font), color);
            if (ui.clicked(cx, y, width[i], chipH)) {
                search.setText("");
                search.setFocused(false);
                if (!id.equals(category)) {
                    category = id;
                    expandedColor = null;
                    expandedChoice = null;
                    scroll.setOffset(0f);
                    cardState.clear();
                    categoryT = 0f;
                }
            }
            cx += width[i] + gap;
        }
    }

    // ------------------------------------------------------------------------------ cards

    private float[] cardState(ClickGuiBridge.ModInfo mod) {
        float[] st = cardState.get(mod.id);
        if (st == null) {
            st = new float[] {0f, 0f, 0f, mod.enabled ? 1f : 0f, 0f, FAVORITES.contains(mod.id) ? 1f : 0f};
            cardState.put(mod.id, st);
        }
        return st;
    }

    private float cardHeight(UiFrame ui, ClickGuiBridge.ModInfo mod) {
        float inner = CARD_W - 2f * CARD_PAD;
        float body = settingsHeight(ui, mod, inner);
        return body <= 0f ? CARD_HEAD : CARD_HEAD + 1f + body + CARD_PAD;
    }

    private void drawCard(UiFrame ui, ClickGuiBridge b, ExpaPalette p, ClickGuiBridge.ModInfo mod, float[] st, float h, float dt) {
        Canvas c = ui.canvas();
        float x = st[0];
        float y = st[1];
        boolean hover = ui.hovered(x, y, CARD_W, CARD_HEAD);
        st[3] = Anim.approach(st[3], mod.enabled ? 1f : 0f, 0.25f, dt);
        st[4] = Anim.approach(st[4], hover ? 1f : 0f, 0.25f, dt);
        boolean fav = FAVORITES.contains(mod.id);
        st[5] = Anim.approach(st[5], fav ? 1f : 0f, 0.3f, dt);

        panel(c, x, y, CARD_W, h, CARD_RADIUS, p.cardFill, p.mix(p.cardOutline, p.cardOutlineHover, st[4]));

        // header: frame icon, name, [key], star, switch
        float midY = y + CARD_HEAD / 2f;
        float swW = 12f, swH = 8f;
        float swX = x + CARD_W - CARD_PAD - swW;
        float swY = midY - swH / 2f;
        float rightEdge = swX - 5f;
        if (mod.keyName != null && !mod.keyName.isEmpty()) {
            boolean capturing = mod.id.equals(captureModule) && captureSetting == null;
            String key = capturing ? "..." : mod.keyName;
            FontHandle kf = ui.font(10);
            float kw = Math.max(15f, kf.measure(key) + 8f);
            float kx = rightEdge - kw;
            boolean kh = ui.hovered(kx, midY - 5f, kw, 10f);
            panel(c, kx, midY - 5f, kw, 10f, 3f, capturing ? Argb.withAlpha(p.accent, 40) : p.inputFill,
                    capturing ? p.accent : (kh ? p.text600 : p.inputOutline));
            c.drawString(kf, key, kx + (kw - kf.measure(key)) / 2f, Chrome.textY(midY - 5f, 10f, kf), capturing ? p.accentBright : p.text400);
            if (ui.clicked(kx, midY - 5f, kw, 10f)) {
                captureModule = mod.id;
                captureSetting = null;
                captureListIndex = -1;
            }
            rightEdge = kx - 5f;
        }
        float starSize = 7f;
        float starX = rightEdge - starSize;
        boolean starHover = ui.hovered(starX - 3f, midY - 6f, starSize + 6f, 12f);
        drawStar(c, starX + starSize / 2f, midY, 3.4f, p.mix(starHover ? p.text400 : p.text600, p.favorite, st[5]), st[5]);
        if (ui.clicked(starX - 3f, midY - 6f, starSize + 6f, 12f)) {
            if (fav) {
                FAVORITES.remove(mod.id);
            } else {
                FAVORITES.add(mod.id);
            }
            cardState.clear();
        }
        rightEdge = starX - 5f;

        int iconColor = p.mix(p.text500, p.accent, st[3]);
        float icon = 7f;
        float ix = x + CARD_PAD;
        c.strokeRoundRect(ix, midY - icon / 2f, icon, icon, 2f, 0.9f, iconColor);
        c.fillRoundRect(ix + 2.25f, midY - 1.25f, 2.5f, 2.5f, 1.25f, iconColor);
        FontHandle nameFont = ui.font(15);
        float nameX = ix + icon + 4f;
        String name = TextFit.ellipsize(nameFont, mod.name, rightEdge - nameX);
        c.drawString(nameFont, name, nameX, Chrome.textY(y, CARD_HEAD, nameFont), p.text100);

        if (mod.canToggle) {
            int fill = p.mix(p.offFill, p.accent, st[3]);
            int outline = p.mix(p.offOutline, p.accentBright, st[3]);
            panel(c, swX, swY, swW, swH, swH / 2f + 0.5f, p.mix(fill, p.mix(fill, 0xFFFFFFFF, 0.05f), st[4]), outline);
            float knob = (swH - 3f) / 2f;
            float kx = swX + 1.5f + knob + (swW - 3f - 2f * knob) * st[3];
            c.fillCircle(kx, midY, knob, p.mix(p.offKnob, 0xFFFFFFFF, st[3]));
        }
        if (mod.canToggle && ui.clicked(x, y, CARD_W, CARD_HEAD)) {
            b.toggle(mod.id);
        }

        // settings
        if (!mod.settings.isEmpty()) {
            float inner = CARD_W - 2f * CARD_PAD;
            float sx = x + CARD_PAD;
            float sy = y + CARD_HEAD + 1f;
            String lastGroup = null;
            boolean collapsed = false;
            boolean first = true;
            for (int i = 0; i < mod.settings.size(); i++) {
                ClickGuiBridge.SettingInfo s = mod.settings.get(i);
                if (!s.visible) {
                    continue;
                }
                String groupId = s.group == null ? null : s.group.id;
                if (groupId != null && !groupId.equals(lastGroup)) {
                    collapsed = groupCollapsed(mod.id, s.group);
                    if (!first) {
                        sy += GAP;
                    }
                    first = false;
                    sy += drawGroup(ui, b, p, mod.id, s.group, sx, sy, inner, collapsed);
                } else if (groupId == null) {
                    collapsed = false;
                }
                lastGroup = groupId;
                if (collapsed) {
                    continue;
                }
                if (!first) {
                    sy += GAP;
                }
                first = false;
                sy += drawSetting(ui, b, p, mod, s, sx, sy, inner, dt);
            }
        }
    }

    private float settingsHeight(UiFrame ui, ClickGuiBridge.ModInfo mod, float inner) {
        float height = 0f;
        boolean first = true;
        String lastGroup = null;
        boolean collapsed = false;
        for (int i = 0; i < mod.settings.size(); i++) {
            ClickGuiBridge.SettingInfo s = mod.settings.get(i);
            if (!s.visible) {
                continue;
            }
            String groupId = s.group == null ? null : s.group.id;
            if (groupId != null && !groupId.equals(lastGroup)) {
                collapsed = groupCollapsed(mod.id, s.group);
                height += (first ? 0f : GAP) + GROUP_ROW;
                first = false;
            } else if (groupId == null) {
                collapsed = false;
            }
            lastGroup = groupId;
            if (collapsed) {
                continue;
            }
            height += (first ? 0f : GAP) + settingHeight(ui, mod.id, s, inner);
            first = false;
        }
        return height;
    }

    private float settingHeight(UiFrame ui, String moduleId, ClickGuiBridge.SettingInfo s, float inner) {
        switch (s.kind) {
            case ClickGuiBridge.SettingInfo.NUMBER:
                return NUMBER_ROW;
            case ClickGuiBridge.SettingInfo.TEXT:
                return TEXT_ROW;
            case ClickGuiBridge.SettingInfo.CHOICE:
                if (expandedChoice != null && expandedChoice == settingState(moduleId, s.id)) {
                    return ROW + 2f + flowHeight(ui, s.options, inner);
                }
                return ROW;
            case ClickGuiBridge.SettingInfo.COLOR:
                if (expandedColor != null && expandedColor == settingState(moduleId, s.id)) {
                    return ROW + colorExtra(s);
                }
                return ROW;
            case ClickGuiBridge.SettingInfo.LIST:
                return ROW + LIST_ROW * s.items.size();
            default:
                return ROW;
        }
    }

    private float drawGroup(UiFrame ui, ClickGuiBridge b, ExpaPalette p, String moduleId, ClickGuiBridge.GroupInfo group,
                            float x, float y, float w, boolean collapsed) {
        String label = group.label.isEmpty() ? b.settingGroupLabel(group.id) : group.label;
        FontHandle font = ui.font(11);
        boolean hover = ui.hovered(x, y, w, GROUP_ROW);
        GlyphIcons.draw(ui, collapsed ? "chev-r" : "chev-d", x, y + (GROUP_ROW - 5f) / 2f, 5f, hover ? p.text300 : p.text500);
        ui.canvas().drawString(font, TextFit.ellipsize(font, label, w - 12f), x + 9f, Chrome.textY(y, GROUP_ROW, font),
                hover ? p.text300 : p.text500);
        if (ui.clicked(x, y, w, GROUP_ROW)) {
            groups(moduleId).put(group.id, Boolean.valueOf(!collapsed));
            cardState.clear();
        }
        return GROUP_ROW;
    }

    // ------------------------------------------------------------------------------ settings

    private float drawSetting(UiFrame ui, ClickGuiBridge b, ExpaPalette p, ClickGuiBridge.ModInfo mod,
                              ClickGuiBridge.SettingInfo s, float x, float y, float w, float dt) {
        Canvas c = ui.canvas();
        SettingState state = settingState(mod.id, s.id);
        FontHandle labelFont = ui.font(13);
        switch (s.kind) {
            case ClickGuiBridge.SettingInfo.BOOL: {
                if (Float.isNaN(state.knob)) {
                    state.knob = s.boolValue ? 1f : 0f;
                }
                state.knob = Anim.approach(state.knob, s.boolValue ? 1f : 0f, 0.25f, dt);
                boolean hover = ui.hovered(x, y, w, ROW);
                float box = 9f;
                float bx = x + w - box;
                float by = y + (ROW - box) / 2f;
                int label = p.mix(p.text300, p.text100, Math.max(state.knob, hover ? 0.6f : 0f));
                c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - box - 6f), x, Chrome.textY(y, ROW, labelFont), label);
                panel(c, bx, by, box, box, 2.5f, p.mix(p.offFill, p.accent, state.knob), p.mix(p.offOutline, p.accentBright, state.knob));
                if (state.knob > 0.05f) {
                    int white = Argb.mulAlpha(0xFFFFFFFF, state.knob);
                    c.line(bx + 2.2f, by + 4.6f, bx + 3.9f, by + 6.3f, 1f, white);
                    c.line(bx + 3.9f, by + 6.3f, bx + 7f, by + 2.7f, 1f, white);
                }
                if (ui.clicked(x, y, w, ROW)) {
                    b.setBool(mod.id, s.id, !s.boolValue);
                }
                return ROW;
            }
            case ClickGuiBridge.SettingInfo.NUMBER: {
                double span = s.max - s.min;
                float t = span == 0 ? 0f : clamp01((float) ((s.numberValue - s.min) / span));
                FontHandle valueFont = ui.font(11);
                String value = fmt(s.numberValue);
                float vw = valueFont.measure(value);
                c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - vw - 8f), x, y + 1f, p.text200);
                c.drawString(valueFont, value, x + w - vw, y + 1.5f, p.text500);
                float ty = y + 15f;
                float th = 3f;
                boolean over = ui.hovered(x, ty - 4f, w, th + 8f);
                if (ui.beginDrag(state, x, ty - 4f, w, th + 8f)) {
                    t = clamp01((ui.localMouseX() - x) / w);
                    if (!ui.input().isButtonDown(0)) {
                        ui.input().releaseDrag(state);
                    }
                }
                state.knob = Anim.approach(Float.isNaN(state.knob) ? t : state.knob, t, 0.4f, dt);
                float shown = ui.input().isDragging(state) ? t : state.knob;
                c.fillRoundRect(x, ty, w, th, th / 2f, p.trackBg);
                c.fillRoundRect(x, ty, Math.max(th, w * shown), th, th / 2f, p.accent);
                if (over || ui.input().isDragging(state)) {
                    c.fillCircle(x + w * shown, ty + th / 2f, 3.2f, 0xFFFFFFFF);
                }
                double mapped = s.min + t * span;
                if (isWhole(s.min) && isWhole(s.max) && span >= 5) {
                    mapped = Math.round(mapped);
                }
                if (ui.input().isDragging(state) && Math.abs(mapped - s.numberValue) > 1e-4) {
                    b.setNumber(mod.id, s.id, mapped);
                }
                return NUMBER_ROW;
            }
            case ClickGuiBridge.SettingInfo.TEXT: {
                c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w), x, y + 1f, p.text200);
                if (state.field == null) {
                    state.field = newField(s.textValue);
                }
                float fy = y + 12f;
                boolean focused = state.field.focused();
                panel(c, x, fy, w, 13f, 3.5f, p.inputFill, focused ? p.accent : p.inputOutline);
                state.field.draw(ui, x, fy, w, 13f);
                if (syncField(state.field, s.textValue)) {
                    b.setText(mod.id, s.id, state.field.text());
                }
                return TEXT_ROW;
            }
            case ClickGuiBridge.SettingInfo.CHOICE: {
                boolean open = state == expandedChoice;
                String value = s.options.isEmpty() ? "" : s.options.get(Math.max(0, Math.min(s.selectedIndex, s.options.size() - 1)));
                FontHandle chipFont = ui.font(10);
                float cw = Math.min(w * 0.58f, Math.max(24f, chipFont.measure(value) + 14f));
                float cx = x + w - cw;
                float cy = y + (ROW - CHIP_H) / 2f;
                c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - cw - 6f), x, Chrome.textY(y, ROW, labelFont), p.text200);
                boolean hover = ui.hovered(cx, cy, cw, CHIP_H);
                panel(c, cx, cy, cw, CHIP_H, 3f, open ? Argb.withAlpha(p.accent, 36) : p.inputFill,
                        open ? p.accent : (hover ? p.text600 : p.inputOutline));
                c.drawString(chipFont, TextFit.ellipsize(chipFont, value, cw - 12f), cx + 4f, Chrome.textY(cy, CHIP_H, chipFont),
                        open ? p.accentBright : p.text300);
                GlyphIcons.draw(ui, open ? "chev-d" : "chev-r", cx + cw - 7f, cy + (CHIP_H - 4f) / 2f, 4f, p.text500);
                if (ui.clicked(cx, cy, cw, CHIP_H)) {
                    expandedChoice = open ? null : state;
                    cardState.clear();
                }
                if (!open) {
                    return ROW;
                }
                float fy = y + ROW + 2f;
                float used = drawFlow(ui, p, b, mod.id, s, x, fy, w);
                return ROW + 2f + used;
            }
            case ClickGuiBridge.SettingInfo.COLOR:
                return drawColor(ui, b, p, mod.id, s, state, x, y, w, labelFont);
            case ClickGuiBridge.SettingInfo.KEY: {
                c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - 40f), x, Chrome.textY(y, ROW, labelFont), p.text200);
                drawKey(ui, p, mod.id, s.id, s.keyName, false, -1, x, y, w);
                return ROW;
            }
            case ClickGuiBridge.SettingInfo.LIST:
                return drawList(ui, b, p, mod.id, s, state, x, y, w, labelFont);
            default:
                return ROW;
        }
    }

    private float flowHeight(UiFrame ui, List<String> options, float w) {
        return flowLayout(ui, options, w, null);
    }

    /** Lays option chips out left to right with wrapping; fills {@code xs/ys} when given. Returns total height. */
    private float flowLayout(UiFrame ui, List<String> options, float w, float[][] out) {
        FontHandle f = ui.font(10);
        float cx = 0f, cy = 0f, gap = 3f;
        for (int i = 0; i < options.size(); i++) {
            float cw = Math.min(w, Math.max(18f, f.measure(options.get(i)) + 10f));
            if (cx > 0f && cx + cw > w) {
                cx = 0f;
                cy += CHIP_H + gap;
            }
            if (out != null) {
                out[0][i] = cx;
                out[1][i] = cy;
                out[2][i] = cw;
            }
            cx += cw + gap;
        }
        return options.isEmpty() ? 0f : cy + CHIP_H + gap;
    }

    private float drawFlow(UiFrame ui, ExpaPalette p, ClickGuiBridge b, String moduleId, ClickGuiBridge.SettingInfo s,
                           float x, float y, float w) {
        Canvas c = ui.canvas();
        FontHandle f = ui.font(10);
        float[][] pos = new float[3][s.options.size()];
        float total = flowLayout(ui, s.options, w, pos);
        for (int i = 0; i < s.options.size(); i++) {
            float ox = x + pos[0][i];
            float oy = y + pos[1][i];
            float ow = pos[2][i];
            boolean selected = i == s.selectedIndex;
            boolean hover = ui.hovered(ox, oy, ow, CHIP_H);
            panel(c, ox, oy, ow, CHIP_H, 3f,
                    selected ? Argb.withAlpha(p.accent, 40) : (hover ? p.mix(p.inputFill, p.text600, 0.2f) : p.inputFill),
                    selected ? p.accent : p.inputOutline);
            String label = TextFit.ellipsize(f, s.options.get(i), ow - 6f);
            c.drawString(f, label, ox + (ow - f.measure(label)) / 2f, Chrome.textY(oy, CHIP_H, f), selected ? p.accentBright : p.text300);
            if (ui.clicked(ox, oy, ow, CHIP_H)) {
                b.setChoice(moduleId, s.id, i);
                expandedChoice = null;
                cardState.clear();
            }
        }
        return total;
    }

    private float colorExtra(ClickGuiBridge.SettingInfo s) {
        float h = 3f + PICKER_H + 4f + 5f + 4f + 5f + 3f;
        if (!s.options.isEmpty()) {
            h += CHIP_H + 3f;
        }
        return h;
    }

    private float drawColor(UiFrame ui, ClickGuiBridge b, ExpaPalette p, String moduleId, ClickGuiBridge.SettingInfo s,
                            SettingState state, float x, float y, float w, FontHandle labelFont) {
        Canvas c = ui.canvas();
        boolean open = state == expandedColor;
        int rgb = java.awt.Color.HSBtoRGB(s.hue, s.saturation, s.brightness);
        int color = Argb.of(Math.round(s.alpha * 255f), (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        float dot = 9f;
        float dx = x + w - dot;
        float cy = y + ROW / 2f;
        c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - dot - 8f), x, Chrome.textY(y, ROW, labelFont), p.text200);
        c.fillCircle(dx + dot / 2f, cy, dot / 2f + 0.8f, open ? p.accent : p.inputOutline);
        c.fillCircle(dx + dot / 2f, cy, dot / 2f - 0.2f, color | 0xFF000000);
        if (ui.clicked(x, y, w, ROW)) {
            expandedColor = open ? null : state;
            cardState.clear();
        }
        if (!open) {
            return ROW;
        }
        String mode = s.colorMode == null ? "" : s.colorMode;
        float px = x;
        float py = y + ROW + 3f;
        float pw = w;
        int hueColor = java.awt.Color.HSBtoRGB(s.hue, 1f, 1f) | 0xFF000000;
        c.fillGradientH(px, py, pw, PICKER_H, 0xFFFFFFFF, hueColor);
        c.fillGradientV(px, py, pw, PICKER_H, 0x00000000, 0xFF000000);
        c.strokeRoundRect(px, py, pw, PICKER_H, 2f, 0.75f, p.inputOutline);
        float mx = px + s.saturation * pw;
        float my = py + (1f - s.brightness) * PICKER_H;
        c.fillCircle(mx, my, 3.2f, 0xFFFFFFFF);
        c.fillCircle(mx, my, 2f, color | 0xFF000000);
        if (ui.beginDrag(state.svDrag, px, py, pw, PICKER_H)) {
            float sat = clamp01((ui.localMouseX() - px) / pw);
            float bri = 1f - clamp01((ui.localMouseY() - py) / PICKER_H);
            b.setColor(moduleId, s.id, s.hue, sat, bri, s.alpha, mode);
            releaseDrag(ui, state.svDrag);
        }
        float hueY = py + PICKER_H + 4f;
        drawHue(c, px, hueY, pw, 5f);
        float hue = dragValue(ui, p, state.hueDrag, px, hueY, pw, 5f, s.hue);
        if (Math.abs(hue - s.hue) > 1e-4f) {
            b.setColor(moduleId, s.id, hue, s.saturation, s.brightness, s.alpha, mode);
        }
        float alphaY = hueY + 9f;
        drawChecker(c, px, alphaY, pw, 5f);
        int opaque = color | 0xFF000000;
        c.fillGradientH(px, alphaY, pw, 5f, opaque & 0x00FFFFFF, opaque);
        float alpha = dragValue(ui, p, state.alphaDrag, px, alphaY, pw, 5f, s.alpha);
        if (Math.abs(alpha - s.alpha) > 1e-4f) {
            b.setColor(moduleId, s.id, s.hue, s.saturation, s.brightness, alpha, mode);
        }
        if (!s.options.isEmpty()) {
            FontHandle f = ui.font(10);
            float mx0 = px;
            float my0 = alphaY + 5f + 4f;
            for (int i = 0; i < s.options.size(); i++) {
                String option = s.options.get(i);
                float ow = Math.max(22f, f.measure(option) + 10f);
                if (mx0 + ow > px + pw) {
                    break;
                }
                boolean sel = option.equals(mode);
                boolean hover = ui.hovered(mx0, my0, ow, CHIP_H);
                panel(c, mx0, my0, ow, CHIP_H, 3f, sel ? Argb.withAlpha(p.accent, 40) : (hover ? p.mix(p.inputFill, p.text600, 0.2f) : p.inputFill),
                        sel ? p.accent : p.inputOutline);
                c.drawString(f, option, mx0 + (ow - f.measure(option)) / 2f, Chrome.textY(my0, CHIP_H, f), sel ? p.accentBright : p.text300);
                if (ui.clicked(mx0, my0, ow, CHIP_H)) {
                    b.setColor(moduleId, s.id, s.hue, s.saturation, s.brightness, s.alpha, option);
                }
                mx0 += ow + 3f;
            }
        }
        return ROW + colorExtra(s);
    }

    private void drawKey(UiFrame ui, ExpaPalette p, String moduleId, String settingId, String keyName,
                         boolean list, int listIndex, float x, float y, float w) {
        Canvas c = ui.canvas();
        boolean capturing = moduleId.equals(captureModule) && settingId.equals(captureSetting)
                && captureListIndex == (list ? listIndex : -1);
        String label = capturing ? "..." : (keyName == null || keyName.isEmpty() ? "None" : keyName);
        FontHandle f = ui.font(10);
        float bw = Math.max(26f, f.measure(label) + 10f);
        float bx = list ? x : x + w - bw;
        float by = y + (ROW - CHIP_H) / 2f;
        boolean hover = ui.hovered(bx, by, bw, CHIP_H);
        panel(c, bx, by, bw, CHIP_H, 3f, capturing ? Argb.withAlpha(p.accent, 40) : p.inputFill,
                capturing ? p.accent : (hover ? p.text600 : p.inputOutline));
        c.drawString(f, label, bx + (bw - f.measure(label)) / 2f, Chrome.textY(by, CHIP_H, f), capturing ? p.accentBright : p.text300);
        if (ui.clicked(bx, by, bw, CHIP_H)) {
            captureModule = moduleId;
            captureSetting = settingId;
            captureListIndex = list ? listIndex : -1;
        }
    }

    private float drawList(UiFrame ui, ClickGuiBridge b, ExpaPalette p, String moduleId, ClickGuiBridge.SettingInfo s,
                           SettingState state, float x, float y, float w, FontHandle labelFont) {
        Canvas c = ui.canvas();
        c.drawString(labelFont, TextFit.ellipsize(labelFont, s.label, w - 20f), x, Chrome.textY(y, ROW, labelFont), p.text200);
        if (s.items.size() < s.maxItems) {
            float bx = x + w - 14f;
            float by = y + (ROW - CHIP_H) / 2f;
            boolean hover = ui.hovered(bx, by, 14f, CHIP_H);
            panel(c, bx, by, 14f, CHIP_H, 3f, p.inputFill, hover ? p.text600 : p.inputOutline);
            FontHandle f = ui.font(12);
            c.drawString(f, "+", bx + (14f - f.measure("+")) / 2f, Chrome.textY(by, CHIP_H, f), p.text300);
            if (ui.clicked(bx, by, 14f, CHIP_H)) {
                b.addListItem(moduleId, s.id);
            }
        }
        FontHandle itemFont = ui.font(11);
        for (int i = 0; i < s.items.size(); i++) {
            ClickGuiBridge.ListItem item = s.items.get(i);
            float rowY = y + ROW + LIST_ROW * i;
            float rx = x + w - 11f;
            float ry = rowY + (LIST_ROW - 11f) / 2f;
            boolean xh = ui.hovered(rx, ry, 11f, 11f);
            if (xh) {
                c.fillRoundRect(rx, ry, 11f, 11f, 3f, Argb.withAlpha(p.error, 40));
            }
            int xc = xh ? p.error : p.text500;
            c.line(rx + 3.3f, ry + 3.3f, rx + 7.7f, ry + 7.7f, 0.9f, xc);
            c.line(rx + 3.3f, ry + 7.7f, rx + 7.7f, ry + 3.3f, 0.9f, xc);
            if (ui.clicked(rx, ry, 11f, 11f)) {
                b.removeListItem(moduleId, s.id, i);
                state.items.clear();
                if (captureListIndex >= 0 && moduleId.equals(captureModule) && s.id.equals(captureSetting)) {
                    cancelKeyCapture();
                }
                continue;
            }
            if (s.editableItems) {
                drawKey(ui, p, moduleId, s.id, item.keyName, true, i, x, rowY, 30f);
                while (state.items.size() <= i) {
                    state.items.add(null);
                }
                TextBox box = state.items.get(i);
                if (box == null) {
                    box = newField(item.text);
                    state.items.set(i, box);
                }
                float fx = x + 33f;
                float fw = w - 33f - 14f;
                float fy = rowY + (LIST_ROW - 11f) / 2f;
                panel(c, fx, fy, fw, 11f, 3f, p.inputFill, box.focused() ? p.accent : p.inputOutline);
                box.draw(ui, fx, fy, fw, 11f);
                if (syncField(box, item.text)) {
                    b.setListItemText(moduleId, s.id, i, box.text());
                }
            } else {
                c.drawString(itemFont, TextFit.ellipsize(itemFont, item.text, w - 16f), x + 2f,
                        Chrome.textY(rowY, LIST_ROW, itemFont), p.text400);
            }
        }
        return ROW + LIST_ROW * s.items.size();
    }

    // ------------------------------------------------------------------------------ drawing helpers

    /** Rounded surface with a thin outline, the shape used by every surface of the original. */
    private static void panel(Canvas c, float x, float y, float w, float h, float r, int fill, int outline) {
        if (Argb.alpha(fill) > 0) {
            c.fillRoundRect(x, y, w, h, r, fill);
        }
        if (Argb.alpha(outline) > 0) {
            c.strokeRoundRect(x, y, w, h, r, 0.85f, outline);
        }
    }

    private static void iconButton(Canvas c, ExpaPalette p, float x, float y, boolean hover) {
        if (hover) {
            c.fillRoundRect(x, y, 13f, 13f, 4f, p.hoverFill);
        }
    }

    /** Five-pointed star as a pentagram; filled (favourite) gets a centre dot and a thicker stroke. */
    private static void drawStar(Canvas c, float cx, float cy, float r, int color, float filled) {
        float[] xs = new float[5];
        float[] ys = new float[5];
        for (int i = 0; i < 5; i++) {
            double a = -Math.PI / 2 + i * 2 * Math.PI / 5;
            xs[i] = cx + (float) Math.cos(a) * r;
            ys[i] = cy + (float) Math.sin(a) * r + 0.3f;
        }
        float w = 0.8f + 0.5f * filled;
        for (int i = 0; i < 5; i++) {
            int j = (i + 2) % 5;
            c.line(xs[i], ys[i], xs[j], ys[j], w, color);
        }
        if (filled > 0.05f) {
            c.fillCircle(cx, cy + 0.3f, r * 0.42f, color);
        }
    }

    private static void drawHue(Canvas c, float x, float y, float w, float h) {
        int[] colors = {0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000};
        float segment = w / 6f;
        for (int i = 0; i < 6; i++) {
            c.fillGradientH(x + segment * i, y, segment + 0.5f, h, colors[i], colors[i + 1]);
        }
    }

    private static void drawChecker(Canvas c, float x, float y, float w, float h) {
        float size = 2.5f;
        int columns = Math.max(1, (int) Math.ceil(w / size));
        for (int i = 0; i < columns; i++) {
            c.fillRect(x + i * size, y, Math.min(size, w - i * size), h, (i & 1) == 0 ? 0xFFB8BDC2 : 0xFF747B82);
        }
    }

    private static float dragValue(UiFrame ui, ExpaPalette p, Object id, float x, float y, float w, float h, float value) {
        if (ui.beginDrag(id, x, y, w, h)) {
            value = clamp01((ui.localMouseX() - x) / w);
            releaseDrag(ui, id);
        }
        ui.canvas().fillCircle(x + value * w, y + h * 0.5f, 3f, 0xFFFFFFFF);
        ui.canvas().strokeRoundRect(x + value * w - 3f, y + h * 0.5f - 3f, 6f, 6f, 3f, 0.6f, Argb.withAlpha(0xFF000000, 90));
        return value;
    }

    private static void releaseDrag(UiFrame ui, Object id) {
        if (!ui.input().isButtonDown(0)) {
            ui.input().releaseDrag(id);
        }
    }

    // ------------------------------------------------------------------------------ state

    private boolean groupCollapsed(String moduleId, ClickGuiBridge.GroupInfo group) {
        Map<String, Boolean> groups = groups(moduleId);
        Boolean value = groups.get(group.id);
        if (value == null) {
            value = Boolean.valueOf(group.collapsedByDefault);
            groups.put(group.id, value);
        }
        return value.booleanValue();
    }

    private Map<String, Boolean> groups(String moduleId) {
        Map<String, Boolean> groups = collapsedGroups.get(moduleId);
        if (groups == null) {
            groups = new HashMap<String, Boolean>();
            collapsedGroups.put(moduleId, groups);
        }
        return groups;
    }

    private SettingState settingState(String moduleId, String settingId) {
        Map<String, SettingState> perModule = settingStates.get(moduleId);
        if (perModule == null) {
            perModule = new HashMap<String, SettingState>();
            settingStates.put(moduleId, perModule);
        }
        SettingState state = perModule.get(settingId);
        if (state == null) {
            state = new SettingState();
            perModule.put(settingId, state);
        }
        return state;
    }

    private static TextBox newField(String text) {
        TextBox box = new TextBox(text);
        box.setFontSize(11);
        box.setPaintBox(false);
        box.setPadLeft(4f);
        return box;
    }

    /** Field shows the bridge value unless the user is editing it; a user edit is written back. */
    private static boolean syncField(TextBox box, String external) {
        String value = external == null ? "" : external;
        if (box.changed()) {
            return !box.text().equals(value);
        }
        if (!box.focused() && !box.text().equals(value)) {
            box.setText(value);
        }
        return false;
    }

    private void applyCapturedKey(UiFrame ui, ClickGuiBridge bridge) {
        int raw = ui.input().consumeRawKey();
        if (raw < 0 || captureModule == null) {
            return;
        }
        if (raw == 1 || raw == 256) {
            cancelKeyCapture();
            return;
        }
        if (captureSetting == null) {
            bridge.setModuleKey(captureModule, raw);
        } else if (captureListIndex >= 0) {
            bridge.setListItemKey(captureModule, captureSetting, captureListIndex, raw);
        } else {
            bridge.setKey(captureModule, captureSetting, raw);
        }
        captureModule = null;
        captureSetting = null;
        captureListIndex = -1;
    }

    private void tickOpen(float dt) {
        if (!animateOpen) {
            openT = closing ? 0f : 1f;
            return;
        }
        if (closing) {
            openT = Math.max(0f, openT - dt / OPEN_SEC);
        } else if (openT < 1f) {
            openT = Math.min(1f, openT + dt / OPEN_SEC);
        }
    }

    private float dt(UiFrame ui) {
        long now = ui.host().nowNanos();
        float dt = lastNanos == 0L ? 0.016f : (now - lastNanos) / 1_000_000_000f;
        lastNanos = now;
        if (dt > 0.05f) {
            dt = 0.05f;
        }
        if (dt < 0f) {
            dt = 0.016f;
        }
        return dt;
    }

    private static String fmt(double v) {
        if (Math.abs(v - Math.rint(v)) < 1e-6) {
            return Long.toString(Math.round(v));
        }
        String s = String.format(Locale.ROOT, "%.2f", v);
        if (s.indexOf('.') >= 0) {
            s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return s;
    }

    private static boolean isWhole(double v) {
        return Math.abs(v - Math.rint(v)) < 1e-9;
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /** UI-only state of one setting row; its identity doubles as the drag owner. */
    private static final class SettingState {
        float knob = Float.NaN;
        TextBox field;
        final List<TextBox> items = new ArrayList<TextBox>();
        final Object svDrag = new Object();
        final Object hueDrag = new Object();
        final Object alphaDrag = new Object();
    }
}
