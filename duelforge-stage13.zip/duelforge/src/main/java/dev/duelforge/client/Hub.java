package dev.duelforge.client;

import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Menu hub: remembers which menu was used last and draws the LAB / CONTROLLER / STEPAN switch in every header. */
public final class Hub {
    public enum Menu { LAB, CONTROLLER, STEPAN }

    private static Menu current = Menu.LAB;

    private Hub() {}

    public static Menu current() { return current; }

    /** The old vanilla screens (BotScreen / ControllerScreen / StepanScreen) are replaced by one Expensive-style GUI (ExpaScreen). */
    public static Screen create(Menu menu) {
        current = menu;
        return new dev.duelforge.client.expa.ExpaScreen(switch (menu) {
            case LAB -> "launch";
            case CONTROLLER -> "controller";
            case STEPAN -> "sbattle";
        });
    }

    /** Opens the GUI at the section that was used last (Lab on first use). */
    public static void open() {
        Minecraft.getInstance().setScreen(create(current));
    }

    public static void open(Menu menu) {
        Minecraft.getInstance().setScreen(create(menu));
    }

    /** Three header buttons: [Лаб] [Контроллер] [Степан]. The active one is green. Header is 26 px high, buttons sit at py+4. */
    public static void addSwitch(Menu self, int px, int py, Consumer<AbstractWidget> adder) {
        adder.accept(Button.builder(label("Лаб", self == Menu.LAB), b -> { if (self != Menu.LAB) open(Menu.LAB); })
                .bounds(px + 66, py + 4, 50, 18).build());
        adder.accept(Button.builder(label("Контроллер", self == Menu.CONTROLLER), b -> { if (self != Menu.CONTROLLER) open(Menu.CONTROLLER); })
                .bounds(px + 118, py + 4, 76, 18).build());
        adder.accept(Button.builder(label("Степан", self == Menu.STEPAN), b -> { if (self != Menu.STEPAN) open(Menu.STEPAN); })
                .bounds(px + 196, py + 4, 56, 18).build());
    }

    private static Component label(String text, boolean active) {
        MutableComponent c = Component.literal(text);
        return active ? c.withStyle(ChatFormatting.GREEN) : c;
    }
}
