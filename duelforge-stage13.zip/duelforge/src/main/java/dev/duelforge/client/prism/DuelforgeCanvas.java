package dev.duelforge.client.prism;

import java.util.ArrayDeque;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import top.fpsmaster.prism.canvas.Canvas;
import top.fpsmaster.prism.canvas.FontHandle;
import top.fpsmaster.prism.canvas.ImageHandle;
import top.fpsmaster.prism.theme.Argb;

/**
 * Prism Canvas on top of GuiGraphics (Minecraft 1.21.11). Rounded shapes are drawn as 1px scanlines (no AA).
 * Structure follows FPSMaster Nova's NovaCanvas (MIT, FPSMaster Team), simplified: no shape atlas, no images.
 */
public final class DuelforgeCanvas implements Canvas {
    private final GuiGraphics g;
    private final Font font;
    private final ArrayDeque<Float> alpha = new ArrayDeque<>();
    private int clipDepth = 0;

    public DuelforgeCanvas(GuiGraphics g, Font font) {
        this.g = g;
        this.font = font;
        alpha.addLast(1f);
    }

    private int tint(int argb) { return Argb.mulAlpha(argb, alpha.getLast()); }

    private void rawFill(int x0, int y0, int x1, int y1, int argb) {
        if (x1 <= x0 || y1 <= y0 || Argb.alpha(argb) <= 2) return;
        g.fill(x0, y0, x1, y1, argb);
    }

    private void hline(float x0, float x1, int y, int argb) {
        int a = (int) Math.floor(Math.min(x0, x1));
        int b = (int) Math.ceil(Math.max(x0, x1));
        if (b > a) rawFill(a, y, b, y + 1, argb);
    }

    /** Horizontal span [left,right] of a rounded rect at scanline centre py, or null when outside. */
    private static float[] roundSpan(float py, float x, float y, float w, float h, float r) {
        if (py < y || py >= y + h) return null;
        float inset = 0f;
        if (r > 0.5f && py < y + r) {
            float dy = r - (py - y);
            float d = r * r - dy * dy;
            if (d <= 0f) return null;
            inset = r - (float) Math.sqrt(d);
        } else if (r > 0.5f && py > y + h - r) {
            float dy = r - (y + h - py);
            float d = r * r - dy * dy;
            if (d <= 0f) return null;
            inset = r - (float) Math.sqrt(d);
        }
        return new float[] {x + inset, x + w - inset};
    }

    @Override public void fillRect(float x, float y, float w, float h, int argb) {
        if (w <= 0f || h <= 0f) return;
        rawFill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), tint(argb));
    }

    @Override public void fillRoundRect(float x, float y, float w, float h, float radius, int argb) {
        if (w <= 0f || h <= 0f) return;
        float r = Math.max(0f, Math.min(radius, Math.min(w, h) * 0.5f));
        if (r < 0.5f) { fillRect(x, y, w, h, argb); return; }
        int color = tint(argb);
        int y0 = (int) Math.floor(y), y1 = (int) Math.ceil(y + h);
        for (int row = y0; row < y1; row++) {
            float[] span = roundSpan(row + 0.5f, x, y, w, h, r);
            if (span != null) hline(span[0], span[1], row, color);
        }
    }

    @Override public void strokeRoundRect(float x, float y, float w, float h, float radius, float strokeWidth, int argb) {
        if (w <= 0f || h <= 0f) return;
        float s = Math.max(strokeWidth, 0.6f);
        float r = Math.max(0f, Math.min(radius, Math.min(w, h) * 0.5f));
        int color = tint(argb);
        int y0 = (int) Math.floor(y - s * 0.15f), y1 = (int) Math.ceil(y + h + s * 0.15f);
        for (int row = y0; row < y1; row++) {
            float py = row + 0.5f;
            float[] outer = roundSpan(py, x, y, w, h, r);
            if (outer == null) continue;
            float[] inner = roundSpan(py, x + s, y + s, w - 2f * s, h - 2f * s, Math.max(0f, r - s));
            if (inner == null || w <= 2f * s || h <= 2f * s) {
                hline(outer[0], outer[1], row, color);
            } else {
                hline(outer[0], inner[0], row, color);
                hline(inner[1], outer[1], row, color);
            }
        }
    }

    @Override public void fillCircle(float cx, float cy, float radius, int argb) {
        int color = tint(argb);
        if (radius < 0.4f) {
            rawFill(Math.round(cx), Math.round(cy), Math.round(cx) + 1, Math.round(cy) + 1, color);
            return;
        }
        int y0 = (int) Math.floor(cy - radius), y1 = (int) Math.ceil(cy + radius);
        float r2 = radius * radius;
        for (int row = y0; row < y1; row++) {
            float dy = (row + 0.5f) - cy;
            float inner = r2 - dy * dy;
            if (inner <= 0f) continue;
            float dx = (float) Math.sqrt(inner);
            hline(cx - dx, cx + dx, row, color);
        }
    }

    @Override public void line(float x1, float y1, float x2, float y2, float width, int argb) {
        float hw = Math.max(width * 0.5f, 0.5f);
        float dx = x2 - x1, dy = y2 - y1;
        if (Math.abs(dx) < 0.35f) { fillRect(x1 - hw, Math.min(y1, y2) - hw, hw * 2f, Math.abs(dy) + hw * 2f, argb); return; }
        if (Math.abs(dy) < 0.35f) { fillRect(Math.min(x1, x2) - hw, y1 - hw, Math.abs(dx) + hw * 2f, hw * 2f, argb); return; }
        // diagonal: stamp small squares along the segment
        int color = tint(argb);
        int steps = Math.max(1, (int) Math.ceil(Math.sqrt(dx * dx + dy * dy) * 1.5f));
        int size = Math.max(1, Math.round(hw * 2f));
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            int px = Math.round(x1 + dx * t - size / 2f), py = Math.round(y1 + dy * t - size / 2f);
            rawFill(px, py, px + size, py + size, color);
        }
    }

    @Override public void fillGradientH(float x, float y, float w, float h, int left, int right) {
        int x0 = Math.round(x), x1 = Math.round(x + w), y0 = Math.round(y), y1 = Math.round(y + h);
        int n = x1 - x0;
        if (n <= 0 || y1 <= y0) return;
        for (int i = 0; i < n; i++) {
            float t = n == 1 ? 0f : i / (float) (n - 1);
            rawFill(x0 + i, y0, x0 + i + 1, y1, tint(lerp(left, right, t)));
        }
    }

    @Override public void fillGradientV(float x, float y, float w, float h, int top, int bottom) {
        int x0 = Math.round(x), x1 = Math.round(x + w), y0 = Math.round(y), y1 = Math.round(y + h);
        if (x1 <= x0 || y1 <= y0) return;
        g.fillGradient(x0, y0, x1, y1, tint(top), tint(bottom));
    }

    private static int lerp(int a, int b, float t) {
        int aa = (int) (Argb.alpha(a) + (Argb.alpha(b) - Argb.alpha(a)) * t);
        int rr = (int) (Argb.red(a) + (Argb.red(b) - Argb.red(a)) * t);
        int gg = (int) (Argb.green(a) + (Argb.green(b) - Argb.green(a)) * t);
        int bb = (int) (Argb.blue(a) + (Argb.blue(b) - Argb.blue(a)) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    @Override public void drawString(FontHandle handle, String text, float x, float y, int argb) {
        if (text == null || text.isEmpty()) return;
        float scale = handle instanceof DuelforgeFont df ? df.scale() : 1f;
        int color = tint(argb);
        if (Argb.alpha(color) <= 2) return;
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(x, y);
        if (Math.abs(scale - 1f) >= 0.01f) pose.scale(scale, scale);
        g.drawString(font, text, 0, 0, color, false);
        pose.popMatrix();
    }

    @Override public void drawImage(ImageHandle image, float x, float y, float w, float h, int tintArgb) {
        // Icons are not bundled: Prism's GlyphIcons falls back to vector shapes when host.image() is null.
    }

    @Override public void pushClip(float x, float y, float w, float h) {
        clipDepth++;
        g.enableScissor(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h));
    }

    @Override public void popClip() {
        if (clipDepth > 0) { clipDepth--; g.disableScissor(); }
    }

    @Override public void pushAlpha(float a) { alpha.addLast(alpha.getLast() * a); }

    @Override public void popAlpha() { if (alpha.size() > 1) alpha.removeLast(); }

    @Override public void pushTransform() { g.pose().pushMatrix(); }

    @Override public void popTransform() { g.pose().popMatrix(); }

    @Override public void translate(float x, float y) { g.pose().translate(x, y); }

    @Override public void scale(float s) { g.pose().scale(s, s); }
}
