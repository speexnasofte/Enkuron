package dev.duelforge.client;

import dev.duelforge.ai.Opts;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import dev.duelforge.vis.HudMath;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * HUD cards for the network ("Lab") bots in the look of Expensive's widgets: dark card with cut corners, tier-coloured edge, status dot,
 * smoothly animated health bar that goes accent -> yellow -> red, mode/state line and hit counter. Maths lives in {@link HudMath}.
 */
public final class LabHud {
    private static final int W = 150, H = 36, GAP = 4, MARGIN = 6;
    private static final Map<String, Float> SHOWN = new HashMap<>();
    private static long lastNanos = System.nanoTime();

    private LabHud() {}

    static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("duelforge", "lab_bots"), (g, tick) -> render(g));
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (!Opts.labHud || mc.options.hideGui || mc.level == null) return;
        long now = System.nanoTime();
        float dt = Math.min(0.25f, (now - lastNanos) / 1.0e9f);
        lastNanos = now;

        List<BotClient> bots = BotManager.INSTANCE.list().stream().filter(b -> b.status != BotClient.Status.STOPPED).toList();
        if (bots.isEmpty()) { SHOWN.clear(); return; }
        int[][] pos = HudMath.layout(bots.size(), g.guiWidth(), g.guiHeight(), Opts.labHudCorner, W, H, GAP, MARGIN);
        for (int i = 0; i < pos.length; i++) {
            BotClient b = bots.get(i);
            int x = pos[i][0], y = pos[i][1];
            float target = Math.max(0f, Math.min(1f, b.health() / 20f));
            float shown = HudMath.approach(SHOWN.getOrDefault(b.name, target), target, dt, 9f);
            SHOWN.put(b.name, shown);
            int edge = HudMath.tierColor(b.tier.ordinal(), dev.duelforge.ai.Tier.values().length);

            // card with cut corners
            g.fill(x + 1, y, x + W - 1, y + H, HudMath.CARD);
            g.fill(x, y + 1, x + W, y + H - 1, HudMath.CARD);
            g.fill(x, y + 3, x + 2, y + H - 3, edge);

            g.drawString(mc.font, Component.literal(HudMath.clip(b.name, 14)), x + 7, y + 4, HudMath.TEXT);
            String tier = b.tier.name();
            g.drawString(mc.font, Component.literal(tier), x + W - 16 - mc.font.width(tier), y + 4, edge);
            int dot = switch (b.status) {
                case PLAYING -> HudMath.OK;
                case KICKED, ERROR -> HudMath.ERROR;
                default -> HudMath.WARN;
            };
            g.fill(x + W - 11, y + 6, x + W - 7, y + 10, dot);

            // health bar
            int bx = x + 7, bw = W - 14;
            g.fill(bx, y + 16, bx + bw, y + 20, HudMath.TRACK);
            g.fill(bx, y + 16, bx + Math.round(bw * shown), y + 20, HudMath.hpColor(shown));

            g.drawString(mc.font, Component.literal(HudMath.clip(b.brainState(), 20)), x + 7, y + 24, HudMath.TEXT_DIM);
            String hits = b.hits() + " ударов";
            g.drawString(mc.font, Component.literal(hits), x + W - 7 - mc.font.width(hits), y + 24, HudMath.TEXT_DIM);
        }
    }
}
