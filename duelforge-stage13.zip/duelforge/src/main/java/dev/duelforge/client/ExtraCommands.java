package dev.duelforge.client;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.duelforge.ai.DuelManager;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.ai.Tier;
import dev.duelforge.net.BotManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * /botlab duel bots <ip> <nickA> <nickB> <tierA> <tierB> <mode> [firstTo]   two bots fight, score is kept
 * /botlab duel me <ip> <bot> <tier> <mode> [firstTo]                        a bot fights you
 * /botlab duel score | stop | rematch | reset | point <name> | firstto <n> | roundcmd <command|clear> | history
 * /botlab npc <ip> <nick|Name*N>      spawn passive NPC dummies with 99 totems in both hands
 * /botlab npc fight|armor <on|off> | npc totems <1..99>
 */
final class ExtraCommands {
    private ExtraCommands() {}

    private static int say(FabricClientCommandSource s, String msg) { DuelforgeClient.say(s, msg); return 1; }

    static String myName() {
        return Minecraft.getInstance().getUser().getName();
    }

    static void register(LiteralArgumentBuilder<FabricClientCommandSource> root) {
        LiteralArgumentBuilder<FabricClientCommandSource> duel = literal("duel");
        // bots <ip> <a> <b> <tierA> <tierB> <mode> [first]
        var botsMode = argument("mode", word())
                .executes(c -> duelBots(c.getSource(), getString(c, "ip"), getString(c, "a"), getString(c, "b"),
                        getString(c, "tierA"), getString(c, "tierB"), getString(c, "mode"), DuelManager.INSTANCE.firstTo))
                .then(argument("first", IntegerArgumentType.integer(1, 50))
                        .executes(c -> duelBots(c.getSource(), getString(c, "ip"), getString(c, "a"), getString(c, "b"),
                                getString(c, "tierA"), getString(c, "tierB"), getString(c, "mode"), IntegerArgumentType.getInteger(c, "first"))));
        var botsTierB = argument("tierB", word()).then(botsMode);
        var botsTierA = argument("tierA", word()).then(botsTierB);
        var botsB = argument("b", word()).then(botsTierA);
        var botsA = argument("a", word()).then(botsB);
        duel.then(literal("bots").then(argument("ip", StringArgumentType.string()).then(botsA)));

        // me <ip> <bot> <tier> <mode> [first]
        var meMode = argument("mode", word())
                .executes(c -> duelMe(c.getSource(), getString(c, "ip"), getString(c, "bot"), getString(c, "tier"), getString(c, "mode"), DuelManager.INSTANCE.firstTo))
                .then(argument("first", IntegerArgumentType.integer(1, 50))
                        .executes(c -> duelMe(c.getSource(), getString(c, "ip"), getString(c, "bot"), getString(c, "tier"), getString(c, "mode"), IntegerArgumentType.getInteger(c, "first"))));
        var meTier = argument("tier", word()).then(meMode);
        var meBot = argument("bot", word()).then(meTier);
        duel.then(literal("me").then(argument("ip", StringArgumentType.string()).then(meBot)));
        duel.then(literal("score").executes(c -> {
            DuelManager d = DuelManager.INSTANCE;
            say(c.getSource(), d.scoreLine() + (d.active ? "  · идёт" : d.winner.isEmpty() ? "" : "  · победил " + d.winner));
            for (String l : d.log().subList(Math.max(0, d.log().size() - 6), d.log().size())) say(c.getSource(), "  " + l);
            return 1;
        }));
        duel.then(literal("stop").executes(c -> { DuelManager.INSTANCE.stop(); return 1; }));
        duel.then(literal("rematch").executes(c -> { DuelManager.INSTANCE.rematch(); return 1; }));
        duel.then(literal("reset").executes(c -> { DuelManager.INSTANCE.reset(); return say(c.getSource(), "Дуэль сброшена.") ; }));
        duel.then(literal("point").then(argument("name", word()).executes(c -> { DuelManager.INSTANCE.point(getString(c, "name")); return 1; })));
        duel.then(literal("firstto").then(argument("n", IntegerArgumentType.integer(1, 50)).executes(c -> {
            DuelManager.INSTANCE.firstTo = IntegerArgumentType.getInteger(c, "n");
            return say(c.getSource(), "До " + DuelManager.INSTANCE.firstTo + " побед (для следующей дуэли).");
        })));
        duel.then(literal("roundcmd").then(argument("command", greedyString()).executes(c -> {
            String cmd = getString(c, "command");
            if (cmd.equalsIgnoreCase("clear")) DuelManager.INSTANCE.roundCommands.clear(); else DuelManager.INSTANCE.roundCommands.add(cmd);
            return say(c.getSource(), "Команды после каждого очка ({A} и {B} = имена): " + DuelManager.INSTANCE.roundCommands);
        })));
        duel.then(literal("history").executes(c -> {
            var h = DuelManager.INSTANCE.history();
            if (h.isEmpty()) return say(c.getSource(), "Сыгранных дуэлей ещё нет.");
            for (String l : h) say(c.getSource(), l);
            return h.size();
        }));
        root.then(duel);

        LiteralArgumentBuilder<FabricClientCommandSource> npc = literal("npc");
        npc.then(literal("fight").then(argument("v", word()).executes(c -> {
            Opts.npcFight = getString(c, "v").equalsIgnoreCase("on");
            return say(c.getSource(), "NPC бьёт в ответ кулаками: " + (Opts.npcFight ? "да" : "нет"));
        })));
        npc.then(literal("armor").then(argument("v", word()).executes(c -> {
            Opts.npcArmor = getString(c, "v").equalsIgnoreCase("on");
            return say(c.getSource(), "Незеритовая броня на новых NPC: " + (Opts.npcArmor ? "да" : "нет"));
        })));
        npc.then(literal("totems").then(argument("n", IntegerArgumentType.integer(1, 99)).executes(c -> {
            Opts.npcTotems = IntegerArgumentType.getInteger(c, "n");
            return say(c.getSource(), "Тотемов в каждой руке у новых NPC: " + Opts.npcTotems);
        })));
        npc.then(argument("ip", StringArgumentType.string()).executes(c -> spawnNpc(c.getSource(), getString(c, "ip"), "NPC"))
                .then(argument("nicks", StringArgumentType.string()).executes(c -> spawnNpc(c.getSource(), getString(c, "ip"), getString(c, "nicks")))));
        root.then(npc);
    }

    private static int spawnNpc(FabricClientCommandSource src, String ip, String nicks) {
        int n = BotManager.INSTANCE.spawnNpc(ip, nicks);
        return say(src, "NPC: " + n + " шт. → " + ip + ". Тотемы (" + Opts.npcTotems + " в каждой руке) выдаются командами /item replace: нужны права оператора"
                + (Opts.kitViaBots ? " у бота." : " у тебя.") + " Бьёт в ответ: " + (Opts.npcFight ? "да" : "нет"));
    }

    private static int duelBots(FabricClientCommandSource src, String ip, String a, String b, String tA, String tB, String mode, int first) {
        BotManager.INSTANCE.startDuelBots(ip, a, b, Tier.parse(tA), Tier.parse(tB), Mode.parse(mode), first);
        return say(src, "Дуэль ботов " + a + " (" + Tier.parse(tA) + ") vs " + b + " (" + Tier.parse(tB) + "), режим " + Mode.parse(mode) + ", до " + first
                + ". Счёт: /botlab duel score. Второй бот заходит через " + BotManager.INSTANCE.staggerMs + " мс.");
    }

    private static int duelMe(FabricClientCommandSource src, String ip, String bot, String tier, String mode, int first) {
        String me = myName();
        BotManager.INSTANCE.startDuelVsPlayer(ip, bot, Tier.parse(tier), Mode.parse(mode), first, me);
        return say(src, "Дуэль " + me + " vs бот " + bot + " (" + Tier.parse(tier) + ", " + Mode.parse(mode) + "), до " + first
                + ". Твои смерти бот определяет «на глаз», если счёт не сошёлся: /botlab duel point " + me);
    }
}
