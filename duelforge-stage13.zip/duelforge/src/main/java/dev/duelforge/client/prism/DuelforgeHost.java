package dev.duelforge.client.prism;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.Font;
import top.fpsmaster.prism.canvas.Canvas;
import top.fpsmaster.prism.canvas.FontHandle;
import top.fpsmaster.prism.canvas.ImageHandle;
import top.fpsmaster.prism.host.UiHost;
import top.fpsmaster.prism.input.FrameInput;
import top.fpsmaster.prism.input.Input;

/** Prism host for a Minecraft Screen. Size is the GUI-scaled screen size (1 Prism unit = 1 GUI unit). */
public final class DuelforgeHost implements UiHost {
    private final DuelforgeCanvas canvas;
    private final FrameInput input;
    private final Font font;
    private final float w, h;
    private final Map<Integer, DuelforgeFont> fonts = new HashMap<>();

    public DuelforgeHost(DuelforgeCanvas canvas, FrameInput input, Font font, float w, float h) {
        this.canvas = canvas;
        this.input = input;
        this.font = font;
        this.w = w;
        this.h = h;
    }

    @Override public Canvas canvas() { return canvas; }
    @Override public Input input() { return input; }
    @Override public FontHandle font(int size) { return fonts.computeIfAbsent(size, s -> new DuelforgeFont(font, s)); }
    @Override public float width() { return w; }
    @Override public float height() { return h; }
    @Override public long nowNanos() { return System.nanoTime(); }
    @Override public boolean blurEnabled() { return false; }
    @Override public void blurBehind(float x, float y, float w, float h, float radius) { }
    @Override public ImageHandle image(String id) { return null; }
}
