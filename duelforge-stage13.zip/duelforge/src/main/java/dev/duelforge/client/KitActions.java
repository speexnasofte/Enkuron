package dev.duelforge.client;

import dev.duelforge.ai.Kit;
import dev.duelforge.ai.KitStore;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Opts;
import dev.duelforge.net.BotManager;

/** Kit operations shared by the /botlab kit commands and the GUI. Every method returns a message for the user. */
final class KitActions {
    private KitActions() {}

    /** The kit the quick commands act on: the last one saved, loaded or picked. */
    static volatile String last = null;

    private static String nameOrLast(String n) { return n == null || n.isBlank() ? last : n; }

    static String save(String rawName) {
        String n = KitStore.sanitize(rawName == null ? "" : rawName);
        if (n.isEmpty()) {                                   // no name given: kit1, kit2, ...
            int i = 1;
            while (KitStore.get("kit" + i) != null) i++;
            n = "kit" + i;
        }
        Kit k = KitCapture.capture(n);
        if (k == null) return "Нет игрока: зайди в мир и повтори.";
        if (k.slots.isEmpty()) return "Инвентарь пуст, сохранять нечего.";
        Kit old = KitStore.get(n);
        k.mode = old != null && old.mode != null ? old.mode : k.guessMode();
        if (old != null) k.name = old.name;
        if (!KitStore.save(k)) return "Не удалось записать файл кита.";
        last = k.name;
        return "Кит «" + k.name + "» сохранён с тебя: " + k.summary() + ". Надеть: /botlab kit load, ботам: /botlab kit give";
    }

    static String load(String name) {
        name = nameOrLast(name);
        Kit k = KitStore.get(name);
        if (k == null) return name == null ? "Сначала сохрани кит: /botlab kit save" : "Кита «" + name + "» нет.";
        last = k.name;
        KitLoader.queue(k.commands("@s", true));
        return "Кит «" + k.name + "» грузится на тебя (" + (k.slots.size() + 1) + " команд). Нужны права оператора.";
    }

    static String give(String name, String bot) {
        name = nameOrLast(name);
        Kit k = KitStore.get(name);
        if (k == null) return name == null ? "Сначала сохрани кит: /botlab kit save" : "Кита «" + name + "» нет.";
        last = k.name;
        int n = BotManager.INSTANCE.applyKit(k, bot);
        if (n == 0) return "Нет подходящих ботов.";
        return "Кит «" + k.name + "» → " + n + " бот(ов), режим " + (k.mode == null ? "прежний" : k.mode.name())
                + (Opts.kitViaBots ? " (команды шлют сами боты)" : " (команды шлёшь ты, пауза " + Opts.kitDelay + " тик.)");
    }

    static String rename(String from, String to) {
        if (from == null) return "Выбери кит в списке.";
        return KitStore.rename(from, to) ? "Кит «" + from + "» теперь «" + KitStore.sanitize(to) + "»." : "Не вышло: нет такого кита или имя «" + to + "» занято.";
    }

    static String delete(String name) {
        if (name == null) return "Выбери кит в списке.";
        if (name.equalsIgnoreCase(Opts.selectedKit)) Opts.selectedKit = null;
        return KitStore.delete(name) ? "Кит «" + name + "» удалён." : "Кита «" + name + "» нет.";
    }

    static String setMode(String name, String mode) {
        Kit k = KitStore.get(name);
        if (k == null) return "Кита «" + name + "» нет.";
        k.mode = Mode.parse(mode);
        return KitStore.save(k) ? "Режим кита «" + k.name + "»: " + k.mode : "Не удалось записать файл кита.";
    }

    static String cycleMode(String name) {
        Kit k = KitStore.get(name);
        if (k == null) return "Выбери кит в списке.";
        Mode[] all = Mode.values();
        int next = k.mode == null ? 0 : (k.mode.ordinal() + 1) % all.length;
        if (all[next] == Mode.NPC) next = (next + 1) % all.length;      // NPC has its own tab, a kit never runs it
        k.mode = all[next];
        return KitStore.save(k) ? "Режим кита «" + k.name + "»: " + k.mode.label : "Не удалось записать файл кита.";
    }

    static String use(String name) {
        if (name == null || name.equalsIgnoreCase("none")) { Opts.selectedKit = null; return "Кит для запуска: нет (режим и хотбар по таблице)."; }
        Kit k = KitStore.get(name);
        if (k == null) return "Кита «" + name + "» нет.";
        Opts.selectedKit = k.name;
        return "Новые боты получат кит «" + k.name + "» (" + k.summary() + ").";
    }
}
