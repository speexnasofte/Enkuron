package dev.duelforge.client;

import com.mojang.authlib.GameProfile;
import dev.duelforge.ai.Kit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.TagParser;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Item icons and the 3D player model for the bot card. This is the only class that touches rendering entities and item
 * registries, so if a Minecraft version changes those APIs, fix or delete this file (and the two calls in BotScreen).
 * Needs a loaded world (the registries live there); in the main menu the card falls back to text.
 */
final class BotPreview {
    private BotPreview() {}

    private static final Map<String, ItemStack> ITEMS = new HashMap<>();
    private static final Map<String, RemotePlayer> MODELS = new HashMap<>();

    /** The item as a real stack (enchant glint, potion colour, ...), or null if it cannot be built. */
    static ItemStack stack(String item, int count) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || item == null || item.isEmpty()) return null;
        String key = item + "#" + count;
        ItemStack cached = ITEMS.get(key);
        if (cached == null) {
            ItemStack made = ItemStack.EMPTY;
            try {
                CompoundTag tag = TagParser.parseCompoundFully(Kit.stackSnbt(item, count));
                RegistryOps<Tag> ops = mc.level.registryAccess().createSerializationContext(NbtOps.INSTANCE);
                made = ItemStack.CODEC.parse(ops, tag).result().orElse(ItemStack.EMPTY);
            } catch (Exception ignored) { }
            ITEMS.put(key, made);
            cached = made;
        }
        return cached.isEmpty() ? null : cached;
    }

    /** One 18x18 inventory slot with the item icon and count (text fallback when no world is loaded). */
    static void slot(GuiGraphics g, Font font, int x, int y, String item, int count, boolean selected) {
        g.fill(x, y, x + 18, y + 18, selected ? 0xFF35E0A1 : 0xFF3A444F);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF1A2027);
        if (item == null || item.isEmpty()) return;
        ItemStack st = stack(item, count);
        if (st != null) {
            g.renderItem(st, x + 1, y + 1);
            g.renderItemDecorations(font, st, x + 1, y + 1);
        } else {
            String id = item.contains("[") ? item.substring(0, item.indexOf('[')) : item;
            id = id.substring(id.indexOf(':') + 1);
            g.drawString(font, id.length() > 3 ? id.substring(0, 3) : id, x + 2, y + 5, 0xFFE6EDF3);
            if (count > 1) g.drawString(font, String.valueOf(count), x + 2, y + 10, 0xFFF2C14E);
        }
    }

    /** Spinning-with-the-mouse 3D model of the bot wearing the kit's armor, offhand and first hotbar item. */
    static void model(GuiGraphics g, Font font, int x1, int y1, int x2, int y2, int mouseX, int mouseY, String name, Kit kit) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            g.drawString(font, "3D-модель: зайди в мир", x1 + 4, (y1 + y2) / 2, 0xFF8B98A5);
            return;
        }
        RemotePlayer p = MODELS.get(name);
        if (p == null || p.level() != level) {
            UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            p = new RemotePlayer(level, new GameProfile(id, name));
            MODELS.put(name, p);
        }
        wear(p, EquipmentSlot.HEAD, kit, "armor.head");
        wear(p, EquipmentSlot.CHEST, kit, "armor.chest");
        wear(p, EquipmentSlot.LEGS, kit, "armor.legs");
        wear(p, EquipmentSlot.FEET, kit, "armor.feet");
        wear(p, EquipmentSlot.OFFHAND, kit, "weapon.offhand");
        wear(p, EquipmentSlot.MAINHAND, kit, "hotbar.0");
        InventoryScreen.renderEntityInInventoryFollowsMouse(g, x1, y1, x2, y2, 55, 0.0625F, mouseX, mouseY, p);
    }

    private static void wear(RemotePlayer p, EquipmentSlot slot, Kit kit, String key) {
        Kit.Entry e = kit == null ? null : kit.slots.get(key);
        ItemStack st = e == null ? null : stack(e.item(), 1);
        p.setItemSlot(slot, st == null ? ItemStack.EMPTY : st);
    }
}
