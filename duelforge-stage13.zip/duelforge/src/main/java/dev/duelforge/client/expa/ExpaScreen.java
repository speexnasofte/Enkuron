package dev.duelforge.client.expa;

import dev.duelforge.client.UnifiedBridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import top.fpsmaster.prism.input.FrameInput;
import top.fpsmaster.prism.input.Keys;
import dev.duelforge.client.prism.DuelforgeCanvas;
import dev.duelforge.client.prism.DuelforgeHost;
import top.fpsmaster.prism.theme.Theme;
import top.fpsmaster.prism.widget.UiFrame;

/**
 * Duelforge GUI in the style of the "Expensive" client ({@link ExpaGui}), drawn through the Prism canvas
 * (FPSMaster Prism, MIT). Opens with /df, /df gui, the open-menu key or from the "Степан" menu.
 * Input forwarding follows FPSMaster Nova's ToolkitScreen.
 */
public final class ExpaScreen extends Screen {
    private static final boolean ON_MAC = System.getProperty("os.name", "").toLowerCase().startsWith("mac");

    private final FrameInput input = new FrameInput();
    private final ExpaGui gui;
    private final UnifiedBridge bridge;
    private double wheelRemainder = 0.0;

    public ExpaScreen() { this("launch"); }

    /** @param category first category to show: launch, bots, kits, modes, controller, sbattle, sutil */
    public ExpaScreen(String category) {
        super(Component.literal("Duelforge"));
        gui = new ExpaGui(category);
        input.setClipboardBackend(
                () -> Minecraft.getInstance().keyboardHandler.getClipboard(),
                text -> Minecraft.getInstance().keyboardHandler.setClipboard(text));
        bridge = new UnifiedBridge(() -> gui.beginClose());
    }

    @Override
    protected void init() { gui.onOpen(); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        input.setMouse(mouseX, mouseY);
        DuelforgeCanvas canvas = new DuelforgeCanvas(g, this.font);
        DuelforgeHost host = new DuelforgeHost(canvas, input, this.font, this.width, this.height);
        UiFrame ui = new UiFrame(host, Theme.of(UnifiedBridge.light, false));
        boolean done = gui.draw(ui, bridge);
        input.endFrame();
        if (done) onClose();
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        input.press(event.button(), (int) event.x(), (int) event.y());
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        input.release(event.button());
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT || key == GLFW.GLFW_KEY_RIGHT_SHIFT) input.setKeyDown(Keys.SHIFT, true);
        int shortcut = editShortcut(key, event.modifiers());
        if (shortcut != 0) {
            input.pressKey(shortcut);
            return true;
        }
        input.pressKey(mapKey(key));
        input.pressRawKey(key);
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (!gui.cancelKeyCapture()) gui.beginClose();
        }
        return true;
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        int key = event.key();
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT || key == GLFW.GLFW_KEY_RIGHT_SHIFT) input.setKeyDown(Keys.SHIFT, false);
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        String s = event.codepointAsString();
        if (!s.isEmpty() && !Character.isISOControl(s.charAt(0))) input.type(s);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY == 0.0) return true;
        if (wheelRemainder != 0.0 && (wheelRemainder > 0) != (scrollY > 0)) wheelRemainder = 0.0;
        wheelRemainder += scrollY;
        int steps = (int) wheelRemainder;
        if (steps != 0) {
            input.addWheel(steps);
            wheelRemainder -= steps;
        }
        return true;
    }

    private static int editShortcut(int glfw, int modifiers) {
        int primary = ON_MAC ? GLFW.GLFW_MOD_SUPER : GLFW.GLFW_MOD_CONTROL;
        if ((modifiers & primary) == 0) return 0;
        return switch (glfw) {
            case GLFW.GLFW_KEY_A -> Keys.SELECT_ALL;
            case GLFW.GLFW_KEY_C -> Keys.COPY;
            case GLFW.GLFW_KEY_X -> Keys.CUT;
            case GLFW.GLFW_KEY_V -> Keys.PASTE;
            default -> 0;
        };
    }

    private static int mapKey(int glfw) {
        return switch (glfw) {
            case GLFW.GLFW_KEY_HOME -> Keys.HOME;
            case GLFW.GLFW_KEY_END -> Keys.END;
            case GLFW.GLFW_KEY_BACKSPACE -> Keys.BACKSPACE;
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> Keys.ENTER;
            case GLFW.GLFW_KEY_ESCAPE -> Keys.ESCAPE;
            case GLFW.GLFW_KEY_LEFT -> Keys.LEFT;
            case GLFW.GLFW_KEY_RIGHT -> Keys.RIGHT;
            case GLFW.GLFW_KEY_DELETE -> Keys.DELETE;
            default -> glfw;
        };
    }
}
