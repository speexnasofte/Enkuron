package dev.duelforge.client;

import dev.duelforge.ai.Kit;
import dev.duelforge.ai.Mode;
import dev.duelforge.ai.Order;
import dev.duelforge.ai.RemoteKits;
import dev.duelforge.ai.Tier;
import dev.duelforge.net.BotClient;
import dev.duelforge.net.BotManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.HttpUtil;

/**
 * Controller for servers WITHOUT the mod: the same menu buttons (spawn / follow / attack / kits / tier) drive network bots
 * from the Lab. Also finds the address bots should join: the server you are on, or your singleplayer world opened to LAN
 * (switched to offline-mode so the bots can join without Minecraft accounts).
 */
final class RemoteControl {
    private RemoteControl() {}

    static final String TEAM = "ctl";
    static final int MAX = 4;
    /** Controller speed tier 1 (fastest) .. 5 (slowest) -> Lab tier for NEW bots. */
    static int speed = 2;
    static Mode mode = Mode.SWORD;
    /** Use network bots even where the server has the mod (singleplayer): smart AI instead of the simple entity. */
    static boolean forceNetwork = false;
    static String lastMessage = "";

    // ------------------------------------------------------------------ address

    /** What you typed, else the server you are on, else your world opened to LAN. Null when there is none. */
    static String resolveHost(String typed) {
        if (typed != null && !typed.isBlank()) return typed.trim();
        return currentAddress();
    }

    static String currentAddress() {
        Minecraft mc = Minecraft.getInstance();
        IntegratedServer srv = mc.getSingleplayerServer();
        if (srv != null) {
            if (!srv.isPublished()) {
                int port = HttpUtil.getAvailablePort();
                if (!srv.publishServer(srv.getDefaultGameType(), true, port)) {
                    say("Не удалось открыть мир для сети (LAN).");
                    return null;
                }
                srv.setUsesAuthentication(false);   // bots have no licensed accounts; this is your own LAN world
                say("Мир открыт для сети на порту " + srv.getPort() + " (offline-режим, чтобы боты могли зайти).");
            }
            return "127.0.0.1:" + srv.getPort();
        }
        ServerData sd = mc.getCurrentServer();
        return sd == null || sd.ip == null || sd.ip.isBlank() ? null : sd.ip;
    }

    static void say(String msg) {
        lastMessage = msg;
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> { if (mc.player != null) mc.player.displayClientMessage(Component.literal(msg), false); });
    }

    // ------------------------------------------------------------------ bots

    static List<BotClient> mine() {
        List<BotClient> out = new ArrayList<>();
        for (BotClient b : BotManager.INSTANCE.list()) if (TEAM.equals(b.team)) out.add(b);
        return out;
    }

    private static String owner() { return Minecraft.getInstance().getUser().getName(); }

    static Tier tierFor(int speed) {
        return switch (speed) { case 1 -> Tier.HT1; case 2 -> Tier.HT2; case 3 -> Tier.HT3; case 4 -> Tier.HT4; default -> Tier.HT5; };
    }

    private static String freeName() {
        for (int i = 1; i <= 99; i++) {
            String n = "DFBot" + i;
            boolean used = false;
            for (BotClient b : mine()) if (b.name.equalsIgnoreCase(n)) used = true;
            if (!used) return n;
        }
        return "DFBot";
    }

    /** One menu button. Returns a short status line for the screen. */
    static void handle(String action) {
        List<BotClient> bots = mine();
        if (action.startsWith("tier_")) {
            speed = action.charAt(action.length() - 1) - '0';
            say("Скорость " + speed + " = " + tierFor(speed) + ". Применится к новым ботам (уже запущенных пересоздай кнопками «Удалить» и «Создать»).");
            return;
        }
        Kit kit = RemoteKits.build(action);
        if (kit != null) {
            if (bots.isEmpty()) { say("Сначала создай бота."); return; }
            if (kit.mode != null) mode = kit.mode;
            for (BotClient b : bots) BotManager.INSTANCE.applyKit(kit, b.name);
            say("Кит выдан командами /item replace с твоего аккаунта (нужны права оператора). Режим ботов: " + mode.label + ".");
            return;
        }
        switch (action) {
            case "spawn" -> {
                if (bots.size() >= MAX) { say("Максимум " + MAX + " ботов."); return; }
                String host = currentAddress();
                if (host == null) { say("Зайди в мир или на сервер."); return; }
                BotManager.INSTANCE.joinControlled(host, freeName(), tierFor(speed), mode, TEAM, Order.IDLE, owner());
                say("Бот заходит на " + host + " (ник DFBot*). Если сервер в online-режиме, нужен аккаунт: /df account add");
            }
            case "follow" -> { for (BotClient b : bots) b.setOrder(Order.FOLLOW, owner()); say("Боты следуют за тобой."); }
            case "attack" -> { for (BotClient b : bots) b.setOrder(Order.FIGHT, owner()); say("Боты атакуют тебя."); }
            case "clear" -> { for (BotClient b : bots) b.setOrder(Order.IDLE, owner()); say("Боты стоят."); }
            case "despawn" -> { for (BotClient b : bots) BotManager.INSTANCE.leave(b.name); say("Боты удалены."); }
            default -> { }
        }
    }

    /** Status line per bot, for the menu. */
    static List<String> statusLines() {
        List<String> out = new ArrayList<>();
        for (BotClient b : mine()) {
            String s = b.name + ": " + b.status + (b.status == BotClient.Status.PLAYING ? " · " + b.order.name().toLowerCase() : "");
            if (!b.info.isEmpty() && b.status != BotClient.Status.PLAYING) s += " - " + b.info;
            out.add(s);
        }
        return out;
    }
}
