package dev.duelforge.client;

import dev.duelforge.ai.Opts;
import net.minecraft.client.Minecraft;

import java.util.ArrayDeque;
import java.util.List;

/** Sends commands from the real player, one every few ticks, so a big kit does not trip the server's chat-spam kick. */
final class KitLoader {
    private KitLoader() {}

    private static final ArrayDeque<String> QUEUE = new ArrayDeque<>();
    private static int cooldown;

    static synchronized void queue(List<String> commands) { QUEUE.addAll(commands); }

    static synchronized int pending() { return QUEUE.size(); }

    static synchronized void tick(Minecraft mc) {
        if (mc.player == null) { QUEUE.clear(); return; }
        if (cooldown > 0) { cooldown--; return; }
        String c = QUEUE.poll();
        if (c != null) {
            mc.player.connection.sendCommand(c);
            cooldown = Math.max(1, Opts.kitDelay);
        }
    }
}
