package dev.duelforge.client;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.duelforge.ai.Kit;
import dev.duelforge.ai.KitStore;
import dev.duelforge.ai.Layout;
import dev.duelforge.ai.Opts;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * /botlab kit save <name>            save what you carry (hotbar, inventory, armor, offhand)
 * /botlab kit load <name>            put the kit on yourself (clears you first)
 * /botlab kit give <name> [bot|all]  put the kit on live bots, switch them to its mode and hotbar layout
 * /botlab kit list | show <name> | rename <old> <new> | delete <name> | mode <name> <mode> | use <name|none>
 * /botlab kitdelay <ticks> | kitbots <on|off> | spear <reach> <cooldown>
 */
final class KitCommands {
    private KitCommands() {}

    private static int say(FabricClientCommandSource s, String msg) {
        s.sendFeedback(Component.literal(msg));
        return 1;
    }

    static void register(LiteralArgumentBuilder<FabricClientCommandSource> root) {
        LiteralArgumentBuilder<FabricClientCommandSource> kit = literal("kit");
        kit.then(literal("save").executes(c -> say(c.getSource(), KitActions.save(""))).then(argument("name", word()).executes(c -> say(c.getSource(), KitActions.save(getString(c, "name"))))));
        kit.then(literal("load").executes(c -> say(c.getSource(), KitActions.load(null))).then(argument("name", word()).executes(c -> say(c.getSource(), KitActions.load(getString(c, "name"))))));
        kit.then(literal("give").executes(c -> say(c.getSource(), KitActions.give(null, "all"))).then(argument("name", word())
                .executes(c -> say(c.getSource(), KitActions.give(getString(c, "name"), "all")))
                .then(argument("bot", word()).executes(c -> say(c.getSource(), KitActions.give(getString(c, "name"), getString(c, "bot")))))));
        kit.then(literal("list").executes(c -> {
            var names = KitStore.names();
            if (names.isEmpty()) return say(c.getSource(), "Китов нет. /botlab kit save <имя> сохранит твой инвентарь.");
            for (String n : names) {
                Kit k = KitStore.get(n);
                say(c.getSource(), (n.equalsIgnoreCase(Opts.selectedKit) ? "* " : "  ") + n + " - " + (k == null ? "?" : k.summary()));
            }
            return names.size();
        }));
        kit.then(literal("show").then(argument("name", word()).executes(c -> {
            Kit k = KitStore.get(getString(c, "name"));
            if (k == null) return say(c.getSource(), "Кита нет.");
            say(c.getSource(), k.name + ": " + k.summary());
            say(c.getSource(), "раскладка бота: " + Layout.detect(k.mode == null ? k.guessMode() : k.mode, k.hotbarItems()).describe());
            String[] h = k.hotbarItems();
            for (int i = 0; i < 9; i++) if (!h[i].isEmpty()) say(c.getSource(), "  " + (i + 1) + ": " + (h[i].length() > 90 ? h[i].substring(0, 90) + "..." : h[i]));
            return 1;
        })));
        kit.then(literal("rename").then(argument("old", word()).then(argument("new", word())
                .executes(c -> say(c.getSource(), KitActions.rename(getString(c, "old"), getString(c, "new")))))));
        kit.then(literal("delete").then(argument("name", word()).executes(c -> say(c.getSource(), KitActions.delete(getString(c, "name"))))));
        kit.then(literal("mode").then(argument("name", word()).then(argument("mode", word())
                .executes(c -> say(c.getSource(), KitActions.setMode(getString(c, "name"), getString(c, "mode")))))));
        kit.then(literal("use").then(argument("name", word()).executes(c -> say(c.getSource(), KitActions.use(getString(c, "name"))))));
        root.then(kit);

        root.then(literal("diag").executes(c -> {
            var bots = dev.duelforge.net.BotManager.INSTANCE.list();
            if (bots.isEmpty()) return say(c.getSource(), "Ботов нет.");
            int shown = 0;
            for (var b : bots) {
                if (b.status != dev.duelforge.net.BotClient.Status.PLAYING) continue;
                say(c.getSource(), b.name + " [" + b.tier + " " + b.mode + "] hp " + Math.round(b.health()) + ": " + b.diag());
                if (++shown >= 12) { say(c.getSource(), "... ещё " + (bots.size() - shown)); break; }
            }
            return shown;
        }));
        root.then(literal("kitdelay").then(argument("ticks", IntegerArgumentType.integer(1, 40)).executes(c -> {
            Opts.kitDelay = IntegerArgumentType.getInteger(c, "ticks");
            return say(c.getSource(), "Пауза между командами кита: " + Opts.kitDelay + " тик.");
        })));
        root.then(literal("kitbots").then(argument("v", word()).executes(c -> {
            Opts.kitViaBots = getString(c, "v").equalsIgnoreCase("on");
            return say(c.getSource(), "Кит грузят " + (Opts.kitViaBots ? "сами боты (они должны быть оп)" : "твои команды"));
        })));
        root.then(literal("spear").then(argument("reach", DoubleArgumentType.doubleArg(2.0, 6.0))
                .then(argument("cooldown", IntegerArgumentType.integer(4, 40)).executes(c -> {
                    Opts.spearReach = DoubleArgumentType.getDouble(c, "reach");
                    Opts.spearCooldown = IntegerArgumentType.getInteger(c, "cooldown");
                    return say(c.getSource(), "Копьё: дальность " + Opts.spearReach + ", пауза " + Opts.spearCooldown + " тик.");
                }))));
    }
}
