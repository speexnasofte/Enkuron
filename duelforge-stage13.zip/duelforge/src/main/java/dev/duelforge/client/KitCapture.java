package dev.duelforge.client;

import dev.duelforge.ai.Kit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Reads what the real player carries (hotbar, inventory, armor, offhand) into a {@link Kit}. */
final class KitCapture {
    private KitCapture() {}

    /** @return the kit, or null when there is no player (not in a world). */
    static Kit capture(String name) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return null;
        RegistryOps<Tag> ops = p.registryAccess().createSerializationContext(NbtOps.INSTANCE);
        Kit k = new Kit(name);
        Inventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) put(k, "hotbar." + i, inv.getItem(i), ops);
        for (int i = 9; i < 36; i++) put(k, "inventory." + (i - 9), inv.getItem(i), ops);
        put(k, "armor.head", p.getItemBySlot(EquipmentSlot.HEAD), ops);
        put(k, "armor.chest", p.getItemBySlot(EquipmentSlot.CHEST), ops);
        put(k, "armor.legs", p.getItemBySlot(EquipmentSlot.LEGS), ops);
        put(k, "armor.feet", p.getItemBySlot(EquipmentSlot.FEET), ops);
        put(k, "weapon.offhand", p.getItemBySlot(EquipmentSlot.OFFHAND), ops);
        return k;
    }

    private static void put(Kit k, String slot, ItemStack st, RegistryOps<Tag> ops) {
        if (st == null || st.isEmpty()) return;
        Tag tag = ItemStack.CODEC.encodeStart(ops, st).result().orElse(null);
        if (tag == null) return;
        Kit.Entry e = Kit.fromSnbt(tag.toString());      // {id, count, components} printed as SNBT -> "id[component=value]"
        if (e != null) k.slots.put(slot, e);
    }
}
