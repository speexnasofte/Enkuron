package dev.duelforge.ai;

/**
 * Maps a block-state id (as sent in chunk packets) to a coarse class the AI cares about. The table is built at client
 * start from the game's own block registry (client/BlockTableBuilder), so the ids always match the protocol version
 * the bot speaks. Without a table (tests, headless) only id 0 = air is known and everything else counts as a full block.
 */
public final class BlockTable {
    private BlockTable() {}

    public static final byte AIR = 0;
    /** Full 1x1x1 collision cube (stone, planks ...). */
    public static final byte FULL = 1;
    /** Has collision but is not a full cube (slab, stairs, fence ...). Treated as "unknown shape": never blocks the bot's physics. */
    public static final byte PARTIAL = 2;
    public static final byte WATER = 3;
    public static final byte LAVA = 4;
    public static final byte WEB = 5;
    public static final byte FIRE = 6;
    /** Not air, no collision (grass, flowers, buttons, rails ...). */
    public static final byte PLANT = 7;
    /** Obsidian / bedrock: full cube and a valid end-crystal base. */
    public static final byte OBSIDIAN = 8;

    private static volatile byte[] table;

    public static void set(byte[] t) { table = t; }
    public static boolean ready() { return table != null; }

    public static byte classOf(int stateId) {
        byte[] t = table;
        if (t == null) return stateId == 0 ? AIR : FULL;
        return stateId >= 0 && stateId < t.length ? t[stateId] : FULL;
    }

    /** Blocks movement and explosion rays. */
    public static boolean isFull(int cls) { return cls == FULL || cls == OBSIDIAN; }
}
