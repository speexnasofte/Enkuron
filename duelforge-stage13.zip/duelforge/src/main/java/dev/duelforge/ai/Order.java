package dev.duelforge.ai;

/** What a bot is told to do by its owner (Controller menu). FIGHT is the normal PvP behaviour. */
public enum Order {
    /** Normal PvP: attack the nearest enemy (or only {@code focus} if one is set). */
    FIGHT,
    /** Walk after the owner and keep close, no attacks. */
    FOLLOW,
    /** Stand still. */
    IDLE
}
