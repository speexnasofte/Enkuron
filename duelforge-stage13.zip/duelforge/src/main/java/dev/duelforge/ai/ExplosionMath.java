package dev.duelforge.ai;

/**
 * End-crystal damage model (ported from Expensive's ExplosionDamageUtil, rewritten without Minecraft classes).
 * The bot does not parse chunks, so exposure is taken as 1.0 (open arena floor); distance, armor, toughness and
 * enchantment protection follow vanilla (CombatRules.getDamageAfterAbsorb + EnchantmentHelper protection).
 */
public final class ExplosionMath {
    private ExplosionMath() {}

    /** Crystal explosion power 6 -> diameter 12 blocks. */
    public static final double DIAMETER = 12.0;

    /** Armor values of one wearer: defense points, toughness, protection "EPF" against explosions (cap 20), resistance level (0 = none). */
    public record Armor(double armor, double toughness, double epf, int resistance) {
        public static final Armor NONE = new Armor(0, 0, 0, 0);
        /** Full netherite with Protection IV: what the bot assumes about an enemy it cannot inspect. */
        public static final Armor NETHERITE_P4 = new Armor(20, 12, 16, 0);
        public static final Armor DIAMOND_P4 = new Armor(20, 8, 16, 0);

        /** Reads armor.head/chest/legs/feet from a kit; unknown kit -> NONE. */
        public static Armor fromKit(Kit k) {
            if (k == null) return NONE;
            double armor = 0, tough = 0, epf = 0;
            for (String part : new String[]{"head", "chest", "legs", "feet"}) {
                Kit.Entry e = k.slots.get("armor." + part);
                if (e == null) continue;
                String id = e.item();
                String mat = material(id);
                if (mat == null) continue;
                armor += points(mat, part);
                tough += switch (mat) { case "netherite" -> 3; case "diamond" -> 2; default -> 0; };
                epf += Math.max(level(id, "blast_protection") * 2, level(id, "protection"));
            }
            return new Armor(armor, tough, Math.min(20, epf), 0);
        }

        public Armor withResistance(int level) { return new Armor(armor, toughness, epf, level); }
    }

    private static String material(String id) {
        for (String m : new String[]{"netherite", "diamond", "iron", "chainmail", "golden", "leather", "turtle"})
            if (id.contains(m + "_") || id.contains(":" + m)) return m;
        return null;
    }

    private static int points(String mat, String part) {
        int i = switch (part) { case "head" -> 0; case "chest" -> 1; case "legs" -> 2; default -> 3; };
        int[] v = switch (mat) {
            case "netherite", "diamond" -> new int[]{3, 8, 6, 3};
            case "iron" -> new int[]{2, 6, 5, 2};
            case "chainmail" -> new int[]{2, 5, 4, 1};
            case "golden" -> new int[]{2, 5, 3, 1};
            case "leather" -> new int[]{1, 3, 2, 1};
            default -> new int[]{2, 0, 0, 0};          // turtle shell helmet
        };
        return v[i];
    }

    /** Enchantment level written in a kit item string, e.g. "blast_protection:4" (plain "protection" must not match blast_/fire_/projectile_). */
    private static int level(String id, String ench) {
        int from = 0;
        while (true) {
            int i = id.indexOf(ench + ":", from);
            if (i < 0) return 0;
            boolean plainOk = !ench.equals("protection") || i == 0 || !(Character.isLetter(id.charAt(i - 1)) || id.charAt(i - 1) == '_');
            if (plainOk) {
                int j = i + ench.length() + 1, e = j;
                while (e < id.length() && Character.isDigit(id.charAt(e))) e++;
                try { return Integer.parseInt(id.substring(j, e)); } catch (NumberFormatException ex) { return 0; }
            }
            from = i + 1;
        }
    }

    /** Damage after armor, protection and resistance (no absorption, normal difficulty). */
    public static double afterArmor(double raw, Armor a) {
        if (raw <= 0) return 0;
        double f = 2.0 + a.toughness() / 4.0;
        double g = Math.min(20.0, Math.max(a.armor() * 0.2, a.armor() - raw / f));
        double d = raw * (1.0 - g / 25.0);
        d *= 1.0 - Math.min(20.0, a.epf()) / 25.0;
        if (a.resistance() > 0) d *= Math.max(0, 1.0 - 0.2 * a.resistance());
        return Math.max(0, d);
    }

    /** Damage an end crystal exploding at (cx,cy,cz) does to something standing with its feet at (ex,ey,ez). */
    public static double crystal(Armor a, double cx, double cy, double cz, double ex, double ey, double ez) {
        return crystal(a, cx, cy, cz, ex, ey, ez, 1.0);
    }

    public static double crystal(Armor a, double cx, double cy, double cz, double ex, double ey, double ez, double exposure) {
        double dist = Math.sqrt((cx - ex) * (cx - ex) + (cy - ey) * (cy - ey) + (cz - ez) * (cz - ez));
        double ratio = dist / DIAMETER;
        if (ratio > 1.0) return 0;
        double impact = (1.0 - ratio) * exposure;
        double raw = (impact * impact + impact) / 2.0 * 7.0 * DIAMETER + 1.0;
        return afterArmor(raw, a);
    }

    /** Ground distance from a crystal at which damage to a wearer of this armor drops below the given amount. */
    public static double safeRadius(Armor a, double below) {
        for (double d = 0.5; d < DIAMETER; d += 0.25) if (crystal(a, 0, 0, 0, d, 0, 0) < below) return d;
        return DIAMETER;
    }
}
