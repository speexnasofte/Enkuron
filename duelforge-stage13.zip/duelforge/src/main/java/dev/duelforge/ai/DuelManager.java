package dev.duelforge.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Duel score keeper. Two sides (bot vs bot, or a bot vs you) play "first to N". Every death gives the other side a point.
 * Bot deaths are exact (the server sends health 0). Your own deaths are not announced to a bot, so the connection reports
 * them with a heuristic (the bot hit you a moment ago and you vanished next to it) - the menu has a manual +1 for the rest.
 * Pure Java: the client mod plugs in {@link #announce} (chat) and {@link #sender} (commands sent from your client).
 */
public final class DuelManager {
    public static final DuelManager INSTANCE = new DuelManager();

    public static final class Side {
        public final String name;
        public final boolean bot;
        public int score, streak, best;
        long lastLoss;

        Side(String name, boolean bot) { this.name = name; this.bot = bot; }
    }

    private Side a, b;
    public volatile boolean active;
    public volatile int firstTo = 5;
    public volatile String winner = "";
    private long startedAt, endedAt;
    private final List<String> log = new CopyOnWriteArrayList<>();
    private final List<String> history = new CopyOnWriteArrayList<>();

    /** Text for the player's chat (set by the client mod). */
    public volatile Consumer<String> announce = s -> { };
    /** Sends commands from the player's client (set by the client mod). */
    public volatile Consumer<List<String>> sender = c -> { };
    /** Commands run after every point, {A} and {B} are replaced by the two names (e.g. "tp {A} 0 64 8"). */
    public final List<String> roundCommands = new CopyOnWriteArrayList<>();
    public volatile int roundDelayMs = 2500;
    /** Ignore a second death of the same side inside this window (death packet + removal heuristic). */
    static final long LOSS_WINDOW_MS = 1500;

    private final ScheduledExecutorService sched = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "botlab-duel"); t.setDaemon(true); return t;
    });

    private DuelManager() { }

    // ------------------------------------------------------------------ control

    public synchronized void start(String aName, boolean aBot, String bName, boolean bBot, int target) {
        a = new Side(aName, aBot);
        b = new Side(bName, bBot);
        firstTo = Math.max(1, Math.min(50, target));
        winner = "";
        active = true;
        startedAt = System.currentTimeMillis(); endedAt = 0;
        log.clear();
        say("Дуэль: " + aName + " vs " + bName + ", до " + firstTo + " побед");
    }

    public synchronized void stop() {
        if (a == null) return;
        if (active) { active = false; endedAt = System.currentTimeMillis(); say("Дуэль остановлена: " + scoreLine()); }
    }

    /** Zero the score and start a new match with the same two sides. */
    public synchronized void rematch() {
        if (a == null) return;
        start(a.name, a.bot, b.name, b.bot, firstTo);
    }

    public synchronized void reset() { a = null; b = null; active = false; winner = ""; log.clear(); }

    // ------------------------------------------------------------------ events

    /** A bot died (set_health <= 0). */
    public synchronized void onDeath(String name) { lose(name, "погиб"); }

    /** The connection of {@code bot} saw {@code player} vanish right after fighting him. */
    public synchronized void onPlayerLost(String player, String bot) {
        if (!active || a == null) return;
        Side s = side(player);
        if (s != null && !s.bot) lose(player, "убит ботом " + bot);
    }

    /** Manual point (menu button or command). */
    public synchronized void point(String name) {
        if (!active || a == null) return;
        Side s = side(name);
        if (s != null) award(s, "ручное очко");
    }

    private void lose(String name, String how) {
        if (!active || a == null) return;
        Side dead = side(name);
        if (dead == null) return;
        long now = System.currentTimeMillis();
        if (now - dead.lastLoss < LOSS_WINDOW_MS) return;
        dead.lastLoss = now;
        dead.streak = 0;
        award(dead == a ? b : a, dead.name + " " + how);
    }

    private void award(Side s, String why) {
        s.score++; s.streak++; s.best = Math.max(s.best, s.streak);
        Side o = s == a ? b : a;
        o.streak = 0;
        String line = "Раунд " + (a.score + b.score) + ": " + why + " → " + s.name + "  " + a.score + ":" + b.score;
        say(line);
        if (s.score >= firstTo) {
            active = false; endedAt = System.currentTimeMillis(); winner = s.name;
            String res = "Победил " + s.name + "  " + a.name + " " + a.score + ":" + b.score + " " + b.name
                    + "  (" + (endedAt - startedAt) / 1000 + " с, лучшая серия " + Math.max(a.best, b.best) + ")";
            history.add(0, res);
            while (history.size() > 8) history.remove(history.size() - 1);
            say(res);
            return;
        }
        if (!roundCommands.isEmpty()) {
            List<String> cmds = new ArrayList<>();
            for (String c : roundCommands) cmds.add(c.replace("{A}", a.name).replace("{B}", b.name));
            sched.schedule(() -> sender.accept(cmds), Math.max(0, roundDelayMs), TimeUnit.MILLISECONDS);
        }
    }

    private void say(String m) {
        log.add(m);
        while (log.size() > 40) log.remove(0);
        try { announce.accept("[Дуэль] " + m); } catch (RuntimeException ignored) { }
    }

    // ------------------------------------------------------------------ read access

    private Side side(String name) {
        if (a != null && a.name.equalsIgnoreCase(name)) return a;
        if (b != null && b.name.equalsIgnoreCase(name)) return b;
        return null;
    }

    /** True while a match runs and {@code name} is the human side (the connections watch for it). */
    public synchronized boolean watchesPlayer(String name) {
        if (!active || a == null) return false;
        Side s = side(name);
        return s != null && !s.bot;
    }

    public synchronized boolean involves(String name) { return side(name) != null; }

    public synchronized boolean has() { return a != null; }
    public synchronized String nameA() { return a == null ? "" : a.name; }
    public synchronized String nameB() { return b == null ? "" : b.name; }
    public synchronized int scoreA() { return a == null ? 0 : a.score; }
    public synchronized int scoreB() { return b == null ? 0 : b.score; }
    public synchronized int streakA() { return a == null ? 0 : a.streak; }
    public synchronized int streakB() { return b == null ? 0 : b.streak; }

    public synchronized String scoreLine() {
        return a == null ? "дуэли нет" : a.name + " " + a.score + ":" + b.score + " " + b.name + " (до " + firstTo + ")";
    }

    public List<String> log() { return List.copyOf(log); }

    public List<String> history() { return List.copyOf(history); }
}
