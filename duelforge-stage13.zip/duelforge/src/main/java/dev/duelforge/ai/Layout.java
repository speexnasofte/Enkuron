package dev.duelforge.ai;

import java.util.Locale;
import java.util.function.Predicate;

/**
 * Maps the bot's logical hotbar roles (Brain.S_*) to real hotbar slots. Built from a kit, so bots use the layout the
 * kit was saved with instead of a fixed one. Roles the kit does not contain keep their default slot.
 */
public final class Layout {
    public static final Layout DEFAULT = new Layout(new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8});

    private final int[] map;

    private Layout(int[] map) { this.map = map; }

    public int map(int logical) { return logical >= 0 && logical < 9 ? map[logical] : logical; }

    public String describe() {
        String[] n = {"оружие", "осн.2", "еда", "осн.3", "осн.4", "осн.5", "осн.6", "жемчуг", "тотем"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) if (map[i] != i) sb.append(n[i]).append("→").append(map[i] + 1).append(' ');
        return sb.length() == 0 ? "стандартная" : sb.toString().trim();
    }

    private static String id(String s) { int b = s.indexOf('['); return (b < 0 ? s : s.substring(0, b)).toLowerCase(Locale.ROOT); }

    private static Predicate<String> idIs(String full) { return s -> id(s).equals(full); }

    private static Predicate<String> idHas(String part) { return s -> id(s).contains(part); }

    private static Predicate<String> splash(String effect) {
        return s -> id(s).contains("splash_potion") && s.toLowerCase(Locale.ROOT).contains(effect);
    }

    private static boolean assign(int[] m, String[] h, boolean[] used, int logical, Predicate<String> p) {
        if (p == null) return false;
        for (int i = 0; i < 9; i++) {
            if (!used[i] && !h[i].isEmpty() && p.test(h[i])) { m[logical] = i; used[i] = true; return true; }
        }
        return false;
    }

    public static Layout detect(Mode mode, String[] hotbar) {
        int[] m = {0, 1, 2, 3, 4, 5, 6, 7, 8};
        String[] h = new String[9];
        for (int i = 0; i < 9; i++) h[i] = hotbar != null && i < hotbar.length && hotbar[i] != null ? hotbar[i] : "";
        boolean[] used = new boolean[9];

        Predicate<String> weapon = switch (mode) {
            case AXE -> s -> id(s).contains("_axe") && !id(s).contains("pickaxe");
            case MACE, MACE_PRO, ROCKET_MACE -> idHas("mace");
            case SPEAR -> idHas("_spear");
            case MIXED -> null;
            default -> idHas("_sword");
        };
        assign(m, h, used, 0, weapon);

        Predicate<String> second = null, third = null, fourth = null, fifth = null, sixth = null;
        switch (mode) {
            case CRYSTAL -> { second = idIs("minecraft:end_crystal"); third = idIs("minecraft:obsidian"); }
            case ANCHOR -> { second = idIs("minecraft:respawn_anchor"); third = idIs("minecraft:glowstone"); }
            case MACE, MACE_PRO -> second = idIs("minecraft:wind_charge");
            case ROCKET_MACE, ELYTRA -> second = idIs("minecraft:firework_rocket");
            case SMP, DIAMOND_SMP -> { second = splash("healing"); third = splash("harming"); fourth = splash("swiftness"); fifth = splash("strength"); }
            case POT, NETHPOT -> { second = splash("healing"); third = splash("harming"); fourth = splash("swiftness"); fifth = splash("strength"); }
            case BOW -> second = idIs("minecraft:bow");
            case UHC -> { second = idIs("minecraft:bow"); third = idHas("cobweb"); fourth = idIs("minecraft:lava_bucket"); fifth = idIs("minecraft:flint_and_steel"); sixth = idHas("bucket"); }
            case TRAPPER -> { third = idHas("cobweb"); fourth = idIs("minecraft:lava_bucket"); fifth = idIs("minecraft:flint_and_steel"); sixth = idHas("bucket"); }
            case CROSSBOW -> second = idIs("minecraft:crossbow");
            case TRIDENT -> second = idIs("minecraft:trident");
            case AXE_SWORD -> second = s -> id(s).contains("_axe") && !id(s).contains("pickaxe");
            case CART -> { second = s -> id(s).endsWith("rail"); third = idIs("minecraft:tnt_minecart"); fourth = idIs("minecraft:flint_and_steel"); }
            default -> { }
        }
        assign(m, h, used, 1, second);
        assign(m, h, used, 3, third);
        assign(m, h, used, 4, fourth);
        assign(m, h, used, 5, fifth);
        assign(m, h, used, 6, sixth);
        assign(m, h, used, 2, s -> id(s).endsWith("golden_apple"));
        assign(m, h, used, 7, idIs("minecraft:ender_pearl"));
        assign(m, h, used, 8, idIs("minecraft:totem_of_undying"));
        return new Layout(m);
    }
}
