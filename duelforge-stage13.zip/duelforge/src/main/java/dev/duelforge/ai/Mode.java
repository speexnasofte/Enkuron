package dev.duelforge.ai;

import java.util.Locale;

/**
 * PvP style. The server kit must provide the hotbar described by {@link #kit}.
 * Slots in the description are 1-based (as in game); code uses 0-based.
 */
public enum Mode {
    SWORD("Меч", "1 меч · 3 золотое яблоко · 9 тотем"),
    AXE("Топор", "1 топор · 3 золотое яблоко · 9 тотем"),
    SMP("SMP", "1 меч · 2 взрывное лечение (опц.) · 3 золотое яблоко · 4 взрывная скорость (опц.) · 5 взрывная сила (опц.) · 9 тотем; поты + яблоки, отходит при низком HP"),
    DIAMOND_SMP("Diamond SMP", "как SMP, кит в алмазной броне: 1 меч · 2 взрывное лечение · 3 яблоко · 4 скорость · 5 сила · 9 тотем"),
    CRYSTAL("Кристаллы", "1 меч · 2 кристаллы · 3 золотое яблоко · 4 обсидиан · 9 тотем"),
    ANCHOR("Якорь", "1 меч · 2 якорь возрождения · 3 яблоко · 4 светокамень · 9 тотем (Обычный мир / Энд)"),
    MACE("Булава", "1 булава · 2 ветряные заряды · 3 яблоко"),
    MACE_PRO("Булава+", "1 булава (лучше с Wind Burst) · 2 ветряные заряды · 3 яблоко · 9 тотем (запуск с земли или прыжком, упреждение при падении, цепочка Wind Burst)"),
    ROCKET_MACE("Ракета+булава", "1 булава · 2 фейерверки · 3 яблоко · элитры надеты"),
    ELYTRA("Элитры", "1 меч · 2 фейерверки · 3 яблоко · элитры надеты"),
    POT("Поты", "1 меч · 2 взрывное лечение · 4 взрывной вред (опц.) · 9 тотем"),
    BOW("Лук", "1 меч · 2 лук (+стрелы в инвентаре) · 3 яблоко"),
    CROSSBOW("Арбалет", "1 меч · 2 арбалет (+стрелы) · 3 яблоко"),
    TRIDENT("Трезубец", "1 меч · 2 трезубец с Верностью · 3 яблоко"),
    PEARL("Жемчуг", "1 меч · 3 яблоко · 8 жемчуг Края · 9 тотем"),
    CART("Карт", "1 меч · 2 рельсы · 3 яблоко · 4 TNT-вагонетка · 5 огниво (взрыв через ~4 с после поджога)"),
    UHC("UHC", "1 меч · 2 лук (+стрелы) · 3 яблоко · 4 паутина · 5 ведро лавы · 6 огниво · 7 пустое ведро; ловушки + лук с 12+ блоков, меч вблизи"),
    TRAPPER("Ловушки", "1 меч · 3 яблоко · 4 паутина · 5 ведро лавы · 6 огниво · 7 пустое ведро · 9 тотем (паутина под врага, лава, огонь, воровство воды; без лука)"),
    SHIELD("Щит", "1 меч · 3 яблоко · щит в левой руке (блок между ударами)"),
    NETHPOT("Незер-поты", "1 меч · 2 взрывное лечение · 5 взрывная скорость · 6 взрывная сила · 9 тотем"),
    SPEAR("Копьё", "1 копьё · 3 золотое яблоко · 9 тотем (бьёт издалека, дальность: /botlab spear)"),
    AXE_SWORD("Топор+меч", "1 меч · 2 топор · 3 яблоко · 9 тотем (топор-опенер: заряжен к контакту, потом меч)"),
    PRESSURE("Прессинг", "1 меч · 3 золотое яблоко · 9 тотем (давит без остановки: все комбо, мало стрейфа)"),
    NPC("NPC", "ничего не нужно: стоит и смотрит на игрока, 99 тотемов в обеих руках (вкладка NPC)"),
    MIXED("Микс", "случайный режим на каждый респавн (кит должен подходить всем)");

    public final String label;
    public final String kit;

    Mode(String label, String kit) { this.label = label; this.kit = kit; }

    public boolean ranged() { return this == BOW || this == CROSSBOW || this == TRIDENT; }

    /** MCTiers-style names that map onto the modes above. */
    private static Mode alias(String u) {
        return switch (u) {
            case "VANILLA", "CPVP", "CRYSTALPVP" -> CRYSTAL;
            case "NETHOP", "NETH_OP", "NETHERITE_POT", "NETHPOT" -> NETHPOT;
            case "DIAMOND_POT", "DPOT" -> POT;
            case "TRAP", "TRAPS", "WEB" -> TRAPPER;
            case "DSMP", "DIAMONDSMP", "DIAMOND_SMP_POT" -> DIAMOND_SMP;
            case "MACEPRO", "MACE+" -> MACE_PRO;
            default -> null;
        };
    }

    public static Mode parse(String s) {
        try {
            String u = s.trim().toUpperCase(Locale.ROOT).replace('-', '_');
            Mode a = alias(u);
            return a != null ? a : valueOf(u);
        }
        catch (Exception e) { return SWORD; }
    }
}
