package dev.duelforge.ai;

import java.util.Random;

/**
 * Sword + shield. Raises the offhand shield while the sword is on cooldown and the enemy is close, lowers it right before
 * each swing. Holding the shield slows movement like any used item.
 */
final class ShieldLogic {
    private final Brain br;
    private boolean blocking;
    private int heldTicks, holdCd;

    ShieldLogic(Brain br) { this.br = br; }

    void reset() { blocking = false; heldTicks = 0; holdCd = 0; }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Random r = br.r;
        if (holdCd > 0) holdCd--;
        double flat = br.flat(t);
        br.select(Brain.S_WEAPON);

        if (blocking) {
            heldTicks++;
            if (br.cooldown <= 1 || flat > 5.0 || heldTicks > 30) {
                b.releaseUse(); blocking = false; holdCd = 3;      // lower the shield, then swing via melee()
            } else {
                br.state = "shield/block";
                br.faceTarget(t, 1.0);
                if (--br.strafeTimer <= 0) {
                    br.strafeTimer = Math.max(6, br.tier.strafeTicks() + r.nextInt(10));
                    if (r.nextBoolean()) br.strafeDir = -br.strafeDir;
                }
                b.strafe = br.strafeDir; b.wantSprint = false;
                return;
            }
        } else if (flat < 4.5 && br.cooldown > 3 && holdCd == 0 && r.nextInt(3) > 0) {
            b.startUseOff(); blocking = true; heldTicks = 0;
            br.state = "shield/block";
            br.faceTarget(t, 1.0);
            return;
        }
        br.melee(t);
    }
}
