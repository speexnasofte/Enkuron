package dev.duelforge.ai;

/**
 * Projectile flight solver (arrow, bolt, trident, ender pearl, potion).
 * Vanilla order per tick: move, drag, gravity. Works in the vertical plane through the shooter and the aim point.
 */
public final class Ballistics {
    private Ballistics() {}

    /** @param pitch Minecraft pitch in degrees (negative = up) @param ticks flight time in ticks */
    public record Shot(double pitch, double ticks) {}

    /** Height (relative to the launch point) and time at which the projectile crosses horizontal distance d, or null. */
    private static double[] cross(double d, double thetaDeg, double speed, double g, double drag) {
        double th = Math.toRadians(thetaDeg);
        double hx = 0, hy = 0, vh = speed * Math.cos(th), vy = speed * Math.sin(th);
        for (int i = 0; i < 300; i++) {
            double nx = hx + vh, ny = hy + vy;
            if (nx >= d) {
                double f = (d - hx) / (nx - hx);
                return new double[]{hy + (ny - hy) * f, i + f};
            }
            hx = nx; hy = ny;
            vh *= drag; vy = vy * drag - g;
            if (vh < 0.02) return null;
        }
        return null;
    }

    /**
     * Flat (direct) solution that passes through horizontal distance d at relative height h.
     * Returns null when the target is out of range.
     */
    public static Shot solve(double d, double h, double speed, double g, double drag) {
        d = Math.max(0.5, d);
        double prev = -60;
        for (double th = -60; th <= 75; th += 2.5) {
            double[] c = cross(d, th, speed, g, drag);
            if (c == null) return null;                 // too steep / too far: nothing beyond works
            if (c[0] >= h) {
                double lo = Math.max(-60, th - 2.5), hi = th;
                double[] best = c;
                for (int i = 0; i < 16; i++) {
                    double mid = (lo + hi) / 2;
                    double[] m = cross(d, mid, speed, g, drag);
                    if (m == null || m[0] >= h) { hi = mid; if (m != null) best = m; } else lo = mid;
                }
                return new Shot(-hi, best[1]);
            }
            prev = th;
        }
        return null;
    }
}
