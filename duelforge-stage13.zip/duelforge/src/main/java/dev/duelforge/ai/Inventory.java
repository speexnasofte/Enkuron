package dev.duelforge.ai;

import java.util.Locale;

/**
 * What the bot believes it carries: hotbar and the 27 inventory slots (from its kit) with counts that go down as it uses
 * consumables. The server inventory is not parsed, so this is a model, kept honest by the bot's own actions.
 * Without a kit everything is "unknown" and treated as available.
 */
public final class Inventory {
    private final boolean known;
    private final String[] hotItem = new String[9];
    private final int[] hotCount = new int[9];
    private final String[] invItem = new String[27];
    private final int[] invCount = new int[27];

    private Inventory(boolean known) {
        this.known = known;
        java.util.Arrays.fill(hotItem, "");
        java.util.Arrays.fill(invItem, "");
    }

    public static Inventory unknown() { return new Inventory(false); }

    public static Inventory fromKit(Kit k) {
        Inventory v = new Inventory(true);
        for (int i = 0; i < 9; i++) {
            Kit.Entry e = k.slots.get("hotbar." + i);
            if (e != null) { v.hotItem[i] = e.item(); v.hotCount[i] = e.count(); }
        }
        for (int i = 0; i < 27; i++) {
            Kit.Entry e = k.slots.get("inventory." + i);
            if (e != null) { v.invItem[i] = e.item(); v.invCount[i] = e.count(); }
        }
        return v;
    }

    public boolean known() { return known; }

    static String id(String s) { int b = s.indexOf('['); return (b < 0 ? s : s.substring(0, b)).toLowerCase(Locale.ROOT); }

    /** Items that are used up (tools and weapons are not). */
    static boolean consumable(String item) {
        String id = id(item);
        return id.contains("end_crystal") || id.endsWith(":obsidian") || id.endsWith("golden_apple") || id.contains("splash_potion")
                || id.contains("ender_pearl") || id.contains("firework_rocket") || id.contains("wind_charge") || id.endsWith(":glowstone")
                || id.contains("respawn_anchor") || id.contains("cobweb") || id.contains("tnt_minecart") || id.endsWith("rail") || id.contains("totem_of_undying");
    }

    /** Is there something usable in this hotbar slot? */
    public boolean has(int slot) {
        if (!known) return true;
        if (slot < 0 || slot > 8) return false;
        return !hotItem[slot].isEmpty() && (hotCount[slot] > 0 || !consumable(hotItem[slot]));
    }

    /** Does this hotbar slot hold an item whose id contains the text (and is it not used up)? Unknown inventory = yes. */
    public boolean holds(int slot, String part) {
        if (!known) return true;
        if (slot < 0 || slot > 8) return false;
        return id(hotItem[slot]).contains(part) && (hotCount[slot] > 0 || !consumable(hotItem[slot]));
    }

    public void use(int slot) {
        if (!known || slot < 0 || slot > 8 || hotItem[slot].isEmpty() || !consumable(hotItem[slot])) return;
        if (hotCount[slot] > 0) hotCount[slot]--;
    }

    /** An action we counted as used did not happen (e.g. the crystal never spawned). */
    public void refund(int slot) {
        if (!known || slot < 0 || slot > 8 || hotItem[slot].isEmpty() || !consumable(hotItem[slot])) return;
        hotCount[slot]++;
    }

    /** If a consumable hotbar slot ran dry and the inventory holds the same item, returns {menuSlot, hotbarSlot} for a swap. */
    public int[] pollRefill() {
        if (!known) return null;
        for (int h = 0; h < 9; h++) {
            if (hotItem[h].isEmpty() || hotCount[h] > 0 || !consumable(hotItem[h])) continue;
            for (int i = 0; i < 27; i++) {
                if (invCount[i] > 0 && invItem[i].equals(hotItem[h])) {
                    hotCount[h] = invCount[i]; invCount[i] = 0;
                    return new int[]{9 + i, h};
                }
            }
        }
        return null;
    }

    // ---- read access for the GUI
    public String hotItem(int i) { return hotItem[i]; }
    public int hotCount(int i) { return hotCount[i]; }
    public String invItem(int i) { return invItem[i]; }
    public int invCount(int i) { return invCount[i]; }
}
