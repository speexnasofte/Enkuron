package dev.duelforge.ai;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A saved loadout: item text per inventory slot (slot names as in /item replace: hotbar.0-8, inventory.0-26,
 * armor.head/chest/legs/feet, weapon.offhand) plus the PvP mode the bot should run with it.
 */
public final class Kit {
    public record Entry(int count, String item) {}

    public String name;
    /** PvP mode for bots using this kit (null = use the mode chosen at launch). */
    public Mode mode;
    public final Map<String, Entry> slots = new LinkedHashMap<>();

    public Kit(String name) { this.name = name; }

    /** Item stack as the game prints it ({id, count, components}); converts it to "id[component=value,...]". */
    public static Entry fromSnbt(String stackSnbt) {
        Map<String, String> m = Snbt.topLevel(stackSnbt);
        String id = Snbt.unquote(m.get("id"));
        if (id == null || id.isEmpty() || id.endsWith("air")) return null;
        int count = 1;
        String c = m.get("count");
        if (c != null) { try { count = Integer.parseInt(c.replaceAll("[^0-9-]", "")); } catch (NumberFormatException ignored) { } }
        StringBuilder sb = new StringBuilder(id);
        String comps = m.get("components");
        if (comps != null && !comps.equals("{}")) {
            StringBuilder cs = new StringBuilder();
            for (Map.Entry<String, String> e : Snbt.topLevel(comps).entrySet()) {
                if (cs.length() > 0) cs.append(',');
                if (e.getKey().startsWith("!")) cs.append(e.getKey());       // removed default component
                else cs.append(e.getKey()).append('=').append(e.getValue());
            }
            if (cs.length() > 0) sb.append('[').append(cs).append(']');
        }
        return new Entry(Math.max(1, count), sb.toString());
    }

    /** "id[a=v,b=w]" back to the stack SNBT the game can parse: {id:"id",count:n,components:{"a":v,"b":w}}. */
    public static String stackSnbt(String item, int count) {
        int b = item.indexOf('[');
        String id = b < 0 ? item : item.substring(0, b);
        StringBuilder comps = new StringBuilder();
        if (b >= 0 && item.endsWith("]")) {
            String body = item.substring(b + 1, item.length() - 1);
            int depth = 0, start = 0;
            char quote = 0;
            for (int i = 0; i <= body.length(); i++) {
                char c = i < body.length() ? body.charAt(i) : ',';
                if (quote != 0) { if (c == '\\') i++; else if (c == quote) quote = 0; continue; }
                if (c == '"' || c == '\'') quote = c;
                else if (c == '{' || c == '[' || c == '(') depth++;
                else if (c == '}' || c == ']' || c == ')') depth--;
                else if (c == ',' && depth == 0) {
                    String e = body.substring(start, i); start = i + 1;
                    int eq = e.indexOf('=');
                    if (comps.length() > 0) comps.append(',');
                    if (e.startsWith("!")) comps.append('"').append(e.trim()).append("\":{}");
                    else if (eq > 0) comps.append('"').append(e.substring(0, eq).trim()).append("\":").append(e.substring(eq + 1).trim());
                }
            }
        }
        return "{id:\"" + id + "\",count:" + Math.max(1, count) + (comps.length() > 0 ? ",components:{" + comps + "}" : "") + "}";
    }

    /** Commands that put this kit onto a target ("@s" or a nick). */
    public List<String> commands(String target, boolean clear) {
        List<String> out = new ArrayList<>();
        if (clear) out.add("clear " + target);
        for (Map.Entry<String, Entry> e : slots.entrySet()) {
            Entry v = e.getValue();
            out.add("item replace entity " + target + " " + e.getKey() + " with " + v.item() + (v.count() > 1 ? " " + v.count() : ""));
        }
        return out;
    }

    /** Hotbar contents (9 strings, empty = nothing) used for slot-role detection. */
    public String[] hotbarItems() {
        String[] h = new String[9];
        for (int i = 0; i < 9; i++) { Entry e = slots.get("hotbar." + i); h[i] = e == null ? "" : e.item(); }
        return h;
    }

    public String summary() {
        int hot = 0, inv = 0, armor = 0;
        for (String k : slots.keySet()) {
            if (k.startsWith("hotbar.")) hot++; else if (k.startsWith("inventory.")) inv++; else if (k.startsWith("armor.")) armor++;
        }
        return (mode == null ? "?" : mode.name()) + " · хотбар " + hot + " · броня " + armor
                + (slots.containsKey("weapon.offhand") ? " · оффхенд" : "") + (inv > 0 ? " · инв. " + inv : "");
    }

    /** Best guess of the PvP mode from the items. */
    public Mode guessMode() {
        StringBuilder sb = new StringBuilder();
        for (String s : hotbarItems()) sb.append(s.toLowerCase(Locale.ROOT)).append(' ');
        Entry off = slots.get("weapon.offhand");
        String all = sb.toString(), offs = off == null ? "" : off.item().toLowerCase(Locale.ROOT);
        boolean sword = all.contains("_sword");
        if (all.contains("end_crystal")) return Mode.CRYSTAL;
        if (all.contains("respawn_anchor")) return Mode.ANCHOR;
        if (all.contains("tnt_minecart")) return Mode.CART;
        if (all.contains("cobweb") && all.contains("lava_bucket")) return all.contains("minecraft:bow") ? Mode.UHC : Mode.TRAPPER;
        if (all.contains("mace")) return all.contains("firework_rocket") ? Mode.ROCKET_MACE : all.contains("wind_burst") ? Mode.MACE_PRO : Mode.MACE;
        if (all.contains("_spear")) return Mode.SPEAR;
        boolean axe = all.replace("pickaxe", "").contains("_axe");
        if (sword && axe && !all.contains("splash_potion")) return Mode.AXE_SWORD;
        if (all.contains("splash_potion") && all.contains("golden_apple") && sword)
            return slots.containsKey("armor.chest") && slots.get("armor.chest").item().contains("diamond_") ? Mode.DIAMOND_SMP : Mode.SMP;
        if (all.contains("splash_potion")) return all.contains("swiftness") || all.contains("strength") ? Mode.NETHPOT : Mode.POT;
        if (all.contains("minecraft:trident")) return Mode.TRIDENT;
        if (all.contains("minecraft:crossbow")) return Mode.CROSSBOW;
        if (all.contains("minecraft:bow")) return sword ? Mode.UHC : Mode.BOW;
        if (offs.contains("shield")) return Mode.SHIELD;
        if (all.contains("_axe") && !all.contains("pickaxe") && !sword) return Mode.AXE;
        return Mode.SWORD;
    }

    // ------------------------------------------------------------------ file format

    public String serialize() {
        StringBuilder sb = new StringBuilder("# PvP Bot Lab kit\n");
        if (mode != null) sb.append("mode=").append(mode.name()).append('\n');
        for (Map.Entry<String, Entry> e : slots.entrySet())
            sb.append("slot\t").append(e.getKey()).append('\t').append(e.getValue().count()).append('\t')
                    .append(e.getValue().item().replace('\n', ' ')).append('\n');
        return sb.toString();
    }

    public static Kit parse(String name, List<String> lines) {
        Kit k = new Kit(name);
        for (String line : lines) {
            if (line.startsWith("mode=")) k.mode = Mode.parse(line.substring(5));
            else if (line.startsWith("slot\t")) {
                String[] p = line.split("\t", 4);
                if (p.length == 4) {
                    try { k.slots.put(p[1], new Entry(Integer.parseInt(p[2]), p[3])); } catch (NumberFormatException ignored) { }
                }
            }
        }
        return k;
    }
}
