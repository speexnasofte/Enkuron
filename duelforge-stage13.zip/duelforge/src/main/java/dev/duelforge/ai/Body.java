package dev.duelforge.ai;

import dev.duelforge.net.Ids;
import dev.duelforge.net.Wire;

import java.util.Random;
import java.util.function.Consumer;

/**
 * The bot's physical body: vanilla-accurate walking / jumping / elytra physics on an assumed flat floor,
 * mouse-like rotation (quantised to a fixed sensitivity step) and the packets a real client would send.
 * Everything here is deliberately "legit-looking": speeds, reach and rotation all stay inside vanilla limits.
 */
public final class Body {
    public interface Net { void send(int id, Consumer<Wire.Out> body); }

    private static final double MOUSE_STEP = 0.15; // sensitivity 50% -> 0.15 degree granularity

    private final Net net;
    private final Random rnd;

    public int entityId;
    public double x, y, z, vx, vy, vz;
    public float yaw, pitch;
    public boolean onGround = true, gliding, sprinting, haveFix;
    public double groundY;
    /** Blocks the server sent; null or an unloaded column = the old flat-floor model. Set by the network layer. */
    public ChunkStore terrain;
    public float health = 20f;
    public boolean dead;

    // inputs set by the brain each tick
    public float fwd, strafe;
    public boolean jump, wantSprint;
    /** True while holding right-click on an item (eating, drawing a bow): vanilla slows movement to 20%. */
    public boolean usingItem;
    /** true: eating / drawing a bow does not slow the bot (NOT vanilla - anticheats flag it as NoSlow). */
    public boolean noSlow;
    /** Number of attack packets sent (HUD statistics). */
    public int attacks;
    /** How many times the server moved us back (position corrections after the first fix). */
    public int corrections;

    private double lastX, lastY, lastZ;
    private float lastYaw, lastPitch;
    private int sinceSent;
    private int inputFlags = -1;
    private int sequence;
    public int boostTicks;

    public Body(Net net, Random rnd) { this.net = net; this.rnd = rnd; }

    // ------------------------------------------------------------------ rotation

    private static double wrap(double a) {
        a %= 360.0;
        if (a >= 180) a -= 360;
        if (a < -180) a += 360;
        return a;
    }

    public static double yawTo(double dx, double dz) { return Math.toDegrees(Math.atan2(-dx, dz)); }

    public static double pitchTo(double dx, double dy, double dz) {
        return -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    /** Turn the head toward a target angle the way a hand on a mouse would. */
    public void aim(double targetYaw, double targetPitch, double speed, double noise) {
        double dy = wrap(targetYaw - yaw);
        double dp = targetPitch - pitch;
        double sy = Math.signum(dy) * Math.min(speed, Math.abs(dy) * 0.6 + 0.4);
        double sp = Math.signum(dp) * Math.min(speed * 0.8, Math.abs(dp) * 0.6 + 0.3);
        if (Math.abs(dy) < 0.2) sy = 0;
        if (Math.abs(dp) < 0.2) sp = 0;
        double ny = yaw + sy + (sy != 0 ? rnd.nextGaussian() * noise * 0.2 : 0);
        double np = pitch + sp + (sp != 0 ? rnd.nextGaussian() * noise * 0.15 : 0);
        yaw = (float) (Math.round(wrap(ny) / MOUSE_STEP) * MOUSE_STEP);
        pitch = (float) (Math.round(Math.max(-90, Math.min(90, np)) / MOUSE_STEP) * MOUSE_STEP);
    }

    public double angleError(double targetYaw, double targetPitch) {
        return Math.hypot(wrap(targetYaw - yaw), targetPitch - pitch);
    }

    // ------------------------------------------------------------------ physics

    /** Called by the network layer when the server teleports us. */
    public void serverPosition(double nx, double ny, double nz, double dvx, double dvy, double dvz, float nyaw, float npitch) {
        if (haveFix) corrections++;
        if (!haveFix || onGround) groundY = ny;
        if (Opts.terrainPhysics && terrain != null && terrain.loaded(nx, nz) && !Collide.onPartial(terrain, nx, ny, nz)) {
            double fy = Collide.floorY(terrain, nx, ny, nz);
            if (!Double.isNaN(fy)) groundY = fy;
        }
        x = nx; y = ny; z = nz;
        vx = dvx; vy = dvy; vz = dvz;
        yaw = nyaw; pitch = npitch;
        lastX = x; lastY = y; lastZ = z; lastYaw = yaw; lastPitch = pitch;
        haveFix = true;
        gliding = false;
        onGround = Math.abs(ny - groundY) < 1e-3;
    }

    /** Velocity pushed by the server (knockback, wind charge, ...). */
    public void serverMotion(double mx, double my, double mz) { vx = mx; vy = my; vz = mz; onGround = false; }

    public void step() {
        if (!haveFix) return;
        final boolean tm = Opts.terrainPhysics && terrain != null && terrain.loaded(x, z) && !Collide.onPartial(terrain, x, y, z);
        double yawRad = Math.toRadians(yaw);
        boolean grounded = onGround;
        double f = grounded ? 0.546 : 0.91;

        if (gliding) {
            glideStep();
        } else {
            if (grounded && jump) {
                vy = 0.42;
                if (sprinting) { vx -= Math.sin(yawRad) * 0.2; vz += Math.cos(yawRad) * 0.2; }
            }
            double in = Math.hypot(fwd, strafe);
            double acc = grounded ? (sprinting ? 0.13 : 0.1) : (sprinting ? 0.026 : 0.02);
            if (in > 0.01) {
                double s = 0.98 / Math.max(1.0, in) * (usingItem && !noSlow ? 0.2 : 1.0);
                double lf = fwd * s, ls = strafe * s;
                vx += (ls * Math.cos(yawRad) - lf * Math.sin(yawRad)) * acc;
                vz += (lf * Math.cos(yawRad) + ls * Math.sin(yawRad)) * acc;
            }
            if (tm) {
                double[] r = Collide.move(terrain, x, y, z, vx, vy, vz);
                if (r[0] != vx) vx = 0;
                if (r[2] != vz) vz = 0;
                if (r[1] != vy) vy = 0;
                x += r[0]; y += r[1]; z += r[2];
            } else {
                x += vx; y += vy; z += vz;
            }
            vy = (vy - 0.08) * 0.98;
            vx *= f; vz *= f;
        }
        if (tm) {
            double fy = Collide.floorY(terrain, x, y, z);
            if (!Double.isNaN(fy)) groundY = fy;
        }
        if (y <= groundY + (tm ? 1.0E-6 : 0)) {
            y = groundY;
            if (vy < 0) vy = 0;
            onGround = true;
            if (gliding) { gliding = false; boostTicks = 0; }
        } else {
            onGround = false;
        }
    }

    /** Vanilla elytra physics (LivingEntity#travelFallFlying). */
    private void glideStep() {
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double lx = -Math.sin(yr) * Math.cos(pr), ly = -Math.sin(pr), lz = Math.cos(yr) * Math.cos(pr);
        double hl = Math.sqrt(lx * lx + lz * lz);
        double vh = Math.sqrt(vx * vx + vz * vz);
        double cp = Math.cos(pr);
        double sq = cp * cp;
        vy += 0.08 * (-1.0 + sq * 0.75);
        if (vy < 0 && hl > 0) {
            double d = vy * -0.1 * sq;
            vx += lx * d / hl; vy += d; vz += lz * d / hl;
        }
        if (pr < 0 && hl > 0) {
            double d = vh * -Math.sin(pr) * 0.04;
            vx -= lx * d / hl; vy += d * 3.2; vz -= lz * d / hl;
        }
        if (hl > 0) {
            vx += (lx / hl * vh - vx) * 0.1;
            vz += (lz / hl * vh - vz) * 0.1;
        }
        if (boostTicks > 0) { // firework rocket
            vx += lx * 0.1 + (lx * 1.5 - vx) * 0.5;
            vy += ly * 0.1 + (ly * 1.5 - vy) * 0.5;
            vz += lz * 0.1 + (lz * 1.5 - vz) * 0.5;
            boostTicks--;
        }
        vx *= 0.99; vy *= 0.98; vz *= 0.99;
        x += vx; y += vy; z += vz;
    }

    // ------------------------------------------------------------------ packets

    /** One client tick: send input state, movement and tick-end like a vanilla client. */
    public void flush() {
        if (!haveFix) return;
        boolean wantS = wantSprint && fwd > 0.5f && !gliding && (!usingItem || noSlow);
        if (wantS != sprinting) {
            sprinting = wantS;
            int act = wantS ? 1 : 2;
            net.send(Ids.SB_PLAYER_COMMAND, o -> o.varInt(entityId).varInt(act).varInt(0));
        }
        int flags = 0;
        if (fwd > 0.5f) flags |= 1;
        if (fwd < -0.5f) flags |= 2;
        if (strafe > 0.5f) flags |= 4;   // left
        if (strafe < -0.5f) flags |= 8;  // right
        if (jump) flags |= 0x10;
        if (sprinting) flags |= 0x40;
        if (flags != inputFlags) {
            inputFlags = flags;
            final int fl = flags;
            net.send(Ids.SB_PLAYER_INPUT, o -> o.u8(fl));
        }

        boolean moved = (x - lastX) * (x - lastX) + (y - lastY) * (y - lastY) + (z - lastZ) * (z - lastZ) > 4.0E-8 || ++sinceSent >= 20;
        boolean rotated = yaw != lastYaw || pitch != lastPitch;
        int g = onGround ? 1 : 0;
        if (moved && rotated) {
            net.send(Ids.SB_MOVE_POS_ROT, o -> o.f64(x).f64(y).f64(z).f32(yaw).f32(pitch).u8(g));
        } else if (moved) {
            net.send(Ids.SB_MOVE_POS, o -> o.f64(x).f64(y).f64(z).u8(g));
        } else if (rotated) {
            net.send(Ids.SB_MOVE_ROT, o -> o.f32(yaw).f32(pitch).u8(g));
        }
        if (moved) sinceSent = 0;
        lastX = x; lastY = y; lastZ = z; lastYaw = yaw; lastPitch = pitch;
        net.send(Ids.SB_TICK_END, o -> {});
    }

    // ------------------------------------------------------------------ actions

    public void selectSlot(int slot) { net.send(Ids.SB_SET_CARRIED, o -> o.i16(slot)); }

    public void swing() { net.send(Ids.SB_SWING, o -> o.varInt(0)); }

    public void attack(int targetId) {
        attacks++;
        net.send(Ids.SB_INTERACT, o -> o.varInt(targetId).varInt(1).bool(false));
        swing();
    }

    public void useItem() { useItemHand(0); }

    /** hand 0 = main, 1 = offhand (shield). */
    public void useItemHand(int hand) {
        final int seq = ++sequence;
        final float yw = yaw, pt = pitch;
        net.send(Ids.SB_USE_ITEM, o -> o.varInt(hand).varInt(seq).f32(yw).f32(pt));
    }

    /** Right-click the top face of a block with the held item (end crystal on obsidian). */
    public void useOnBlockTop(int bx, int by, int bz) {
        final int seq = ++sequence;
        net.send(Ids.SB_USE_ITEM_ON, o -> o.varInt(0).i64(Wire.packPos(bx, by, bz)).varInt(1)
                .f32(0.5f).f32(1.0f).f32(0.5f).bool(false).bool(false).varInt(seq));
        swing();
    }

    /** Start holding right-click (eat, draw bow / crossbow / trident). Movement is slowed until {@link #releaseUse()}. */
    public void startUse() {
        usingItem = true;
        useItem();
    }

    /** Raise the shield in the offhand. */
    public void startUseOff() {
        usingItem = true;
        useItemHand(1);
    }

    /** Right-click an entity (ignite a TNT minecart with flint and steel). */
    public void interact(int targetId) {
        net.send(Ids.SB_INTERACT, o -> o.varInt(targetId).varInt(0).varInt(0).bool(false));
        swing();
    }

    /** Release the held item (shoot the bow, finish charging a crossbow, throw the trident). */
    public void releaseUse() {
        usingItem = false;
        final int seq = ++sequence;
        net.send(Ids.SB_PLAYER_ACTION, o -> o.varInt(5).i64(Wire.packPos(0, 0, 0)).u8(0).varInt(seq));
    }

    /**
     * Inventory click "swap with hotbar key": menuSlot is the player-inventory menu slot (9-35 inventory, 36-44 hotbar,
     * 45 offhand), button 0-8 = hotbar slot, 40 = offhand. Sent with an empty changed-slot list; the server runs the click
     * on its own state.
     */
    public void containerSwap(int menuSlot, int button) {
        net.send(Ids.SB_CONTAINER_CLICK, o -> o.varInt(0).varInt(0).i16(menuSlot).u8(button).varInt(2).varInt(0).bool(false));
    }

    /** Swap main hand and offhand (F key) - moves a totem from the hotbar into the offhand. */
    public void swapOffhand() {
        final int seq = ++sequence;
        net.send(Ids.SB_PLAYER_ACTION, o -> o.varInt(6).i64(Wire.packPos(0, 0, 0)).u8(0).varInt(seq));
    }

    public void startGliding() {
        gliding = true;
        net.send(Ids.SB_PLAYER_COMMAND, o -> o.varInt(entityId).varInt(6).varInt(0));
    }

    public void command(String cmd) {
        String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        net.send(Ids.SB_CHAT_COMMAND, o -> o.str(c));
    }

    public void respawn() { net.send(Ids.SB_CLIENT_COMMAND, o -> o.varInt(0)); }
}
