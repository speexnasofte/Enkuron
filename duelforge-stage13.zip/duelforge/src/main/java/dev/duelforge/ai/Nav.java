package dev.duelforge.ai;

import java.util.*;

/**
 * Path finding over the blocks the server sent ({@link ChunkStore}). A cell is a place the bot can stand: a full block
 * under it and two free cells (feet, head) above. Moves: 8 horizontal directions (diagonals only when both sides are free),
 * one step up (a jump), drops of up to 3 blocks. Water, lava, fire, webs, partial blocks (slabs, stairs: unknown height) and
 * unloaded chunks are not walkable. If the target cannot be reached the path leads to the explored cell closest to it.
 */
public final class Nav {
    public static final int MAX_NODES = 3000;

    private static boolean passable(int c) { return c == BlockTable.AIR || c == BlockTable.PLANT; }

    public static boolean walkable(ChunkStore s, int x, int y, int z) {
        return BlockTable.isFull(s.get(x, y - 1, z)) && passable(s.get(x, y, z)) && passable(s.get(x, y + 1, z));
    }

    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

    private static final class Node implements Comparable<Node> {
        final int x, y, z; final double g, f; final Node from;
        /** Reached through a drop: cannot be undone, so it is never the fallback "closest" cell when the target is unreachable. */
        final boolean dropped;
        Node(int x, int y, int z, double g, double f, Node from, boolean dropped) { this.x = x; this.y = y; this.z = z; this.g = g; this.f = f; this.from = from; this.dropped = dropped || (from != null && from.dropped); }
        public int compareTo(Node o) { return Double.compare(f, o.f); }
    }

    private static long key(int x, int y, int z) { return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF); }

    private static double h(int x, int y, int z, int gx, int gy, int gz) {
        double dx = Math.abs(x - gx), dz = Math.abs(z - gz);
        return Math.max(dx, dz) + 0.414 * Math.min(dx, dz) + 0.5 * Math.abs(y - gy);
    }

    /**
     * Cells from the one after the start to the goal (or to the closest reachable cell), or null when the start itself is not
     * a standable cell or nothing better than staying put was found.
     */
    public static int[][] find(ChunkStore s, int sx, int sy, int sz, int gx, int gy, int gz) {
        if (!walkable(s, sx, sy, sz)) return null;
        PriorityQueue<Node> open = new PriorityQueue<>();
        Map<Long, Double> best = new HashMap<>();
        Node start = new Node(sx, sy, sz, 0, h(sx, sy, sz, gx, gy, gz), null, false);
        open.add(start);
        best.put(key(sx, sy, sz), 0.0);
        Node closest = start;
        double closestH = start.f;
        int expanded = 0;
        Node goal = null;
        while (!open.isEmpty() && expanded < MAX_NODES) {
            Node n = open.poll();
            Double bg = best.get(key(n.x, n.y, n.z));
            if (bg != null && n.g > bg + 1e-9) continue;
            expanded++;
            if (Math.abs(n.x - gx) <= 1 && Math.abs(n.z - gz) <= 1 && Math.abs(n.y - gy) <= 2) { goal = n; break; }
            double hn = h(n.x, n.y, n.z, gx, gy, gz);
            if (hn < closestH && !n.dropped) { closestH = hn; closest = n; }
            for (int[] d : DIRS) {
                int nx = n.x + d[0], nz = n.z + d[1];
                boolean diag = d[0] != 0 && d[1] != 0;
                if (diag) {
                    if (!passable(s.get(n.x + d[0], n.y, n.z)) || !passable(s.get(n.x + d[0], n.y + 1, n.z))
                            || !passable(s.get(n.x, n.y, n.z + d[1])) || !passable(s.get(n.x, n.y + 1, n.z + d[1]))) continue;
                }
                double step = diag ? 1.414 : 1.0;
                // same level
                if (walkable(s, nx, n.y, nz)) push(open, best, nx, n.y, nz, n.g + step, gx, gy, gz, n, false);
                if (diag) continue;
                // one up (jump): head room at the start, free cells at the destination
                if (passable(s.get(n.x, n.y + 2, n.z)) && walkable(s, nx, n.y + 1, nz)) push(open, best, nx, n.y + 1, nz, n.g + step + 1.0, gx, gy, gz, n, false);
                // drop up to 3
                if (passable(s.get(nx, n.y, nz)) && passable(s.get(nx, n.y + 1, nz))) {
                    for (int dd = 1; dd <= 3; dd++) {
                        int ny = n.y - dd;
                        if (!passable(s.get(nx, ny, nz))) break;
                        if (BlockTable.isFull(s.get(nx, ny - 1, nz))) { push(open, best, nx, ny, nz, n.g + step + 0.3 * dd, gx, gy, gz, n, true); break; }
                    }
                }
            }
        }
        Node end = goal != null ? goal : closest;
        if (end == start) return null;
        ArrayList<int[]> out = new ArrayList<>();
        for (Node n = end; n.from != null; n = n.from) out.add(new int[]{n.x, n.y, n.z});
        Collections.reverse(out);
        return out.toArray(new int[0][]);
    }

    private static void push(PriorityQueue<Node> open, Map<Long, Double> best, int x, int y, int z, double g, int gx, int gy, int gz, Node from, boolean drop) {
        long k = key(x, y, z);
        Double old = best.get(k);
        if (old != null && old <= g) return;
        best.put(k, g);
        open.add(new Node(x, y, z, g, g + h(x, y, z, gx, gy, gz), from, drop));
    }

    // ------------------------------------------------------------------ steering (per bot)

    private int[][] path;
    private int idx, pathTick = -1000;
    private double pathTx, pathTz;

    public Nav() {}

    public void reset() { path = null; idx = 0; pathTick = -1000; }
    public boolean active() { return path != null; }

    /**
     * Called after the mode logic has chosen its movement. When the bot wants to walk towards the target but a wall is in the
     * way, replaces the movement by a step towards the next path cell (the bot keeps looking at the target: the direction is
     * turned into forward / strafe relative to its yaw). Returns true when it took over.
     */
    public boolean assist(Body b, World w, World.Ent t, int tick) {
        ChunkStore s = w.chunks;
        if (!Opts.pathfinding || !Opts.terrainPhysics || !b.onGround || b.gliding || b.fwd <= 0.1f
                || !s.loaded(b.x, b.z) || !s.loaded(t.x, t.z) || Math.hypot(t.x - b.x, t.z - b.z) < 2.5) { path = null; return false; }
        boolean blocked = s.rayBlocked(b.x, b.y + 0.5, b.z, t.x, t.y + 0.5, t.z) || s.rayBlocked(b.x, b.y + 1.5, b.z, t.x, t.y + 1.5, t.z);
        if (!blocked) { path = null; return false; }
        int sx = (int) Math.floor(b.x), sy = (int) Math.floor(b.y + 1e-3), sz = (int) Math.floor(b.z);
        boolean stale = path == null || tick - pathTick > 20 || Math.hypot(t.x - pathTx, t.z - pathTz) > 2.5;
        if (stale) {
            double ty = Collide.floorY(s, t.x, t.y + 0.5, t.z);
            path = find(s, sx, sy, sz, (int) Math.floor(t.x), Double.isNaN(ty) ? (int) Math.floor(t.y + 1e-3) : (int) Math.round(ty), (int) Math.floor(t.z));
            idx = 0; pathTick = tick; pathTx = t.x; pathTz = t.z;
        }
        if (path == null || path.length == 0) return false;
        while (idx < path.length - 1 && Math.hypot(path[idx][0] + 0.5 - b.x, path[idx][2] + 0.5 - b.z) < 0.55 && Math.abs(path[idx][1] - b.y) < 1.2) idx++;
        int[] c = path[idx];
        double dx = c[0] + 0.5 - b.x, dz = c[2] + 0.5 - b.z, len = Math.hypot(dx, dz);
        if (len < 1e-3 && idx >= path.length - 1) return false;
        if (len > 1e-3) { dx /= len; dz /= len; }
        double yr = Math.toRadians(b.yaw);
        b.fwd = (float) (dx * -Math.sin(yr) + dz * Math.cos(yr));
        b.strafe = (float) (dx * Math.cos(yr) + dz * Math.sin(yr));
        b.wantSprint = true;
        if (c[1] > b.y + 0.4 && len < 1.7) b.jump = true;
        return true;
    }
}
