package dev.duelforge.ai;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/**
 * Per-mode kit commands, run once after login when no join command was set and {@link Opts#autoKit} is on.
 * Default for each mode is "kit <mode>" (e.g. "kit crystal", "kit rocket_mace"). Override in
 * config/pvpbotlab-kits.properties, one line per mode: crystal=kit crystalpvp   (an empty value disables it).
 */
public final class Kits {
    private Kits() {}

    private static final Properties P = new Properties();

    static {
        try {
            Path f = Path.of("config", "pvpbotlab-kits.properties");
            if (Files.exists(f)) try (InputStream in = Files.newInputStream(f)) { P.load(in); }
        } catch (Exception ignored) { }
    }

    /** The command to run (without the leading slash) or null. */
    public static String forMode(Mode m) {
        if (m == Mode.MIXED || m == Mode.NPC) return null;
        String key = m.name().toLowerCase(Locale.ROOT);
        String v = P.getProperty(key);
        if (v == null) return "kit " + key;
        v = v.trim();
        return v.isEmpty() ? null : v;
    }
}
