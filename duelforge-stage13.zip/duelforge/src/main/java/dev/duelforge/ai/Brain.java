package dev.duelforge.ai;

import java.util.Random;
import java.util.Set;

/**
 * Decision layer. Runs once per client tick and drives {@link Body}.
 * Skill (Tier) controls aim speed/noise, reaction time, hit timing, crits, w-taps and healing.
 * Mode-specific tactics live in {@link CrystalLogic}, {@link AnchorLogic}, {@link RangedLogic}, {@link PotLogic}.
 */
public final class Brain {
    static final double EYE = 1.62;
    /** Hotbar layout (0-based): weapon, second item, golden apple, third/fourth/fifth/sixth item, ender pearl, spare totem. */
    public static final int S_WEAPON = 0, S_SECOND = 1, S_HEAL = 2, S_THIRD = 3, S_FOURTH = 4, S_FIFTH = 5, S_SIXTH = 6, S_PEARL = 7, S_TOTEM = 8;

    final Body b;
    final World w;
    final Random r;
    final Tier tier;
    private Mode configured;
    private final Set<String> friends;
    private Layout layout = Layout.DEFAULT;
    Inventory inv = Inventory.unknown();
    private int invCd;
    private final String selfName;

    public Mode mode;
    int tick, cooldown, strafeTimer, strafeDir = 1, slot = -1;
    private int react, lockedId = -1, lockSince, healTicks, healCd, retreat, retreatCd;
    final Combo combo = new Combo();
    /** Share of W/S-taps that really turn the next swing into a sprint hit (knockback); the rest become jump crits (more damage). */
    static final double SPRINT_HIT = 0.2;
    private int phase, phaseTicks, ability;
    int abilityCd;
    private boolean critWanted;
    private int critWait;
    private int totemStep, pokes;
    /** Hotbar role the melee logic swings (S_WEAPON normally, S_SECOND for the axe opener of AXE_SWORD). */
    private int weaponRole = S_WEAPON;
    private boolean axeArmed = true;
    private int swordHits, npcAggro;
    private float npcHp = 20f;
    /** PRESSURE: keep walking into the enemy, follow every hit with a combo. */
    private boolean aggr;
    private float lastHp = 20f;
    private int pearlCd, pearlStep, pearlWait;
    private boolean pearlEscape;
    public String state = "idle";
    /** Controller orders: FIGHT (default), FOLLOW the player named {@code focus}, or IDLE. */
    private volatile Order order = Order.FIGHT;
    private volatile String focus;

    // ---- diagnostics (shown by /botlab diag and in the menu)
    private int dTicks, dReach, dFar, dStuck, stuckTicks, corrAt, stuckDir = 1;

    /** Where this bot spends its time: a bot that is rarely in reach is stuck, lagging or blocked, not "weak". */
    public String diag() {
        double n = Math.max(1, dTicks);
        return String.format("в зоне удара %.0f%% · далеко (>8) %.0f%% · ударов %d · коррекций сервера %d · застреваний %d",
                100.0 * dReach / n, 100.0 * dFar / n, b.attacks, b.corrections, dStuck);
    }

    private final CrystalLogic crystal = new CrystalLogic(this);
    private final AnchorLogic anchor = new AnchorLogic(this);
    private final RangedLogic ranged = new RangedLogic(this);
    private final PotLogic pot = new PotLogic(this);
    private final CartLogic cart = new CartLogic(this);
    private final ShieldLogic shield = new ShieldLogic(this);
    private final TrapLogic trap = new TrapLogic(this);
    private final MaceLogic maceLogic = new MaceLogic(this);

    public Brain(Body b, World w, Random r, Tier tier, Mode mode, String team, Set<String> friends, String selfName) {
        this.b = b; this.w = w; this.r = r; this.tier = tier; this.configured = mode;
        this.friends = friends; this.selfName = selfName;
        pickMode();
    }

    /** Switch the PvP mode of a running bot (kit applied to it). */
    public void setMode(Mode m) { configured = m; onRespawn(); }

    /** Entity id of the enemy the bot is fighting right now (-1 = none); used by the target ring. */
    public int targetId() { return lockedId; }

    public void setOrder(Order o, String who) { order = o == null ? Order.FIGHT : o; focus = who; lockedId = -1; }

    public void setLayout(Layout l) { layout = l == null ? Layout.DEFAULT : l; slot = -1; }

    /** The kit the bot was given: its items define what the bot may use and what it can refill from the inventory. */
    public void setKit(Kit k) { inv = k == null ? Inventory.unknown() : Inventory.fromKit(k); selfArmor = ExplosionMath.Armor.fromKit(k); }

    /** Armor the bot wears (read from its kit; unknown kit = none, the safe assumption) and what it assumes about the enemy. */
    ExplosionMath.Armor selfArmor = ExplosionMath.Armor.NONE;
    ExplosionMath.Armor enemyArmor = ExplosionMath.Armor.NETHERITE_P4;

    /** Damage a crystal exploding at this point would do to the bot right now. */
    double selfCrystal(double cx, double cy, double cz) { return ExplosionMath.crystal(selfArmor, cx, cy, cz, b.x, b.y, b.z, w.exposure(cx, cy, cz, b.x, b.y, b.z)); }

    /** Damage a crystal exploding at this point would do to the enemy. */
    double enemyCrystal(World.Ent t, double cx, double cy, double cz) { return ExplosionMath.crystal(enemyArmor, cx, cy, cz, t.x, t.y, t.z, w.exposure(cx, cy, cz, t.x, t.y, t.z)); }

    /**
     * Where to point the head at an enemy (ported from Expensive's HitPointResolver): ten points up the hitbox column, the one that
     * needs the smallest head turn from the current look direction and is within reach. Low tiers keep a fixed chest point; so does
     * anything out of reach (then only the general direction matters).
     */
    double[] aimPoint(World.Ent t) {
        double chest = t.y + 1.2;
        if (!Opts.hitboxAim || tier.ordinal() < Tier.HT3.ordinal()) return new double[]{t.x, chest, t.z};
        double ex = b.x, ey = b.y + EYE, ez = b.z;
        double lim = tier.reach() + 0.25;
        double best = Double.MAX_VALUE; double by = chest;
        for (int i = 0; i <= 10; i++) {
            double py = t.y + 1.8 * i / 10.0;
            // the column point is moved to the hitbox edge nearest to us so the reach test matches what the server measures
            double cx = Math.max(t.x - 0.3, Math.min(ex, t.x + 0.3)), cz = Math.max(t.z - 0.3, Math.min(ez, t.z + 0.3));
            double d = Math.sqrt(sq(cx - ex) + sq(py - ey) + sq(cz - ez));
            if (d > lim) continue;
            double[] a = angTo(t.x, py, t.z);
            double cost = b.angleError(a[0], a[1]);
            if (cost < best) { best = cost; by = py; }
        }
        return new double[]{t.x, by, t.z};
    }

    public Inventory inventory() { return inv; }

    /** Hotbar slot (0-8) the bot currently holds, -1 if unknown. */
    public int selectedSlot() { return slot; }

    /** Does the bot still have something usable for this logical role? */
    boolean has(int logical) { return inv.has(layout.map(logical)); }

    /** Count one use of a consumable role (crystal placed, apple eaten, pot thrown ...). */
    void consume(int logical) { inv.use(layout.map(logical)); }

    void refund(int logical) { inv.refund(layout.map(logical)); }

    /** Does the hotbar slot of this role hold an item whose id contains the text (unknown inventory: assume yes)? */
    boolean kitHas(int logical, String part) { return inv.holds(layout.map(logical), part); }

    /** Exact item text the kit put in the slot of this role ("" if unknown). */
    String kitItem(int logical) { int s = layout.map(logical); return inv.known() && s >= 0 && s < 9 ? inv.hotItem(s) : ""; }

    /** SMP / Diamond SMP: pots are used only when the kit is known and really holds splash potions. */
    boolean smpPots() { return inv.known() && kitHas(S_SECOND, "splash_potion"); }

    /** Is the bot currently holding the given logical hotbar role? */
    boolean holding(int logical) { return slot == layout.map(logical); }

    public void onRespawn() {
        pickMode();
        phase = 0; lockedId = -1; slot = -1; healTicks = 0; totemStep = 0; pearlStep = 0; lastHp = 20f;
        b.usingItem = false;
        crystal.reset(); anchor.reset(); ranged.reset(); pot.reset(); cart.reset(); shield.reset(); trap.reset(); maceLogic.reset();
        combo.reset(); retreat = 0; retreatCd = 0;
        weaponRole = S_WEAPON; axeArmed = true; swordHits = 0; npcAggro = 0; npcHp = 20f;
    }

    private void pickMode() {
        if (configured == Mode.MIXED) {
            Mode[] all = {Mode.SWORD, Mode.AXE, Mode.SMP, Mode.CRYSTAL, Mode.ANCHOR, Mode.MACE, Mode.ROCKET_MACE,
                    Mode.ELYTRA, Mode.POT, Mode.BOW, Mode.CROSSBOW, Mode.TRIDENT, Mode.PEARL, Mode.CART, Mode.UHC, Mode.SHIELD, Mode.NETHPOT, Mode.SPEAR, Mode.AXE_SWORD, Mode.PRESSURE};
            mode = all[r.nextInt(all.length)];
        } else mode = configured;
    }

    // ------------------------------------------------------------------ helpers

    /** Select a hotbar slot; returns true if the slot actually changed (the caller should wait a tick before using it). */
    boolean select(int logical) {
        int s = layout.map(logical);
        if (slot == s) return false;
        slot = s;
        b.selectSlot(s);
        return true;
    }

    static double sq(double v) { return v * v; }

    double dist(World.Ent e) { return Math.sqrt(sq(e.x - b.x) + sq(e.y - b.y) + sq(e.z - b.z)); }

    double flat(World.Ent e) { return Math.hypot(e.x - b.x, e.z - b.z); }

    /** Distance from our eye to the closest point of an entity hitbox (halfWidth, height). */
    double reachBox(World.Ent e, double halfW, double height) {
        double ex = b.x, ey = b.y + EYE, ez = b.z;
        double cx = Math.max(e.x - halfW, Math.min(ex, e.x + halfW));
        double cy = Math.max(e.y, Math.min(ey, e.y + height));
        double cz = Math.max(e.z - halfW, Math.min(ez, e.z + halfW));
        return Math.sqrt(sq(cx - ex) + sq(cy - ey) + sq(cz - ez));
    }

    /** Distance to a player's hitbox (0.6 wide, 1.8 tall). */
    double reachDist(World.Ent e) { return reachBox(e, 0.3, 1.8); }

    double eyeDist(double x, double y, double z) { return Math.sqrt(sq(x - b.x) + sq(y - b.y - EYE) + sq(z - b.z)); }

    /** {yaw, pitch} from our eye to a point. */
    double[] angTo(double x, double y, double z) {
        double dx = x - b.x, dz = z - b.z;
        return new double[]{Body.yawTo(dx, dz), Body.pitchTo(dx, y - (b.y + EYE), dz)};
    }

    private boolean isEnemy(World.Ent e) {
        if (!e.player || e.name.equalsIgnoreCase(selfName) || friends.contains(e.name.toLowerCase())) return false;
        String f = focus;
        return order != Order.FIGHT || f == null || e.name.equalsIgnoreCase(f);
    }

    private World.Ent pickTarget() {
        World.Ent cur = w.ents.get(lockedId);
        World.Ent best = null; double bd = 1e9;
        for (World.Ent e : w.ents.values()) {
            // stationary players send no movement packets, so staleness is judged only by remove_entities
            if (!isEnemy(e)) continue;
            double d = dist(e);
            if (d < bd) { bd = d; best = e; }
        }
        if (cur != null && isEnemy(cur) && dist(cur) < 96) {
            // stay on the current target unless somebody is much closer
            if (best != null && best != cur && bd < dist(cur) * 0.5 && tick - lockSince > 40) { cur = null; }
            else return cur;
        }
        if (best != null && lockedId != best.id) {
            lockedId = best.id; lockSince = tick; react = tier.reactTicks() + r.nextInt(3);
        }
        return best;
    }

    private double cooldownTicks() {
        return switch (mode) {
            case AXE -> 20;
            case MACE, MACE_PRO, ROCKET_MACE -> 33;
            default -> 12.5;
        };
    }

    /**
     * Pick a block cell (x, z) beside the target at floor level, within block-reach of us and not inside anybody's hitbox.
     * Prefers cells far from us (less self damage) and close to the target (more damage). Returns {x, z} or null.
     */
    int[] pickCell(World.Ent t, double minBot, double maxBot, int gy, java.util.function.BiPredicate<Integer, Integer> bad) {
        return pickCell(t, minBot, maxBot, gy, bad, null);
    }

    /** Same, with an extra score per cell; NEGATIVE_INFINITY from {@code extra} rules the cell out. */
    int[] pickCell(World.Ent t, double minBot, double maxBot, int gy, java.util.function.BiPredicate<Integer, Integer> bad,
                   java.util.function.BiFunction<Integer, Integer, Double> extra) {
        int tx = (int) Math.floor(t.x), tz = (int) Math.floor(t.z);
        int[] best = null; double bs = -1e9;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int cx = tx + dx, cz = tz + dz;
                if (bad.test(cx, cz)) continue;
                double mx = cx + 0.5, mz = cz + 0.5;
                if (overlaps(cx, cz, t.x, t.z, 0.3) || overlaps(cx, cz, b.x, b.z, 0.3)) continue;
                double dBot = eyeDist(mx, gy + 1, mz);
                double flatBot = Math.hypot(mx - b.x, mz - b.z);
                double dT = Math.hypot(mx - t.x, mz - t.z);
                if (dBot > maxBot || flatBot < minBot || dT > 2.4) continue;
                double score = -Math.abs(dT - 1.1) * 2.0 + flatBot * 0.35 + (w.hasBlock(cx, gy, cz) ? 1.5 : 0) + r.nextDouble() * 0.2;
                if (extra != null) { double x = extra.apply(cx, cz); if (x == Double.NEGATIVE_INFINITY) continue; score += x; }
                if (score > bs) { bs = score; best = new int[]{cx, cz}; }
            }
        }
        return best;
    }

    private static boolean overlaps(int cx, int cz, double px, double pz, double hw) {
        return px + hw > cx && px - hw < cx + 1 && pz + hw > cz && pz - hw < cz + 1;
    }

    // ------------------------------------------------------------------ main loop

    private final Nav nav = new Nav();

    public void tick() {
        tick++;
        b.noSlow = tier.max() || Opts.noSlow;
        b.jump = false; b.fwd = 0; b.strafe = 0;
        if (abilityCd > 0) abilityCd--;
        if (cooldown > 0) cooldown--;
        if (pearlCd > 0) pearlCd--;
        if (healCd > 0) healCd--;
        if (retreatCd > 0) retreatCd--;
        if (!b.haveFix || b.dead) { state = "dead/loading"; return; }

        if (mode == Mode.NPC) { npcTick(); return; }

        // obstacle recovery: the server keeps pulling us back (wall, fence, wrong floor height) -> jump and sidestep
        if (tick % 20 == 0) {
            int recent = b.corrections - corrAt; corrAt = b.corrections;
            if (recent >= 4 && stuckTicks == 0) { stuckTicks = 18; stuckDir = r.nextBoolean() ? 1 : -1; dStuck++; }
        }
        if (stuckTicks > 0) {
            stuckTicks--; state = "unstick";
            b.fwd = 1; b.strafe = stuckDir; b.wantSprint = true; b.jump = b.onGround;
            return;
        }
        trackHealth();
        if (totemStep > 0) { totem(); return; }
        if (invCd > 0) invCd--;
        else if (healTicks == 0 && !b.usingItem) {          // hotbar management: refill an emptied consumable slot from the inventory
            int[] rf = inv.pollRefill();
            if (rf != null) { b.containerSwap(rf[0], rf[1]); invCd = 8; }
        }

        if (order == Order.IDLE) { state = "idle"; b.wantSprint = false; return; }
        if (order == Order.FOLLOW) { followTick(); return; }

        World.Ent t = pickTarget();
        if (t != null) { dTicks++; double rd = reachDist(t); if (rd <= 3.0) dReach++; else if (rd > 8) dFar++; }
        if (t == null) { state = "searching"; b.wantSprint = false; idleLook(); return; }
        if (react > 0) { react--; state = "reacting"; faceTarget(t, 0.5); return; }

        // heal (potion bots heal with splash potions inside PotLogic)
        if ((mode != Mode.POT && mode != Mode.NETHPOT) || pot.broke()) {
            if (healTicks == 0 && healCd == 0 && b.health <= tier.healAt() && has(S_HEAL) && (flat(t) >= Opts.healSafeDist || b.health <= Opts.healPanic) && r.nextDouble() < (tier.max() ? 1.0 : 0.12)) {
                healTicks = 36;
                ranged.interrupt(); shield.reset();
            }
            if (healTicks > 0) { healTicks--; heal(t); return; }
        }
        if (pearlTick(t)) return;

        dispatch(t);
        // a wall between us and the target: walk around it (only when the mode wants to advance and the blocks are known)
        if (nav.assist(b, w, t, tick)) state = state + "+nav";
    }

    private void dispatch(World.Ent t) {
        switch (mode) {
            case CRYSTAL -> crystal.tick(t);
            case ANCHOR -> anchor.tick(t);
            case MACE -> mace(t);
            case MACE_PRO -> maceLogic.tick(t);
            case SMP, DIAMOND_SMP -> { if (smpPots() && pot.support(t)) return; smp(t); }
            case ROCKET_MACE -> rocket(t, 22);
            case ELYTRA -> rocket(t, 12);
            case POT, NETHPOT -> pot.tick(t);
            case CART -> cart.tick(t);
            case SHIELD -> shield.tick(t);
            case SPEAR -> spear(t);
            case AXE_SWORD -> axeSword(t);
            case PRESSURE -> { aggr = true; try { melee(t); } finally { aggr = false; } }
            case UHC -> { if (trap.tick(t)) return; if (ranged.busy() || flat(t) > 12 || trap.enemyStuck() || trap.lavaHot()) ranged.tick(t); else melee(t); }
            case TRAPPER -> { if (trap.tick(t)) return; melee(t); }
            case BOW, CROSSBOW, TRIDENT -> ranged.tick(t);
            default -> melee(t);
        }
    }

    /** Controller "follow me": walk toward the owner, sprint when far, stop at ~3 blocks. */
    private void followTick() {
        World.Ent o = null;
        String f = focus;
        if (f != null) for (World.Ent e : w.ents.values()) if (e.player && e.name.equalsIgnoreCase(f)) { o = e; break; }
        if (o == null) { state = "follow: нет владельца в зоне видимости"; b.wantSprint = false; idleLook(); return; }
        double d = flat(o);
        double[] a = angTo(o.x, o.y + 1.2, o.z);
        b.aim(a[0], Math.max(-20, Math.min(20, a[1])), Math.max(10, tier.aimSpeed()), 0.5);
        if (d > 3.2) { b.fwd = 1; b.wantSprint = d > 6; } else b.wantSprint = false;
        state = "follow";
    }

    private void idleLook() {
        if (tick % 40 == 0) b.aim(b.yaw + (r.nextDouble() - 0.5) * 120, 0, 6, 1);
    }

    void faceTarget(World.Ent t, double speedMul) {
        double lead = Double.parseDouble(System.getProperty("lead", "0"));
        double[] ap = aimPoint(t);
        double[] a = angTo(ap[0] + t.velX(w.now) * lead, ap[1], ap[2] + t.velZ(w.now) * lead);
        b.aim(a[0], a[1], tier.aimSpeed() * speedMul, tier.aimNoise());
    }

    // ------------------------------------------------------------------ totem / heal / pearl

    /** A totem pop leaves exactly 1.0 hp; then a spare totem from slot 9 is moved to the offhand. */
    private void trackHealth() {
        float hp = b.health;
        if (Opts.totemRefill && lastHp > 1.5f && hp > 0 && Math.abs(hp - 1.0f) < 1e-3f && has(S_TOTEM)) {
            totemStep = 3; healTicks = 0; b.usingItem = false; ranged.interrupt(); shield.reset();
        }
        lastHp = hp;
    }

    private void totem() {
        state = "totem";
        b.wantSprint = false;
        switch (totemStep) {
            case 3 -> select(S_TOTEM);
            case 2 -> { b.swapOffhand(); consume(S_TOTEM); }
            default -> { }
        }
        totemStep--;
    }

    private void heal(World.Ent t) {
        state = "healing";
        select(S_HEAL);
        b.wantSprint = false;
        // back away from the enemy while eating
        double[] a = angTo(t.x, b.y + EYE, t.z);
        b.aim(a[0], 5, tier.aimSpeed(), tier.aimNoise());
        b.fwd = flat(t) < 6 ? -0.6f : 0;
        if (healTicks == 34 || healTicks == 17) b.startUse(); // the server ignores a repeated use while already eating
        if (healTicks == 0) { b.usingItem = false; select(S_WEAPON); healCd = 0; consume(S_HEAL); }
    }

    /** PEARL mode: throw a pearl to close a big gap, or to run away when low. Returns true if this tick was used. */
    private boolean pearlTick(World.Ent t) {
        if (mode != Mode.PEARL) return false;
        if (pearlStep == 0) {
            if (pearlCd > 0 || b.gliding || b.usingItem || !has(S_PEARL)) return false;
            double flat = flat(t);
            boolean escape = b.health <= tier.healAt() + 2 && flat < 6 && r.nextInt(8) == 0;
            boolean engage = flat > 14 && flat < 45 && r.nextInt(25) == 0;
            if (!escape && !engage) return false;
            pearlEscape = escape; pearlStep = 1; pearlWait = 0;
        }
        state = pearlEscape ? "pearl/escape" : "pearl/engage";
        select(S_PEARL);
        b.wantSprint = false;
        double yaw, d, h;
        if (pearlEscape) {
            yaw = Body.yawTo(b.x - t.x, b.z - t.z); d = 16; h = b.groundY - (b.y + EYE);
        } else {
            yaw = Body.yawTo(t.x - b.x, t.z - b.z); d = Math.max(4, flat(t) - 1.5); h = t.y - (b.y + EYE);
        }
        Ballistics.Shot s = Ballistics.solve(d, h, 1.5, 0.03, 0.99);
        if (s == null) { pearlStep = 0; pearlCd = 40; return false; }
        b.aim(yaw, s.pitch(), tier.aimSpeed(), tier.aimNoise() * 0.5);
        pearlWait++;
        if (pearlWait > 1 && (b.angleError(yaw, s.pitch()) < 3 || pearlWait > 14)) {
            b.useItem(); consume(S_PEARL);
            pearlCd = 24 + r.nextInt(60);
            pearlStep = 0;
        }
        return true;
    }

    // ------------------------------------------------------------------ melee (sword / axe / smp / fallback)

    void melee(World.Ent t) { melee(t, tier.reach(), cooldownTicks()); }

    /** Teammate players (other bots) standing within r blocks of the target. */
    private int matesNear(World.Ent t, double r) {
        int n = 0;
        for (World.Ent e : w.ents.values()) {
            if (!e.player || e == t || e.name.equalsIgnoreCase(selfName) || !friends.contains(e.name.toLowerCase())) continue;
            if (Math.hypot(e.x - t.x, e.z - t.z) < r) n++;
        }
        return n;
    }

    /** Push away from teammates that stand inside us; returns {forward, strafe} in the bot's own axes. */
    private double[] separation() {
        double px = 0, pz = 0;
        for (World.Ent e : w.ents.values()) {
            if (!e.player || e.name.equalsIgnoreCase(selfName) || !friends.contains(e.name.toLowerCase())) continue;
            double dx = b.x - e.x, dz = b.z - e.z, d2 = dx * dx + dz * dz;
            if (d2 < 1.21 && d2 > 1e-4) { px += dx / d2; pz += dz / d2; }
        }
        if (px == 0 && pz == 0) return null;
        double yr = Math.toRadians(b.yaw);
        return new double[]{px * -Math.sin(yr) + pz * Math.cos(yr), px * Math.cos(yr) + pz * Math.sin(yr)};
    }

    void melee(World.Ent t, double reach, double cdTicks) {
        double dist = reachDist(t);
        double near = Math.max(3.2, reach + 0.3);
        int mates = matesNear(t, 8.0);
        select(weaponRole);
        faceTarget(t, 1.0);
        state = aggr ? "pressure" : "melee";

        // strafe pattern
        if (--strafeTimer <= 0) {
            strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(12) - 6);
            if (r.nextBoolean()) strafeDir = -strafeDir;
        }
        double flat = flat(t);
        if (flat > near) { b.fwd = 1; b.wantSprint = true; if (flat > 6 && b.onGround && r.nextInt(14) == 0) b.jump = true; }
        else if (flat > 1.8) { b.fwd = 1; b.strafe = strafeDir * 0.8f; b.wantSprint = true; }
        else { b.fwd = -0.2f; b.strafe = strafeDir; b.wantSprint = false; }
        // spacing (axe, smp): back off while the weapon recharges, rush in right before the next swing
        boolean spacing = (mode == Mode.AXE || mode == Mode.SMP || mode == Mode.DIAMOND_SMP) && mates == 0 && !combo.active();
        if (spacing && cooldown > 5 && flat < near + 0.4) { b.fwd = flat < 2.2 ? -1 : 0; b.strafe = strafeDir; b.wantSprint = false; }
        else if (spacing && cooldown <= 5 && flat > reach - 0.2) { b.fwd = 1; b.wantSprint = true; }
        // swarm: far from the target, run to this bot's own angle around it instead of queueing behind teammates
        if (mates >= 2 && flat > near + 1.5) {
            double ang = Swarm.ring(selfName);
            double[] ra = angTo(t.x + Math.cos(ang) * 2.4, b.y + 0.4, t.z + Math.sin(ang) * 2.4);
            b.aim(ra[0], 4, tier.aimSpeed(), tier.aimNoise());
            b.fwd = 1; b.wantSprint = true; b.strafe = 0;
            state = "melee/ring";
        }
        if (aggr && mates == 0) {                          // pressure: stay on the enemy, sidestep less, never stop sprinting at range
            b.strafe *= 0.5f;
            if (flat > 1.4 && !combo.active()) { b.fwd = 1; b.wantSprint = true; }
        }
        double[] sep = separation();
        if (sep != null) {
            b.fwd = (float) Math.max(-1, Math.min(1, b.fwd + sep[0] * 0.6));
            b.strafe = (float) Math.max(-1, Math.min(1, b.strafe + sep[1] * 0.9));
        }

        combo.apply(b);                                    // W-tap / S-tap / strafe flip after the last hit
        // crit timing: hit while falling
        if (critWanted && b.onGround && cooldown <= 3 && dist < 3.6) { b.jump = true; b.wantSprint = false; }
        // Sprint state at the moment of a crit (ported from Expensive's AttackAura sprintTicks). The attack packet leaves before this
        // tick's sprint command, so the server judges the hit by the flag set on the PREVIOUS tick. A crit needs sprint OFF (vanilla):
        // keep it off for the whole jump, not only on the take-off tick (melee() turns sprint back on every tick otherwise).
        if (Opts.sprintReset && critWanted && (!b.onGround || (cooldown <= 3 && dist < 3.6))) b.wantSprint = false;

        double[] ap = aimPoint(t);
        double[] a = angTo(ap[0], ap[1], ap[2]);
        double err = b.angleError(a[0], a[1]);
        boolean ready = cooldown <= 0 && dist <= reach && err < 14;
        boolean falling = !b.onGround && b.vy < -0.05;
        boolean critOk = !critWanted || (falling && !(Opts.sprintReset && b.sprinting)) || critWait > 14;
        if (ready && !critOk) critWait++;
        if (ready && critOk && (mates == 0 || Swarm.reserveHit(t.id, 9))) {      // one swing per invulnerability window
            if (r.nextDouble() < tier.whiffChance()) b.swing(); else b.attack(t.id);
            cooldown = (int) Math.ceil(cdTicks + r.nextInt(tier.hitDelayMax() + 1));
            afterHit(flat);
            if (mode == Mode.AXE_SWORD) { if (weaponRole == S_SECOND) axeArmed = false; else swordHits++; }
        }
    }

    /** Pick the combo and the hit type (sprint hit or jump crit) for the next swing. */
    void afterHit(double flat) {
        combo.onHit(r, tier, flat, strafeDir, aggr);
        if (combo.kind() == Combo.Kind.STRAFE || combo.kind() == Combo.Kind.ORBIT) strafeDir = combo.dir();
        boolean axeSwing = mode == Mode.AXE || (mode == Mode.AXE_SWORD && weaponRole == S_SECOND);
        double crit = axeSwing ? Math.max(tier.critChance(), 0.6) : tier.critChance();   // an axe crit is worth the wait
        boolean sprintHit = combo.sprintNext() && r.nextDouble() < SPRINT_HIT * (aggr ? 2.0 : 1.0);   // otherwise the tap only resets sprint and a jump crit follows
        critWanted = combo.critNext() || (!sprintHit && r.nextDouble() < crit);
        critWait = 0;
    }

    // ------------------------------------------------------------------ smp (sword + golden apples: kite when low)

    private void smp(World.Ent t) {
        double flat = flat(t);
        boolean low = b.health <= tier.healAt() && b.health > Opts.healPanic && has(S_HEAL) && healCd == 0;
        if (retreat > 0 || (low && retreatCd == 0 && flat < Opts.healSafeDist)) {
            if (retreat == 0) retreat = 30;
            retreat--;
            if (retreat == 0 || flat >= Opts.healSafeDist + 3) { retreat = 0; retreatCd = 90; }
            state = "smp/retreat";
            select(S_WEAPON);
            b.aim(Body.yawTo(b.x - t.x, b.z - t.z), 0, tier.aimSpeed(), tier.aimNoise());   // run away, then the heal logic eats
            b.fwd = 1; b.strafe = 0; b.wantSprint = true;
            if (b.onGround && r.nextInt(12) == 0) b.jump = true;
            return;
        }
        melee(t);
    }

    // ------------------------------------------------------------------ axe + sword (axe opener, then sword)

    /**
     * Swapping to a different item resets the attack charge, so the axe is only worth it as an opener: the bot holds it
     * while it walks up (it charges for the 20 ticks on the way), lands one big hit, swaps to the sword (charge time 12.5
     * instead of waiting 20) and keeps the sword until the enemy is far away again (it fled, healed, we respawned).
     */
    private void axeSword(World.Ent t) {
        double flat = flat(t);
        if (!has(S_SECOND)) { weaponRole = S_WEAPON; melee(t); return; }
        if (!axeArmed && (flat > 9 || swordHits >= 8)) { axeArmed = true; swordHits = 0; }
        int want = axeArmed ? S_SECOND : S_WEAPON;
        if (want != weaponRole) {
            weaponRole = want;
            cooldown = (int) Math.ceil(want == S_SECOND ? 20 : 12.5);      // the swap restarts the charge
        }
        melee(t, tier.reach(), axeArmed ? 20 : 12.5);
        state = axeArmed ? "axe-opener" : "axe-sword/sword";
    }

    // ------------------------------------------------------------------ npc dummy

    /** NPC: stands still, watches the nearest player and (optionally) answers hits with its fists. Never heals or swaps items. */
    private void npcTick() {
        state = "npc";
        World.Ent t = pickTarget();
        float hp = b.health;
        if (hp < npcHp - 0.5f && hp > 0) npcAggro = 100;
        npcHp = hp;
        if (react > 0) react--;
        if (t == null) { idleLook(); return; }
        if (Opts.npcFight && npcAggro > 0) {
            npcAggro--;
            melee(t, 2.6, 12);
            state = "npc/fight";
            return;
        }
        if (flat(t) < 14) faceTarget(t, 0.3);
    }

    // ------------------------------------------------------------------ spear (poke from range, step back, repeat)

    private void spear(World.Ent t) {
        double reach = Math.min(Opts.spearReach, tier.reach() + 1.2);
        double dist = reachDist(t), flat = flat(t);
        double ideal = Math.max(2.4, reach - 0.6);
        int mates = matesNear(t, 8.0);
        select(S_WEAPON);
        faceTarget(t, 1.0);
        state = "spear";
        if (--strafeTimer <= 0) {
            strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(12) - 6);
            if (r.nextBoolean()) strafeDir = -strafeDir;
        }
        if (flat > reach + 0.8) { b.fwd = 1; b.wantSprint = true; if (flat > 6 && b.onGround && r.nextInt(14) == 0) b.jump = true; }
        else if (flat > ideal + 0.3) { b.fwd = 1; b.strafe = strafeDir * 0.7f; b.wantSprint = true; }
        else if (flat < ideal - 0.8) { b.fwd = -1; b.strafe = strafeDir; b.wantSprint = false; }   // too close: step back to poke distance
        else { b.fwd = 0; b.strafe = strafeDir; b.wantSprint = false; }
        combo.apply(b);

        double[] a = angTo(t.x, t.y + 1.2, t.z);
        double err = b.angleError(a[0], a[1]);
        if (cooldown <= 0 && dist <= reach && err < 10 && (mates == 0 || Swarm.reserveHit(t.id, 9))) {
            if (r.nextDouble() < tier.whiffChance()) b.swing(); else b.attack(t.id);
            cooldown = Opts.spearCooldown + r.nextInt(tier.hitDelayMax() + 1);
            // poke, then step back (S-tap); at the top tier alternate with a strafe flip
            pokes++;
            boolean runup = Opts.combo && Opts.spearRunup && Opts.comboOn(Combo.Kind.BAIT) && tier.ordinal() >= Tier.LT2.ordinal();
            if (Opts.combo && tier.max() && (pokes % 3) == 0 && Opts.comboOn(Combo.Kind.STRAFE)) combo.start(Combo.Kind.STRAFE, 6, -strafeDir);
            else if (runup && (tier.max() ? (pokes % 3) == 1 : r.nextDouble() < 0.35)) combo.start(Combo.Kind.BAIT, 9, strafeDir);   // back off, then charge in
            else combo.start(Combo.Kind.S_TAP, 3, strafeDir);
            if (combo.kind() == Combo.Kind.STRAFE) strafeDir = combo.dir();
        }
    }

    // ------------------------------------------------------------------ mace (wind charge boost + smash)

    private void mace(World.Ent t) {
        state = "mace/" + phase;
        double flat = flat(t);
        switch (phase) {
            case 0 -> { // approach
                select(S_WEAPON);
                faceTarget(t, 1.0);
                b.fwd = flat > 2.5 ? 1 : 0; b.wantSprint = flat > 3;
                if (flat < 9 && flat > 1.2 && b.onGround && abilityCd == 0 && b.health > 4 && has(S_SECOND)) { phase = 1; phaseTicks = 0; combo.reset(); }
                else if (flat <= 2.0 && cooldown <= 0 && reachDist(t) <= tier.reach()) { b.attack(t.id); cooldown = 34; }
                combo.apply(b);
            }
            case 1 -> { // jump and fire wind charge under our feet at the apex
                phaseTicks++;
                boolean down = !b.onGround && b.vy < 0.12 && phaseTicks > 3;
                if (!down) faceTarget(t, 0.6);                    // while aiming at the floor faceTarget would pull the head back up (pitch never passes 82)
                if (phaseTicks == 1) { select(S_SECOND); b.jump = true; }
                if (down) {
                    b.aim(b.yaw, 90, 80, 0.2);
                    if (b.pitch > 82) { b.useItem(); consume(S_SECOND); phase = 2; phaseTicks = 0; abilityCd = 40 - tier.ordinal() * 2; }
                }
                if (phaseTicks > 12) phase = 0;
            }
            case 2 -> { // rising: swap to mace
                phaseTicks++;
                select(S_WEAPON);
                faceTarget(t, 0.7);
                airSteer(t);
                if (b.vy < 0 || phaseTicks > 30) { phase = 3; phaseTicks = 0; }
            }
            default -> { // dive
                phaseTicks++;
                select(S_WEAPON);
                faceTarget(t, 1.0);
                airSteer(t);
                if (cooldown <= 0 && reachDist(t) <= tier.reach() && b.vy < -0.1 && b.y - b.groundY >= 1.5) {
                    b.attack(t.id); cooldown = 34; phase = 0;
                    combo.start(Combo.Kind.S_TAP, 4, strafeDir);   // smash, then back off while the mace recharges
                }
                if (b.onGround) phase = 0;
            }
        }
    }

    private void airSteer(World.Ent t) {
        b.fwd = flat(t) > 1.0 ? 1 : 0;
        b.wantSprint = false;
    }

    // ------------------------------------------------------------------ rocket mace / elytra

    private void rocket(World.Ent t, int altitude) {
        state = (mode == Mode.ELYTRA ? "elytra/" : "rocket/") + phase;
        double flat = flat(t);
        double alt = b.y - b.groundY;
        switch (phase) {
            case 0 -> { // approach on foot, take off when in range
                select(S_WEAPON);
                faceTarget(t, 1.0);
                b.fwd = 1; b.wantSprint = true;
                if (flat < 16 && flat > 4 && b.onGround && abilityCd == 0 && has(S_SECOND)) { phase = 1; phaseTicks = 0; ability = 2 + r.nextInt(2); }
                else if (flat <= 2.8 && cooldown <= 0 && reachDist(t) <= tier.reach()) { b.attack(t.id); cooldown = (int) cooldownTicks(); }
            }
            case 1 -> { // jump, open elytra on the way down
                phaseTicks++;
                if (phaseTicks == 1) b.jump = true;
                if (!b.onGround && b.vy < -0.05 && !b.gliding) { b.startGliding(); phase = 2; phaseTicks = 0; }
                if (phaseTicks > 20) phase = 0;
            }
            case 2 -> { // climb with fireworks
                phaseTicks++;
                select(S_SECOND);
                b.aim(Body.yawTo(t.x - b.x, t.z - b.z), -62, 30, 0.3);
                if (b.boostTicks <= 0 && ability > 0 && alt < altitude && b.pitch < -40) { b.useItem(); consume(S_SECOND); b.boostTicks = 22; ability--; }
                if (!b.gliding) { phase = 0; abilityCd = 30; }
                if ((alt >= altitude && b.boostTicks <= 0) || (ability == 0 && b.boostTicks <= 0) || phaseTicks > 90) { phase = 3; phaseTicks = 0; }
            }
            default -> { // dive onto the target
                phaseTicks++;
                select(S_WEAPON);
                double dx = t.x - b.x, dz = t.z - b.z;
                double tp = Body.pitchTo(dx, t.y + 1.0 - b.y, dz);
                b.aim(Body.yawTo(dx, dz), Math.max(-20, Math.min(70, tp)), 35, tier.aimNoise() * 0.5);
                if (cooldown <= 0 && reachDist(t) <= tier.reach()) { b.attack(t.id); cooldown = (int) cooldownTicks(); }
                if (!b.gliding) { phase = 0; abilityCd = 60; }
                if (phaseTicks > 120) { phase = 0; abilityCd = 60; }
            }
        }
    }
}
