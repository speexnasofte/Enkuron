package dev.duelforge.ai;

/**
 * Pot PvP: melee fighter that runs away while throwing splash healing potions at its own feet and occasionally throws a
 * splash harming potion at the enemy. There is no inventory tracking, so after many throws without recovering the bot
 * assumes it is out of potions and falls back to golden apples (see {@link #broke()}).
 */
final class PotLogic {
    private final Brain br;
    private int potCd, harmTicks, throwsInRow, buffCd, buffStep;
    private boolean broke;

    PotLogic(Brain br) { this.br = br; }

    void reset() { potCd = 0; harmTicks = 0; throwsInRow = 0; broke = false; buffCd = 0; buffStep = 0; }

    boolean broke() { return broke; }

    void tick(World.Ent t) {
        if (support(t)) return;
        br.melee(t);
    }

    /**
     * Everything potion-related (heal at our feet, buffs, harming throw). Returns true when it used this tick; false = the
     * mode's own fight logic runs (melee for POT/NETHPOT, sword + apple retreat for SMP / Diamond SMP).
     */
    boolean support(World.Ent t) {
        final Body b = br.b;
        if (potCd > 0) potCd--;
        if (buffCd > 0) buffCd--;
        boolean low = b.health <= br.tier.healAt() + 5 && b.health < 19.5f;
        if (!low) throwsInRow = 0;

        if (low && !broke) { heal(t); return true; }
        if (buff(t)) return true;
        if (harmTicks > 0) { harmTicks--; if (br.has(Brain.S_THIRD) && harm(t)) return true; }
        double flat = br.flat(t);
        if (flat > 3.0 && flat < 7 && potCd == 0 && br.r.nextInt(40) == 0 && b.health > br.tier.healAt() + 6
                && (!smp() || br.kitHas(Brain.S_THIRD, "splash_potion"))) harmTicks = 10;
        return false;
    }

    private boolean smp() { return br.mode == Mode.SMP || br.mode == Mode.DIAMOND_SMP; }

    /** NETHPOT: open the fight with splash speed and strength at our own feet, refresh every minute. */
    private boolean buff(World.Ent t) {
        if ((br.mode != Mode.NETHPOT && !smp()) || buffCd > 0) return false;
        int role = buffStep == 0 ? Brain.S_FOURTH : Brain.S_FIFTH;
        if (!br.has(role) || (smp() && !br.kitHas(role, "splash_potion"))) { buffCd = 1200; buffStep = 0; return false; }
        if (buffStep == 0 && br.flat(t) < 5) return false;
        final Body b = br.b;
        br.state = "pot/buff";
        boolean sw = br.select(buffStep == 0 ? Brain.S_FOURTH : Brain.S_FIFTH);
        b.aim(b.yaw, 88, br.tier.aimSpeed() * 1.5, 0.2);
        b.wantSprint = false;
        if (!sw && potCd == 0 && b.pitch > 80) {
            b.useItem(); br.consume(buffStep == 0 ? Brain.S_FOURTH : Brain.S_FIFTH);
            potCd = 6;
            if (++buffStep >= 2) { buffStep = 0; buffCd = 1200; }
        }
        return true;
    }

    private void heal(World.Ent t) {
        final Body b = br.b;
        br.state = "pot/heal";
        if (!br.has(Brain.S_SECOND)) { broke = true; return; }
        br.select(Brain.S_SECOND);
        // run away from the enemy while looking at the ground; the potion lands around our feet
        double yawAway = Body.yawTo(b.x - t.x, b.z - t.z);
        b.aim(yawAway, 88, br.tier.aimSpeed() * 1.5, 0.2);
        b.fwd = 1; b.wantSprint = true;
        if (potCd == 0 && b.pitch > 80 && br.holding(Brain.S_SECOND)) {
            b.useItem(); br.consume(Brain.S_SECOND);
            potCd = 6 + br.r.nextInt(4);
            if (++throwsInRow >= 10) { broke = true; throwsInRow = 0; }
        }
    }

    private boolean harm(World.Ent t) {
        final Body b = br.b;
        br.state = "pot/harm";
        boolean sw = br.select(Brain.S_THIRD);
        // thrown potions get a -20 degree launch offset, so aim 20 degrees further down at the enemy's feet
        double[] a = br.angTo(t.x, t.y + 0.1, t.z);
        double pitch = Math.min(90, a[1] + 20);
        b.aim(a[0], pitch, br.tier.aimSpeed(), br.tier.aimNoise());
        if (!sw && b.angleError(a[0], pitch) < 6) {
            b.useItem(); br.consume(Brain.S_THIRD);
            potCd = 10; harmTicks = 0;
            return false;
        }
        return true;
    }
}
