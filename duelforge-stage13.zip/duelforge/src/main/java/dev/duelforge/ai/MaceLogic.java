package dev.duelforge.ai;

import java.util.Random;

/**
 * MACE_PRO. A smash hit is worth 4 extra damage per block fallen (after the first 1.5), so the whole mode is about getting
 * high and landing on the enemy:
 * <ul>
 *   <li><b>Jump launch</b>: jump, wind charge under the feet at the top of the jump (the big launch).</li>
 *   <li><b>Ground launch</b>: no jump, charge straight down at the floor; faster, used when the enemy is already close.</li>
 *   <li><b>Timing</b>: it launches when the mace is about to be recharged (cooldown <= 18 ticks), so the smash is ready on
 *       arrival instead of wasting the height.</li>
 *   <li><b>Aim</b>: during the fall the bot predicts where the enemy will be when it lands (fall time from its own height
 *       and speed) and steers there, instead of chasing where the enemy is now.</li>
 *   <li><b>Minimum fall</b>: no smash from a short fall ({@link Opts#maceMinFall}): the bot keeps falling and takes a
 *       bigger hit when the enemy is still under it.</li>
 *   <li><b>Wind Burst</b>: if the mace has that enchantment the smash itself launches the bot again, so it stays in the
 *       air and chains smashes instead of going back to the ground.</li>
 * </ul>
 * Hotbar: 1 mace, 2 wind charges, 3 golden apples.
 */
final class MaceLogic {
    private final Brain br;
    private int phase, ticks, variant;
    private double apexY;

    MaceLogic(Brain br) { this.br = br; }

    void reset() { phase = 0; ticks = 0; apexY = 0; }

    private boolean windBurst() { return br.kitItem(Brain.S_WEAPON).contains("wind_burst"); }

    /** Ticks until a body at height h above the enemy, moving with vertical speed vy, reaches it (vanilla gravity). */
    static int fallTicks(double h, double vy) {
        if (h <= 0) return 1;
        double y = 0, v = vy;
        for (int i = 1; i <= 60; i++) { v = (v - 0.08) * 0.98; y += v; if (y <= -h) return i; }
        return 60;
    }

    private void airSteer(World.Ent t, double ex, double ez) {
        Body b = br.b;
        double[] a = br.angTo(ex, t.y + 1.0, ez);
        b.aim(a[0], Math.max(-20, Math.min(70, a[1])), br.tier.aimSpeed(), br.tier.aimNoise() * 0.5);
        b.fwd = Math.hypot(ex - b.x, ez - b.z) > 0.7 ? 1 : 0;
        b.wantSprint = false;
    }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final Random r = br.r;
        double flat = br.flat(t);
        br.state = "mace+/" + phase + (phase == 1 ? (variant == 0 ? "/jump" : "/ground") : "");

        switch (phase) {
            case 0 -> {                                              // approach
                br.select(Brain.S_WEAPON);
                br.faceTarget(t, 1.0);
                b.fwd = flat > 2.5 ? 1 : 0; b.wantSprint = flat > 3;
                if (--br.strafeTimer <= 0) {
                    br.strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(12));
                    if (r.nextBoolean()) br.strafeDir = -br.strafeDir;
                }
                if (flat < 3.0 && br.cooldown > 0) b.strafe = br.strafeDir;
                boolean launch = b.onGround && br.abilityCd == 0 && b.health > 6 && br.has(Brain.S_SECOND)
                        && br.cooldown <= 18 && flat > 1.0 && flat < 11;
                if (launch) {
                    variant = flat < 4.5 || r.nextInt(4) == 0 ? 1 : 0;
                    phase = 1; ticks = 0; br.combo.reset();
                } else if (flat <= 2.0 && br.cooldown <= 0 && br.reachDist(t) <= tier.reach() && !br.has(Brain.S_SECOND)) {
                    b.attack(t.id); br.cooldown = 34;
                }
                br.combo.apply(b);
            }
            case 1 -> {                                              // launch
                ticks++;
                boolean down = variant == 1 || (!b.onGround && b.vy < 0.12 && ticks > 3);
                if (!down) br.faceTarget(t, 0.6);                  // aiming at the floor: faceTarget would pull the head back up
                if (variant == 0) {
                    if (ticks == 1) { br.select(Brain.S_SECOND); b.jump = true; }
                    if (down) {
                        b.aim(b.yaw, 90, 80, 0.2);
                        if (b.pitch > 82) fire();
                    }
                    if (ticks > 14) phase = 0;
                } else {
                    br.select(Brain.S_SECOND);
                    b.aim(b.yaw, 90, 80, 0.2);
                    if (ticks > 2 && b.pitch > 82 && b.onGround) fire();
                    if (ticks > 12) phase = 0;
                }
            }
            case 2 -> {                                              // rising: mace in hand, drift toward the enemy
                ticks++;
                br.select(Brain.S_WEAPON);
                apexY = Math.max(apexY, b.y);
                airSteer(t, t.x, t.z);
                if (b.vy < 0 || ticks > 35) { phase = 3; ticks = 0; }
            }
            case 3 -> {                                              // dive onto the point where the enemy will be
                ticks++;
                br.select(Brain.S_WEAPON);
                apexY = Math.max(apexY, b.y);
                int n = fallTicks(b.y - t.y, b.vy);
                int lead = Math.min(n, 14);
                double ex = t.x + t.velX(br.w.now) * lead, ez = t.z + t.velZ(br.w.now) * lead;
                airSteer(t, ex, ez);
                double fall = apexY - b.y;
                if (br.cooldown <= 0 && br.reachDist(t) <= tier.reach() && b.vy < -0.1 && fall >= Opts.maceMinFall) {
                    b.attack(t.id); br.cooldown = 34;
                    if (windBurst()) { phase = 2; ticks = 0; apexY = b.y; }   // the burst throws us up again: stay airborne
                    else { phase = 4; ticks = 0; br.combo.start(Combo.Kind.S_TAP, 4, br.strafeDir); }
                }
                if (b.onGround) { phase = 4; ticks = 0; }
                if (ticks > 80) phase = 0;
            }
            default -> {                                             // recover: back off while the mace recharges
                ticks++;
                br.select(Brain.S_WEAPON);
                br.faceTarget(t, 1.0);
                if (b.onGround) {
                    b.fwd = flat < 3.2 ? -1 : 0; b.strafe = br.strafeDir; b.wantSprint = false;
                    br.combo.apply(b);
                    if (br.cooldown <= 18 || ticks > 40) { phase = 0; ticks = 0; }
                } else {
                    airSteer(t, t.x, t.z);
                }
            }
        }
    }

    private void fire() {
        br.b.useItem();
        br.consume(Brain.S_SECOND);
        phase = 2; ticks = 0; apexY = br.b.y;
        br.abilityCd = Math.max(12, 40 - br.tier.ordinal() * 2);
    }
}
