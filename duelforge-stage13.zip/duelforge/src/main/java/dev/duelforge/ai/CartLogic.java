package dev.duelforge.ai;

import java.util.Random;

/**
 * TNT-minecart PvP: rail beside the target, TNT minecart on the rail, ignite it with flint and steel (right-click the
 * minecart), then run away - the fuse is about 4 seconds. Hotbar: 2 rails, 4 TNT minecart, 5 flint and steel.
 */
final class CartLogic {
    private final Brain br;
    private int phase;                 // 0 rail, 1 minecart, 2 wait + ignite, 3 retreat
    private boolean cellOk;
    private int cx, cz, since, placedAt, boomAt, placeCd, cartId = -1;

    CartLogic(Brain br) { this.br = br; }

    void reset() { phase = 0; cellOk = false; cartId = -1; placeCd = 0; }

    private void restart(int gy) {
        br.w.clearBlock(cx, gy, cz);
        phase = 0; cellOk = false; cartId = -1; placeCd = 20;
    }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final Random r = br.r;
        final World w = br.w;
        if (placeCd > 0) placeCd--;
        double flat = br.flat(t);
        int gy = (int) Math.floor(b.groundY + 1e-4);
        br.state = "cart/" + phase;

        if (phase == 3) {                                   // lit: run away from the cart
            World.Ent cart = w.ents.get(cartId);
            if (flat < 2.6) { br.melee(t); return; }
            double ax = cart != null ? cart.x : cx + 0.5, az = cart != null ? cart.z : cz + 0.5;
            b.aim(Body.yawTo(b.x - ax, b.z - az), 8, tier.aimSpeed(), tier.aimNoise());
            b.fwd = 1; b.wantSprint = true;
            if (w.now - boomAt > 100) { phase = 0; cellOk = false; cartId = -1; placeCd = 20; }
            return;
        }

        if (--br.strafeTimer <= 0) {
            br.strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(10));
            if (r.nextBoolean()) br.strafeDir = -br.strafeDir;
        }
        if (flat > 4.9) { b.fwd = 1; b.wantSprint = flat > 7; }
        else if (flat < 2.6) { b.fwd = -0.6f; b.wantSprint = false; }
        else { b.strafe = br.strafeDir; b.wantSprint = false; }

        double[] aim = br.angTo(t.x, t.y + 1.2, t.z);
        int act = 0;
        World.Ent cart = null;

        if (phase == 0) {
            if (placeCd <= 0 && flat < 9 && br.has(Brain.S_SECOND) && br.has(Brain.S_THIRD) && br.has(Brain.S_FOURTH)) {
                if (!cellOk) {
                    int[] cell = br.pickCell(t, 1.5, 4.3, gy, (x, z) -> false);
                    if (cell != null) { cx = cell[0]; cz = cell[1]; cellOk = true; since = br.tick; }
                }
                if (cellOk) { act = 1; aim = br.angTo(cx + 0.5, gy, cz + 0.5); }
            }
        } else if (phase == 1) {
            aim = br.angTo(cx + 0.5, gy + 0.2, cz + 0.5);
            if (placeCd <= 0) act = 2;
            if (br.tick - since > 80) restart(gy);
        } else {                                            // phase 2: find the minecart entity, then ignite it
            for (World.Ent e : w.ents.values()) {
                if (e.player || e.spawnTick < placedAt) continue;
                if (Math.abs(e.x - (cx + 0.5)) < 1.0 && Math.abs(e.z - (cz + 0.5)) < 1.0 && e.y > gy - 0.6 && e.y < gy + 1.5) { cartId = e.id; cart = e; break; }
            }
            if (cart != null) {
                act = 3;
                aim = br.angTo(cart.x, cart.y + 0.4, cart.z);
                if (br.reachBox(cart, 0.49, 0.7) > tier.reach() - 0.3) { b.fwd = 1; b.wantSprint = false; b.strafe = 0; }
            }
            if (br.tick - since > 80) restart(gy);
        }

        b.aim(aim[0], aim[1], tier.aimSpeed(), tier.aimNoise());
        double err = b.angleError(aim[0], aim[1]);

        switch (act) {
            case 1 -> {
                boolean sw = br.select(Brain.S_SECOND);
                if (!sw && err < 8 && br.eyeDist(cx + 0.5, gy, cz + 0.5) <= 4.3) {
                    b.useOnBlockTop(cx, gy - 1, cz);
                    w.setBlock(cx, gy, cz); br.consume(Brain.S_SECOND);
                    phase = 1; placeCd = 1 + r.nextInt(2); since = br.tick;
                }
            }
            case 2 -> {
                boolean sw = br.select(Brain.S_THIRD);
                if (!sw && err < 8 && br.eyeDist(cx + 0.5, gy + 0.2, cz + 0.5) <= 4.3) {
                    b.useOnBlockTop(cx, gy, cz); br.consume(Brain.S_THIRD);
                    phase = 2; placedAt = w.now; since = br.tick;
                }
            }
            case 3 -> {
                boolean sw = br.select(Brain.S_FOURTH);
                if (!sw && err < 10 && br.reachBox(cart, 0.49, 0.7) <= tier.reach()) {
                    b.interact(cart.id);
                    phase = 3; boomAt = w.now;
                }
            }
            default -> { }
        }
    }
}
