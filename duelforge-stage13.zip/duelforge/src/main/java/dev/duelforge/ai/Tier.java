package dev.duelforge.ai;

import java.util.Locale;

/** MCTiers-style skill ladder, LT5 (weakest) .. HT1 (strongest). */
public enum Tier {
    LT5, HT5, LT4, HT4, LT3, HT3, LT2, HT2, LT1, HT1,
    /** MAX: every human handicap removed (reaction, aim noise, whiffs, timing). Reach stays inside the vanilla 3.0 limit. */
    HT0;

    private double lerp(double a, double b) { return a + (b - a) * Math.min(ordinal(), 9) / 9.0; }

    public boolean max() { return this == HT0; }

    /** Max head turn speed, degrees per tick. */
    public double aimSpeed() { return max() ? 70 : lerp(7, 38); }
    /** Aim wobble (std-dev, degrees). */
    public double aimNoise() { return max() ? 0.04 : lerp(3.2, 0.25); }
    /** Ticks before the bot reacts to a new target / event. */
    public int reactTicks() { return max() ? 1 : (int) Math.round(lerp(10, 2)); }
    /** Extra random delay (ticks) added on top of the weapon cooldown. */
    public int hitDelayMax() { return (int) Math.round(lerp(7, 0)); }
    /** Chance that a swing is a visible whiff (swing without hit). */
    public double whiffChance() { return max() ? 0.0 : lerp(0.28, 0.02); }
    /** Ticks between strafe direction changes (average). */
    public int strafeTicks() { return max() ? 9 : (int) Math.round(lerp(45, 12)); }
    /** Probability the bot delivers a jump-crit instead of a plain hit. */
    public double critChance() { return max() ? 1.0 : lerp(0.0, 0.9); }
    /** Probability of a sprint-reset (w-tap) after a hit. */
    public double wtapChance() { return max() ? 1.0 : lerp(0.05, 0.95); }
    /** Health below which the bot eats a golden apple / retreats. */
    public float healAt() { return max() ? 10f : (float) lerp(4, 9); }
    /** Max reach in blocks (kept under the vanilla 3.0 limit on purpose). */
    public double reach() { return max() ? 2.98 : lerp(2.65, 2.95); }

    public static Tier parse(String s) {
        try { String u = s.trim().toUpperCase(Locale.ROOT); return u.equals("MAX") ? HT0 : valueOf(u); }
        catch (Exception e) { return HT3; }
    }
}
