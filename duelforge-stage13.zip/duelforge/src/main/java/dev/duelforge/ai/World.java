package dev.duelforge.ai;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * What the bot knows: other entities (position, type, smoothed horizontal velocity) and the blocks the bot itself
 * placed (obsidian, anchors) plus, since 2.3.0, the block classes of the chunks the server sent ({@link #chunks}).
 * Where a chunk is not loaded the old assumption (flat arena floor) still applies.
 */
public final class World {
    public static final class Ent {
        public final int id;
        public final UUID uuid;
        public double x, y, z;
        /** Entity-type registry id from add_entity (used to learn which id is the end crystal). */
        public int type = -1;
        public boolean player;
        public String name = "";
        public int seenTick, spawnTick, lastMove;
        public double vx, vz;

        Ent(int id, UUID uuid) { this.id = id; this.uuid = uuid; }

        /** Relative move (delta packets): updates a smoothed per-tick velocity. */
        public void moveTo(double nx, double ny, double nz, int tick) {
            int dt = Math.max(1, tick - lastMove);
            double k = dt <= 3 ? 0.5 : 1.0;
            vx = vx * (1 - k) + (nx - x) / dt * k;
            vz = vz * (1 - k) + (nz - z) / dt * k;
            x = nx; y = ny; z = nz;
            lastMove = tick; seenTick = tick;
        }

        /** Absolute teleport: position jumps, velocity is unknown. */
        public void setPos(double nx, double ny, double nz, int tick) {
            x = nx; y = ny; z = nz; vx = 0; vz = 0;
            lastMove = tick; seenTick = tick;
        }

        public double velX(int now) { return now - lastMove > 2 ? 0 : vx; }
        public double velZ(int now) { return now - lastMove > 2 ? 0 : vz; }
    }

    public final Map<Integer, Ent> ents = new HashMap<>();
    public final Map<UUID, String> names = new HashMap<>();
    /** Client tick counter of the owning connection; entity timestamps use this clock. */
    public int now;
    private final Set<Long> blocks = new HashSet<>();
    /** Blocks the server sent (chunk packets). Empty until chunks arrive; every query then answers "unknown". */
    public final ChunkStore chunks = new ChunkStore();

    public Ent add(int id, UUID uuid, int type, double x, double y, double z, int tick) {
        Ent e = new Ent(id, uuid);
        e.type = type;
        e.x = x; e.y = y; e.z = z;
        e.seenTick = tick; e.spawnTick = tick; e.lastMove = tick;
        String n = names.get(uuid);
        if (n != null) { e.player = true; e.name = n; }
        ents.put(id, e);
        return e;
    }

    public void setName(UUID u, String n) {
        names.put(u, n);
        for (Ent e : ents.values()) if (e.uuid.equals(u)) { e.player = true; e.name = n; }
    }

    public void removeName(UUID u) { names.remove(u); }

    // ---- blocks placed by this bot (optimistic: there is no block_update parsing) ----

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFFL);
    }

    public boolean hasBlock(int x, int y, int z) { return blocks.contains(key(x, y, z)); }
    public void setBlock(int x, int y, int z) { blocks.add(key(x, y, z)); }
    public void clearBlock(int x, int y, int z) { blocks.remove(key(x, y, z)); }

    // ---- terrain (from chunk packets) ----

    /** Class of the block at (x, y, z) ({@link BlockTable}), or {@link ChunkStore#UNKNOWN}. */
    public int blockAt(int x, int y, int z) { return chunks.get(x, y, z); }

    /**
     * Share (0..1) of the entity's box that an explosion at (cx, cy, cz) reaches, as vanilla computes it. 1.0 when the
     * terrain is not known or the target is out of the 12-block range anyway.
     */
    public double exposure(double cx, double cy, double cz, double ex, double ey, double ez) {
        double dx = cx - ex, dy = cy - ey, dz = cz - ez;
        if (dx * dx + dy * dy + dz * dz > 144.0) return 1.0;
        return chunks.seenPercent(cx, cy, cz, ex - 0.3, ey, ez - 0.3, ex + 0.3, ey + 1.8, ez + 0.3);
    }
}
