package dev.duelforge.ai;

/**
 * Player-sized box (0.6 x 1.8) against the full blocks of a {@link ChunkStore}. Vanilla order: Y first, then the larger
 * of X / Z. Only full cubes collide: slabs, stairs and other partial shapes are ignored (their height is not known), so
 * the server may still correct the bot there; unknown chunks do not collide either.
 */
public final class Collide {
    private Collide() {}

    public static final double HALF = 0.3, HEIGHT = 1.8;
    private static final double EPS = 1.0E-7;

    /** The movement that is possible from (x, y, z) when trying (dx, dy, dz). Unchanged components were not blocked. */
    public static double[] move(ChunkStore s, double x, double y, double z, double dx, double dy, double dz) {
        double[] r = {dx, dy, dz};
        r[1] = sweepY(s, x, y, z, dy);
        y += r[1];
        if (Math.abs(dx) >= Math.abs(dz)) {
            r[0] = sweepX(s, x, y, z, dx); x += r[0];
            r[2] = sweepZ(s, x, y, z, dz);
        } else {
            r[2] = sweepZ(s, x, y, z, dz); z += r[2];
            r[0] = sweepX(s, x, y, z, dx);
        }
        return r;
    }

    private static double sweepY(ChunkStore s, double x, double y, double z, double d) {
        if (d == 0) return d;
        int x0 = fl(x - HALF + EPS), x1 = fl(x + HALF - EPS), z0 = fl(z - HALF + EPS), z1 = fl(z + HALF - EPS);
        int y0 = fl(Math.min(y, y + d) - EPS), y1 = fl(Math.max(y + HEIGHT, y + HEIGHT + d) + EPS);
        for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++) for (int by = y0; by <= y1; by++) {
            if (!s.full(bx, by, bz)) continue;
            if (d > 0 && by >= y + HEIGHT - EPS) d = Math.min(d, by - (y + HEIGHT));
            else if (d < 0 && by + 1 <= y + EPS) d = Math.max(d, by + 1 - y);
        }
        return d;
    }

    private static double sweepX(ChunkStore s, double x, double y, double z, double d) {
        if (d == 0) return d;
        int x0 = fl(Math.min(x - HALF, x - HALF + d) - EPS), x1 = fl(Math.max(x + HALF, x + HALF + d) + EPS);
        int y0 = fl(y + EPS), y1 = fl(y + HEIGHT - EPS), z0 = fl(z - HALF + EPS), z1 = fl(z + HALF - EPS);
        for (int bx = x0; bx <= x1; bx++) for (int by = y0; by <= y1; by++) for (int bz = z0; bz <= z1; bz++) {
            if (!s.full(bx, by, bz)) continue;
            if (d > 0 && bx >= x + HALF - EPS) d = Math.min(d, bx - (x + HALF));
            else if (d < 0 && bx + 1 <= x - HALF + EPS) d = Math.max(d, bx + 1 - (x - HALF));
        }
        return d;
    }

    private static double sweepZ(ChunkStore s, double x, double y, double z, double d) {
        if (d == 0) return d;
        int z0 = fl(Math.min(z - HALF, z - HALF + d) - EPS), z1 = fl(Math.max(z + HALF, z + HALF + d) + EPS);
        int y0 = fl(y + EPS), y1 = fl(y + HEIGHT - EPS), x0 = fl(x - HALF + EPS), x1 = fl(x + HALF - EPS);
        for (int bz = z0; bz <= z1; bz++) for (int by = y0; by <= y1; by++) for (int bx = x0; bx <= x1; bx++) {
            if (!s.full(bx, by, bz)) continue;
            if (d > 0 && bz >= z + HALF - EPS) d = Math.min(d, bz - (z + HALF));
            else if (d < 0 && bz + 1 <= z - HALF + EPS) d = Math.max(d, bz + 1 - (z - HALF));
        }
        return d;
    }

    /**
     * Height of the highest full block top under the bot's footprint (the surface it would land on), searched up to 96
     * blocks down. NaN when the column is unknown or has no floor.
     */
    public static double floorY(ChunkStore s, double x, double y, double z) {
        int start = fl(y + 1.0E-3) - 1;
        int x0 = fl(x - HALF + EPS), x1 = fl(x + HALF - EPS), z0 = fl(z - HALF + EPS), z1 = fl(z + HALF - EPS);
        double best = Double.NaN;
        for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++) {
            for (int by = start; by >= start - 96; by--) {
                int c = s.get(bx, by, bz);
                if (c == ChunkStore.UNKNOWN) break;
                if (BlockTable.isFull(c)) { if (Double.isNaN(best) || by + 1 > best) best = by + 1; break; }
            }
        }
        return best;
    }

    /**
     * True when a partial block (slab, stairs, carpet ...) is at the bot's feet or right under them. Its height is unknown,
     * so the terrain model must not decide the floor there (it would drop the bot through the slab and the server would
     * pull it back every tick).
     */
    public static boolean onPartial(ChunkStore s, double x, double y, double z) {
        int by = fl(y + 1.0E-3);
        int x0 = fl(x - HALF + EPS), x1 = fl(x + HALF - EPS), z0 = fl(z - HALF + EPS), z1 = fl(z + HALF - EPS);
        for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++)
            if (s.get(bx, by, bz) == BlockTable.PARTIAL || s.get(bx, by - 1, bz) == BlockTable.PARTIAL) return true;
        return false;
    }

    private static int fl(double v) { return (int) Math.floor(v); }
}
