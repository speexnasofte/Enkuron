package dev.duelforge.ai;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Kits live in config/pvpbotlab/kits/<name>.kit (plain text, editable by hand). */
public final class KitStore {
    private KitStore() {}

    public static volatile Path dir = Path.of("config", "pvpbotlab", "kits");

    public static String sanitize(String n) {
        String s = n == null ? "" : n.trim().replaceAll("[^A-Za-z0-9_-]", "_");
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    public static List<String> names() {
        List<String> out = new ArrayList<>();
        try {
            if (!Files.isDirectory(dir)) return out;
            try (Stream<Path> s = Files.list(dir)) {
                s.map(p -> p.getFileName().toString()).filter(f -> f.endsWith(".kit"))
                        .forEach(f -> out.add(f.substring(0, f.length() - 4)));
            }
        } catch (IOException ignored) { }
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    public static Kit get(String name) {
        if (name == null) return null;
        for (String n : names()) {
            if (n.equalsIgnoreCase(name)) {
                try { return Kit.parse(n, Files.readAllLines(dir.resolve(n + ".kit"), StandardCharsets.UTF_8)); }
                catch (IOException e) { return null; }
            }
        }
        return null;
    }

    public static boolean save(Kit k) {
        try {
            Files.createDirectories(dir);
            Files.writeString(dir.resolve(sanitize(k.name) + ".kit"), k.serialize(), StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) { return false; }
    }

    public static boolean delete(String name) {
        Kit k = get(name);
        if (k == null) return false;
        try { return Files.deleteIfExists(dir.resolve(k.name + ".kit")); } catch (IOException e) { return false; }
    }

    /** Rename; fails if the target exists or the source does not. */
    public static boolean rename(String from, String to) {
        Kit k = get(from);
        String nn = sanitize(to);
        if (k == null || nn.isEmpty() || get(nn) != null) return false;
        String old = k.name;
        k.name = nn;
        if (!save(k)) return false;
        try { Files.deleteIfExists(dir.resolve(old + ".kit")); } catch (IOException ignored) { }
        return true;
    }
}
