package dev.duelforge.ai;

import java.util.ArrayList;
import java.util.List;

/**
 * UHC / TRAPPER tricks. Hotbar roles: 4 cobweb (S_THIRD), 5 lava bucket (S_FOURTH), 6 flint and steel (S_FIFTH),
 * 7 empty bucket (S_SIXTH).
 *
 * <ul>
 *   <li><b>Web</b>: a cobweb on the floor cell under the enemy (standing still) or on the cell it runs into (moving).</li>
 *   <li><b>Lava</b>: when the enemy is stuck in the web (or running away after one) the lava bucket goes on the cell next to it,
 *       the bot backs off from the flow and picks the lava up again a few seconds later.</li>
 *   <li><b>Fire</b>: flint and steel on cells around the enemy so the way out is closed.</li>
 *   <li><b>Water steal</b>: when the enemy runs, the empty bucket is aimed at its feet: if it placed water to put itself
 *       out or to cool the lava, the source goes into the bucket.</li>
 *   <li>When it burns itself (hp drops near its own lava) it pours the stolen water on its feet.</li>
 * </ul>
 *
 * Without chunk data everything here is a model: the bot knows only the blocks it placed itself and guesses the
 * rest from how the enemy moves (see {@link #enemyStuck()}). When the server's chunks are read ({@link World#chunks}) the
 * web is looked up instead of guessed: a broken or burnt web frees the enemy at once. Wrong guesses cost one wasted item use, never a crash.
 * Bucket and block placement follow vanilla: buckets use the item (ray from the eyes, so the bot aims at the floor point
 * under the cell), blocks and flint use the top face of the floor block.
 */
final class TrapLogic {
    /** Horizontal limit of a block / bucket target: the ray reach is 4.5 from the eye, the eye is 1.62 above the floor. */
    private static final double MAX_EYE = 4.3;
    /** Lava flows up to ~3 cells on a flat floor: stay farther than this from the source. */
    private static final double LAVA_SAFE = 3.0;

    private enum Act { NONE, WEB, LAVA, FIRE, SCOOP, STEAL, POUR }

    private final Brain br;
    private final List<int[]> webs = new ArrayList<>();            // {x, z, tick}
    private int webCd, lavaCd, fireCd, stealCd, pourCd, scoopCd;
    private boolean lavaFull = true;                                // the lava bucket still holds lava
    private boolean sixthFull;                                      // the 7th-slot bucket probably holds water
    private int sixthFullAt;
    private int lavaX, lavaZ, lavaAt = -1000;
    private int webX, webY, webZ, webAt = -1000;
    private int stuck, fires;
    private double lastDist = 99;
    private int lastDistAt;
    private boolean flee;
    private int probes, lastFleeAt;
    private float hpPrev = 20f;
    private int hurtAt = -1000, retreat;

    TrapLogic(Brain br) { this.br = br; }

    void reset() {
        webs.clear();
        webCd = lavaCd = fireCd = stealCd = pourCd = scoopCd = 0;
        lavaFull = true; sixthFull = br.kitItem(Brain.S_SIXTH).contains("water_bucket"); sixthFullAt = 0;
        lavaAt = webAt = -1000; probes = 0; lastFleeAt = -1000; stuck = 0; fires = 0; flee = false; lastDist = 99; hpPrev = 20f; hurtAt = -1000; retreat = 0;
    }

    /** The enemy stands in a web we placed and does not move: free hits for the bow. */
    boolean enemyStuck() { return stuck >= 3; }

    /** Lava is on the floor and still dangerous: the bot keeps its distance from it. */
    boolean lavaHot() { return !lavaFull && br.tick - lavaAt < 70; }

    private boolean ready(int role, String part) { return br.kitHas(role, part); }

    // ------------------------------------------------------------------ main

    /** Returns true when the trap logic used this tick (aim / movement / item). false = the normal mode logic runs. */
    boolean tick(World.Ent t) {
        final Body b = br.b;
        final World w = br.w;
        final int now = br.tick;
        if (webCd > 0) webCd--;
        if (lavaCd > 0) lavaCd--;
        if (fireCd > 0) fireCd--;
        if (stealCd > 0) stealCd--;
        if (pourCd > 0) pourCd--;
        if (scoopCd > 0) scoopCd--;
        webs.removeIf(x -> now - x[2] > 150);
        if (sixthFull && now - sixthFullAt > 150 && !br.kitItem(Brain.S_SIXTH).contains("water_bucket")) sixthFull = false;   // the guess expires
        if (!Opts.traps) return false;

        final int gy = (int) Math.floor(b.groundY + 1e-4);
        final double flat = br.flat(t), dist = br.reachDist(t);
        final double spd = Math.hypot(t.velX(w.now), t.velZ(w.now));

        // enemy running away: the distance grew by half a block over the last 6 ticks while it moves
        if (now - lastDistAt >= 6) { flee = flat - lastDist > 0.5 && spd > 0.1; lastDist = flat; lastDistAt = now; }
        if (flee) lastFleeAt = now; else if (now - lastFleeAt > 40) probes = 0;
        if (b.health < hpPrev - 0.9f) hurtAt = now;
        hpPrev = b.health;

        // enemy stuck in our web: it stands in the web cell, hardly moves, the web is fresh
        // (with chunk data: the block itself. Not in the first ticks: the server's block_update arrives after our placement.)
        int webCls = w.blockAt(webX, webY, webZ);
        boolean webGone = now - webAt > 4 && webCls != ChunkStore.UNKNOWN && webCls != BlockTable.WEB;
        if (webGone) webs.removeIf(x -> x[0] == webX && x[1] == webZ);   // a gone web is neither avoided nor counted as a trap
        boolean inWeb = now - webAt < 100 && !webGone && Math.hypot(t.x - (webX + 0.5), t.z - (webZ + 0.5)) < 1.0;
        stuck = inWeb && spd < 0.04 ? stuck + 1 : 0;

        // 1. lava next to the bot: leave the flow
        boolean nearLava = !lavaFull && now - lavaAt < 240 && Math.hypot(b.x - (lavaX + 0.5), b.z - (lavaZ + 0.5)) < LAVA_SAFE + 0.4;
        boolean burning = now - hurtAt < 20 && now - lavaAt < 240 && Math.hypot(b.x - (lavaX + 0.5), b.z - (lavaZ + 0.5)) < 5.0;
        if (burning && sixthFull && pourCd == 0 && ready(Brain.S_SIXTH, "bucket")) return run(Act.POUR, t, gy, 0, 0, flat);
        if (retreat > 0 || nearLava) {
            if (retreat > 0) retreat--;
            br.state = "trap/leave-lava";
            b.aim(Body.yawTo(b.x - (lavaX + 0.5), b.z - (lavaZ + 0.5)), 6, br.tier.aimSpeed(), br.tier.aimNoise());
            b.fwd = 1; b.wantSprint = true;
            return true;
        }

        // 2. pick the lava up again (the bucket is empty and the fight moved on)
        if (!lavaFull && now - lavaAt > 70 && scoopCd == 0 && ready(Brain.S_FOURTH, "bucket")) {
            if (now - lavaAt > 400) lavaFull = true;                      // lost: stop waiting for it
            else if (flat > 2.5) {
                double fl = Math.hypot(b.x - (lavaX + 0.5), b.z - (lavaZ + 0.5));
                if (fl > 4.1 || fl < 3.7) {                                // outside the flow (~3 cells) but inside the bucket reach
                    br.state = "trap/to-lava";
                    double[] a = br.angTo(lavaX + 0.5, gy, lavaZ + 0.5);
                    b.aim(a[0], a[1], br.tier.aimSpeed(), br.tier.aimNoise());
                    b.fwd = fl > 4.1 ? 1 : -1; b.wantSprint = false;
                    return true;
                }
                return run(Act.SCOOP, t, gy, lavaX, lavaZ, flat);
            }
        }

        // 3. steal water from a fleeing enemy
        if (Opts.waterSteal && flee && !sixthFull && stealCd == 0 && dist <= 4.2 && ready(Brain.S_SIXTH, "bucket")) {
            return run(Act.STEAL, t, gy, 0, 0, flat);
        }

        // 4. webs / lava / fire
        boolean trapped = stuck >= 4;
        if (Opts.trapWeb && webCd == 0 && dist >= 2.0 && dist <= 4.1 && ready(Brain.S_THIRD, "cobweb")) {
            int[] c = webCell(t, spd, gy);
            if (c != null) return run(Act.WEB, t, gy, c[0], c[1], flat);
        }
        if (Opts.trapLava && lavaCd == 0 && lavaFull && ready(Brain.S_FOURTH, "lava_bucket") && (trapped || (flee && now - webAt < 100))) {
            int[] c = lavaCell(t, spd, gy, trapped);
            if (c != null) return run(Act.LAVA, t, gy, c[0], c[1], flat);
            if (trapped) {                                                 // wrong distance for a safe throw: adjust it
                br.faceTarget(t, 1.0);
                b.fwd = flat > 3.9 ? 1 : flat < 3.3 ? -1 : 0; b.strafe = 0; b.wantSprint = false;
                br.state = "trap/range";
                return true;
            }
        }
        if (Opts.trapFire && fireCd == 0 && ready(Brain.S_FIFTH, "flint") && (now - lavaAt < 90 || trapped) && fires < 6) {
            int[] c = fireCell(t, gy);
            if (c != null) return run(Act.FIRE, t, gy, c[0], c[1], flat);
        }

        // 5. lava is down: do not walk into it. Sword bots wait, bow bots keep shooting (UHC)
        if (lavaHot()) {
            br.state = "trap/hold";
            br.faceTarget(t, 1.0);
            double dl = Math.hypot(b.x - (lavaX + 0.5), b.z - (lavaZ + 0.5));
            b.fwd = dl < LAVA_SAFE + 1.0 ? -1 : 0;
            b.strafe = br.strafeDir * 0.5f; b.wantSprint = false;
            return br.mode == Mode.TRAPPER;
        }

        // 6. do not run into our own web
        for (int[] x : webs) {
            if (Math.hypot(b.x - (x[0] + 0.5), b.z - (x[1] + 0.5)) < 1.25 && flat > 2.2) {
                br.state = "trap/avoid-web";
                b.aim(Body.yawTo(b.x - (x[0] + 0.5), b.z - (x[1] + 0.5)), 4, br.tier.aimSpeed(), br.tier.aimNoise());
                b.fwd = 1; b.wantSprint = false;
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ cell choice

    private boolean inWebList(int cx, int cz) {
        for (int[] x : webs) if (x[0] == cx && x[1] == cz) return true;
        return false;
    }

    /** Does the line from the bot's eye to the middle of a cell cross a web cell (other than that cell)? A bucket ray would stop there. */
    private boolean crossesWeb(int cx, int cz) {
        Body b = br.b;
        double tx = cx + 0.5, tz = cz + 0.5;
        for (int i = 1; i < 20; i++) {
            double f = i / 20.0, x = b.x + (tx - b.x) * f, z = b.z + (tz - b.z) * f;
            int px = (int) Math.floor(x), pz = (int) Math.floor(z);
            if ((px != cx || pz != cz) && inWebList(px, pz)) return true;
        }
        return false;
    }

    /** Web under a standing enemy, or on the cell it runs into in ~5 ticks. Never on top of the bot. */
    private int[] webCell(World.Ent t, double spd, int gy) {
        double lead = spd > 0.1 ? 5 : 0;
        double px = t.x + t.velX(br.w.now) * lead, pz = t.z + t.velZ(br.w.now) * lead;
        double len = Math.hypot(px - t.x, pz - t.z);
        if (len > 2.5) { px = t.x + (px - t.x) * 2.5 / len; pz = t.z + (pz - t.z) * 2.5 / len; }
        int cx = (int) Math.floor(px), cz = (int) Math.floor(pz);
        if (Math.hypot(cx + 0.5 - br.b.x, cz + 0.5 - br.b.z) < 1.4) return null;
        if (inWebList(cx, cz)) return null;
        if (br.eyeDist(cx + 0.5, gy, cz + 0.5) > MAX_EYE) return null;
        return new int[]{cx, cz};
    }

    /**
     * Lava cell. Stuck enemy: a cell beside its web that is 3..4 blocks from us (safe from the flow, inside the throw reach).
     * Running enemy: the cell it is about to run into. Cobweb cells are never used (a bucket does not fill a web).
     */
    private int[] lavaCell(World.Ent t, double spd, int gy, boolean trapped) {
        Body b = br.b;
        int bx = trapped ? webX : (int) Math.floor(t.x + t.velX(br.w.now) * 6);
        int bz = trapped ? webZ : (int) Math.floor(t.z + t.velZ(br.w.now) * 6);
        int[][] cand = trapped ? new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}} : new int[][]{{0, 0}};
        int[] best = null; double bd = -1;
        for (int[] d : cand) {
            int cx = bx + d[0], cz = bz + d[1];
            if (inWebList(cx, cz) || crossesWeb(cx, cz)) continue;
            double fb = Math.hypot(cx + 0.5 - b.x, cz + 0.5 - b.z);
            if (fb < LAVA_SAFE || br.eyeDist(cx + 0.5, gy, cz + 0.5) > MAX_EYE) continue;
            if (fb > bd) { bd = fb; best = new int[]{cx, cz}; }
        }
        return best;
    }

    /** A cell around the enemy for fire: not the lava, not a web, not near us, as far from the lava as possible. */
    private int[] fireCell(World.Ent t, int gy) {
        Body b = br.b;
        int tx = (int) Math.floor(t.x), tz = (int) Math.floor(t.z);
        int[] best = null; double bs = -1e9;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int cx = tx + dx, cz = tz + dz;
                if (inWebList(cx, cz) || (!lavaFull && cx == lavaX && cz == lavaZ)) continue;
                if (Math.hypot(cx + 0.5 - b.x, cz + 0.5 - b.z) < 2.4) continue;
                if (br.eyeDist(cx + 0.5, gy, cz + 0.5) > MAX_EYE) continue;
                double s = (lavaFull ? 0 : Math.hypot(cx - lavaX, cz - lavaZ)) + br.r.nextDouble() * 0.3;
                if (s > bs) { bs = s; best = new int[]{cx, cz}; }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ doing it

    private boolean run(Act act, World.Ent t, int gy, int cx, int cz, double flat) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final int now = br.tick;
        int role = switch (act) {
            case WEB -> Brain.S_THIRD;
            case LAVA, SCOOP -> Brain.S_FOURTH;
            case FIRE -> Brain.S_FIFTH;
            default -> Brain.S_SIXTH;
        };
        double[] a = switch (act) {
            case WEB, LAVA, FIRE -> br.angTo(cx + 0.5, gy, cz + 0.5);              // the floor point under the cell
            case SCOOP -> br.angTo(lavaX + 0.5, gy + 0.5, lavaZ + 0.5);            // the lava source itself
            case STEAL -> br.angTo(t.x, t.y + 0.3, t.z);                           // the enemy's feet
            default -> new double[]{b.yaw, 90};                                    // POUR: straight down
        };
        br.state = "trap/" + act.name().toLowerCase();
        b.aim(a[0], a[1], tier.aimSpeed() * 1.4, tier.aimNoise() * 0.5);
        b.wantSprint = false;
        if (act == Act.WEB || act == Act.FIRE || act == Act.STEAL) b.strafe = br.strafeDir * 0.6f;
        boolean sw = br.select(role);
        if (sw) return true;                                                       // let the server see the new slot first
        double err = b.angleError(a[0], a[1]);
        // blocks and flint send exact coordinates; a bucket uses a ray from the eyes (reach 4.5), so it must be aimed closely
        double tol = act == Act.WEB || act == Act.FIRE ? 8 : 1.5;
        if (err > tol) return true;

        switch (act) {
            case WEB -> {
                b.useOnBlockTop(cx, gy - 1, cz);
                br.consume(Brain.S_THIRD);
                webs.add(new int[]{cx, cz, now});
                webX = cx; webY = gy; webZ = cz; webAt = now; stuck = 0;
                webCd = 22 + br.r.nextInt(12);
            }
            case LAVA -> {
                b.useItem();
                lavaFull = false; lavaAt = now; lavaX = cx; lavaZ = cz;
                lavaCd = 160; retreat = 14; fires = 0;
            }
            case FIRE -> {
                b.useOnBlockTop(cx, gy - 1, cz);
                fires++; fireCd = 24 + br.r.nextInt(10);
            }
            case SCOOP -> {
                b.useItem();
                lavaFull = true; scoopCd = 30;                                      // optimistic: a miss just repeats once
            }
            case STEAL -> {
                b.useItem();
                stealCd = 8;
                // three probes per escape (its cell and the way ahead); then assume it was water after all and the bucket is full
                if (++probes >= 3 && (now - lavaAt < 160 || now - webAt < 100)) { sixthFull = true; sixthFullAt = now; probes = 0; }
            }
            case POUR -> {
                b.useItem();
                sixthFull = false; pourCd = 40;
            }
            default -> { }
        }
        return true;
    }
}
