package dev.duelforge.ai;

import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Block classes (see {@link BlockTable}) of the chunks the server sent. Memory: one byte per block, but a section that is
 * a single block type (all air, all stone ...) is stored as one byte. Coordinates are world block coordinates.
 * Everything answers "unknown" ({@link #UNKNOWN}) for chunks that are not loaded, so callers can fall back to the old
 * flat-floor assumption.
 */
public final class ChunkStore {
    public static final int UNKNOWN = -1;

    public static final class Chunk {
        /** Section index of the lowest section (-4 for a normal overworld, y = -64). */
        public final int minSec;
        private final byte[] uniform;
        private final byte[][] cls;

        public Chunk(int minSec, int sections) {
            this.minSec = minSec;
            this.uniform = new byte[sections];
            this.cls = new byte[sections][];
        }

        public int sections() { return uniform.length; }

        /** Fills section s: {@code arr} = 4096 classes (index (y*16+z)*16+x) or null for a section of one class. */
        public void setSection(int s, byte uni, byte[] arr) {
            if (arr != null) {
                boolean same = true;
                for (int i = 1; i < arr.length && same; i++) same = arr[i] == arr[0];
                if (same) { uni = arr[0]; arr = null; }
            }
            uniform[s] = uni;
            cls[s] = arr;
        }

        int get(int lx, int y, int lz) {
            int s = (y >> 4) - minSec;
            if (s < 0 || s >= uniform.length) return BlockTable.AIR;
            byte[] c = cls[s];
            return c == null ? uniform[s] : c[((y & 15) << 8) | (lz << 4) | lx];
        }

        void set(int lx, int y, int lz, byte v) {
            int s = (y >> 4) - minSec;
            if (s < 0 || s >= uniform.length) return;
            byte[] c = cls[s];
            if (c == null) {
                if (uniform[s] == v) return;
                c = new byte[4096];
                Arrays.fill(c, uniform[s]);
                cls[s] = c;
            }
            c[((y & 15) << 8) | (lz << 4) | lx] = v;
        }

        public int minY() { return minSec * 16; }
        public int maxY() { return (minSec + uniform.length) * 16; }
    }

    private final ConcurrentHashMap<Long, Chunk> map = new ConcurrentHashMap<>();

    private static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL); }

    /** Lowest section index for a chunk with n sections (overworld 24 -> -4; nether / end 16 -> 0). */
    public static int minSecFor(int n) { return n >= 24 ? -4 : 0; }

    public void put(int cx, int cz, Chunk c) { map.put(key(cx, cz), c); }
    public void remove(int cx, int cz) { map.remove(key(cx, cz)); }
    public void clear() { map.clear(); }
    public int size() { return map.size(); }
    public boolean loaded(double x, double z) { return map.containsKey(key(((int) Math.floor(x)) >> 4, ((int) Math.floor(z)) >> 4)); }

    /** Forget chunks farther than r chunks (Chebyshev) from chunk (cx, cz). */
    public void trim(int cx, int cz, int r) {
        map.keySet().removeIf(k -> {
            int x = (int) (k >> 32), z = (int) (long) k;
            return Math.abs(x - cx) > r || Math.abs(z - cz) > r;
        });
    }

    /** Class of the block at (x, y, z), or {@link #UNKNOWN} when its chunk is not loaded. */
    public int get(int x, int y, int z) {
        Chunk c = map.get(key(x >> 4, z >> 4));
        return c == null ? UNKNOWN : c.get(x & 15, y, z & 15);
    }

    /** Applies a block change (block_update / section_blocks_update); ignored when the chunk is not loaded. */
    public void setState(int x, int y, int z, int stateId) {
        Chunk c = map.get(key(x >> 4, z >> 4));
        if (c != null) c.set(x & 15, y, z & 15, BlockTable.classOf(stateId));
    }

    public boolean full(int x, int y, int z) { return BlockTable.isFull(get(x, y, z)); }
    public boolean solid(int x, int y, int z) { int c = get(x, y, z); return BlockTable.isFull(c) || c == BlockTable.PARTIAL; }

    /**
     * True when a straight line from a to b passes through a full block (voxel walk, like the explosion's clip).
     * Unknown chunks do not block.
     */
    public boolean rayBlocked(double ax, double ay, double az, double bx, double by, double bz) {
        int x = (int) Math.floor(ax), y = (int) Math.floor(ay), z = (int) Math.floor(az);
        int ex = (int) Math.floor(bx), ey = (int) Math.floor(by), ez = (int) Math.floor(bz);
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        int sx = Integer.signum((int) Math.signum(dx)), sy = Integer.signum((int) Math.signum(dy)), sz = Integer.signum((int) Math.signum(dz));
        double tdx = dx == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dx);
        double tdy = dy == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dy);
        double tdz = dz == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dz);
        double tx = dx == 0 ? Double.POSITIVE_INFINITY : (sx > 0 ? x + 1 - ax : ax - x) * tdx;
        double ty = dy == 0 ? Double.POSITIVE_INFINITY : (sy > 0 ? y + 1 - ay : ay - y) * tdy;
        double tz = dz == 0 ? Double.POSITIVE_INFINITY : (sz > 0 ? z + 1 - az : az - z) * tdz;
        int guard = Math.abs(ex - x) + Math.abs(ey - y) + Math.abs(ez - z) + 2;
        while (guard-- > 0) {
            if (full(x, y, z)) return true;
            if (x == ex && y == ey && z == ez) return false;
            if (tx <= ty && tx <= tz) { x += sx; tx += tdx; }
            else if (ty <= tz) { y += sy; ty += tdy; }
            else { z += sz; tz += tdz; }
        }
        return false;
    }

    /**
     * Vanilla {@code Explosion.getSeenPercent}: the share of sample points on the entity's box that the explosion centre
     * can see without a full block in between. 1.0 when the centre's chunk is not loaded.
     */
    public double seenPercent(double cx, double cy, double cz, double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        if (get((int) Math.floor(cx), (int) Math.floor(cy), (int) Math.floor(cz)) == UNKNOWN) return 1.0;
        double d = 1.0 / ((maxX - minX) * 2.0 + 1.0);
        double e = 1.0 / ((maxY - minY) * 2.0 + 1.0);
        double f = 1.0 / ((maxZ - minZ) * 2.0 + 1.0);
        double g = (1.0 - Math.floor(1.0 / d) * d) / 2.0;
        double h = (1.0 - Math.floor(1.0 / f) * f) / 2.0;
        if (d < 0 || e < 0 || f < 0) return 0;
        int seen = 0, total = 0;
        for (double k = 0.0; k <= 1.0; k += d)
            for (double l = 0.0; l <= 1.0; l += e)
                for (double m = 0.0; m <= 1.0; m += f) {
                    double px = minX + (maxX - minX) * k + g, py = minY + (maxY - minY) * l, pz = minZ + (maxZ - minZ) * m + h;
                    if (!rayBlocked(px, py, pz, cx, cy, cz)) seen++;
                    total++;
                }
        return total == 0 ? 0 : (double) seen / total;
    }
}
