package dev.duelforge.ai;

import java.util.Random;

/**
 * Respawn-anchor PvP (overworld / end): place an anchor beside the target, charge it with glowstone, then right-click it
 * with a non-glowstone item to detonate. Blocks are tracked optimistically (there is no block_update parsing).
 */
final class AnchorLogic {
    private final Brain br;
    private int phase;                 // 0 pick cell + place anchor, 1 charge, 2 detonate
    private boolean cellOk;
    private int cx, cz, since, wait, placeCd;

    AnchorLogic(Brain br) { this.br = br; }

    void reset() { phase = 0; cellOk = false; wait = 0; placeCd = 0; }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final Random r = br.r;
        if (placeCd > 0) placeCd--;
        if (wait > 0) wait--;
        double flat = br.flat(t);
        int gy = (int) Math.floor(b.groundY + 1e-4);

        if (phase == 0 && (flat < 2.6 || !br.has(Brain.S_SECOND) || !br.has(Brain.S_THIRD))) { br.melee(t); return; }

        // anchors blast hard: hold a larger distance than crystals
        if (--br.strafeTimer <= 0) {
            br.strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(10));
            if (r.nextBoolean()) br.strafeDir = -br.strafeDir;
        }
        // cells within block-reach (about 4.4 from the eye) must exist beside the target, so close in to ~4.9
        if (flat > 4.9) { b.fwd = 1; b.wantSprint = flat > 7; }
        else if (flat < 3.5) { b.fwd = -0.6f; b.wantSprint = false; }
        else { b.strafe = br.strafeDir; b.wantSprint = false; }

        double[] aim = br.angTo(t.x, t.y + 1.2, t.z);
        int act = 0;
        br.state = "anchor";
        if (phase == 0) {
            if (placeCd <= 0 && flat < 9) {
                if (!cellOk) {
                    int[] cell = br.pickCell(t, 3.0, 4.4, gy, (x, z) -> false);
                    if (cell != null) { cx = cell[0]; cz = cell[1]; cellOk = true; }
                }
                if (cellOk) { act = 1; aim = br.angTo(cx + 0.5, gy, cz + 0.5); br.state = "anchor/place"; }
            }
        } else {
            aim = br.angTo(cx + 0.5, gy + 1, cz + 0.5);
            if (wait == 0) act = phase + 1;           // 2 = charge, 3 = detonate
            br.state = phase == 1 ? "anchor/charge" : "anchor/boom";
            if (br.tick - since > 40) { br.w.clearBlock(cx, gy, cz); phase = 0; cellOk = false; }
        }

        b.aim(aim[0], aim[1], tier.aimSpeed(), tier.aimNoise());
        double err = b.angleError(aim[0], aim[1]);

        switch (act) {
            case 1 -> {
                boolean sw = br.select(Brain.S_SECOND);
                if (!sw && err < 8 && br.eyeDist(cx + 0.5, gy, cz + 0.5) <= 4.3) {
                    b.useOnBlockTop(cx, gy - 1, cz);
                    br.w.setBlock(cx, gy, cz); br.consume(Brain.S_SECOND);
                    phase = 1; wait = 1 + r.nextInt(2); since = br.tick;
                }
            }
            case 2 -> {
                boolean sw = br.select(Brain.S_THIRD);
                if (!sw && err < 8) { b.useOnBlockTop(cx, gy, cz); br.consume(Brain.S_THIRD); phase = 2; wait = 1; }
            }
            case 3 -> {
                boolean sw = br.select(Brain.S_WEAPON);
                if (!sw && err < 8) {
                    b.useOnBlockTop(cx, gy, cz);
                    br.w.clearBlock(cx, gy, cz);
                    phase = 0; cellOk = false;
                    placeCd = 12 + r.nextInt(10);
                }
            }
            default -> { }
        }
    }
}
