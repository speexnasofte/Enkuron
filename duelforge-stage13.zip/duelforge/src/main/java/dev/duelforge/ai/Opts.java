package dev.duelforge.ai;

import java.util.Locale;

/** Global tunables shared by every bot (changed from the GUI or /botlab). */
public final class Opts {
    private Opts() {}

    /** Whether crystal bots place their own obsidian base before placing a crystal. */
    public enum Obsidian {
        /** Try the floor first; after two failed crystals switch to placing obsidian. */
        AUTO,
        /** Always place an obsidian block next to the target first. */
        ALWAYS,
        /** Floor is already obsidian/bedrock (arena), never place blocks. */
        NEVER;

        public Obsidian next() { return values()[(ordinal() + 1) % values().length]; }

        public static Obsidian parse(String s) {
            try { return valueOf(s.trim().toUpperCase(Locale.ROOT)); } catch (Exception e) { return AUTO; }
        }
    }

    public static volatile Obsidian obsidian = Obsidian.AUTO;
    /** After a totem pop (hp drops to exactly 1.0) swap a fresh totem from hotbar slot 9 into the offhand. */
    public static volatile boolean totemRefill = true;
    /** When no join command is set, run the per-mode kit command from {@link Kits} after login. */
    public static volatile boolean autoKit = true;
    /** Name of the saved kit that new bots get (null = none). */
    public static volatile String selectedKit = null;
    /** true: every bot runs its own kit commands (bots must be op); false: your client sends them for the bots. */
    public static volatile boolean kitViaBots = false;
    /** Ticks between kit commands sent from one connection (the server can kick for chat spam). */
    public static volatile int kitDelay = 3;
    /** Spear: how far the bot pokes and how many ticks between pokes. 1.21.11 spear values are not verified - tune with /botlab spear. */
    public static volatile double spearReach = 4.0;
    public static volatile int spearCooldown = 16;
    /** Every bot ignores the use-item slowdown (eating and drawing at full speed). HT0 always does. Not vanilla: anticheats flag it. */
    public static volatile boolean noSlow = false;
    /** Eating a golden apple next to an enemy only gets the bot hit: below healAt it eats when the enemy is at least this far away... */
    public static volatile double healSafeDist = 3.5;
    /** ...or when health is at or below this (then it eats even in melee). */
    public static volatile double healPanic = 4.0;
    /** Hit combos after a landed hit: W-tap, S-tap and strafe flips (see {@link Combo}). false = only the old random W-tap. */
    public static volatile boolean combo = true;

    /** Bit per {@link Combo.Kind} ordinal: which combos the bots may use (all on by default). */
    public static volatile int comboMask = 0xFFFF;
    /** Two combos in a row (e.g. S-tap then strafe, W-tap then jump crit) for tiers LT2 and up. */
    public static volatile boolean comboChain = true;
    /** Multiplier for how often a combo follows a hit (0.3 .. 1.6). */
    public static volatile double comboRate = 1.0;

    public static boolean comboOn(Combo.Kind k) { return (comboMask & (1 << k.ordinal())) != 0; }

    public static void comboSet(Combo.Kind k, boolean on) {
        if (on) comboMask |= 1 << k.ordinal(); else comboMask &= ~(1 << k.ordinal());
    }

    /** NPC dummy: hit it and it hits back with its fists for a few seconds (default: just stands). */
    public static volatile boolean npcFight = false;
    /** NPC gets full netherite armor. */
    public static volatile boolean npcArmor = false;
    /** Totems in each hand of an NPC (1..99, stack size is raised with the max_stack_size component). */
    public static volatile int npcTotems = 99;

    /** UHC / TRAPPER: master switch for the trap tricks and one switch per trick. */
    public static volatile boolean traps = true;
    /** Cobweb under the enemy (or ahead of the way it runs). */
    public static volatile boolean trapWeb = true;
    /** Lava bucket next to a webbed / fleeing enemy (the bot backs off and picks the lava up again). */
    public static volatile boolean trapLava = true;
    /** Flint and steel: fire around the enemy to close the way out. */
    public static volatile boolean trapFire = true;
    /** Empty bucket aimed at the feet of a fleeing enemy: picks up the water it placed to escape. */
    public static volatile boolean waterSteal = true;
    /** MACE_PRO: smallest fall (blocks) before the bot smashes; a longer fall is a bigger hit. */
    public static volatile double maceMinFall = 2.5;

    /** Spear bots retreat after a poke to build a run-up instead of standing at poke range (1.21.11 spear values are not verified). */
    public static volatile boolean spearRunup = true;

    /** Crystal bots pick the cell by predicted damage (to the enemy and to themselves) instead of geometry only, and never detonate what would kill them. */
    public static volatile boolean smartCrystal = true;
    /** Smart crystal: a cell is ruled out when the crystal would leave the bot with less than this much health. */
    public static volatile double crystalSelfReserve = 2.0;
    /** Smart crystal: damage to the enemy that counts as a "good" crystal (lower cells are still used when nothing better exists). */
    public static volatile double crystalMinDamage = 4.0;
    /** Aim at the point of the enemy hitbox that needs the smallest head turn (HT3 and up); false = always the chest. */
    public static volatile boolean hitboxAim = true;
    /** Parse chunk / block packets: the bot then knows the terrain (floor, walls, cover from explosions). false = flat-floor model. */
    public static volatile boolean readChunks = true;
    /** Walk, fall and land on the real blocks instead of an assumed flat floor (needs {@link #readChunks}). */
    public static volatile boolean terrainPhysics = true;
    /** Walk around walls (A* over the known blocks) when the straight line to the target is blocked (needs terrainPhysics). */
    public static volatile boolean pathfinding = true;
    /** Chunks farther than this (in chunks, from the bot) are forgotten; the bots ask for {@link #botViewDistance}. */
    public static volatile int chunkKeep = 8;
    /** View distance (chunks) the bots ask the server for. Smaller = less memory and traffic; 6 covers combat and the path finder (radius ~3 chunks). */
    public static volatile int botViewDistance = 6;

    /** Melee: keep sprint off for the whole jump of a jump-crit (vanilla: a hit while sprinting is never a crit; ported from Expensive's sprint reset). */
    public static volatile boolean sprintReset = true;

    /** HUD cards for Lab bots (name, tier, health, mode/state, hits) in the Expensive style. */
    public static volatile boolean labHud = true;
    /** Corner of the Lab HUD: bit0 = right, bit1 = bottom. */
    public static volatile int labHudCorner = 1;
    /** Rotating particle ring around the enemy each bot is fighting (TargetESP look). */
    public static volatile boolean targetRing = true;
}
