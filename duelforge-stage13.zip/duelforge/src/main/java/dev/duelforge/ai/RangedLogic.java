package dev.duelforge.ai;

import java.util.Random;

/**
 * Bow, crossbow and trident. Keeps distance, strafes, leads a moving target with a ballistic solver and releases once the
 * aim is good enough for the bot's tier. Drawing slows movement to 20% like a real client.
 * Crossbow: hold ~26 ticks, release (loads), then use again to fire. Trident: needs Loyalty or the bot loses it.
 */
final class RangedLogic {
    private final Brain br;
    private int phase;           // 0 idle, 1 charging, 2 crossbow loaded
    private int phaseTicks, wantTicks;
    private boolean loaded;

    RangedLogic(Brain br) { this.br = br; }

    boolean busy() { return phase != 0 || loaded; }

    void reset() { phase = 0; loaded = false; phaseTicks = 0; }

    /** Something (eating, totem swap) cancelled the held item. */
    void interrupt() { phase = loaded ? 2 : 0; phaseTicks = 0; }

    private double speed() { return switch (br.mode) { case BOW, UHC -> 3.0; case CROSSBOW -> 3.15; default -> 2.5; }; }

    private int need() { return switch (br.mode) { case BOW, UHC -> 20; case CROSSBOW -> 26; default -> 11; }; }

    /** {yaw, pitch} that leads the target's horizontal motion, or null when out of range. */
    private double[] lead(World.Ent t) {
        Body b = br.b;
        double px = t.x, pz = t.z, py = t.y + 1.0;
        Ballistics.Shot s = null;
        for (int i = 0; i < 3; i++) {
            double d = Math.hypot(px - b.x, pz - b.z);
            s = Ballistics.solve(d, py - (b.y + Brain.EYE), speed(), 0.05, 0.99);
            if (s == null) return null;
            px = t.x + t.velX(br.w.now) * s.ticks();
            pz = t.z + t.velZ(br.w.now) * s.ticks();
        }
        return new double[]{Body.yawTo(px - b.x, pz - b.z), s.pitch()};
    }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final Random r = br.r;
        double flat = br.flat(t);
        br.state = br.mode.name().toLowerCase() + "/" + phase;

        // too close: fight with the sword instead (only between shots)
        if (phase != 1 && flat < 3.2) { b.usingItem = false; br.melee(t); return; }

        // keep a shooting distance and strafe
        if (--br.strafeTimer <= 0) {
            br.strafeTimer = Math.max(6, tier.strafeTicks() + r.nextInt(12));
            if (r.nextBoolean()) br.strafeDir = -br.strafeDir;
        }
        if (flat < 8 && br.mode != Mode.UHC) { b.fwd = -1; b.wantSprint = false; }
        else if (flat > (br.mode == Mode.UHC ? 12 : 26) && phase != 1) { b.fwd = 1; b.wantSprint = true; }   // UHC keeps closing in
        b.strafe = br.strafeDir;

        double[] aim = lead(t);
        double err = 99;
        if (aim != null) {
            b.aim(aim[0], aim[1], tier.aimSpeed(), tier.aimNoise());
            err = b.angleError(aim[0], aim[1]);
        } else br.faceTarget(t, 1.0);
        double releaseErr = 2.5 + (9 - tier.ordinal()) * 0.8;       // HT1 2.5 deg .. LT5 9.7 deg

        switch (phase) {
            case 0 -> {
                boolean sw = br.select(Brain.S_SECOND);
                if (loaded) { phase = 2; phaseTicks = 0; return; }
                if (!sw && br.cooldown <= 0 && flat >= 3.5 && flat <= 60 && aim != null && err < 25) {
                    b.startUse();
                    phase = 1; phaseTicks = 0;
                    wantTicks = need() - ((br.mode == Mode.BOW || br.mode == Mode.UHC) ? r.nextInt(1 + (9 - tier.ordinal()) / 2) : 0);
                }
            }
            case 1 -> {
                phaseTicks++;
                b.wantSprint = false;
                boolean close = flat < 3.0;
                if (close || (phaseTicks >= wantTicks && (err < releaseErr || phaseTicks > wantTicks + 25)) || phaseTicks > 120) {
                    b.releaseUse();
                    if (br.mode == Mode.CROSSBOW && !close && phaseTicks >= need()) { loaded = true; phase = 2; phaseTicks = 0; }
                    else { phase = 0; br.cooldown = 4 + r.nextInt(tier.hitDelayMax() + 3); }
                }
            }
            default -> {                                            // crossbow loaded: fire when aligned
                phaseTicks++;
                br.select(Brain.S_SECOND);
                if (phaseTicks > 2 && ((aim != null && err < releaseErr) || phaseTicks > 30)) {
                    b.useItem();
                    loaded = false; phase = 0;
                    br.cooldown = 4 + r.nextInt(tier.hitDelayMax() + 3);
                }
            }
        }
    }
}
