package dev.duelforge.ai;

/**
 * The Controller kit buttons for network bots: builds a real {@link Kit} (hotbar the PvP brain expects + armor)
 * from the id of a {@code LocalKit}. The items reach the bot through /item replace commands (needs op rights).
 */
public final class RemoteKits {
    private RemoteKits() {}

    private static final String HEAL = "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_healing\"}]";
    private static final String SPEED = "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_swiftness\"}]";
    private static final String STRENGTH = "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_strength\"}]";

    private static void hot(Kit k, int slot, int count, String item) { k.slots.put("hotbar." + slot, new Kit.Entry(count, item)); }

    private static void armor(Kit k, String mat, boolean elytra) {
        k.slots.put("armor.head", new Kit.Entry(1, "minecraft:" + mat + "_helmet"));
        k.slots.put("armor.chest", new Kit.Entry(1, elytra ? "minecraft:elytra" : "minecraft:" + mat + "_chestplate"));
        k.slots.put("armor.legs", new Kit.Entry(1, "minecraft:" + mat + "_leggings"));
        k.slots.put("armor.feet", new Kit.Entry(1, "minecraft:" + mat + "_boots"));
    }

    private static void totem(Kit k) { hot(k, 8, 1, "minecraft:totem_of_undying"); k.slots.put("weapon.offhand", new Kit.Entry(1, "minecraft:totem_of_undying")); }

    /** @return the kit for a Controller kit id ("kit_crystal", ...) or null for an unknown id */
    public static Kit build(String id) {
        Kit k = new Kit(id);
        String sword = "minecraft:netherite_sword", apple = "minecraft:golden_apple";
        switch (id) {
            case "kit_crystal" -> { k.mode = Mode.CRYSTAL; hot(k, 0, 1, sword); hot(k, 1, 64, "minecraft:end_crystal"); hot(k, 2, 16, apple); hot(k, 3, 64, "minecraft:obsidian"); totem(k); armor(k, "netherite", false); }
            case "kit_pot" -> { k.mode = Mode.POT; hot(k, 0, 1, sword); hot(k, 1, 16, HEAL); totem(k); armor(k, "netherite", false); }
            case "kit_smp" -> { k.mode = Mode.SMP; hot(k, 0, 1, sword); hot(k, 1, 8, HEAL); hot(k, 2, 16, apple); hot(k, 3, 1, SPEED); hot(k, 4, 1, STRENGTH); totem(k); armor(k, "netherite", false); }
            case "kit_diamond_smp" -> { k.mode = Mode.DIAMOND_SMP; hot(k, 0, 1, "minecraft:diamond_sword"); hot(k, 1, 8, HEAL); hot(k, 2, 16, apple); hot(k, 3, 1, SPEED); hot(k, 4, 1, STRENGTH); totem(k); armor(k, "diamond", false); }
            case "kit_sword" -> { k.mode = Mode.SWORD; hot(k, 0, 1, "minecraft:diamond_sword"); hot(k, 2, 16, apple); totem(k); armor(k, "diamond", false); }
            case "kit_diamond" -> { k.mode = Mode.SWORD; hot(k, 0, 1, "minecraft:diamond_sword"); hot(k, 2, 16, apple); armor(k, "diamond", false); }
            case "kit_bedfight" -> { k.mode = Mode.SWORD; hot(k, 0, 1, "minecraft:diamond_sword"); hot(k, 2, 16, apple); armor(k, "diamond", false); }
            case "kit_netherite_sword" -> { k.mode = Mode.SHIELD; hot(k, 0, 1, sword); hot(k, 2, 16, apple); k.slots.put("weapon.offhand", new Kit.Entry(1, "minecraft:shield")); armor(k, "netherite", false); }
            case "kit_axe" -> { k.mode = Mode.AXE; hot(k, 0, 1, "minecraft:netherite_axe"); hot(k, 2, 16, apple); k.slots.put("weapon.offhand", new Kit.Entry(1, "minecraft:shield")); armor(k, "netherite", false); }
            case "kit_mace" -> { k.mode = Mode.MACE; hot(k, 0, 1, "minecraft:mace"); hot(k, 1, 64, "minecraft:wind_charge"); hot(k, 2, 16, apple); armor(k, "netherite", false); }
            case "kit_sotg" -> { k.mode = Mode.SWORD; hot(k, 0, 1, sword); hot(k, 2, 16, apple); totem(k); armor(k, "netherite", false); }
            case "kit_uhc" -> { k.mode = Mode.UHC; hot(k, 0, 1, "minecraft:diamond_sword"); hot(k, 1, 1, "minecraft:bow"); hot(k, 2, 16, apple); hot(k, 3, 16, "minecraft:cobweb");
                hot(k, 4, 1, "minecraft:lava_bucket"); hot(k, 5, 1, "minecraft:flint_and_steel"); hot(k, 6, 1, "minecraft:bucket");
                k.slots.put("inventory.0", new Kit.Entry(64, "minecraft:arrow")); k.slots.put("weapon.offhand", new Kit.Entry(1, "minecraft:shield")); armor(k, "diamond", false); }
            case "kit_spear_mace" -> { k.mode = Mode.SPEAR; hot(k, 0, 1, "minecraft:netherite_spear"); hot(k, 2, 16, apple); totem(k); armor(k, "netherite", false); }
            case "kit_bow" -> { k.mode = Mode.BOW; hot(k, 0, 1, sword); hot(k, 1, 1, "minecraft:bow"); hot(k, 2, 16, apple); k.slots.put("inventory.0", new Kit.Entry(64, "minecraft:arrow")); armor(k, "netherite", false); }
            case "kit_elytra" -> { k.mode = Mode.ELYTRA; hot(k, 0, 1, sword); hot(k, 1, 64, "minecraft:firework_rocket"); hot(k, 2, 16, apple); totem(k); armor(k, "netherite", true); }
            default -> { return null; }
        }
        return k;
    }
}
