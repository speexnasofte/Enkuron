package dev.duelforge.ai;

import java.util.Random;

/**
 * Hit combos the bot chains right after it lands a hit.
 * <ul>
 *   <li>W_TAP - let go of W for a tick or two: sprint resets, the next sprint hit knocks the enemy back again.</li>
 *   <li>S_TAP - tap S: sprint resets and the bot steps back so the enemy flies out of reach and has to walk back into us.</li>
 *   <li>STRAFE - sidestep with a flipped direction (A to D) while still moving forward: the enemy loses the aim.</li>
 *   <li>JUMP_CRIT - jump right after the hit: the next swing lands while falling (crit, +50% damage).</li>
 *   <li>BAIT - step back for a few ticks so the enemy follows, then burst forward with a sprint hit.</li>
 *   <li>DOUBLE_TAP - two sprint resets in a row (release, re-sprint, release).</li>
 *   <li>ORBIT - circle the enemy in one direction at close range: hard to hit, stays inside reach.</li>
 * </ul>
 * W-tap, S-tap, double tap and bait prepare a sprint hit (knockback); strafe, orbit and jump crit prepare a jump crit:
 * in vanilla a crit is impossible while sprinting. Two combos can be chained (see {@link Opts#comboChain}).
 */
public final class Combo {
    public enum Kind {
        NONE("-", ""),
        W_TAP("W-тап", "отпустить W на 1-2 тика: спринт сбрасывается, след. удар снова отбрасывает"),
        S_TAP("S-тап", "шаг назад: враг вылетает из досягаемости и должен подойти"),
        STRAFE("Стрейф-флип", "смена A/D на ходу: враг теряет прицел, бот готовит крит"),
        JUMP_CRIT("Прыжок-крит", "прыжок сразу после удара: след. удар в падении = крит"),
        BAIT("Приманка", "отступить 4 тика, враг идёт следом, потом рывок со спринт-ударом"),
        DOUBLE_TAP("Двойной тап", "два сброса спринта подряд: надёжнее w-тап"),
        ORBIT("Орбита", "круг вокруг врага на ближней дистанции, держит в зоне удара");

        public final String label, info;
        Kind(String label, String info) { this.label = label; this.info = info; }
    }

    private Kind kind = Kind.NONE, pending = Kind.NONE;
    private int left, dir = 1, hits, age, seq;

    public boolean active() { return kind != Kind.NONE; }

    public Kind kind() { return kind; }

    /** New strafe direction picked by a STRAFE / ORBIT combo (the brain adopts it). */
    public int dir() { return dir; }

    /** The combo (or the last combo of a chain) that decides what the next hit will be. */
    private Kind last() { return pending != Kind.NONE ? pending : kind; }

    /** True when the next hit should be a sprint hit (a tap prepared it), so no jump crit is wanted. */
    public boolean sprintNext() {
        Kind k = last();
        return k == Kind.W_TAP || k == Kind.S_TAP || k == Kind.DOUBLE_TAP || k == Kind.BAIT;
    }

    /** True when the combo itself asks for a falling hit. */
    public boolean critNext() { return last() == Kind.JUMP_CRIT; }

    public void reset() { kind = Kind.NONE; pending = Kind.NONE; left = 0; age = 0; }

    public void start(Kind k, int ticks, int strafeDir) {
        kind = k; left = ticks; dir = strafeDir; age = 0; pending = Kind.NONE;
    }

    private void startKind(Kind k, Random r, int strafeDir) {
        switch (k) {
            case W_TAP -> start(k, 1 + r.nextInt(2), strafeDir);
            case S_TAP -> start(k, 2 + r.nextInt(2), strafeDir);
            case STRAFE -> start(k, 5 + r.nextInt(3), -strafeDir);
            case JUMP_CRIT -> start(k, 9, strafeDir);
            case BAIT -> start(k, 7, strafeDir);
            case DOUBLE_TAP -> start(k, 3, strafeDir);
            case ORBIT -> start(k, 8 + r.nextInt(3), strafeDir);
            default -> reset();
        }
    }

    /** Pick the combo that follows a landed hit. */
    public Kind onHit(Random r, Tier tier, double flat, int strafeDir) { return onHit(r, tier, flat, strafeDir, false); }

    /** @param aggressive pressure mode: always follow up, favour the forward combos */
    public Kind onHit(Random r, Tier tier, double flat, int strafeDir, boolean aggressive) {
        hits++;
        Kind k;
        if (!Opts.combo) {
            k = r.nextDouble() < tier.wtapChance() ? Kind.W_TAP : Kind.NONE;
        } else if (tier.max()) {
            k = rotate(flat);
        } else {
            double gate = (0.2 + 0.75 * tier.wtapChance()) * Opts.comboRate;
            if (aggressive) gate = Math.max(gate, 0.95);
            k = r.nextDouble() >= gate ? Kind.NONE : weighted(r, tier, flat, aggressive);
        }
        if (k == Kind.NONE) { reset(); return k; }
        startKind(k, r, strafeDir);
        // chains only for the stronger tiers; MAX always chains
        if (Opts.combo && Opts.comboChain && (tier.max() || (tier.ordinal() >= Tier.LT2.ordinal() && r.nextDouble() < 0.5 * Opts.comboRate))) {
            Kind nx = followUp(k, flat);
            if (nx != Kind.NONE && Opts.comboOn(nx)) pending = nx;
        }
        return k;
    }

    /** MAX: sprint hit and jump crit take turns, with the extra combos in between. */
    private Kind rotate(double flat) {
        Kind[] order = {
                flat < 1.9 ? Kind.S_TAP : Kind.W_TAP, Kind.STRAFE, Kind.DOUBLE_TAP, Kind.JUMP_CRIT,
                flat >= 1.9 ? Kind.BAIT : Kind.S_TAP, Kind.ORBIT};
        for (int i = 0; i < order.length; i++) {
            Kind k = order[(seq + i) % order.length];
            if (Opts.comboOn(k)) { seq += i + 1; return k; }
        }
        return Kind.NONE;
    }

    private Kind weighted(Random r, Tier tier, double flat, boolean aggressive) {
        int t = tier.ordinal();
        Kind[] ks = {Kind.W_TAP, Kind.S_TAP, Kind.STRAFE, Kind.JUMP_CRIT, Kind.ORBIT, Kind.DOUBLE_TAP, Kind.BAIT};
        double[] w = {
                flat < 1.7 ? 0.15 : 0.30,
                flat < 1.7 ? 0.40 : 0.20,
                0.25,
                t >= Tier.LT3.ordinal() ? 0.20 : 0,
                t >= Tier.LT3.ordinal() ? 0.12 : 0,
                t >= Tier.LT2.ordinal() ? 0.12 : 0,
                t >= Tier.LT2.ordinal() && flat >= 1.9 ? 0.12 : 0};
        if (aggressive) { w[0] *= 1.6; w[5] *= 2; w[3] *= 1.4; w[1] *= 0.5; w[4] *= 0.5; }
        double sum = 0;
        for (int i = 0; i < ks.length; i++) { if (!Opts.comboOn(ks[i])) w[i] = 0; sum += w[i]; }
        if (sum <= 0) return Kind.NONE;
        double x = r.nextDouble() * sum;
        for (int i = 0; i < ks.length; i++) { x -= w[i]; if (x <= 0 && w[i] > 0) return ks[i]; }
        return Kind.NONE;
    }

    private static Kind followUp(Kind k, double flat) {
        return switch (k) {
            case S_TAP -> Kind.STRAFE;
            case W_TAP -> Kind.JUMP_CRIT;
            case DOUBLE_TAP -> Kind.ORBIT;
            case STRAFE -> flat < 2.0 ? Kind.S_TAP : Kind.NONE;
            default -> Kind.NONE;
        };
    }

    /** Override the bot's inputs while a combo is running. Returns true if it did. */
    public boolean apply(Body b) {
        if (kind == Kind.NONE) return false;
        switch (kind) {
            case W_TAP -> { b.fwd = 0; b.wantSprint = false; }
            case S_TAP -> { b.fwd = -1; b.strafe = dir * 0.5f; b.wantSprint = false; }
            case STRAFE -> { b.fwd = 0.6f; b.strafe = dir; b.wantSprint = true; }
            case JUMP_CRIT -> { b.fwd = 0.7f; b.strafe = dir * 0.3f; b.wantSprint = false; if (age == 0 && b.onGround) b.jump = true; }
            case BAIT -> {
                if (left > 3) { b.fwd = -1; b.strafe = dir * 0.4f; b.wantSprint = false; }
                else { b.fwd = 1; b.strafe = 0; b.wantSprint = true; }
            }
            case DOUBLE_TAP -> {
                if (left == 2) { b.fwd = 1; b.wantSprint = true; } else { b.fwd = 0; b.wantSprint = false; }
            }
            default -> { b.fwd = 0.35f; b.strafe = dir; b.wantSprint = true; }   // ORBIT
        }
        age++;
        if (--left <= 0) {
            Kind nx = pending;
            kind = Kind.NONE; pending = Kind.NONE;
            if (nx != Kind.NONE) { Random r = new Random(hits * 31L + age); startKind(nx, r, dir); }
        }
        return true;
    }
}
