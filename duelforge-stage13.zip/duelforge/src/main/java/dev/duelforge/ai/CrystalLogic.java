package dev.duelforge.ai;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Crystal PvP. Places a crystal beside the target's feet, breaks it, repeats; breaks enemy crystals near us.
 * If the floor is not obsidian/bedrock the bot first places an obsidian block (right-click the floor, then the crystal
 * goes on top of it). In AUTO mode the bot learns this by itself: two crystals that never spawn on the bare floor switch
 * it to "place obsidian first". The end-crystal entity type id is learned from the first crystal the bot spawns.
 */
final class CrystalLogic {
    private final Brain br;

    private int phase;                    // 0 idle, 1 waiting for our crystal entity to appear
    private boolean cellOk;
    private int cx, cz, cellSince;
    private boolean onObsidian;
    private double ex, ey, ez;
    private int placedAt;
    private int placeCd, breakCd, crystalId = -1;
    private int fails, obsFails;
    private boolean needObs;
    private int crystalType = -1;
    private final Map<Long, Integer> bad = new HashMap<>();

    CrystalLogic(Brain br) { this.br = br; }

    void reset() { phase = 0; cellOk = false; crystalId = -1; placeCd = 0; breakCd = 0; }

    private int gy() { return (int) Math.floor(br.b.groundY + 1e-4); }

    private static long key(int x, int z) { return ((long) x << 32) ^ (z & 0xFFFFFFFFL); }

    private boolean isBad(int x, int z) {
        Integer until = bad.get(key(x, z));
        return until != null && until > br.tick;
    }

    private boolean needObsidian() {
        return switch (Opts.obsidian) {
            case ALWAYS -> true;
            case NEVER -> false;
            default -> {
                // chunk data known: the floor under the cell decides at once (only obsidian / bedrock carries a crystal),
                // otherwise the bot learns it from two failed crystals
                int floor = br.w.blockAt(cx, gy() - 1, cz);
                yield floor == ChunkStore.UNKNOWN ? needObs : floor != BlockTable.OBSIDIAN;
            }
        };
    }

    /** Did the crystal we just placed spawn? Learns the crystal type id and whether the bare floor works. */
    private void watchSpawn() {
        if (phase != 1) return;
        World w = br.w;
        for (World.Ent e : w.ents.values()) {
            if (e.player || e.spawnTick < placedAt) continue;
            if (Math.abs(e.x - ex) < 0.9 && Math.abs(e.z - ez) < 0.9 && Math.abs(e.y - ey) < 0.8) {
                crystalId = e.id;
                if (crystalType < 0) crystalType = e.type;
                if (onObsidian) obsFails = 0; else { fails = 0; needObs = false; }
                phase = 0;
                return;
            }
        }
        if (w.now - placedAt > 8) {
            br.refund(Brain.S_SECOND);                  // the crystal never appeared: do not count it as used
            if (onObsidian) {
                w.clearBlock(cx, gy(), cz);          // the obsidian was probably not there after all: place it again
                if (++obsFails >= 2) { bad.put(key(cx, cz), br.tick + 400); obsFails = 0; }
            } else if (++fails >= 2 && Opts.obsidian != Opts.Obsidian.NEVER) {
                needObs = true; fails = 0;           // bare floor does not work -> place obsidian from now on
            }
            phase = 0; cellOk = false;
        }
    }

    private World.Ent findCrystal() {
        World.Ent best = null; double bd = 1e9;
        for (World.Ent e : br.w.ents.values()) {
            if (e.player) continue;
            boolean ours = e.id == crystalId;
            boolean known = crystalType >= 0 && e.type == crystalType;
            if (!ours && !known) continue;
            double d = br.dist(e);
            if (d > 6.5) continue;
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private void move(double flat) {
        Body b = br.b;
        if (--br.strafeTimer <= 0) {
            br.strafeTimer = Math.max(6, br.tier.strafeTicks() + br.r.nextInt(10));
            if (br.r.nextBoolean()) br.strafeDir = -br.strafeDir;
        }
        if (flat > 4.8) { b.fwd = 1; b.wantSprint = true; }
        else if (flat < 2.4) { b.fwd = -0.6f; b.wantSprint = false; b.strafe = br.strafeDir; }
        else { b.strafe = br.strafeDir; b.wantSprint = false; }
    }

    /**
     * Damage-based value of a crystal on cell (x,z): good for the enemy's damage, bad for ours; NEGATIVE_INFINITY when the blast
     * would leave the bot under the reserve. The crystal entity stands on top of the base block, i.e. at the floor surface (gy).
     */
    private double cellValue(World.Ent t, int x, int z, int gy) {
        if (!Opts.smartCrystal) return 0;
        double self = br.selfCrystal(x + 0.5, gy, z + 0.5);
        if (self >= br.b.health - Opts.crystalSelfReserve) return Double.NEGATIVE_INFINITY;
        double en = br.enemyCrystal(t, x + 0.5, gy, z + 0.5);
        double v = en * 0.5 - self * 0.8;
        if (en < Opts.crystalMinDamage) v -= (Opts.crystalMinDamage - en) * 0.7;
        return v;
    }

    void tick(World.Ent t) {
        final Body b = br.b;
        final Tier tier = br.tier;
        final Random r = br.r;
        final World w = br.w;
        watchSpawn();
        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;
        double flat = br.flat(t);
        move(flat);
        br.combo.apply(b);                    // W-tap / S-tap / strafe flip after our last melee hit

        int gy = gy();
        int baseY = gy - 1;
        boolean obs = false;
        int act = 0;                          // 1 break crystal, 2 place obsidian, 3 place crystal, 4 melee
        double[] aim = br.angTo(t.x, t.y + 1.2, t.z);
        br.state = "crystal";

        World.Ent c = findCrystal();
        if (c != null) {
            act = 1;
            aim = br.angTo(c.x, c.y + 1.0, c.z);
            br.state = "crystal/break";
        } else if (phase == 0 && placeCd <= 0 && flat < 8 && br.has(Brain.S_SECOND)) {
            if (cellOk && (br.tick - cellSince > 40 || isBad(cx, cz) || Math.hypot(cx + 0.5 - t.x, cz + 0.5 - t.z) > 2.6)) cellOk = false;
            if (!cellOk) {
                // crystals are broken by hand (reach < 3), so the cell must be within melee reach of the crystal's 2x2 box
                final World.Ent tt = t;
                int[] cell = br.pickCell(t, 1.2, tier.reach() + 0.8, gy, this::isBad, (x, z) -> cellValue(tt, x, z, gy));
                if (cell != null) { cx = cell[0]; cz = cell[1]; cellOk = true; cellSince = br.tick; }
            }
            if (cellOk) {
                boolean hasObs = w.hasBlock(cx, gy, cz) || w.blockAt(cx, gy, cz) == BlockTable.OBSIDIAN;
                if (needObsidian() && !hasObs && !br.has(Brain.S_THIRD)) {
                    cellOk = false;                       // no obsidian left: cannot build a base
                } else if (needObsidian() && !hasObs) {
                    act = 2;
                    aim = br.angTo(cx + 0.5, gy, cz + 0.5);
                    br.state = "crystal/obsidian";
                } else {
                    act = 3; obs = hasObs;
                    baseY = hasObs ? gy : gy - 1;
                    aim = br.angTo(cx + 0.5, baseY + 1, cz + 0.5);
                    br.state = "crystal/place";
                }
            }
        }
        // low on health: do not drop a crystal next to ourselves (self damage), fight with the sword instead
        if (act == 3 && Opts.smartCrystal) {
            // the bot may have moved since the cell was chosen: re-check the blast against the current position
            if (br.selfCrystal(cx + 0.5, baseY + 1, cz + 0.5) >= b.health - Opts.crystalSelfReserve) { act = 0; cellOk = false; br.state = "crystal/safe"; }
        } else if (act == 3 && b.health <= 8f && br.eyeDist(cx + 0.5, baseY + 1, cz + 0.5) < 3.4) { act = 0; cellOk = false; br.state = "crystal/safe"; }
        if (act == 0 && flat < 2.6) act = 4;

        b.aim(aim[0], aim[1], tier.aimSpeed(), tier.aimNoise());
        double err = b.angleError(aim[0], aim[1]);

        switch (act) {
            case 1 -> {                       // hit the crystal with whatever is in hand (no slot swap = faster)
                double d = br.reachBox(c, 1.0, 2.0);
                // a crystal that would leave us under the reserve is not worth breaking next to us (breaking it detonates it): back off instead
                boolean lethal = Opts.smartCrystal && br.selfCrystal(c.x, c.y, c.z) >= b.health - Opts.crystalSelfReserve;
                if (lethal) { b.fwd = -1; b.strafe = 0; b.wantSprint = false; br.state = "crystal/evade"; }
                else if (d <= tier.reach() && err < 10 && breakCd <= 0) {
                    b.attack(c.id);
                    breakCd = tier.max() ? 0 : 1 + r.nextInt(tier.hitDelayMax() / 2 + 2);
                    if (c.id == crystalId) crystalId = -1;
                } else if (d > tier.reach() - 0.2) { b.fwd = 1; b.wantSprint = false; b.strafe = 0; }   // close in on our own crystal
            }
            case 2 -> {
                boolean sw = br.select(Brain.S_THIRD);
                if (!sw && err < 8 && br.eyeDist(cx + 0.5, gy, cz + 0.5) <= 4.3) {
                    b.useOnBlockTop(cx, gy - 1, cz);
                    w.setBlock(cx, gy, cz); br.consume(Brain.S_THIRD);
                    placeCd = tier.max() ? 0 : 1 + r.nextInt(tier.hitDelayMax() / 2 + 2);
                }
            }
            case 3 -> {
                boolean sw = br.select(Brain.S_SECOND);
                if (!sw && err < 8 && br.eyeDist(cx + 0.5, baseY + 1, cz + 0.5) <= 4.3) {
                    b.useOnBlockTop(cx, baseY, cz);
                    br.consume(Brain.S_SECOND);
                    phase = 1; placedAt = w.now; onObsidian = obs;
                    ex = cx + 0.5; ey = baseY + 1; ez = cz + 0.5;
                    placeCd = tier.max() ? 2 : 3 + r.nextInt(tier.hitDelayMax() / 2 + 3);
                }
            }
            case 4 -> {
                br.select(Brain.S_WEAPON);
                if (br.cooldown <= 0 && br.reachDist(t) <= tier.reach() && err < 14) {
                    b.attack(t.id);
                    br.cooldown = 13 + r.nextInt(tier.hitDelayMax() + 1);
                    br.afterHit(flat);
                }
            }
            default -> { }
        }
    }
}
