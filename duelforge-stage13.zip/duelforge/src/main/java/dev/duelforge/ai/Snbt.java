package dev.duelforge.ai;

import java.util.LinkedHashMap;
import java.util.Map;

/** Tiny SNBT helper: splits the top level of a compound into key -> raw value text. */
public final class Snbt {
    private Snbt() {}

    public static String unquote(String s) {
        if (s == null) return null;
        s = s.trim();
        if (s.length() >= 2 && (s.charAt(0) == '"' || s.charAt(0) == '\'') && s.charAt(s.length() - 1) == s.charAt(0)) {
            char q = s.charAt(0);
            String inner = s.substring(1, s.length() - 1);
            return inner.replace("\\" + q, String.valueOf(q)).replace("\\\\", "\\");
        }
        return s;
    }

    /** {a:1,"b:c":{x:2}} -> {a=1, b:c={x:2}} (keys unquoted, values left as written). */
    public static Map<String, String> topLevel(String snbt) {
        Map<String, String> out = new LinkedHashMap<>();
        if (snbt == null) return out;
        String s = snbt.trim();
        if (s.length() < 2 || s.charAt(0) != '{') return out;
        int i = 1, n = s.length();
        while (i < n) {
            while (i < n && (Character.isWhitespace(s.charAt(i)) || s.charAt(i) == ',')) i++;
            if (i >= n || s.charAt(i) == '}') break;
            int ks = i;
            if (s.charAt(i) == '"' || s.charAt(i) == '\'') i = skipString(s, i);
            else while (i < n && s.charAt(i) != ':') i++;
            String key = unquote(s.substring(ks, i));
            while (i < n && s.charAt(i) != ':') i++;
            i++;                                              // ':'
            int vs = i, depth = 0;
            while (i < n) {
                char c = s.charAt(i);
                if (c == '"' || c == '\'') { i = skipString(s, i); continue; }
                if (c == '{' || c == '[' || c == '(') depth++;
                else if (c == '}' || c == ']' || c == ')') { if (depth == 0) break; depth--; }
                else if (c == ',' && depth == 0) break;
                i++;
            }
            out.put(key.trim(), s.substring(vs, Math.min(i, n)).trim());
        }
        return out;
    }

    /** Index just after the closing quote of the string starting at i. */
    private static int skipString(String s, int i) {
        char q = s.charAt(i++);
        while (i < s.length()) {
            char c = s.charAt(i++);
            if (c == '\\') i++;
            else if (c == q) break;
        }
        return i;
    }
}
