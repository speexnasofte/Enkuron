package dev.duelforge.ai;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntSupplier;

/**
 * Coordination between many bots that fight the same player.
 * A player is invulnerable for ~10 ticks after a hit, so extra hits inside that window do nothing and only reset the
 * attacker's weapon cooldown. Bots therefore reserve a hit window per target and wait their turn with a fully charged
 * swing instead of wasting it. Bots also pick different angles around the target.
 */
public final class Swarm {
    private Swarm() {}

    /** Clock in ticks (wall clock by default; the simulator replaces it). */
    public static volatile IntSupplier clock = () -> (int) (System.currentTimeMillis() / 50);

    private static final Map<Integer, Integer> LAST = new ConcurrentHashMap<>();

    /** @return true if this bot may swing at the target now (and claims the window). */
    public static boolean reserveHit(int targetId, int window) {
        final int now = clock.getAsInt();
        final boolean[] ok = {false};
        LAST.compute(targetId, (k, v) -> {
            if (v == null || now - v >= window) { ok[0] = true; return now; }
            return v;
        });
        return ok[0];
    }

    public static void reset() { LAST.clear(); }

    /** Stable angle (radians) around the target for this bot. */
    public static double ring(String name) {
        int h = name.hashCode() * 0x9E3779B1;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65536.0 * Math.PI * 2;
    }
}
