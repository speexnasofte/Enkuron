import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;
import java.util.function.Consumer;

public class Sim {
    static final class Pkt { int id; byte[] data; Pkt(int i, byte[] d){id=i;data=d;} }

    static long px(long p){ return p >> 38; }
    static long py(long p){ return (p << 52) >> 52; }
    static long pz(long p){ return (p << 26) >> 38; }

    // ---- scenario outputs
    static int rails, carts, ignites, shieldUp, releases, obsPlaced, crystalPlaced, crystalBroken, anchorPlaced, anchorCharged, anchorBoom, bowReleases, useItems, swaps, attacksOnEnemy, selects;
    static List<String> log = new ArrayList<>();
    static double arrowHits, arrowShots;

    static double startX = 10; static int lowHpFrom = -1, lowHpTo = -1;
    static void run(String title, Mode mode, Tier tier, Opts.Obsidian obsPolicy, boolean floorObsidian, boolean movingTarget, int ticks, boolean totemTest) {
        rails=carts=ignites=shieldUp=releases=obsPlaced=crystalPlaced=crystalBroken=anchorPlaced=anchorCharged=anchorBoom=bowReleases=useItems=swaps=attacksOnEnemy=selects=0;
        arrowHits=arrowShots=0; log.clear();
        Opts.obsidian = obsPolicy;
        Random rnd = new Random(7);
        final World w = new World();
        final List<Pkt> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Pkt(id, o.bytes())); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        World.Ent enemy = w.add(1000, eu, 128, 0, 64, 0, 0);
        body.entityId = 1;
        body.serverPosition(startX, 64, 0, 0, 0, 0, 90, 0);
        Brain brain = new Brain(body, w, rnd, tier, mode, "A", Set.of(), "Bot1");

        Set<Long> serverObs = new HashSet<>();
        Set<Long> anchors = new HashSet<>();
        Set<Long> railSet = new HashSet<>();
        Map<Integer,double[]> pendingCrystals = new HashMap<>(); // spawn at tick
        List<int[]> spawnQueue = new ArrayList<>();               // {tick, x,y,z}
        int sel = 0, nextId = 2000;
        double ex = 0, dir = 1;

        for (int tick = 1; tick <= ticks; tick++) {
            w.now = tick;
            if (lowHpFrom > 0 && tick == lowHpFrom) body.health = 6f;
            if (lowHpTo > 0 && tick == lowHpTo) body.health = 20f;
            if (totemTest && tick == 20) body.health = 1.0f;
            if (totemTest && tick == 19) body.health = 20f;
            // moving target: strafes +-3 blocks along z at 0.2/tick
            if (movingTarget) {
                double nz = enemy.z + dir * 0.2;
                if (Math.abs(nz) > 3) dir = -dir;
                enemy.moveTo(enemy.x, enemy.y, enemy.z + dir * 0.2, tick);
            }
            // spawn queued crystals
            for (Iterator<int[]> it = spawnQueue.iterator(); it.hasNext();) {
                int[] s = it.next();
                if (s[0] <= tick) { w.add(nextId++, UUID.randomUUID(), 77, s[1]+0.5, s[2], s[3]+0.5, tick); it.remove(); }
            }
            out.clear();
            brain.tick(); body.step(); body.flush();
            for (Pkt p : out) {
                Wire.In in = new Wire.In(p.data);
                if (p.id == Ids.SB_SET_CARRIED) { sel = in.i16(); selects++; }
                else if (p.id == Ids.SB_PLAYER_ACTION) {
                    int st = in.varInt();
                    if (st == 6) { swaps++; log.add(tick + ": swap offhand (held slot " + sel + ")"); }
                    if (st == 5) releases++;
                    if (st == 5 && (mode.ranged() || mode == Mode.UHC)) {
                        bowReleases++;
                        // fly an arrow and see whether it passes through the target
                        double yaw = Math.toRadians(body.yaw), pit = Math.toRadians(body.pitch);
                        double sp = (mode == Mode.BOW || mode == Mode.UHC) ? 3.0 : mode == Mode.CROSSBOW ? 3.15 : 2.5;
                        double vx = -Math.sin(yaw)*Math.cos(pit)*sp, vy = -Math.sin(pit)*sp, vz = Math.cos(yaw)*Math.cos(pit)*sp;
                        double x = body.x, y = body.y+1.62, z = body.z; boolean hit=false;
                        for (int k = 0; k < 200 && !hit; k++) {
                            for (int q = 1; q <= 12 && !hit; q++) {
                                double f = q / 12.0;
                                double sx = x+vx*f, sy = y+vy*f, sz = z+vz*f;
                                double ez = enemy.z + (movingTarget ? dir*0.2*(k+f) : 0);
                                if (Math.abs(sx-enemy.x)<0.45 && Math.abs(sz-ez)<0.45 && sy>enemy.y && sy<enemy.y+1.8) hit=true;
                            }
                            x+=vx; y+=vy; z+=vz; vx*=0.99; vy=vy*0.99-0.05; vz*=0.99;
                        }
                        arrowShots++; if (hit) arrowHits++;
                    }
                } else if (p.id == Ids.SB_USE_ITEM) { useItems++; if (in.varInt() == 1) shieldUp++; }
                else if (p.id == Ids.SB_USE_ITEM_ON) {
                    in.varInt(); long pos = in.i64();
                    int x=(int)px(pos), y=(int)py(pos), z=(int)pz(pos);
                    if (mode == Mode.CRYSTAL) {
                        if (sel == Brain.S_THIRD) { serverObs.add(((long)x<<40)^((long)y<<20)^z); obsPlaced++; log.add(tick+": obsidian placed on floor block ("+x+","+y+","+z+") -> obsidian at y="+(y+1)); serverObs.add(((long)x<<40)^((long)(y+1)<<20)^z); }
                        else if (sel == Brain.S_SECOND) {
                            boolean onObs = serverObs.contains(((long)x<<40)^((long)y<<20)^z) && y >= 64;
                            boolean ok = onObs || (floorObsidian && y == 63);
                            crystalPlaced++;
                            log.add(tick+": crystal use on ("+x+","+y+","+z+") valid="+ok);
                            if (ok) spawnQueue.add(new int[]{tick+2, x, y+1, z});
                        }
                    } else if (mode == Mode.CART) {
                        long k = ((long)x<<40)^((long)y<<20)^z;
                        if (sel == Brain.S_SECOND) { railSet.add(((long)x<<40)^((long)(y+1)<<20)^z); rails++; }
                        else if (sel == Brain.S_THIRD && railSet.contains(k)) { carts++; spawnQueue.add(new int[]{tick+1, x, y+1, z}); log.add(tick+": minecart placed at ("+x+","+(y+1)+","+z+")"); }
                    } else if (mode == Mode.ANCHOR) {
                        long k = ((long)x<<40)^((long)y<<20)^z;
                        if (sel == Brain.S_SECOND) { anchors.add(((long)x<<40)^((long)(y+1)<<20)^z); anchorPlaced++; log.add(tick+": anchor placed at ("+x+","+(y+1)+","+z+")"); }
                        else if (sel == Brain.S_THIRD && anchors.contains(k)) { anchorCharged++; log.add(tick+": anchor charged"); }
                        else if (sel == Brain.S_WEAPON && anchors.contains(k)) { anchorBoom++; anchors.remove(k); log.add(tick+": anchor detonated"); }
                    }
                } else if (p.id == Ids.SB_INTERACT) {
                    int target = in.varInt();
                    int itype = in.varInt();
                    World.Ent e = w.ents.get(target);
                    if (itype == 0 && mode == Mode.CART) { ignites++; log.add(tick+": TNT minecart ignited, bot at x="+String.format("%.1f",body.x)); }
                    else if (target == 1000) attacksOnEnemy++;
                    else if (e != null) { crystalBroken++; w.ents.remove(target); log.add(tick+": crystal broken (id "+target+")"); }
                }
            }
        }
        System.out.println("=== " + title + " ===");
        System.out.printf("state=%s hp=%.1f  selects=%d useItem=%d swapOffhand=%d attacks(enemy)=%d total attacks=%d%n", brain.state, body.health, selects, useItems, swaps, attacksOnEnemy, body.attacks);
        if (mode == Mode.CRYSTAL) System.out.printf("obsidian=%d crystals placed=%d broken=%d%n", obsPlaced, crystalPlaced, crystalBroken);
        if (mode == Mode.CART) System.out.printf("rails=%d carts=%d ignited=%d  final bot x=%.1f%n", rails, carts, ignites, body.x);
        if (mode == Mode.SHIELD) System.out.printf("shield raised=%d released=%d%n", shieldUp, releases);
        if (mode == Mode.ANCHOR) System.out.printf("anchors placed=%d charged=%d detonated=%d%n", anchorPlaced, anchorCharged, anchorBoom);
        if (mode.ranged()) System.out.printf("releases=%d arrows through target=%.0f of %.0f%n", bowReleases, arrowHits, arrowShots);
        for (int i = 0; i < Math.min(14, log.size()); i++) System.out.println("   " + log.get(i));
    }

    public static void main(String[] a) {
        run("CRYSTAL / grass floor / AUTO", Mode.CRYSTAL, Tier.HT3, Opts.Obsidian.AUTO, false, false, 400, false);
        run("CRYSTAL / obsidian floor / AUTO", Mode.CRYSTAL, Tier.HT3, Opts.Obsidian.AUTO, true, false, 400, false);
        run("CRYSTAL / grass floor / ALWAYS", Mode.CRYSTAL, Tier.HT1, Opts.Obsidian.ALWAYS, false, false, 400, false);
        run("ANCHOR", Mode.ANCHOR, Tier.HT3, Opts.Obsidian.AUTO, false, false, 400, false);
        run("CART", Mode.CART, Tier.HT3, Opts.Obsidian.AUTO, false, false, 400, false);
        run("SHIELD", Mode.SHIELD, Tier.HT3, Opts.Obsidian.AUTO, false, false, 300, false);
        startX = 30; run("UHC from 30 blocks (bow, then sword)", Mode.UHC, Tier.HT2, Opts.Obsidian.AUTO, false, true, 700, false); startX = 10;
        startX = 20; lowHpFrom = -1; run("NETHPOT (buffs at start)", Mode.NETHPOT, Tier.HT3, Opts.Obsidian.AUTO, false, false, 120, false); startX = 10;
        run("BOW vs standing target (HT1)", Mode.BOW, Tier.HT1, Opts.Obsidian.AUTO, false, false, 600, false);
        run("BOW vs strafing target (HT1)", Mode.BOW, Tier.HT1, Opts.Obsidian.AUTO, false, true, 800, false);
        run("CROSSBOW vs strafing target (HT2)", Mode.CROSSBOW, Tier.HT2, Opts.Obsidian.AUTO, false, true, 800, false);
        run("TRIDENT vs strafing target (HT2)", Mode.TRIDENT, Tier.HT2, Opts.Obsidian.AUTO, false, true, 800, false);
        lowHpFrom = 60; lowHpTo = 140; run("POT (hp 6 from tick 60..140)", Mode.POT, Tier.HT3, Opts.Obsidian.AUTO, false, false, 220, false); lowHpFrom = lowHpTo = -1;
        startX = 32; run("PEARL (starts 32 blocks away)", Mode.PEARL, Tier.HT3, Opts.Obsidian.AUTO, false, false, 300, false); startX = 10;
        run("SWORD + totem pop", Mode.SWORD, Tier.HT3, Opts.Obsidian.AUTO, false, false, 80, true);
        for (Mode m : Mode.values()) if (m != Mode.MIXED) run("smoke " + m, m, Tier.LT5, Opts.Obsidian.AUTO, false, true, 300, false);
        startX = 10; run("MIXED smoke", Mode.MIXED, Tier.HT2, Opts.Obsidian.AUTO, false, true, 1200, false);
    }
}
