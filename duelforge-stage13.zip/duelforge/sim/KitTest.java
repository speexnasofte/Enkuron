import dev.duelforge.ai.*;
import java.nio.file.*;
import java.util.*;

/** Kit system checks that need no Minecraft: SNBT conversion, file round trip, mode guess, hotbar layout, commands. */
public class KitTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    public static void main(String[] a) throws Exception {
        KitStore.dir = Files.createTempDirectory("kits");
        // what Tag.toString() prints for a stack: quoted component keys, nested compounds, removed component
        String sword = "{components:{\"minecraft:enchantments\":{\"minecraft:sharpness\":5,\"minecraft:unbreaking\":3},\"minecraft:custom_name\":'{\"text\":\"Blade, of: doom\"}',\"!minecraft:attribute_modifiers\":{}},count:1,id:\"minecraft:netherite_sword\"}";
        Kit.Entry e = Kit.fromSnbt(sword);
        System.out.println("item string: " + e.item());
        check("sword id + enchantments + removed component", e.item().startsWith("minecraft:netherite_sword[minecraft:enchantments={")
                && e.item().contains("!minecraft:attribute_modifiers") && e.item().contains("Blade, of: doom") && e.count() == 1);
        Kit.Entry cr = Kit.fromSnbt("{count:64,id:\"minecraft:end_crystal\"}");
        check("plain stack keeps count, no brackets", cr.count() == 64 && cr.item().equals("minecraft:end_crystal"));
        check("air is ignored", Kit.fromSnbt("{count:1,id:\"minecraft:air\"}") == null);

        Kit k = new Kit("Crystal Main");
        k.slots.put("hotbar.3", e);
        k.slots.put("hotbar.0", Kit.fromSnbt("{count:1,id:\"minecraft:netherite_sword\"}"));
        k.slots.put("hotbar.5", cr);
        k.slots.put("hotbar.1", Kit.fromSnbt("{count:64,id:\"minecraft:obsidian\"}"));
        k.slots.put("hotbar.6", Kit.fromSnbt("{count:12,id:\"minecraft:golden_apple\"}"));
        k.slots.put("hotbar.8", Kit.fromSnbt("{count:6,id:\"minecraft:totem_of_undying\"}"));
        k.slots.put("armor.head", Kit.fromSnbt("{count:1,id:\"minecraft:netherite_helmet\"}"));
        k.slots.put("weapon.offhand", Kit.fromSnbt("{count:1,id:\"minecraft:totem_of_undying\"}"));
        k.mode = k.guessMode();
        check("mode guessed from items = CRYSTAL", k.mode == Mode.CRYSTAL);

        check("name sanitized", KitStore.sanitize("my kit/ё!").equals("my_kit___"));
        k.name = KitStore.sanitize(k.name);
        check("save", KitStore.save(k));
        Kit r = KitStore.get("crystal_main");
        check("load is case-insensitive", r != null && r.slots.size() == k.slots.size() && r.mode == Mode.CRYSTAL);
        check("round trip keeps item text", r.slots.get("hotbar.3").item().equals(e.item()));
        check("rename", KitStore.rename("crystal_main", "pvp-1") && KitStore.get("crystal_main") == null && KitStore.get("pvp-1") != null);
        check("rename onto an existing name fails", !KitStore.rename("pvp-1", "pvp-1"));
        check("list", KitStore.names().equals(List.of("pvp-1")));

        List<String> cmds = r.commands("Bot7", true);
        System.out.println("commands for a bot: " + cmds.size() + ", e.g. " + cmds.get(1));
        check("clear first, one /item replace per slot", cmds.get(0).equals("clear Bot7") && cmds.size() == 1 + r.slots.size());
        check("count appended only when >1", cmds.stream().anyMatch(c -> c.endsWith("with minecraft:end_crystal 64")) && cmds.stream().anyMatch(c -> c.contains("hotbar.0 with minecraft:netherite_sword") && !c.endsWith(" 1")));

        String back = Kit.stackSnbt("minecraft:netherite_sword[minecraft:enchantments={levels:{\"minecraft:sharpness\":5}},minecraft:custom_name='{\"text\":\"A, B\"}',!minecraft:attribute_modifiers]", 1);
        System.out.println("stack snbt: " + back);
        Map<String, String> bm = Snbt.topLevel(back);
        Map<String, String> bc = Snbt.topLevel(bm.get("components"));
        check("stackSnbt: id, count, 3 components incl. removed one, comma in a name survives",
                "\"minecraft:netherite_sword\"".equals(bm.get("id")) && "1".equals(bm.get("count")) && bc.size() == 3 && bc.containsKey("!minecraft:attribute_modifiers") && bc.get("minecraft:custom_name").contains("A, B"));
        Layout lay = Layout.detect(Mode.CRYSTAL, r.hotbarItems());
        System.out.println("layout: " + lay.describe());
        check("crystal layout: weapon 0, crystals 5, obsidian 1, apples 6, totem 8",
                lay.map(0) == 0 && lay.map(1) == 5 && lay.map(3) == 1 && lay.map(2) == 6 && lay.map(8) == 8);

        String[] pot = {"minecraft:netherite_sword", "minecraft:splash_potion[minecraft:potion_contents={potion:\"minecraft:strong_healing\"}]", "", "minecraft:splash_potion[minecraft:potion_contents={potion:\"minecraft:strong_swiftness\"}]",
                "minecraft:splash_potion[minecraft:potion_contents={potion:\"minecraft:strong_strength\"}]", "minecraft:splash_potion[minecraft:potion_contents={potion:\"minecraft:harming\"}]", "", "minecraft:ender_pearl", ""};
        Layout lp = Layout.detect(Mode.NETHPOT, pot);
        check("nethpot layout: heal pot 1, harm 5, speed 3, strength 4, pearl 7", lp.map(1) == 1 && lp.map(3) == 5 && lp.map(4) == 3 && lp.map(5) == 4 && lp.map(7) == 7);
        Layout lc = Layout.detect(Mode.CART, new String[]{"minecraft:iron_sword", "", "", "minecraft:flint_and_steel", "minecraft:tnt_minecart", "minecraft:rail", "", "", ""});
        check("cart layout: rail 5, minecart 4, flint 3", lc.map(1) == 5 && lc.map(3) == 4 && lc.map(4) == 3);
        Layout ls = Layout.detect(Mode.SPEAR, new String[]{"", "minecraft:netherite_spear", "", "", "", "", "", "", ""});
        check("spear found in slot 2", ls.map(0) == 1);
        check("unknown roles keep the default", Layout.detect(Mode.SWORD, new String[9]).describe().equals("стандартная"));

        Kit guess = new Kit("t");
        guess.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:diamond_sword")); guess.slots.put("hotbar.1", new Kit.Entry(1, "minecraft:bow"));
        check("sword+bow -> UHC", guess.guessMode() == Mode.UHC);
        guess.slots.clear(); guess.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_spear"));
        check("spear -> SPEAR", guess.guessMode() == Mode.SPEAR);
        guess.slots.clear(); guess.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_mace")); guess.slots.put("hotbar.1", new Kit.Entry(1, "minecraft:wind_charge"));
        check("mace -> MACE", guess.guessMode() == Mode.MACE);
        check("delete", KitStore.delete("PVP-1") && KitStore.names().isEmpty());
        System.out.println(fail == 0 ? "ALL KIT CHECKS PASSED" : fail + " FAILED");
        System.exit(fail == 0 ? 0 : 1);
    }
}
