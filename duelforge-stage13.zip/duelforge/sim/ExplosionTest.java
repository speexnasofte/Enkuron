import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * v2.1 checks: crystal damage model (ported from Expensive), damage-aware crystal placement and hitbox aim.
 * Run: javac -cp out -d out sim/ExplosionTest.java && java -cp out ExplosionTest
 */
public class ExplosionTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    static long px(long p) { return p >> 38; }
    static long py(long p) { return (p << 52) >> 52; }
    static long pz(long p) { return (p << 26) >> 38; }

    static Kit kit(String armor) {
        Kit k = new Kit("c");
        k.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_sword"));
        k.slots.put("hotbar.1", new Kit.Entry(64, "minecraft:end_crystal"));
        k.slots.put("hotbar.2", new Kit.Entry(8, "minecraft:golden_apple"));
        k.slots.put("hotbar.3", new Kit.Entry(64, "minecraft:obsidian"));
        k.slots.put("hotbar.8", new Kit.Entry(4, "minecraft:totem_of_undying"));
        if (armor != null)
            for (String p : new String[]{"helmet:head", "chestplate:chest", "leggings:legs", "boots:feet"})
                k.slots.put("armor." + p.split(":")[1], new Kit.Entry(1, "minecraft:" + armor + "_" + p.split(":")[0] + "[enchantments={blast_protection:4}]"));
        k.mode = Mode.CRYSTAL;
        return k;
    }

    /** Returns {placements, lethalPlacements, evadeTicks, finalPitch}. */
    static double[] run(Tier tier, float hp, String armor, double enemyDist, boolean smart, int ticks) { return run(Mode.CRYSTAL, tier, hp, armor, enemyDist, smart, ticks); }

    static double[] run(Mode mode, Tier tier, float hp, String armor, double enemyDist, boolean smart, int ticks) {
        Opts.smartCrystal = smart; Opts.obsidian = Opts.Obsidian.NEVER;
        Random rnd = new Random(3);
        World w = new World();
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        World.Ent enemy = w.add(1000, eu, 128, enemyDist, 64, 0, 0);
        body.entityId = 1; body.health = hp;
        body.serverPosition(0, 64, 0, 0, 0, 0, -90, 0);
        Brain brain = new Brain(body, w, rnd, tier, mode, "A", Set.of(), "Bot1");
        Kit k = kit(armor);
        brain.setLayout(Layout.detect(mode, k.hotbarItems()));
        brain.setKit(k);
        ExplosionMath.Armor mine = ExplosionMath.Armor.fromKit(k);
        int sel = 0, placed = 0, lethal = 0, evade = 0, n = 0; double pitchSum = 0;
        for (int tick = 1; tick <= ticks; tick++) {
            w.now = tick;
            out.clear();
            brain.tick(); body.step(); body.flush();
            if (brain.state.contains("evade")) evade++;
            if (tick > ticks / 3) { pitchSum += body.pitch; n++; }
            for (Object[] pk : out) {
                int id = (Integer) pk[0];
                Wire.In in = new Wire.In((byte[]) pk[1]);
                if (id == Ids.SB_SET_CARRIED) sel = in.i16();
                else if (id == Ids.SB_USE_ITEM_ON && sel == Brain.S_SECOND) {
                    in.varInt(); long pos = in.i64();
                    double cx = px(pos) + 0.5, cy = py(pos) + 1, cz = pz(pos) + 0.5;
                    placed++;
                    double self = ExplosionMath.crystal(mine, cx, cy, cz, body.x, body.y, body.z);
                    if (self >= hp - 2.0) lethal++;
                }
            }
        }
        return new double[]{placed, lethal, evade, n == 0 ? 0 : pitchSum / n};
    }

    public static void main(String[] a) {
        System.out.println("=== damage model ===");
        ExplosionMath.Armor n = ExplosionMath.Armor.NETHERITE_P4;
        double near = ExplosionMath.crystal(n, 0, 0, 0, 1, 0, 0), mid = ExplosionMath.crystal(n, 0, 0, 0, 6, 0, 0);
        System.out.printf("   netherite P4: 1 block %.1f, 6 blocks %.1f; naked: 1 block %.1f, 6 blocks %.1f%n",
                near, mid, ExplosionMath.crystal(ExplosionMath.Armor.NONE, 0, 0, 0, 1, 0, 0), ExplosionMath.crystal(ExplosionMath.Armor.NONE, 0, 0, 0, 6, 0, 0));
        check("point blank on full netherite is a big hit (10..30)", near > 10 && near < 30);
        check("damage falls with distance", near > mid && mid > ExplosionMath.crystal(n, 0, 0, 0, 10, 0, 0));
        check("nothing beyond 12 blocks", ExplosionMath.crystal(n, 0, 0, 0, 12.5, 0, 0) == 0);
        check("naked 6 blocks away is lethal (>20)", ExplosionMath.crystal(ExplosionMath.Armor.NONE, 0, 0, 0, 6, 0, 0) > 20);
        check("armor always helps: diamond < none", ExplosionMath.crystal(ExplosionMath.Armor.DIAMOND_P4, 0, 0, 0, 3, 0, 0) < ExplosionMath.crystal(ExplosionMath.Armor.NONE, 0, 0, 0, 3, 0, 0));
        check("resistance 2 cuts 40%", Math.abs(ExplosionMath.afterArmor(10, ExplosionMath.Armor.NONE.withResistance(2)) - 6.0) < 1e-9);
        Kit full = new Kit("f");
        for (String p : new String[]{"helmet:head", "chestplate:chest", "leggings:legs", "boots:feet"})
            full.slots.put("armor." + p.split(":")[1], new Kit.Entry(1, "minecraft:netherite_" + p.split(":")[0] + "[enchantments={protection:4,unbreaking:3}]"));
        ExplosionMath.Armor fa = ExplosionMath.Armor.fromKit(full);
        check("kit armor: 4 netherite pieces = 20 armor, 12 toughness, Prot IV x4 = 16", fa.armor() == 20 && fa.toughness() == 12 && fa.epf() == 16);
        Kit bp = new Kit("b");
        bp.slots.put("armor.head", new Kit.Entry(1, "minecraft:diamond_helmet[enchantments={blast_protection:4}]"));
        check("kit armor: Blast Prot IV counts double (8), 'blast_protection' is not read as plain protection", ExplosionMath.Armor.fromKit(bp).epf() == 8);
        check("no armor in kit -> NONE", ExplosionMath.Armor.fromKit(new Kit("e")).equals(ExplosionMath.Armor.NONE));

        System.out.println("=== smart crystal placement (naked bot, 6 hp, enemy 2.5 blocks away) ===");
        double[] off = run(Tier.HT3, 6f, null, 2.5, false, 400);
        double[] on = run(Tier.HT3, 6f, null, 2.5, true, 400);
        System.out.printf("   old logic: %d crystals, %d would have killed/crippled us; smart: %d crystals, %d lethal, %d evade ticks%n",
                (int) off[0], (int) off[1], (int) on[0], (int) on[1], (int) on[2]);
        check("smart: no placed crystal leaves us under the reserve", on[1] == 0);
        check("old logic does place such crystals (the test is meaningful)", off[1] > 0);
        double[] healthy = run(Tier.HT3, 20f, "netherite", 2.5, true, 400);
        System.out.printf("   full-hp netherite bot: %d crystals, %d lethal%n", (int) healthy[0], (int) healthy[1]);
        check("healthy armored bot still places crystals", healthy[0] >= 3 && healthy[1] == 0);

        System.out.println("=== hitbox aim ===");
        double[] best = run(Mode.SWORD, Tier.HT3, 20f, "netherite", 2.5, true, 20);
        Opts.hitboxAim = false;
        double[] off2 = run(Mode.SWORD, Tier.HT3, 20f, "netherite", 2.5, true, 20);
        Opts.hitboxAim = true;
        double[] low = run(Mode.SWORD, Tier.LT5, 20f, "netherite", 2.5, true, 20);
        System.out.printf("   sword duel, mean pitch while closing in: HT3 hitbox aim %.1f, HT3 chest point %.1f, LT5 %.1f%n", best[3], off2[3], low[3]);
        check("HT3 with hitbox aim looks less downward than the fixed chest point", best[3] < off2[3] - 1.0);
        check("low tiers keep the chest point (setting does not change them)", Math.abs(low[3] - off2[3]) < 6);
        System.out.println(fail == 0 ? "ALL OK" : fail + " FAILED");
        System.exit(fail == 0 ? 0 : 1);
    }
}
