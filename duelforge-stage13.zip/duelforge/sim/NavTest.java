import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * Walking around walls: A* over a hand-built block world, then a whole bot (Brain + Body physics) that has to get to an
 * enemy standing behind a wall, up a one-block ledge, and out of a U-shaped pocket.
 *
 *   javac -d out $(find ../src/main/java/dev/duelforge/ai ../src/main/java/dev/duelforge/net -name '*.java') ChunkTest.java NavTest.java
 */
public class NavTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    interface Fill { byte at(int x, int y, int z); }

    static ChunkStore build(Fill f) {
        ChunkTest.setTable();
        ChunkStore st = new ChunkStore();
        for (int cx = -3; cx <= 3; cx++) for (int cz = -3; cz <= 3; cz++) {
            ChunkStore.Chunk c = new ChunkStore.Chunk(-4, 24);
            for (int s = 0; s < 24; s++) {
                byte[] arr = new byte[4096];
                for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                    arr[(y * 16 + z) * 16 + x] = f.at(cx * 16 + x, -64 + s * 16 + y, cz * 16 + z);
                c.setSection(s, (byte) 0, arr);
            }
            st.put(cx, cz, c);
        }
        return st;
    }

    static final byte A = BlockTable.AIR, F = BlockTable.FULL;

    static byte flat(int y) { return y <= 63 ? F : A; }

    static boolean crossesWall(int[][] p, int wallX) { for (int[] c : p) if (c[0] == wallX && c[1] < 67) return true; return false; }

    // ---------------------------------------------------------------- whole-bot harness
    static double[] walk(ChunkStore terrain, double bx, double bz, double ex, double ez, int ticks) {
        Random rnd = new Random(3);
        World w = new World();
        // share the prebuilt chunks
        for (int cx = -3; cx <= 3; cx++) for (int cz = -3; cz <= 3; cz++) copy(terrain, w.chunks, cx, cz);
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        body.terrain = w.chunks;
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        w.add(1000, eu, 128, ex, 64, ez, 0);
        body.entityId = 1;
        body.serverPosition(bx, 64, bz, 0, 0, 0, -90, 0);
        Brain brain = new Brain(body, w, rnd, Tier.HT2, Mode.SWORD, "A", Set.of(), "Bot1");
        Kit k = new Kit("t");
        k.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_sword"));
        k.mode = Mode.SWORD;
        brain.setLayout(Layout.detect(Mode.SWORD, k.hotbarItems()));
        brain.setKit(k);
        double best = 1e9; int navTicks = 0; int reach = -1;
        for (int tick = 1; tick <= ticks; tick++) {
            w.now = tick; out.clear();
            brain.tick(); body.step(); body.flush();
            if (brain.state.endsWith("+nav")) navTicks++;
            double d = Math.hypot(body.x - ex, body.z - ez);
            best = Math.min(best, d);
            if (d < 3.0 && reach < 0) reach = tick;
        }
        return new double[]{best, navTicks, reach, body.x, body.z};
    }

    static void copy(ChunkStore from, ChunkStore to, int cx, int cz) {
        // ChunkStore has no public chunk getter; rebuild from queries
        ChunkStore.Chunk c = new ChunkStore.Chunk(-4, 24);
        for (int s = 0; s < 24; s++) {
            byte[] arr = new byte[4096];
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                arr[(y * 16 + z) * 16 + x] = (byte) from.get(cx * 16 + x, -64 + s * 16 + y, cz * 16 + z);
            c.setSection(s, (byte) 0, arr);
        }
        to.put(cx, cz, c);
    }

    public static void main(String[] a) {
        Opts.terrainPhysics = true; Opts.pathfinding = true;

        System.out.println("== A* ==");
        ChunkStore wall = build((x, y, z) -> y <= 63 ? F : (x == 5 && y <= 66 && z >= -10 && z <= 10 ? F : A));
        int[][] p = Nav.find(wall, 0, 64, 0, 10, 64, 0);
        check("wall with a gap around z=10: path found, ends next to the target", p != null && Math.abs(p[p.length - 1][0] - 10) <= 1 && Math.abs(p[p.length - 1][2]) <= 1);
        check("the path never enters the wall column", p != null && !crossesWall(p, 5) || (p != null && Arrays.stream(p).noneMatch(c -> c[0] == 5 && c[2] >= -10 && c[2] <= 10)));
        check("it goes round on diagonals (about 11 + 11 steps): " + (p == null ? 0 : p.length) + " cells", p != null && p.length >= 20 && p.length <= 30);

        ChunkStore ledge = build((x, y, z) -> y <= 63 ? F : (x == 5 && y == 64 ? F : A));
        p = Nav.find(ledge, 0, 64, 0, 10, 64, 0);
        boolean up = false, reached = p != null;
        if (p != null) for (int[] c : p) if (c[1] == 65) up = true;
        check("1-block ledge: the path steps up and over it, straight (" + (p == null ? 0 : p.length) + " cells)", reached && up && p.length <= 12);

        ChunkStore high = build((x, y, z) -> y <= 63 ? F : (x == 5 && y <= 65 && z >= -4 && z <= 4 ? F : A));
        p = Nav.find(high, 0, 64, 0, 10, 64, 0);
        check("2-block wall of 9 width: detour round it, not over", p != null && Arrays.stream(p).noneMatch(c -> c[1] > 64) && p.length > 10);

        ChunkStore boxed = build((x, y, z) -> y <= 63 ? F : ((Math.abs(x - 10) == 3 || Math.abs(z) == 3) && Math.abs(x - 10) <= 3 && Math.abs(z) <= 3 && y <= 68 ? F : A));
        p = Nav.find(boxed, 0, 64, 0, 10, 64, 0);
        check("target walled into a closed box: path leads to the closest reachable cell (outside the box)", p != null && Arrays.stream(p).allMatch(c -> Math.abs(c[0] - 10) > 3 || Math.abs(c[2]) > 3));

        ChunkStore lava = build((x, y, z) -> y <= 62 ? F : (y == 63 ? (x >= 3 && x <= 5 && z >= -45 && z <= 45 ? BlockTable.LAVA : F) : A));
        p = Nav.find(lava, 0, 64, 0, 10, 64, 0);
        check("a lava strip across the whole field is never stepped on (path stops at its edge)", p == null || Arrays.stream(p).noneMatch(c -> c[0] >= 3 && c[0] <= 5 && Math.abs(c[2]) <= 45));

        ChunkStore air = build((x, y, z) -> y <= 40 ? F : A);
        check("start in mid-air: no path", Nav.find(air, 0, 64, 0, 10, 64, 0) == null);

        ChunkStore pit = build((x, y, z) -> (x >= 4 && x <= 6) ? (y <= 61 ? F : A) : (y <= 63 ? F : A));
        p = Nav.find(pit, 0, 64, 0, 10, 64, 0);
        check("a 2-deep pit across the whole field: dropping in is a dead end, the path stops at its edge", p == null || Arrays.stream(p).allMatch(c -> c[0] <= 3));

        System.out.println("== whole bot (Brain + Body physics) ==");
        Opts.pathfinding = false;
        double[] r0 = walk(wall, 0.5, 0.5, 10.5, 0.5, 600);
        Opts.pathfinding = true;
        double[] r1 = walk(wall, 0.5, 0.5, 10.5, 0.5, 600);
        System.out.printf("   wall: pathfinding off: closest %.1f blocks, x=%.1f | on: closest %.1f, reached at tick %d, nav ticks %d%n", r0[0], r0[3], r1[0], (int) r1[2], (int) r1[1]);
        check("without pathfinding the bot is stuck at the wall (x <= 4.7)", r0[3] <= 4.7 + 1e-6 && r0[0] > 4);
        check("with pathfinding the bot walks round the wall and reaches the enemy", r1[0] < 3.0 && r1[2] > 0);

        Opts.pathfinding = false;
        double[] l0 = walk(ledge, 0.5, 0.5, 10.5, 0.5, 600);
        Opts.pathfinding = true;
        double[] l1 = walk(ledge, 0.5, 0.5, 10.5, 0.5, 600);
        System.out.printf("   1-block ledge: off: closest %.1f | on: closest %.1f, reached at tick %d%n", l0[0], l1[0], (int) l1[2]);
        check("pathfinding: the bot jumps onto and over the ledge", l1[0] < 3.0);

        ChunkStore pocket = build((x, y, z) -> y <= 63 ? F : ((x == 4 && z >= -4 && z <= 4 && y <= 66) || (z == 4 && x >= -2 && x <= 4 && y <= 66) || (z == -4 && x >= -2 && x <= 4 && y <= 66) ? F : A));
        Opts.pathfinding = false;
        double[] u0 = walk(pocket, 0.5, 0.5, 12.5, 0.5, 700);
        Opts.pathfinding = true;
        double[] u1 = walk(pocket, 0.5, 0.5, 12.5, 0.5, 700);
        System.out.printf("   U pocket (open to the back): off: closest %.1f | on: closest %.1f, reached at tick %d%n", u0[0], u1[0], (int) u1[2]);
        check("without pathfinding the bot stays in the pocket", u0[0] > 6);
        check("with pathfinding it leaves the pocket backwards and reaches the enemy", u1[0] < 3.0);

        double[] free = walk(build(NavTest::flatAt), 0.5, 0.5, 10.5, 0.5, 300);
        check("open field: nav stays out of the way (0 nav ticks), the bot still reaches the enemy", free[1] == 0 && free[0] < 3.0);

        System.out.println(fail == 0 ? "ALL OK" : "FAILED: " + fail);
        if (fail > 0) System.exit(1);
    }

    static byte flatAt(int x, int y, int z) { return flat(y); }
}
