import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * CRYSTAL bot with chunk data: on a known stone floor it builds an obsidian base first; on a known obsidian floor it
 * places the crystal straight away; without chunks it still tries the bare floor first (old behaviour).
 */
public class CrystalChunkTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    /** floor: 0 = no chunks, 1 = stone floor, 2 = obsidian floor. Returns the carried slots of the first block placements. */
    static List<Integer> run(int floor) {
        Random rnd = new Random(5);
        World w = new World();
        if (floor > 0) {
            ChunkTest.setTable();
            byte[] t = new byte[8];
            t[ChunkTest.AIR] = BlockTable.AIR; t[ChunkTest.STONE] = BlockTable.FULL; t[ChunkTest.OBS] = BlockTable.OBSIDIAN;
            BlockTable.set(t);
            for (int cx = -2; cx <= 2; cx++) for (int cz = -2; cz <= 2; cz++) {
                ChunkStore.Chunk c = new ChunkStore.Chunk(-4, 24);
                for (int s = 0; s < 24; s++) c.setSection(s, s < 8 ? (floor == 2 ? BlockTable.OBSIDIAN : BlockTable.FULL) : BlockTable.AIR, null);
                w.chunks.put(cx, cz, c);
            }
        }
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        w.add(1000, eu, 128, 3, 64, 0, 0);
        body.entityId = 1;
        body.serverPosition(0, 64, 0, 0, 0, 0, -90, 0);
        Brain brain = new Brain(body, w, rnd, Tier.HT2, Mode.CRYSTAL, "A", Set.of(), "Bot1");
        Kit k = new Kit("t");
        String[] hot = {"netherite_sword", "end_crystal", "golden_apple", "obsidian"};
        int[] cnt = {1, 64, 8, 64};
        for (int i = 0; i < hot.length; i++) k.slots.put("hotbar." + i, new Kit.Entry(cnt[i], "minecraft:" + hot[i]));
        k.mode = Mode.CRYSTAL;
        brain.setLayout(Layout.detect(Mode.CRYSTAL, k.hotbarItems()));
        brain.setKit(k);
        int sel = 0;
        List<Integer> placed = new ArrayList<>();
        for (int tick = 1; tick <= 200 && placed.size() < 3; tick++) {
            w.now = tick;
            out.clear();
            brain.tick(); body.step(); body.flush();
            for (Object[] pk : out) {
                int id = (Integer) pk[0];
                Wire.In in = new Wire.In((byte[]) pk[1]);
                if (id == Ids.SB_SET_CARRIED) sel = in.i16();
                else if (id == Ids.SB_USE_ITEM_ON) placed.add(sel);
            }
        }
        return placed;
    }

    public static void main(String[] a) {
        Opts.obsidian = Opts.Obsidian.AUTO;
        Opts.smartCrystal = false;   // cell choice by expected damage is a separate feature; here only the base block matters
        List<Integer> none = run(0), stone = run(1), obs = run(2);
        System.out.println("   first placements (slot 1 = crystal, 3 = obsidian): no chunks " + none + ", stone floor " + stone + ", obsidian floor " + obs);
        check("no chunks: tries the bare floor with a crystal first", !none.isEmpty() && none.get(0) == Brain.S_SECOND);
        check("known stone floor: builds an obsidian base first", !stone.isEmpty() && stone.get(0) == Brain.S_THIRD);
        check("known stone floor: the crystal goes on the new obsidian", stone.size() >= 2 && stone.get(1) == Brain.S_SECOND);
        check("known obsidian floor: crystal straight away, no obsidian placed", !obs.isEmpty() && obs.get(0) == Brain.S_SECOND && !obs.contains(Brain.S_THIRD));
        System.out.println(fail == 0 ? "ALL OK" : "FAILED: " + fail);
        if (fail > 0) System.exit(1);
    }
}
