import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * v1.6 checks for UHC / TRAPPER (web, lava, fire, water steal) and MACE_PRO (launch, dive, smash).
 * A tiny fake server: it reads the packets the bot sends, tracks what the bot placed and moves the enemy / the bot the way
 * the real server would (web holds the enemy, a wind charge pushes the bot up). Run: java -cp out TrapTest
 */
public class TrapTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    static long px(long p) { return p >> 38; }
    static long py(long p) { return (p << 52) >> 52; }
    static long pz(long p) { return (p << 26) >> 38; }

    static Kit kit(Mode m) {
        Kit k = new Kit("t");
        String[] hot = switch (m) {
            case UHC -> new String[]{"netherite_sword", "bow", "golden_apple", "cobweb", "lava_bucket", "flint_and_steel", "bucket"};
            case TRAPPER -> new String[]{"netherite_sword", "", "golden_apple", "cobweb", "lava_bucket", "flint_and_steel", "bucket"};
            default -> new String[]{"mace[enchantments={wind_burst:1}]", "wind_charge", "golden_apple"};
        };
        int[] cnt = switch (m) {
            case UHC, TRAPPER -> new int[]{1, 1, 8, 6, 1, 1, 1};
            default -> new int[]{1, 12, 8};
        };
        for (int i = 0; i < hot.length; i++) if (!hot[i].isEmpty()) k.slots.put("hotbar." + i, new Kit.Entry(cnt[i], "minecraft:" + hot[i]));
        k.mode = m;
        return k;
    }

    /** Give the bot chunk data (flat stone floor up to y=63) and break the web this many ticks after it was placed (-1: never). */
    static boolean chunks = false;
    static int breakWebAfter = -1;

    static void floor(World w) {
        ChunkTest.setTable();
        for (int cx = -2; cx <= 2; cx++) for (int cz = -2; cz <= 3; cz++) {
            ChunkStore.Chunk c = new ChunkStore.Chunk(-4, 24);
            for (int sec = 0; sec < 24; sec++) c.setSection(sec, sec < 8 ? BlockTable.FULL : BlockTable.AIR, null);
            w.chunks.put(cx, cz, c);
        }
    }

    /** Result of one scenario. */
    static final class R {
        List<String> log = new ArrayList<>();
        int webs, lava, fire, scoops, steals, pours, attacks, smashes, wind;
        double maxFall, firstWebTick = -1, firstLavaTick = -1, lavaBotDist = -1, minDistToLava = 99;
        int lavaX, lavaZ, webX, webZ;
        List<Integer> webTicks = new ArrayList<>();
        Set<String> states = new TreeSet<>();
    }

    interface Enemy { void move(World.Ent e, int tick, boolean webbed); }

    static R run(Mode mode, Tier tier, double startX, int ticks, Enemy mover, boolean webHolds) {
        R res = new R();
        Random rnd = new Random(11);
        World w = new World();
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        World.Ent enemy = w.add(1000, eu, 128, 0, 64, 0, 0);
        if (chunks) floor(w);
        body.entityId = 1;
        body.serverPosition(startX, 64, 0, 0, 0, 0, 90, 0);
        Brain brain = new Brain(body, w, rnd, tier, mode, "A", Set.of(), "Bot1");
        Kit k = kit(mode);
        brain.setLayout(Layout.detect(mode, k.hotbarItems()));
        brain.setKit(k);

        int sel = 0, webAt = -1000;
        int webCx = Integer.MIN_VALUE, webCz = 0;
        boolean lavaDown = false;
        double apex = 64;
        for (int tick = 1; tick <= ticks; tick++) {
            w.now = tick;
            if (breakWebAfter >= 0 && webCx != Integer.MIN_VALUE && tick - webAt == breakWebAfter) {
                if (chunks) w.chunks.setState(webCx, 64, webCz, ChunkTest.AIR);   // server tells the bot: block_update -> air
                webCx = Integer.MIN_VALUE;                                         // and the model enemy is free
            }
            boolean webbed = webCx != Integer.MIN_VALUE && tick - webAt < 90 && (int) Math.floor(enemy.x) == webCx && (int) Math.floor(enemy.z) == webCz;
            if (!(webHolds && webbed)) mover.move(enemy, tick, false);
            out.clear();
            brain.tick(); body.step(); body.flush();
            res.states.add(brain.state.split("/")[0] + "/" + (brain.state.contains("/") ? brain.state.substring(brain.state.indexOf('/') + 1) : ""));
            if (body.y > apex) apex = body.y;
            if (body.onGround) apex = body.y;
            if (lavaDown) res.minDistToLava = Math.min(res.minDistToLava, Math.hypot(body.x - (res.lavaX + 0.5), body.z - (res.lavaZ + 0.5)));
            for (Object[] pk : out) {
                int id = (Integer) pk[0];
                Wire.In in = new Wire.In((byte[]) pk[1]);
                if (id == Ids.SB_SET_CARRIED) sel = in.i16();
                else if (id == Ids.SB_USE_ITEM_ON) {
                    in.varInt(); long pos = in.i64();
                    int x = (int) px(pos), y = (int) py(pos), z = (int) pz(pos);
                    if (sel == Brain.S_THIRD) {
                        res.webs++; webAt = tick; webCx = x; webCz = z; res.webX = x; res.webZ = z; res.webTicks.add(tick);
                        if (chunks) w.chunks.setState(x, y + 1, z, ChunkTest.WEB);
                        if (res.firstWebTick < 0) res.firstWebTick = tick;
                        res.log.add(tick + ": web on floor block (" + x + "," + y + "," + z + ") -> cell (" + x + "," + (y + 1) + "," + z + ")  enemy at " + String.format("%.1f,%.1f", enemy.x, enemy.z));
                    } else if (sel == Brain.S_FIFTH) {
                        res.fire++;
                        res.log.add(tick + ": fire on cell (" + x + "," + (y + 1) + "," + z + ")");
                    }
                } else if (id == Ids.SB_USE_ITEM) {
                    in.varInt(); in.varInt();
                    float yaw = in.f32(), pitch = in.f32();
                    if (mode == Mode.MACE_PRO || mode == Mode.MACE) {
                        if (sel == Brain.S_SECOND && pitch > 80) { res.wind++; body.serverMotion(0, 1.15, 0); res.log.add(tick + ": wind charge, bot y=" + String.format("%.2f", body.y)); }
                    } else if (sel == Brain.S_FOURTH || sel == Brain.S_SIXTH) {
                        // ray from the eye to the floor plane (y = 64): the cell the bucket would use
                        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
                        double dy = -Math.sin(pr), dh = Math.cos(pr);
                        double ex = body.x, ey = body.y + 1.62, ez = body.z;
                        double tt = dy < -1e-6 ? (ey - 64.0) / -dy : -1;
                        int hx = Integer.MIN_VALUE, hz = 0;
                        if (tt > 0 && tt <= 4.5) { hx = (int) Math.floor(ex + -Math.sin(yr) * dh * tt); hz = (int) Math.floor(ez + Math.cos(yr) * dh * tt); }
                        if (sel == Brain.S_FOURTH && !lavaDown && hx != Integer.MIN_VALUE) {
                            lavaDown = true; res.lava++; res.lavaX = hx; res.lavaZ = hz;
                            if (res.firstLavaTick < 0) res.firstLavaTick = tick;
                            res.lavaBotDist = Math.hypot(hx + 0.5 - body.x, hz + 0.5 - body.z);
                            res.log.add(tick + ": lava on cell (" + hx + "," + hz + "), bot " + String.format("%.1f", res.lavaBotDist) + " blocks away, enemy at " + String.format("%.1f,%.1f", enemy.x, enemy.z));
                        } else if (sel == Brain.S_FOURTH && lavaDown) {
                            // the bucket is empty: a use aimed at the lava cell scoops it
                            double d = Math.hypot(body.x - (res.lavaX + 0.5), body.z - (res.lavaZ + 0.5));
                            res.scoops++; lavaDown = false;
                            res.log.add(tick + ": lava bucket used again (scoop), bot " + String.format("%.1f", d) + " from the lava cell, pitch " + String.format("%.0f", pitch));
                        } else if (sel == Brain.S_SIXTH) {
                            if (pitch > 80) { res.pours++; res.log.add(tick + ": bucket 7 poured at own feet"); }
                            else { res.steals++; if (res.steals <= 2) res.log.add(tick + ": empty bucket aimed at the enemy's feet (water steal probe), pitch " + String.format("%.0f", pitch)); }
                        }
                    }
                } else if (id == Ids.SB_INTERACT) {
                    int target = in.varInt();
                    int type = in.varInt();
                    if (type == 1 && target == 1000) {
                        res.attacks++;
                        double fall = apex - body.y;
                        if (mode == Mode.MACE_PRO || mode == Mode.MACE) {
                            if (fall >= 1.5) { res.smashes++; res.maxFall = Math.max(res.maxFall, fall); res.log.add(tick + ": SMASH after a fall of " + String.format("%.1f", fall) + " blocks, enemy at " + String.format("%.1f,%.1f", enemy.x, enemy.z) + " bot at " + String.format("%.1f,%.1f", body.x, body.z)); }
                            else res.log.add(tick + ": plain mace hit");
                            apex = body.y;
                            if (mode == Mode.MACE_PRO && k.slots.get("hotbar.0").item().contains("wind_burst")) body.serverMotion(0, 0.9, 0);   // wind burst
                        }
                    }
                }
            }
        }
        return res;
    }

    public static void main(String[] a) {
        Opts.traps = true; Opts.trapWeb = true; Opts.trapLava = true; Opts.trapFire = true; Opts.waterSteal = true;

        System.out.println("=== modes ===");
        check("parse trapper / mace_pro / MCTiers aliases", Mode.parse("trapper") == Mode.TRAPPER && Mode.parse("mace-pro") == Mode.MACE_PRO
                && Mode.parse("nethop") == Mode.NETHPOT && Mode.parse("vanilla") == Mode.CRYSTAL && Mode.parse("web") == Mode.TRAPPER && Mode.parse("zzz") == Mode.SWORD);
        Kit u = kit(Mode.UHC);
        Layout lu = Layout.detect(Mode.UHC, u.hotbarItems());
        check("UHC layout: bow 1, apples 2, web 3, lava 4, flint 5, bucket 6",
                lu.map(Brain.S_SECOND) == 1 && lu.map(Brain.S_HEAL) == 2 && lu.map(Brain.S_THIRD) == 3 && lu.map(Brain.S_FOURTH) == 4 && lu.map(Brain.S_FIFTH) == 5 && lu.map(Brain.S_SIXTH) == 6);
        check("kit guess: web+lava+bow = UHC, web+lava no bow = TRAPPER, mace+wind_burst = MACE_PRO",
                u.guessMode() == Mode.UHC && kit(Mode.TRAPPER).guessMode() == Mode.TRAPPER && kit(Mode.MACE_PRO).guessMode() == Mode.MACE_PRO);
        Kit m1 = kit(Mode.MACE); m1.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:mace"));
        check("plain mace kit stays MACE", m1.guessMode() == Mode.MACE);
        check("auto-kit commands for the new modes", "kit trapper".equals(Kits.forMode(Mode.TRAPPER)) && "kit mace_pro".equals(Kits.forMode(Mode.MACE_PRO)));

        System.out.println("=== TRAPPER vs an enemy that stands still (web holds it) ===");
        R r = run(Mode.TRAPPER, Tier.HT2, 8, 400, (e, t, wb) -> { }, true);
        r.log.stream().limit(14).forEach(s -> System.out.println("   " + s));
        System.out.println("   states: " + r.states);
        check("webs the enemy early", r.webs >= 1 && r.firstWebTick > 0 && r.firstWebTick < 80);
        check("web lands on the enemy's own cell (0,0)", r.webX == 0 && r.webZ == 0);
        check("lava goes beside the web, not into it", r.lava == 1 && !(r.lavaX == r.webX && r.lavaZ == r.webZ) && Math.abs(r.lavaX - r.webX) + Math.abs(r.lavaZ - r.webZ) == 1);
        check("lava thrown from a safe distance (>= 3.0 blocks)", r.lavaBotDist >= 3.0 && r.lavaBotDist <= 4.2);
        check("the bot never stands within 2.5 blocks of its own lava afterwards", r.minDistToLava >= 2.5);
        check("fire placed around the enemy", r.fire >= 1);
        check("the lava is picked up again", r.scoops >= 1);
        check("never uses more cobwebs than the kit holds (6)", r.webs <= 6);

        System.out.println("=== UHC vs an enemy that runs away along z ===");
        R f = run(Mode.UHC, Tier.HT2, 6, 500, (e, t, wb) -> { if (t > 20 && t < 140) e.moveTo(e.x, e.y, e.z + 0.22, t); }, false);
        f.log.stream().limit(12).forEach(s -> System.out.println("   " + s));
        System.out.println("   states: " + f.states);
        check("webs the cell ahead of the runner (z > 0)", f.webs >= 1 && f.webZ >= 1);
        check("probes the runner's feet with the empty bucket (water steal)", f.steals >= 1);
        Opts.waterSteal = false;
        R nf = run(Mode.UHC, Tier.HT2, 6, 500, (e, t, wb) -> { if (t > 20 && t < 140) e.moveTo(e.x, e.y, e.z + 0.22, t); }, false);
        check("water steal switched off: no probes", nf.steals == 0);
        Opts.waterSteal = true;
        Opts.traps = false;
        R off = run(Mode.TRAPPER, Tier.HT2, 8, 300, (e, t, wb) -> { }, true);
        check("traps switched off: no web, lava or fire", off.webs == 0 && off.lava == 0 && off.fire == 0);
        Opts.traps = true;
        Opts.trapLava = false;
        R nl = run(Mode.TRAPPER, Tier.HT2, 8, 300, (e, t, wb) -> { }, true);
        check("lava switched off: webs and fire only", nl.lava == 0 && nl.webs >= 1);
        Opts.trapLava = true;

        System.out.println("=== with chunk data (web is a block, not a guess) ===");
        chunks = true;
        R cw = run(Mode.TRAPPER, Tier.HT2, 8, 400, (e, t, wb) -> { }, true);
        check("same plan with chunks: web on the enemy, lava beside it, lava picked up", cw.webs >= 1 && cw.webX == 0 && cw.webZ == 0 && cw.lava == 1
                && Math.abs(cw.lavaX - cw.webX) + Math.abs(cw.lavaZ - cw.webZ) == 1 && cw.scoops >= 1);
        chunks = false; breakWebAfter = 7;
        R gb = run(Mode.TRAPPER, Tier.HT2, 8, 400, (e, t, wb) -> { }, true);
        chunks = true;
        R cb = run(Mode.TRAPPER, Tier.HT2, 8, 400, (e, t, wb) -> { }, true);
        System.out.println("   web broken 7 ticks after placing, enemy stands still:");
        System.out.println("     no chunks: webs at " + gb.webTicks + ", first lava tick " + (int) gb.firstLavaTick);
        System.out.println("     chunks:    webs at " + cb.webTicks + ", first lava tick " + (int) cb.firstLavaTick);
        boolean guessedWrong = gb.firstLavaTick > 0 && (gb.webTicks.size() < 2 || gb.firstLavaTick < gb.webTicks.get(1));
        boolean knowsBetter = cb.firstLavaTick < 0 || (cb.webTicks.size() >= 2 && cb.firstLavaTick > cb.webTicks.get(1));
        check("without chunks the bot still believes the broken web holds (lava goes down before a new web)", guessedWrong);
        check("with chunks it sees the web is gone: no lava while there is no web", knowsBetter);
        chunks = false; breakWebAfter = -1;

        System.out.println("=== MACE_PRO vs an enemy that stands still (wind burst mace) ===");
        R m = run(Mode.MACE_PRO, Tier.HT2, 12, 500, (e, t, wb) -> { }, false);
        m.log.stream().limit(14).forEach(s -> System.out.println("   " + s));
        System.out.println("   states: " + m.states);
        check("launches with a wind charge", m.wind >= 1);
        check("smashes from a real fall (>= 2.5 blocks)", m.smashes >= 1 && m.maxFall >= 2.5);
        System.out.println("   smashes=" + m.smashes + " wind charges=" + m.wind + " biggest fall=" + String.format("%.1f", m.maxFall));

        System.out.println("=== MACE_PRO vs an enemy walking along z ===");
        R mw = run(Mode.MACE_PRO, Tier.HT2, 12, 600, (e, t, wb) -> { double z = e.z; double d = ((t / 60) % 2 == 0) ? 0.12 : -0.12; e.moveTo(e.x, e.y, z + d, t); }, false);
        mw.log.stream().limit(8).forEach(s -> System.out.println("   " + s));
        check("hits a walking enemy from above too", mw.smashes >= 1);
        Opts.maceMinFall = 12;
        R mh = run(Mode.MACE_PRO, Tier.HT2, 12, 400, (e, t, wb) -> { }, false);
        check("minimum fall setting is respected (12 blocks: no smash from a ~8 block launch)", mh.smashes == 0);
        Opts.maceMinFall = 2.5;

        System.out.println("=== smoke: every mode still runs ===");
        for (Mode md : Mode.values()) {
            if (md == Mode.MIXED || md == Mode.NPC) continue;
            try { run(md, Tier.HT0, 10, 200, (e, t, wb) -> { }, false); }
            catch (Throwable ex) { check("smoke " + md + " threw " + ex, false); }
        }
        check("smoke ok", true);

        System.out.println(fail == 0 ? "ALL TRAP/MACE CHECKS PASSED" : fail + " CHECK(S) FAILED");
        if (fail > 0) System.exit(1);
    }
}
