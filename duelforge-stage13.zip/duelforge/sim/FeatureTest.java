import dev.duelforge.ai.*;
import dev.duelforge.net.BotManager;
import java.util.*;

/** v1.5 checks that need no Minecraft: combos, new modes, NPC gear, duel scoring. */
public class FeatureTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    public static void main(String[] a) throws Exception {
        // ---- modes / kit detection
        check("new modes parse", Mode.parse("axe_sword") == Mode.AXE_SWORD && Mode.parse("pressure") == Mode.PRESSURE && Mode.parse("npc") == Mode.NPC);
        Kit k = new Kit("x");
        k.slots.put("hotbar.0", Kit.fromSnbt("{count:1,id:\"minecraft:netherite_sword\"}"));
        k.slots.put("hotbar.1", Kit.fromSnbt("{count:1,id:\"minecraft:netherite_axe\"}"));
        k.slots.put("hotbar.2", Kit.fromSnbt("{count:8,id:\"minecraft:golden_apple\"}"));
        check("sword+axe kit -> AXE_SWORD", k.guessMode() == Mode.AXE_SWORD);
        Layout l = Layout.detect(Mode.AXE_SWORD, k.hotbarItems());
        check("AXE_SWORD layout: sword 0, axe 1, apples 2", l.map(0) == 0 && l.map(1) == 1 && l.map(2) == 2);
        k.slots.put("hotbar.1", Kit.fromSnbt("{count:1,id:\"minecraft:diamond_pickaxe\"}"));
        check("sword+pickaxe is still a plain sword kit", k.guessMode() == Mode.SWORD);
        check("NPC and MIXED have no auto-kit command", Kits.forMode(Mode.NPC) == null && Kits.forMode(Mode.MIXED) == null && Kits.forMode(Mode.PRESSURE) != null);

        // ---- NPC gear
        Opts.npcTotems = 99; Opts.npcArmor = false;
        List<String> g = BotManager.npcGear("Dummy1");
        System.out.println("   " + g.get(0));
        check("NPC: 99 totems main hand + offhand, stack size raised",
                g.size() == 2 && g.get(0).contains("weapon.mainhand") && g.get(1).contains("weapon.offhand")
                        && g.stream().allMatch(c -> c.contains("max_stack_size=99") && c.endsWith(" 99") && c.contains("totem_of_undying")));
        Opts.npcTotems = 500; Opts.npcArmor = true;
        g = BotManager.npcGear("@s");
        check("NPC: count clamped to 99, armor adds 4 pieces", g.size() == 6 && g.get(0).endsWith(" 99") && g.stream().filter(c -> c.contains("netherite_")).count() == 4);
        Opts.npcTotems = 99; Opts.npcArmor = false;

        // ---- combos
        Random r = new Random(7);
        Opts.combo = true; Opts.comboChain = true; Opts.comboMask = 0xFFFF; Opts.comboRate = 1.0;
        Set<Combo.Kind> seen = EnumSet.noneOf(Combo.Kind.class);
        Combo c = new Combo();
        for (int i = 0; i < 400; i++) { seen.add(c.onHit(r, Tier.HT0, r.nextBoolean() ? 2.5 : 1.2, 1)); runOut(c); }
        check("MAX uses every combo kind", seen.containsAll(EnumSet.range(Combo.Kind.W_TAP, Combo.Kind.ORBIT)));
        seen.clear();
        for (int i = 0; i < 600; i++) { seen.add(c.onHit(r, Tier.HT4, 2.5, 1)); runOut(c); }
        check("HT4 never uses the advanced combos", !seen.contains(Combo.Kind.JUMP_CRIT) && !seen.contains(Combo.Kind.BAIT) && !seen.contains(Combo.Kind.DOUBLE_TAP) && !seen.contains(Combo.Kind.ORBIT));
        seen.clear();
        for (int i = 0; i < 800; i++) { seen.add(c.onHit(r, Tier.HT2, 2.5, 1)); runOut(c); }
        check("HT2 uses jump-crit, double tap and bait", seen.contains(Combo.Kind.JUMP_CRIT) && seen.contains(Combo.Kind.DOUBLE_TAP) && seen.contains(Combo.Kind.BAIT));
        Opts.comboSet(Combo.Kind.BAIT, false); Opts.comboSet(Combo.Kind.ORBIT, false);
        seen.clear();
        int chained = 0;
        for (int i = 0; i < 800; i++) { seen.add(c.onHit(r, Tier.HT0, 2.5, 1)); chained += runOut(c); }
        check("disabled combos are never picked, even by MAX", !seen.contains(Combo.Kind.BAIT) && !seen.contains(Combo.Kind.ORBIT));
        check("chains happen (two combos in a row)", chained > 100);
        Opts.comboChain = false;
        chained = 0;
        for (int i = 0; i < 300; i++) { c.onHit(r, Tier.HT0, 2.5, 1); chained += runOut(c); }
        check("no chains when switched off", chained == 0);
        Opts.comboChain = true; Opts.comboMask = 0xFFFF;
        Opts.combo = false;
        seen.clear();
        for (int i = 0; i < 200; i++) { seen.add(c.onHit(r, Tier.HT2, 2.5, 1)); runOut(c); }
        check("combo off: only the old random w-tap", seen.stream().allMatch(x -> x == Combo.Kind.W_TAP || x == Combo.Kind.NONE));
        Opts.combo = true;

        // combo inputs: every kind drives the body without a stall
        Body body = new Body((id, cb) -> { }, new Random(1));
        body.serverPosition(0, 64, 0, 0, 0, 0, 0, 0);
        for (Combo.Kind kind : Combo.Kind.values()) {
            if (kind == Combo.Kind.NONE) continue;
            Combo cc = new Combo(); cc.start(kind, 9, 1);
            int ticks = 0; boolean moved = false;
            while (cc.active() && ticks < 30) { body.fwd = 0; body.strafe = 0; body.jump = false; cc.apply(body); moved |= body.fwd != 0 || body.strafe != 0 || body.jump || kind == Combo.Kind.W_TAP; ticks++; }
            check(kind + " runs for its duration (" + ticks + " ticks) and ends", ticks == 9 && !cc.active() && moved);
        }
        Combo bait = new Combo(); bait.start(Combo.Kind.BAIT, 7, 1);
        bait.apply(body);
        boolean backFirst = body.fwd < 0;
        for (int i = 0; i < 4; i++) bait.apply(body);
        check("BAIT steps back first, then charges forward with sprint", backFirst && body.fwd > 0 && body.wantSprint);
        Combo jc = new Combo(); jc.start(Combo.Kind.JUMP_CRIT, 9, 1);
        body.onGround = true; body.jump = false; jc.apply(body);
        check("JUMP_CRIT jumps on its first tick and asks for a falling hit", body.jump && jc.critNext());

        // ---- duel scoring
        DuelManager d = DuelManager.INSTANCE;
        List<String> said = new ArrayList<>();
        d.announce = said::add;
        d.roundCommands.clear();
        d.start("Alpha", true, "Beta", true, 3);
        d.onDeath("Beta");
        check("a death scores for the other side", d.scoreA() == 1 && d.scoreB() == 0);
        d.onDeath("Beta");
        check("a repeated death inside the window is ignored", d.scoreA() == 1);
        Thread.sleep(DuelManagerWindow() + 50);
        d.onDeath("Alpha");
        check("both sides can score", d.scoreA() == 1 && d.scoreB() == 1);
        Thread.sleep(DuelManagerWindow() + 50);
        d.onDeath("beta");
        Thread.sleep(DuelManagerWindow() + 50);
        d.onDeath("BETA");
        check("names are case-insensitive, first to 3 wins and the match ends", d.scoreA() == 3 && !d.active && d.winner.equals("Alpha"));
        d.onDeath("Alpha");
        check("no points after the end", d.scoreB() == 1 && d.history().size() == 1);
        check("announcements were made", said.stream().anyMatch(s -> s.contains("Победил Alpha")));
        d.rematch();
        check("rematch zeroes the score with the same sides", d.active && d.scoreA() == 0 && d.scoreB() == 0 && d.nameA().equals("Alpha"));

        d.start("Bot1", true, "Steve", false, 5);
        check("only the human side is watched for the death heuristic", d.watchesPlayer("steve") && !d.watchesPlayer("Bot1"));
        d.onPlayerLost("Bot1", "Bot1");
        check("a bot is never scored through the player heuristic", d.scoreA() == 0 && d.scoreB() == 0);
        d.onPlayerLost("Steve", "Bot1");
        check("player lost -> the bot scores", d.scoreA() == 1);
        d.point("Steve");
        check("manual point", d.scoreB() == 1);
        List<List<String>> sent = new ArrayList<>();
        d.sender = sent::add; d.roundDelayMs = 20;
        d.roundCommands.add("tp {A} 0 64 5"); d.roundCommands.add("tp {B} 0 64 -5");
        Thread.sleep(DuelManagerWindow() + 50);
        d.onDeath("Bot1");
        Thread.sleep(200);
        check("round commands expand {A}/{B} after a point", sent.size() == 1 && sent.get(0).get(0).equals("tp Bot1 0 64 5") && sent.get(0).get(1).equals("tp Steve 0 64 -5"));
        d.stop();
        check("stop ends the match", !d.active);
        d.reset();
        check("reset clears everything", !d.has() && d.log().isEmpty());

        System.out.println(fail == 0 ? "ALL FEATURE CHECKS PASSED" : fail + " FAILED");
        if (fail > 0) System.exit(1);
    }

    static long DuelManagerWindow() { return 1500; }

    /** Run a combo to its end; returns 1 if a second combo (chain) started after the first. */
    static int runOut(Combo c) {
        Body b = new Body((id, cb) -> { }, new Random(1));
        b.serverPosition(0, 64, 0, 0, 0, 0, 0, 0);
        Combo.Kind first = c.kind();
        int chained = 0, guard = 0;
        while (c.active() && guard++ < 40) {
            Combo.Kind before = c.kind();
            c.apply(b);
            if (c.active() && c.kind() != before) chained = 1;
        }
        return first != Combo.Kind.NONE ? chained : 0;
    }
}
