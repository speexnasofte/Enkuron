import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/** SMP / Diamond SMP with potions: healing pots at the feet when low, speed + strength at the start, apples as fallback. */
public class SmpTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    static Kit kit(boolean pots, String armor) {
        Kit k = new Kit("s");
        k.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_sword"));
        if (pots) {
            k.slots.put("hotbar.1", new Kit.Entry(6, "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_healing\"}]"));
            k.slots.put("hotbar.3", new Kit.Entry(1, "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_swiftness\"}]"));
            k.slots.put("hotbar.4", new Kit.Entry(1, "minecraft:splash_potion[potion_contents={potion:\"minecraft:strong_strength\"}]"));
        }
        k.slots.put("hotbar.2", new Kit.Entry(8, "minecraft:golden_apple"));
        k.slots.put("armor.chest", new Kit.Entry(1, "minecraft:" + armor + "_chestplate"));
        return k;
    }

    static int[] run(Mode mode, Kit k, int lowFrom) {
        Random rnd = new Random(5);
        World w = new World();
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("e".getBytes());
        w.setName(eu, "Enemy");
        w.add(1000, eu, 128, 0, 64, 0, 0);
        body.entityId = 1; body.serverPosition(10, 64, 0, 0, 0, 0, 90, 0);
        Brain br = new Brain(body, w, rnd, Tier.HT2, mode, "A", Set.of(), "Bot1");
        br.setLayout(Layout.detect(mode, k.hotbarItems())); br.setKit(k);
        int sel = 0, heal = 0, speed = 0, str = 0, apples = 0;
        for (int t = 1; t <= 400; t++) {
            w.now = t;
            if (t == lowFrom) body.health = 7f;
            if (t == lowFrom + 120) body.health = 20f;
            out.clear(); br.tick(); body.step(); body.flush();
            for (Object[] p : out) {
                int id = (Integer) p[0]; Wire.In in = new Wire.In((byte[]) p[1]);
                if (id == Ids.SB_SET_CARRIED) sel = in.i16();
                else if (id == Ids.SB_USE_ITEM) {
                    in.varInt(); in.varInt(); in.f32(); float pitch = in.f32();
                    if (sel == 1 && pitch > 80) heal++;
                    else if (sel == 3 && pitch > 80) speed++;
                    else if (sel == 4 && pitch > 80) str++;
                    else if (sel == 2) apples++;
                }
            }
        }
        return new int[]{heal, speed, str, apples};
    }

    public static void main(String[] a) {
        check("parse diamond_smp / dsmp", Mode.parse("diamond_smp") == Mode.DIAMOND_SMP && Mode.parse("DSMP") == Mode.DIAMOND_SMP && Mode.parse("smp") == Mode.SMP);
        check("sword+pots+gapples = SMP, diamond chest = DIAMOND_SMP, no gapples = POT",
                kit(true, "netherite").guessMode() == Mode.SMP && kit(true, "diamond").guessMode() == Mode.DIAMOND_SMP);
        Kit potOnly = kit(true, "diamond"); potOnly.slots.remove("hotbar.2");
        check("pot kit without apples is not SMP", potOnly.guessMode() == Mode.NETHPOT);
        Layout l = Layout.detect(Mode.SMP, kit(true, "netherite").hotbarItems());
        check("SMP layout: healing slot 2, apples 3, speed 4, strength 5", l.map(1) == 1 && l.map(2) == 2 && l.map(4) == 3 && l.map(5) == 4);
        check("auto-kit command", "kit diamond_smp".equals(Kits.forMode(Mode.DIAMOND_SMP)));
        for (Mode m : new Mode[]{Mode.SMP, Mode.DIAMOND_SMP}) {
            int[] r = run(m, kit(true, m == Mode.SMP ? "netherite" : "diamond"), 150);
            System.out.println("   " + m + ": healing pots=" + r[0] + " speed=" + r[1] + " strength=" + r[2] + " apples=" + r[3]);
            check(m + ": throws healing pots when low", r[0] >= 2 && r[0] <= 6);
            check(m + ": opens with speed and strength", r[1] >= 1 && r[2] >= 1);
        }
        int[] np = run(Mode.SMP, kit(false, "netherite"), 150);
        System.out.println("   SMP without pots: " + Arrays.toString(np));
        check("SMP kit without pots: no pot throws, apples as before", np[0] == 0 && np[1] == 0 && np[2] == 0 && np[3] >= 1);
        Opts.totemRefill = true;
        System.out.println(fail == 0 ? "ALL SMP CHECKS PASSED" : fail + " CHECK(S) FAILED");
        if (fail > 0) System.exit(1);
    }
}
