import dev.duelforge.client.expa.ExpaGui;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import top.fpsmaster.prism.canvas.Canvas;
import top.fpsmaster.prism.canvas.FontHandle;
import top.fpsmaster.prism.canvas.ImageHandle;
import top.fpsmaster.prism.host.UiHost;
import top.fpsmaster.prism.input.FrameInput;
import top.fpsmaster.prism.input.Input;
import top.fpsmaster.prism.screen.ClickGuiBridge;
import top.fpsmaster.prism.theme.Theme;
import top.fpsmaster.prism.widget.UiFrame;

/**
 * Headless preview of the Expensive-style menu (no Minecraft needed).
 * Run: javac -d out $(find src/main/java/top -name '*.java') src/main/java/dev/duelforge/client/expa/*.java sim/ExpaPreview.java
 *      java -cp out ExpaPreview [outDir] [gui scale, default 2]
 * Writes PNG frames: closed-in-the-middle of the open animation, idle, choice open, colour picker, search, light.
 */
public class ExpaPreview {
    static int SCALE = 2;
    static final int GW = 960 / 2, GH = 540 / 2; // 1080p at GUI scale 4 would be 480x270; this is 960x540 at scale 2

    // ------------------------------------------------------------ Java2D canvas
    static final class J2dCanvas implements Canvas {
        final Graphics2D g;
        final ArrayDeque<Float> alpha = new ArrayDeque<>();
        final ArrayDeque<AffineTransform> xf = new ArrayDeque<>();
        final ArrayDeque<Shape> clips = new ArrayDeque<>();

        J2dCanvas(Graphics2D g) {
            this.g = g;
            alpha.push(1f);
        }

        Color c(int argb) {
            int a = Math.round(((argb >>> 24) & 255) * alpha.peek());
            return new Color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, Math.max(0, Math.min(255, a)));
        }

        public void fillRect(float x, float y, float w, float h, int argb) { g.setColor(c(argb)); g.fill(new Rectangle2D.Float(x, y, w, h)); }
        public void fillRoundRect(float x, float y, float w, float h, float r, int argb) { g.setColor(c(argb)); g.fill(new RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2)); }
        public void strokeRoundRect(float x, float y, float w, float h, float r, float sw, int argb) {
            g.setColor(c(argb)); g.setStroke(new BasicStroke(sw));
            g.draw(new RoundRectangle2D.Float(x + sw / 2, y + sw / 2, w - sw, h - sw, r * 2, r * 2));
        }
        public void fillCircle(float cx, float cy, float r, int argb) { g.setColor(c(argb)); g.fill(new Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2)); }
        public void line(float x1, float y1, float x2, float y2, float w, int argb) {
            g.setColor(c(argb)); g.setStroke(new BasicStroke(w, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)); g.draw(new Line2D.Float(x1, y1, x2, y2));
        }
        public void fillGradientH(float x, float y, float w, float h, int l, int r) {
            g.setPaint(new GradientPaint(x, 0, c(l), x + w, 0, c(r))); g.fill(new Rectangle2D.Float(x, y, w, h));
        }
        public void fillGradientV(float x, float y, float w, float h, int t, int b) {
            g.setPaint(new GradientPaint(0, y, c(t), 0, y + h, c(b))); g.fill(new Rectangle2D.Float(x, y, w, h));
        }
        public void drawString(FontHandle font, String text, float x, float y, int argb) {
            J2dFont f = (J2dFont) font;
            g.setFont(f.font); g.setColor(c(argb));
            g.drawString(text, x, y + f.ascent);
        }
        public void drawImage(ImageHandle image, float x, float y, float w, float h, int tint) { }
        public void pushClip(float x, float y, float w, float h) {
            clips.push(g.getClip() == null ? new Rectangle2D.Float(-1e5f, -1e5f, 2e5f, 2e5f) : g.getClip());
            g.clip(new Rectangle2D.Float(x, y, w, h));
        }
        public void popClip() { g.setClip(clips.pop()); }
        public void pushAlpha(float a) { alpha.push(alpha.peek() * a); }
        public void popAlpha() { alpha.pop(); }
        public void pushTransform() { xf.push(g.getTransform()); }
        public void popTransform() { g.setTransform(xf.pop()); }
        public void translate(float x, float y) { g.translate(x, y); }
        public void scale(float s) { g.scale(s, s); }
    }

    static final FontRenderContext FRC = new FontRenderContext(null, true, true);

    static final class J2dFont implements FontHandle {
        final int px; final Font font; final float ascent;
        J2dFont(int px) {
            this.px = px;
            font = new Font("DejaVu Sans", Font.PLAIN, 1).deriveFont(px * 0.5f * 0.92f);
            ascent = font.getLineMetrics("Ay", FRC).getAscent() + (px * 0.5f - font.getLineMetrics("Ay", FRC).getHeight()) / 2f;
        }
        public int size() { return px; }
        public float measure(String t) { return (float) font.getStringBounds(t, FRC).getWidth(); }
        public float lineHeight() { return px * 0.5f; }
    }

    static final class J2dHost implements UiHost {
        final J2dCanvas canvas; final FrameInput input; long now = 1_000_000_000L;
        final Map<Integer, J2dFont> fonts = new HashMap<>();
        J2dHost(J2dCanvas c, FrameInput i) { canvas = c; input = i; }
        public Canvas canvas() { return canvas; }
        public Input input() { return input; }
        public FontHandle font(int s) { return fonts.computeIfAbsent(s, J2dFont::new); }
        public float width() { return GW; }
        public float height() { return GH; }
        public long nowNanos() { return now; }
        public boolean blurEnabled() { return false; }
        public void blurBehind(float x, float y, float w, float h, float r) { }
        public ImageHandle image(String id) { return null; }
    }

    // ------------------------------------------------------------ fake bridge with every setting kind
    static final class Fake implements ClickGuiBridge {
        boolean light;
        final Map<String, Boolean> on = new HashMap<>();
        final Map<String, Double> num = new HashMap<>();
        final Map<String, Boolean> flag = new HashMap<>();
        final Map<String, Integer> choice = new HashMap<>();
        final Map<String, String> text = new HashMap<>();
        float hue = 0.62f, sat = 0.7f, bri = 0.9f;
        final List<String> log = new ArrayList<>();

        public String i18n(String k) { return k.equals("clickgui.search.placeholder") ? "Поиск…" : k.equals("clickgui.search.noresults") ? "Ничего не найдено" : k; }
        public String edition() { return "PvP"; }
        public String brand() { return "Duelforge"; }
        public String version() { return "2.0.1"; }
        public boolean showExtraNav() { return false; }
        public List<String> categories() { return List.of("launch", "bots", "kits", "modes", "controller", "sbattle", "sutil"); }
        public String categoryLabel(String id) {
            return switch (id) { case "launch" -> "Запуск"; case "bots" -> "Боты и дуэли"; case "kits" -> "Киты"; case "modes" -> "Режимы и опции"; case "controller" -> "Контроллер"; case "sbattle" -> "PvP бот: бой"; default -> "PvP бот: утилиты"; };
        }
        public String categoryIcon(String id) { return switch (id) { case "launch" -> "globe"; case "bots" -> "box"; case "kits" -> "folder"; default -> "sliders"; }; }
        public int moduleCount(String c) { return modules(c, "").size(); }
        public int enabledCount(String c) { return 0; }
        public List<ModInfo> modules(String cat, String q) {
            List<ModInfo> all = new ArrayList<>();
            List<SettingInfo> s1 = new ArrayList<>();
            s1.add(new SettingInfo("ip", "IP сервера", text.getOrDefault("ip", "play.example.net")));
            s1.add(new SettingInfo("nicks", "Ники ботов", text.getOrDefault("nicks", "Bot*10")));
            s1.add(new SettingInfo("tier", "Тир", List.of("LT5", "LT4", "LT3", "LT2", "LT1", "HT5", "HT4", "HT3", "HT2", "HT1", "MAX"), choice.getOrDefault("tier", 7)));
            s1.add(new SettingInfo("mode", "Режим", List.of("SWORD", "CRYSTAL", "ANCHOR", "POT", "UHC", "MACE", "SMP"), choice.getOrDefault("mode", 0)));
            s1.add(new SettingInfo("go", "Создать ботов", flag.getOrDefault("go", false)));
            all.add(new ModInfo("launch", "Запуск ботов", on.getOrDefault("launch", false), true, s1));
            List<SettingInfo> s2 = new ArrayList<>();
            s2.add(new SettingInfo("speed", "Скорость", num.getOrDefault("speed", 3.0), 1, 5));
            s2.add(new SettingInfo("reach", "Дальность", num.getOrDefault("reach", 2.98), 2.0, 6.0));
            s2.add(new SettingInfo("auto", "Авто-киты", flag.getOrDefault("auto", true)));
            s2.add(new SettingInfo("tr", "Ловушки", flag.getOrDefault("tr", false)));
            s2.add(new SettingInfo("col", "Цвет HUD", hue, sat, bri, 1f, "Static", List.of("Static", "Rainbow", "Fade")));
            s2.add(new SettingInfo("key", "Клавиша", 0, "RSHIFT"));
            all.add(new ModInfo("opts", "Опции", on.getOrDefault("opts", true), true, s2));
            List<SettingInfo> s3 = new ArrayList<>();
            s3.add(new SettingInfo("l", "Список ботов", List.of(new ListItem("Bot1 · HT3 · 20 HP"), new ListItem("Bot2 · LT4 · 18 HP")), 2, false));
            all.add(new ModInfo("bots", "Боты", false, false, s3));
            all.add(new ModInfo("kits", "Киты", false, false, List.of(new SettingInfo("kit", "Кит", List.of("kit1", "kit2"), 0), new SettingInfo("save", "Сохранить с меня", false))));
            all.add(new ModInfo("duel", "Дуэль", on.getOrDefault("duel", false), true, List.of(new SettingInfo("first", "До N побед", num.getOrDefault("first", 5.0), 1, 20), new SettingInfo("a", "Бот A", "DuelA"))));
            all.add(new ModInfo("npc", "NPC", false, true, List.of(new SettingInfo("tot", "Тотемов", num.getOrDefault("tot", 99.0), 1, 99))));
            List<ModInfo> out = new ArrayList<>();
            String ql = q == null ? "" : q.trim().toLowerCase();
            for (ModInfo m : all) { if (ql.isEmpty() || m.name.toLowerCase().contains(ql)) out.add(m); }
            if (ql.isEmpty() && !cat.equals("launch")) { // other categories: reuse a slice so the grid is not empty
                return cat.equals("bots") ? out.subList(2, 6) : out.subList(1, 3);
            }
            return out;
        }
        public void toggle(String id) { on.put(id, !on.getOrDefault(id, false)); log.add("toggle " + id); }
        public void setNumber(String m, String s, double v) { num.put(s, v); }
        public void setBool(String m, String s, boolean v) { flag.put(s, v); log.add("bool " + s + "=" + v); }
        public void setChoice(String m, String s, int i) { choice.put(s, i); log.add("choice " + s + "=" + i); }
        public void setText(String m, String s, String v) { text.put(s, v); log.add("text " + s + "=" + v); }
        public void setColor(String m, String s, float h, float sa, float b, float a, String mode) { hue = h; sat = sa; bri = b; }
        public boolean lightTheme() { return light; }
        public void toggleTheme() { light = !light; log.add("theme"); }
        public void openMusic() { }
        public void openProfiles() { }
    }

    // ------------------------------------------------------------ driver
    static BufferedImage img = new BufferedImage(GW * SCALE, GH * SCALE, BufferedImage.TYPE_INT_ARGB);
    static FrameInput input = new FrameInput();
    static J2dHost host;

    static void frame(ExpaGui gui, Fake bridge, int n) {
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setColor(new Color(58, 82, 52)); // fake game background
        g.fillRect(0, 0, img.getWidth(), img.getHeight());
        g.setColor(new Color(90, 120, 80));
        for (int i = 0; i < 40; i++) g.fillRect((i * 97) % img.getWidth(), (i * 53) % img.getHeight(), 60, 30);
        g.scale(SCALE, SCALE);
        J2dCanvas canvas = new J2dCanvas(g);
        host = new J2dHost(canvas, input);
        for (int i = 0; i < n; i++) {
            host.now += 16_000_000L;
            UiFrame ui = new UiFrame(host, Theme.of(bridge.light, false));
            gui.draw(ui, bridge);
            input.endFrame();
        }
        g.dispose();
    }

    static void save(String dir, String name) throws Exception {
        ImageIO.write(img, "png", new File(dir, name));
        System.out.println("wrote " + name);
    }

    static void click(ExpaGui gui, Fake b, int x, int y) {
        input.setMouse(x, y);
        frame(gui, b, 2);
        input.press(0, x, y);
        frame(gui, b, 2);
        input.release(0);
        frame(gui, b, 4);
    }

    public static void main(String[] a) throws Exception {
        String dir = a.length > 0 ? a[0] : "/tmp/expa";
        new File(dir).mkdirs();
        Fake b = new Fake();
        ExpaGui gui = new ExpaGui("launch");
        gui.onOpen();
        input.setMouse(10, 10);
        frame(gui, b, 8);
        save(dir, "1_opening.png");
        frame(gui, b, 60);
        save(dir, "2_idle.png");

        // window geometry (GUI units): centered 460x275
        float wx = (GW - 460f) / 2f, wy = (GH - 275f) / 2f;
        // toggle the first module via its header (top-left card)
        click(gui, b, (int) (wx + 12 + 40), (int) (wy + 30 + 24 + 4 + 12));
        frame(gui, b, 30);
        System.out.println("after header click: " + b.log);

        // open the "Тир" dropdown (coordinates in GUI units, read off the idle screenshot)
        click(gui, b, 145, 149);
        frame(gui, b, 30);
        save(dir, "3_choice_open.png");
        click(gui, b, 160, 168); // pick LT3 chip area (first row), closes the dropdown
        frame(gui, b, 30);
        System.out.println("after choice click: " + b.log);

        // colour picker of "Цвет HUD"
        click(gui, b, 250, 176);
        frame(gui, b, 30);
        save(dir, "3b_color_open.png");
        click(gui, b, 250, 176);

        // switch category
        click(gui, b, 108, 44);
        frame(gui, b, 40);
        save(dir, "4_category2.png");

        // search: click the field in the header, then type
        click(gui, b, 350, 18);
        input.type("кит");
        frame(gui, b, 4);
        save(dir, "5_search_typed.png");

        // light theme
        b.light = true;
        frame(gui, b, 4);
        save(dir, "6_light.png");
        System.out.println("log: " + b.log);
    }
}
