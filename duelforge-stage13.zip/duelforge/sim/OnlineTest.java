import dev.duelforge.ai.*;
import dev.duelforge.net.*;

import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.zip.*;
import javax.crypto.Cipher;
import javax.crypto.spec.*;

/**
 * End-to-end check of the bot against a fake 1.21.11 server (offline AND online mode, RSA + AES/CFB8, compression,
 * Mojang session join through a local mock). Packet ids come from Ids, so a wrong id table shows up as "bot never moved".
 */
public class OnlineTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    // ------------------------------------------------------------ fake server
    static final class Server implements Runnable {
        final boolean online;
        final ServerSocket ss;
        volatile String loginName; volatile UUID loginUuid;
        volatile boolean tokenOk, accepted, loaded, moved, attacked, swung, gotKeepAlive;
        volatile String hash;            // what a vanilla server would compute
        volatile String kickReason;
        final AtomicInteger movePackets = new AtomicInteger(), attackPackets = new AtomicInteger();
        InputStream in; OutputStream out; Cipher enc, dec; int threshold = -1;
        volatile boolean done;
        /** Send floor + a wall (chunk packets) and a batch-finished packet; record what the bot answers and how far east it walks. */
        volatile boolean terrain;
        volatile boolean batchAcked;
        volatile double maxX = -1e9;

        Server(boolean online) throws IOException { this.online = online; ss = new ServerSocket(0); }

        int port() { return ss.getLocalPort(); }

        int readVar() throws IOException {
            int v = 0, s = 0;
            while (true) {
                int b = rd();
                v |= (b & 0x7F) << s;
                if ((b & 0x80) == 0) return v;
                s += 7;
            }
        }

        int rd() throws IOException {
            int b = in.read();
            if (b < 0) throw new EOFException();
            if (dec != null) b = dec.update(new byte[]{(byte) b})[0] & 0xFF;
            return b;
        }

        byte[] frame() throws IOException {
            int len = readVar();
            byte[] d = new byte[len];
            for (int i = 0; i < len; i++) d[i] = (byte) rd();
            if (threshold < 0) return d;
            Wire.In h = new Wire.In(d);
            int ulen = h.varInt();
            int hdr = d.length - h.left();
            if (ulen == 0) return Arrays.copyOfRange(d, hdr, d.length);
            Inflater inf = new Inflater();
            inf.setInput(d, hdr, d.length - hdr);
            byte[] res = new byte[ulen];
            try { int n = 0; while (n < ulen) { int r = inf.inflate(res, n, ulen - n); if (r == 0) break; n += r; } } catch (DataFormatException e) { throw new IOException(e); }
            return res;
        }

        void send(int id, java.util.function.Consumer<Wire.Out> c) throws IOException {
            Wire.Out o = new Wire.Out(); o.varInt(id); c.accept(o);
            byte[] payload = o.bytes();
            Wire.Out f = new Wire.Out();
            if (threshold >= 0) {
                if (payload.length >= threshold) {
                    Deflater d = new Deflater(); d.setInput(payload); d.finish();
                    byte[] buf = new byte[payload.length + 64]; int n = d.deflate(buf); d.end();
                    byte[] ib = new Wire.Out().varInt(payload.length).raw(Arrays.copyOf(buf, n)).bytes();
                    f.varInt(ib.length).raw(ib);
                } else {
                    byte[] ib = new Wire.Out().varInt(0).raw(payload).bytes();
                    f.varInt(ib.length).raw(ib);
                }
            } else f.varInt(payload.length).raw(payload);
            byte[] b = f.bytes();
            if (enc != null) b = enc.update(b);
            out.write(b); out.flush();
        }

        @Override public void run() {
            try (Socket s = ss.accept()) {
                in = new BufferedInputStream(s.getInputStream()); out = s.getOutputStream();
                Wire.In hs = new Wire.In(frame());
                hs.varInt(); hs.varInt(); hs.str(); hs.u16(); hs.varInt();
                Wire.In ls = new Wire.In(frame());
                ls.varInt(); loginName = ls.str(); loginUuid = ls.uuid();

                if (online) {
                    KeyPairGenerator g = KeyPairGenerator.getInstance("RSA"); g.initialize(1024);
                    KeyPair kp = g.generateKeyPair();
                    byte[] pub = kp.getPublic().getEncoded(), token = {1, 2, 3, 4};
                    send(Ids.LOGIN_CB_ENCRYPTION, o -> o.str("").buf(pub).buf(token).bool(true));
                    Wire.In er = new Wire.In(frame());
                    check("bot answers with login packet 0x01", er.varInt() == Ids.LOGIN_SB_ENCRYPTION);
                    Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding"); rsa.init(Cipher.DECRYPT_MODE, kp.getPrivate());
                    byte[] secret = rsa.doFinal(er.bytes()), tok = rsa.doFinal(er.bytes());
                    tokenOk = Arrays.equals(tok, token);
                    hash = Auth.serverHash("", secret, pub);
                    SecretKeySpec k = new SecretKeySpec(secret, "AES");
                    dec = Cipher.getInstance("AES/CFB8/NoPadding"); dec.init(Cipher.DECRYPT_MODE, k, new IvParameterSpec(secret));
                    enc = Cipher.getInstance("AES/CFB8/NoPadding"); enc.init(Cipher.ENCRYPT_MODE, k, new IvParameterSpec(secret));
                }
                send(Ids.LOGIN_CB_COMPRESSION, o -> o.varInt(256));
                threshold = 256;
                UUID id = loginUuid;
                send(Ids.LOGIN_CB_FINISHED, o -> o.uuid(id).str(loginName).varInt(0));
                Wire.In ack = new Wire.In(frame());
                if (ack.varInt() != Ids.LOGIN_SB_ACK) throw new IOException("no login ack");
                Wire.In ci = new Wire.In(frame()); ci.varInt();               // client information
                send(Ids.CFG_CB_FINISH, o -> {});
                while (true) { Wire.In f = new Wire.In(frame()); if (f.varInt() == Ids.CFG_SB_FINISH) break; }

                // PLAY
                send(Ids.CB_LOGIN, o -> o.i32(7).u8(0));
                send(Ids.CB_PLAYER_POSITION, o -> o.varInt(1).f64(0).f64(64).f64(0).f64(0).f64(0).f64(0).f32(0).f32(0).i32(0));
                UUID enemy = UUID.nameUUIDFromBytes("Enemy".getBytes());
                send(Ids.CB_PLAYER_INFO_UPDATE, o -> o.u8(0x01).varInt(1).uuid(enemy).str("Enemy").varInt(0));
                send(Ids.CB_ADD_ENTITY, o -> o.varInt(500).uuid(enemy).varInt(155).f64(4).f64(64).f64(0).u8(0).u8(0).u8(0).u8(0).u8(0).u8(0).u8(0));
                send(Ids.CB_KEEPALIVE, o -> o.i64(42));
                if (terrain) {
                    // stone up to y=63 everywhere around, plus a wall at x=2 (y 64..66) that spans z -16..15
                    for (int cxx = -1; cxx <= 1; cxx++) for (int cz = -1; cz <= 0; cz++) {
                        final int cx = cxx;
                        final byte[] pk = ChunkTest.chunkPacket(cx, cz, ChunkTest.sections(24, -64, false,
                                (x, y, z) -> y <= 63 ? ChunkTest.STONE : ((cx == 0 && x == 2 && y <= 66) ? ChunkTest.STONE : ChunkTest.AIR), -1), true);
                        send(Ids.CB_LEVEL_CHUNK, o -> o.raw(pk));
                    }
                    send(Ids.CB_CHUNK_BATCH_FINISHED, o -> o.varInt(6));
                }
                long end = System.currentTimeMillis() + 9000;
                s.setSoTimeout(500);
                while (System.currentTimeMillis() < end && !done) {
                    Wire.In f;
                    try { f = new Wire.In(frame()); } catch (SocketTimeoutException e) { continue; }
                    int pid = f.varInt();
                    if (pid == Ids.SB_ACCEPT_TELEPORT) accepted = f.varInt() == 1;
                    else if (pid == Ids.SB_PLAYER_LOADED) loaded = true;
                    else if (pid == Ids.SB_MOVE_POS || pid == Ids.SB_MOVE_POS_ROT) { moved = true; movePackets.incrementAndGet(); maxX = Math.max(maxX, f.f64()); }
                    else if (pid == Ids.SB_CHUNK_BATCH_RECEIVED) batchAcked = f.f32() > 0;
                    else if (pid == Ids.SB_KEEPALIVE) gotKeepAlive = f.i64() == 42;
                    else if (pid == Ids.SB_INTERACT) { if (f.varInt() == 500 && f.varInt() == 1) { attacked = true; attackPackets.incrementAndGet(); } }
                    else if (pid == Ids.SB_SWING) swung = true;
                    if (attackPackets.get() >= 3) done = true;
                }
            } catch (Exception e) {
                kickReason = e.toString();
            }
        }
    }

    static boolean waitFor(java.util.function.BooleanSupplier c, int ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) { if (c.getAsBoolean()) return true; Thread.sleep(50); }
        return c.getAsBoolean();
    }

    public static void main(String[] a) throws Exception {
        // ---- mock Mojang session server
        AtomicReference<String> joinBody = new AtomicReference<>();
        HttpServer http = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        http.createContext("/session/minecraft/join", ex -> {
            joinBody.set(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            ex.sendResponseHeaders(204, -1); ex.close();
        });
        http.start();
        System.setProperty("duelforge.sessionUrl", "http://127.0.0.1:" + http.getAddress().getPort() + "/session/minecraft/join");
        UUID accUuid = UUID.fromString("11111111-2222-3333-4444-555555555555");
        Auth.sessionSource = () -> new String[]{"Alt", accUuid.toString(), "TOKEN123"};
        Auth.file = java.nio.file.Path.of(System.getProperty("java.io.tmpdir"), "df-test-accounts-" + System.nanoTime() + ".properties");

        System.out.println("== offline-mode server");
        Server off = new Server(false);
        new Thread(off).start();
        BotClient b1 = new BotClient("127.0.0.1", off.port(), "OfflineBot", "A", Tier.HT3, Mode.SWORD, new ArrayList<>(), Set.of("offlinebot"));
        b1.start();
        check("bot joined (PLAYING)", waitFor(() -> b1.status == BotClient.Status.PLAYING, 4000));
        check("teleport accepted (position packet id is right)", waitFor(() -> off.accepted, 3000));
        check("player_loaded sent", waitFor(() -> off.loaded, 2000));
        check("keep-alive answered", waitFor(() -> off.gotKeepAlive, 2000));
        check("bot moves", waitFor(() -> off.moved, 3000));
        check("bot attacks the enemy player (use_entity id is right)", waitFor(() -> off.attacked, 8000));
        check("bot swings", waitFor(() -> off.swung, 2000));
        b1.stop();

        System.out.println("== online-mode server (encryption + session join)");
        Server on = new Server(true);
        new Thread(on).start();
        BotClient b2 = new BotClient("127.0.0.1", on.port(), "Alt", "A", Tier.HT3, Mode.SWORD, new ArrayList<>(), Set.of("alt"));
        b2.start();
        check("bot joined online server", waitFor(() -> b2.status == BotClient.Status.PLAYING, 6000));
        check("server saw the account name", "Alt".equals(on.loginName));
        check("server saw the account uuid", accUuid.equals(on.loginUuid));
        check("RSA verify token decrypted correctly", on.tokenOk);
        String jb = joinBody.get();
        check("session join was called", jb != null);
        check("session join: token + profile", jb != null && jb.contains("\"accessToken\":\"TOKEN123\"") && jb.contains("\"selectedProfile\":\"11111111222233334444555555555555\""));
        check("session join: serverId hash equals what the server computes", jb != null && on.hash != null && jb.contains("\"serverId\":\"" + on.hash + "\""));
        check("encrypted play: teleport accepted", waitFor(() -> on.accepted, 3000));
        check("encrypted play: bot attacks", waitFor(() -> on.attacked, 8000));
        b2.stop();

        System.out.println("== online-mode server, nick without account");
        Server on2 = new Server(true);
        new Thread(on2).start();
        BotClient b3 = new BotClient("127.0.0.1", on2.port(), "Stranger", "A", Tier.HT3, Mode.SWORD, new ArrayList<>(), Set.of("stranger"));
        b3.start();
        check("bot reports the problem", waitFor(() -> b3.status == BotClient.Status.ERROR, 4000) && b3.info.contains("online-mode") && b3.info.contains("Alt"));
        System.out.println("      info: " + b3.info);

        System.out.println("== Controller orders (FOLLOW / IDLE)");
        Server fo = new Server(false);
        new Thread(fo).start();
        BotClient b4 = new BotClient("127.0.0.1", fo.port(), "Follower", "ctl", Tier.HT3, Mode.SWORD, new ArrayList<>(), Set.of("follower"));
        b4.setOrder(Order.IDLE, "Enemy");
        b4.start();
        check("joined", waitFor(() -> b4.status == BotClient.Status.PLAYING, 4000));
        Thread.sleep(2500);
        check("IDLE: no attacks, no walking", fo.attackPackets.get() == 0);
        b4.setOrder(Order.FOLLOW, "Enemy");
        check("FOLLOW: walks toward the owner", waitFor(() -> fo.moved, 3000));
        check("FOLLOW: still does not attack", fo.attackPackets.get() == 0);
        b4.setOrder(Order.FIGHT, "Enemy");
        check("FIGHT on the owner: attacks", waitFor(() -> fo.attacked, 8000));
        b4.stop();

        System.out.println("== chunks: terrain from chunk packets");
        ChunkTest.setTable();
        for (boolean physics : new boolean[]{true, false}) {
            Opts.terrainPhysics = physics;
            Server ts = new Server(false);
            ts.terrain = true;
            new Thread(ts).start();
            BotClient b5 = new BotClient("127.0.0.1", ts.port(), "Terra" + (physics ? 1 : 0), "A", Tier.HT3, Mode.SWORD, new ArrayList<>(), Set.of("terra" + (physics ? 1 : 0)));
            b5.start();
            check("joined", waitFor(() -> b5.status == BotClient.Status.PLAYING, 4000));
            if (physics) {
                check("bot acknowledges the chunk batch (chunk_batch_received)", waitFor(() -> ts.batchAcked, 3000));
                check("bot stored the 6 chunks (" + b5.chunkCount() + ")", waitFor(() -> b5.chunkCount() == 6, 3000));
            }
            waitFor(() -> ts.attackPackets.get() >= 3, 8000);
            Thread.sleep(500);
            if (physics) check(String.format("terrainPhysics on: the wall at x=2 stops the bot (max x sent = %.3f, limit 1.7)", ts.maxX), ts.maxX <= 1.7 + 1e-6 && ts.maxX > 0.5);
            else check(String.format("terrainPhysics off: flat model walks through the wall (max x sent = %.3f)", ts.maxX), ts.maxX > 2.5);
            b5.stop();
        }
        Opts.terrainPhysics = true;

        http.stop(0);
        System.out.println(fail == 0 ? "\nALL OK" : "\nFAILED: " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
