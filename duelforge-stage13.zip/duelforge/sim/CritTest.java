import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * Jump-crit validity: in vanilla a hit is a crit only while falling AND not sprinting. The attack packet leaves before the
 * tick's sprint command, so the sprint state the server sees is the one set on the previous tick.
 * Run: javac -cp out -d out sim/CritTest.java && java -cp out CritTest
 */
public class CritTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    /** {airborne hits, airborne hits while sprinting (no crit), total hits, grounded hits, grounded hits while sprinting} */
    static int[] run(Mode mode, Tier tier, long seed, int ticks) {
        Random rnd = new Random(seed);
        World w = new World();
        List<Object[]> out = new ArrayList<>();
        Body body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); out.add(new Object[]{id, o.bytes()}); }, rnd);
        UUID eu = UUID.nameUUIDFromBytes("enemy".getBytes());
        w.setName(eu, "Enemy");
        World.Ent enemy = w.add(1000, eu, 128, 6, 64, 0, 0);
        body.entityId = 1;
        body.serverPosition(0, 64, 0, 0, 0, 0, -90, 0);
        Brain brain = new Brain(body, w, rnd, tier, mode, "A", Set.of(), "Bot1");
        Kit k = new Kit("k");
        k.slots.put("hotbar.0", new Kit.Entry(1, "minecraft:netherite_sword"));
        k.slots.put("hotbar.2", new Kit.Entry(8, "minecraft:golden_apple"));
        k.mode = mode;
        brain.setLayout(Layout.detect(mode, k.hotbarItems()));
        brain.setKit(k);
        int air = 0, airSprint = 0, total = 0, ground = 0, groundSprint = 0;
        double ang = 0;
        for (int tick = 1; tick <= ticks; tick++) {
            w.now = tick;
            // the enemy slowly circles the bot's start point so the duel keeps going
            ang += 0.03; enemy.setPos(body.x + 2.2 * Math.cos(ang) + 0.0, 64, body.z + 2.2 * Math.sin(ang), tick);
            boolean sprintSeenByServer = body.sprinting, onGround = body.onGround;
            double vy = body.vy;
            out.clear();
            brain.tick(); body.step(); body.flush();
            for (Object[] pk : out) {
                if ((Integer) pk[0] != Ids.SB_INTERACT) continue;
                Wire.In in = new Wire.In((byte[]) pk[1]);
                int target = in.varInt(); int type = in.varInt();
                if (type != 1 || target != 1000) continue;
                total++;
                if (!onGround && vy < 0) { air++; if (sprintSeenByServer) airSprint++; }
                else if (onGround) { ground++; if (sprintSeenByServer) groundSprint++; }
            }
        }
        return new int[]{air, airSprint, total, ground, groundSprint};
    }

    public static void main(String[] a) {
        Opts.combo = true;
        int[] base = sweep();
        Opts.sprintReset = false;
        int[] old = sweep();
        Opts.sprintReset = true;
        System.out.printf("   old logic: %d falling hits, %d of them sprinting (no crit); %d of %d ground hits were sprint hits (%.0f%%)%n", old[0], old[1], old[4], old[3], 100.0 * old[4] / Math.max(1, old[3]));
        System.out.printf("   new logic: %d falling hits, %d of them sprinting (no crit); %d of %d ground hits were sprint hits (%.0f%%)%n", base[0], base[1], base[4], base[3], 100.0 * base[4] / Math.max(1, base[3]));
        check("the bot lands falling hits (the test is meaningful)", base[0] >= 10);
        check("no falling hit is delivered while sprinting", base[1] == 0);
        check("old logic did deliver such hits (the test is meaningful)", old[1] > 0);
        check("sprint hits on the ground are not lost (still >= 85%)", 100.0 * base[4] / Math.max(1, base[3]) >= 85);
        System.out.println(fail == 0 ? "ALL OK" : fail + " FAILED");
        System.exit(fail == 0 ? 0 : 1);
    }

    static int[] sweep() {
        int air = 0, bad = 0, total = 0, g = 0, gs = 0;
        for (Tier t : new Tier[]{Tier.HT3, Tier.HT1, Tier.HT0}) {
            for (long s = 1; s <= 4; s++) {
                int[] r = run(Mode.SWORD, t, s, 1200);
                air += r[0]; bad += r[1]; total += r[2]; g += r[3]; gs += r[4];
            }
        }
        return new int[]{air, bad, total, g, gs};
    }
}
