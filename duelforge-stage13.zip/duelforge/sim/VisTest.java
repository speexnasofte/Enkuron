import dev.duelforge.vis.*;

/** Maths of the bot HUD and the target ring. Run: javac -cp out -d out sim/VisTest.java && java -cp out VisTest */
public class VisTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    public static void main(String[] a) {
        check("lerpColor endpoints", HudMath.lerpColor(0xFF000000, 0xFFFFFFFF, 0) == 0xFF000000 && HudMath.lerpColor(0xFF000000, 0xFFFFFFFF, 1) == 0xFFFFFFFF);
        check("lerpColor midpoint, alpha kept", HudMath.lerpColor(0xFF000000, 0xFFFFFFFF, 0.5f) == 0xFF808080);
        check("lerpColor clamps t", HudMath.lerpColor(0xFF102030, 0xFF405060, 7f) == 0xFF405060);
        check("full health = accent, empty = error", HudMath.hpColor(1f) == HudMath.ACCENT && HudMath.hpColor(0f) == HudMath.ERROR && HudMath.hpColor(0.5f) == HudMath.WARN);
        float v = 1f;
        for (int i = 0; i < 60; i++) v = HudMath.approach(v, 0.25f, 1 / 60f, 9f);
        check("health bar glides to the target within a second", v == 0.25f);
        check("one frame moves it only part of the way", HudMath.approach(1f, 0f, 1 / 60f, 9f) > 0.5f);
        check("no jump on a long pause (dt 0)", HudMath.approach(0.8f, 0.2f, 0f, 9f) == 0.8f);

        int[][] tl = HudMath.layout(3, 854, 480, 0, 150, 36, 4, 6);
        check("top-left stack goes down", tl.length == 3 && tl[0][0] == 6 && tl[0][1] == 6 && tl[1][1] == 46 && tl[2][1] == 86);
        int[][] br = HudMath.layout(2, 854, 480, 3, 150, 36, 4, 6);
        check("bottom-right stack goes up from the corner", br[0][0] == 854 - 150 - 6 && br[0][1] == 480 - 6 - 36 && br[1][1] == 480 - 6 - 36 - 40);
        check("cards that do not fit are dropped", HudMath.layout(50, 854, 200, 1, 150, 36, 4, 6).length == (200 - 12 + 4) / 40);
        check("tiny screen: no negative count", HudMath.layout(3, 100, 10, 0, 150, 36, 4, 6).length == 0);
        check("clip", HudMath.clip("abcdefghij", 6).equals("abcde…") && HudMath.clip("abc", 6).equals("abc") && HudMath.clip(null, 3).isEmpty());
        check("tier colours: weakest cool, strongest red", HudMath.tierColor(0, 11) == 0xFF5B8DEF && HudMath.tierColor(10, 11) == HudMath.ERROR && HudMath.tierColor(5, 11) == HudMath.ACCENT);

        double[][] r = RingMath.ring(10, 64, -5, 1.0, 8, 0.3);
        boolean onCircle = true;
        for (double[] p : r) onCircle &= Math.abs(Math.hypot(p[0] - 10, p[2] + 5) - 1.0) < 1e-9 && p[1] == 64;
        check("ring: 8 points, all on the circle, level", r.length == 8 && onCircle);
        check("ring: evenly spaced", Math.abs(Math.hypot(r[0][0] - r[1][0], r[0][2] - r[1][2]) - 2 * Math.sin(Math.PI / 8)) < 1e-9);
        check("ring rotates with phase", Math.abs(RingMath.ring(0, 0, 0, 1, 4, 0)[0][0] - 1) < 1e-9 && Math.abs(RingMath.ring(0, 0, 0, 1, 4, Math.PI / 2)[0][2] - 1) < 1e-9);
        check("sweep goes 0 -> 1 -> 0 over the period", RingMath.sweep(0, 40) == 0 && RingMath.sweep(20, 40) == 1 && RingMath.sweep(10, 40) == 0.5 && RingMath.sweep(40, 40) == 0);
        check("radius is wider than the hitbox", RingMath.radiusFor(0.6) > 0.6 && RingMath.radiusFor(0.1) >= 0.45);
        System.out.println(fail == 0 ? "ALL OK" : fail + " FAILED");
        System.exit(fail == 0 ? 0 : 1);
    }
}
