import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * Chunk reading without Minecraft: builds level_chunk_with_light / block_update / section_blocks_update packets the way
 * the server writes them (both paletted-container layouts, both heightmap layouts), parses them and checks the terrain
 * queries, explosion cover and the terrain physics of the Body.
 *
 *   javac -d out $(find ../src/main/java/dev/duelforge/ai ../src/main/java/dev/duelforge/net -name '*.java') ChunkTest.java
 *   java -cp out ChunkTest
 */
public class ChunkTest {
    static int fail = 0;
    static void check(String what, boolean ok) { System.out.println((ok ? "  ok   " : "  FAIL ") + what); if (!ok) fail++; }

    // state ids used by this test's block table
    static final int AIR = 0, STONE = 1, WATER = 2, OBS = 3, WEB = 4, SLAB = 5, LAVA = 6;

    // ---- packet writer (mirrors the server) ----
    static void container(Wire.Out o, boolean prefixed, int[] v, int maxIndirect, boolean forceDirect, int directBits) {
        TreeSet<Integer> distinct = new TreeSet<>();
        for (int x : v) distinct.add(x);
        if (distinct.size() == 1 && !forceDirect) {
            o.u8(0).varInt(distinct.first());
            if (prefixed) o.varInt(0);
            return;
        }
        int bpe; int[] palette = null;
        if (forceDirect) bpe = directBits;
        else {
            bpe = Math.max(maxIndirect == 8 ? 4 : 1, 32 - Integer.numberOfLeadingZeros(distinct.size() - 1));
            palette = distinct.stream().mapToInt(Integer::intValue).toArray();
        }
        o.u8(bpe);
        if (palette != null) { o.varInt(palette.length); for (int p : palette) o.varInt(p); }
        int per = 64 / bpe, longs = (v.length + per - 1) / per;
        long[] data = new long[longs];
        for (int i = 0; i < v.length; i++) {
            int val = v[i];
            if (palette != null) val = Arrays.binarySearch(palette, v[i]);
            data[i / per] |= ((long) val) << ((i % per) * bpe);
        }
        if (prefixed) o.varInt(longs);
        for (long l : data) o.i64(l);
    }

    interface Fill { int at(int x, int y, int z); }

    /** Section bytes: sections of 16 blocks in y from minY; f gives the state at world-local (x, y, z). */
    static byte[] sections(int n, int minY, boolean prefixed, Fill f, int directSection) {
        Wire.Out o = new Wire.Out();
        for (int s = 0; s < n; s++) {
            int[] v = new int[4096];
            int nonAir = 0;
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                int st = f.at(x, minY + s * 16 + y, z);
                v[(y * 16 + z) * 16 + x] = st;
                if (st != AIR) nonAir++;
            }
            o.i16(nonAir);
            container(o, prefixed, v, 8, s == directSection, 15);
            int[] biomes = new int[64];
            for (int i = 0; i < 64; i++) biomes[i] = (i % 5 == 0) ? 2 : 1;
            container(o, prefixed, biomes, 3, false, 0);
        }
        return o.bytes();
    }

    static byte[] chunkPacket(int cx, int cz, byte[] sec, boolean mapHeightmaps) {
        Wire.Out o = new Wire.Out();
        o.i32(cx).i32(cz);
        if (mapHeightmaps) {
            o.varInt(2);
            o.varInt(1).varInt(37); for (int i = 0; i < 37; i++) o.i64(i * 31L);
            o.varInt(4).varInt(37); for (int i = 0; i < 37; i++) o.i64(i * 17L);
        } else {
            o.u8(0x0A).u8(0x0C).i16(1).raw("H".getBytes()).i32(2).i64(5).i64(6).u8(0);   // nameless compound {H: long[2]}
        }
        o.buf(sec);
        o.varInt(0);                      // block entities
        o.raw(new byte[40]);              // light data (ignored)
        return o.bytes();
    }

    /** World of the test (chunk-local x, world y, z): stone up to y=63, a wall at x=5 (y 64..66), obsidian at (2,64,2), slab at (9,64,9). */
    static int world(int x, int y, int z) {
        if (y <= 63) return STONE;
        if (x == 5 && y >= 64 && y <= 66) return STONE;
        if (x == 2 && z == 2 && y == 64) return OBS;
        if (x == 9 && z == 9 && y == 64) return SLAB;
        if (x == 12 && z == 12 && y == 64) return WEB;
        if (x == 13 && z == 13 && y == 64) return LAVA;
        if (x == 14 && z == 3 && y == 64) return WATER;
        return AIR;
    }

    static byte[] setTable() {
        byte[] t = new byte[8];
        t[AIR] = BlockTable.AIR; t[STONE] = BlockTable.FULL; t[WATER] = BlockTable.WATER; t[OBS] = BlockTable.OBSIDIAN;
        t[WEB] = BlockTable.WEB; t[SLAB] = BlockTable.PARTIAL; t[LAVA] = BlockTable.LAVA;
        BlockTable.set(t);
        return t;
    }

    public static void main(String[] a) {
        byte[] t = setTable();

        for (boolean prefixed : new boolean[]{false, true}) for (boolean mapHm : new boolean[]{true, false}) {
            System.out.println("== level chunk: " + (prefixed ? "length-prefixed" : "fixed") + " containers, " + (mapHm ? "map" : "NBT") + " heightmaps");
            ChunkStore st = new ChunkStore();
            ChunkParser.resetMode();
            byte[] sec = sections(24, -64, prefixed, ChunkTest::world, 8);  // section 8 (y 64..79) uses the direct palette
            boolean ok = ChunkParser.levelChunk(new Wire.In(chunkPacket(0, 0, sec, mapHm)), st);
            check("chunk accepted", ok);
            check("floor is a full block", st.get(3, 63, 3) == BlockTable.FULL);
            check("air above the floor", st.get(3, 64, 3) == BlockTable.AIR);
            check("deep stone (y=-64) known, minY = -64", st.get(3, -64, 3) == BlockTable.FULL);
            check("wall at x=5", st.get(5, 65, 7) == BlockTable.FULL && st.get(5, 67, 7) == BlockTable.AIR);
            check("obsidian recognised (crystal base)", st.get(2, 64, 2) == BlockTable.OBSIDIAN);
            check("slab = partial, web, lava, water", st.get(9, 64, 9) == BlockTable.PARTIAL && st.get(12, 64, 12) == BlockTable.WEB
                    && st.get(13, 64, 13) == BlockTable.LAVA && st.get(14, 64, 3) == BlockTable.WATER);
            check("unknown chunk reads UNKNOWN", st.get(100, 64, 100) == ChunkStore.UNKNOWN);
            check("layout remembered (" + ChunkParser.knownMode() + ")", ChunkParser.knownMode() == (prefixed ? 2 : 1));
            // every block of the chunk, not just spot checks
            int bad = 0;
            for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = -64; y < 320; y++) {
                int exp = t[world(x, y, z)];
                if (st.get(x, y, z) != exp) bad++;
            }
            check("all " + (16 * 16 * 384) + " blocks match", bad == 0);
        }

        System.out.println("== layout self-heals when the other layout arrives");
        {
            ChunkStore st = new ChunkStore();
            ChunkParser.resetMode();
            check("prefixed chunk", ChunkParser.levelChunk(new Wire.In(chunkPacket(0, 0, sections(24, -64, true, ChunkTest::world, -1), true)), st));
            check("fixed chunk after it", ChunkParser.levelChunk(new Wire.In(chunkPacket(1, 0, sections(24, -64, false, ChunkTest::world, -1), true)), st) && ChunkParser.knownMode() == 1);
            check("both chunks stored", st.size() == 2 && st.get(16 + 3, 63, 3) == BlockTable.FULL);
            check("garbage does not throw and is rejected", !ChunkParser.levelChunk(new Wire.In(chunkPacket(2, 0, new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9}, true)), st));
            check("nether-sized chunk (16 sections) starts at y=0", ChunkParser.levelChunk(new Wire.In(chunkPacket(3, 0, sections(16, 0, false, (x, y, z) -> y < 10 ? STONE : AIR, -1), true)), st)
                    && st.get(48 + 1, 9, 1) == BlockTable.FULL && st.get(48 + 1, 10, 1) == BlockTable.AIR);
        }

        System.out.println("== block updates");
        ChunkStore st = new ChunkStore();
        ChunkParser.resetMode();
        ChunkParser.levelChunk(new Wire.In(chunkPacket(0, 0, sections(24, -64, false, ChunkTest::world, 8), true)), st);
        ChunkParser.levelChunk(new Wire.In(chunkPacket(-1, -1, sections(24, -64, false, ChunkTest::world, -1), true)), st);
        {
            long pos = Wire.packPos(3, 64, 3);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(pos).varInt(WEB).bytes()), st);
            check("block_update: web appears", st.get(3, 64, 3) == BlockTable.WEB);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(-5, 70, -3)).varInt(STONE).bytes()), st);
            check("block_update in negative coordinates (chunk -1,-1)", st.get(-5, 70, -3) == BlockTable.FULL && st.get(-5, 71, -3) == BlockTable.AIR);
            // section update: section x=0,y=4 (y 64..79),z=0
            long sp = ((0L & 0x3FFFFF) << 42) | (4L & 0xFFFFF) | ((0L & 0x3FFFFF) << 20);
            Wire.Out o = new Wire.Out().i64(sp).varInt(3);
            int[][] ch = {{7, 65, 8, OBS}, {1, 66, 1, STONE}, {5, 64, 0, AIR}};
            for (int[] c : ch) {
                long local = ((long) c[0] << 8) | ((long) c[2] << 4) | (c[1] & 15);
                long v = ((long) c[3] << 12) | local;
                while ((v & ~0x7FL) != 0) { o.u8((int) ((v & 0x7F) | 0x80)); v >>>= 7; }
                o.u8((int) v);
            }
            ChunkParser.sectionBlocksUpdate(new Wire.In(o.bytes()), st);
            check("section_blocks_update: 3 blocks", st.get(7, 65, 8) == BlockTable.OBSIDIAN && st.get(1, 66, 1) == BlockTable.FULL && st.get(5, 64, 0) == BlockTable.AIR);
            check("update of an unloaded chunk is ignored", ok(() -> ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(500, 64, 500)).varInt(STONE).bytes()), st)));
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(pos).varInt(AIR).bytes()), st);
            ChunkParser.forgetChunk(new Wire.In(new Wire.Out().i64((0L & 0xFFFFFFFFL) | ((long) -1 << 32)).bytes()), st);   // chunk (0,-1)
            check("forget_level_chunk of another chunk keeps (0,0)", st.size() == 2);
            ChunkParser.forgetChunk(new Wire.In(new Wire.Out().i64((-1L & 0xFFFFFFFFL) | ((long) -1 << 32)).bytes()), st);   // chunk (-1,-1)
            check("forget_level_chunk removes (-1,-1)", st.size() == 1 && st.get(-5, 70, -3) == ChunkStore.UNKNOWN);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(7, 65, 8)).varInt(AIR).bytes()), st);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(1, 66, 1)).varInt(AIR).bytes()), st);
        }

        System.out.println("== rays and explosion cover");
        {
            // wall x=5, y 64..66, whole z range. Crystal east of it, target west of it.
            double seenBehind = st.seenPercent(8.5, 65.0, 8.5, 2.2, 64.0, 8.2, 2.8, 65.8, 8.8);
            check("target behind a 3-high wall: seen = " + seenBehind, seenBehind == 0.0);
            double seenOpen = st.seenPercent(1.5, 65.0, 8.5, 2.2, 64.0, 8.2, 2.8, 65.8, 8.8);
            check("same side, no wall: seen = " + seenOpen, seenOpen == 1.0);
            check("rayBlocked through the wall / along it", st.rayBlocked(8.5, 65.5, 8.5, 2.5, 65.5, 8.5) && !st.rayBlocked(4.5, 65.5, 1.5, 4.5, 65.5, 14.5));
            check("floor blocks a ray going down", st.rayBlocked(3.5, 66, 3.5, 3.5, 60, 3.5));
            check("ray that crosses x=5 above the wall (y>67) is free; one crossing at y=65 is blocked",
                    !st.rayBlocked(6.5, 80.0, 8.5, 4.5, 67.5, 8.5) && st.rayBlocked(6.5, 65.5, 8.5, 4.5, 65.5, 8.5));
            ChunkStore low = new ChunkStore();
            ChunkParser.levelChunk(new Wire.In(chunkPacket(0, 0, sections(24, -64, false, (x, y, z) -> y <= 63 ? STONE : (x == 5 && y == 64 ? STONE : AIR), -1), true)), low);
            double part = low.seenPercent(8.5, 65.0, 8.5, 2.2, 64.0, 8.2, 2.8, 65.8, 8.8);
            check("1-high wall: head sees the crystal, feet do not: seen = " + String.format("%.2f", part), part > 0.3 && part < 0.9);
        }
        {
            World w = new World();
            check("World.exposure without chunks = 1.0", w.exposure(8.5, 65, 8.5, 2.5, 64, 8.5) == 1.0);
            ChunkParser.levelChunk(new Wire.In(chunkPacket(0, 0, sections(24, -64, false, ChunkTest::world, -1), true)), w.chunks);
            check("World.exposure behind the wall = 0", w.exposure(8.5, 65, 8.5, 2.5, 64, 8.5) == 0.0);
            ExplosionMath.Armor none = ExplosionMath.Armor.NONE;
            double open = ExplosionMath.crystal(none, 1.5, 65, 8.5, 2.5, 64, 8.5, w.exposure(1.5, 65, 8.5, 2.5, 64, 8.5));
            double covered = ExplosionMath.crystal(none, 8.5, 65, 8.5, 2.5, 64, 8.5, w.exposure(8.5, 65, 8.5, 2.5, 64, 8.5));
            check(String.format("crystal damage in the open %.1f vs behind the wall %.1f", open, covered), open > 15 && covered < 2);
        }

        System.out.println("== collision");
        {
            double[] r = Collide.move(st, 2.5, 64, 8.5, 4.0, 0, 0);
            check("walking into the wall stops at x=4.7 (moved " + r[0] + ")", Math.abs(r[0] - 2.2) < 1e-9);
            r = Collide.move(st, 2.5, 70, 8.5, 0, -10, 0);
            check("falling from y=70 lands at 64 (dy " + r[1] + ")", Math.abs(r[1] + 6) < 1e-9);
            r = Collide.move(st, 2.5, 64, 8.5, 0, 0, 3.0);
            check("moving along z is free", r[2] == 3.0);
            r = Collide.move(st, 4.0, 64, 8.5, 3.0, 0, 0);
            check("starting right next to the wall (x+0.3=4.3 -> 4.7): moves 0.7 at most (" + r[0] + ")", Math.abs(r[0] - 0.7) < 1e-9);
            r = Collide.move(st, 3.0, 64, 8.5, 1.0, 1.0, 0);
            check("jumping towards the wall from x=3.0: Y free, X free (wall is 1.7 away)", r[1] == 1.0 && r[0] == 1.0);
            r = Collide.move(st, 3.0, 64, 8.5, 2.5, 1.0, 0);
            check("same jump with 2.5 forward: X cut to 1.7, Y still free", Math.abs(r[0] - 1.7) < 1e-9 && r[1] == 1.0);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(2, 66, 8)).varInt(STONE).bytes()), st);
            r = Collide.move(st, 2.5, 64, 8.5, 0, 1.0, 0);
            check("ceiling at y=66 stops the head (" + r[1] + ")", Math.abs(r[1] - 0.2) < 1e-9);
            ChunkParser.blockUpdate(new Wire.In(new Wire.Out().i64(Wire.packPos(2, 66, 8)).varInt(AIR).bytes()), st);
            check("floorY on flat ground = 64", Collide.floorY(st, 2.5, 64, 8.5) == 64.0);
            check("floorY on top of the wall = 67", Collide.floorY(st, 5.5, 70, 8.5) == 67.0);
            check("floorY straddling the wall edge = 67 (highest corner)", Collide.floorY(st, 4.9, 70, 8.5) == 67.0);
            check("floorY in an unknown column = NaN", Double.isNaN(Collide.floorY(st, 300, 70, 300)));
            check("slab detected under the feet", Collide.onPartial(st, 9.5, 65, 9.5) && Collide.onPartial(st, 9.5, 64, 9.5) && !Collide.onPartial(st, 2.5, 64, 8.5));
        }

        System.out.println("== Body on real terrain");
        {
            Body b = new Body((id, body) -> {}, new Random(1));
            b.terrain = st;
            b.serverPosition(2.5, 64, 8.5, 0, 0, 0, -90f, 0f);    // yaw -90 = walking towards +x
            check("standing on the floor: onGround, groundY = 64", b.onGround && b.groundY == 64.0);
            b.fwd = 1; b.wantSprint = true;
            for (int i = 0; i < 60; i++) b.step();
            check(String.format("walked into the wall and stopped: x = %.3f (<= 4.7)", b.x), b.x <= 4.7 + 1e-6 && b.x > 4.4);
            check("still on the ground at y = 64", b.onGround && Math.abs(b.y - 64) < 1e-9);
            // drop the bot above the wall top: it must land on y = 67, not fall to 64
            b.serverPosition(5.5, 72, 8.5, 0, 0, 0, 0f, 0f);
            b.fwd = 0; b.wantSprint = false;
            for (int i = 0; i < 40; i++) b.step();
            check(String.format("falls onto the wall top: y = %.3f", b.y), Math.abs(b.y - 67) < 1e-6 && b.onGround);
            // slab under the feet -> terrain model stays out of it
            b.serverPosition(9.5, 65, 9.5, 0, 0, 0, 0f, 0f);
            for (int i = 0; i < 5; i++) b.step();
            check(String.format("on a slab the old model is kept: y stays %.3f", b.y), Math.abs(b.y - 65) < 1e-9);
            // off switch
            Opts.terrainPhysics = false;
            b.serverPosition(2.5, 64, 8.5, 0, 0, 0, -90f, 0f);
            b.fwd = 1;
            for (int i = 0; i < 60; i++) b.step();
            check(String.format("terrainPhysics off: walks through the wall (x = %.2f)", b.x), b.x > 6);
            Opts.terrainPhysics = true;
            // jump on flat terrain lands where it started
            b.serverPosition(2.5, 64, 12.5, 0, 0, 0, 0f, 0f);
            b.fwd = 0; b.jump = true; b.step(); b.jump = false;
            double top = b.y;
            for (int i = 0; i < 30; i++) { b.step(); top = Math.max(top, b.y); }
            check(String.format("jump apex %.3f (vanilla 1.252), lands back at 64", top - 64), Math.abs(top - 64 - 1.2522) < 0.01 && Math.abs(b.y - 64) < 1e-6 && b.onGround);
        }

        System.out.println("== trim");
        {
            ChunkStore s = new ChunkStore();
            for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) s.put(x, z, new ChunkStore.Chunk(0, 1));
            s.trim(0, 0, 3);
            check("121 chunks trimmed to radius 3 = 49", s.size() == 49);
        }

        System.out.println(fail == 0 ? "\nALL OK" : "\nFAILED: " + fail);
        if (fail > 0) System.exit(1);
    }

    static boolean ok(Runnable r) { try { r.run(); return true; } catch (RuntimeException e) { return false; } }
}
