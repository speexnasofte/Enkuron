import dev.duelforge.ai.*;
import dev.duelforge.net.*;
import java.util.*;

/**
 * Duel / swarm simulator. Server rules modelled: weapon cooldown damage scaling, crits, ~10 tick invulnerability after a hit
 * (extra hits inside it only deal the difference), knockback, golden apples, reach check. The "human" is a scripted fighter
 * with adjustable skill. This is a MODEL, not a real server: use it to compare bot versions with each other.
 */
public class Duel {
    static final int HUMAN_ID = 1000;
    static final double BASE_DMG = 3.6;               // one full sword hit through armor, hp points

    static final class Skill { int react; double miss, full, crit; int strafe; float healAt; int apples; }
    static Skill skill(String n) {
        Skill s = new Skill();
        switch (n) {
            case "LT4" -> { s.react = 10; s.miss = 0.30; s.full = 0.55; s.crit = 0.15; s.strafe = 25; s.healAt = 5; s.apples = 4; }
            case "HT3" -> { s.react = 6; s.miss = 0.15; s.full = 0.80; s.crit = 0.40; s.strafe = 18; s.healAt = 7; s.apples = 5; }
            default -> { s.react = 3; s.miss = 0.05; s.full = 0.95; s.crit = 0.80; s.strafe = 12; s.healAt = 8; s.apples = 6; }
        }
        return s;
    }

    static final class Pkt { int id; byte[] d; Pkt(int i, byte[] b) { id = i; d = b; } }

    /** Server-side state of a fighter that has no Body (the scripted human). */
    static final class Fighter {
        double x, y = 64, z, vx, vy, vz; float hp = 20; int hurt; float lastDmg; double lastAtk = -100; boolean ground = true;
        int eat, eatCd, apples, react; double want = 1; int strafeT; int strafeDir = 1; boolean sprint;
    }

    static final class Bot {
        String name; int id; Body body; Brain brain; World w; final List<Pkt> out = new ArrayList<>();
        int sel, hurt, lastAtk = -100, eat, apples = 6, respawnAt = -1; float lastDmg; boolean alive = true; int deaths;
    }

    static int tick;
    static long bSwing, bLanded, bIframe, bReach, bCrit, hSwing, hLanded, hCrit; static double bCharge, hCharge; static long tTot, tReach, tClose, tFar; static java.util.Map<String,Integer> states = new java.util.TreeMap<>();
    static Random rnd;

    /** Returns damage actually applied (0 when inside the invulnerability window with an equal or weaker hit). */
    static float applyHit(int[] hurt, float[] lastDmg, float dmg) {
        if (hurt[0] > 10) {
            if (dmg <= lastDmg[0]) return 0;
            float applied = dmg - lastDmg[0]; lastDmg[0] = dmg; return applied;
        }
        hurt[0] = 20; lastDmg[0] = dmg; return dmg;
    }

    static double boxDist(double ex, double ey, double ez, double bx, double by, double bz) {
        double dx = Math.max(Math.abs(ex - bx) - 0.3, 0), dz = Math.max(Math.abs(ez - bz) - 0.3, 0);
        double dy = ey < by ? by - ey : (ey > by + 1.8 ? ey - by - 1.8 : 0);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    static double[] run(String botTier, String humanSkill, int n, boolean oldCode, int maxTicks, long seed) {
        rnd = new Random(seed);
        tick = 0;
        Shim.clock(() -> tick);
        Skill sk = skill(humanSkill);
        Fighter h = new Fighter(); h.apples = sk.apples; h.react = sk.react; h.x = 0; h.z = 0;
        UUID hu = UUID.nameUUIDFromBytes("Human".getBytes());
        List<Bot> bots = new ArrayList<>();
        Set<String> names = new HashSet<>();
        for (int i = 0; i < n; i++) names.add("b" + i);
        for (int i = 0; i < n; i++) {
            Bot b = new Bot(); b.name = "b" + i; b.id = 2000 + i;
            b.w = new World();
            b.w.setName(hu, "Human");
            for (int j = 0; j < n; j++) b.w.setName(UUID.nameUUIDFromBytes(("b" + j).getBytes()), "b" + j);
            b.body = new Body((id, c) -> { Wire.Out o = new Wire.Out(); c.accept(o); b.out.add(new Pkt(id, o.bytes())); }, new Random(seed * 31 + i));
            b.body.entityId = b.id;
            double ang = 2 * Math.PI * i / n + 0.3;
            double r = n == 1 ? 12 : 14 + (i % 3) * 3;
            b.body.serverPosition(Math.cos(ang) * r, 64, Math.sin(ang) * r, 0, 0, 0, 0, 0);
            b.brain = new Brain(b.body, b.w, new Random(seed * 17 + i), Tier.parse(botTier), Mode.parse(System.getProperty("mode", "SWORD")), "A", names, b.name);
            bots.add(b);
        }
        int botDeaths = 0;
        for (tick = 1; tick <= maxTicks; tick++) {
            // ---- entity updates visible to every bot
            for (Bot b : bots) {
                Shim.now(b.w, tick);
                World.Ent he = b.w.ents.get(HUMAN_ID);
                if (he == null) { Shim.add(b.w, HUMAN_ID, hu, h.x, h.y, h.z, tick); }
                else Shim.move(he, h.x, h.y, h.z, tick);
                for (Bot o : bots) {
                    if (o == b || !o.alive) continue;
                    World.Ent oe = b.w.ents.get(o.id);
                    UUID ou = UUID.nameUUIDFromBytes(o.name.getBytes());
                    if (oe == null) { Shim.add(b.w, o.id, ou, o.body.x, o.body.y, o.body.z, tick); }
                    else Shim.move(oe, o.body.x, o.body.y, o.body.z, tick);
                }
            }
            // ---- human
            Bot tgt = null; double bd = 1e9;
            for (Bot b : bots) if (b.alive) { double d = Math.hypot(b.body.x - h.x, b.body.z - h.z); if (d < bd) { bd = d; tgt = b; } }
            if (tgt == null && n == 1) break;
            if (h.hurt > 0) h.hurt--;
            if (h.eatCd > 0) h.eatCd--;
            double fwd = 0, strafe = 0; double yaw = 0; boolean jump = false;
            if (tgt != null) {
                yaw = Body.yawTo(tgt.body.x - h.x, tgt.body.z - h.z);
                if (h.react > 0) h.react--;
                else if (h.eat > 0) {
                    h.eat--; fwd = -0.3;
                    if (h.eat == 0) h.hp = Math.min(24, h.hp + 8);
                } else {
                    if (h.hp <= sk.healAt && h.apples > 0 && h.eatCd == 0) { h.eat = 32; h.apples--; h.eatCd = 40; }
                    else {
                        if (--h.strafeT <= 0) { h.strafeT = sk.strafe + rnd.nextInt(8); if (rnd.nextBoolean()) h.strafeDir = -h.strafeDir; }
                        h.sprint = bd > 2.9;
                        if (bd > 2.9) fwd = 1; else if (bd < 1.8) fwd = -0.4; else { fwd = 0.3; strafe = h.strafeDir; }
                        double charge = Math.min(1, (tick - h.lastAtk) / 12.5);
                        if (boxDist(h.x, h.y + 1.62, h.z, tgt.body.x, tgt.body.y, tgt.body.z) <= 3.0 && charge >= h.want) {
                            hSwing++; h.lastAtk = tick; h.want = rnd.nextDouble() < sk.full ? 1.0 : 0.55;
                            if (rnd.nextDouble() >= sk.miss) {
                                double d = BASE_DMG * (0.2 + 0.8 * charge * charge);
                                if (charge > 0.9 && rnd.nextDouble() < sk.crit) d *= 1.5;
                                int[] hu2 = {tgt.hurt}; float[] ld = {tgt.lastDmg};
                                float ap = applyHit(hu2, ld, (float) d); if (ap > 0) { hLanded++; hCharge += charge; } tgt.hurt = hu2[0]; tgt.lastDmg = ld[0];
                                if (ap > 0) {
                                    tgt.body.health -= ap;
                                    double dx = tgt.body.x - h.x, dz = tgt.body.z - h.z, l = Math.max(0.01, Math.hypot(dx, dz));
                                    double kb = h.sprint ? 0.9 : 0.4;
                                    tgt.body.serverMotion(tgt.body.vx * 0.5 + dx / l * kb, Math.min(0.4, tgt.body.vy * 0.5 + 0.4), tgt.body.vz * 0.5 + dz / l * kb);
                                }
                            }
                        }
                        jump = h.ground && rnd.nextInt(30) == 0;
                    }
                }
            }
            // human physics (same constants as Body)
            double yr = Math.toRadians(yaw), f = h.ground ? 0.546 : 0.91;
            if (h.ground && jump) h.vy = 0.42;
            double in = Math.hypot(fwd, strafe);
            if (in > 0.01) {
                double acc = h.ground ? (h.sprint ? 0.13 : 0.1) : (h.sprint ? 0.026 : 0.02), s = 0.98 / Math.max(1, in);
                h.vx += (strafe * s * Math.cos(yr) - fwd * s * Math.sin(yr)) * acc;
                h.vz += (fwd * s * Math.cos(yr) + strafe * s * Math.sin(yr)) * acc;
            }
            h.x += h.vx; h.y += h.vy; h.z += h.vz; h.vy = (h.vy - 0.08) * 0.98; h.vx *= f; h.vz *= f;
            if (h.y <= 64) { h.y = 64; if (h.vy < 0) h.vy = 0; h.ground = true; } else h.ground = false;
            if (h.hp <= 0) { return new double[]{1, tick, botDeaths}; }

            // ---- bots
            for (Bot b : bots) {
                if (b.hurt > 0) b.hurt--;
                if (!b.alive) {
                    if (n > 1 && tick >= b.respawnAt) {
                        b.alive = true; b.body.health = 20; b.body.dead = false; b.hurt = 0; b.apples = 6; b.eat = 0;
                        double ang = rnd.nextDouble() * 6.28;
                        b.body.serverPosition(Math.cos(ang) * 16, 64, Math.sin(ang) * 16, 0, 0, 0, 0, 0);
                        b.brain.onRespawn();
                        b.w.ents.clear();
                    }
                    continue;
                }
                if (b.body.health <= 0) { b.alive = false; b.body.dead = true; b.deaths++; botDeaths++; b.respawnAt = tick + 50 + rnd.nextInt(30); continue; }
                b.out.clear();
                b.brain.tick(); b.body.step(); b.body.flush();
                if (n == 1) { double dd = boxDist(b.body.x, b.body.y + 1.62, b.body.z, h.x, h.y, h.z); tTot++; if (dd <= 2.95) tReach++; else if (dd < 4.5) tClose++; else tFar++; states.merge(b.brain.state, 1, Integer::sum); }
                for (Pkt p : b.out) {
                    Wire.In in2 = new Wire.In(p.d);
                    if (p.id == Ids.SB_SET_CARRIED) { int s = in2.i16(); if (s != b.sel) b.eat = 0; b.sel = s; }
                    else if (p.id == Ids.SB_USE_ITEM && b.sel == 2 && b.eat == 0 && b.apples > 0) { b.eat = 33; }
                    else if (p.id == Ids.SB_INTERACT) {
                        int target = in2.varInt(); int type = in2.varInt();
                        if (type != 1 || target != HUMAN_ID) continue;
                        bSwing++;
                        if (boxDist(b.body.x, b.body.y + 1.62, b.body.z, h.x, h.y, h.z) > 3.0) { bReach++; b.lastAtk = tick; continue; }
                        double charge = Math.min(1, (tick - b.lastAtk) / 12.5);
                        b.lastAtk = tick;
                        double d = BASE_DMG * (0.2 + 0.8 * charge * charge);
                        if (charge > 0.9 && !b.body.onGround && b.body.vy < 0 && !b.body.sprinting) { d *= 1.5; bCrit++; }
                        int[] hh = {h.hurt}; float[] ld = {h.lastDmg};
                        float ap = applyHit(hh, ld, (float) d); h.hurt = hh[0]; h.lastDmg = ld[0];
                        if (ap == 0) bIframe++; else { bLanded++; bCharge += charge; }
                        if (ap > 0) {
                            h.hp -= ap;
                            double dx = h.x - b.body.x, dz = h.z - b.body.z, l = Math.max(0.01, Math.hypot(dx, dz));
                            double kb = b.body.sprinting && charge > 0.9 ? 0.9 : 0.4;
                            h.vx = h.vx * 0.5 + dx / l * kb; h.vz = h.vz * 0.5 + dz / l * kb; h.vy = Math.min(0.4, h.vy * 0.5 + 0.4); h.ground = false;
                        }
                    }
                }
                if (b.eat > 0 && --b.eat == 0) { b.apples--; b.body.health = Math.min(24, b.body.health + 8); }
            }
            if (n > 1) {
                boolean any = false; for (Bot b : bots) if (b.alive) any = true;
                if (!any && tick > 1) { /* all dead, they respawn */ }
            } else if (!bots.get(0).alive) return new double[]{0, tick, botDeaths};
        }
        return new double[]{0, maxTicks, botDeaths};
    }

    public static void main(String[] a) {
        boolean old = a[0].equals("old");
        Shim.knobs();
        String tier = a[1], skillName = a[2];
        int n = Integer.parseInt(a[3]), runs = Integer.parseInt(a[4]);
        int wins = 0; double t = 0, lost = 0;
        for (int i = 0; i < runs; i++) {
            double[] r = run(tier, skillName, n, old, n == 1 ? 1500 : 2400, 1000 + i);
            if (r[0] > 0) { wins++; t += r[1]; }
            lost += r[2];
        }
        System.out.printf("%-4s %s x%-2d vs %-3s: bot wins %3d/%d (%.0f%%)  avg kill %.0f ticks  avg bot deaths %.1f%n",
                old ? "OLD" : "NEW", tier, n, skillName, wins, runs, 100.0 * wins / runs, wins > 0 ? t / wins : 0, lost / runs);
        if (a.length > 5) System.out.printf("      bot time: in reach %.0f%%  3-4.5 blocks %.0f%%  farther %.0f%%  states %s%n", 100.0 * tReach / Math.max(1, tTot), 100.0 * tClose / Math.max(1, tTot), 100.0 * tFar / Math.max(1, tTot), states);
        if (a.length > 5) System.out.printf("      bot: swings %d  landed %d (avg charge %.2f)  into-iframes %d  out-of-reach %d  crits %d | human: swings %d landed %d (avg charge %.2f)%n",
                bSwing, bLanded, bLanded == 0 ? 0 : bCharge / bLanded, bIframe, bReach, bCrit, hSwing, hLanded, hLanded == 0 ? 0 : hCharge / hLanded);
    }
}
