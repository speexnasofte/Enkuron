import dev.duelforge.ai.*;
import java.util.UUID;
public class Shim {
    static World.Ent add(World w, int id, UUID u, double x, double y, double z, int t) { return w.add(id, u, 128, x, y, z, t); }
    static void move(World.Ent e, double x, double y, double z, int t) { e.moveTo(x, y, z, t); }
    static void now(World w, int t) { w.now = t; }
    static void clock(java.util.function.IntSupplier c) { Swarm.clock = c; Swarm.reset(); }
    static void knobs() {
        if (System.getProperty("safe") != null) Opts.healSafeDist = Double.parseDouble(System.getProperty("safe"));
        if (System.getProperty("mask") != null) Opts.comboMask = Integer.parseInt(System.getProperty("mask"));
        if (System.getProperty("chain") != null) Opts.comboChain = Boolean.parseBoolean(System.getProperty("chain"));
        if (System.getProperty("combo") != null) Opts.combo = Boolean.parseBoolean(System.getProperty("combo"));
        if (System.getProperty("panic") != null) Opts.healPanic = Double.parseDouble(System.getProperty("panic"));
    }
}
