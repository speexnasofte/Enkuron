# Port status: pvp-bot-fabric (Stepan1411, Unlicense) -> dev.duelforge.stepan

NOTE: nothing here has been compiled yet (no JDK / Gradle access where it was written). Build once and report errors.

Stage 1 (done): BotSettings, BotFaction, BotNameGenerator, CustomCommand, BotSettingsReader/Updater, StatsConfig,
LocalStats*, WorldConfigHelper, InventoryHelper, special_names.json.

Stage 2 (done, partial):
- BotManager (spawn/remove/restore via herobot `playerspawn` / `player` commands). Calls into combat/utils/navigation
  state were replaced by `BotManager.addRemoveListener(...)`; the ported modules register themselves there.
- HerobotMovement (herobot bridge, command based), StatsReporter (kept, but NOT started: no telemetry),
  ServerConfigHandlerMixin (only when herobot is installed), ProfileLagFix (no-op, see comment),
  StepanBootstrap (lifecycle + reduced ticker, called from DuelforgeMod).
- Menu: third tab "Степан" in the hub switch (client/StepanScreen, /df stepan). Stepan's repo contains no GUI source,
  so this screen is written from scratch over BotSettings.

Stage 3 (done, NOT compiled): BotUtils, BotEquipment, EatingMovementFix, BotTicker, BotCombat, BotCrystalPvp, BotAnchorPvp, BotNavigation, BotPath (scripted Yarn->Mojang translation, see below)
Stage 4 (done, NOT compiled): BotKits (ItemStack codec -> SNBT in kits.json, same calls as Duelforge KitCapture), BotPathVisualizer (ServerLevel#sendParticles, DustParticleOptions(int,float)).
  Also fixed: StepanBootstrap now calls BotKits.init + BotPath.init like the original SERVER_STARTED sequence (BotPath.init was missing before).
Stage 5 (done, NOT compiled): BotCommand (/pvpbot ..., Brigadier, Mojang names), network payloads (BotPayloads, SettingsPayloads; ids moved to the
  "duelforge" namespace so they cannot clash with Stepan's own mod), registered in StepanBootstrap together with the command callback.
  Stubs filled: ProfileLagFix (NameAndId + MinecraftServer#services(); optional - delete the body if the build complains), BotManager stub removed (stage 2),
  BotTicker path visualizer (stage 4). Intentionally NOT ported: DamageTrackingMixin (only fed anonymous stats), ServerPlayerEntityMixin (empty).
  The settings GUI of Stepan's separate mod is replaced by the Prism GUI (UnifiedBridge).

## Stage 3 translation notes (verify on first build)
- Mappings applied by script: Yarn names -> Mojang names (ServerPlayerEntity->ServerPlayer, getStack->getItem, setVelocity->setDeltaMovement,
  swingHand->swing, setCurrentHand->startUsingItem, getHungerManager->getFoodData, Box->AABB, ...).
- Also unverified in stage 5: ServerPlayer#teleportTo(level,x,y,z,Set,yaw,pitch,boolean), ByteBufCodecs.list(), StreamCodec.unit, NameAndId, MinecraftServer#services().
- Names I could not verify offline (most likely compile errors if any): MobEffects.STRENGTH / SPEED / FIRE_RESISTANCE,
  RespawnAnchorBlock.CHARGE, Holder#getRegisteredName, PotionContents#getAllEffects, ItemEnchantments#keySet,
  LivingEntity#getLastHurtByMob, Item#components(), Inventory#getSelectedSlot/setSelectedSlot.
- BotTicker: StatsReporter heartbeat removed (no telemetry); BotPathVisualizer.update call commented out until stage 5.

## GUI (Expensive style on the Prism canvas) - one merged GUI
- The menu now looks like the "Expensive" client: one floating 920x550 window (drawn as 460x275 GUI units, scaled down automatically on small screens),
  header with brand + search + theme + close, category chips, masonry grid of module cards that always show their settings
  (star = pin to top, header click = toggle, switch, checkboxes, sliders, dropdown chips, colour picker, key chips, lists).
  Palette = the tone tables of the original dark theme (accent 6E74E3, frame 151617, surface 0F1011); the light theme is derived.
- `dev.duelforge.client.expa`: `ExpaGui` (the view, no Minecraft imports), `ExpaPalette`, `ExpaScreen` (the Minecraft Screen, input forwarding).
  Only the look was ported. The original draws with its own OpenGL shaders/MSDF fonts for 1.21.4 (Yarn), which cannot run on 1.21.11 as is,
  so no code, textures or fonts were copied: text uses the vanilla font, icons are the Prism vector fallbacks.
- Data side is unchanged: `dev.duelforge.client.UnifiedBridge` (implements `ClickGuiBridge`) feeds the GUI with EVERYTHING: Lab (launch, bots, NPC, duel, kits, combos, options),
  Controller (control, kits, bot HUD) and the ported PVP Bot (combat, utilities, realism). Buttons are switches that spring back.
- `top.fpsmaster.prism` stays as the 2D toolkit (Canvas / UiFrame / TextBox / Scroll / input). The old Prism ClickGUI (`SharedClickGui`) and `PrismScreen` were removed;
  the other `Shared*` screens in that package (music, cosmetics, ...) are not used and were left untouched.
- `dev.duelforge.client.prism`: DuelforgeCanvas / DuelforgeHost / DuelforgeFont. Hub.open(...), the open-menu key and
  /df, /df lab|controller|stepan|gui all open this one screen (different start section). The old BotScreen/ControllerScreen/StepanScreen
  are no longer opened (files kept).
- Headless preview without Minecraft: `sim/ExpaPreview.java` renders the GUI with Java2D into PNGs (see the header of the file for the javac line).
- Not compiled against Minecraft. `ExpaScreen` is `PrismScreen` with the view swapped, so it uses the same Minecraft calls as before. Likely first errors:
  Screen input signatures (MouseButtonEvent/KeyEvent/CharacterEvent, 1.21.9+), KeyboardHandler#getClipboard/setClipboard.
- Not in the new GUI yet: bot detail card (3D model, inventory) of the old Lab screen.
