package com.pvpbot;

import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import com.pvpbot.StrafeAI;
import com.pvpbot.BotKit;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.awt.Color;
import java.util.*;

/**
 * PVPBotScreen v5.0 — МАКСИМАЛЬНАЯ ВЕРСИЯ
 *
 * Улучшения над v4.0:
 *  - RenderUtil (скруглённые прямоугольники, glow, тени)
 *  - AnimationUtil (плавные hover/enable анимации на каждой карточке)
 *  - Pulse-анимация на активных кнопках
 *  - Gradient шапка и sidebar
 *  - Улучшенные карточки: accent-полоска, glow при enabled
 *  - Иконки модов через Unicode/Emoji
 *  - Drag окна мышкой (перемещение)
 *  - Поиск с живой анимацией и иконкой лупы
 *  - Scrollbar с плавной анимацией
 *  - Notification badge на вкладке STATS
 *  - Полный settings: слайдеры кликабельны
 *  - Difficulty: анимированный выбор
 *  - Stats: K/D граф + сессионный таймер
 *  - Tooltip с задержкой
 *  - Нижний статусбар с цветом по статусу
 *  - Все параметры конфига привязаны
 */
public class PVPBotScreen extends Screen {

    // ═══════════════════════════════════════════════════════════════
    //  ПАЛИТРА
    // ═══════════════════════════════════════════════════════════════
    private static final int BG_MAIN      = 0xFF0A0D12;
    private static final int BG_WIN       = 0xFF111520;
    private static final int BG_LEFT      = 0xFF0B0E16;
    private static final int BG_CARD      = 0xFF161B28;
    private static final int BG_CARD_HOV  = 0xFF1C2235;
    private static final int BG_CARD_EN   = 0xFF0D1A10;
    private static final int BG_HEADER    = 0xFF080C14;
    private static final int BG_ENABLED   = 0xFF0C2012;
    private static final int BG_DISABLED  = 0xFF200C0C;
    private static final int BG_OPT       = 0xFF141824;
    private static final int BG_GEAR      = 0xFF10141F;
    private static final int BG_SEARCH    = 0xFF0C1018;
    private static final int BG_PROF      = 0xFF0F1320;
    private static final int BG_PROF_ACT  = 0xFF172030;
    private static final int BG_SUB_ACT   = 0xFF182440;
    private static final int BG_TOOLTIP   = 0xEE08090F;

    private static final int BORDER_CARD  = 0xFF1A2035;
    private static final int BORDER_SEP   = 0xFF171D2E;
    private static final int BORDER_SRCH  = 0xFF1E2840;

    private static final int ACCENT_BLUE  = 0xFF3B82F6;
    private static final int ACCENT_GREEN = 0xFF22C55E;
    private static final int ACCENT_RED   = 0xFFEF4444;
    private static final int ACCENT_PURP  = 0xFFA855F7;
    private static final int ACCENT_YEL   = 0xFFFACC15;
    private static final int ACCENT_CYAN  = 0xFF06B6D4;
    private static final int ACCENT_ORG   = 0xFFFB923C;
    private static final int ACCENT_GRAY = 0xFF64748B;

    private static final int TEXT_WHITE   = 0xFFFFFFFF;
    private static final int TEXT_BRIGHT  = 0xFFE2E8F0;
    private static final int TEXT_GRAY    = 0xFF7A8BB0;
    private static final int TEXT_DARK    = 0xFF303A55;
    private static final int TEXT_GREEN   = 0xFF22C55E;
    private static final int TEXT_RED     = 0xFFEF4444;
    private static final int TEXT_BLUE    = 0xFF60A5FA;

    private static final int NEW_BG       = 0xFF1E3A8A;
    private static final int NEW_FG       = 0xFF93C5FD;

    // ═══════════════════════════════════════════════════════════════
    //  РАЗМЕРЫ
    // ═══════════════════════════════════════════════════════════════
    private static final int WIN_W    = 680;
    private static final int WIN_H    = 430;
    private static final int HEADER_H = 30;
    private static final int LEFT_W   = 136;
    private static final int SUB_H    = 28;
    private static final int FOOT_H   = 20;
    private static final int CARD_W   = 150;
    private static final int CARD_H   = 84;
    private static final int CARD_GAP = 6;
    private static final int COLS     = 3;
    private static final int PROF_H   = 46;
    private static final int PROF_GAP = 3;

    // ═══════════════════════════════════════════════════════════════
    //  ENUMS
    // ═══════════════════════════════════════════════════════════════
    private enum ModCat {
        ALL("ALL",""), NEW("NEW","★"), HUD("HUD","📊"),
        SERVER("SERVER","🌐"), MECHANIC("MECHANIC","⚙"),
        COMBAT("COMBAT","⚔"), VISUAL("VISUAL","👁"),
        UTILITY("UTILITY","🔧");
        final String label, icon;
        ModCat(String l, String i){ label=l; icon=i; }
    }

    private enum Tab {
        MODS("MODS"), KITS("KITS"), SETTINGS("SETTINGS"), DIFFICULTY("DIFFICULTY"),
        PROFILES("PROFILES"), STATS("STATS"), SQUAD("SQUAD"),
        ROLES("РОЛИ"), HISTORY("ИСТОРИЯ");
        final String label;
        Tab(String l){ label=l; }
    }

    // ═══════════════════════════════════════════════════════════════
    //  ДАННЫЕ МОДУЛЕЙ  { name, configKey, cat, isNew, desc, icon, accentColor }
    // ═══════════════════════════════════════════════════════════════
    private static final Object[][] MODS = {
        {"Auto Attack",    "autoAttack",               ModCat.COMBAT,   false, "Атакует ближайшего врага автоматически",   "⚔",  ACCENT_RED},
        {"W-Tap",          "wTapEnabled",              ModCat.COMBAT,   false, "Зажимает W для сброса кулдауна атаки",     "⚡", ACCENT_YEL},
        {"S-Tap",          "sTapEnabled",              ModCat.COMBAT,   false, "Зажимает S после удара для -KB",           "↩",  ACCENT_YEL},
        {"Auto Crystal",   "autoCrystal",              ModCat.COMBAT,   true,  "Расставляет и взрывает End Crystal",       "💎", ACCENT_CYAN},
        {"Auto Bow",       "autoBowEnabled",           ModCat.COMBAT,   false, "Стреляет из лука на дальней дистанции",    "🏹", ACCENT_GREEN},
        {"Kite",           "kiteEnabled",              ModCat.COMBAT,   false, "Держит дистанцию и стреляет из лука",      "🎈", ACCENT_BLUE},
        {"Auto Dodge",     "autoDodge",                ModCat.COMBAT,   false, "Уклоняется от атак в ближнем бою",         "🛡", ACCENT_BLUE},
        {"Fake Attack",    "fakeAttackEnabled",        ModCat.COMBAT,   true,  "Ложные замахи для дезориентации врага",    "🎭", ACCENT_PURP},
        {"Pattern AI",     "patternAIEnabled",         ModCat.SERVER,   true,  "ИИ меняет паттерны атаки динамически",    "🧠", ACCENT_PURP},
        {"Anti Pattern",   "antiPatternEnabled",       ModCat.SERVER,   true,  "Контрит паттерны атаки противника",        "🔄", ACCENT_CYAN},
        {"Adaptive CD",    "adaptiveCooldownEnabled",  ModCat.SERVER,   true,  "Адаптивный кулдаун под пинг сервера",      "⏱", ACCENT_BLUE},
        {"Ping Display",   "statsEnabled",             ModCat.SERVER,   false, "Показывает пинг в HUD",                    "📡", ACCENT_GREEN},
        {"Show HUD",       "showHud",                  ModCat.HUD,      false, "Отображает HUD с информацией о боте",      "📊", ACCENT_BLUE},
        {"Show DPS",       "showDps",                  ModCat.HUD,      false, "Показывает DPS урона на экране",           "💥", ACCENT_RED},
        {"Bot Stats",      "statsEnabled",             ModCat.HUD,      false, "Статистика K/D и урона в бою",             "📈", ACCENT_GREEN},
        {"Radar",          "radarEnabled",             ModCat.HUD,      false, "Мини-карта с ближайшими игроками",         "📡", ACCENT_CYAN},
        {"Auto Sprint",    "autoSprint",               ModCat.MECHANIC, false, "Постоянный спринт без остановки",          "🏃", ACCENT_GREEN},
        {"Toggle Sneak",   "toggleSneak",              ModCat.MECHANIC, false, "Шифт для уклонения от крит-прыжков",       "🕵", ACCENT_GRAY},
        {"Auto Heal",      "autoHeal",                 ModCat.MECHANIC, false, "Пьёт зелья лечения при низком HP",         "❤",  ACCENT_RED},
        {"Auto Gap",       "autoGapEnabled",           ModCat.MECHANIC, false, "Ест золотые яблоки при критическом HP",    "🍎", ACCENT_YEL},
        {"Auto Armor",     "autoArmor",                ModCat.MECHANIC, false, "Надевает лучшую броню автоматически",      "🦺", ACCENT_BLUE},
        {"Auto Totem",     "autoTotem",                ModCat.MECHANIC, false, "Перекладывает тотем в оффхенд авто",       "🗿", ACCENT_YEL},
        {"Auto Log",       "autoLogEnabled",           ModCat.UTILITY,  false, "Выходит из игры при критическом HP",       "🚪", ACCENT_RED},
        {"Auto Pearl",     "autoPearlEnabled",         ModCat.MECHANIC, true,  "Бросает Эндер-жемчуг для отступления",    "🔮", ACCENT_PURP},
        {"Auto Respawn",   "autoRespawn",              ModCat.MECHANIC, false, "Авто-ответ при смерти/выходе",             "⏺",  ACCENT_GREEN},
        {"ESP",            "espEnabled",               ModCat.VISUAL,   false, "Подсвечивает игроков сквозь стены",        "👁",  ACCENT_CYAN},
        {"Tracers",        "tracersEnabled",           ModCat.VISUAL,   false, "Рисует линии к ближайшим игрокам",         "📐", ACCENT_BLUE},
        {"Anti KB",        "antiKnockbackEnabled",     ModCat.MECHANIC, false, "Снижает отброс от ударов",                 "🧲", ACCENT_YEL},
        {"Notifications",  "notificationsEnabled",     ModCat.UTILITY,  false, "Уведомления о событиях в чат",             "🔔", ACCENT_YEL},
        {"Training Mode",  "trainingMode",             ModCat.UTILITY,  false, "Щадящий режим для обучения новичков",      "🎓", ACCENT_GREEN},
        {"Hunt",           "huntEnabled",              ModCat.UTILITY,  true,  "Ищет и преследует врагов вдали",           "🎯", ACCENT_RED},
        {"Bunker",         "bunkerEnabled",            ModCat.MECHANIC, false, "Прячется в укрытие при низком HP",         "🏰", ACCENT_BLUE},
        {"Standby",        "standbyMode",              ModCat.UTILITY,  true,  "Боты ждут команды /bot attack",            "⏸",  ACCENT_GRAY},
        {"Auto Eat",       "autoEat",                  ModCat.MECHANIC, false, "Ест еду при низком голоде авто",           "🍖", ACCENT_ORG},
        {"Obsidian Place", "autoCrystal",              ModCat.COMBAT,   true,  "Кладёт обсидиан под кристаллы",            "🪨", ACCENT_GRAY},
        {"Whitelist",      "whitelistEnabled",         ModCat.UTILITY,  false, "Атакует только игроков из списка",         "📋", ACCENT_BLUE},
        {"Auto Kit",       "autoKitSelect",            ModCat.MECHANIC, true,  "Авто-выбор кита под броню врага",          "🎒", ACCENT_PURP},
    };


    // ═══════════════════════════════════════════════════════════════
    //  ПРОФИЛИ
    // ═══════════════════════════════════════════════════════════════
    private static class Prof {
        String name, sub; int color; boolean active;
        Prof(String n, String s, int c, boolean a){ name=n; sub=s; color=c; active=a; }
    }
    private final List<Prof> profiles = new ArrayList<>();

    // ═══════════════════════════════════════════════════════════════
    //  СОСТОЯНИЕ
    // ═══════════════════════════════════════════════════════════════
    private int winX, winY;
    private Tab tab       = Tab.MODS;
    private ModCat cat    = ModCat.ALL;
    private int scrollY   = 0;
    private int maxScrollY = 0; // для вкладки KITS
    private int targetScrollY = 0;
    private String search = "";
    private boolean searchFocus = false;
    private String optMod = null;
    private int optPanX, optPanY;
    private String tooltip     = null;
    private int ttX, ttY, ttTimer = 0;
    private int dragSlider = -1; // index слайдера, который тянем
    private final Map<String,Boolean> mstate = new LinkedHashMap<>();
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private long sessionStart = System.currentTimeMillis();

    // ── SQUAD TAB состояние ───────────────────────────────────────
    /** Выбранный тип отряда (индекс в SQUAD_PRESETS). */
    private int squadSelectedPreset = -1;
    /** Количество бойцов в отряде (слайдер 1–30). */
    private int squadCount = 10;
    /** true если тянем слайдер количества. */
    private boolean draggingSquadSlider = false;

    // Drag окна
    private boolean dragging = false;
    private int dragOffX, dragOffY;

    // ═══════════════════════════════════════════════════════════════
    //  КОНСТРУКТОР
    // ═══════════════════════════════════════════════════════════════
    public PVPBotScreen(Screen parent) {
        super(Component.literal("PVPBot v5.0"));
        if (profiles.isEmpty()) {
            profiles.add(new Prof("Testing",          "Latest PvP",       0xFF3B82F6, true));
            profiles.add(new Prof("Main",             "Latest PvP",       0xFF22C55E, false));
            profiles.add(new Prof("Crystal Fighter",  "Crystal EXPERT",   0xFFA855F7, false));
            profiles.add(new Prof("UHC Preset",       "UHC HARD",         0xFFEF4444, false));
            profiles.add(new Prof("Training",         "Beginner EASY",    0xFF06B6D4, false));
        }
        reloadModState();
    }

    private void reloadModState() {
        for (Object[] m : MODS) {
            String k = (String) m[1];
            mstate.put(k, getB(k));
        }
        // fix: antiKnockbackEnabled не в конфиге напрямую
        mstate.put("antiKnockbackEnabled", false);
    }

    // ═══════════════════════════════════════════════════════════════
    //  INIT
    // ═══════════════════════════════════════════════════════════════
    @Override
    protected void init() {
        winX = (width  - WIN_W) / 2;
        winY = (height - WIN_H) / 2;
        rebuild();
    }

    private void rebuild() {
        clearWidgets();
        if (tab == Tab.MODS)        buildModsWidgets();
        else if (tab == Tab.SETTINGS)    buildSettingsWidgets();
        else if (tab == Tab.DIFFICULTY)  buildDiffWidgets();
        else if (tab == Tab.PROFILES)    buildProfilesWidgets();
        else if (tab == Tab.STATS)       buildStatsWidgets();
        else if (tab == Tab.SQUAD)       buildSquadWidgets();
        else if (tab == Tab.ROLES)       buildRolesWidgets();
        else if (tab == Tab.HISTORY)     {} // no widgets needed
        buildProfileWidgets();
    }

    // ─────────────────────────────────────────────────────────────
    //  Sidebar widget buttons (profiles)
    // ─────────────────────────────────────────────────────────────
    private void buildProfileWidgets() {
        // Клики по профилям и кнопкам sidebar обрабатываются в mouseClicked().
        // Рендер делается в renderLeft() — не добавляем Button-виджеты,
        // чтобы избежать двойного рендера текста поверх кастомных карточек.
    }

    // ─────────────────────────────────────────────────────────────
    //  MODS widgets
    // ─────────────────────────────────────────────────────────────
    private void buildModsWidgets() {
        // close opt panel — невидимая кнопка только для закрытия панели опций
        if (optMod != null) {
            addRenderableWidget(Button.builder(Component.literal(""), b -> { optMod = null; rebuild(); })
                .pos(optPanX + 150, optPanY + 4).size(12, 12).build());
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  SETTINGS widgets
    // ─────────────────────────────────────────────────────────────
    private void buildSettingsWidgets() {
        // Все клики обрабатываются в handleSettingsClick() и mouseClicked().
        // Рендер полностью кастомный (renderSettings), виджеты не нужны.
    }

    private void addTogBtn(int x, int y, String label, boolean on, Runnable action) {
        // no-op: тоглы рендерятся вручную, клики через handleSettingsClick
    }
    private void addPM(int x, int y, String label, Runnable dec, Runnable inc) {
        // no-op: кнопки +/- рендерятся вручную в renderNumRow
    }

    // ─────────────────────────────────────────────────────────────
    //  DIFFICULTY widgets
    // ─────────────────────────────────────────────────────────────
    private void buildDiffWidgets() {
        // Клики обрабатываются в handleDiffTabClick(). Рендер кастомный.
    }

    // ─────────────────────────────────────────────────────────────
    //  PROFILES widgets
    // ─────────────────────────────────────────────────────────────
    private void buildProfilesWidgets() {
        // Клики обрабатываются в handleProfPresetsClick(). Рендер кастомный.
    }

    private void buildStatsWidgets() {
        // Кнопки Reset/Kit Stats обрабатываются в mouseClicked через координаты.
    }

    // ═══════════════════════════════════════════════════════════════
    //  RENDER  (главный)
    // ═══════════════════════════════════════════════════════════════
    @Override
    public void render(GuiGraphicsExtractor g, int mx, int my, float pt) {
        tooltip = null;
        // плавный скролл
        scrollY += (targetScrollY - scrollY) * 0.18f;
        // затемнённый фон
        g.fillGradient(0, 0, width, height, 0xCC000000, 0xDD000510);

        // тень окна
        for (int i = 8; i > 0; i--) {
            int a = (int)(40 * (1f - (float)i / 8));
            g.fill(winX - i, winY - i, winX + WIN_W + i, winY + WIN_H + i, (a << 24) | 0x000000);
        }

        // Основное окно
        RenderUtil.rounded(g, winX, winY, WIN_W, WIN_H, 8, new Color(0x111520));
        // RGB animated border
        int borderRgb = AnimationUtil.rgbCycleFull(0.2f, 0.6f, 0.5f);
        RenderUtil.outline(g, winX, winY, WIN_W, WIN_H, 8, new Color(borderRgb));

        renderHeader(g, mx, my);
        renderLeft(g, mx, my);
        g.fill(winX + LEFT_W, winY + HEADER_H, winX + LEFT_W + 1, winY + WIN_H, 0xFF0A0D18);

        switch (tab) {
            case MODS       -> renderMods(g, mx, my);
            case KITS       -> renderKitsTab(g, mx, my);
            case SETTINGS   -> renderSettings(g, mx, my);
            case DIFFICULTY -> renderDifficulty(g, mx, my);
            case PROFILES   -> renderProfilesTab(g, mx, my);
            case STATS      -> renderStats(g, mx, my);
            case SQUAD      -> renderSquadTab(g, mx, my);
            case ROLES      -> renderRolesTab(g, mx, my);
            case HISTORY    -> renderHistoryTab(g, mx, my);
            default -> {}
        }

        renderFooter(g, mx, my);
        super.render(g, mx, my, pt);
        if (tooltip != null) renderTooltip2(g, tooltip, ttX, ttY);
    }

    // ═══════════════════════════════════════════════════════════════
    //  HEADER
    // ═══════════════════════════════════════════════════════════════
    private void renderHeader(GuiGraphicsExtractor g, int mx, int my) {
        // gradient header
        g.fillGradient(winX, winY, winX + WIN_W, winY + HEADER_H, 0xFF0C1220, 0xFF080C16);
        // RGB animated top accent line
        int rgb1 = AnimationUtil.rgbCycle(0.3f);
        int rgb2 = AnimationUtil.rgbCycleOffset(0.3f, 0.33f);
        int rgb3 = AnimationUtil.rgbCycleOffset(0.3f, 0.66f);
        g.fillGradient(winX + 4, winY, winX + LEFT_W + (WIN_W - LEFT_W) / 2, winY + 1, rgb1, rgb2);
        g.fillGradient(winX + LEFT_W + (WIN_W - LEFT_W) / 2, winY, winX + WIN_W - 4, winY + 1, rgb2, rgb3);
        g.fill(winX, winY + HEADER_H - 1, winX + WIN_W, winY + HEADER_H, 0xFF0A0F1E);

        // Logo + name (иконка из текстуры)
        try {
            net.minecraft.resources.ResourceLocation logoRL =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("pvpbot", "textures/gui/logo.png");
            // В 1.21.4 blit сам привязывает текстуру, RenderSystem.setShaderTexture не нужен
            g.blit(net.minecraft.client.renderer.RenderType::guiTextured, logoRL, winX + 5, winY + 5, 0, 0, 20, 20, 20, 20);
        } catch (Exception ex) {
            // fallback если текстура не загружена
            fr(g, winX + 6, winY + 7, 16, 16, 0xFF1A2540);
            bd(g, winX + 6, winY + 7, 16, 16, 0xFF2A3F6F);
            g.drawString(font, "E", winX + 10, winY + 10, ACCENT_CYAN);
        }
        g.drawString(font, "PVPBot", winX + 28, winY + 10, TEXT_BRIGHT);
        // version badge
        fr(g, winX + 108, winY + 8, 28, 12, NEW_BG);
        g.drawString(font, "v5.0", winX + 110, winY + 10, NEW_FG);

        // Nav tabs
        int tx = winX + LEFT_W + 8;
        for (Tab t : Tab.values()) {
            boolean act = t == tab;
            String lbl = t.label;
            int tw = font.width(lbl) + 14;
            boolean hov = mx >= tx && mx < tx + tw && my >= winY + 2 && my < winY + HEADER_H;
            float anim = AnimationUtil.tick("tab_" + t.name(), (hov || act) ? 1f : 0f, 0.18f);

            if (act) {
                // RGB animated underline on active tab
                int tabRgb = AnimationUtil.rgbCycleOffset(0.25f, (float)t.ordinal() / Tab.values().length);
                int ua = (int)(255 * anim);
                g.fill(tx, winY + HEADER_H - 2, tx + tw, winY + HEADER_H, (ua << 24) | (tabRgb & 0x00FFFFFF));
                // subtle bg
                fr(g, tx, winY + 2, tw, HEADER_H - 3, 0x0A3B82F6);
                g.drawString(font, lbl, tx + 7, winY + 10, TEXT_WHITE);
            } else {
                int col = AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim);
                if (hov) fr(g, tx, winY + 4, tw, HEADER_H - 6, 0x12FFFFFF);
                g.drawString(font, lbl, tx + 7, winY + 10, col);
            }
            // STATS: красный badge если убийства > 0
            if (t == Tab.STATS && KillDeathTracker.kills > 0) {
                fr(g, tx + tw - 6, winY + 6, 6, 6, ACCENT_RED);
            }
            tx += tw + 2;
        }

        // Close button
        int cx = winX + WIN_W - 18, cy = winY + 8;
        boolean hX = mx >= cx && mx < cx + 14 && my >= cy && my < cy + 14;
        float xA = AnimationUtil.tick("close_btn", hX ? 1f : 0f, 0.2f);
        int xBg = AnimationUtil.lerpColor(0xFF0D1420, 0xFF7F1D1D, xA);
        fr(g, cx, cy, 14, 14, xBg);
        bd(g, cx, cy, 14, 14, hX ? ACCENT_RED : 0xFF1E2A40);
        g.drawString(font, "✕", cx + 3, cy + 3, hX ? TEXT_WHITE : TEXT_GRAY);
    }

    // ═══════════════════════════════════════════════════════════════
    //  LEFT SIDEBAR
    // ═══════════════════════════════════════════════════════════════
    private void renderLeft(GuiGraphicsExtractor g, int mx, int my) {
        // gradient sidebar
        g.fillGradient(winX, winY + HEADER_H, winX + LEFT_W, winY + WIN_H, 0xFF0B0E16, 0xFF0D1220);
        int px = winX + 4, py = winY + HEADER_H + 4;

        g.drawString(font, "PROFILES", px + 4, py, TEXT_DARK);
        py += 12;

        for (int i = 0; i < profiles.size(); i++) {
            Prof p = profiles.get(i);
            int gy = py + i * (PROF_H + PROF_GAP);
            boolean hov = mx >= px && mx < px + LEFT_W - 8 && my >= gy && my < gy + PROF_H;
            boolean act = p.active;
            float anim = AnimationUtil.tick("prof_" + i, (hov || act) ? 1f : 0f, 0.15f);

            // bg card
            int bg = AnimationUtil.lerpColor(BG_PROF, act ? BG_PROF_ACT : 0xFF111826, anim);
            RenderUtil.rounded(g, px, gy, LEFT_W - 8, PROF_H, 4, new Color(bg));
            // color stripe left
            int sa = act ? 255 : (int)(120 * anim);
            g.fill(px, gy, px + 3, gy + PROF_H, (sa << 24) | (p.color & 0x00FFFFFF));
            // active border
            if (act) RenderUtil.outline(g, px, gy, LEFT_W - 8, PROF_H, 4, new Color((p.color & 0x00FFFFFF) | 0x30000000));

            // icon circle
            fr(g, px + 6, gy + 8, 22, 22, (p.color & 0x00FFFFFF) | 0x20000000);
            g.drawString(font, "◈", px + 10, gy + 12, act ? p.color : AnimationUtil.lerpColor(TEXT_DARK, p.color, anim));

            g.drawString(font, p.name, px + 31, gy + 6, act ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim));
            g.drawString(font, p.sub,  px + 31, gy + 17, AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, anim));

            if (act) {
                // RGB pulsing active dot
                float pulse = AnimationUtil.pulse(4.0f);
                int pa = (int)(200 + 55 * pulse);
                int dotRgb = AnimationUtil.rgbCycleOffset(0.3f, (float)i / profiles.size());
                g.fill(px + LEFT_W - 18, gy + 18, px + LEFT_W - 12, gy + 24, (pa << 24) | (dotRgb & 0x00FFFFFF));
            }
            if (hov && !act) { tooltip = p.name + " — " + p.sub; ttX = mx; ttY = gy - 4; }
        }

        int bY = winY + WIN_H - FOOT_H - 48;
        // New profile & HUD layout buttons
        for (int i = 0; i < 2; i++) {
            String lbl = i == 0 ? "+ NEW PROFILE" : "❖ HUD LAYOUT";
            int ly = bY + i * 23;
            boolean hov = mx >= px && mx < px + LEFT_W - 8 && my >= ly && my < ly + 18;
            float anim = AnimationUtil.tick("sidebtn_" + i, hov ? 1f : 0f, 0.2f);
            int bg = AnimationUtil.lerpColor(BG_PROF, 0xFF1A2535, anim);
            RenderUtil.rounded(g, px, ly, LEFT_W - 8, 18, 4, new Color(bg));
            g.drawString(font, lbl, px + 6, ly + 5, AnimationUtil.lerpColor(TEXT_GRAY, ACCENT_BLUE, anim));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  MODS TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderMods(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        renderSubBar(g, mx, my, cx, cy, cw);
        renderGrid(g, mx, my, cx, cy + SUB_H, cw, ch - SUB_H);
        if (optMod != null) renderOptPanel(g, mx, my, optMod);
    }

    // ─────────────────────────────────────────────────────────────
    //  Sub-category bar
    // ─────────────────────────────────────────────────────────────
    private void renderSubBar(GuiGraphicsExtractor g, int mx, int my, int cx, int cy, int cw) {
        g.fillGradient(cx, cy, cx + cw, cy + SUB_H, 0xFF0C1018, 0xFF080C14);
        g.fill(cx, cy + SUB_H - 1, cx + cw, cy + SUB_H, 0xFF0A0D18);

        int tx = cx + 6;
        for (ModCat c : ModCat.values()) {
            boolean act = c == cat;
            String lbl = c.icon.isEmpty() ? c.label : c.icon + " " + c.label;
            int tw = font.width(lbl) + 12;
            boolean hov = mx >= tx && mx < tx + tw && my >= cy && my < cy + SUB_H;
            float anim = AnimationUtil.tick("cat_" + c.name(), (hov || act) ? 1f : 0f, 0.18f);

            if (act) {
                RenderUtil.rounded(g, tx, cy + 5, tw, SUB_H - 8, 4, new Color(BG_SUB_ACT));
                g.fill(tx + 2, cy + SUB_H - 3, tx + tw - 2, cy + SUB_H - 1, ACCENT_BLUE);
                g.drawString(font, lbl, tx + 6, cy + 9, ACCENT_BLUE);
            } else {
                if (hov) RenderUtil.rounded(g, tx, cy + 5, tw, SUB_H - 8, 4, new Color(0xFF131A28));
                g.drawString(font, lbl, tx + 6, cy + 9, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim));
            }

            // NEW badge
            if (c == ModCat.NEW) { fr(g, tx + tw - 5, cy + 5, 5, 5, ACCENT_BLUE); }
            tx += tw + 3;
        }

        // Search box
        int sX = cx + cw - 94, sY = cy + 6, sW = 88, sH = 16;
        boolean sfH = mx >= sX && mx < sX + sW && my >= sY && my < sY + sH;
        float sAnim = AnimationUtil.tick("search", searchFocus ? 1f : (sfH ? 0.5f : 0f), 0.2f);
        RenderUtil.rounded(g, sX, sY, sW, sH, 4, new Color(BG_SEARCH));
        int sBorder = AnimationUtil.lerpColor(BORDER_SRCH, ACCENT_BLUE, sAnim);
        bd(g, sX, sY, sW, sH, sBorder);
        g.drawString(font, "🔍", sX + 3, sY + 4, AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, sAnim));
        String ds = search.isEmpty() ? (searchFocus ? "" : "Search...") : search;
        g.drawString(font, ds, sX + 14, sY + 4, search.isEmpty() ? TEXT_DARK : TEXT_BRIGHT);
        if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0)
            fr(g, sX + 14 + font.width(search), sY + 3, 1, 10, TEXT_BRIGHT);
    }

    // ─────────────────────────────────────────────────────────────
    //  MOD CARD GRID
    // ─────────────────────────────────────────────────────────────
    private void renderGrid(GuiGraphicsExtractor g, int mx, int my, int cx, int cy, int cw, int ch) {
        // clip region
        int sX = cx + 6, sY = cy + 6;
        int maxSc = maxScroll();

        // scrollbar
        if (maxSc > 0) {
            int sbX = cx + cw - 5;
            fr(g, sbX, cy, 4, ch, 0xFF080C14);
            float fr2 = (float) scrollY / maxSc;
            int tH = Math.max(20, (int)((float) ch / (maxSc + ch) * ch));
            RenderUtil.rounded(g, sbX, cy + (int)((ch - tH) * fr2), 4, tH, 2, new Color(0xFF2D4A80));
        }

        int col = 0, row = 0, total = 0;
        for (Object[] mod : MODS) {
            String name = (String) mod[0], key = (String) mod[1];
            ModCat mc = (ModCat) mod[2]; boolean isN = (boolean) mod[3];
            String desc = (String) mod[4], icon = (String) mod[5];
            int accent = (int)(long)(Integer) mod[6];
            if (!filter(name, mc, isN)) continue;
            total++;

            int cardX = sX + col * (CARD_W + CARD_GAP);
            int cardY = sY + row * (CARD_H + CARD_GAP) - scrollY;

            if (cardY + CARD_H >= cy && cardY <= cy + ch) {
                boolean en   = mstate.getOrDefault(key, false);
                boolean hov  = mx >= cardX && mx < cardX + CARD_W && my >= Math.max(cardY, cy) && my < cardY + CARD_H && cardY >= cy - 4;
                renderCard(g, cardX, cardY, name, key, icon, desc, en, hov, isN, mc, accent);
                if (hov && cardY >= cy) { tooltip = desc; ttX = mx; ttY = Math.max(cardY - 4, cy); }
            }

            col++; if (col >= COLS) { col = 0; row++; }
        }

        if (total == 0) {
            String msg = "Модов не найдено: «" + search + "»";
            g.drawString(font, msg, cx + (cw - font.width(msg)) / 2, cy + ch / 2, TEXT_GRAY);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  ОДНА КАРТОЧКА МОДА
    // ─────────────────────────────────────────────────────────────
    private void renderCard(GuiGraphicsExtractor g, int cx, int cy, String name, String key,
                            String icon, String desc, boolean en, boolean hov,
                            boolean isNew, ModCat mc, int accent) {
        String animKey = "card_" + key + "_" + name;
        float ha = AnimationUtil.tick(animKey + "_h", hov ? 1f : 0f, 0.16f);
        float ea = AnimationUtil.tick(animKey + "_e", en  ? 1f : 0f, 0.14f);

        // card bg
        int bg = AnimationUtil.lerpColor(BG_CARD, en ? BG_CARD_EN : BG_CARD_HOV, Math.max(ha, ea * 0.5f));
        RenderUtil.rounded(g, cx, cy, CARD_W, CARD_H, 6, new Color(bg));

        // top accent line (RGB when enabled, static when not)
        int lineColor = en
            ? AnimationUtil.rgbCycleOffset(0.5f, (float)(cx + cy) / 600f)
            : accent;
        int lineAlpha = (int)(255 * Math.max(0.4f, ea));
        g.fillGradient(cx + 6, cy, cx + CARD_W - 6, cy + 2,
            (lineAlpha << 24) | (lineColor & 0x00FFFFFF), 0x00000000);

        // border
        int borderCol = en
            ? AnimationUtil.lerpColor(BORDER_CARD, (accent & 0x00FFFFFF) | 0x60000000, ea)
            : AnimationUtil.lerpColor(BORDER_CARD, 0xFF1E2A45, ha);
        bd(g, cx, cy, CARD_W, CARD_H, borderCol);

        // glow при enabled — RGB пульсирующий
        if (ea > 0.1f) {
            int glowRgb = AnimationUtil.rgbCycleOffset(0.4f, (float)(cx + cy) / 500f);
            for (int i = 4; i > 0; i--) {
                int ga = (int)(35 * ea * (1f - (float)i / 4));
                if (ga > 3) g.fill(cx - i, cy - i, cx + CARD_W + i, cy + CARD_H + i,
                    (ga << 24) | (glowRgb & 0x00FFFFFF));
            }
        }

        // icon circle background
        int iconBgAlpha = (int)(60 + 40 * ha);
        fr(g, cx + 6, cy + 8, 20, 20, (iconBgAlpha << 24) | (accent & 0x00FFFFFF));
        g.drawString(font, icon, cx + 9, cy + 12, AnimationUtil.lerpColor(accent, TEXT_WHITE, ha * 0.4f));

        // mod name
        g.drawString(font, trunc(name, CARD_W - 50), cx + 30, cy + 9, en ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, ha));

        // NEW badge
        if (isNew) {
            fr(g, cx + CARD_W - 30, cy + 7, 26, 10, NEW_BG);
            bd(g, cx + CARD_W - 30, cy + 7, 26, 10, ACCENT_BLUE);
            g.drawString(font, "NEW", cx + CARD_W - 27, cy + 8, NEW_FG);
        }

        // desc
        g.drawString(font, trunc(desc, CARD_W - 10), cx + 5, cy + 24, TEXT_GRAY);

        // separator
        g.fill(cx + 4, cy + CARD_H - 36, cx + CARD_W - 4, cy + CARD_H - 35, BORDER_SEP);

        // ENABLED / DISABLED button
        int eY = cy + CARD_H - 34;
        int enBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, ea);
        fr(g, cx + 4, eY, CARD_W - 36, 14, enBg);
        bd(g, cx + 4, eY, CARD_W - 36, 14,
            AnimationUtil.lerpColor(0xFF3A1A1A, (0x80000000 | (ACCENT_GREEN & 0x00FFFFFF)), ea));
        String eStr = en ? "● ENABLED" : "● DISABLED";
        int eFg = AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, ea);
        g.drawString(font, eStr, cx + 7, eY + 3, eFg);

        // OPTIONS / gear
        int oX = cx + 4, oY = cy + CARD_H - 18;
        boolean gSel = name.equals(optMod);
        fr(g, oX, oY, CARD_W - 36, 14, BG_OPT);
        bd(g, oX, oY, CARD_W - 36, 14, 0xFF141824);
        g.drawString(font, "OPTIONS", oX + 4, oY + 3, hov ? TEXT_GRAY : TEXT_DARK);

        // gear icon button
        int gX = cx + CARD_W - 30;
        float gA = AnimationUtil.tick("gear_" + name, gSel ? 1f : 0f, 0.2f);
        int gBg = AnimationUtil.lerpColor(BG_GEAR, 0xFF1B3060, gA);
        fr(g, gX, oY, 26, 14, gBg);
        bd(g, gX, oY, 26, 14, AnimationUtil.lerpColor(0xFF141824, ACCENT_BLUE, gA));
        g.drawString(font, "⚙", gX + 8, oY + 3, AnimationUtil.lerpColor(TEXT_GRAY, ACCENT_BLUE, gA));
    }

    private int optPanelHeight(String n) {
        return switch (n) {
            case "Kite", "Auto Crystal", "Obsidian Place", "Auto Pearl" -> 130; // 4 слайдера
            case "Auto Bow", "Auto Attack", "Adaptive CD", "ESP", "Radar" -> 86; // 2 слайдера
            case "Auto Dodge", "Auto Heal", "Auto Gap", "Auto Log",
                 "Bunker", "Hunt", "Auto Eat", "W-Tap", "Tracers" -> 60; // 1 слайдер
            default -> 52; // текст
        };
    }

    // ─────────────────────────────────────────────────────────────
    //  OPTIONS PANEL
    // ─────────────────────────────────────────────────────────────
    private void renderOptPanel(GuiGraphicsExtractor g, int mx, int my, String mName) {
        int pX = Math.min(optPanX, winX + WIN_W - 170);
        int pY = Math.min(optPanY, winY + WIN_H - FOOT_H - 138);
        int pW = 164, pH = optPanelHeight(mName);
        // shadow
        for (int i = 6; i > 0; i--) {
            int a = (int)(35 * (1f - (float)i / 6));
            g.fill(pX - i, pY - i, pX + pW + i, pY + pH + i, (a << 24));
        }
        RenderUtil.rounded(g, pX, pY, pW, pH, 6, new Color(0xFF0C1018));
        bd(g, pX, pY, pW, pH, ACCENT_BLUE);
        // header
        g.fillGradient(pX, pY, pX + pW, pY + 18, 0xFF0F1825, 0xFF0C1018);
        g.fill(pX, pY + 17, pX + pW, pY + 18, ACCENT_BLUE);
        g.drawString(font, mName, pX + 6, pY + 5, TEXT_WHITE);
        // close x
        g.drawString(font, "✕", pX + pW - 12, pY + 5, TEXT_GRAY);

        renderOptParams(g, mx, my, mName, pX + 5, pY + 22, pW - 10);
    }

    private void renderOptParams(GuiGraphicsExtractor g, int mx, int my, String n, int px, int py, int pw) {
        switch (n) {
            // ── COMBAT ─────────────────────────────────────────────
            case "Auto Attack" -> {
                drawSlider(g, mx, my, "Atk CD",    px, py,      pw, 2,  30,  cfg.attackCooldown, 0);
                drawSlider(g, mx, my, "Atk Range", px, py + 26, pw, 1,  6,   cfg.attackRange,    1);
            }
            case "W-Tap" -> {
                drawSlider(g, mx, my, "Release T", px, py,      pw, 1,  8,   cfg.wTapReleaseTicks, 0);
            }
            case "Auto Crystal", "Obsidian Place" -> {
                drawSlider(g, mx, my, "Place R",   px, py,      pw, 2,  10,  cfg.crystalPlaceRange,   0);
                drawSlider(g, mx, my, "Cr CD",     px, py + 26, pw, 1,  20,  cfg.crystalCooldown,     1);
                drawSlider(g, mx, my, "Cr DMG",    px, py + 52, pw, 5,  30,  cfg.diffCrystalDamage,   2);
                drawSlider(g, mx, my, "Diff CD",   px, py + 78, pw, 1,  60,  cfg.diffCrystalCooldown, 3);
            }
            case "Auto Bow" -> {
                drawSlider(g, mx, my, "Bow Range", px, py,      pw, 5,  50,  cfg.bowRange,    0);
                drawSlider(g, mx, my, "Bow CD",    px, py + 26, pw, 5,  60,  cfg.bowCooldown, 1);
            }
            case "Kite" -> {
                drawSlider(g, mx, my, "Bow Range", px, py,      pw, 5,  50,  cfg.bowRange,    0);
                drawSlider(g, mx, my, "Bow CD",    px, py + 26, pw, 5,  60,  cfg.bowCooldown, 1);
                drawSlider(g, mx, my, "Min Dist",  px, py + 52, pw, 2,  20,  cfg.kiteMinDist, 2);
                drawSlider(g, mx, my, "Max Dist",  px, py + 78, pw, 5,  40,  cfg.kiteMaxDist, 3);
            }
            case "Auto Dodge" -> {
                drawSlider(g, mx, my, "Dodge R",   px, py,      pw, 1,  8,   cfg.dodgeRange,  0);
            }
            // ── MECHANIC ───────────────────────────────────────────
            case "Auto Heal" -> {
                drawSlider(g, mx, my, "Heal HP",   px, py,      pw, 1,  20,  cfg.healThreshold,        0);
            }
            case "Auto Gap" -> {
                drawSlider(g, mx, my, "Gap HP",    px, py,      pw, 1,  20,  cfg.autoGapHpThreshold,   0);
            }
            case "Auto Log" -> {
                drawSlider(g, mx, my, "Log HP",    px, py,      pw, 1,  15,  cfg.autoLogHpThreshold,   0);
            }
            case "Auto Pearl" -> {
                drawSlider(g, mx, my, "Pearl Dist",px, py,      pw, 5,  32,  cfg.diffPearlThrowDist,   0);
                drawSlider(g, mx, my, "Escape HP", px, py + 26, pw, 1,  20,  cfg.diffPearlEscapeHpThreshold, 1);
                drawSlider(g, mx, my, "Pearl CD",  px, py + 52, pw, 20, 300, cfg.diffPearlCooldown,    2);
            }
            case "Bunker" -> {
                drawSlider(g, mx, my, "Bunker HP", px, py,      pw, 1,  20,  cfg.bunkerHpThreshold,    0);
            }
            case "Hunt" -> {
                drawSlider(g, mx, my, "Hunt Range",px, py,      pw, 16, 256, cfg.huntRange,             0);
            }
            case "Anti KB" -> {
                g.drawString(font, "Снижает отброс", px, py,      TEXT_GRAY);
                g.drawString(font, "от ударов врага", px, py + 12, TEXT_DARK);
            }
            case "Auto Eat" -> {
                drawSlider(g, mx, my, "Food Thr",  px, py,      pw, 1,  20,  cfg.eatThreshold,          0);
            }
            // ── VISUAL / HUD ───────────────────────────────────────
            case "ESP" -> {
                drawSlider(g, mx, my, "ESP Range", px, py,      pw, 10, 128, cfg.espRange,              0);
                drawSlider(g, mx, my, "Line W",    px, py + 26, pw, 1,  5,   cfg.espLineWidth,          1);
            }
            case "Radar" -> {
                drawSlider(g, mx, my, "Radar R",   px, py,      pw, 10, 128, cfg.radarRange,            0);
                drawSlider(g, mx, my, "Radar Rad", px, py + 26, pw, 10, 100, cfg.radarRadius,           1);
            }
            case "Tracers" -> {
                drawSlider(g, mx, my, "ESP Range", px, py,      pw, 10, 128, cfg.espRange,              0);
            }
            // ── SERVER / AI ────────────────────────────────────────
            case "Adaptive CD" -> {
                drawSlider(g, mx, my, "Atk CD",    px, py,      pw, 2,  30,  cfg.attackCooldown,        0);
                drawSlider(g, mx, my, "Atk Range", px, py + 26, pw, 1,  6,   cfg.attackRange,           1);
            }
            // ── TOGGLES-ONLY (нет числовых параметров) ─────────────
            case "S-Tap", "Auto Sprint", "Toggle Sneak",
                 "Auto Armor", "Auto Totem", "Auto Respawn",
                 "Fake Attack", "Pattern AI", "Anti Pattern",
                 "Ping Display", "Show HUD", "Show DPS", "Bot Stats",
                 "Notifications", "Training Mode", "Standby",
                 "Whitelist", "Auto Kit" -> {
                g.drawString(font, "Только вкл/выкл", px, py,      TEXT_GRAY);
                g.drawString(font, "— кнопка на карточке", px, py + 12, TEXT_DARK);
            }
            default -> {
                g.drawString(font, "Нет параметров", px, py,      TEXT_GRAY);
                g.drawString(font, "вкл/выкл на карточке", px, py + 12, TEXT_DARK);
            }
        }
    }

    private void drawSlider(GuiGraphicsExtractor g, int mx, int my, String label,
                            int sx, int sy, int sw, double min, double max, double val, int idx) {
        // label left, value right
        g.drawString(font, label + ":", sx, sy, TEXT_GRAY);
        String vs = (val == (int) val) ? String.valueOf((int) val) : String.format("%.1f", val);
        g.drawString(font, vs, sx + sw - font.width(vs), sy, TEXT_BRIGHT);

        int ty = sy + 11;
        // track
        RenderUtil.rounded(g, sx, ty, sw, 5, 2, new Color(0xFF101826));
        double frac = Math.max(0, Math.min(1, (val - min) / (max - min)));
        // fill
        int fillW = (int)(sw * frac);
        if (fillW > 4) RenderUtil.rounded(g, sx, ty, fillW, 5, 2, new Color(ACCENT_BLUE));
        // knob
        int kx = sx + fillW - 4;
        boolean kHov = mx >= kx - 2 && mx < kx + 10 && my >= ty - 3 && my < ty + 8;
        float kA = AnimationUtil.tick("slider_" + idx, kHov ? 1f : 0f, 0.2f);
        int kColor = AnimationUtil.lerpColor(ACCENT_BLUE, TEXT_WHITE, kA);
        RenderUtil.rounded(g, kx, ty - 2, 8, 9, 3, new Color(kColor));
    }

    // ═══════════════════════════════════════════════════════════════
    //  SETTINGS TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderSettings(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        g.fill(cx, cy, cx + cw, cy + ch, 0xFF0A0D12);
        fr(g, cx, cy, cw, ch, BG_MAIN);
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        int sx = cx + 12, sy = cy + 8;

        // DIFFICULTY
        secTitle(g, "DIFFICULTY", sx, sy); sy += 14;
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int[] dc = {0xFF22C55E, 0xFFEAB308, 0xFFEF4444, 0xFF991B1B};
        int dcW = 58;
        for (int i = 0; i < 4; i++) {
            int dx = sx + i * (dcW + 4);
            boolean act = cfg.difficulty == diffs[i];
            boolean hov = mx >= dx && mx < dx + dcW && my >= sy && my < sy + 22;
            float a = AnimationUtil.tick("sets_diff_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int dBg = AnimationUtil.lerpColor(BG_CARD, (dc[i] & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, dx, sy, dcW, 22, 4, new Color(dBg));
            g.fill(dx, sy, dx + dcW, sy + 2, dc[i]);
            g.drawString(font, diffs[i].name(), dx + 4, sy + 7, act ? dc[i] : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
            if (act) g.drawString(font, "✓", dx + dcW - 10, sy + 7, dc[i]);
        }
        sy += 32;

        // COMBAT MODE
        secTitle(g, "COMBAT MODE", sx, sy); sy += 14;
        PVPBotConfig.Mode[] modes = PVPBotConfig.Mode.values();
        String[] mIcons = {
            "🗡",   // SWORD      — голубой меч (mctiers)
            "🪓",   // AXE        — голубой топор (mctiers)
            "🔨",   // MACE       — серая булава (mctiers)
            "🔨",   // MACE_ELYTRA— булава + элитры
            "❤",   // UHC        — красное сердце (mctiers)
            "💀",   // NETHOP     — фиолетовый череп (mctiers)
            "⚗",   // POT        — колба/зелье (mctiers)
            "🟢",   // SMP        — зелёный жемчуг (mctiers)
            "💠",   // CRYSTAL    — голубой кристалл (mctiers Vanilla)
            "💀",   // NETHPOT    — фиолетовый череп
            "💠",   // TPC        — кристалл
            "❄",   // SNOWBALL
            "❤",   // TOTEM      — сердце
            "🔱",   // TRIDENT
            "🐝",   // BEEHIVE
            "🎆",   // FIREWORK
            "🏹",   // CROSSBOW
        };
        int availW = WIN_W - LEFT_W - 20;
        int modesPerRow = 7;
        int mcW = (availW - (modesPerRow - 1) * 3) / modesPerRow; // авто-ширина
        int mcH = 20;
        for (int i = 0; i < modes.length; i++) {
            int mc = i % modesPerRow, mr = i / modesPerRow;
            int mx2 = sx + mc * (mcW + 3), my2 = sy + mr * (mcH + 3);
            boolean act = cfg.mode == modes[i];
            boolean hov = mx >= mx2 && mx < mx2 + mcW && my >= my2 && my < my2 + mcH;
            float a = AnimationUtil.tick("sets_mode_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int strp = modeColor(modes[i]);
            int mBg = AnimationUtil.lerpColor(BG_CARD, (strp & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, mx2, my2, mcW, mcH, 3, new Color(mBg));
            g.fill(mx2, my2, mx2 + mcW, my2 + 2, act ? strp : AnimationUtil.lerpColor(0xFF101826, strp, a * 0.7f));
            String ico = i < mIcons.length ? mIcons[i] : "?";
            String label = trunc(modes[i].name(), mcW - 16);
            g.drawString(font, ico + " " + label, mx2 + 3, my2 + 6, act ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
        }
        sy += (modes.length / modesPerRow + 2) * (mcH + 3) + 6;

        // QUICK TOGGLES
        secTitle(g, "QUICK TOGGLES", sx, sy); sy += 14;
        renderTogRow(g, mx, my, sx, sy,
            new String[]{"W-Tap","Pearls","Crystals","Standby","PatternAI"},
            new boolean[]{cfg.wTapEnabled, cfg.diffUsePearls, cfg.diffUseCrystals, cfg.standbyMode, cfg.patternAIEnabled});
        sy += 22;
        renderTogRow(g, mx, my, sx, sy,
            new String[]{"AdaptCD","Whitelist","Bunker","Hunt","Training"},
            new boolean[]{cfg.adaptiveCooldownEnabled, cfg.whitelistEnabled, cfg.bunkerEnabled, cfg.huntEnabled, cfg.trainingMode});
        sy += 22;

        // Strafe row
        boolean strafeOn = cfg.strafeEnabled;
        boolean strafeHov = mx >= sx && mx < sx + 88 && my >= sy && my < sy + 16;
        float strafeA = AnimationUtil.tick("togrow_Strafe", strafeOn ? 1f : (strafeHov ? 0.4f : 0f), 0.16f);
        int strafeBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, strafeA);
        RenderUtil.rounded(g, sx, sy, 88, 16, 3, new Color(strafeBg));
        bd(g, sx, sy, 88, 16, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, strafeA));
        g.drawString(font, "Strafe:" + (strafeOn ? "ON" : "OFF"), sx + 4, sy + 4,
            AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, strafeA));

        // Strafe style buttons
        StrafeAI.StrafeStyle[] styles = StrafeAI.StrafeStyle.values();
        int styleX = sx + 96;
        for (int i = 0; i < styles.length; i++) {
            boolean act = cfg.strafeStyle == styles[i];
            boolean hov = mx >= styleX && mx < styleX + 58 && my >= sy && my < sy + 16;
            float sa = AnimationUtil.tick("strafe_style_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int sbg = AnimationUtil.lerpColor(BG_CARD, (ACCENT_CYAN & 0x00FFFFFF) | 0x25000000, sa);
            RenderUtil.rounded(g, styleX, sy, 58, 16, 3, new Color(sbg));
            bd(g, styleX, sy, 58, 16, act ? ACCENT_CYAN : AnimationUtil.lerpColor(BORDER_CARD, ACCENT_CYAN, sa));
            g.drawString(font, styles[i].name(), styleX + 4, sy + 4,
                act ? ACCENT_CYAN : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, sa));
            styleX += 62;
        }
        sy += 30;

        // PARAMETERS
        secTitle(g, "PARAMETERS", sx, sy); sy += 14;
        renderNumRow(g, mx, my, sx,       sy,    "Attack CD",  String.valueOf(cfg.attackCooldown));
        renderNumRow(g, mx, my, sx + 210, sy,    "Atk Range",  String.format("%.1f", cfg.attackRange));
        renderNumRow(g, mx, my, sx,       sy+20, "Max Bots",   String.valueOf(cfg.maxBots));
        renderNumRow(g, mx, my, sx + 210, sy+20, "Cr.Damage",  String.format("%.0f", cfg.diffCrystalDamage));
        renderNumRow(g, mx, my, sx,       sy+40, "Heal HP",    String.format("%.0f", cfg.healThreshold));
        renderNumRow(g, mx, my, sx + 210, sy+40, "Crystal CD", String.valueOf(cfg.crystalCooldown));
        renderNumRow(g, mx, my, sx,       sy+60, "Bot Max HP", String.format("%.0f", cfg.botMaxHealth));
        renderNumRow(g, mx, my, sx + 210, sy+60, "Heal Thr",   String.format("%.0f", cfg.botHealThreshold));
        sy += 80;

        // ── SOUND ────────────────────────────────────────────────
        secTitle(g, "CLIENT SOUNDS", sx, sy); sy += 14;

        ClientSounds.SoundMode[] soundModes = ClientSounds.modes();
        ClientSounds.SoundMode   cur   = ClientSounds.INSTANCE.getMode();
        int btnW = 68, btnH = 16, btnGap = 4;
        int perRow = 5;
        for (int i = 0; i < soundModes.length; i++) {
            ClientSounds.SoundMode m = soundModes[i];
            int col = i % perRow, row = i / perRow;
            int bx = sx + col * (btnW + btnGap);
            int by = sy + row * (btnH + btnGap);
            boolean sel = m == cur;
            boolean hov = mx >= bx && mx < bx + btnW && my >= by && my < by + btnH;
            float a = AnimationUtil.tick("snd_mode_" + i, sel ? 1f : (hov ? 0.5f : 0f), 0.2f);
            int bg = AnimationUtil.lerpColor(BG_CARD, 0x22AAAAFF, a);
            int bd = AnimationUtil.lerpColor(BORDER_CARD, sel ? ACCENT_CYAN : ACCENT_BLUE, a);
            RenderUtil.rounded(g, bx, by, btnW, btnH, 3, new Color(bg));
            bd(g, bx, by, btnW, btnH, bd);
            g.drawString(font, (sel ? "§b" : "§7") + m.label, bx + 5, by + 4,
                sel ? ACCENT_CYAN : TEXT_GRAY);
        }
        sy += (int) Math.ceil(soundModes.length / (float) perRow) * (btnH + btnGap) + 6;

        // Громкость (ползунок)
        g.drawString(font, "Volume:", sx, sy + 2, TEXT_GRAY);
        int slW = 160;
        fr(g, sx + 52, sy + 5, slW, 4, BG_CARD);
        fr(g, sx + 52, sy + 5, (int)(slW * ClientSounds.INSTANCE.getVolume()), 4, ACCENT_CYAN);
        int knobX = sx + 52 + (int)(slW * ClientSounds.INSTANCE.getVolume()) - 3;
        fr(g, knobX, sy + 2, 6, 10, 0xFFCCEEFF);
        g.drawString(font, (int)(ClientSounds.INSTANCE.getVolume() * 100) + "%",
            sx + 52 + slW + 6, sy + 2, TEXT_GRAY);

        // Кнопка Test
        int testX = sx + 52 + slW + 40;
        boolean hovTest = mx >= testX && mx < testX + 40 && my >= sy && my < sy + 14;
        float aTest = AnimationUtil.tick("snd_test", hovTest ? 1f : 0f, 0.2f);
        RenderUtil.rounded(g, testX, sy, 40, 14, 3,
            new Color(AnimationUtil.lerpColor(BG_CARD, 0x22AAFFAA, aTest)));
        bd(g, testX, sy, 40, 14, AnimationUtil.lerpColor(BORDER_CARD, ACCENT_GREEN, aTest));
        g.drawString(font, "▶ Test", testX + 4, sy + 3,
            AnimationUtil.lerpColor(TEXT_GRAY, ACCENT_GREEN, aTest));

        sy += 24;

        // ── WEB CONFIG ────────────────────────────────────────────
        secTitle(g, "WEB CONFIG (порт " + cfg.webConfigPort + ")", sx, sy); sy += 14;
        boolean wcOn = cfg.webConfigEnabled;
        boolean wcHov = mx >= sx && mx < sx + 120 && my >= sy && my < sy + 18;
        float wcA = AnimationUtil.tick("wc_toggle", wcOn ? 1f : (wcHov ? 0.4f : 0f), 0.18f);
        int wcBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, wcA);
        RenderUtil.rounded(g, sx, sy, 120, 18, 4, new Color(wcBg));
        bd(g, sx, sy, 120, 18, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, wcA));
        g.drawString(font, wcOn ? "🌐 HTTP: ON  (localhost:" + cfg.webConfigPort + ")" : "🌐 HTTP: OFF",
            sx + 5, sy + 5, AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, wcA));
        if (wcOn) {
            g.drawString(font, "→ http://localhost:" + cfg.webConfigPort, sx + 130, sy + 5, TEXT_GRAY);
        }
        sy += 26;

        // ── AUTO CHAT TAUNTS ──────────────────────────────────────
        secTitle(g, "AUTO CHAT TAUNTS", sx, sy); sy += 14;
        boolean acOn = cfg.autoChatEnabled;
        boolean acHov = mx >= sx && mx < sx + 100 && my >= sy && my < sy + 16;
        float acA = AnimationUtil.tick("ac_toggle", acOn ? 1f : (acHov ? 0.4f : 0f), 0.18f);
        RenderUtil.rounded(g, sx, sy, 100, 16, 3, new Color(AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, acA)));
        bd(g, sx, sy, 100, 16, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, acA));
        g.drawString(font, "AutoChat: " + (acOn ? "ON" : "OFF"), sx + 4, sy + 4,
            AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, acA));
        sy += 20;
        // Kill message field
        g.drawString(font, "Kill msg:", sx, sy + 2, TEXT_GRAY);
        int kmX = sx + 58; int kmW = 180;
        fr(g, kmX, sy, kmW, 13, BG_CARD); bd(g, kmX, sy, kmW, 13, BORDER_CARD);
        g.drawString(font, trunc(cfg.chatKillMessage, kmW - 6), kmX + 3, sy + 2, TEXT_BRIGHT);
        sy += 18;
        // Low HP message field
        g.drawString(font, "Low HP:", sx, sy + 2, TEXT_GRAY);
        fr(g, kmX, sy, kmW, 13, BG_CARD); bd(g, kmX, sy, kmW, 13, BORDER_CARD);
        g.drawString(font, trunc(cfg.chatLowHpMessage, kmW - 6), kmX + 3, sy + 2, TEXT_BRIGHT);
        g.drawString(font, "(click to edit)", kmX + kmW + 4, sy + 2, TEXT_GRAY);
        sy += 24;

        // ── BOT LEARNING ──────────────────────────────────────────
        secTitle(g, "BOT LEARNING", sx, sy); sy += 14;
        boolean blRec = BotLearning.INSTANCE.isRecording();
        g.drawString(font, "Status: " + (blRec ? "§aRECORDING" : "§7IDLE"), sx, sy, TEXT_GRAY); sy += 12;
        int topN = BotLearning.INSTANCE.getPatternCount();
        g.drawString(font, "Learned patterns: §e" + topN, sx, sy, TEXT_GRAY); sy += 12;
        // Start/Stop buttons
        int blBtnW = 72;
        for (int i = 0; i < 3; i++) {
            String[] btnLabels = {"▶ Start", "■ Stop", "⟳ Reset"};
            int[] btnColors = {ACCENT_GREEN, ACCENT_RED, ACCENT_YEL};
            int bx = sx + i * (blBtnW + 4);
            boolean bHov = mx >= bx && mx < bx + blBtnW && my >= sy && my < sy + 16;
            float bA = AnimationUtil.tick("bl_btn_" + i, bHov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, bx, sy, blBtnW, 16, 3,
                new Color(AnimationUtil.lerpColor(BG_CARD, (btnColors[i] & 0x00FFFFFF) | 0x22000000, bA)));
            bd(g, bx, sy, blBtnW, 16, AnimationUtil.lerpColor(BORDER_CARD, btnColors[i], bA));
            g.drawCenteredString(font, btnLabels[i], bx + blBtnW / 2, sy + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, btnColors[i], bA));
        }
        // Top pattern display
        sy += 22;
        var topPat = BotLearning.INSTANCE.getTopPattern();
        if (topPat != null && !topPat.isEmpty()) {
            // Format: first 6 actions abbreviated
            StringBuilder sb = new StringBuilder("Top: ");
            int show = Math.min(6, topPat.size());
            for (int i = 0; i < show; i++) {
                if (i > 0) sb.append("→");
                sb.append(topPat.get(i).name().substring(0, Math.min(3, topPat.get(i).name().length())));
            }
            if (topPat.size() > 6) sb.append("…");
            sb.append(" (").append(BotLearning.INSTANCE.getPatternCount()).append(" total)");
            g.drawString(font, trunc(sb.toString(), WIN_W - LEFT_W - 30), sx, sy, ACCENT_CYAN);
        } else {
            g.drawString(font, "No patterns yet — stand near a player and /bot learn start", sx, sy, TEXT_GRAY);
        }
        g.disableScissor();
    }

    private void renderTogRow(GuiGraphicsExtractor g, int mx, int my, int sx, int sy, String[] labels, boolean[] vals) {
        for (int i = 0; i < labels.length; i++) {
            int tx = sx + i * 96, ty = sy;
            boolean on = vals[i];
            boolean hov = mx >= tx && mx < tx + 88 && my >= ty && my < ty + 16;
            float a = AnimationUtil.tick("togrow_" + labels[i], on ? 1f : (hov ? 0.4f : 0f), 0.16f);
            int tBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, a);
            RenderUtil.rounded(g, tx, ty, 88, 16, 3, new Color(tBg));
            int tBorder = AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, a);
            bd(g, tx, ty, 88, 16, tBorder);
            g.drawString(font, labels[i] + ":" + (on ? "ON" : "OFF"), tx + 4, ty + 4,
                AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, a));
        }
    }

    private void renderNumRow(GuiGraphicsExtractor g, int mx, int my, int sx, int sy, String label, String val) {
        g.drawString(font, label + ":", sx, sy + 2, TEXT_GRAY);
        fr(g, sx + 118, sy, 50, 12, BG_CARD); bd(g, sx + 118, sy, 50, 12, BORDER_CARD);
        g.drawString(font, val, sx + 122, sy + 2, TEXT_BRIGHT);
        // minus/plus
        for (int i = 0; i < 2; i++) {
            int bx = sx + 170 + i * 16;
            boolean hov = mx >= bx && mx < bx + 14 && my >= sy && my < sy + 12;
            float a = AnimationUtil.tick("pm_" + label + i, hov ? 1f : 0f, 0.2f);
            fr(g, bx, sy, 14, 12, AnimationUtil.lerpColor(BG_GEAR, 0xFF1A2A40, a));
            bd(g, bx, sy, 14, 12, AnimationUtil.lerpColor(BORDER_CARD, ACCENT_BLUE, a));
            g.drawString(font, i == 0 ? "−" : "+", bx + 3, sy + 2, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  DIFFICULTY TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderDifficulty(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;
        g.drawString(font, "DIFFICULTY SETTINGS", sx, sy, TEXT_WHITE);
        g.drawString(font, "Current: " + cfg.difficulty.name(), sx + 186, sy, diffCol(cfg.difficulty));
        sy += 18;

        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int[] cols = {0xFF22C55E, 0xFFEAB308, 0xFFEF4444, 0xFF991B1B};
        String[][] params = {
            {"Кд: 24 тика","Дальн: 2.8","Перлы: НЕТ","Кристаллы: НЕТ","Скорость -35%","Промахи: 30%","AI: Отключён"},
            {"Кд: 13±4 тика","Дальн: 3.5","Лук >12 блоков","Перлы: НЕТ","Скорость: норма","Стрейф: редко","AI: Базовый"},
            {"Кд: 7 тиков","Дальн: 4.0","Перлы: ДА","Кристаллы: ДА","Бьёт в воздухе","Скорость +3%","AI: Продвинутый"},
            {"Кд: 4 тика","Дальн: 4.5","Перлы+Кристаллы","Обсидиан авто","Воздух ×1.4","Combo BURST","AI: Эксперт"},
        };

        int dcW = (cw - 16) / 4 - 4;
        for (int i = 0; i < 4; i++) {
            boolean act = cfg.difficulty == diffs[i];
            int dx = sx + i * (dcW + 5);
            boolean hov = mx >= dx && mx < dx + dcW && my >= sy && my < sy + 140;
            float a = AnimationUtil.tick("diff_card_" + i, (act || hov) ? 1f : 0f, 0.14f);

            int dBg = AnimationUtil.lerpColor(BG_CARD, (cols[i] & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, dx, sy, dcW, 140, 6, new Color(dBg));
            // top stripe
            g.fillGradient(dx + 6, sy, dx + dcW - 6, sy + 3, cols[i], (cols[i] & 0x00FFFFFF) | 0x00000000);
            // border
            bd(g, dx, sy, dcW, 140, act ? cols[i] : AnimationUtil.lerpColor(BORDER_CARD, cols[i], a * 0.6f));

            g.drawString(font, diffs[i].name(), dx + 5, sy + 8, act ? cols[i] : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
            if (act) g.drawString(font, "✓", dx + dcW - 12, sy + 8, cols[i]);

            for (int pi = 0; pi < params[i].length; pi++) {
                g.drawString(font, "• " + params[i][pi], dx + 5, sy + 22 + pi * 10,
                    AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, Math.max(0.5f, a)));
            }

            // bottom action bar
            fr(g, dx, sy + 124, dcW, 16, act ? 0xFF0A1A0D : 0xFF0A0D14);
            g.drawString(font, act ? "● ACTIVE" : (hov ? "Click to select" : ""),
                dx + 5, sy + 128, act ? cols[i] : ACCENT_BLUE);
        }

        sy += 150;
        secTitle(g, "FINE TUNING", sx, sy); sy += 14;
        drawSlider(g, mx, my, "Attack CD",  sx,       sy,     220, 2, 30, cfg.attackCooldown, 10);
        drawSlider(g, mx, my, "Atk Range",  sx + 240, sy,     180, 1, 6,  cfg.attackRange, 11);
        sy += 26;
        drawSlider(g, mx, my, "Crystal DMG",sx,       sy,     220, 5, 30, cfg.diffCrystalDamage, 12);
        drawSlider(g, mx, my, "Pearl HP",   sx + 240, sy,     180, 1, 20, cfg.diffPearlEscapeHpThreshold, 13);
        sy += 26;
        drawSlider(g, mx, my, "Crystal CD", sx,       sy,     220, 1, 20, cfg.diffCrystalCooldown, 14);
        drawSlider(g, mx, my, "Bow Range",  sx + 240, sy,     180, 3, 30, cfg.diffBowSwitchRange, 15);
    }

    // ═══════════════════════════════════════════════════════════════
    //  PROFILES TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderProfilesTab(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;
        g.drawString(font, "LOAD PRESET PROFILE", sx, sy, TEXT_WHITE); sy += 18;

        Object[][] built = {
            {"pvp",             "PvP Standard",    "SWORD · HARD",    "kit_sword",   0xFFC0A050},
            {"pve",             "PvE Mode",         "BOW · MEDIUM",    "kit_axe",     0xFF22C55E},
            {"crystal",         "Crystal PvP",      "CRYSTAL · EXPERT","kit_crystal", 0xFF60A5FA},
            {"passive",         "Passive",          "No Attack",       "kit_vanilla", 0xFF94A3B8},
            {"smp",             "SMP Survival",     "SWORD · MEDIUM",  "kit_smp",     0xFF4ADE80},
            {"uhc",             "UHC Mode",         "BOW · HARD",      "kit_uhc",     0xFFEF4444},
            {"nethpot",         "NethPot",          "POTION · HARD",   "kit_nethpot", 0xFF8B5CF6},
            {"axe",             "Axe PvP",          "AXE · HARD",      "kit_axe",     0xFFFB923C},
            {"tpc",             "TPC",              "CRYSTAL · EXPERT","kit_tpc",     0xFF8B5CF6},
            {"obsidian_crystal","Obsidian Crystal", "CRYSTAL · EXPERT","kit_crystal", 0xFF6366F1},
            {"snowball",        "Snowball",         "SNOWBALL · MED",  "kit_snowball",0xFF94A3B8},
            {"shield_sword",    "Shield Sword",     "SWORD · HARD",    "kit_sword",   0xFF3B82F6},
        };

        int pW = 118, pH = 60, pCols = 4, pGap = 5;
        for (int i = 0; i < built.length; i++) {
            Object[] bp = built[i];
            int col = i % pCols, row = i / pCols;
            int bx = sx + col * (pW + pGap), by = sy + row * (pH + pGap);
            boolean hov = mx >= bx && mx < bx + pW && my >= by && my < by + pH;
            int acc = (int)(long)(Integer) bp[4];
            float a = AnimationUtil.tick("prof_preset_" + i, hov ? 1f : 0f, 0.18f);

            int pbg = AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x14000000, a);
            RenderUtil.rounded(g, bx, by, pW, pH, 6, new Color(pbg));
            g.fillGradient(bx + 4, by, bx + pW - 4, by + 3, acc, (acc & 0x00FFFFFF));
            bd(g, bx, by, pW, pH, AnimationUtil.lerpColor(BORDER_CARD, acc, a * 0.7f));

            // Иконка кита через IconRenderer (PNG или Unicode-fallback)
            IconRenderer.draw(g, (String) bp[3], bx + 4, by + 5, 10);
            g.drawString(font, (String) bp[1], bx + 18, by + 8, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, a));
            g.drawString(font, (String) bp[2], bx + 5,  by + 20, TEXT_GRAY);

            if (hov) {
                fr(g, bx, by + pH - 16, pW, 16, 0xFF0A1018);
                g.drawString(font, "Load: " + bp[0], bx + 5, by + pH - 12, ACCENT_BLUE);
            }
        }

        int saveY = sy + (built.length / pCols + 1) * (pH + pGap) + 8;
        secTitle(g, "SAVE CURRENT CONFIG", sx, saveY); saveY += 14;
        int[] sc = {0xFF22C55E, 0xFF60A5FA, 0xFF8B5CF6};
        String[] sn = {"pvp", "crystal", "passive"};
        for (int i = 0; i < 3; i++) {
            boolean hov = mx >= sx + i * 142 && mx < sx + i * 142 + 132 && my >= saveY && my < saveY + 16;
            float a = AnimationUtil.tick("save_btn_" + i, hov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, sx + i * 142, saveY, 132, 16, 3, new Color(AnimationUtil.lerpColor(BG_CARD, (sc[i] & 0x00FFFFFF) | 0x20000000, a)));
            bd(g, sx + i * 142, saveY, 132, 16, AnimationUtil.lerpColor(BORDER_CARD, sc[i], a));
            g.drawString(font, "💾 Save as '" + sn[i] + "'", sx + i * 142 + 5, saveY + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, sc[i], a));
        }

        // ── Экспорт / Импорт профилей ─────────────────────────────
        int expY = saveY + 26;
        secTitle(g, "EXPORT / IMPORT PROFILES", sx, expY); expY += 14;

        // Кнопка Export
        boolean hovExp = mx >= sx && mx < sx + 130 && my >= expY && my < expY + 18;
        float aExp = AnimationUtil.tick("exp_btn", hovExp ? 1f : 0f, 0.2f);
        RenderUtil.rounded(g, sx, expY, 130, 18, 3,
            new Color(AnimationUtil.lerpColor(BG_CARD, 0x20E8A020, aExp)));
        bd(g, sx, expY, 130, 18, AnimationUtil.lerpColor(BORDER_CARD, 0xFFE8A020, aExp));
        g.drawString(font, "📤 Export current profile", sx + 5, expY + 5,
            AnimationUtil.lerpColor(TEXT_GRAY, 0xFFE8A020, aExp));

        // Список сохранённых профилей для импорта
        java.util.List<String> savedProfiles = BotConfig.listProfiles();
        int impX = sx + 140;
        g.drawString(font, "📂 Saved profiles:", impX, expY, TEXT_GRAY);
        expY += 12;
        if (savedProfiles.isEmpty()) {
            g.drawString(font, "Нет сохранённых профилей", impX, expY, TEXT_DARK);
        } else {
            for (int i = 0; i < Math.min(savedProfiles.size(), 5); i++) {
                String pname = savedProfiles.get(i);
                int py2 = expY + i * 16;
                boolean hovImp = mx >= impX && mx < impX + 200 && my >= py2 && my < py2 + 14;
                float aImp = AnimationUtil.tick("imp_" + i, hovImp ? 1f : 0f, 0.2f);
                if (hovImp) fr(g, impX - 2, py2 - 1, 204, 14, 0x15FFFFFF);
                g.drawString(font, "📥 " + pname, impX, py2 + 2,
                    AnimationUtil.lerpColor(TEXT_GRAY, 0xFF60A5FA, aImp));
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  STATS TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderStats(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;

        g.drawString(font, "SESSION STATISTICS", sx, sy, TEXT_WHITE);
        long secs = (System.currentTimeMillis() - sessionStart) / 1000;
        g.drawString(font, String.format("⏱ %02d:%02d", secs / 60, secs % 60), sx + 200, sy, TEXT_GRAY);
        sy += 18;

        // Big stat cards
        int[] vs = {KillDeathTracker.kills, KillDeathTracker.deaths, KillDeathTracker.assists};
        String[] ls = {"KILLS", "DEATHS", "ASSISTS"};
        int[] cs = {ACCENT_GREEN, ACCENT_RED, ACCENT_YEL};
        String[] icons = {"⚔", "💀", "🤝"};
        int sW = 104, sH = 52;
        for (int i = 0; i < 3; i++) {
            int bx = sx + i * (sW + 8);
            float a = AnimationUtil.tick("stats_card_" + i, 1f, 0.05f);
            RenderUtil.rounded(g, bx, sy, sW, sH, 6, new Color(BG_CARD));
            g.fillGradient(bx + 4, sy, bx + sW - 4, sy + 3, cs[i], (cs[i] & 0x00FFFFFF));
            bd(g, bx, sy, sW, sH, (cs[i] & 0x00FFFFFF) | 0x50000000);
            g.drawString(font, icons[i], bx + 5, sy + 6, cs[i]);
            String numStr = String.valueOf(vs[i]);
            int numW = font.width(numStr) * 2;
            g.drawCenteredString(font, numStr, bx + sW / 2, sy + 16, cs[i]);
            g.drawCenteredString(font, ls[i], bx + sW / 2, sy + 36, TEXT_GRAY);
        }

        // K/D ratio
        double kd = KillDeathTracker.deaths == 0 ? KillDeathTracker.kills : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
        int kdX = sx + 3 * (sW + 8);
        RenderUtil.rounded(g, kdX, sy, sW, sH, 6, new Color(BG_CARD));
        g.fillGradient(kdX + 4, sy, kdX + sW - 4, sy + 3, ACCENT_BLUE, (ACCENT_BLUE & 0x00FFFFFF));
        bd(g, kdX, sy, sW, sH, (ACCENT_BLUE & 0x00FFFFFF) | 0x50000000);
        g.drawString(font, "📊", kdX + 5, sy + 6, ACCENT_BLUE);
        g.drawCenteredString(font, String.format("%.2f", kd), kdX + sW / 2, sy + 16, ACCENT_BLUE);
        g.drawCenteredString(font, "K/D RATIO", kdX + sW / 2, sy + 36, TEXT_GRAY);

        sy += sH + 12;
        secTitle(g, "RECENT FIGHTS — BAR CHART", sx, sy); sy += 14;

        // bar chart
        int[] results = {1, 0, 1, 1, -1, 1, 0, 1, -1, 1};
        String[] opp   = {"Notch","Steve","Hero","Alex","Ender","Creep","P1","Ghost","B0ne","Raid"};
        int bW = 28, barH = 48, bG = 5;
        for (int i = 0; i < results.length; i++) {
            int bx = sx + i * (bW + bG);
            int bc = results[i] > 0 ? ACCENT_GREEN : (results[i] < 0 ? ACCENT_RED : TEXT_GRAY);
            int fh = results[i] > 0 ? barH : (results[i] < 0 ? barH / 2 : barH / 3);
            fr(g, bx, sy, bW, barH, 0xFF141A28);
            // animated bar fill
            float ba = AnimationUtil.tick("bar_" + i, 1f, 0.04f);
            int realFh = (int)(fh * ba);
            fr(g, bx, sy + barH - realFh, bW, realFh, (bc & 0x00FFFFFF) | 0xCC000000);
            bd(g, bx, sy, bW, barH, 0xFF1A2035);
            // result label
            String rl = results[i] > 0 ? "W" : (results[i] < 0 ? "L" : "D");
            g.drawCenteredString(font, rl, bx + bW / 2, sy + barH + 2, bc);
            // opponent name (rotated hint)
            if (i % 2 == 0) g.drawString(font, opp[i], bx - 1, sy + barH + 14, TEXT_DARK);
        }

        sy += barH + 30;
        secTitle(g, "CURRENT SESSION INFO", sx, sy); sy += 14;
        g.drawString(font, "Mode: " + cfg.mode.name(), sx, sy, TEXT_BRIGHT);
        g.drawString(font, "Difficulty: " + cfg.difficulty.name(), sx + 110, sy, diffCol(cfg.difficulty));
        g.drawString(font, cfg.standbyMode ? "⏸ STANDBY" : "⚔ ACTIVE", sx + 250, sy, cfg.standbyMode ? TEXT_GRAY : ACCENT_RED);
        g.drawString(font, "Bots: " + cfg.maxBots, sx + 380, sy, TEXT_BRIGHT);
        sy += 18;

        // ── KIT STATS ─────────────────────────────────────────────
        secTitle(g, "KIT STATS", sx, sy); sy += 14;

        java.util.Map<String, KitStatsTracker.KitRecord> allRecords = KitStatsTracker.INSTANCE.getAllRecords();
        String bestKit = KitStatsTracker.INSTANCE.getBestKit();

        if (allRecords.isEmpty()) {
            g.drawString(font, "Нет данных — начни бой с ботом", sx, sy, TEXT_GRAY);
        } else {
            // Шапка таблицы
            g.drawString(font, "Кит             Rounds  Win%    DMG↑    DMG↓", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;

            int rowIdx = 0;
            for (java.util.Map.Entry<String, KitStatsTracker.KitRecord> entry : allRecords.entrySet()) {
                if (sy > cy + ch - 20) break;
                String kitId = entry.getKey();
                KitStatsTracker.KitRecord rec = entry.getValue();

                boolean isBest = kitId.equals(bestKit);
                if (rowIdx % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);

                // Звёздочка для лучшего кита
                int nameColor = isBest ? ACCENT_YEL : TEXT_BRIGHT;
                String kitLabel = (isBest ? "★ " : "  ") + padRight(kitId, 14);
                g.drawString(font, kitLabel,                                          sx,       sy, nameColor);
                g.drawString(font, padLeft(String.valueOf(rec.rounds), 4),            sx + 116, sy, TEXT_GRAY);

                float wr = rec.winRate() * 100f;
                int wrColor = wr >= 60 ? ACCENT_GREEN : (wr >= 40 ? ACCENT_YEL : ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f%%", wr), 5),           sx + 152, sy, wrColor);
                g.drawString(font, padLeft(String.format("%.0f", rec.avgDamageDealt()), 6), sx + 192, sy, ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f", rec.avgDamageTaken()), 6), sx + 232, sy, 0xFFFF8844);

                // Мини-полоска Win Rate
                int barW = 60;
                int barX = sx + 272;
                fr(g, barX, sy + 1, barW, 7, 0xFF1A2035);
                fr(g, barX, sy + 1, (int)(barW * rec.winRate()), 7, (wrColor & 0x00FFFFFF) | 0xAA000000);
                bd(g, barX, sy + 1, barW, 7, BORDER_CARD);

                sy += 12;
                rowIdx++;
            }

            // Кнопка сброса
            sy += 4;
            boolean hovRst = mx >= sx && mx < sx + 90 && my >= sy && my < sy + 14;
            float aRst = AnimationUtil.tick("kitstats_reset", hovRst ? 1f : 0f, 0.2f);
            fr(g, sx, sy, 90, 14, AnimationUtil.lerpColor(BG_CARD, 0x20EF4444, aRst));
            bd(g, sx, sy, 90, 14, AnimationUtil.lerpColor(BORDER_CARD, 0xFFEF4444, aRst));
            g.drawString(font, "🗑 Сбросить KitStats", sx + 4, sy + 3,
                AnimationUtil.lerpColor(TEXT_GRAY, 0xFFEF4444, aRst));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  FOOTER
    // ═══════════════════════════════════════════════════════════════
    private void renderFooter(GuiGraphicsExtractor g, int mx, int my) {
        int fy = winY + WIN_H - FOOT_H;
        g.fillGradient(winX, fy, winX + WIN_W, winY + WIN_H, 0xFF080C14, 0xFF060A12);
        // RGB animated bottom border line
        int fr1 = AnimationUtil.rgbCycle(0.25f);
        int fr2 = AnimationUtil.rgbCycleOffset(0.25f, 0.5f);
        g.fillGradient(winX, fy, winX + WIN_W / 2, fy + 1, fr1, fr2);
        g.fillGradient(winX + WIN_W / 2, fy, winX + WIN_W, fy + 1, fr2, fr1);

        // status dot (pulsing)
        float pulse = (float)(0.6 + 0.4 * Math.sin(System.currentTimeMillis() / 350.0));
        int pa = (int)(255 * pulse);
        int statusColor = cfg.enabled ? ACCENT_GREEN : ACCENT_RED;
        g.fill(winX + LEFT_W - 14, fy + 7, winX + LEFT_W - 8, fy + 13, (pa << 24) | (statusColor & 0x00FFFFFF));

        String st = "  Difficulty: " + cfg.difficulty.name()
            + "  |  Mode: " + cfg.mode.name()
            + "  |  " + (cfg.standbyMode ? "⏸ STANDBY" : "⚔ ACTIVE")
            + "  |  Bots: " + cfg.maxBots;
        g.drawString(font, st, winX + LEFT_W + 6, fy + 6, TEXT_GRAY);
        g.drawString(font, "PVPBot v5.0", winX + WIN_W - font.width("PVPBot v5.0") - 6, fy + 6, TEXT_DARK);
    }

    // ═══════════════════════════════════════════════════════════════
    //  TOOLTIP
    // ═══════════════════════════════════════════════════════════════
    private void renderTooltip2(GuiGraphicsExtractor g, String text, int tx, int ty) {
        if (text == null || text.isEmpty()) return;
        int tw = font.width(text) + 10, th = 16;
        if (tx + tw > winX + WIN_W - 2) tx = winX + WIN_W - 2 - tw;
        ty -= th + 4;
        if (ty < winY) ty = winY + 2;
        // shadow
        for (int i = 4; i > 0; i--) {
            int a = (int)(20 * (1f - (float)i / 4));
            g.fill(tx - i, ty - i, tx + tw + i, ty + th + i, (a << 24));
        }
        RenderUtil.rounded(g, tx, ty, tw, th, 4, new Color(BG_TOOLTIP));
        bd(g, tx, ty, tw, th, 0xFF334155);
        g.drawString(font, text, tx + 5, ty + 4, TEXT_BRIGHT);
    }

    // ═══════════════════════════════════════════════════════════════
    //  INPUT
    // ═══════════════════════════════════════════════════════════════
    @Override
    public boolean mouseClicked(double mx0, double my0, int btn) {
        int mx = (int) mx0, my = (int) my0;

        // header tab click
        int tx2 = winX + LEFT_W + 8;
        for (Tab t : Tab.values()) {
            int tw = font.width(t.label) + 14;
            if (mx >= tx2 && mx < tx2 + tw && my >= winY + 2 && my < winY + HEADER_H) {
                tab = t; scrollY = 0; targetScrollY = 0; optMod = null; rebuild(); return true;
            }
            tx2 += tw + 2;
        }

        // close button
        if (mx >= winX + WIN_W - 18 && mx < winX + WIN_W - 4 && my >= winY + 8 && my < winY + 22) {
            onClose(); return true;
        }

        // profile click in left panel
        int px = winX + 4, py = winY + HEADER_H + 16;
        for (int i = 0; i < profiles.size(); i++) {
            int gy = py + i * (PROF_H + PROF_GAP);
            if (mx >= px && mx < px + LEFT_W - 8 && my >= gy && my < gy + PROF_H) {
                for (int j = 0; j < profiles.size(); j++) profiles.get(j).active = (j == i);
                String[] keys = {"pvp","pvp","crystal","uhc","passive"};
                if (i < keys.length) ModuleManager.INSTANCE.loadProfile(keys[i]);
                reloadModState(); applyKitToBots(); rebuild(); return true;
            }
        }
        // "+ NEW PROFILE" and "HUD LAYOUT" sidebar buttons
        int bY = winY + WIN_H - FOOT_H - 48;
        if (mx >= px && mx < px + LEFT_W - 8) {
            if (my >= bY && my < bY + 18) {
                profiles.add(new Prof("Profile " + (profiles.size() + 1), "Custom", ACCENT_BLUE, false));
                rebuild(); return true;
            }
            // HUD LAYOUT button (second row, bY + 23)
        }

        // search focus
        if (tab == Tab.MODS) {
            int sX = winX + LEFT_W + cw() - 94, sY = winY + HEADER_H + 6;
            searchFocus = (mx >= sX && mx < sX + 88 && my >= sY && my < sY + 16);
            if (!searchFocus && optMod != null) {
                if (mx < optPanX || mx > optPanX + 165 || my < optPanY || my > optPanY + 140)
                    optMod = null;
            }
        }

        // diff/profile tab clicks
        if (tab == Tab.KITS)       handleKitsTabClick(mx, my);
        if (tab == Tab.DIFFICULTY) handleDiffTabClick(mx, my);
        if (tab == Tab.PROFILES)   { handleProfPresetsClick(mx, my); handleProfSaveClick(mx, my); }
        if (tab == Tab.SETTINGS)   handleSettingsClick(mx, my);
        if (tab == Tab.MODS && btn == 0) handleCardBodyClick(mx, my);
        if (tab == Tab.SQUAD)      handleSquadTabClick(mx, my);
        if (tab == Tab.ROLES)      handleRolesTabClick(mx, my);
        if (tab == Tab.STATS)      handleStatsClick(mx, my);
        if (tab == Tab.HISTORY)    handleHistoryTabClick(mx, my);

        // drag start
        if (my >= winY && my < winY + HEADER_H) { dragging = true; dragOffX = mx - winX; dragOffY = my - winY; }

        return super.mouseClicked(mx0, my0, btn);
    }

    private int cw() { return WIN_W - LEFT_W - 1; }

    private void handleProfSaveClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 26;
        int pW = 118, pH = 60, pCols = 4, pGap = 5;
        int built = 12;
        int saveY = sy + (built / pCols + 1) * (pH + pGap) + 8 + 14;
        String[] sn = {"pvp", "crystal", "passive"};
        for (int i = 0; i < 3; i++) {
            if (mx >= sx + i * 142 && mx < sx + i * 142 + 132 && my >= saveY && my < saveY + 16) {
                ModuleManager.INSTANCE.saveProfile(sn[i]); BotConfig.save(); return;
            }
        }

        // ── Экспорт ────────────────────────────────────────────────
        int expY = saveY + 26 + 14;
        if (mx >= sx && mx < sx + 130 && my >= expY && my < expY + 18) {
            // Имя профиля = текущий активный профиль
            String pname = profiles.stream()
                .filter(p -> p.active).findFirst()
                .map(p -> p.name.replaceAll("\\s+", "_"))
                .orElse("my_profile");
            boolean ok = BotConfig.exportProfile(pname);
            if (minecraft != null && minecraft.player != null) {
                String msg = ok ? "§a[PVPBot] Профиль экспортирован: " + pname + ".json"
                                : "§c[PVPBot] Ошибка экспорта!";
                minecraft.gui.getChat().addMessage(
                    net.minecraft.network.chat.Component.literal(msg));
            }
            return;
        }

        // ── Импорт ────────────────────────────────────────────────
        int impX = sx + 140;
        expY += 12;
        java.util.List<String> savedProfiles = BotConfig.listProfiles();
        for (int i = 0; i < Math.min(savedProfiles.size(), 5); i++) {
            int py2 = expY + i * 16;
            if (mx >= impX && mx < impX + 200 && my >= py2 && my < py2 + 14) {
                String pname = savedProfiles.get(i);
                boolean ok = BotConfig.importProfile(pname);
                if (minecraft != null && minecraft.player != null) {
                    String msg = ok ? "§a[PVPBot] Профиль загружен: " + pname
                                    : "§c[PVPBot] Ошибка импорта!";
                    minecraft.gui.getChat().addMessage(
                        net.minecraft.network.chat.Component.literal(msg));
                }
                reloadModState(); rebuild(); return;
            }
        }
    }

    private void handleHistoryTabClick(int mx, int my) {
        // Кнопка "Очистить историю FightAnalyzer"
        // Позиция кнопки вычисляется аналогично renderHistoryTab
        int sx = winX + LEFT_W + 10;
        // Приблизительный Y кнопки (после таблицы боёв)
        // Упрощённо — ищем по mx/my в нижней части экрана
        int approxBtnY = winY + HEADER_H + 170; // подбирается по рендеру
        if (mx >= sx && mx < sx + 100 && my >= approxBtnY - 20 && my < approxBtnY + 40) {
            FightAnalyzer.INSTANCE.clearHistory();
            if (minecraft != null && minecraft.player != null)
                minecraft.gui.getChat().addMessage(
                    net.minecraft.network.chat.Component.literal("§7[PVPBot] История боёв очищена."));
            rebuild();
        }
    }

    private void handleStatsClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 8 + 18 + 52 + 12 + 14 + 14;
        // Reset Stats
        if (mx >= sx && mx < sx + 100 && my >= sy && my < sy + 14) {
            KillDeathTracker.reset(); rebuild(); return;
        }
        // Kit Stats (old command button — now replaced by inline table, keep for compat)
        if (mx >= sx + 110 && mx < sx + 210 && my >= sy && my < sy + 14) {
            if (minecraft != null && minecraft.player != null)
                minecraft.player.connection.sendCommand("bot kitstats");
        }

        // KitStats reset button — approximate Y position after kit table
        // (after bar chart + session info + kit table header + rows)
        int kitResetY = winY + HEADER_H + 8 + 18 + 52 + 12 + 14 + 14 + 48 + 30 + 18 + 14
            + (KitStatsTracker.INSTANCE.getAllRecords().size() * 12) + 4;
        if (mx >= sx && mx < sx + 90 && my >= kitResetY - 20 && my < kitResetY + 30) {
            KitStatsTracker.INSTANCE.reset();
            rebuild(); return;
        }
    }

    private void handleDiffTabClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 26;
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int dcW = (WIN_W - LEFT_W - 20) / 4 - 5;
        for (int i = 0; i < 4; i++) {
            int dx = sx + i * (dcW + 5);
            if (mx >= dx && mx < dx + dcW && my >= sy && my < sy + 140) {
                cfg.difficulty = diffs[i]; cfg.applyDifficulty(); BotConfig.save(); rebuild(); break;
            }
        }
    }

    private void handleProfPresetsClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 26;
        String[] keys = {"pvp","pve","crystal","passive","smp","uhc","nethpot","axe","tpc","obsidian_crystal","snowball","shield_sword"};
        int pW = 118, pH = 60, pCols = 4, pGap = 5;
        for (int i = 0; i < keys.length; i++) {
            int col = i % pCols, row = i / pCols;
            int bx = sx + col * (pW + pGap), by = sy + row * (pH + pGap);
            if (mx >= bx && mx < bx + pW && my >= by && my < by + pH) {
                ModuleManager.INSTANCE.loadProfile(keys[i]); reloadModState(); applyKitToBots(); rebuild(); break;
            }
        }
    }

    private void handleSettingsClick(int mx, int my) {
        int sx = winX + LEFT_W + 12, sy = winY + HEADER_H + 8;

        // Difficulty buttons
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int dcW = 58;
        for (int i = 0; i < 4; i++) {
            int dx = sx + i * (dcW + 4), dy = sy + 14;
            if (mx >= dx && mx < dx + dcW && my >= dy && my < dy + 22) {
                cfg.difficulty = diffs[i]; cfg.applyDifficulty(); BotConfig.save(); rebuild(); return;
            }
        }

        // Mode buttons
        PVPBotConfig.Mode[] modes = PVPBotConfig.Mode.values();
        int mY = sy + 48;
        int modesPerRowC = 7;
        int availWC = WIN_W - LEFT_W - 20;
        int mcWC = (availWC - (modesPerRowC - 1) * 3) / modesPerRowC;
        for (int i = 0; i < modes.length; i++) {
            int mc2 = i % modesPerRowC, mr = i / modesPerRowC;
            int mx2 = sx + mc2 * (mcWC + 3), my2 = mY + mr * (20 + 3);
            if (mx >= mx2 && mx < mx2 + mcWC && my >= my2 && my < my2 + 20) {
                cfg.mode = modes[i]; BotConfig.save(); applyKitToBots(); rebuild(); return;
            }
        }

        // Quick Toggles
        int tY = mY + (modes.length / modesPerRowC + 2) * (20 + 3) + 6 + 14;
        String[] togLabels1 = {"W-Tap","Pearls","Crystals","Standby","PatternAI"};
        String[] togLabels2 = {"AdaptCD","Whitelist","Bunker","Hunt","Training"};
        for (int i = 0; i < togLabels1.length; i++) {
            int tx = sx + i * 96;
            if (mx >= tx && mx < tx + 88 && my >= tY && my < tY + 16) {
                switch (i) {
                    case 0 -> cfg.wTapEnabled = !cfg.wTapEnabled;
                    case 1 -> cfg.diffUsePearls = !cfg.diffUsePearls;
                    case 2 -> cfg.diffUseCrystals = !cfg.diffUseCrystals;
                    case 3 -> cfg.standbyMode = !cfg.standbyMode;
                    case 4 -> cfg.patternAIEnabled = !cfg.patternAIEnabled;
                }
                BotConfig.save(); rebuild(); return;
            }
        }
        for (int i = 0; i < togLabels2.length; i++) {
            int tx = sx + i * 96;
            if (mx >= tx && mx < tx + 88 && my >= tY + 22 && my < tY + 38) {
                switch (i) {
                    case 0 -> cfg.adaptiveCooldownEnabled = !cfg.adaptiveCooldownEnabled;
                    case 1 -> cfg.whitelistEnabled = !cfg.whitelistEnabled;
                    case 2 -> cfg.bunkerEnabled = !cfg.bunkerEnabled;
                    case 3 -> cfg.huntEnabled = !cfg.huntEnabled;
                    case 4 -> cfg.trainingMode = !cfg.trainingMode;
                }
                BotConfig.save(); rebuild(); return;
            }
        }

        // Strafe toggle
        int strafeY = tY + 44;
        if (mx >= sx && mx < sx + 88 && my >= strafeY && my < strafeY + 16) {
            cfg.strafeEnabled = !cfg.strafeEnabled;
            BotConfig.save(); rebuild(); return;
        }
        // Strafe style buttons
        StrafeAI.StrafeStyle[] styles = StrafeAI.StrafeStyle.values();
        int styleX = sx + 96;
        for (StrafeAI.StrafeStyle style : styles) {
            if (mx >= styleX && mx < styleX + 58 && my >= strafeY && my < strafeY + 16) {
                cfg.strafeStyle = style;
                BotConfig.save(); rebuild(); return;
            }
            styleX += 62;
        }

        // +/- parameter buttons (ниже strafe-ряда — +30px)
        int nY = tY + 48 + 30 + 14;
        int[][] pmOffsets = {{sx, nY}, {sx+210, nY}, {sx, nY+20}, {sx+210, nY+20}, {sx, nY+40}, {sx+210, nY+40}};
        for (int i = 0; i < pmOffsets.length; i++) {
            int bx = pmOffsets[i][0] + 148, by = pmOffsets[i][1];
            if (my >= by && my < by + 12) {
                if (mx >= bx && mx < bx + 14) { // minus
                    switch(i) {
                        case 0 -> cfg.attackCooldown = Math.max(1, cfg.attackCooldown - 1);
                        case 1 -> cfg.attackRange = Math.max(1, cfg.attackRange - .5);
                        case 2 -> cfg.maxBots = Math.max(1, cfg.maxBots - 1);
                        case 3 -> cfg.diffCrystalDamage = Math.max(5, cfg.diffCrystalDamage - 1);
                        case 4 -> cfg.botMaxHealth = Math.max(20, cfg.botMaxHealth - 2);
                        case 5 -> cfg.botHealThreshold = Math.max(1, cfg.botHealThreshold - 1);
                    }
                    BotConfig.save(); rebuild(); return;
                }
                if (mx >= bx + 16 && mx < bx + 30) { // plus
                    switch(i) {
                        case 0 -> cfg.attackCooldown = Math.min(30, cfg.attackCooldown + 1);
                        case 1 -> cfg.attackRange = Math.min(6, cfg.attackRange + .5);
                        case 2 -> cfg.maxBots = Math.min(20, cfg.maxBots + 1);
                        case 3 -> cfg.diffCrystalDamage = Math.min(30, cfg.diffCrystalDamage + 1);
                        case 4 -> cfg.botMaxHealth = Math.min(200, cfg.botMaxHealth + 2);
                        case 5 -> cfg.botHealThreshold = Math.min(40, cfg.botHealThreshold + 1);
                    }
                    BotConfig.save(); rebuild(); return;
                }
            }
        }

        // ── CLIENT SOUNDS — клики по режимам ──────────────────────
        // sy позиции секции SOUND: после PARAMETERS (sy+80 от начала PARAMETERS)
        // Приблизительно вычисляем sy звуковой секции
        int soundBaseY = winY + HEADER_H + 8 + 14 + 22 + 14 + 22 + 14 + 30 + 14 + 80 + 14;
        ClientSounds.SoundMode[] soundModes = ClientSounds.modes();
        int btnW = 68, btnH = 16, btnGap = 4, perRow = 5;
        for (int i = 0; i < soundModes.length; i++) {
            int col = i % perRow, row = i / perRow;
            int bx = sx + col * (btnW + btnGap);
            int by = soundBaseY + row * (btnH + btnGap);
            if (mx >= bx && mx < bx + btnW && my >= by && my < by + btnH) {
                ClientSounds.INSTANCE.setMode(soundModes[i]);
                ClientSounds.INSTANCE.playEnable(); // превью звука при выборе
                rebuild(); return;
            }
        }

        // Ползунок громкости
        int sliderRows = (int) Math.ceil(soundModes.length / (float) perRow);
        int volY = soundBaseY + sliderRows * (btnH + btnGap) + 6;
        int slX = sx + 52, slW = 160;
        if (mx >= slX && mx < slX + slW && my >= volY && my < volY + 14) {
            float vol = (float)(mx - slX) / slW;
            ClientSounds.INSTANCE.setVolume(vol);
            rebuild(); return;
        }

        // Кнопка Test
        int testX = sx + 52 + slW + 40;
        if (mx >= testX && mx < testX + 40 && my >= volY && my < volY + 14) {
            ClientSounds.INSTANCE.playEnable();
            return;
        }

        // ── WEB CONFIG toggle (≈24px ниже Test button) ───────────
        int wcY = volY + 24 + 14; // после секции SOUND (заголовок + тест)
        if (mx >= sx && mx < sx + 120 && my >= wcY && my < wcY + 18) {
            cfg.webConfigEnabled = !cfg.webConfigEnabled;
            if (cfg.webConfigEnabled) {
                WebConfig.INSTANCE.start(cfg.webConfigPort);
            } else {
                WebConfig.INSTANCE.stop();
            }
            BotConfig.save(); rebuild(); return;
        }

        // ── AUTO CHAT toggle ─────────────────────────────────────
        int acY = wcY + 26 + 14; // после WebConfig секции
        if (mx >= sx && mx < sx + 100 && my >= acY && my < acY + 16) {
            cfg.autoChatEnabled = !cfg.autoChatEnabled;
            BotConfig.save(); rebuild(); return;
        }

        // ── BOT LEARNING buttons ─────────────────────────────────
        int blY = acY + 20 + 18 + 18 + 24 + 14; // после AutoChat секции
        int blBtnW = 72;
        for (int i = 0; i < 3; i++) {
            int bx = sx + i * (blBtnW + 4);
            if (mx >= bx && mx < bx + blBtnW && my >= blY && my < blY + 16) {
                switch (i) {
                    case 0 -> BotLearning.INSTANCE.startRecording();
                    case 1 -> BotLearning.INSTANCE.stopRecording();
                    case 2 -> BotLearning.INSTANCE.reset();
                }
                rebuild(); return;
            }
        }
    }

    private void handleCardBodyClick(int mx, int my) {
        int[] l = layout(); int sX = l[0], sY = l[1];
        int col = 0, row = 0;
        for (Object[] mod : MODS) {
            String name = (String) mod[0], key = (String) mod[1];
            ModCat mc = (ModCat) mod[2]; boolean isN = (boolean) mod[3];
            if (!filter(name, mc, isN)) continue;
            int cx = sX + col * (CARD_W + CARD_GAP), cy = sY + row * (CARD_H + CARD_GAP) - scrollY;

            if (mx >= cx && mx < cx + CARD_W && my >= cy && my < cy + CARD_H) {
                // ENABLED кнопка (нижняя левая часть карточки)
                if (my >= cy + CARD_H - 18 && my < cy + CARD_H - 4 && mx < cx + CARD_W - 30) {
                    boolean cur = mstate.getOrDefault(key, false);
                    mstate.put(key, !cur); setB(key, !cur); BotConfig.save(); rebuild();
                    playToggleSound(!cur); return;
                }
                // OPTIONS/GEAR кнопка (нижний правый угол)
                if (my >= cy + CARD_H - 18 && my < cy + CARD_H - 4 && mx >= cx + CARD_W - 30) {
                    optMod = name.equals(optMod) ? null : name;
                    optPanX = cx + CARD_W + 3;
                    optPanY = Math.min(cy, winY + WIN_H - FOOT_H - 135);
                    if (optPanX + 165 > winX + WIN_W) optPanX = cx - 168;
                    rebuild(); return;
                }
                // клик по верхней части карточки — тоже тогл
                if (my < cy + CARD_H - 36) {
                    boolean cur = mstate.getOrDefault(key, false);
                    mstate.put(key, !cur); setB(key, !cur); BotConfig.save(); rebuild();
                    playToggleSound(!cur); return;
                }
            }
            col++; if (col >= COLS) { col = 0; row++; }
        }
    }

    @Override
    public boolean mouseDragged(double mx0, double my0, int btn, double dx, double dy) {
        if (dragging && minecraft != null) {
            winX = (int) mx0 - dragOffX;
            winY = (int) my0 - dragOffY;
            winX = Math.max(0, Math.min(width - WIN_W, winX));
            winY = Math.max(0, Math.min(height - WIN_H, winY));
            rebuild();
        }
        if (draggingSquadSlider && tab == Tab.SQUAD) {
            updateSquadSlider((int) mx0);
        }
        return super.mouseDragged(mx0, my0, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = false; dragSlider = -1; draggingSquadSlider = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        if (tab == Tab.MODS) {
            targetScrollY = Math.max(0, Math.min(maxScroll(), targetScrollY - (int)(dy * 14)));
            return true;
        }
        return super.mouseScrolled(mx, my, dx, dy);
    }

    @Override
    public boolean keyPressed(int k, int sc, int mods) {
        if (searchFocus) {
            if (k == 259) { if (!search.isEmpty()) { search = search.substring(0, search.length() - 1); } return true; }
            if (k == 256) { if (!search.isEmpty()) { search = ""; return true; } searchFocus = false; return false; }
        }
        if (k == 256) { onClose(); return true; }
        return super.keyPressed(k, sc, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (searchFocus && c >= 32) { search += c; targetScrollY = 0; return true; }
        return super.charTyped(c, mods);
    }

    // ═══════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════
    private int[] layout() {
        return new int[]{ winX + LEFT_W + 6, winY + HEADER_H + SUB_H + 6, WIN_H - HEADER_H - SUB_H - FOOT_H - 12 };
    }

    private int maxScroll() {
        int cnt = 0;
        for (Object[] m : MODS) if (filter((String) m[0], (ModCat) m[2], (boolean) m[3])) cnt++;
        int rows = (cnt + COLS - 1) / COLS;
        return Math.max(0, rows * (CARD_H + CARD_GAP) - (WIN_H - HEADER_H - SUB_H - FOOT_H - 12));
    }

    private boolean filter(String name, ModCat mc, boolean isN) {
        if (!search.isEmpty()) return name.toLowerCase().contains(search.toLowerCase());
        return switch (cat) {
            case ALL -> true; case NEW -> isN; case HUD -> mc == ModCat.HUD;
            case SERVER -> mc == ModCat.SERVER; case MECHANIC -> mc == ModCat.MECHANIC;
            case COMBAT -> mc == ModCat.COMBAT; case VISUAL -> mc == ModCat.VISUAL;
            case UTILITY -> mc == ModCat.UTILITY;
            default     -> false;
        };
    }

    private int modeColor(PVPBotConfig.Mode m) {
        return switch (m) {
            case SWORD, TRIDENT, CROSSBOW -> 0xFF3388FF;  // голубой меч
            case AXE                      -> 0xFF4499CC;  // голубой топор
            case MACE, MACE_ELYTRA        -> 0xFF888888;  // серая булава
            case UHC, TOTEM               -> 0xFFCC2222;  // красное сердце
            case NETHOP, NETHPOT          -> 0xFF9933CC;  // фиолетовый череп
            case POT                      -> 0xFFCC44BB;  // розовая колба
            case SMP                      -> 0xFF1A8040;  // зелёный жемчуг
            case CRYSTAL, TPC             -> 0xFF00CFFF;  // голубой кристалл
            case SNOWBALL                 -> 0xFF88AACC;
            case BEEHIVE                  -> 0xFFDDA020;
            case FIREWORK                 -> 0xFFFF4444;
            default                       -> 0xFFC0A050;
        };
    }

    private int diffCol(PVPBotConfig.Difficulty d) {
        return switch (d) {
            case EASY   -> 0xFF22C55E;
            case MEDIUM -> 0xFFEAB308;
            case HARD   -> 0xFFEF4444;
            case EXPERT -> 0xFF991B1B;
            default     -> 0xFFFFFFFF;
        };
    }

    private void secTitle(GuiGraphicsExtractor g, String t, int sx, int sy) {
        g.drawString(font, t, sx, sy, ACCENT_BLUE);
        g.fill(sx + font.width(t) + 5, sy + 4, sx + cw() - 10, sy + 5, 0xFF1A2540);
    }

    private boolean getB(String f) {
        try { return (boolean) cfg.getClass().getField(f).get(cfg); } catch (Exception e) { return false; }
    }

    private void setB(String f, boolean v) {
        try { cfg.getClass().getField(f).set(cfg, v); } catch (Exception e) {
            switch (f) {
                case "autoAttack"               -> cfg.autoAttack = v;
                case "autoDodge"                -> cfg.autoDodge = v;
                case "autoHeal"                 -> cfg.autoHeal = v;
                case "autoGapEnabled"           -> cfg.autoGapEnabled = v;
                case "autoArmor"                -> cfg.autoArmor = v;
                case "autoTotem"                -> cfg.autoTotem = v;
                case "autoEat"                  -> cfg.autoEat = v;
                case "wTapEnabled"              -> cfg.wTapEnabled = v;
                case "sTapEnabled"              -> cfg.sTapEnabled = v;
                case "autoSprint"               -> cfg.autoSprint = v;
                case "autoCrystal"              -> cfg.autoCrystal = v;
                case "autoBowEnabled"           -> cfg.autoBowEnabled = v;
                case "kiteEnabled"              -> cfg.kiteEnabled = v;
                case "espEnabled"               -> cfg.espEnabled = v;
                case "radarEnabled"             -> cfg.radarEnabled = v;
                case "tracersEnabled"           -> cfg.tracersEnabled = v;
                case "autoRespawn"              -> cfg.autoRespawn = v;
                case "autoLogEnabled"           -> cfg.autoLogEnabled = v;
                case "autoPearlEnabled"         -> cfg.autoPearlEnabled = v;
                case "showHud"                  -> cfg.showHud = v;
                case "showDps"                  -> cfg.showDps = v;
                case "statsEnabled"             -> cfg.statsEnabled = v;
                case "patternAIEnabled"         -> cfg.patternAIEnabled = v;
                case "antiPatternEnabled"       -> cfg.antiPatternEnabled = v;
                case "trainingMode"             -> cfg.trainingMode = v;
                case "autoKitSelect"            -> cfg.autoKitSelect = v;
                case "notificationsEnabled"     -> cfg.notificationsEnabled = v;
                case "adaptiveCooldownEnabled"  -> cfg.adaptiveCooldownEnabled = v;
                case "fakeAttackEnabled"        -> cfg.fakeAttackEnabled = v;
                case "bunkerEnabled"            -> cfg.bunkerEnabled = v;
                case "huntEnabled"              -> cfg.huntEnabled = v;
                case "standbyMode"              -> cfg.standbyMode = v;
                case "whitelistEnabled"         -> cfg.whitelistEnabled = v;
                case "toggleSneak"              -> cfg.toggleSneak = v;
            default -> {}
            }
        }
    }

    // draw primitives
    private void fr(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) { g.fill(x, y, x+w, y+h, c); }
    private void bd(GuiGraphicsExtractor g, int x, int y, int w, int h, int c) {
        g.fill(x,y,x+w,y+1,c); g.fill(x,y+h-1,x+w,y+h,c);
        g.fill(x,y,x+1,y+h,c); g.fill(x+w-1,y,x+w,y+h,c);
    }

    /** Звук при тогле модуля: включение → высокий клик, выключение → низкий. */
    /**
     * Звук тогла через ClientSounds (WAV из ресурсов, стиль чит-клиента).
     */
    private void playToggleSound(boolean enabled) {
        if (enabled) ClientSounds.INSTANCE.playEnable();
        else         ClientSounds.INSTANCE.playDisable();
    }
    private String trunc(String s, int maxW) {
        if (font.width(s) <= maxW) return s;
        while (!s.isEmpty() && font.width(s + "…") > maxW) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { AnimationUtil.clear(); BotConfig.save(); super.onClose(); }
    @Override public void tick() {
        super.tick();
        scrollY = Math.max(0, Math.min(maxScroll(), scrollY));
        targetScrollY = Math.max(0, Math.min(maxScroll(), targetScrollY));
    }

    // ═══════════════════════════════════════════════════════════════
    //  SQUAD TAB  —  пресеты отрядов с выбором количества
    // ═══════════════════════════════════════════════════════════════

    /**
     * Пресеты отрядов:
     * { id, icon, название, описание, цвет акцента, kitCmd, minSize, maxSize, roleTag }
     *
     * roleTag — суффикс для /bot squad create чтобы передать тип:
     *   "standard"  → обычный смешанный отряд
     *   "axe"       → все с топором
     *   "smp"       → SMP (меч/щит/еда)
     *   "elytra"    → элитрасты + булава (1–5 чел)
     *   "crystal"   → crystal PvP
     *   "nethpot"   → зельеварщики
     *   "uhc"       → UHC (лук + меч)
     */
    private static final Object[][] SQUAD_PRESETS = {
        // id          icon  название             описание строка 1           описание строка 2      цвет акцента     kitCmd    min max  roleTag
        { "standard",  "kit_sword",   "Стандартный",      "Автороли: Элита·Медик",   "Танкер·Солдаты",     0xFF3B82F6, "sword",    3, 30, "standard" },
        { "axe",       "kit_axe",     "Топорщики",         "Все бойцы с нетерит",      "топором и щитом",    0xFFFB923C, "axe",      2, 30, "axe"      },
        { "smp",       "kit_smp",     "SMP Отряд",         "Алмаз·Меч·Щит",           "Стиль выживача",     0xFF22C55E, "smp",      2, 30, "smp"      },
        { "elytra",    "kit_elytra",  "Элитра + Булава",   "1–5 бойцов пикируют",      "сверху с булавой",   0xFF8B5CF6, "mace_elytra", 1, 5, "elytra" },
        { "crystal",   "kit_crystal", "Crystal PvP",       "Нетерит + End Crystal",    "Тотемы·Кристаллы",  0xFF60A5FA, "crystal",  2, 20, "crystal"  },
        { "nethpot",   "kit_nethpot", "Зельеварщики",      "Зелья·Урон·Лечение",       "Iron броня·Splash",  0xFFA855F7, "nethpot",  3, 20, "nethpot"  },
        { "uhc",       "kit_uhc",     "UHC Отряд",         "Алмаз·Лук·Яблоки",        "Без регена ХП",      0xFFEF4444, "uhc",      2, 20, "uhc"      },
        { "tpc",       "kit_tpc",     "TPC Элита",         "Топор+Кристалл+Тотем",    "Высший уровень",     0xFFE879F9, "tpc",      2, 15, "tpc"      },
    };

    // кэш Y координат карточек пресетов для mouseClicked
    private final int[] squadPresetY = new int[SQUAD_PRESETS.length];
    private int squadPresetX0, squadPresetW, squadPresetH;
    // кэш слайдера
    private int squadSliderX, squadSliderY, squadSliderW;

    private void buildSquadWidgets() {
        // Все кнопки рендерятся кастомно в renderSquadTab, клики в handleSquadTabClick
    }

    private void renderSquadTab(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // ── Заголовок ─────────────────────────────────────────────
        g.drawString(font, "⚔  ОТРЯДЫ — ВЫБОР ТИПА И РАЗМЕРА", sx, sy, ACCENT_BLUE);
        sy += 14;
        g.drawString(font, "Выберите тип · настройте количество · нажмите Создать", sx, sy, TEXT_GRAY);
        sy += 16;

        // ── Сетка пресетов 4×2 ────────────────────────────────────
        int cols = 4;
        int cardW = 118, cardH = 72, cardGap = 5;
        squadPresetW = cardW; squadPresetH = cardH; squadPresetX0 = sx;

        for (int i = 0; i < SQUAD_PRESETS.length; i++) {
            Object[] p = SQUAD_PRESETS[i];
            int acc    = (int)(long)(Integer) p[5];
            int minS   = (int) p[7];
            int maxS   = (int) p[8];

            int col = i % cols, row = i / cols;
            int bx = sx + col * (cardW + cardGap);
            int by = sy + row * (cardH + cardGap);
            squadPresetY[i] = by;

            boolean sel  = (squadSelectedPreset == i);
            boolean hov  = mx >= bx && mx < bx + cardW && my >= by && my < by + cardH;
            float anim   = AnimationUtil.tick("sq_preset_" + i, (hov || sel) ? 1f : 0f, 0.18f);

            // Фон карточки
            int bgCard = sel
                ? AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x30000000, 1f)
                : AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x18000000, anim);
            RenderUtil.rounded(g, bx, by, cardW, cardH, 6, new java.awt.Color(bgCard));

            // Акцент-полоска сверху
            float stripA = sel ? 1f : anim;
            int stripAlpha = (int)(255 * stripA);
            g.fillGradient(bx + 6, by, bx + cardW - 6, by + 3,
                (stripAlpha << 24) | (acc & 0x00FFFFFF), 0);

            // Рамка
            bd(g, bx, by, cardW, cardH,
                sel ? acc : AnimationUtil.lerpColor(BORDER_CARD, acc, anim * 0.6f));

            // Выбранный — дополнительный glow
            if (sel) {
                for (int gi = 2; gi > 0; gi--) {
                    int ga = 0x15;
                    g.fill(bx - gi, by - gi, bx + cardW + gi, by + cardH + gi,
                        (ga << 24) | (acc & 0x00FFFFFF));
                }
            }

            // Иконка + название
            IconRenderer.draw(g, (String) p[1], bx + 4, by + 6, 10);
            g.drawString(font, (String) p[2], bx + 18, by + 7,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, anim));

            // Описание
            g.drawString(font, (String) p[3], bx + 5, by + 22, TEXT_GRAY);
            g.drawString(font, (String) p[4], bx + 5, by + 32, TEXT_GRAY);

            // Мин/макс
            String sizeStr = "👥 " + minS + "–" + maxS + " бойцов";
            g.drawString(font, sizeStr, bx + 5, by + 44, sel ? acc : TEXT_DARK);

            // Кит
            g.drawString(font, "⚙ " + ((String) p[6]).toUpperCase(), bx + 5, by + 54,
                sel ? AnimationUtil.lerpColor(TEXT_GRAY, acc, 0.8f) : TEXT_DARK);

            // Галочка выбора
            if (sel) {
                fr(g, bx + cardW - 14, by + cardH - 14, 13, 13,
                    (acc & 0x00FFFFFF) | 0xFF000000);
                g.drawString(font, "✓", bx + cardW - 11, by + cardH - 12, 0xFFFFFFFF);
            }
        }

        int gridBottom = sy + 2 * (cardH + cardGap) + 4;

        // ── Слайдер количества ────────────────────────────────────
        int slY = gridBottom + 6;
        g.drawString(font, "КОЛИЧЕСТВО БОЙЦОВ:", sx, slY, TEXT_WHITE); slY += 12;

        // Ограничение по выбранному пресету
        int minAllowed = 1, maxAllowed = 30;
        if (squadSelectedPreset >= 0) {
            minAllowed = (int) SQUAD_PRESETS[squadSelectedPreset][7];
            maxAllowed = (int) SQUAD_PRESETS[squadSelectedPreset][8];
        }
        squadCount = Math.max(minAllowed, Math.min(maxAllowed, squadCount));

        int slW = cw - 30, slH = 8;
        int slX = sx;
        squadSliderX = slX; squadSliderY = slY; squadSliderW = slW;

        // Трек
        fr(g, slX, slY + 2, slW, slH, 0xFF1A2035);
        // Заполнение
        float frac = (float)(squadCount - minAllowed) / Math.max(1, maxAllowed - minAllowed);
        int fillW  = (int)(slW * frac);
        int slAcc  = squadSelectedPreset >= 0
            ? (int)(long)(Integer) SQUAD_PRESETS[squadSelectedPreset][5]
            : ACCENT_BLUE;
        g.fillGradient(slX, slY + 2, slX + fillW, slY + 2 + slH, slAcc,
            (slAcc & 0x00FFFFFF) | 0xAA000000);
        // Ручка
        int kx = slX + fillW - 4;
        fr(g, kx, slY, 8, slH + 4, slAcc);
        bd(g, kx, slY, 8, slH + 4, TEXT_WHITE);

        slY += slH + 8;

        // Цифры
        String countLabel = "× " + squadCount + (squadCount >= 20 ? "  §aАвторолиСрабатывают!" : "");
        g.drawString(font, "× " + squadCount, sx, slY, slAcc);

        // Подсказка авто-ролей
        if (squadCount >= 20) {
            g.drawString(font, "✦ Авто-роли: Элита · Медик · Танкер · Солдаты",
                sx + 30, slY, ACCENT_GREEN);
        }
        slY += 14;

        // Быстрые кнопки количества
        int[] quickNums = {1, 3, 5, 10, 15, 20, 25, 30};
        int qx = sx;
        for (int n : quickNums) {
            if (n < minAllowed || n > maxAllowed) { qx += 28; continue; }
            boolean qsel = (squadCount == n);
            boolean qhov = mx >= qx && mx < qx + 24 && my >= slY && my < slY + 14;
            float qa = AnimationUtil.tick("sq_quick_" + n, (qhov || qsel) ? 1f : 0f, 0.2f);
            int qbg = AnimationUtil.lerpColor(BG_CARD, slAcc & 0x00FFFFFF | 0x40000000, qa);
            fr(g, qx, slY, 24, 14, qbg);
            bd(g, qx, slY, 24, 14, qsel ? slAcc : BORDER_CARD);
            g.drawString(font, String.valueOf(n), qx + (n >= 10 ? 2 : 6), slY + 3,
                qsel ? TEXT_WHITE : TEXT_GRAY);
            qx += 28;
        }

        // ── Выбранный пресет — итоговая панель ────────────────────
        if (squadSelectedPreset >= 0) {
            Object[] sel = SQUAD_PRESETS[squadSelectedPreset];
            int pacc = (int)(long)(Integer) sel[5];
            int panY = slY + 20;
            int panW = cw - 20, panH = 32;
            RenderUtil.rounded(g, sx, panY, panW, panH, 5,
                new java.awt.Color((pacc & 0x00FFFFFF) | 0x20000000, true));
            bd(g, sx, panY, panW, panH, pacc);
            g.drawString(font, (String) sel[1] + " " + (String) sel[2],
                sx + 8, panY + 6, pacc);
            String kitInfo = "Кит: " + ((String) sel[6]).toUpperCase()
                + "  ·  Бойцов: " + squadCount
                + "  ·  /bot spawn " + squadCount + " → /bot squad create";
            g.drawString(font, kitInfo, sx + 8, panY + 18, TEXT_GRAY);
        }

        // ── Кнопки управления отрядом (кастомный рендер) ─────────
        int bbY = winY + WIN_H - FOOT_H - 32;
        String[][] btns = {{"⚔  СОЗДАТЬ ОТРЯД", "160"}, {"✕  Расформировать", "130"}, {"📋  Статус", "90"}};
        int[] bAccents = {ACCENT_GREEN, ACCENT_RED, ACCENT_BLUE};
        int bbX = sx;
        for (int i = 0; i < btns.length; i++) {
            int bW = Integer.parseInt(btns[i][1]);
            boolean hov = mx >= bbX && mx < bbX + bW && my >= bbY && my < bbY + 20;
            float ba = AnimationUtil.tick("squad_btn_" + i, hov ? 1f : 0f, 0.2f);
            int bbg = AnimationUtil.lerpColor(BG_CARD, (bAccents[i] & 0x00FFFFFF) | 0x25000000, ba);
            RenderUtil.rounded(g, bbX, bbY, bW, 20, 4, new Color(bbg));
            bd(g, bbX, bbY, bW, 20, AnimationUtil.lerpColor(BORDER_CARD, bAccents[i], ba));
            g.drawString(font, btns[i][0], bbX + 6, bbY + 6,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, ba));
            bbX += bW + 8;
        }
    }

    /** Кнопка Создать: спавним нужное количество ботов с нужным китом и создаём отряд. */
    private void spawnSquad() {
        if (squadSelectedPreset < 0) return;
        Object[] p = SQUAD_PRESETS[squadSelectedPreset];
        String kit = (String) p[6];
        // /bot spawn <count>  →  /bot kit <kit>  →  /bot squad create
        sendCmd("bot spawn " + squadCount);
        sendCmd("bot kit " + kit);
        sendCmd("bot squad create");
    }

    private void sendCmd(String cmd) {
        if (minecraft != null && minecraft.player != null)
            minecraft.player.connection.sendCommand(cmd);
    }

    /**
     * Применяет кит соответствующий текущему cfg.mode ко всем активным ботам.
     * Вызывается при смене режима/профиля из GUI.
     */
    private void applyKitToBots() {
        BotKit kit = modeToKit(cfg.mode);
        if (kit != null) sendCmd("kit " + kit.id);
    }

    /** Маппинг Mode → BotKit. */
    private static BotKit modeToKit(PVPBotConfig.Mode mode) {
        return switch (mode) {
            case SWORD          -> BotKit.SWORD;
            case CRYSTAL        -> BotKit.CRYSTAL;
            case SMP            -> BotKit.SMP;
            case UHC            -> BotKit.UHC;
            case NETHPOT        -> BotKit.NETHPOT;
            case AXE            -> BotKit.AXE;
            case TPC            -> BotKit.TPC;
            case MACE           -> BotKit.MACE;
            case MACE_ELYTRA    -> BotKit.MACE_ELYTRA;
            case BEEHIVE        -> BotKit.BEEHIVE;
            case FIREWORK       -> BotKit.FIREWORK;
            case CROSSBOW       -> BotKit.CROSSBOW;
            case TRIDENT        -> BotKit.TRIDENT;
            case TOTEM          -> BotKit.TOTEM;
            case SNOWBALL       -> BotKit.SNOWBALL;
            case NETHOP         -> BotKit.NETHOP;
            case POT            -> BotKit.POT;
        };
    }

    // Обработка кликов вкладки SQUAD
    private void handleSquadTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 10;
        int cy = winY + HEADER_H + 38;
        int cols = 4, cardW = 118, cardH = 72, cardGap = 5;

        // Клики по карточкам пресетов
        for (int i = 0; i < SQUAD_PRESETS.length; i++) {
            int col = i % cols, row = i / cols;
            int bx = cx + col * (cardW + cardGap);
            int by = cy + row * (cardH + cardGap);
            if (mx >= bx && mx < bx + cardW && my >= by && my < by + cardH) {
                squadSelectedPreset = (squadSelectedPreset == i) ? -1 : i;
                // Скорректировать количество под лимиты пресета
                if (squadSelectedPreset >= 0) {
                    int mn = (int) SQUAD_PRESETS[squadSelectedPreset][7];
                    int mx2 = (int) SQUAD_PRESETS[squadSelectedPreset][8];
                    squadCount = Math.max(mn, Math.min(mx2, squadCount));
                }
                rebuild();
                return;
            }
        }

        // Клики по быстрым кнопкам количества
        int gridBottom = cy + 2 * (cardH + cardGap) + 4;
        int slY = gridBottom + 6 + 12 + 8 + 8 + 8 + 14; // approximate
        int[] quickNums = {1, 3, 5, 10, 15, 20, 25, 30};
        int qx = cx;
        for (int n : quickNums) {
            if (mx >= qx && mx < qx + 24 && my >= slY && my < slY + 14) {
                int mn = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][7] : 1;
                int mxN = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][8] : 30;
                if (n >= mn && n <= mxN) { squadCount = n; }
                return;
            }
            qx += 28;
        }

        // Слайдер
        if (squadSliderW > 0 && my >= squadSliderY && my < squadSliderY + 12
                && mx >= squadSliderX && mx < squadSliderX + squadSliderW) {
            draggingSquadSlider = true;
            updateSquadSlider(mx);
        }

        // Кнопки управления отрядом внизу
        int bbY = winY + WIN_H - FOOT_H - 32;
        int bbX = winX + LEFT_W + 10;
        if (my >= bbY && my < bbY + 20) {
            if (mx >= bbX && mx < bbX + 160)            { spawnSquad(); return; }
            if (mx >= bbX + 168 && mx < bbX + 298)      { sendCmd("bot squad disband"); return; }
            if (mx >= bbX + 306 && mx < bbX + 396)      { sendCmd("bot squad info"); return; }
        }
    }

    private void updateSquadSlider(int mx) {
        if (squadSliderW <= 0) return;
        int minS = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][7] : 1;
        int maxS = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][8] : 30;
        float frac = (float)(mx - squadSliderX) / squadSliderW;
        frac = Math.max(0f, Math.min(1f, frac));
        squadCount = minS + Math.round(frac * (maxS - minS));
    }
    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — ROLES TAB — настройка ролей отряда
    // ═══════════════════════════════════════════════════════════════

    /** Список строк слайдеров ролей {role, sliderX, sliderY, sliderW} */
    private final int[]   roleSliderPos  = new int[BotRole.values().length * 3];
    private int           draggingRoleIdx = -1;

    private void buildRolesWidgets() {
        // Кнопки рендерятся кастомно в renderRolesTab, клики в handleRolesTabClick
    }

    private void renderRolesTab(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;
        BotRole.RoleConfig roleCfg = PVPBotConfig.INSTANCE.roleConfig;
        boolean pct = roleCfg.usePercent;

        g.drawString(font, "⚔  Настройка ролей отряда", sx, sy, ACCENT_BLUE);
        sy += 12;
        g.drawString(font, "Перетащи ползунок: 0=выкл, 100=все. Режим: " + (pct ? "%" : "шт."),
            sx, sy, TEXT_GRAY);
        sy += 16;

        // ── Кнопки "Авторежим" и "Режим: % / шт." ───────────────
        String[] roleBtnLabels = {"Авторежим", pct ? "Режим: %" : "Режим: шт."};
        int[] roleBtnAccents   = {ACCENT_GRAY, pct ? ACCENT_GREEN : ACCENT_YEL};
        int rbX = sx;
        for (int i = 0; i < roleBtnLabels.length; i++) {
            boolean hov = mx >= rbX && mx < rbX + 90 && my >= sy && my < sy + 16;
            float ra = AnimationUtil.tick("role_btn_" + i, hov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, rbX, sy, 90, 16, 3,
                new Color(AnimationUtil.lerpColor(BG_CARD, (roleBtnAccents[i] & 0x00FFFFFF) | 0x25000000, ra)));
            bd(g, rbX, sy, 90, 16, AnimationUtil.lerpColor(BORDER_CARD, roleBtnAccents[i], ra));
            g.drawString(font, roleBtnLabels[i], rbX + 5, sy + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, ra));
            rbX += 96;
        }
        sy += 22;

        BotRole[] roles = BotRole.values();
        int rowH = 22;
        int slW  = 200;

        for (int i = 0; i < roles.length; i++) {
            BotRole role = roles[i];
            Integer v    = roleCfg.roleCounts.get(role);
            int val      = (v == null || v == -1) ? -1 : v;
            int y        = sy + i * rowH;

            // Цветовой квадратик роли
            fr(g, sx, y + 4, 6, 6, 0xFF000000 | role.mapColor);
            // Название роли
            g.drawString(font, role.displayName, sx + 10, y + 3, TEXT_BRIGHT);

            // Слайдер background
            int slX = sx + 80;
            fr(g, slX, y + 4, slW, 8, 0xFF1A2035);

            // Слайдер fill
            float frac = val <= 0 ? 0f : (val / 100f);
            int fillW  = (int)(slW * frac);
            int slColor = val == 0 ? ACCENT_RED : (0xFF000000 | role.mapColor);
            if (fillW > 0) fr(g, slX, y + 4, fillW, 8, slColor);

            // Ручка
            if (fillW > 0) {
                int kx = slX + fillW - 3;
                fr(g, kx, y + 2, 6, 12, TEXT_WHITE);
            }

            // Значение
            String valStr = val == -1 ? "авто" : (val == 0 ? "выкл" : val + (pct ? "%" : " шт."));
            int valColor  = val == -1 ? TEXT_GRAY : (val == 0 ? ACCENT_RED : ACCENT_GREEN);
            g.drawString(font, valStr, slX + slW + 6, y + 3, valColor);

            // Сохраняем позицию для mouseClicked
            int base = i * 3;
            roleSliderPos[base]     = slX;
            roleSliderPos[base + 1] = y + 2;
            roleSliderPos[base + 2] = slW;
        }

        // Мини-карта отряда (справа)
        renderSquadMinimap(g, cx + cw - 100, cy + 20);
    }

    private void handleRolesTabClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 8 + 12 + 16;
        // Кнопки "Авторежим" и "Режим: % / шт."
        if (my >= sy && my < sy + 16) {
            if (mx >= sx && mx < sx + 90) {
                sendCmd("bot squad rolesauto"); rebuild(); return;
            }
            if (mx >= sx + 96 && mx < sx + 186) {
                PVPBotConfig.INSTANCE.roleConfig.usePercent = !PVPBotConfig.INSTANCE.roleConfig.usePercent;
                BotConfig.save(); rebuild(); return;
            }
        }

        // Слайдеры ролей
        BotRole[] roles = BotRole.values();
        for (int i = 0; i < roles.length; i++) {
            int base = i * 3;
            int slX  = roleSliderPos[base];
            int slY  = roleSliderPos[base + 1];
            int slW  = roleSliderPos[base + 2];
            if (mx >= slX && mx <= slX + slW && my >= slY && my <= slY + 14) {
                float frac = (float)(mx - slX) / slW;
                int val = Math.round(frac * 100);
                PVPBotConfig.INSTANCE.roleConfig.roleCounts.put(roles[i], val);
                PVPBotConfig.INSTANCE.roleConfig.usePercent = true;
                BotConfig.save();
                sendCmd("bot squad role " + roles[i].name() + " " + val);
                return;
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — HISTORY TAB — история боёв
    // ═══════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════════
    //  KITS TAB — выбор кита + кнопка «Надеть на бота»
    // ═══════════════════════════════════════════════════════════════

    // Данные карточек кита: { id, displayName, iconId, акцентЦвет, строка1, строка2 }
    private static final Object[][] KIT_CARDS = {
        {"sword",      "Sword PvP",        "kit_sword",   0xFF3B82F6,
            "Diamond Prot4 Unb3",         "Sword Sharp5 Unb3"},
        {"axe",        "Axe PvP",          "kit_axe",     0xFFFB923C,
            "Diamond (без зачар!)",        "Axe Sharp5 Eff5 + Shield"},
        {"pot",        "Diamond Pot",      "kit_pot",     0xFFEC4899,
            "Diamond Prot4 Unb3",         "Sword Sharp5 + Splash Potion"},
        {"uhc",        "UHC",              "kit_uhc",     0xFFEF4444,
            "Diamond Prot3/Prot2 Unb3",   "Sword Sharp3 + Bow Power5 Inf"},
        {"nethop",     "NethOP",           "kit_nethop",  0xFF8B5CF6,
            "Netherite Prot4 Unb3 Mend",  "NethSword Sharp5 Unb3 Mend + Tot"},
        {"smp",        "SMP",              "kit_smp",     0xFF22C55E,
            "Netherite Prot4 Unb3 Mend",  "Sword Sharp5 KB2 FA2 + Totem"},
        {"crystal",    "Crystal PvP",      "kit_crystal", 0xFF06B6D4,
            "Neth Prot4 / BlastProt4",    "Sword Sharp5 KB1 + Totem"},
        {"mace",       "Mace PvP",         "kit_mace",    0xFF94A3B8,
            "Netherite Prot4 Unb3 Mend",  "Mace Density5 Breach4 + Totem"},
        {"mace_elytra","Mace + Elytra",    "kit_mace",    0xFFA855F7,
            "Netherite + Elytra нагрудник","Mace Density5 Breach4 + Totem"},
        {"tpc",        "TPC",              "kit_tpc",     0xFF60A5FA,
            "Netherite Prot4 Unb3 Mend",  "NethAxe Sharp5 Eff5 + Totem"},
        {"snowball",   "Snowball",         "kit_snowball",0xFF64748B,
            "Diamond Prot4 Unb3",         "Snowball + Shield"},
        {"trident",    "Trident PvP",      "kit_trident", 0xFF0EA5E9,
            "Diamond Prot4 Unb3",         "Trident Loyalty3 + Shield"},
        {"crossbow",   "Crossbow PvP",     "kit_sword",   0xFF84CC16,
            "Diamond Prot4 Unb3",         "Crossbow Multishot QC3 + Shield"},
    };

    private String selectedKitId = null;

    private void renderKitsTab(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // Заголовок
        g.drawString(font, "ВЫБЕРИ КИТ", sx, sy, TEXT_WHITE);
        g.drawString(font, "§7источник: mctiers.com/kits", sx + font.width("ВЫБЕРИ КИТ") + 8, sy + 1, TEXT_GRAY);
        sy += 14;

        // Сетка карточек: 3 колонки
        int kW = 154, kH = 72, kGap = 5, kCols = 3;
        for (int i = 0; i < KIT_CARDS.length; i++) {
            Object[] kd = KIT_CARDS[i];
            String  kid  = (String) kd[0];
            String  name = (String) kd[1];
            String  icon = (String) kd[2];
            int     acc  = (int)(long)(Integer) kd[3];
            String  sub1 = (String) kd[4];
            String  sub2 = (String) kd[5];

            int col = i % kCols, row = i / kCols;
            int kx = sx + col * (kW + kGap);
            int ky = sy + row * (kH + kGap) - (int) scrollY;

            // Пропускаем если за пределами видимости
            if (ky + kH < cy || ky > cy + ch) continue;

            boolean hov = mx >= kx && mx < kx + kW && my >= ky && my < ky + kH;
            boolean sel = kid.equals(selectedKitId);
            boolean active = kid.equals(cfg.mode != null ? cfg.mode.name().toLowerCase() : "");

            float aHov = AnimationUtil.tick("kit_hov_" + i, hov ? 1f : 0f, 0.18f);
            float aSel = AnimationUtil.tick("kit_sel_" + i, sel ? 1f : 0f, 0.22f);

            // Фон карточки
            int bgBase = sel ? AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x22000000, 1f)
                             : AnimationUtil.lerpColor(BG_CARD, BG_CARD_HOV, aHov);
            RenderUtil.rounded(g, kx, ky, kW, kH, 5, new Color(bgBase));

            // Акцент-полоска сверху
            int topAlpha = (int)((0.4f + 0.6f * aSel) * 255) << 24;
            g.fill(kx + 4, ky, kx + kW - 4, ky + 2, topAlpha | (acc & 0x00FFFFFF));

            // Рамка
            int borderCol = sel ? acc : AnimationUtil.lerpColor(BORDER_CARD, acc, aHov * 0.6f);
            bd(g, kx, ky, kW, kH, borderCol);

            // Иконка
            IconRenderer.draw(g, icon, kx + 5, ky + 5, 12);

            // Название
            int nameCol = AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, Math.max(aHov, aSel));
            g.drawString(font, name, kx + 21, ky + 7, nameCol);

            // Галочка «активный режим»
            if (active) {
                g.drawString(font, "§a●", kx + kW - 14, ky + 6, 0xFF22C55E);
            }

            // Подробности снаряжения
            g.drawString(font, sub1, kx + 5, ky + 22, TEXT_GRAY);
            g.drawString(font, sub2, kx + 5, ky + 32, 0xFF4A6080);

            // Кнопка «Надеть на бота» — показывается при выделении или hover
            if (sel || hov) {
                int btnY = ky + kH - 18;
                int btnW = kW - 10;
                boolean btnHov = mx >= kx + 5 && mx < kx + 5 + btnW && my >= btnY && my < btnY + 14;
                float aBtnHov = AnimationUtil.tick("kit_btn_hov_" + i, btnHov ? 1f : 0f, 0.2f);
                int btnBg = AnimationUtil.lerpColor(0xFF0A1018, (acc & 0x00FFFFFF) | 0x33000000, aBtnHov);
                int btnBd = AnimationUtil.lerpColor(BORDER_CARD, acc, aBtnHov);
                RenderUtil.rounded(g, kx + 5, btnY, btnW, 14, 3, new Color(btnBg));
                bd(g, kx + 5, btnY, btnW, 14, btnBd);
                int btnTextCol = AnimationUtil.lerpColor(TEXT_GRAY, acc, aBtnHov);
                String btnLabel = active ? "✔ Применён" : "▶ Надеть на бота";
                int labelW = font.width(btnLabel);
                g.drawString(font, btnLabel, kx + 5 + (btnW - labelW) / 2, btnY + 3, btnTextCol);
            }
        }

        // Итого строк
        int rows = (KIT_CARDS.length + kCols - 1) / kCols;
        maxScrollY = Math.max(0, rows * (kH + kGap) - (ch - 30));
    }

    private void handleKitsTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        int sx = cx + 10, sy = cy + 8 + 14;

        int kW = 154, kH = 72, kGap = 5, kCols = 3;
        for (int i = 0; i < KIT_CARDS.length; i++) {
            Object[] kd = KIT_CARDS[i];
            String  kid = (String) kd[0];
            int col = i % kCols, row = i / kCols;
            int kx = sx + col * (kW + kGap);
            int ky = sy + row * (kH + kGap) - (int) scrollY;

            if (mx >= kx && mx < kx + kW && my >= ky && my < ky + kH) {
                // Клик по карточке — выделяем
                selectedKitId = kid;

                // Клик по кнопке «Надеть» (нижние 18px карточки)
                int btnY = ky + kH - 18;
                if (my >= btnY && my < ky + kH) {
                    // Применяем кит всем ботам через команду
                    sendCmd("bot kit " + kid);
                    // Также меняем режим в конфиге если возможно
                    try {
                        cfg.mode = PVPBotConfig.Mode.valueOf(kid.toUpperCase());
                        BotConfig.save();
                    } catch (IllegalArgumentException ignored) {}
                    rebuild();
                }
                return;
            }
        }
    }

    private void renderHistoryTab(GuiGraphicsExtractor g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // ── Секция 1: История отрядных боёв ──────────────────────
        g.drawString(font, "BATTLE HISTORY (Отряд)", sx, sy, ACCENT_BLUE); sy += 14;

        java.util.List<CasualtyTracker.BattleRecord> history = CasualtyTracker.INSTANCE.getHistory();
        if (history.isEmpty()) {
            g.drawString(font, "Ещё не было отрядных боёв.", sx, sy, TEXT_GRAY);
            sy += 12;
        } else {
            g.drawString(font, "Дата         Кит        Бойцов  Потери  Итог", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;
            int shown = Math.min(history.size(), 6);
            for (int i = 0; i < shown; i++) {
                CasualtyTracker.BattleRecord rec = history.get(i);
                if (i % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);
                int rc = rec.victory ? ACCENT_GREEN : ACCENT_RED;
                g.drawString(font, rec.dateStr(),                          sx,       sy, TEXT_GRAY);
                g.drawString(font, padRight(rec.squadKit, 10),             sx + 72,  sy, ACCENT_YEL);
                g.drawString(font, padLeft(String.valueOf(rec.initialSize), 4), sx + 148, sy, TEXT_BRIGHT);
                g.drawString(font, padLeft(String.valueOf(rec.casualties),  4), sx + 184, sy, ACCENT_RED);
                g.drawString(font, rec.victory ? "Победа" : "Пораж.",      sx + 220, sy, rc);
                sy += 12;
            }
            if (history.size() > 6)
                g.drawString(font, "...ещё " + (history.size() - 6), sx, sy, TEXT_DARK);
            sy += 14;
        }

        // ── Секция 2: История личных боёв (FightAnalyzer) ─────────
        g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 6;
        g.drawString(font, "FIGHT LOG (Личный бой)", sx, sy, ACCENT_CYAN); sy += 14;

        java.util.List<FightAnalyzer.FightRecord> fights = FightAnalyzer.INSTANCE.getHistory();
        if (fights.isEmpty()) {
            g.drawString(font, "Ещё не было боёв. Убей цель для записи.", sx, sy, TEXT_GRAY);
        } else {
            // Шапка
            g.drawString(font, "Игрок           Точн%  Урон ↑  Урон ↓  DPS    Время", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;

            for (int i = 0; i < Math.min(fights.size(), 8); i++) {
                FightAnalyzer.FightRecord r = fights.get(i);
                if (sy > winY + WIN_H - FOOT_H - 14) break;
                if (i % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);

                // Полоска победы
                int wc = r.won ? 0xFF00CC44 : 0xFF888888;
                fr(g, sx - 4, sy, 2, 10, wc);

                String name = r.target.length() > 14 ? r.target.substring(0, 13) + "…" : r.target;
                g.drawString(font, padRight(name, 15),                         sx,       sy, r.won ? TEXT_WHITE : TEXT_GRAY);
                g.drawString(font, padLeft(r.accuracy() + "%", 5),             sx + 120, sy, ACCENT_GREEN);
                g.drawString(font, padLeft(String.format("%.0f", r.totalDamage), 6), sx + 162, sy, ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f", r.damageTaken), 6), sx + 200, sy, 0xFFFF8844);
                g.drawString(font, padLeft(String.format("%.1f", r.avgDps), 5), sx + 238, sy, ACCENT_YEL);
                g.drawString(font, String.format("%.1fs", r.durationSec),      sx + 278, sy, TEXT_GRAY);
                sy += 12;
            }

            // Кнопка очистить историю
            sy += 4;
            boolean hovClr = mx >= sx && mx < sx + 100 && my >= sy && my < sy + 14;
            float aClr = AnimationUtil.tick("clr_fights", hovClr ? 1f : 0f, 0.2f);
            fr(g, sx, sy, 100, 14, AnimationUtil.lerpColor(BG_CARD, 0x20EF4444, aClr));
            bd(g, sx, sy, 100, 14, AnimationUtil.lerpColor(BORDER_CARD, 0xFFEF4444, aClr));
            g.drawString(font, "🗑 Очистить историю", sx + 4, sy + 3,
                AnimationUtil.lerpColor(TEXT_GRAY, 0xFFEF4444, aClr));
        }

        // ── Текущий бой (если идёт) ──────────────────────────────
        CasualtyTracker.BattleRecord cur = CasualtyTracker.INSTANCE.getCurrent();
        if (cur != null) {
            int panY = winY + WIN_H - FOOT_H - 54;
            fr(g, sx - 2, panY, cw - 16, 20, 0xFF0C1A0C);
            bd(g, sx - 2, panY, cw - 16, 20, ACCENT_GREEN);
            g.drawString(font,
                "⚔ Бой идёт: " + cur.squadKit
                + "  Бойцов: " + cur.initialSize
                + "  Потери: " + cur.casualties,
                sx + 2, panY + 6, ACCENT_GREEN);
        }

        // ── Секция 3: BotReplay (последние 5 сек боя) ───────────
        int replayPanY = winY + WIN_H - FOOT_H - 28;
        g.fill(sx, replayPanY - 8, cx + cw - 10, replayPanY - 7, BORDER_SEP);
        g.drawString(font, "⏱ REPLAY (последние 5с)", sx, replayPanY - 6, ACCENT_YEL);

        java.util.List<String> replayLines = new java.util.ArrayList<>(BotReplay.CLIENT_SUMMARY);
        if (replayLines.isEmpty()) {
            g.drawString(font, "Нет данных — нужен активный бой", sx, replayPanY + 4, TEXT_GRAY);
        } else {
            // Рисуем компактную полоску событий
            int rx = sx;
            for (String line : replayLines) {
                // Цвет по действию
                int lc = TEXT_GRAY;
                if (line.contains("ATTACK"))  lc = ACCENT_RED;
                else if (line.contains("DODGE"))   lc = ACCENT_CYAN;
                else if (line.contains("RETREAT")) lc = ACCENT_YEL;
                else if (line.contains("FAKE"))    lc = 0xFFCC88FF;
                g.drawString(font, line, rx, replayPanY + 4, lc);
                rx += font.width(line) + 8;
                if (rx > cx + cw - 20) break; // не вылезаем за панель
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — Мини-карта отряда (точки по ролям)
    // ═══════════════════════════════════════════════════════════════

    /**
     * Рисует мини-карту отряда — точки цветом по роли.
     * Центр = позиция командира / владельца.
     * Масштаб: 1 блок = 2 пикселя, радиус = 40px = 20 блоков.
     */
    private void renderSquadMinimap(GuiGraphicsExtractor g, int cx, int cy) {
        int r = 40; // радиус в px = 20 блоков
        // Фон
        fr(g, cx - r, cy - r, r * 2, r * 2, 0xAA111111);
        // Рамка (4 линии вместо hLine/vLine)
        g.fill(cx - r, cy - r, cx + r, cy - r + 1, 0xFF444444); // top
        g.fill(cx - r, cy + r - 1, cx + r, cy + r, 0xFF444444); // bottom
        g.fill(cx - r, cy - r, cx - r + 1, cy + r, 0xFF444444); // left
        g.fill(cx + r - 1, cy - r, cx + r, cy + r, 0xFF444444); // right
        // Крестик центра (владелец)
        g.fill(cx - 1, cy - 3, cx + 2, cy + 4, 0xFFFFFFFF);
        g.fill(cx - 3, cy - 1, cx + 4, cy + 2, 0xFFFFFFFF);

        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        double px = mc.player.getX(), pz = mc.player.getZ();
        double scale = r / 20.0;

        for (net.minecraft.world.entity.Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof BotEntity bot)) continue;
            int color = bot.getSquadRole() != null ? (0xFF000000 | bot.getSquadRole().mapColor) : 0xFF888888;
            double dx = (bot.getX() - px) * scale;
            double dz = (bot.getZ() - pz) * scale;
            if (Math.abs(dx) > r || Math.abs(dz) > r) continue;
            int bx = cx + (int) dx;
            int bz = cy + (int) dz;
            g.fill(bx - 1, bz - 1, bx + 2, bz + 2, color);
        }

        g.drawString(font, "Мини-карта (20б)", cx - r, cy + r + 3, TEXT_DARK);
    }

    // ─── helpers ─────────────────────────────────────────────────

    private String padRight(String s, int n) {
        if (s.length() >= n) return s.substring(0, n);
        return s + " ".repeat(n - s.length());
    }
    private String padLeft(String s, int n) {
        if (s.length() >= n) return s;
        return " ".repeat(n - s.length()) + s;
    }

}