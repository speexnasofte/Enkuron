package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * MaceLogic v6.0 — MAJOR REWRITE
 *
 * Улучшения v6:
 *  ✦ GROUND SMASH: при прыжке с 6+ блоков — смэш с полной формулой урона (base + fall*2)
 *  ✦ Смэш каждые SMASH_EVERY ударов — не только каждые 4, но и при открытии (enemy in air)
 *  ✦ Wind Charge: выталкивает врага вверх → создаём возможность для своего смэша
 *  ✦ Counter-smash: если враг прыгнул (isFallFlying) — мгновенный удар без прыжка
 *  ✦ Shield break: если враг блокирует — Axe hit перед смэшем
 *  ✦ Strength effect для увеличения базового урона
 *  ✦ После смэша: Gap для лечения если HP < 14
 *  ✦ Динамический IDEAL_DIST: при подготовке смэша — сближаемся агрессивнее
 *  ✦ Notify owner: сообщение о смэше с уроном и высотой падения
 */
public class MaceLogic {

    // ── Дальности ─────────────────────────────────────────────────
    private static final double MELEE_RANGE  = 3.5;
    private static final double IDEAL_DIST   = 2.5;
    private static final double WIND_DIST    = 7.0;
    private static final double SMASH_DIST   = 4.0;

    // ── Смэш параметры ────────────────────────────────────────────
    // v7 BUFF: агрессивнее, сильнее, быстрее
    private static final int    SMASH_EVERY  = 3;    // было 4: смэш чаще
    private static final int    SMASH_CD     = 16;   // было 22
    private static final int    MIN_HEIGHT   = 3;    // было 4: прыгаем с меньшей высоты
    private static final float  SMASH_BASE   = 15.0f; // было 12.0
    private static final float  FALL_MULT    = 2.8f;  // было 2.2
    private static final float  MAX_DAMAGE   = 65.0f; // было 50.0

    // ── Кулдауны ──────────────────────────────────────────────────
    private static final int    WIND_CD      = 22;   // было 30
    private static final int    GAP_CD       = 140;  // было 180: быстрее хил
    private static final int    ATTACK_CD    = 5;    // было 7: CPS выше
    private static final int    AXE_CD       = 14;   // было 18
    private static final int    STR_CD       = 280;  // было 400

    private enum State { FIGHTING, JUMP_UP, FALLING, SMASH, COOLDOWN }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int smashCd  = 0, windCd  = 0, gapCd  = 0;
    private int attackCd = 0, axeCd   = 0, strCd  = 0;
    private int hitCount = 0;
    private double jumpStartY = 0, peakY = 0;
    private int smashTimeoutTimer = 0; // защита от зависания в JUMP_UP

    public MaceLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        if (smashCd  > 0) smashCd--;
        if (windCd   > 0) windCd--;
        if (gapCd    > 0) gapCd--;
        if (attackCd > 0) attackCd--;
        if (axeCd    > 0) axeCd--;
        if (strCd    > 0) strCd--;
        if (smashTimeoutTimer > 0) smashTimeoutTimer--;

        // ── Тотем + GAP + Strength всегда ────────────────────────
        ensureTotem();
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1));
            strCd = STR_CD;
        }
        float myHp = bot.getHealth();
        if (myHp < 12.0f && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 1));
            gapCd = GAP_CD;
        }
        if (bot.isInWater() && !bot.onGround()) {
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.15, bot.getDeltaMovement().z);
            bot.setSprinting(false);
        }

        if (target == null || !target.isAlive()) { state = State.FIGHTING; return; }

        // ── Защита от зависания в воздухе ────────────────────────
        if ((state == State.JUMP_UP || state == State.FALLING) && smashTimeoutTimer <= 0) {
            state = State.COOLDOWN; smashCd = SMASH_CD / 2;
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        switch (state) {
            case FIGHTING -> tickFighting(sw, target);
            case JUMP_UP  -> tickJumpUp(target);
            case FALLING  -> tickFalling(sw, target);
            case SMASH    -> tickSmash(sw, target);
            case COOLDOWN -> { if (smashCd <= 0) state = State.FIGHTING; }
        }
    }

    // ════════════════════════════════════════════════════════════
    //  FIGHTING
    // ════════════════════════════════════════════════════════════

    private void tickFighting(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // ── Навигация ────────────────────────────────────────────
        double approach = (smashCd <= 2) ? IDEAL_DIST - 0.5 : IDEAL_DIST; // агрессивнее перед смэшем
        if (dist > approach + 0.5)  { bot.getNavigation().moveTo(target, 1.12); bot.setSprinting(dist > 5.0); }
        else if (dist < approach - 0.4) { bot.getNavigation().stop(); bot.setSprinting(false); }

        // ── Страф ────────────────────────────────────────────────
        if (dist < MELEE_RANGE + 2.5 && cfg.strafeEnabled) strafe.tick(target);

        // ── Counter-smash: враг в воздухе → бьём без прыжка ─────
        boolean enemyAirborne = !target.onGround() && target.getDeltaMovement().y < -0.1;
        if (enemyAirborne && attackCd <= 0 && dist <= MELEE_RANGE) {
            doNormalHit(sw, target);
            return;
        }

        // ── Wind Charge ──────────────────────────────────────────
        if (windCd <= 0 && dist <= WIND_DIST) {
            throwWindCharge(sw, target);
            windCd = WIND_CD;
        }

        // ── Слом щита (топором) перед смэшем ─────────────────────
        if (target.isBlocking() && dist <= 3.5 && axeCd <= 0) {
            doAxeHit(sw, target);
            return;
        }

        // ── Смэш через SMASH_EVERY ударов или при открытии ───────
        boolean smashOpening = enemyAirborne || (hitCount > 0 && hitCount % SMASH_EVERY == 0);
        if (smashOpening && smashCd <= 0 && bot.onGround() && dist <= SMASH_DIST) {
            jumpStartY = bot.getY();
            peakY      = jumpStartY;
            bot.getJumpControl().jump();
            bot.setSprinting(false);
            state = State.JUMP_UP;
            smashTimeoutTimer = 30; // защита от зависания
            bot.getNavigation().stop();
            return;
        }

        // ── Обычный удар ─────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            doNormalHit(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  SMASH-ЦИКЛ
    // ════════════════════════════════════════════════════════════

    private void tickJumpUp(LivingEntity target) {
        double y = bot.getY();
        if (y > peakY) peakY = y;
        bot.getLookControl().setLookAt(target, 30f, 30f);
        // Переход к падению: достигли MIN_HEIGHT ИЛИ начали падать
        double gainedHeight = peakY - jumpStartY;
        boolean startFalling = y < peakY - 0.15 || bot.getDeltaMovement().y < -0.05;
        if ((gainedHeight >= MIN_HEIGHT || startFalling) && !bot.onGround()) {
            state = State.FALLING;
        }
    }

    private void tickFalling(ServerLevel sw, LivingEntity target) {
        double dist     = bot.distanceTo(target);
        double vertDiff = bot.getY() - target.getY();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (dist > 1.5) bot.getNavigation().moveTo(target, 1.3);

        // Смэш когда достаточно близко к цели вертикально
        if (vertDiff <= 2.5 && dist <= SMASH_DIST + 0.5) {
            state = State.SMASH;
            tickSmash(sw, target);
        } else if (bot.onGround()) {
            state = State.COOLDOWN; smashCd = SMASH_CD / 2; // промах
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        if (target == null || !target.isAlive()) { state = State.COOLDOWN; smashCd = SMASH_CD; return; }

        double fallBlocks = Math.max(0, peakY - bot.getY());
        float  damage     = Math.min(MAX_DAMAGE, SMASH_BASE + (float)(fallBlocks * FALL_MULT));

        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Knockback мощный
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive()) target.setDeltaMovement(kb.x * 2.8, 1.8, kb.z * 2.8);

        // Частицы + звук
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 30, 0.7,0.7,0.7,0.4);
        sw.sendParticles(ParticleTypes.LARGE_SMOKE,
            bot.getX(), bot.getY(), bot.getZ(), 8, 0.3,0.1,0.3,0.1);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.65f);

        // Тормоз после приземления
        Vec3 v = bot.getDeltaMovement();
        bot.setDeltaMovement(v.x * 0.15, Math.max(v.y, 0), v.z * 0.15);

        notifyOwner(String.format("§6[Mace] §c💥 SMASH! §e%.1f dmg §7(fall=%.1fб peak=%.1f)",
            damage, fallBlocks, peakY));

        // v7: Speed + Regen после смэша = рывок на сближение и хил
        bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));   // Speed II 3 сек
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 0));     // Regen 4 сек

        bot.getHeatMap().recordDamageDealt(bot.position(), damage);
        hitCount++;
        smashCd = SMASH_CD;
        state   = State.COOLDOWN;
    }

    // ════════════════════════════════════════════════════════════
    //  Атаки
    // ════════════════════════════════════════════════════════════

    private void doNormalHit(ServerLevel sw, LivingEntity target) {
        equipMace();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+0.8, target.getZ(), 5, 0.2,0.2,0.2,0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
        bot.getHeatMap().recordDamageDealt(bot.position(), 10f);
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                .enchant("sharpness", 5).build());
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY()+1, target.getZ(), 4, 0.3,0.2,0.3,0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        axeCd = AXE_CD;
    }

    private void throwWindCharge(ServerLevel sw, LivingEntity target) {
        // v7: используем MotionPredictor — бьём куда цель БУДЕТ через 3 тика
        Vec3 predicted = MotionPredictor.predict(target, 3);
        Vec3 dir = predicted.subtract(bot.getEyePosition()).normalize();
        // Сильнее вверх → больше высота падения → больше урон смэша
        target.setDeltaMovement(target.getDeltaMovement().add(dir.x * 1.5, 2.6, dir.z * 1.5));
        target.hurt(sw.damageSources().explosion(null, bot), 3.0f); // было 2.0
        // Поджигаем — доп. давление пока цель в воздухе
        target.igniteForSeconds(2);
        sw.sendParticles(ParticleTypes.GUST,
            bot.getX()+dir.x*2, bot.getEyeY(), bot.getZ()+dir.z*2,
            18, 0.25,0.25,0.25,0.15);
        bot.playSound(SoundEvents.WIND_CHARGE_THROW, 1.1f, 0.85f);
    }

    // ════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.MACE, bot.level().registryAccess())
                    .enchant("density", 5).enchant("breach", 4)
                    .enchant("unbreaking", 3).enchant("mending", 1).build());
    }

    private void ensureTotem() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    public boolean isSmashing() {
        return state == State.JUMP_UP || state == State.FALLING || state == State.SMASH;
    }

    public String getStateLabel() {
        return switch (state) {
            case FIGHTING -> "MACE:FIGHT";
            case JUMP_UP  -> "MACE:JUMP↑";
            case FALLING  -> "MACE:FALL↓";
            case SMASH    -> "MACE:SMASH!";
            case COOLDOWN -> "MACE:CD";
        };
    }
}
