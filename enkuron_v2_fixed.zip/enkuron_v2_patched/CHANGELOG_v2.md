# Enkuron v2 — Changelog

## Глобальное переписывание

### Версия: 2.0.0 | Minecraft: 1.21.4 | Fabric Loader: ≥0.16.9

---

## ✅ Исправленные баги

### Критические
- **Двойной рендер HUD** — `ModuleManager.onRender()` больше не вызывается из
  `HudRenderCallback`. Вызывается ТОЛЬКО из `MixinInGameHud@TAIL`. Устранено
  двоение всех HUD элементов.
- **ConcurrentModificationException** в `onTick` / `onRender` — используется
  снимок `modules.toArray()` при итерации.
- **NPE при старте** — добавлены null-checks в `AutoArmor`, `AutoTotem`,
  `AntiPoison`, `CpsCounter` и других при обращении к `playerScreenHandler`.
- **AutoEat зависание** — `stopEating()` корректно срабатывает при пустом слоте.
- **Sprint в воде** — `setSprinting(false)` при выходе из воды.
- **StepUp конфликт с прыжком** — атрибут `STEP_HEIGHT` сбрасывается при отключении.
- **GlowESP утечка** — все светящиеся сущности сбрасывают `setGlowing(false)` при
  `onDisable()` и смене мира.
- **AutoTotem в закрытом инвентаре** — корректный `screenSlot` для хотбара (36–44)
  и рюкзака (9–35).

### Стабильность
- `EventBus` — авто-подписка/отписка через `Module.toggle()`; нет ручного
  `subscribe`/`unsubscribe` снаружи.
- `ConfigManager` — сохраняет/загружает `ColorSetting`, `GUIStyle`, тему;
  защита от битого JSON.
- `ModuleManager.register()` — проверка на дубликат класса.

---

## 🆕 Новые модули

| Модуль | Категория | Описание |
|--------|-----------|----------|
| `AutoSprint` | MOVEMENT | Умный спринт: Always / OnMove / Combat |
| `StepUp` | MOVEMENT | Шаг на 1 блок без прыжка (атрибут STEP_HEIGHT) |
| `FastPlace` | UTILITY | Уменьшение задержки ПКМ |
| `Speedometer` | HUD | Скорость в блоках/сек |
| `PingHUD` | HUD | Пинг до сервера |
| `DurabilityHUD` | HUD | Прочность держимого предмета |
| `TotemCounter` | HUD | Количество тотемов в инвентаре |
| `EventAlert` | HUD | Уведомления о входе/выходе игроков |
| `WeatherHUD` | HUD | Погода и время суток |
| `DamageNumbers` | VISUAL | Числа урона над сущностями |
| `Nametags` | VISUAL | Кастомные теги над головами с HP |
| `EchoAura` | VISUAL | Расширяющиеся эхо-кольца |
| `AuraShield` | VISUAL | Щит из частиц вокруг игрока |
| `ShockwaveEffect` | VISUAL | Волна при прыжке и ударе |
| `GroundEffect` | VISUAL | Эффекты под ногами при движении |
| `HatEffect` | VISUAL | Головной убор из частиц |
| `HandEffect` | VISUAL | Частицы из рук |
| `ScreenEffects` | VISUAL | Виньетка, хроматическая аберрация |
| `CapeEffect` | VISUAL | Анимированный эффект плаща |
| `WingEffect` | VISUAL | Крылья из частиц |
| `PetOrbit` | VISUAL | Орбита питомца (декоратив) |
| `StarBurst` | VISUAL | Вспышки звёзд вокруг игрока |
| `RainbowTrail` | VISUAL | Радужный след за игроком |
| `KillCounter` | HUD | Счётчик убийств за сессию |
| `SessionStats` | HUD | Убийства, смерти, время сессии |
| `BlockInfo` | HUD | Инфо о блоке под прицелом (ID, координаты) |
| `ChestStealer` | UTILITY | Авто-выкачка сундуков |
| `AutoFish` | UTILITY | Авто-рыбалка |
| `ChatLogger` | UTILITY | Логирование чата в файл |

---

## ♻️ Улучшения существующих модулей

- **Brightness** — заменяет FullBright + SmartBrightness + Brightness из v1.
  Единый слайдер + авто-режим в пещерах.
- **AutoArmor** — совместим с 1.21.4: определение типа брони через
  `getTranslationKey()`, вес по материалу.
- **AutoEat** — использует `DataComponentTypes.FOOD` (API 1.21.4).
- **AutoTotem** — правильный `screenSlot` для хотбара/рюкзака.
- **NoFall** — режимы Packet (обман сервера) и Cancel (клиентский).
- **Sprint** — три режима: Always / Forward / Omni.
- **GlowESP** — `SettingPresets` (фильтр целей, дальность, интервал).
- **Tracers** — 4 режима: Compass / List / Both / Arrows.
- **Zoom** — плавный FoV через `AnimationUtils.lerp` + скролл-зум.
- **ArrayList** — сортировка, анимация, цвет по категории.

---

## 🏗 Архитектурные изменения

- `Module.toggle()` — авто-подписка EventBus, нет дедлока.
- `Module.setEnabled()` — для ConfigManager, нет двойного toggle.
- `ModuleManager.getByClass(Class<T>)` — поиск по типу.
- `ModuleManager.countEnabled(Category)` — для бейджей в GUI.
- `ConfigManager` — сохраняет ColorSetting, HUD-позиции, GUI-стиль, тему.
- `SettingPresets` — общие блоки настроек (TargetFilter, Range, UpdateRate...).
- `ColorSetting` — отдельный от Setting класс, радужный режим.
- `ThemeManager` — 8 тем (Neon, Blue, Red, Mint, Dark, Gold, Aurora, Sakura).
- `GUIManager` — 5 стилей (Modern, Neon, Glass, Minimal, Classic); G для смены.

---

## ⚙️ Совместимость

| Параметр | Значение |
|----------|----------|
| Minecraft | `1.21.4` |
| Fabric Loader | `≥0.16.9` |
| Fabric API | `0.113.0+1.21.4` |
| Java | `21` |
| Yarn маппинги | `1.21.4+build.8` |
