package net.enkuron.mixin.accessor;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accessor отключен, так как chatCooldown удален в 1.21.
 */
@Mixin(ClientPlayerEntity.class)
public interface ClientPlayerEntityAccessor {
    // Временно закомментировано для успешной сборки
    /*
    @Accessor("chatCooldown")
    int getChatCooldown();

    @Accessor("chatCooldown")
    void setChatCooldown(int value);
    */
}