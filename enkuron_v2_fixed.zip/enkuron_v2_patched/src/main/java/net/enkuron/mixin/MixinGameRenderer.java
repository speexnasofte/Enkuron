package net.enkuron.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.Zoom;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    @ModifyReturnValue(method = "getFov", at = @At("RETURN"))
    private float onGetFov(float original) {
        Zoom zoom = (Zoom) ModuleManager.getByName("Zoom"); // FIX: было "zoom", getByName регистронезависимый но явно правильно
        if (zoom != null && zoom.isEnabled()) {
            // Обязательно кастим в float
            return (float) (original * zoom.getFovModifier());
        }
        return original;
    }
}