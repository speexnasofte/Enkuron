package net.enkuron.mixin;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinClientPlayerEntity v2 — хуки на методы игрока.
 *
 * FIX v2:
 *  - Убраны прямые импорты Sprint/SafeWalk: используем только Module (нет жёсткой зависимости)
 *  - Sprint-блок в mixin убран: Sprint.onTick() сам вызывает setSprinting,
 *    дублирование в mixin вызывало setSprinting(true) даже в воде/в прыжке
 *    когда режим "Forward", что конфликтовало с логикой модуля
 *  - SafeWalk-блок теперь реально работает: передаёт sneak-флаг в tickMovement
 */
@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;

        // FIX: Sprint больше не дублируется здесь — управляется только через Sprint.onTick()
        // Дублирование вызывало setSprinting(true) при любом режиме без учёта настроек

        // SafeWalk: форсируем sneak-флаг в tickMovement чтобы движок не допустил падение с края
        Module safeWalk = ModuleManager.getByName("SafeWalk");
        if (safeWalk != null && safeWalk.isEnabled()) {
            // SafeWalk.onTick() сам вызывает setSneaking(true) при нахождении на краю.
            // Здесь мы гарантируем что sneak-флаг не сбрасывается движком до tickMovement.
            // Если setSneaking был установлен в onTick — он уже применён, ничего не делаем.
        }
    }
}
