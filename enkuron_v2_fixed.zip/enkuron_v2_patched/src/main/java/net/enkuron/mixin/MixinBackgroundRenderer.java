package net.enkuron.mixin;

import net.enkuron.modules.impl.FpsBoost;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.FogShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinBackgroundRenderer — управляет туманом.
 *
 * applyFog() устанавливает параметры тумана (start/end/shape).
 * При CANCEL в HEAD туман не применяется — видимость максимальная,
 * GPU не тратит время на fog calculations в шейдерах.
 *
 * Примечание: это влияет только на shader-level fog, не на chunk rendering.
 * Для полного отключения тумана через Sodium/Iris нужен отдельный подход,
 * но для vanilla + Fabric этот mixin даёт нужный результат.
 */
@Mixin(BackgroundRenderer.class)
public class MixinBackgroundRenderer {

    @Inject(
        method = "applyFog",
        at = @At("HEAD"),
        cancellable = true
    )
    private static void onApplyFog(Camera camera,
                                   BackgroundRenderer.FogType fogType,
                                   float viewDistance,
                                   boolean thickFog,
                                   float tickProgress,
                                   CallbackInfo ci) {
        if (FpsBoost.isNoFog()) {
            ci.cancel();
        }
    }
}
