package net.enkuron.mixin;

import net.enkuron.modules.impl.FpsBoost;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinWorldRendererFps — отключает рендер погоды (дождь/снег) для FPS.
 *
 * FIX v2 (1.21.4):
 *  - Убран хук на renderShadow — в 1.21.4 этот приватный метод имеет другую сигнатуру
 *    и remap=false не мог его найти, что приводило к MixinApplyException при загрузке.
 *  - Оставлен только renderWeather — он стабилен между версиями.
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRendererFps {

    @Inject(
        method = "renderWeather",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onRenderWeather(LightmapTextureManager manager,
                                  float tickProgress,
                                  double x, double y, double z,
                                  CallbackInfo ci) {
        if (FpsBoost.isNoWeather()) {
            ci.cancel();
        }
    }
}
