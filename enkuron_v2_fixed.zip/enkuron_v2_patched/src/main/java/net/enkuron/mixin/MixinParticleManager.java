package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.CritParticles;
import net.enkuron.modules.impl.FpsBoost;
import net.enkuron.modules.impl.HitParticles;
import net.enkuron.modules.impl.NoRender;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * MixinParticleManager — подавляет стандартные vanilla-частицы.
 *
 * Приоритеты:
 *  1. FpsBoost.isNoParticles()    → блокируем ВСЕ (производительность)
 *  2. NoRender.isNoParticles()    → блокируем ВСЕ (визуальный)
 *  3. CritParticles включён       → блокируем CRIT / ENCHANTED_HIT
 *  4. HitParticles включён        → блокируем DAMAGE_INDICATOR
 */
@Mixin(ParticleManager.class)
public class MixinParticleManager {

    @Inject(
        method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onAddParticle(ParticleEffect parameters, double x, double y, double z,
                               double velocityX, double velocityY, double velocityZ,
                               CallbackInfoReturnable<Particle> cir) {

        // FpsBoost — блокируем все частицы для производительности
        if (FpsBoost.isNoParticles()) {
            cir.setReturnValue(null);
            return;
        }

        // NoRender — визуальное отключение всех частиц
        NoRender noRender = (NoRender) ModuleManager.getByName("NoRender");
        if (noRender != null && noRender.isNoParticles()) {
            cir.setReturnValue(null);
            return;
        }

        // CritParticles — заменяем vanilla крит-частицы кастомными
        CritParticles critModule = (CritParticles) ModuleManager.getByName("CritParticles");
        if (critModule != null && critModule.isEnabled()) {
            if (parameters == ParticleTypes.CRIT || parameters == ParticleTypes.ENCHANTED_HIT) {
                cir.setReturnValue(null);
                return;
            }
        }

        // HitParticles — заменяем vanilla damage indicator
        HitParticles hitModule = (HitParticles) ModuleManager.getByName("HitParticles");
        if (hitModule != null && hitModule.isEnabled()) {
            if (parameters == ParticleTypes.DAMAGE_INDICATOR) {
                cir.setReturnValue(null);
            }
        }
    }
}