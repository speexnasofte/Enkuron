package net.enkuron.mixin;

import net.enkuron.event.EventBus;
import net.enkuron.event.KeyPressEvent;
import net.enkuron.modules.ModuleManager;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class MixinKeyboard {
    
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void onKey(long window, int key, int scancode, int action, int mods, CallbackInfo ci) {
        // Мы проверяем action == 1 (нажатие) или 2 (удержание), 
        // чтобы не спамить ивентами при отпускании клавиши (action == 0), 
        // если это не нужно твоей логике.
        
        if (key != -1) { // Проверка на валидность клавиши
            // Твой легаси метод
            ModuleManager.onKey(key, action);
            
            // Твой новый ивент-бас
            EventBus.post(new KeyPressEvent(key, action));
        }
    }
}