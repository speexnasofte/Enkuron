package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.BetterChat;
import net.minecraft.client.gui.screen.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinChatScreen — перехватывает отправку сообщений.
 *
 * Даёт BetterChat возможность:
 *  - фильтровать дубли
 *  - добавлять префикс
 *  - нарезать длинные сообщения на части
 */
@Mixin(ChatScreen.class)
public abstract class MixinChatScreen {

    @Inject(method = "sendMessage(Ljava/lang/String;Z)V", at = @At("HEAD"), cancellable = true)
    private void onSendMessage(String message, boolean addToHistory, CallbackInfo ci) {
        BetterChat mod = (BetterChat) ModuleManager.getByName("BetterChat");
        if (mod == null || !mod.isEnabled()) return;

        // Применяем фильтр дублей и префикс
        String processed = mod.processOutgoing(message);
        if (processed == null) {
            ci.cancel(); // дубль — блокируем
            return;
        }

        // Если сообщение изменилось или нужна нарезка — отменяем оригинал и шлём сами
        String[] parts = mod.splitLong(processed);
        if (parts.length > 1 || !processed.equals(message)) {
            ci.cancel();
            ChatScreen self = (ChatScreen)(Object) this;
            for (String part : parts) {
                // Вызываем ванильный sendMessage напрямую через client
                net.minecraft.client.MinecraftClient.getInstance()
                    .getNetworkHandler()
                    .sendChatMessage(part);
            }
        }
        // Если parts.length == 1 и processed == message — пускаем оригинальный вызов
    }
}
