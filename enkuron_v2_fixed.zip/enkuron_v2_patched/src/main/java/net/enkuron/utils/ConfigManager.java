package net.enkuron.utils;

import com.google.gson.*;
import net.enkuron.modules.ColorSetting;
import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.gui.GUIManager;
import net.enkuron.ui.theme.ThemeManager;
import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * ConfigManager v3 — сохранение и загрузка конфигурации.
 *
 * НОВОЕ — Автосохранение:
 *  - каждые AUTO_SAVE_INTERVAL тиков (по умолчанию 1200 = 1 минута)
 *  - при изменении любой настройки через scheduleAutosave() — сохранение через 3 сек
 *  - при выходе из игры (вызывается из Enkuron.java onDisable / shutdown hook)
 *
 * Вызывай onTick() из главного класса Enkuron или из EventBus (TickEvent).
 * Вызывай scheduleAutosave() из Setting.setState() / Setting.setValue() при изменении.
 *
 * Файлы:
 *  .minecraft/enkuron/config.json           — основной конфиг (автосейв)
 *  .minecraft/enkuron/profiles/<name>.json  — именованные профили
 */
public class ConfigManager {

    // ── Константы ────────────────────────────────────────────────────────────
    private static final int AUTO_SAVE_INTERVAL  = 1200; // тиков (~1 мин при 20 TPS)
    private static final int DIRTY_SAVE_DELAY    = 60;   // тиков (~3 сек) после scheduleAutosave

    private static final File CONFIG_DIR   = new File(
        MinecraftClient.getInstance().runDirectory, "enkuron");
    private static final File PROFILES_DIR = new File(CONFIG_DIR, "profiles");
    private static final File ACTIVE_FILE  = new File(CONFIG_DIR, "config.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // ── Автосейв-состояние ───────────────────────────────────────────────────
    private static int  autoSaveTick  = 0;
    private static int  dirtyTick     = -1;  // -1 = нет отложенного сейва
    private static boolean pendingDirty = false;

    // ── Автосейв тик (вызывать из TickEvent) ────────────────────────────────

    /**
     * Вызывать каждый тик из Enkuron / TickEvent подписчика.
     * Сохраняет конфиг:
     *   а) каждые AUTO_SAVE_INTERVAL тиков
     *   б) через DIRTY_SAVE_DELAY тиков после scheduleAutosave()
     */
    public static void onTick() {
        autoSaveTick++;

        // Отложенный "dirty" сейв (после изменения настроек)
        if (pendingDirty) {
            dirtyTick++;
            if (dirtyTick >= DIRTY_SAVE_DELAY) {
                save();
                pendingDirty = false;
                dirtyTick    = -1;
            }
        }

        // Периодический автосейв
        if (autoSaveTick >= AUTO_SAVE_INTERVAL) {
            autoSaveTick = 0;
            save();
        }
    }

    /**
     * Помечает конфиг как "изменённый" — сохранение произойдёт через ~3 сек.
     * Вызывать из Setting.setState() / Setting.setValue() при изменении.
     */
    public static void scheduleAutosave() {
        pendingDirty = true;
        dirtyTick    = 0;
    }

    // ── Активный конфиг ──────────────────────────────────────────────────────

    public static void save() {
        ensureDirs();
        writeToFile(ACTIVE_FILE);
    }

    public static void load() {
        if (!ACTIVE_FILE.exists()) return;
        readFromFile(ACTIVE_FILE);
    }

    // ── Профили ──────────────────────────────────────────────────────────────

    public static void saveProfile(String name) {
        ensureDirs();
        writeToFile(profileFile(name));
    }

    public static boolean loadProfile(String name) {
        File f = profileFile(name);
        if (!f.exists()) return false;
        readFromFile(f);
        save();
        return true;
    }

    public static boolean deleteProfile(String name) {
        return profileFile(name).delete();
    }

    public static List<String> listProfiles() {
        List<String> list = new ArrayList<>();
        if (!PROFILES_DIR.exists()) return list;
        File[] files = PROFILES_DIR.listFiles((d, n) -> n.endsWith(".json"));
        if (files == null) return list;
        for (File f : files) list.add(f.getName().replace(".json", ""));
        return list;
    }

    // ── Запись ──────────────────────────────────────────────────────────────

    private static void writeToFile(File file) {
        try {
            JsonObject root = new JsonObject();

            root.addProperty("guiStyle", GUIManager.getStyle().name());
            root.addProperty("theme",    ThemeManager.getCurrentName());

            JsonArray arr = new JsonArray();
            for (Module m : ModuleManager.getModules()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("name",    m.getName());
                obj.addProperty("enabled", m.isEnabled());
                obj.addProperty("key",     m.getKey());
                obj.addProperty("x",       m.getX());
                obj.addProperty("y",       m.getY());

                JsonObject settingsObj = new JsonObject();
                for (Setting s : m.getSettings()) {
                    switch (s.getType()) {
                        case NUMBER  -> settingsObj.addProperty(s.getName(), s.getValue());
                        case BOOLEAN -> settingsObj.addProperty(s.getName(), s.getState());
                        case ENUM    -> settingsObj.addProperty(s.getName(), s.getOptionIndex());
                    }
                }
                obj.add("settings", settingsObj);

                JsonObject colorsObj = new JsonObject();
                for (ColorSetting cs : m.getColorSettings()) {
                    JsonObject co = new JsonObject();
                    co.addProperty("color",        cs.getColor());
                    co.addProperty("rainbow",      cs.isRainbow());
                    co.addProperty("rainbowSpeed", cs.getRainbowSpeed());
                    colorsObj.add(cs.getName(), co);
                }
                obj.add("colors", colorsObj);

                arr.add(obj);
            }
            root.add("modules", arr);

            try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                GSON.toJson(root, w);
            }
        } catch (Exception e) {
            System.err.println("[Enkuron] Ошибка сохранения конфига: " + e.getMessage());
        }
    }

    // ── Чтение ──────────────────────────────────────────────────────────────

    private static void readFromFile(File file) {
        try (Reader r = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();

            if (root.has("guiStyle")) {
                try { GUIManager.setStyle(GUIManager.GUIStyle.valueOf(root.get("guiStyle").getAsString())); }
                catch (Exception ignored) {}
            }
            if (root.has("theme")) {
                ThemeManager.setByName(root.get("theme").getAsString());
            }

            if (!root.has("modules")) return;
            JsonArray arr = root.getAsJsonArray("modules");
            for (JsonElement el : arr) {
                JsonObject obj = el.getAsJsonObject();
                if (!obj.has("name")) continue;

                Module m = ModuleManager.getByName(obj.get("name").getAsString());
                if (m == null) continue;

                if (obj.has("enabled")) m.setEnabled(obj.get("enabled").getAsBoolean());
                if (obj.has("key"))     m.setKey(obj.get("key").getAsInt());
                if (obj.has("x"))       m.setX(obj.get("x").getAsInt());
                if (obj.has("y"))       m.setY(obj.get("y").getAsInt());

                if (obj.has("settings")) {
                    JsonObject so = obj.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        if (!so.has(s.getName())) continue;
                        try {
                            switch (s.getType()) {
                                case NUMBER  -> s.setValue(so.get(s.getName()).getAsDouble());
                                case BOOLEAN -> s.setState(so.get(s.getName()).getAsBoolean());
                                case ENUM    -> s.setOptionIndex(so.get(s.getName()).getAsInt());
                            }
                        } catch (Exception ignored) {}
                    }
                }

                if (obj.has("colors")) {
                    JsonObject co = obj.getAsJsonObject("colors");
                    for (ColorSetting cs : m.getColorSettings()) {
                        if (!co.has(cs.getName())) continue;
                        try {
                            JsonObject c = co.getAsJsonObject(cs.getName());
                            if (c.has("color"))        cs.setColor(c.get("color").getAsInt());
                            if (c.has("rainbow"))      cs.setRainbow(c.get("rainbow").getAsBoolean());
                            if (c.has("rainbowSpeed")) cs.setRainbowSpeed(c.get("rainbowSpeed").getAsFloat());
                        } catch (Exception ignored) {}
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[Enkuron] Ошибка загрузки конфига: " + e.getMessage());
        }
    }

    // ── Утилиты ─────────────────────────────────────────────────────────────

    private static void ensureDirs() {
        CONFIG_DIR.mkdirs();
        PROFILES_DIR.mkdirs();
    }

    private static File profileFile(String name) {
        return new File(PROFILES_DIR, name.replaceAll("[^a-zA-Z0-9_\\-]", "_") + ".json");
    }
}
