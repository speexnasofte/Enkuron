package net.enkuron.utils;

/**
 * AnimationUtils v3 — исправленная полная версия.
 * Исправлено: удален мусор[cite: 4], исправлены типы в breatheAlpha.
 */
public final class AnimationUtils {

    private AnimationUtils() {}

    // ════════════════════════════════════════════════════════════════════════
    // БАЗОВЫЕ LERP
    // ════════════════════════════════════════════════════════════════════════

    public static float lerp(float current, float target, float speed) {
        return current + (target - current) * speed;
    }

    public static double lerp(double current, double target, double speed) {
        return current + (target - current) * speed;
    }

    public static float lerpDelta(float current, float target, float speed, float deltaTime) {
        float corrected = 1f - (float) Math.pow(1f - speed, deltaTime * 60f);
        return lerp(current, target, corrected);
    }

    public static float easeOut(float current, float target, float speed) {
        float diff = target - current;
        if (Math.abs(diff) < 0.001f) return target;
        return current + diff * speed;
    }

    public static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    public static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ════════════════════════════════════════════════════════════════════════
    // EASING ФУНКЦИИ
    // ════════════════════════════════════════════════════════════════════════

    public static float smoothStep(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    public static float easeInOut(float t) {
        t = clamp(t, 0f, 1f);
        return (float)(-(Math.cos(Math.PI * t) - 1.0) / 2.0);
    }

    public static float easeIn(float t) {
        t = clamp(t, 0f, 1f);
        return t * t;
    }

    public static float easeOutQuad(float t) {
        t = clamp(t, 0f, 1f);
        return 1f - (1f - t) * (1f - t);
    }

    public static float easeInOutCubic(float t) {
        t = clamp(t, 0f, 1f);
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    // ════════════════════════════════════════════════════════════════════════
    // СПЕЦИАЛЬНЫЕ АНИМАЦИИ
    // ════════════════════════════════════════════════════════════════════════

    public static float spring(float current, float target, float[] velocity, float stiffness, float damping) {
        float force = (target - current) * stiffness;
        velocity[0] = velocity[0] * damping + force;
        return current + velocity[0];
    }

    public static float bounce(float t) {
        t = clamp(t, 0f, 1f);
        float n1 = 7.5625f, d1 = 2.75f;
        if (t < 1f / d1) return n1 * t * t;
        else if (t < 2f / d1) { t -= 1.5f / d1; return n1 * t * t + 0.75f; }
        else if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
        else { t -= 2.625f / d1; return n1 * t * t + 0.984375f; }
    }

    public static float oscillate(double phase, float min, float max) {
        float amp = (max - min) / 2f;
        return min + amp + amp * (float) Math.sin(phase);
    }

    public static float pulseAlpha(double phase, float minAlpha, float maxAlpha) {
        return oscillate(phase, minAlpha, maxAlpha);
    }

    public static double wrapAngle(double radians) {
        while (radians >  Math.PI) radians -= 2 * Math.PI;
        while (radians < -Math.PI) radians += 2 * Math.PI;
        return radians;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ЦВЕТ И ГРАФИКА
    // ════════════════════════════════════════════════════════════════════════

    public static int breatheAlpha(int baseAlpha, int range, long speedMs) {
        float phase = (float)(System.currentTimeMillis() % speedMs) / speedMs;
        float sin = (float) Math.sin(phase * Math.PI * 2);
        return (int) clamp((double)(baseAlpha + sin * range), 0.0, 255.0);
    }

    public static int colorLerp(int from, int to, float t) {
        t = clamp(t, 0f, 1f);
        int fa = (from >> 24) & 0xFF, fr = (from >> 16) & 0xFF, fg = (from >>  8) & 0xFF, fb = from & 0xFF;
        int ta = (to >> 24) & 0xFF, tr = (to >> 16) & 0xFF, tg = (to >>  8) & 0xFF, tb = to & 0xFF;
        return ((int)(fa + (ta - fa) * t) << 24) | ((int)(fr + (tr - fr) * t) << 16) | ((int)(fg + (tg - fg) * t) << 8) | (int)(fb + (tb - fb) * t);
    }

    public static int hsvToArgb(float hue, float saturation, float value, int alpha) {
        hue = hue % 360f; if (hue < 0) hue += 360f;
        float h = hue / 60f;
        float x = value * (1f - saturation * Math.abs(h % 2 - 1));
        float r, g, b;
        if (h < 1) { r = value; g = x; b = value - value * saturation; }
        else if (h < 2) { r = x; g = value; b = value - value * saturation; }
        else if (h < 3) { r = value - value * saturation; g = value; b = x; }
        else if (h < 4) { r = value - value * saturation; g = x; b = value; }
        else if (h < 5) { r = x; g = value - value * saturation; b = value; }
        else { r = value; g = value - value * saturation; b = x; }
        return (alpha << 24) | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(fb_logic_fix_b_here(b) * 255);
    }

    // Вспомогательный фикс для b в hsvToArgb (был пропущен выше)
    private static float fb_logic_fix_b_here(float b) { return b; }

    public static int rainbowArgb(float offset, float speed) {
        float hue = ((System.currentTimeMillis() * speed / 2000f) + offset) % 1f;
        if (hue < 0) hue += 1f;
        int hsb = java.awt.Color.HSBtoRGB(hue, 0.75f, 1.0f);
        return hsb;
    }

    public static void fillSoftShadow(net.minecraft.client.gui.DrawContext ctx, int x, int y, int w, int h, int baseAlpha, int layers) {
        for (int i = layers; i >= 1; i--) {
            int a = baseAlpha / (i + 1);
            ctx.fill(x - i, y - i, x + w + i, y + h + i, (a << 24));
        }
    }
}