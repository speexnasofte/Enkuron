package net.enkuron.utils;

import java.awt.Color;

/**
 * EnkuronColor — утилиты для работы с цветами.
 * В Minecraft цвета передаются как int в формате ARGB (Alpha, Red, Green, Blue).
 */
public class EnkuronColor {

    // Основные цвета клиента
    public static final int PRIMARY   = toARGB(0, 120, 255, 255);  // Синий
    public static final int SECONDARY = toARGB(30, 30, 30, 220);   // Тёмно-серый
    public static final int TEXT      = toARGB(255, 255, 255, 255); // Белый
    public static final int ENABLED   = toARGB(80, 200, 120, 255);  // Зелёный
    public static final int DISABLED  = toARGB(200, 80, 80, 255);   // Красный

    /**
     * Собрать цвет из компонентов RGBA
     * @param r  красный (0-255)
     * @param g  зелёный (0-255)
     * @param b  синий (0-255)
     * @param a  прозрачность (0=прозрачный, 255=непрозрачный)
     */
    public static int toARGB(int r, int g, int b, int a) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Получить цвет с изменённой прозрачностью
     */
    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    /**
     * Радужный цвет на основе времени — для красивых эффектов
     */
    public static int rainbow(long offset) {
        float hue = (System.currentTimeMillis() + offset) % 2000 / 2000f;
        Color c = Color.getHSBColor(hue, 0.8f, 1.0f);
        return toARGB(c.getRed(), c.getGreen(), c.getBlue(), 255);
    }
}
