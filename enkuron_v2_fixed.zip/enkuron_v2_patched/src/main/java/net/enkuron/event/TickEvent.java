package net.enkuron.event;

import net.minecraft.client.MinecraftClient;

/** Вызывается каждый клиентский тик (END_CLIENT_TICK). */
public class TickEvent {
    public final MinecraftClient client;
    public TickEvent(MinecraftClient client) { this.client = client; }
}
