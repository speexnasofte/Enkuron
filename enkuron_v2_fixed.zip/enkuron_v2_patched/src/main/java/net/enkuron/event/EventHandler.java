package net.enkuron.event;

import java.lang.annotation.*;

/**
 * Помечает метод как обработчик события в EventBus.
 * Метод должен принимать ровно один аргумент — тип события.
 *
 *   @EventHandler
 *   public void onTick(TickEvent e) { ... }
 *
 *   @EventHandler(priority = 10)   // выше = раньше вызывается
 *   public void onPacket(PacketSendEvent e) { ... }
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler {
    /** Приоритет: выше = вызывается первым. По умолчанию 0. */
    int priority() default 0;
}
