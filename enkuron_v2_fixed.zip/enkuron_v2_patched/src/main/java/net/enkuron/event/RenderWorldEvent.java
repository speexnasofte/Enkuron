package net.enkuron.event;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/** Вызывается при рендере мира (TAIL WorldRenderer#render). */
public class RenderWorldEvent {
    public final MatrixStack matrices;
    public final Vec3d       cameraPos;
    public RenderWorldEvent(MatrixStack matrices, Vec3d cameraPos) {
        this.matrices  = matrices;
        this.cameraPos = cameraPos;
    }
}
