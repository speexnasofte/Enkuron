package net.enkuron.event;

import net.minecraft.client.gui.DrawContext;

/** Вызывается при рендере HUD (каждый кадр). */
public class RenderHudEvent {
    public final DrawContext context;
    public RenderHudEvent(DrawContext context) { this.context = context; }
}
