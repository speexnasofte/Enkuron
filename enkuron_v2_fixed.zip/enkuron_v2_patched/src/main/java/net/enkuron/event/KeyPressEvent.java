package net.enkuron.event;

/** Вызывается при нажатии клавиши (из MixinKeyboard). */
public class KeyPressEvent {
    public final int key;
    public final int action; // GLFW_PRESS=1, GLFW_RELEASE=0, GLFW_REPEAT=2
    public KeyPressEvent(int key, int action) { this.key = key; this.action = action; }
}
