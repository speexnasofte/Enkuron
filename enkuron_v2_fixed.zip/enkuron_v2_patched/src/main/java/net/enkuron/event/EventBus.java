package net.enkuron.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * EventBus v2 — шина событий.
 *
 * Исправления:
 *  - CopyOnWriteArrayList: итерация безопасна при подписке/отписке во время post()
 *  - Статический список snapshot: post() не бросает ConcurrentModificationException
 *  - getClass().getDeclaredMethods() + setAccessible: работает с private/protected методами
 */
public final class EventBus {

    private static final CopyOnWriteArrayList<ListenerMethod> listeners = new CopyOnWriteArrayList<>();

    private EventBus() {}

    public static synchronized void subscribe(Object listener) {
        // Защита от двойной подписки
        if (isSubscribed(listener)) return;
        for (Method m : getAllMethods(listener.getClass())) {
            if (!m.isAnnotationPresent(EventHandler.class)) continue;
            if (m.getParameterCount() != 1) continue;
            try { m.setAccessible(true); } catch (Exception ignored) {}
            int priority = m.getAnnotation(EventHandler.class).priority();
            listeners.add(new ListenerMethod(listener, m, priority));
        }
        // Сортировка по приоритету (высокий первым)
        listeners.sort(Comparator.comparingInt(lm -> -lm.priority));
    }

    public static synchronized void unsubscribe(Object listener) {
        listeners.removeIf(lm -> lm.listener == listener);
    }

    public static void post(Object event) {
        Class<?> eventType = event.getClass();
        // CopyOnWriteArrayList итерируется по snapshot — безопасно
        for (ListenerMethod lm : listeners) {
            if (!lm.eventType.isAssignableFrom(eventType)) continue;
            try {
                lm.method.invoke(lm.listener, event);
            } catch (Exception ex) {
                Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                System.err.println("[EventBus] " + lm.listener.getClass().getSimpleName()
                    + "#" + lm.method.getName() + ": " + cause);
            }
        }
    }

    private static boolean isSubscribed(Object listener) {
        for (ListenerMethod lm : listeners)
            if (lm.listener == listener) return true;
        return false;
    }

    /** Собирает все методы включая суперклассы */
    private static List<Method> getAllMethods(Class<?> clazz) {
        List<Method> result = new ArrayList<>();
        while (clazz != null && clazz != Object.class) {
            result.addAll(Arrays.asList(clazz.getDeclaredMethods()));
            clazz = clazz.getSuperclass();
        }
        return result;
    }

    private static class ListenerMethod {
        final Object   listener;
        final Method   method;
        final Class<?> eventType;
        final int      priority;
        ListenerMethod(Object listener, Method method, int priority) {
            this.listener  = listener;
            this.method    = method;
            this.eventType = method.getParameterTypes()[0];
            this.priority  = priority;
        }
    }
}
