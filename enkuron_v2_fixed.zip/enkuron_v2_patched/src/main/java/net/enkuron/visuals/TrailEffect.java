package net.enkuron.visuals;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * TrailEffect — базовый класс для трейл-эффектов (след за игроком/предметом).
 * Хранит очередь позиций и предоставляет доступ к ним для рендера.
 */
public class TrailEffect {
    public record Point(double x, double y, double z, long time) {}

    private final Deque<Point> points = new ArrayDeque<>();
    private final int maxPoints;
    private final long lifetimeMs;

    public TrailEffect() {
        this(30, 600L);
    }

    public TrailEffect(int maxPoints, long lifetimeMs) {
        this.maxPoints = maxPoints;
        this.lifetimeMs = lifetimeMs;
    }

    /** Добавить новую точку следа. */
    public void addPoint(double x, double y, double z) {
        long now = System.currentTimeMillis();
        points.addFirst(new Point(x, y, z, now));
        // Удаляем старые точки
        while (points.size() > maxPoints) points.removeLast();
        points.removeIf(p -> now - p.time() > lifetimeMs);
    }

    /** Очистить след. */
    public void clear() {
        points.clear();
    }

    /** Получить все точки следа (от новых к старым). */
    public Deque<Point> getPoints() {
        return points;
    }

    /** Количество точек в следе. */
    public int size() {
        return points.size();
    }
}
