package net.enkuron.visuals;

/**
 * PulseManager — управляет пульсирующими визуальными эффектами.
 * Хранит текущую фазу пульса и предоставляет значение для рендеров.
 */
public class PulseManager {
    private static float phase = 0f;
    private static long lastUpdate = 0L;

    public PulseManager() {}

    /** Обновить фазу пульса (вызывать каждый тик). */
    public static void tick() {
        long now = System.currentTimeMillis();
        float delta = (now - lastUpdate) / 1000f;
        lastUpdate = now;
        phase = (phase + delta) % (float)(Math.PI * 2);
    }

    /** Получить текущее значение пульса [0..1]. */
    public static float getPulse() {
        return (float)(Math.sin(phase) * 0.5 + 0.5);
    }

    /** Получить сырую фазу в радианах. */
    public static float getPhase() {
        return phase;
    }
}
