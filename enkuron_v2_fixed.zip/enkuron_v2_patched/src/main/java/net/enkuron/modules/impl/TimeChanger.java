package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * TimeChanger — меняет время суток визуально.
 *
 * Настройки:
 *   Время дня — Полдень / Рассвет / Закат / Полночь
 */
public class TimeChanger extends Module {

    private static final String[] TIMES = {"Полдень", "Рассвет", "Закат", "Полночь"};

    private final Setting timeOfDay = new Setting("Время дня", TIMES, 0);

    public TimeChanger() {
        super("TimeChanger", "Меняет время суток визуально для игрока", Category.VISUAL);
        addSetting(timeOfDay);
    }

    public long getTime() {
        return switch (timeOfDay.getCurrentOption()) {
            case "Рассвет"  -> 0L;
            case "Закат"    -> 12000L;
            case "Полночь"  -> 18000L;
            default         -> 6000L; // Полдень
        };
    }
}
