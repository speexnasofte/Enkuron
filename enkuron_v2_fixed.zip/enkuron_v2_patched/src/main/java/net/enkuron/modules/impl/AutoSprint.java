package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * AutoSprint — автоматически включает спринт при движении вперёд.
 *
 * Настройки:
 *   Режим          — Always / OnMove / Combat (ENUM)
 *   В воде         — спринтовать в воде (BOOLEAN)
 *   Только земля   — не спринтовать в воздухе (BOOLEAN)
 */
public class AutoSprint extends Module {

    private final Setting mode       = new Setting("Режим",
            new String[]{"Always", "OnMove", "Combat"}, 0);
    private final Setting inWater    = new Setting("Спринт в воде",    false);
    private final Setting groundOnly = new Setting("Только на земле",  false);

    public AutoSprint() {
        super("AutoSprint", "Автоматический спринт при движении", Category.MOVEMENT);
        addSetting(mode);
        addSetting(inWater);
        addSetting(groundOnly);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.options == null) return;

        boolean moving = mc.options.forwardKey.isPressed();

        // groundOnly
        if (groundOnly.getState() && !mc.player.isOnGround()) return;

        // inWater
        boolean submerged = mc.player.isSubmergedInWater();
        if (submerged && !inWater.getState()) return;

        // mode
        boolean should = switch (mode.getCurrentOption()) {
            case "Always"  -> true;
            case "OnMove"  -> moving;
            case "Combat"  -> moving && mc.targetedEntity != null;
            default        -> moving;
        };

        if (should && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.player.setSprinting(false);
    }
}
