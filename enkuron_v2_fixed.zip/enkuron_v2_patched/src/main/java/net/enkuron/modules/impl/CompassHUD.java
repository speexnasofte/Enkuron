package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

/**
 * CompassHUD — компас с курсом.
 *
 * Настройки:
 *   Ширина     — ширина шкалы (100–300 пикселей)
 *   Обзор      — угол видимой части (90–360 градусов)
 *   Курс цифрой — показывать градусы и сторону рядом
 */
public class CompassHUD extends Module {

    private static final int BAR_HEIGHT = 14;

    private final Setting barWidth   = new Setting("Ширина",       200.0, 100.0, 300.0);
    private final Setting fov        = new Setting("Обзор (°)",    180.0,  90.0, 360.0);
    private final Setting showDegree = new Setting("Курс цифрой",  true);

    public CompassHUD() {
        super("CompassHUD", "Компас с курсом и сторонами света вверху экрана", Category.HUD);
        addSetting(barWidth);
        addSetting(fov);
        addSetting(showDegree);
        this.width  = 200;
        this.height = BAR_HEIGHT;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int bw = (int) barWidth.getValue();
        this.width  = bw;
        int screenW = mc.getWindow().getScaledWidth();
        this.x = screenW / 2 - bw / 2;
        this.y = 4;

        float yaw = MathHelper.wrapDegrees(mc.player.getYaw());
        if (yaw < 0) yaw += 360f;

        context.fill(x, y, x + bw, y + BAR_HEIGHT, 0xBB111116);
        context.fill(x, y, x + bw, y + 1, 0xFF8844FF);

        String[] dirs  = {"N","NE","E","SE","S","SW","W","NW","N"};
        float[]  degs  = {0, 45, 90, 135, 180, 225, 270, 315, 360};
        int[]    colors= {0xFFEE4444,0xFFAAAAAA,0xFFFFFFFF,0xFFAAAAAA,
                          0xFF4488FF,0xFFAAAAAA,0xFFFFFFFF,0xFFAAAAAA,0xFFEE4444};

        float halfFov = (float)(fov.getValue() / 2.0);

        for (int i = 0; i < dirs.length; i++) {
            float delta = MathHelper.wrapDegrees(degs[i] - yaw);
            if (Math.abs(delta) > halfFov) continue;

            int markerX = x + bw / 2 + (int)(delta / halfFov * (bw / 2));
            int tw = mc.textRenderer.getWidth(dirs[i]);
            context.fill(markerX, y + 2, markerX + 1, y + BAR_HEIGHT - 2, 0xFF666677);
            context.drawText(mc.textRenderer, dirs[i], markerX - tw / 2, y + 3, colors[i], true);
        }

        context.fill(x + bw / 2 - 1, y, x + bw / 2 + 1, y + BAR_HEIGHT, 0xFFFFFFFF);

        if (showDegree.getState()) {
            Direction facing = mc.player.getHorizontalFacing();
            String info = String.format("%.0f° %s", yaw, facing.getName().toUpperCase());
            int infoW = mc.textRenderer.getWidth(info);
            context.drawText(mc.textRenderer, info, x + bw / 2 - infoW / 2, y + BAR_HEIGHT + 2, 0xFFAAAAAA, true);
        }
    }
}
