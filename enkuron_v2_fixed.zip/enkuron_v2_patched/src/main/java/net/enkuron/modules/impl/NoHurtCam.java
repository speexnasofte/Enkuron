package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * NoHurtCam — убирает (или уменьшает) тряску камеры при получении урона.
 *
 * Настройки:
 *   Режим      — Off / Reduce / Full (ENUM)
 *               Off    = модуль выключен (не используется здесь)
 *               Reduce = уменьшает интенсивность
 *               Full   = полностью убирает
 *   Интенсивность (%) — 0–90, активен только в режиме Reduce (NUMBER)
 *
 * Реализация: через mixin-хук или переопределение поля hurtCamIntensity.
 * Для Fabric 1.20.x подходит патч через accessor к GameRenderer.
 * Здесь — thin wrapper: хранит настройки, логику применяет MixinGameRenderer.
 */
public class NoHurtCam extends Module {

    private static NoHurtCam INSTANCE;

    private final Setting modeS     = new Setting("Режим",
            new String[]{"Reduce", "Full"}, 1);
    private final Setting intensity = new Setting("Интенсивность (%)", 30.0, 0.0, 90.0);

    public NoHurtCam() {
        super("NoHurtCam", "Убирает или уменьшает тряску камеры при уроне", Category.VISUAL);
        addSetting(modeS);
        addSetting(intensity);
        INSTANCE = this;
    }

    public static NoHurtCam getInstance() { return INSTANCE; }

    /**
     * Вызывается из MixinGameRenderer перед обсчётом hurtCamIntensity.
     * @param original оригинальный multiplier
     * @return скорректированное значение (0 = полностью выключено)
     */
    public float applyToIntensity(float original) {
        if (!isEnabled()) return original;
        return switch (modeS.getCurrentOption()) {
            case "Full"   -> 0f;
            case "Reduce" -> original * ((float) intensity.getValue() / 100f);
            default       -> original;
        };
    }
}
