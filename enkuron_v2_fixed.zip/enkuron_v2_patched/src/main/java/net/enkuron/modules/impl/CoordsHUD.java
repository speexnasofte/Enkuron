package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Direction;

/**
 * CoordsHUD — координаты X Y Z и направление взгляда.
 *
 * Настройки:
 *   Точность     — количество знаков после запятой (0–2)
 *   Направление  — показывать сторону света
 *   Нether-коорд — показывать координаты в нижнем мире (/8)
 */
public class CoordsHUD extends Module {

    private static final String[] PRECISIONS = {"0", "1", "2"};

    private final Setting precision    = new Setting("Точность",      PRECISIONS, 0);
    private final Setting showFacing   = new Setting("Направление",   true);
    private final Setting netherCoords = new Setting("Nether-коорд",  false);

    public CoordsHUD() {
        super("CoordsHUD", "Показывает координаты X, Y, Z и сторону света", Category.HUD);
        addSetting(precision);
        addSetting(showFacing);
        addSetting(netherCoords);
        this.x = 5; this.y = 50;
        this.width = 130; this.height = 22;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int dec = precision.getOptionIndex();
        String fmt = "%." + dec + "f";

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        // FIX: строим одну format-строку заранее (конкатенация fmt внутри format вызывала IllegalFormatException)
        String coordFmt = "X" + fmt + "  Y" + fmt + "  Z" + fmt;
        String line1 = String.format(coordFmt, px, py, pz);
        String line2 = "";

        if (showFacing.getState()) {
            Direction facing = mc.player.getHorizontalFacing();
            String fs = facing.getName().substring(0, 1).toUpperCase();
            line2 = "Facing: " + facing.getName() + " [" + fs + "]";
        }

        String line3 = "";
        if (netherCoords.getState()) {
            line3 = String.format("Nether: " + fmt + " / " + fmt, px / 8, pz / 8);
        }

        int lineCount = 1 + (showFacing.getState() ? 1 : 0) + (netherCoords.getState() ? 1 : 0);
        this.height = lineCount * 11 + 4;

        int maxW = mc.textRenderer.getWidth(line1);
        if (!line2.isEmpty()) maxW = Math.max(maxW, mc.textRenderer.getWidth(line2));
        if (!line3.isEmpty()) maxW = Math.max(maxW, mc.textRenderer.getWidth(line3));
        this.width = maxW + 10;

        context.fill(x - 2, y - 2, x + maxW + 6, y + height, 0xBB111116);
        context.fill(x - 2, y - 2, x + maxW + 6, y - 1, 0xFF8844FF);

        int dy = y + 1;
        context.drawText(mc.textRenderer, line1, x + 2, dy, 0xFFFFFFFF, true);
        if (!line2.isEmpty()) context.drawText(mc.textRenderer, line2, x + 2, dy + 11, 0xFFAAAAAA, true);
        if (!line3.isEmpty()) context.drawText(mc.textRenderer, line3, x + 2, dy + (showFacing.getState() ? 22 : 11), 0xFF88AAFF, true);
    }
}
