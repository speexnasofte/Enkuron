package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * HealthBar — показывает полоску HP над игроками/мобами в виде HUD-списка.
 *
 * Для настоящего рендера над головами нужен Mixin в WorldRenderer,
 * здесь — HUD-список ближайших целей с полосками HP.
 */
public class HealthBar extends Module {

    private final Setting range      = new Setting("Дальность (блоки)", 24.0, 8.0, 48.0);
    private final Setting onlyPlayer = new Setting("Только игроки",      true);
    private final Setting maxTargets = new Setting("Макс. целей",         5.0, 1.0, 10.0);
    private final Setting updateRate = new Setting("Обновление (тики)",   3.0, 1.0, 10.0);

    private record HpEntry(String name, float hp, float maxHp) {}
    private final List<HpEntry> cached = new ArrayList<>();
    private int tickCounter = 0;

    public HealthBar() {
        super("HealthBar", "Полоски HP ближайших игроков/мобов", Category.HUD);
        this.x = 5; this.y = 400;
        addSetting(range);
        addSetting(onlyPlayer);
        addSetting(maxTargets);
        addSetting(updateRate);
    }

    @Override
    public void onEnable() { cached.clear(); tickCounter = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (++tickCounter < (int) updateRate.getValue()) return;
        tickCounter = 0;

        cached.clear();
        double rng = range.getValue();
        int max = (int) maxTargets.getValue();

        for (Entity e : mc.world.getEntities()) {
            if (cached.size() >= max) break;
            if (!(e instanceof LivingEntity le)) continue;
            if (le.equals(mc.player) || !le.isAlive()) continue;
            if (onlyPlayer.getState() && !(le instanceof PlayerEntity)) continue;

            // FIX: используем полное 3D расстояние (был только XZ — игрок с большой разницей Y не отображался)
            double dx = le.getX() - mc.player.getX();
            double dy = le.getY() - mc.player.getY();
            double dz = le.getZ() - mc.player.getZ();
            if (dx * dx + dy * dy + dz * dz > rng * rng) continue;

            cached.add(new HpEntry(le.getName().getString(), le.getHealth(), le.getMaxHealth()));
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || cached.isEmpty()) return;

        int barW  = 100;
        int entH  = 14;
        int boxH  = cached.size() * entH + 6;
        this.width = barW + 30; this.height = boxH;

        context.fill(x - 2, y - 2, x + barW + 28, y + boxH, 0xBB0A0A14);
        context.fill(x - 2, y - 2, x - 1, y + boxH, 0xFF44AAFF);

        for (int i = 0; i < cached.size(); i++) {
            HpEntry e  = cached.get(i);
            int ty     = y + 2 + i * entH;
            float ratio = Math.min(e.hp() / e.maxHp(), 1f);
            int col    = hpColor(ratio);

            // Имя (обрезаем)
            String name = e.name().length() > 9 ? e.name().substring(0, 9) + "." : e.name();
            context.drawText(mc.textRenderer, "§f" + name, x + 2, ty + 2, 0xFFFFFFFF, false);

            // Полоска
            int bx = x + 56;
            context.fill(bx, ty + 2, bx + barW - 56, ty + 10, 0xFF333333);
            context.fill(bx, ty + 2, bx + (int)((barW - 56) * ratio), ty + 10, col);

            // Цифра HP
            String hpStr = String.format("%.0f", e.hp());
            context.drawText(mc.textRenderer, hpStr, bx + barW - 54, ty + 2, col, false);
        }
    }

    private int hpColor(float ratio) {
        if (ratio > 0.6f) return 0xFF44EE77;
        if (ratio > 0.3f) return 0xFFFFAA22;
        return 0xFFEE3333;
    }
}
