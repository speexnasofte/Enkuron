package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * Blur — размывает задний фон в меню.
 *
 * Эмулируется через полупрозрачный тёмный оверлей поверх экрана
 * (настоящий Gaussian blur требует шейдера, но этот подход работает
 * без дополнительных зависимостей).
 *
 * onlyMenu — применяется только когда открыт экран (currentScreen != null).
 */
public class Blur extends Module {
    private final Setting intensity = new Setting("Интенсивность", 5.0, 1.0, 20.0);
    private final Setting onlyMenu  = new Setting("Только меню",   true);

    public Blur() {
        super("Blur", "Затемняет задний план в меню", Category.VISUAL);
        addSetting(intensity);
        addSetting(onlyMenu);
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled()) return;
        if (onlyMenu.getState() && mc.currentScreen == null) return;

        // FIX: null-check window (может быть null при инициализации)
        if (mc.getWindow() == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Альфа зависит от intensity (1→20 => 0x15→0xA0)
        int alpha = (int) (0x15 + (intensity.getValue() / 20.0) * 0x8B);
        int color = (alpha << 24); // чёрный с переменной прозрачностью

        ctx.fill(0, 0, sw, sh, color);
    }
}
