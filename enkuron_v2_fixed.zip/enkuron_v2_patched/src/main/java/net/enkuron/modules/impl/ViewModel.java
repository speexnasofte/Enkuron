package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * ViewModel — изменяет положение и масштаб руки/предмета в первом лице.
 *
 * Каждое значение применяется через MixinGameRenderer (метод bobView или аналог).
 * Дублирует идею OptiFine Hand, но с большей гибкостью.
 *
 * Настройки:
 *   Смещение X (право/лево)  — -1.0 – 1.0
 *   Смещение Y (вверх/вниз)  — -1.0 – 1.0
 *   Смещение Z (ближе/дальше) — -1.0 – 1.0
 *   Масштаб                  — 0.5 – 2.0
 *   Анимация качания         — вкл/выкл (убирает боб-эффект)
 *   Основная рука            — Right / Left / Both
 */
public class ViewModel extends Module {

    private static final String[] HANDS = {"Right", "Left", "Both"};

    private final Setting offsetX     = new Setting("Смещение X",        0.0, -1.0, 1.0);
    private final Setting offsetY     = new Setting("Смещение Y",        0.0, -1.0, 1.0);
    private final Setting offsetZ     = new Setting("Смещение Z",        0.0, -1.0, 1.0);
    private final Setting scale       = new Setting("Масштаб",           1.0,  0.5, 2.0);
    private final Setting bobbing     = new Setting("Анимация качания",  true);
    private final Setting hand        = new Setting("Рука",              HANDS, 0);

    public ViewModel() {
        super("ViewModel", "Смещение, масштаб и качание предмета в руке", Category.VISUAL);
        addSetting(offsetX);
        addSetting(offsetY);
        addSetting(offsetZ);
        addSetting(scale);
        addSetting(bobbing);
        addSetting(hand);
    }

    public float getOffsetX()  { return (float) offsetX.getValue(); }
    public float getOffsetY()  { return (float) offsetY.getValue(); }
    public float getOffsetZ()  { return (float) offsetZ.getValue(); }
    public float getScale()    { return (float) scale.getValue(); }
    public boolean isBobbing() { return bobbing.getState(); }
    public String getHand()    { return hand.getCurrentOption(); }
}
