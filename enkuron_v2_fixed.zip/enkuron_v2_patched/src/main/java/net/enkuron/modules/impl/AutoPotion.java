package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * AutoPotion — автоматически пьёт зелья при низком HP или отсутствии нужного эффекта.
 *
 * Ищет зелья в хотбаре по приоритету: исцеление → скорость → сила.
 * После питья выдерживает кулдаун, чтобы не спамить.
 *
 * Настройки:
 *   Порог HP (%)     — 20 – 80 (пить при HP ниже этого % от максимума)
 *   Пить силу        — вкл/выкл
 *   Пить скорость    — вкл/выкл
 *   Кулдаун (сек)    — 2 – 15
 *   Только в бою     — вкл (только если рядом враг)
 *   Радиус врага     — 8 – 32 блока
 */
public class AutoPotion extends Module {

    private final Setting hpThreshold  = new Setting("Порог HP (%)",   40.0, 20.0, 80.0);
    private final Setting drinkStrength = new Setting("Пить Силу",      true);
    private final Setting drinkSpeed    = new Setting("Пить Скорость",  true);
    private final Setting cooldown      = new Setting("Кулдаун (сек)",   5.0,  2.0, 15.0);
    private final Setting onlyInCombat  = new Setting("Только в бою",   false);
    private final Setting enemyRange    = new Setting("Радиус врага",   16.0,  8.0, 32.0);

    private int savedSlot     = -1;
    private int cooldownTimer = 0;

    public AutoPotion() {
        super("AutoPotion", "Пьёт зелья исцеления, скорости или силы автоматически", Category.PLAYER);
        addSetting(hpThreshold);
        addSetting(drinkStrength);
        addSetting(drinkSpeed);
        addSetting(cooldown);
        addSetting(onlyInCombat);
        addSetting(enemyRange);
    }

    @Override
    public void onDisable() {
        cooldownTimer = 0;
        if (mc.player != null) {
            mc.options.useKey.setPressed(false);
            if (savedSlot != -1) {
                mc.player.getInventory().selectedSlot = savedSlot;
            }
        }
        savedSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        // FIX: кулдаун тикает — сбрасываем клавишу и слот когда кулдаун истёк
        if (cooldownTimer > 0) {
            cooldownTimer--;
            if (cooldownTimer == 0) {
                mc.options.useKey.setPressed(false);
                if (savedSlot != -1) {
                    mc.player.getInventory().selectedSlot = savedSlot;
                    savedSlot = -1;
                }
            }
            return;
        }

        float maxHp     = mc.player.getMaxHealth();
        float currentHp = mc.player.getHealth();
        float hpPercent = (currentHp / maxHp) * 100f;
        boolean needHeal = hpPercent <= hpThreshold.getValue();

        // Если нужно пить только в бою — проверяем ближайшего врага
        if (onlyInCombat.getState() && !hasNearbyEnemy()) return;

        if (!needHeal) return;

        int potionSlot = findPotion();
        if (potionSlot == -1) return;

        savedSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = potionSlot;
        mc.options.useKey.setPressed(true);
        cooldownTimer = (int) (cooldown.getValue() * 20);
    }

    private int findPotion() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.getItem() == Items.POTION) {
                // В реальной реализации — проверить компоненты зелья
                return i;
            }
        }
        return -1;
    }

    private boolean hasNearbyEnemy() {
        double r = enemyRange.getValue();
        return mc.world.getEntitiesByClass(
            net.minecraft.entity.mob.HostileEntity.class,
            mc.player.getBoundingBox().expand(r),
            e -> true
        ).size() > 0;
    }
}
