package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.modules.SettingPresets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Tracers v3 — переведён на SettingPresets.
 */
public class Tracers extends Module {

    private static final String[] MODES = {"Compass", "List", "Both", "Arrows"};

    // ── Универсальные пресеты ─────────────────────────────────────────────────
    private final SettingPresets.TargetFilter targetFilter = new SettingPresets.TargetFilter();
    private final SettingPresets.Range        range        = new SettingPresets.Range(64.0, 16.0, 128.0);
    private final SettingPresets.MaxTargets   maxTargets   = new SettingPresets.MaxTargets(6.0, 1.0, 12.0);
    private final SettingPresets.UpdateRate   updateRate   = new SettingPresets.UpdateRate(4.0, 1.0, 10.0);

    // ── Собственные настройки ─────────────────────────────────────────────────
    private final Setting mode    = new Setting("Режим",    MODES, 0);
    private final Setting animate = new Setting("Анимация", true);

    private record TracerEntry(String name, double angle, double dist, int color) {}
    private final List<TracerEntry> cached = new ArrayList<>();

    // Анимация: текущие сглаженные X-позиции на компасе (lerp)
    private final float[] dotLerpX = new float[12];
    private final float[] dotAlpha = new float[12];  // 0..1 fade
    private int animTick = 0;

    public Tracers() {
        super("Tracers", "Компас с анимированными направлениями до ближайших целей", Category.VISUAL);
        this.x = 200; this.y = 5;
        targetFilter.addTo(this);  // Игроки / Враждебные / Пассивные / Животные
        range.addTo(this);         // Дальность
        maxTargets.addTo(this);    // Макс. целей
        updateRate.addTo(this);    // Обновление (тики)
        addSetting(mode);
        addSetting(animate);
    }

    @Override
    public void onEnable() {
        cached.clear(); animTick = 0;
        updateRate.reset();
        java.util.Arrays.fill(dotAlpha, 0f);
        java.util.Arrays.fill(dotLerpX, 0f);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        animTick++;
        if (!updateRate.ready()) return;

        cached.clear();
        Vec3d  pp   = mc.player.getPos();
        float  yaw  = mc.player.getYaw();

        List<TracerEntry> all = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le.equals(mc.player) || !le.isAlive()) continue;
            if (!targetFilter.passes(le)) continue;
            if (!range.inRange(le, mc.player)) continue;

            double dx = le.getX() - pp.x;
            double dz = le.getZ() - pp.z;
            double dist = Math.sqrt(dx * dx + dz * dz);

            double worldAngle = Math.toDegrees(Math.atan2(dz, dx)) - 90;
            double relAngle   = ((worldAngle - yaw) % 360 + 360) % 360;
            if (relAngle > 180) relAngle -= 360;

            int color = le instanceof PlayerEntity ? 0xFFFF5555 :
                        le instanceof HostileEntity ? 0xFFFFAA33 : 0xFF55FF55;

            all.add(new TracerEntry(le.getName().getString(), relAngle, dist, color));
        }

        all.sort((a, b) -> Double.compare(a.dist(), b.dist()));
        List<TracerEntry> limited = maxTargets.limit(all);
        cached.addAll(limited);
        int take = limited.size();

        // Обновляем целевые X-позиции для lerp
        int compW = 160;
        int cx = x + compW / 2;
        for (int i = 0; i < take; i++) {
            float targetX = cx + (float)(cached.get(i).angle() / 90.0 * 70);
            if (animate.getState()) {
                dotLerpX[i] += (targetX - dotLerpX[i]) * 0.35f;
                dotAlpha[i] = Math.min(1f, dotAlpha[i] + 0.15f);
            } else {
                dotLerpX[i] = targetX;
                dotAlpha[i] = 1f;
            }
        }
        for (int i = take; i < 12; i++) {
            dotAlpha[i] = Math.max(0f, dotAlpha[i] - 0.2f);
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        String m = mode.getCurrentOption();
        if (m.equals("Compass") || m.equals("Both")) renderCompass(context);
        if (m.equals("List")    || m.equals("Both")) renderList(context);
        if (m.equals("Arrows"))                      renderArrows(context);
    }

    // ── Compass ───────────────────────────────────────────────────────────────

    private void renderCompass(DrawContext ctx) {
        int compW = 160;
        int compH = 18;
        int cx    = x + compW / 2;

        ctx.fill(x, y, x + compW, y + compH, 0xBB0A0A14);
        ctx.fill(x, y,            x + compW, y + 1,          0xFF8844FF);
        ctx.fill(x, y + compH - 1, x + compW, y + compH,     0xFF8844FF);
        ctx.fill(x, y,             x + 1,     y + compH,     0xFF8844FF);
        ctx.fill(x + compW - 1, y, x + compW, y + compH,     0xFF8844FF);

        // Центральный маркер + метки сторон света
        ctx.fill(cx - 1, y + 2, cx + 1, y + compH - 2, 0xFFFFFFFF);
        ctx.drawText(mc.textRenderer, "§7N", cx - 2, y + 3, 0xFFAAAAAA, false);

        // Анимированный "пульс" вокруг ближайшей цели
        if (animate.getState() && !cached.isEmpty()) {
            int pulsePhase = animTick % 20;
            int alpha = pulsePhase < 10 ? pulsePhase * 20 : (20 - pulsePhase) * 20;
            int px = (int) dotLerpX[0];
            if (px >= x + 2 && px <= x + compW - 2) {
                int pColor = (alpha << 24) | (cached.get(0).color() & 0x00FFFFFF);
                ctx.fill(px - 3, y + 1, px + 4, y + compH - 1, pColor);
            }
        }

        // Точки целей со сглаживанием
        for (int i = 0; i < cached.size(); i++) {
            TracerEntry t = cached.get(i);
            int lx = (int) dotLerpX[i];
            if (lx < x + 2 || lx > x + compW - 2) continue;

            int a  = (int)(dotAlpha[i] * 255) & 0xFF;
            int col = (a << 24) | (t.color() & 0x00FFFFFF);

            // Размер точки зависит от дистанции: ближе = больше
            float distRatio = (float)(1.0 - Math.min(t.dist() / range.getValue(), 1.0));
            int dotSize = 1 + (int)(distRatio * 2);
            ctx.fill(lx - dotSize, y + 3, lx + dotSize + 1, y + compH - 3, col);
        }

        this.width = compW; this.height = compH;
    }

    // ── List ─────────────────────────────────────────────────────────────────

    private void renderList(DrawContext ctx) {
        if (cached.isEmpty()) return;
        int offsetY = mode.getCurrentOption().equals("Both") ? 22 : 0;
        int lineH   = 10;
        int boxW    = 140;

        for (int i = 0; i < cached.size(); i++) {
            TracerEntry t = cached.get(i);
            int ty = y + offsetY + i * lineH;
            String dir = angleToDirChar(t.angle());
            String txt = dir + " §f" + shortName(t.name()) +
                         " §8" + String.format("%.0fm", t.dist());
            ctx.fill(x - 2, ty - 1, x + boxW, ty + 9, 0x88000000);
            ctx.drawText(mc.textRenderer, txt, x, ty, t.color(), true);
        }
        this.height = offsetY + cached.size() * lineH;
        this.width  = 140;
    }

    // ── Arrows (новый режим) ──────────────────────────────────────────────────

    /**
     * Режим "Arrows": крупные стрелки вокруг центра экрана.
     * Каждая цель — стрелка (◄ ► ▲ ▼ или диагональ) с именем и дистанцией.
     */
    private void renderArrows(DrawContext ctx) {
        if (cached.isEmpty() || mc.getWindow() == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int pcx = sw / 2;
        int pcy = sh / 2;
        int radius = Math.min(sw, sh) / 3;

        for (int i = 0; i < cached.size(); i++) {
            TracerEntry t = cached.get(i);
            double rad = Math.toRadians(t.angle() - 90); // -90 = вверх
            int ax = pcx + (int)(Math.cos(rad) * radius);
            int ay = pcy + (int)(Math.sin(rad) * radius);

            String arrow = angleToArrow(t.angle());
            String label = arrow + " §f" + shortName(t.name()) + " §8" + (int)t.dist() + "m";

            int lw = mc.textRenderer.getWidth(label);
            ctx.fill(ax - lw/2 - 2, ay - 6, ax + lw/2 + 2, ay + 8, 0xAA000000);
            ctx.drawText(mc.textRenderer, label, ax - lw / 2, ay - 4, t.color(), true);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private String angleToDirChar(double angle) {
        if (angle >  135 || angle < -135) return "§c<<";
        if (angle >   90) return "§e< ";
        if (angle >   20) return "§a/ ";
        if (angle >  -20) return "§f^ ";
        if (angle >  -90) return "§a\\ ";
        if (angle > -135) return "§e >";
        return "§c>>";
    }

    private String angleToArrow(double angle) {
        if (angle >  157 || angle < -157) return "§c◄";
        if (angle >  112) return "§e↙";
        if (angle >   67) return "§e▼";
        if (angle >   22) return "§a↘";
        if (angle >  -22) return "§f▲";
        if (angle >  -67) return "§a↗";
        if (angle > -112) return "§e▲";
        if (angle > -157) return "§e↖";
        return "§c►";
    }

    private String shortName(String name) {
        return name.length() > 12 ? name.substring(0, 12) + "..." : name;
    }
}
