package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * AutoFish v7 — ФИКС: заменён setPressed(true/false) на interactItem,
 * т.к. в 1.21.4 KeyBinding.setPressed не всегда корректно посылает пакет.
 * Также добавлена защита: если рыбак прерван (bobber == null в WATCHING) —
 * возвращаемся в IDLE, а не зависаем.
 */
public class AutoFish extends Module {

    private final Setting recastDelay = new Setting("Задержка подсечки (сек)", 0.3, 0.1, 1.5);
    private final Setting autoRecast  = new Setting("Авто-перезаброс",          true);
    private final Setting rodOnly     = new Setting("Только с удочкой",         true);

    private double lastBobberY  = 0;
    private int    waitTicks    = 0;
    private int    recastTimer  = 0;
    // FIX: toggle() из onTick() вызывает subscribe/unsubscribe во время итерации EventBus
    // — используем флаг, модуль отключится в следующем тике вне итерации
    private boolean pendingDisable = false;

    private enum Phase { IDLE, CAST, WATCHING, REEL, RECAST }
    private Phase phase = Phase.IDLE;

    public AutoFish() {
        super("AutoFish", "Автоматическая рыбалка с подсечкой по поклёвке", Category.UTILITY);
        addSetting(recastDelay);
        addSetting(autoRecast);
        addSetting(rodOnly);
    }

    @Override
    public void onEnable()  { phase = Phase.IDLE; waitTicks = 0; recastTimer = 0; pendingDisable = false; }

    @Override
    public void onDisable() { phase = Phase.IDLE; pendingDisable = false; }

    @Override
    public void onTick() {
        // FIX: обрабатываем отложенное отключение вне итерации EventBus
        if (pendingDisable) { pendingDisable = false; setEnabled(false); return; }
        if (mc.player == null || mc.interactionManager == null) return;
        if (rodOnly.getState() && !holdingRod()) return;

        switch (phase) {
            case IDLE -> {
                // FIX: используем interactItem вместо setPressed
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                phase = Phase.CAST;
                waitTicks = 6;
            }
            case CAST -> {
                if (--waitTicks <= 0) {
                    phase = Phase.WATCHING;
                    var bobber = mc.player.fishHook;
                    lastBobberY = bobber != null ? bobber.getY() : 0;
                }
            }
            case WATCHING -> {
                var bobber = mc.player.fishHook;
                // FIX: если поплавка нет — возврат в IDLE (не зависаем)
                if (bobber == null) { phase = Phase.IDLE; return; }

                double currentY = bobber.getY();
                if (lastBobberY - currentY > 0.04) {
                    waitTicks = (int)(recastDelay.getValue() * 20);
                    phase = Phase.REEL;
                }
                lastBobberY = currentY;
            }
            case REEL -> {
                if (--waitTicks <= 0) {
                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                    phase = Phase.RECAST;
                    recastTimer = 8;
                }
            }
            case RECAST -> {
                if (--recastTimer <= 0) {
                    if (autoRecast.getState()) {
                        phase = Phase.IDLE;
                    } else {
                        // FIX: не вызываем toggle() изнутри onTick() — откладываем на следующий тик
                        phase = Phase.IDLE;
                        pendingDisable = true;
                    }
                }
            }
        }
    }

    private boolean holdingRod() {
        if (mc.player == null) return false;
        return mc.player.getMainHandStack().getItem() == Items.FISHING_ROD
            || mc.player.getOffHandStack().getItem()  == Items.FISHING_ROD;
    }
}
