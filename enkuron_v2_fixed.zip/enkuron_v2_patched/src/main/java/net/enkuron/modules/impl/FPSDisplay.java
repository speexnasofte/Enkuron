package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

/**
 * FPSDisplay — показывает FPS с цветовой индикацией производительности.
 *
 * Настройки:
 *   Позиция       — TOP_LEFT / TOP_RIGHT / BOTTOM_LEFT / BOTTOM_RIGHT
 *   Цвет по FPS   — включить/выключить цветовую индикацию
 *   Фон           — показывать фон
 */
public class FPSDisplay extends Module {

    private static final String[] POSITIONS = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"};

    private final Setting position    = new Setting("Позиция",       POSITIONS, 0);
    private final Setting colorByFps  = new Setting("Цвет по FPS",   true);
    private final Setting showBg      = new Setting("Фон",           true);

    public FPSDisplay() {
        super("FPSDisplay", "Показывает текущий FPS", Category.HUD);
        addSetting(position);
        addSetting(colorByFps);
        addSetting(showBg);
        this.x = 5;
        this.y = 5;
        this.width  = 65;
        this.height = 14;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;
        int fps = mc.getCurrentFps();

        int color;
        if (colorByFps.getState()) {
            if (fps >= 120)     color = 0xFF44EE77;
            else if (fps >= 60) color = 0xFFFFFF44;
            else if (fps >= 30) color = 0xFFFF9944;
            else                color = 0xFFEE4444;
        } else {
            color = 0xFFFFFFFF;
        }

        // Применяем позицию
        applyPosition();

        String text = "FPS " + fps;
        int tw = mc.textRenderer.getWidth(text);
        this.width = tw + 8;

        if (showBg.getState()) {
            context.fill(x - 2, y - 1, x + tw + 4, y + 10, 0xBB111116);
            context.fill(x - 2, y - 1, x - 1,      y + 10, color);
        }

        context.drawText(mc.textRenderer, text, x + 2, y, color, true);
    }

    private void applyPosition() {
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        switch (position.getCurrentOption()) {
            case "TOP_LEFT"     -> { x = 5;           y = 5; }
            case "TOP_RIGHT"    -> { x = sw - width - 5; y = 5; }
            case "BOTTOM_LEFT"  -> { x = 5;           y = sh - height - 5; }
            case "BOTTOM_RIGHT" -> { x = sw - width - 5; y = sh - height - 5; }
        }
    }
}
