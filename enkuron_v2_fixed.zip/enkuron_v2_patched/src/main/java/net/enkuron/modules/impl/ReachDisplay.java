package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * ReachDisplay — дистанция до цели.
 *
 * Настройки:
 *   Точность      — знаков после запятой (1–3)
 *   Только сущности — показывать только при прицеле на сущность
 */
public class ReachDisplay extends Module {

    private static final String[] PRECISIONS = {"1", "2", "3"};

    private final Setting precision      = new Setting("Точность",         PRECISIONS, 1);
    private final Setting entityOnly     = new Setting("Только сущности",  true);

    private double lastReach = 0;

    public ReachDisplay() {
        super("ReachDisplay", "Показывает дистанцию последнего удара", Category.HUD);
        addSetting(precision);
        addSetting(entityOnly);
        this.x = 5; this.y = 180;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        HitResult hit = mc.crosshairTarget;
        boolean isEntity = hit != null && hit.getType() == HitResult.Type.ENTITY;

        if (isEntity) {
            lastReach = hit.getPos().distanceTo(mc.player.getEyePos());
        } else if (entityOnly.getState()) {
            return;
        }

        String fmt = "%." + precision.getCurrentOption() + "f";
        String text = "Reach: " + String.format(fmt, lastReach);
        context.drawText(mc.textRenderer, text, x, y, isEntity ? 0xFFFFFFFF : 0xFF888888, true);
    }
}
