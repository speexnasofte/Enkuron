package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

public class AutoWalk extends Module {
    private static final String[] MODES = {"Forward", "Backward", "Strafe Left", "Strafe Right"};
    private final Setting mode = new Setting("Направление", MODES, 0);

    public AutoWalk() {
        super("AutoWalk", "Автоматически идёт в заданном направлении", Category.MOVEMENT);
        addSetting(mode);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        switch (mode.getCurrentOption()) {
            case "Forward"      -> mc.options.forwardKey.setPressed(true);
            case "Backward"     -> mc.options.backKey.setPressed(true);
            case "Strafe Left"  -> mc.options.leftKey.setPressed(true);
            case "Strafe Right" -> mc.options.rightKey.setPressed(true);
        }
    }

    @Override
    public void onDisable() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
    }
}
