package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.modules.SettingPresets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * GlowESP v3 — переведён на SettingPresets.
 */
public class GlowESP extends Module {

    // ── Универсальные пресеты ─────────────────────────────────────────────────
    private final SettingPresets.TargetFilter targetFilter = new SettingPresets.TargetFilter();
    private final SettingPresets.Range        range        = new SettingPresets.Range(48.0, 16.0, 96.0);
    private final SettingPresets.UpdateRate   updateRate   = new SettingPresets.UpdateRate(5.0);

    // ── Собственные настройки ─────────────────────────────────────────────────
    private final Setting showNearest = new Setting("Показывать ближайшего", true);
    private final Setting showHPBar   = new Setting("Полоса HP",             true);

    private LivingEntity nearestCache = null;
    private double nearestDist = 0;
    private final java.util.Set<LivingEntity> glowingSet = new java.util.HashSet<>();

    public GlowESP() {
        super("GlowESP", "Подсвечивает игроков и мобов вокруг (Glow) + HUD полоса HP", Category.VISUAL);
        targetFilter.addTo(this);   // Игроки / Враждебные / Пассивные / Животные
        range.addTo(this);          // Дальность
        updateRate.addTo(this);     // Обновление (тики)
        addSetting(showNearest);
        addSetting(showHPBar);
        this.x = 5; this.y = 250;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (!updateRate.ready()) return;

        nearestCache = null;
        nearestDist  = Double.MAX_VALUE;
        for (LivingEntity prev : glowingSet) { if (prev.isAlive()) prev.setGlowing(false); }
        glowingSet.clear();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player) || !living.isAlive()) continue;
            if (!targetFilter.passes(living)) continue;
            if (!range.inRange(living, mc.player)) continue;

            living.setGlowing(true);
            glowingSet.add(living);

            double dist = living.getPos().distanceTo(mc.player.getPos());
            if (showNearest.getState() && dist < nearestDist) {
                nearestDist  = dist;
                nearestCache = living;
            }
        }
    }

    @Override
    public void onDisable() {
        for (LivingEntity e : glowingSet) if (e.isAlive()) e.setGlowing(false);
        glowingSet.clear();
        nearestCache = null;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || !showNearest.getState() || nearestCache == null) return;

        LivingEntity t = nearestCache;
        float hp    = t.getHealth();
        float maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int hpColor = hpColor(ratio);

        boolean isPlayer = t instanceof PlayerEntity;
        String icon = isPlayer ? "♟" : "♞";
        String name = icon + " " + t.getName().getString();
        String hpPct = String.format("%.0f%%", ratio * 100);
        String distStr = String.format("%.1fm", nearestDist);

        if (showHPBar.getState()) {
            // Полноценная расширенная панель
            int boxW = 140, boxH = 34;
            this.width = boxW; this.height = boxH;

            // Тень + фон
            context.fill(x-1, y-1, x+boxW+1, y+boxH+1, 0x66000000);
            context.fill(x, y, x+boxW, y+boxH, 0xDD0D0D1E);

            // Акцентная полоска слева — цвет HP
            context.fill(x, y, x+3, y+boxH, hpColor);

            // Строка 1: иконка + имя + дистанция
            context.drawText(mc.textRenderer, name, x+6, y+3, 0xFFFFFFFF, true);
            int dw = mc.textRenderer.getWidth("§8" + distStr);
            context.drawText(mc.textRenderer, "§8" + distStr, x+boxW-dw-3, y+3, 0xFF888888, false);

            // Строка 2: HP-полоса
            int barY  = y + 14;
            int barW  = boxW - 8;
            context.fill(x+4, barY, x+4+barW, barY+6, 0xFF1E1E1E);
            context.fill(x+4, barY, x+4+(int)(barW*ratio), barY+6, hpColor);

            // HP% по центру полосы
            int pctW = mc.textRenderer.getWidth(hpPct);
            context.drawText(mc.textRenderer, hpPct, x+4+(barW-pctW)/2, barY, 0xFFFFFFFF, true);

            // Строка 3: тип + кол-во в зоне
            String typeStr = "ESP §8▸ §7" + glowingSet.size() + " в зоне";
            context.drawText(mc.textRenderer, typeStr, x+6, y+24, 0xFF44CCAA, false);

        } else {
            // Компактная строка (старый стиль)
            String text = String.format("ESP ▸ %s  %.1fm", t.getName().getString(), nearestDist);
            int tw = mc.textRenderer.getWidth(text) + 8;
            this.width = tw; this.height = 11;
            context.fill(x-2, y-1, x+tw+2, y+10, 0xBB111116);
            context.fill(x-2, y-1, x-1, y+10, 0xFF44EE88);
            context.drawText(mc.textRenderer, text, x+2, y, 0xFF88FFAA, true);
        }
    }

    private int hpColor(float ratio) {
        if (ratio > 0.6f) return 0xFF44EE77;
        if (ratio > 0.3f) return 0xFFFFAA22;
        return 0xFFEE3333;
    }
}
