package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * BlockOverlay — кастомная обводка блоков при прицеливании.
 *
 * Стили:
 *   Full    — полная заливка (полупрозрачная)
 *   Outline — только контур
 *   Corner  — только уголки (стиль HUD)
 *
 * Рендерится поверх стандартного выделения блока (vanilla outline отключать
 * нужно через mixin, здесь рисуем дополнительный слой в 2D HUD-режиме как
 * overlay — упрощённый подход без MatrixStack worldspace).
 */
public class BlockOverlay extends Module {
    private static final String[] STYLES = {"Full", "Outline", "Corner"};
    private final Setting style     = new Setting("Стиль",   STYLES, 1);
    private final Setting thickness = new Setting("Толщина", 1.0, 0.5, 3.0);

    // Цвет обводки — ARGB
    private static final int COLOR_FILL    = 0x33FFFFFF;
    private static final int COLOR_OUTLINE = 0xCCFFFFFF;

    public BlockOverlay() {
        super("BlockOverlay", "Кастомная обводка блоков при прицеливании", Category.VISUAL);
        addSetting(style);
        addSetting(thickness);
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || mc.crosshairTarget == null) return;
        if (mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr)) return;

        BlockPos pos = bhr.getBlockPos();
        if (mc.world == null || mc.world.getBlockState(pos).isAir()) return;

        // Рисуем 2D-индикатор в центре экрана (упрощённый overlay)
        int sw  = mc.getWindow().getScaledWidth();
        int sh  = mc.getWindow().getScaledHeight();
        int cx  = sw / 2;
        int cy  = sh / 2;
        int t   = (int) Math.max(1, thickness.getValue());
        int sz  = 12 + t; // размер индикатора

        switch (style.getCurrentOption()) {
            case "Full" -> ctx.fill(cx - sz, cy - sz, cx + sz, cy + sz, COLOR_FILL);
            case "Corner" -> drawCorners(ctx, cx, cy, sz, t, COLOR_OUTLINE);
            default -> { // Outline
                ctx.fill(cx - sz,     cy - sz,     cx + sz,     cy - sz + t, COLOR_OUTLINE); // top
                ctx.fill(cx - sz,     cy + sz - t, cx + sz,     cy + sz,     COLOR_OUTLINE); // bottom
                ctx.fill(cx - sz,     cy - sz,     cx - sz + t, cy + sz,     COLOR_OUTLINE); // left
                ctx.fill(cx + sz - t, cy - sz,     cx + sz,     cy + sz,     COLOR_OUTLINE); // right
            }
        }
    }

    private void drawCorners(DrawContext ctx, int cx, int cy, int sz, int t, int color) {
        int cs = sz / 3; // длина уголка
        // Top-left
        ctx.fill(cx - sz, cy - sz, cx - sz + cs, cy - sz + t, color);
        ctx.fill(cx - sz, cy - sz, cx - sz + t,  cy - sz + cs, color);
        // Top-right
        ctx.fill(cx + sz - cs, cy - sz, cx + sz, cy - sz + t, color);
        ctx.fill(cx + sz - t,  cy - sz, cx + sz, cy - sz + cs, color);
        // Bottom-left
        ctx.fill(cx - sz, cy + sz - t,  cx - sz + cs, cy + sz, color);
        ctx.fill(cx - sz, cy + sz - cs, cx - sz + t,  cy + sz, color);
        // Bottom-right
        ctx.fill(cx + sz - cs, cy + sz - t,  cx + sz, cy + sz, color);
        ctx.fill(cx + sz - t,  cy + sz - cs, cx + sz, cy + sz, color);
    }
}
