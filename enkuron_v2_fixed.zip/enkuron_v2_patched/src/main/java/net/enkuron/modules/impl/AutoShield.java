package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;

/**
 * AutoShield — автоматически поднимает щит при получении урона.
 *
 * Настройки:
 *   Длительность (тики) — как долго держать щит (10–60)
 *   Порог урона         — минимальный урон для активации (0.5–10)
 */
public class AutoShield extends Module {

    private final Setting shieldDuration = new Setting("Длительность (тики)", 30.0, 10.0, 60.0);
    private final Setting damageThreshold = new Setting("Порог урона",          1.0,  0.5, 10.0);

    private float lastHp     = -1f;
    private int   shieldTicks = 0;

    public AutoShield() {
        super("AutoShield", "Автоматически поднимает щит при получении урона", Category.COMBAT);
        addSetting(shieldDuration);
        addSetting(damageThreshold);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        float currentHp = mc.player.getHealth();
        if (lastHp > 0 && (lastHp - currentHp) >= damageThreshold.getValue() && hasShield()) {
            shieldTicks = (int) shieldDuration.getValue();
        }
        lastHp = currentHp;

        if (shieldTicks > 0) {
            mc.options.useKey.setPressed(true);
            shieldTicks--;
        } else {
            // FIX: mc.mouse.wasRightButtonClicked() не существует в 1.21.4.
            // Просто снимаем pressed — если игрок сам держит ПКМ, setPressed(false)
            // перезапишется его реальным вводом в следующем тике.
            mc.options.useKey.setPressed(false);
        }
    }

    private boolean hasShield() {
        if (mc.player == null) return false;
        ItemStack main = mc.player.getMainHandStack();
        ItemStack off  = mc.player.getOffHandStack();
        return main.getItem() == Items.SHIELD || off.getItem() == Items.SHIELD;
    }

    @Override public void onEnable()  { lastHp = -1f; shieldTicks = 0; }
    @Override public void onDisable() {
        shieldTicks = 0;
        if (mc.player != null) mc.options.useKey.setPressed(false);
    }
}
