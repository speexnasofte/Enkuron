package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * AntiAFK — предотвращает кик за AFK.
 *
 * Настройки:
 *   Интервал (сек) — как часто выполнять действие (5–60)
 *   Действие       — Rotate / Jump / Both
 */
public class AntiAFK extends Module {

    private static final String[] ACTIONS = {"Rotate", "Jump", "Both"};

    private final Setting interval = new Setting("Интервал (сек)", 15.0, 5.0, 60.0);
    private final Setting action   = new Setting("Действие",       ACTIONS, 2);

    private int tickCount   = 0;
    private int actionPhase = 0;

    public AntiAFK() {
        super("AntiAFK", "Предотвращает кик за AFK случайными движениями", Category.PLAYER);
        addSetting(interval);
        addSetting(action);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (isPlayerActive()) { tickCount = 0; return; }

        tickCount++;
        int intervalTicks = (int)(interval.getValue() * 20);
        if (tickCount >= intervalTicks) {
            tickCount = 0;
            doAction();
        }
    }

    private void doAction() {
        if (mc.player == null) return;
        String a = action.getCurrentOption();
        switch (actionPhase % 3) {
            case 0 -> { if (!a.equals("Jump"))   mc.player.setYaw(mc.player.getYaw() + 5f); }
            case 1 -> { if (!a.equals("Rotate")) mc.player.jump(); }
            case 2 -> { if (!a.equals("Jump"))   mc.player.setYaw(mc.player.getYaw() - 5f); }
        }
        actionPhase++;
    }

    private boolean isPlayerActive() {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
            || mc.options.leftKey.isPressed()    || mc.options.rightKey.isPressed()
            || mc.options.jumpKey.isPressed()    || mc.options.attackKey.isPressed()
            || mc.options.useKey.isPressed();
    }

    @Override public void onEnable()  { tickCount = 0; actionPhase = 0; }
    @Override public void onDisable() { tickCount = 0; }
}
