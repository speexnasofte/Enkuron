package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.gui.GUIManager;
import net.enkuron.ui.theme.ThemeManager;

/**
 * ThemeSelector — переключение темы и GUI-стиля из меню модулей.
 *
 * Настройки:
 *   Тема      — NEON / BLUE / RED / MINT / DARK / GOLD
 *   GUI Стиль — Neon / Minimal / Classic
 *
 * При изменении настройки применяет тему/стиль немедленно.
 * Не имеет onTick — только настройки.
 */
public class ThemeSelector extends Module {

    private static final String[] THEME_OPTS = {"NEON", "BLUE", "RED", "MINT", "DARK", "GOLD"};
    // FIX: были только Neon/Minimal/Classic — не хватало Modern и Glass из GUIStyle enum
    private static final String[] GUI_OPTS   = {"Modern", "Neon", "Glass", "Minimal", "Classic"};

    private final Setting theme    = new Setting("Тема",      THEME_OPTS, 0);
    private final Setting guiStyle = new Setting("GUI Стиль", GUI_OPTS,   0);

    private String lastTheme    = "NEON";
    private String lastGuiStyle = "Neon";

    public ThemeSelector() {
        super("ThemeSelector", "Смена темы и стиля GUI клиента", Category.MISC);
        addSetting(theme);
        addSetting(guiStyle);
    }

    @Override
    public void onTick() {
        // Применяем тему если изменилась
        String nowTheme = theme.getCurrentOption();
        if (!nowTheme.equals(lastTheme)) {
            ThemeManager.setByName(nowTheme);
            lastTheme = nowTheme;
        }

        // Применяем GUI стиль если изменился
        String nowGui = guiStyle.getCurrentOption();
        if (!nowGui.equals(lastGuiStyle)) {
            try {
                GUIManager.setStyle(GUIManager.GUIStyle.valueOf(nowGui.toUpperCase()));
            } catch (Exception ignored) {}
            lastGuiStyle = nowGui;
        }
    }
}
