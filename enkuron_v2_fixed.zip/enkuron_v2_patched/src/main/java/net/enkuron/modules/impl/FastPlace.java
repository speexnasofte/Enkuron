package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * FastPlace v2 — убирает задержку при зажатии ПКМ.
 *
 * В 1.21.4 задержка размещения контролируется полем itemUseCooldown
 * в MinecraftClient. Доступ через рефлексию или Mixin accessor.
 * Здесь используем рефлексию для простоты (без дополнительного Accessor миксина).
 *
 * Настройки:
 *   Задержка (тики) — 0–4 тиков (0 = мгновенно)
 */
public class FastPlace extends Module {

    private final Setting delay = new Setting("Задержка (тики)", 0.0, 0.0, 4.0);

    private java.lang.reflect.Field cooldownField;

    public FastPlace() {
        super("FastPlace", "Убирает задержку при зажатии ПКМ с блоками", Category.UTILITY);
        addSetting(delay);
        try {
            // В yarn маппингах 1.21.4 поле называется itemUseCooldown
            cooldownField = net.minecraft.client.MinecraftClient.class.getDeclaredField("itemUseCooldown");
            cooldownField.setAccessible(true);
        } catch (Exception e) {
            // Если рефлексия недоступна — модуль будет работать без эффекта
            cooldownField = null;
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (cooldownField == null) return;
        try {
            int currentCooldown = (int) cooldownField.get(mc);
            int targetDelay = (int) delay.getValue();
            if (currentCooldown > targetDelay) {
                cooldownField.set(mc, targetDelay);
            }
        } catch (Exception ignored) {}
    }
}
