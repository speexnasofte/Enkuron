package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * AuraShield — щит из частиц, вращающийся вокруг игрока.
 *
 * Режимы:
 *   Bubble   — сфера из частиц (3D орбиты по всем осям)
 *   Hexagon  — шестиугольный щит на уровне тела
 *   Barrier  — три кольца на разных высотах (нижнее, среднее, верхнее)
 *   Vortex   — два встречных кольца создают вихрь
 *   Matrix   — случайные точки внутри сферы с "каплями" вниз
 */
public class AuraShield extends Module {

    private static final String[] MODES  = {"Bubble", "Hexagon", "Barrier", "Vortex", "Matrix"};
    private static final String[] COLORS = {"Blue", "Purple", "Green", "Red", "Gold", "White", "Rainbow"};

    private final Setting mode    = new Setting("Режим",    MODES,  0);
    private final Setting color   = new Setting("Цвет",     COLORS, 0);
    private final Setting radius  = new Setting("Радиус",   1.2, 0.6, 2.5);
    private final Setting density = new Setting("Плотность",12.0, 6.0, 24.0);
    private final Setting speed   = new Setting("Скорость", 1.0, 0.3, 3.0);

    private double angle  = 0;
    private double angle2 = 0;
    private int    tick   = 0;
    private double rainbow = 0;

    public AuraShield() {
        super("AuraShield", "Щит из частиц вокруг игрока", Category.VISUAL);
        addSetting(mode);
        addSetting(color);
        addSetting(radius);
        addSetting(density);
        addSetting(speed);
    }

    @Override public void onEnable()  { angle = angle2 = tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        double spd = speed.getValue() * 0.15;
        angle  += spd;
        angle2 -= spd * 0.7;
        rainbow += 0.02;

        Vec3d pos = mc.player.getPos();
        double h  = mc.player.getHeight();
        double r  = radius.getValue();
        int cnt   = (int) density.getValue();

        switch (mode.getCurrentOption()) {
            case "Bubble"   -> spawnBubble (pos, r, cnt, h);
            case "Hexagon"  -> spawnHexagon(pos, r, cnt, h);
            case "Barrier"  -> spawnBarrier(pos, r, cnt, h);
            case "Vortex"   -> spawnVortex (pos, r, cnt, h);
            case "Matrix"   -> spawnMatrix (pos, r, cnt, h);
        }
    }

    // ── Bubble: сфера (3 взаимно-перпендикулярных кольца) ───────────────────
    private void spawnBubble(Vec3d pos, double r, int cnt, double h) {
        double cy = pos.y + h / 2.0;
        // Кольцо XZ
        for (int i = 0; i < cnt; i++) {
            double a = angle + (2 * Math.PI * i) / cnt;
            spawn(pos.x + Math.cos(a) * r, cy, pos.z + Math.sin(a) * r);
        }
        // Кольцо XY
        for (int i = 0; i < cnt * 2 / 3; i++) {
            double a = angle2 + (2 * Math.PI * i) / (cnt * 2 / 3);
            spawn(pos.x + Math.cos(a) * r, cy + Math.sin(a) * r, pos.z);
        }
        // Кольцо ZY
        for (int i = 0; i < cnt / 2; i++) {
            double a = -angle + (2 * Math.PI * i) / (cnt / 2);
            spawn(pos.x, cy + Math.sin(a) * r, pos.z + Math.cos(a) * r);
        }
    }

    // ── Hexagon: правильный шестиугольник ────────────────────────────────────
    private void spawnHexagon(Vec3d pos, double r, int cnt, double h) {
        int sides = 6;
        int ptsPerSide = Math.max(cnt / sides, 2);
        for (int s = 0; s < sides; s++) {
            double a1 = angle + (2 * Math.PI * s)       / sides;
            double a2 = angle + (2 * Math.PI * (s + 1)) / sides;
            double x1 = pos.x + Math.cos(a1) * r, z1 = pos.z + Math.sin(a1) * r;
            double x2 = pos.x + Math.cos(a2) * r, z2 = pos.z + Math.sin(a2) * r;
            for (int p = 0; p < ptsPerSide; p++) {
                double t = (double) p / ptsPerSide;
                spawn(lerp(x1, x2, t), pos.y + 0.1, lerp(z1, z2, t));
                spawn(lerp(x1, x2, t), pos.y + h * 0.5, lerp(z1, z2, t));
                spawn(lerp(x1, x2, t), pos.y + h + 0.1, lerp(z1, z2, t));
            }
        }
    }

    // ── Barrier: три вращающихся кольца ──────────────────────────────────────
    private void spawnBarrier(Vec3d pos, double r, int cnt, double h) {
        spawnRing(pos, r,        cnt,       pos.y + 0.1,      angle);
        spawnRing(pos, r * 1.1,  cnt,       pos.y + h / 2.0,  angle + Math.PI / 6);
        spawnRing(pos, r,        cnt,       pos.y + h + 0.1,  angle2);
    }

    // ── Vortex: два встречных кольца ──────────────────────────────────────────
    private void spawnVortex(Vec3d pos, double r, int cnt, double h) {
        double cy = pos.y + h / 2.0;
        // Кольцо снизу вверх (по часовой)
        for (int i = 0; i < cnt; i++) {
            double t = (double) i / cnt;
            double a = angle + t * Math.PI * 4;
            double y = pos.y + t * h;
            double rr = r * (0.4 + 0.6 * Math.sin(t * Math.PI));
            spawn(pos.x + Math.cos(a) * rr, y, pos.z + Math.sin(a) * rr);
        }
        // Встречное (против часовой)
        for (int i = 0; i < cnt; i++) {
            double t = (double) i / cnt;
            double a = angle2 + t * Math.PI * 4;
            double y = pos.y + (1 - t) * h;
            double rr = r * (0.4 + 0.6 * Math.sin(t * Math.PI));
            spawn(pos.x + Math.cos(a) * rr, y, pos.z + Math.sin(a) * rr);
        }
    }

    // ── Matrix: случайные точки + «капли» сверху вниз ────────────────────────
    private void spawnMatrix(Vec3d pos, double r, int cnt, double h) {
        // Случайные точки внутри сферы
        for (int i = 0; i < cnt / 2; i++) {
            double a  = Math.random() * Math.PI * 2;
            double el = (Math.random() - 0.5) * Math.PI;
            double rr = r * (0.7 + Math.random() * 0.3);
            spawn(pos.x + Math.cos(a) * Math.cos(el) * rr,
                  pos.y + h / 2.0 + Math.sin(el) * rr * 0.7,
                  pos.z + Math.sin(a) * Math.cos(el) * rr);
        }
        // «Капли» по периметру
        if (tick % 4 == 0) {
            for (int i = 0; i < 3; i++) {
                double a = Math.random() * Math.PI * 2;
                if (mc.world != null)
                    mc.world.addParticle(resolveParticle(),
                        pos.x + Math.cos(a) * r, pos.y + h + 0.3, pos.z + Math.sin(a) * r,
                        0, -0.08, 0);
            }
        }
    }

    // ── Утилиты ──────────────────────────────────────────────────────────────
    private void spawnRing(Vec3d pos, double r, int cnt, double y, double off) {
        for (int i = 0; i < cnt; i++) {
            double a = off + (2 * Math.PI * i) / cnt;
            spawn(pos.x + Math.cos(a) * r, y, pos.z + Math.sin(a) * r);
        }
    }

    private void spawn(double x, double y, double z) {
        if (mc.world == null) return;
        mc.world.addParticle(resolveParticle(), x, y, z, 0, 0.005, 0);
    }

    private net.minecraft.particle.ParticleEffect resolveParticle() {
        String c = color.getCurrentOption();
        if (c.equals("Rainbow")) {
            float hue = (float)(rainbow % 1.0);
            int rgb = java.awt.Color.HSBtoRGB(hue, 1f, 1f);
            float red   = ((rgb >> 16) & 0xFF) / 255f;
            float green = ((rgb >> 8)  & 0xFF) / 255f;
            float blue  = (rgb         & 0xFF) / 255f;
            return new DustParticleEffect(enkuronDustColor(red, green, blue), 1.0f);
        }
        return switch (c) {
            case "Purple" -> new DustParticleEffect(enkuronDustColor(0.7f, 0.1f, 1.0f), 1.0f);
            case "Green"  -> new DustParticleEffect(enkuronDustColor(0.1f, 1.0f, 0.3f), 1.0f);
            case "Red"    -> new DustParticleEffect(enkuronDustColor(1.0f, 0.1f, 0.1f), 1.0f);
            case "Gold"   -> new DustParticleEffect(enkuronDustColor(1.0f, 0.8f, 0.0f), 1.0f);
            case "White"  -> ParticleTypes.END_ROD;
            default       -> new DustParticleEffect(enkuronDustColor(0.1f, 0.4f, 1.0f), 1.0f); // Blue
        };
    }

    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
