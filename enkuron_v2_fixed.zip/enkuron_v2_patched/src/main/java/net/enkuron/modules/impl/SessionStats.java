package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/**
 * SessionStats — статистика сессии.
 *
 * Показывает:
 *  - Время игры (ч:мм:сс)
 *  - Количество смертей
 *  - Пройденное расстояние (блоки)
 */
public class SessionStats extends Module {

    private final Setting showTime     = new Setting("Время",        true);
    private final Setting showDeaths   = new Setting("Смерти",       true);
    private final Setting showDistance = new Setting("Расстояние",   true);

    private long  startTime = 0;
    private int   deaths    = 0;
    private double distance = 0;
    private Vec3d  lastPos  = null;
    private boolean wasDead = false;

    public SessionStats() {
        super("SessionStats", "Статистика текущей сессии (время, смерти, путь)", Category.HUD);
        this.x = 5; this.y = 500;
        addSetting(showTime);
        addSetting(showDeaths);
        addSetting(showDistance);
    }

    @Override
    public void onEnable() {
        startTime = System.currentTimeMillis();
        deaths    = 0;
        distance  = 0;
        lastPos   = null;
        wasDead   = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        // Счёт смертей
        boolean isDead = mc.player.isDead() || mc.player.getHealth() <= 0;
        if (isDead && !wasDead) deaths++;
        wasDead = isDead;

        // Расстояние
        Vec3d pos = mc.player.getPos();
        if (lastPos != null && !isDead) {
            distance += lastPos.distanceTo(pos);
        }
        lastPos = pos;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int lines = 0;
        if (showTime.getState())     lines++;
        if (showDeaths.getState())   lines++;
        if (showDistance.getState()) lines++;
        if (lines == 0) return;

        int lineH = 10;
        int boxW  = 130;
        int boxH  = lines * lineH + 6;
        this.width = boxW; this.height = boxH;

        context.fill(x - 2, y - 2, x + boxW, y + boxH, 0xBB0A0A14);
        context.fill(x - 2, y - 2, x - 1, y + boxH, 0xFF44FFAA);

        int line = 0;
        if (showTime.getState()) {
            long elapsed = (System.currentTimeMillis() - startTime) / 1000;
            String t = String.format("%d:%02d:%02d", elapsed/3600, (elapsed%3600)/60, elapsed%60);
            context.drawText(mc.textRenderer, "§a⏱ " + t, x + 2, y + 2 + line * lineH, 0xFF88FFAA, false);
            line++;
        }
        if (showDeaths.getState()) {
            context.drawText(mc.textRenderer, "§c☠ Deaths: " + deaths, x + 2, y + 2 + line * lineH, 0xFFFF8888, false);
            line++;
        }
        if (showDistance.getState()) {
            String d = String.format("§b⬛ %.0f блоков", distance);
            context.drawText(mc.textRenderer, d, x + 2, y + 2 + line * lineH, 0xFFAADDFF, false);
        }
    }
}
