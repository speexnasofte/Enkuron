package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/**
 * DurabilityHUD — показывает прочность брони и инструмента в руке.
 *
 * Рисует компактные полоски прочности для:
 *   - 4 слота брони (шлем, нагрудник, поножи, ботинки)
 *   - Предмет в руке
 *
 * Настройки:
 *   Показывать броню  — BOOLEAN
 *   Показывать в руке — BOOLEAN
 *   Порог (%)         — при каком % прочности мигать (5–50%)
 */
public class DurabilityHUD extends Module {

    private static final String[] ARMOR_NAMES = {"Шлем","Нагр","Пон","Бот"};
    private static final int BAR_W = 50;
    private static final int BAR_H = 4;

    private final Setting showArmor = new Setting("Показывать броню",    true);
    private final Setting showHand  = new Setting("Показывать в руке",   true);
    private final Setting warnPct   = new Setting("Порог предупр. (%)",  20.0, 5.0, 50.0);

    private int blinkTick = 0;

    public DurabilityHUD() {
        super("DurabilityHUD", "Полоски прочности брони и инструмента", Category.HUD);
        addSetting(showArmor);
        addSetting(showHand);
        addSetting(warnPct);
        this.x = 5;
        this.y = 140;
    }

    @Override public void onTick() { blinkTick++; }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int drawY = y;
        boolean blink = (blinkTick / 8) % 2 == 0;

        // === Броня ===
        if (showArmor.getState()) {
            // Слоты брони: 3=шлем,2=нагрудник,1=поножи,0=ботинки
            for (int i = 3; i >= 0; i--) {
                ItemStack stack = mc.player.getInventory().getArmorStack(i);
                if (stack.isEmpty() || !stack.isDamageable()) continue;

                float ratio = 1f - (float) stack.getDamage() / stack.getMaxDamage();
                float pct   = ratio * 100f;
                boolean warn = pct <= warnPct.getValue();

                if (warn && !blink) { drawY += 10; continue; } // FIX: шаг 10 как у нормальных строк (был 12 — сбивал выравнивание)

                int color = durabilityColor(ratio);
                int barFill = (int)(BAR_W * ratio);

                // Фон строки
                context.fill(x - 2, drawY - 1, x + BAR_W + 36, drawY + BAR_H + 3, 0xBB111116);

                // Название слота
                String label = ARMOR_NAMES[i];
                context.drawText(mc.textRenderer, "§8" + label, x, drawY, 0xFFAAAAAA, false);

                // Фон полоски
                context.fill(x + 28, drawY, x + 28 + BAR_W, drawY + BAR_H, 0xFF333333);
                // Полоска
                context.fill(x + 28, drawY, x + 28 + barFill, drawY + BAR_H, color);

                // Процент
                String pctStr = String.format("%d%%", (int)pct);
                context.drawText(mc.textRenderer, pctStr, x + 28 + BAR_W + 3, drawY, color, false);

                drawY += 10;
            }
        }

        // === В руке ===
        if (showHand.getState()) {
            ItemStack hand = mc.player.getMainHandStack();
            if (!hand.isEmpty() && hand.isDamageable()) {
                float ratio = 1f - (float) hand.getDamage() / hand.getMaxDamage();
                float pct   = ratio * 100f;
                boolean warn = pct <= warnPct.getValue();

                if (!(warn && !blink)) {
                    int color   = durabilityColor(ratio);
                    int barFill = (int)(BAR_W * ratio);
                    String name = hand.getName().getString();
                    if (name.length() > 10) name = name.substring(0, 9) + "…";

                    context.fill(x - 2, drawY - 1, x + BAR_W + 36, drawY + BAR_H + 3, 0xBB111116);
                    context.drawText(mc.textRenderer, "§7" + name, x, drawY - 8, 0xFFCCCCCC, false);
                    context.fill(x, drawY, x + BAR_W, drawY + BAR_H, 0xFF333333);
                    context.fill(x, drawY, x + barFill, drawY + BAR_H, color);
                    String pctStr = String.format("%d%%", (int)pct);
                    context.drawText(mc.textRenderer, pctStr, x + BAR_W + 3, drawY, color, false);
                }
            }
        }
    }

    private int durabilityColor(float ratio) {
        int r = (int)((1f - ratio) * 255);
        int g = (int)(ratio * 200);
        return EnkuronColor.toARGB(r, g, 0, 255);
    }
}
