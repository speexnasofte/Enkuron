package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * CpsCounter — клики в секунду.
 *
 * Настройки:
 *   Показ ПКМ    — отображать отдельно правые клики
 *   Позиция      — BOTTOM_LEFT / BOTTOM_RIGHT
 */
public class CpsCounter extends Module {

    private static final String[] POSITIONS = {"BOTTOM_LEFT", "BOTTOM_RIGHT"};

    private final Setting showRight = new Setting("Показ ПКМ", true);
    private final Setting position  = new Setting("Позиция",   POSITIONS, 0);

    private final Deque<Long> leftClicks  = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();

    public CpsCounter() {
        super("CpsCounter", "Показывает клики в секунду", Category.HUD);
        addSetting(showRight);
        addSetting(position);
    }

    public void registerClick(boolean isRight) {
        if (!isEnabled()) return;
        long now = System.currentTimeMillis();
        if (isRight) rightClicks.addLast(now);
        else leftClicks.addLast(now);
    }

    public int getLeftCps()  { return countRecent(leftClicks); }
    public int getRightCps() { return countRecent(rightClicks); }

    private int countRecent(Deque<Long> queue) {
        long cutoff = System.currentTimeMillis() - 1000;
        while (!queue.isEmpty() && queue.peekFirst() < cutoff) queue.pollFirst();
        return queue.size();
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;

        int lCps = getLeftCps();
        int rCps = getRightCps();

        // FIX: null-check window
        if (mc.getWindow() == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        int px, py;
        if (position.getCurrentOption().equals("BOTTOM_RIGHT")) {
            px = sw - 75; py = sh - 40;
        } else {
            px = 5; py = sh - 40;
        }

        context.fill(px - 2, py - 2, px + 70, py + 22, EnkuronColor.toARGB(0, 0, 0, 150));
        context.fill(px - 2, py - 2, px + 70, py - 1, EnkuronColor.PRIMARY);

        context.drawText(mc.textRenderer, "CPS", px, py, EnkuronColor.PRIMARY, false);
        context.drawText(mc.textRenderer, "L: " + lCps, px, py + 10,
            lCps > 10 ? EnkuronColor.ENABLED : EnkuronColor.TEXT, false);

        if (showRight.getState()) {
            context.drawText(mc.textRenderer, "R: " + rCps, px + 35, py + 10,
                rCps > 5 ? EnkuronColor.ENABLED : EnkuronColor.TEXT, false);
        }
    }
}
