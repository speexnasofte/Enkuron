package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class EchoAura extends Module {

    private final Setting interval     = new Setting("Интервал (тики)",   10.0,  1.0, 50.0);
    private final Setting maxRadius    = new Setting("Макс. радиус",       4.0,  0.5, 50.0);
    private final Setting expandSpeed  = new Setting("Скорость расш.",     0.12, 0.05,  2.0);
    private final Setting density      = new Setting("Плотность",          16.0,  4.0, 50.0);
    private final Setting yOffset      = new Setting("Y-смещение",          0.0, -2.0,  5.0);
    private final Setting colorMode    = new Setting("Цвет режим",       new String[]{"Static", "Rainbow", "Pulse"},  0);
    private final Setting colorR       = new Setting("Цвет R",            100.0, 0.0, 255.0);
    private final Setting colorG       = new Setting("Цвет G",            180.0, 0.0, 255.0);
    private final Setting colorB       = new Setting("Цвет B",            255.0, 0.0, 255.0);
    private final Setting dustSize     = new Setting("Размер частиц",       1.0,  0.1,  5.0);
    private final Setting fadeOut      = new Setting("Fade out",           true);

    private static class EchoRing {
        double radius;
        EchoRing(double startRadius) { this.radius = startRadius; }
    }

    private final List<EchoRing> rings = new ArrayList<>();
    private int spawnCooldown = 0;
    private double colorHue = 0.0;

    public EchoAura() {
        super("EchoAura", "Эхо-кольца вокруг игрока", Category.VISUAL);
        addSetting(interval); addSetting(maxRadius); addSetting(expandSpeed);
        addSetting(density); addSetting(yOffset); addSetting(colorMode);
        addSetting(colorR); addSetting(colorG); addSetting(colorB);
        addSetting(dustSize); addSetting(fadeOut);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        colorHue = (colorHue + 1.5) % 360.0;

        double spd = expandSpeed.getValue();
        double maxR = maxRadius.getValue();
        rings.removeIf(r -> r.radius >= maxR);
        for (EchoRing ring : rings) ring.radius += spd;

        if (--spawnCooldown <= 0) {
            rings.add(new EchoRing(0.1));
            spawnCooldown = (int) interval.getValue();
        }

        Vec3d pos = mc.player.getPos();
        for (EchoRing ring : rings) {
            if (ring.radius <= 0) continue;
            int cnt = (int) density.getValue();
            float alpha = fadeOut.getState() ? (float)(1.0 - (ring.radius / maxR)) : 1.0f;
            alpha = AnimationUtils.clamp(alpha, 0.05f, 1.0f);

            double y = pos.y + yOffset.getValue() + 0.1;
            for (int i = 0; i < cnt; i++) {
                double a = (2 * Math.PI * i) / cnt;
                double px = pos.x + Math.cos(a) * ring.radius;
                double pz = pos.z + Math.sin(a) * ring.radius;
                mc.world.addParticle(resolveParticle(alpha), px, y, pz, 0, 0, 0);
            }
        }
    }

    private DustParticleEffect resolveParticle(float alpha) {
        float size = (float) dustSize.getValue() * alpha;
        size = Math.max(size, 0.1f);

        float r, g, b;
        if (colorMode.getCurrentOption().equals("Rainbow")) {
            float h = (float) (colorHue / 360.0);
            java.awt.Color c = java.awt.Color.getHSBColor(h, 0.8f, 1.0f);
            r = c.getRed() / 255f;
            g = c.getGreen() / 255f;
            b = c.getBlue() / 255f;
        } else {
            r = (float)(colorR.getValue() / 255f);
            g = (float)(colorG.getValue() / 255f);
            b = (float)(colorB.getValue() / 255f);
        }

        int argb = 0xFF000000 | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
        return new DustParticleEffect(argb, size);
    }
}