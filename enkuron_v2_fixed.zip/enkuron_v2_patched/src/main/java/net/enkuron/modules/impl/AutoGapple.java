package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

/**
 * AutoGapple — автоматически ест золотое яблоко при низком HP.
 *
 * Ищет в хотбаре золотое или зачарованное яблоко.
 * Приоритет: сначала обычное, потом зачарованное (если HP очень низко).
 */
public class AutoGapple extends Module {

    private final Setting hpThreshold   = new Setting("Порог HP",            8.0, 1.0, 20.0);
    private final Setting enchantedAt   = new Setting("Зачарованное при HP",  4.0, 1.0, 10.0);
    private final Setting preferEnchanted = new Setting("Предпочитать зачарованное", false);
    private final Setting interval      = new Setting("Интервал (тики)",      10.0, 5.0, 40.0);

    private int tickCounter = 0;
    private boolean wasEating = false;

    public AutoGapple() {
        super("AutoGapple", "Автоматически ест золотое яблоко при низком HP", Category.COMBAT);
        addSetting(hpThreshold);
        addSetting(enchantedAt);
        addSetting(preferEnchanted);
        addSetting(interval);
    }

    @Override
    public void onEnable() { tickCounter = 0; wasEating = false; }

    @Override
    public void onDisable() { wasEating = false; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (++tickCounter < (int) interval.getValue()) return;
        tickCounter = 0;

        float hp = mc.player.getHealth();
        if (hp >= (float) hpThreshold.getValue()) return;

        boolean wantEnchanted = preferEnchanted.getState() || hp <= (float) enchantedAt.getValue();

        // Ищем в хотбаре
        int slot = findGapple(wantEnchanted);
        if (slot == -1 && wantEnchanted) {
            // Пробуем обычное
            slot = findGapple(false);
        }
        if (slot == -1) return;

        // Переключаем слот, едим, сразу возвращаем слот обратно
        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        // FIX: возвращаем слот немедленно — interactItem уже отправил пакет,
        // удерживать слот не нужно и это вызывало "прилипание" слота
        mc.player.getInventory().selectedSlot = prev;
    }

    private int findGapple(boolean enchanted) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (enchanted && stack.getItem() == Items.ENCHANTED_GOLDEN_APPLE) return i;
            if (!enchanted && stack.getItem() == Items.GOLDEN_APPLE) return i;
        }
        return -1;
    }
}
