package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.effect.StatusEffects;

/**
 * AntiPoison — пьёт молоко при отравлении или негативных эффектах.
 *
 * Настройки:
 *   Эффекты       — All (все) / Poison (только яд) / Critical (яд+иссушение)
 *   Интервал (сек) — кулдаун после выпивания (1–10)
 */
public class AntiPoison extends Module {

    private static final String[] MODES = {"All", "Poison", "Critical"};

    private final Setting effectMode = new Setting("Эффекты",        MODES, 0);
    private final Setting cooldownSec = new Setting("Интервал (сек)", 1.0, 1.0, 10.0);

    private int  previousSlot = -1;
    private boolean drinking  = false;
    private int  cooldown     = 0;

    public AntiPoison() {
        super("AntiPoison", "Пьёт молоко при отравлении или негативных эффектах", Category.PLAYER);
        addSetting(effectMode);
        addSetting(cooldownSec);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }

        boolean hasBadEffect = hasBadEffect();

        if (hasBadEffect && !drinking) {
            int milkSlot = findMilkInHotbar();
            if (milkSlot != -1) {
                previousSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = milkSlot;
                drinking = true;
            }
        }

        if (drinking) {
            mc.options.useKey.setPressed(true);
            // FIX: прекращаем если молоко исчезло из слота (сломалось/выброшено)
            int milkCheck = findMilkInHotbar();
            if (milkCheck == -1) { stopDrinking(); return; }
        }

        if (!hasBadEffect && drinking) {
            stopDrinking();
            cooldown = (int)(cooldownSec.getValue() * 20);
        }
    }

    private boolean hasBadEffect() {
        if (mc.player == null) return false;
        return switch (effectMode.getCurrentOption()) {
            case "Poison"   -> (mc.player.getStatusEffect(StatusEffects.POISON) != null);
            case "Critical" -> (mc.player.getStatusEffect(StatusEffects.POISON) != null)
                            || (mc.player.getStatusEffect(StatusEffects.WITHER) != null);
            default         -> (mc.player.getStatusEffect(StatusEffects.POISON) != null)
                            || (mc.player.getStatusEffect(StatusEffects.WITHER) != null)
                            || (mc.player.getStatusEffect(StatusEffects.SLOWNESS) != null)
                            || (mc.player.getStatusEffect(StatusEffects.WEAKNESS) != null)
                            || (mc.player.getStatusEffect(StatusEffects.NAUSEA) != null)
                            || (mc.player.getStatusEffect(StatusEffects.BLINDNESS) != null);
        };
    }

    private void stopDrinking() {
        mc.options.useKey.setPressed(false);
        drinking = false;
        if (previousSlot != -1) {
            mc.player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
    }

    private int findMilkInHotbar() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.getItem() == Items.MILK_BUCKET) return i;
        }
        return -1;
    }

    @Override public void onDisable() { if (drinking) stopDrinking(); }
}
