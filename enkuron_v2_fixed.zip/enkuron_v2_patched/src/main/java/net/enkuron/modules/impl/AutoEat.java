package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;

/**
 * AutoEat — автоматически восполняет сытость едой из хотбара.
 *
 * Настройки:
 *   Порог голода   — при каком уровне голода начинать есть (1–20)
 *   Только хорошую — есть только еду с nutrition >= 4 (не гнилую плоть и т.п.)
 *   Умный выбор    — выбирать еду с наибольшим насыщением (иначе — первую попавшуюся)
 */
public class AutoEat extends Module {

    private final Setting hungerThreshold = new Setting("Порог голода",   17.0, 1.0, 20.0);
    private final Setting onlyGoodFood    = new Setting("Только хорошую", true);
    private final Setting smartPick       = new Setting("Умный выбор",    true);

    private static final int POST_EAT_COOLDOWN = 20;

    private int  previousSlot  = -1;
    private boolean eating     = false;
    private int  cooldownTimer = 0;

    public AutoEat() {
        super("AutoEat", "Автоматически восполняет сытость едой из хотбара", Category.PLAYER);
        addSetting(hungerThreshold);
        addSetting(onlyGoodFood);
        addSetting(smartPick);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        if (cooldownTimer > 0) { cooldownTimer--; return; }

        int hunger = mc.player.getHungerManager().getFoodLevel();
        int threshold = (int) hungerThreshold.getValue();

        // FIX: начинаем есть когда голод НИЖЕ порога (не <=, иначе никогда не остановимся при пороге=20)
        if (hunger < threshold && !eating) {
            int foodSlot = findFoodSlot();
            if (foodSlot != -1) {
                previousSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = foodSlot;
                eating = true;
            }
        }

        if (eating) mc.options.useKey.setPressed(true);

        // FIX: останавливаем если наелись (>= 20) ИЛИ еда кончилась ИЛИ порог больше не нужен
        if (eating && (hunger >= 20 || hunger >= threshold || findFoodSlot() == -1)) stopEating();
    }

    private void stopEating() {
        if (!eating) return;
        mc.options.useKey.setPressed(false);
        eating = false;
        if (previousSlot != -1) {
            mc.player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
        cooldownTimer = POST_EAT_COOLDOWN;
    }

    private int findFoodSlot() {
        int bestSlot = -1;
        int bestNutrition = 0;
        int minNutrition  = onlyGoodFood.getState() ? 4 : 0;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            FoodComponent food = stack.get(DataComponentTypes.FOOD);
            if (food == null || food.nutrition() < minNutrition) continue;

            if (smartPick.getState()) {
                // выбираем с наибольшим насыщением
                if (food.nutrition() > bestNutrition) {
                    bestNutrition = food.nutrition();
                    bestSlot = i;
                }
            } else {
                // первый попавшийся с достаточным питанием
                return i;
            }
        }
        return bestSlot;
    }

    @Override
    public void onDisable() {
        if (eating) stopEating();
        cooldownTimer = 0;
    }
}
