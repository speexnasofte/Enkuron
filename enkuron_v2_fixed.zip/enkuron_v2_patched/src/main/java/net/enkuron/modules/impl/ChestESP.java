package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.block.*;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * ChestESP v2 — расширенный список контейнеров + шалкеры + стрелка направления.
 *
 * Теперь показывает:
 *  - Обычные сундуки / большие сундуки
 *  - Эндер-сундуки
 *  - Бочки
 *  - Шалкеры (ShulkerBox, все цвета) — NEW
 *
 * Каждая запись содержит стрелку направления (↑↗→↘↓↙←↖) — NEW
 * Стрелка указывает горизонтальное направление к контейнеру
 * относительно текущего взгляда игрока.
 *
 * Цветовое различие типов:
 *  §6 Сундук / §5 Эндер / §e Бочка / §d Шалкер
 */
public class ChestESP extends Module {

    private final Setting range      = new Setting("Дальность (блоки)", 24.0, 8.0, 48.0);
    private final Setting showEnder  = new Setting("Эндер-сундуки",     true);
    private final Setting showBarrel = new Setting("Бочки",             true);
    private final Setting showShulker= new Setting("Шалкеры",           true);
    private final Setting showArrow  = new Setting("Стрелка направл.",  true);
    private final Setting maxEntries = new Setting("Макс. в списке",    8.0, 2.0, 16.0);
    private final Setting updateRate = new Setting("Обновление (тики)", 10.0, 2.0, 20.0);

    private record ChestEntry(BlockPos pos, String type, double dist, String color) {}
    private final List<ChestEntry> cached = new ArrayList<>();
    private int tickCounter = 0;

    public ChestESP() {
        super("ChestESP", "Показывает ближайшие сундуки, шалкеры и контейнеры со стрелкой", Category.VISUAL);
        this.x = 5; this.y = 380;
        addSetting(range); addSetting(showEnder); addSetting(showBarrel);
        addSetting(showShulker); addSetting(showArrow);
        addSetting(maxEntries); addSetting(updateRate);
    }

    @Override
    public void onEnable() { cached.clear(); tickCounter = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (++tickCounter < (int) updateRate.getValue()) return;
        tickCounter = 0;

        cached.clear();
        int rng = (int) range.getValue();
        BlockPos pp  = mc.player.getBlockPos();
        int max = (int) maxEntries.getValue();

        for (int dx = -rng; dx <= rng && cached.size() < max * 2; dx++) {
            for (int dy = -rng / 2; dy <= rng / 2; dy++) {
                for (int dz = -rng; dz <= rng && cached.size() < max * 2; dz++) {
                    BlockPos pos   = pp.add(dx, dy, dz);
                    Block    block = mc.world.getBlockState(pos).getBlock();

                    String type  = null;
                    String color = null;

                    if (block instanceof ChestBlock) {
                        type = "Сундук"; color = "§6";
                    } else if (showEnder.getState() && block instanceof EnderChestBlock) {
                        type = "Эндер";  color = "§5";
                    } else if (showBarrel.getState() && block instanceof BarrelBlock) {
                        type = "Бочка";  color = "§e";
                    } else if (showShulker.getState() && block instanceof ShulkerBoxBlock) {
                        type = "Шалкер"; color = "§d";
                    }

                    if (type == null) continue;

                    double dist = mc.player.getPos().distanceTo(pos.toCenterPos());
                    if (dist > rng) continue;
                    cached.add(new ChestEntry(pos, type, dist, color));
                }
            }
        }

        cached.sort((a, b) -> Double.compare(a.dist(), b.dist()));
        if (cached.size() > max) cached.subList(max, cached.size()).clear();
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || cached.isEmpty()) return;

        int lineH = 10;
        int boxW  = 140;
        int boxH  = cached.size() * lineH + 14;
        this.width = boxW; this.height = boxH;

        context.fill(x-2, y-2, x+boxW, y+boxH, 0xBB0A0A14);
        context.fill(x-2, y-2, x-1, y+boxH, 0xFFFFAA00);

        context.drawText(mc.textRenderer,
            "§6Containers §8(" + cached.size() + ")",
            x+2, y, 0xFFFFCC44, true);

        for (int i = 0; i < cached.size(); i++) {
            ChestEntry e  = cached.get(i);
            int ty        = y + 12 + i * lineH;
            String arrow  = showArrow.getState() ? getDirectionArrow(e.pos()) + " " : "";
            String distStr = String.format("§8%.0fm", e.dist());
            int dw        = mc.textRenderer.getWidth(distStr);

            context.drawText(mc.textRenderer, arrow + e.color() + e.type(), x+4, ty, 0xFFFFFFFF, false);
            context.drawText(mc.textRenderer, distStr, x+boxW-dw-4, ty, 0xFF888888, false);
        }
    }

    /**
     * Возвращает символ стрелки (Unicode), указывающей в сторону блока
     * относительно горизонтального взгляда игрока.
     * Стрелки: ↑ ↗ → ↘ ↓ ↙ ← ↖
     */
    private String getDirectionArrow(BlockPos target) {
        if (mc.player == null) return "·";

        Vec3d pp  = mc.player.getPos();
        double dx = target.getX() + 0.5 - pp.x;
        double dz = target.getZ() + 0.5 - pp.z;

        // Угол до цели в мировом пространстве (0 = север/−Z, по часовой)
        double targetYaw = Math.toDegrees(Math.atan2(dx, -dz));
        // Взгляд игрока
        double playerYaw = mc.player.getYaw();
        // Относительный угол
        double relAngle  = ((targetYaw - playerYaw) % 360 + 360) % 360;

        // 8 секторов по 45°
        int sector = (int)((relAngle + 22.5) / 45) % 8;
        return switch (sector) {
            case 0 -> "↑";   // прямо
            case 1 -> "↗";
            case 2 -> "→";
            case 3 -> "↘";
            case 4 -> "↓";   // сзади
            case 5 -> "↙";
            case 6 -> "←";
            case 7 -> "↖";
            default -> "·";
        };
    }
}
