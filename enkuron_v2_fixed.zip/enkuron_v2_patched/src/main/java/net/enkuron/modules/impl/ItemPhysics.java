package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.ItemEntity;

/**
 * ItemPhysics — визуальная физика предметов на земле.
 *
 * rotation — предметы вращаются по осям X/Z (реалистично лежат)
 * bounce    — лёгкий отскок при появлении предмета (imulse Y)
 *
 * Реализация чисто клиентская: меняем yaw/pitch рендера ItemEntity.
 * Bounce эмулируется через setVelocity при спавне (ItemEntity.age == 0).
 */
public class ItemPhysics extends Module {
    private final Setting rotation = new Setting("Вращение", true);
    private final Setting bounce   = new Setting("Отскок",   true);

    public ItemPhysics() {
        super("ItemPhysics", "Реалистичная физика предметов на земле", Category.VISUAL);
        addSetting(rotation);
        addSetting(bounce);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;

        for (ItemEntity item : mc.world.getEntitiesByClass(ItemEntity.class,
                mc.player.getBoundingBox().expand(32), e -> true)) {

            if (rotation.getState()) {
                // Поворачиваем предмет: pitch = 90° (плоско), yaw накапливается
                item.prevPitch = item.getPitch();
                item.setPitch(90f);
                // Медленное вращение по yaw при движении
                if (item.getVelocity().horizontalLengthSquared() > 1e-4) {
                    item.setYaw(item.getYaw() + 8f);
                }
            }

            if (bounce.getState() && item.age == 1) {
                // При появлении — небольшой импульс вверх
                var vel = item.getVelocity();
                item.setVelocity(vel.x, Math.max(vel.y, 0.25), vel.z);
            }
        }
    }
}
