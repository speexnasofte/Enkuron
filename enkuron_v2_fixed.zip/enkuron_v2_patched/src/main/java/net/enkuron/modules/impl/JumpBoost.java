package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * JumpBoost — периодически даёт прыжок-буст через эффект.
 * Настройки:
 *   level    — уровень прыжка (1–3)
 *   onlyGround — прыгать только с земли
 */
public class JumpBoost extends Module {

    private final Setting level       = new Setting("Уровень прыжка", 1.0, 1.0, 3.0);
    private final Setting onlyGround  = new Setting("Только с земли", true);
    private final Setting refresh     = new Setting("Обновление (сек)", 8.0, 3.0, 30.0);

    private int tickCount = 0;

    public JumpBoost() {
        super("JumpBoost", "Усиливает высоту прыжка через эффект", Category.MOVEMENT);
        addSetting(level);
        addSetting(onlyGround);
        addSetting(refresh);
    }

    @Override
    public void onEnable() {
        tickCount = 0;
        applyEffect();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        // FIX: счётчик всегда идёт, чтобы не было мгновенного срабатывания после приземления
        tickCount++;
        int interval = (int)(refresh.getValue() * 20);
        if (tickCount >= interval) {
            tickCount = 0;
            // Применяем только если условие земли выполнено
            if (!onlyGround.getState() || mc.player.isOnGround()) {
                applyEffect();
            }
        }
    }

    private void applyEffect() {
        if (mc.player == null) return;
        mc.player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.JUMP_BOOST,
                400,
                (int) level.getValue() - 1,
                false, false
        ));
    }

    @Override
    public void onDisable() {
        if (mc.player != null)
            mc.player.removeStatusEffect(StatusEffects.JUMP_BOOST);
    }
}
