package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * ItemESP v2 — показывает выброшенные предметы на земле.
 *
 * НОВОЕ v2:
 *   • Фильтр по редкости: Все / ≥ Uncommon / ≥ Rare / Только Epic
 *   • Иконка редкости перед именем: · ✦ ★ ◆
 *   • Цветная полоска слева по редкости (серый / зелёный / голубой / пурпур)
 *   • Сортировка: сначала редкие, потом по расстоянию (опционально)
 */
public class ItemESP extends Module {

    private static final String[] RARITY_OPTS = {"Все", ">= Uncommon", ">= Rare", "Только Epic"};

    private final Setting range        = new Setting("Дальность (блоки)",  32.0,  8.0, 64.0);
    private final Setting maxItems     = new Setting("Макс. строк",         8.0,  2.0, 16.0);
    private final Setting updateRate   = new Setting("Обновление (тики)",   4.0,  1.0, 20.0);
    private final Setting rarityFilter = new Setting("Фильтр редкости",     RARITY_OPTS, 0);
    private final Setting showIcons    = new Setting("Иконки редкости",     true);
    private final Setting sortByRarity = new Setting("Сортировка по ред.", true);

    private final List<ItemEntry> cached = new ArrayList<>();
    private int tickCounter = 0;

    // Порядок редкости: 0=Common, 1=Uncommon, 2=Rare, 3=Epic
    private record ItemEntry(String name, double dist, int rarityOrder,
                              int stripColor, String rarityPrefix) {}

    public ItemESP() {
        super("ItemESP", "Показывает предметы на земле с фильтром редкости", Category.VISUAL);
        this.x = 5; this.y = 320;
        addSetting(range);
        addSetting(maxItems);
        addSetting(updateRate);
        addSetting(rarityFilter);
        addSetting(showIcons);
        addSetting(sortByRarity);
    }

    @Override
    public void onEnable() { cached.clear(); tickCounter = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (++tickCounter < (int) updateRate.getValue()) return;
        tickCounter = 0;

        cached.clear();
        double rng = range.getValue();
        Vec3d pp = mc.player.getPos();
        int minOrder = minRarityOrder();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie)) continue;
            double dx = ie.getX() - pp.x;
            double dz = ie.getZ() - pp.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > rng) continue;

            ItemStack stack = ie.getStack();
            int[] rarityData = resolveRarity(stack.getRarity());
            int rarityOrder = rarityData[0];
            if (rarityOrder < minOrder) continue;

            String name = stack.getName().getString();
            if (stack.getCount() > 1) name += " x" + stack.getCount();

            cached.add(new ItemEntry(name, dist, rarityOrder,
                    rarityData[1], rarityPrefix(rarityOrder)));
        }

        // Сортировка
        if (sortByRarity.getState()) {
            cached.sort((a, b) -> {
                int cmp = Integer.compare(b.rarityOrder(), a.rarityOrder());
                return cmp != 0 ? cmp : Double.compare(a.dist(), b.dist());
            });
        } else {
            cached.sort((a, b) -> Double.compare(a.dist(), b.dist()));
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || cached.isEmpty()) return;

        int max   = (int) maxItems.getValue();
        int count = Math.min(cached.size(), max);
        int lineH = 10;
        int boxW  = 148;
        int boxH  = 12 + count * lineH;
        this.width = boxW; this.height = boxH;

        context.fill(x - 2, y - 2, x + boxW, y + boxH, 0xBB0A0A14);
        context.fill(x - 2, y - 2, x - 1,    y + boxH, 0xFFFFAA00);

        context.drawText(mc.textRenderer, "§6Items §8(" + cached.size() + ")",
                x + 2, y, 0xFFFFCC44, true);

        for (int i = 0; i < count; i++) {
            ItemEntry entry = cached.get(i);
            int ty = y + 12 + i * lineH;

            // Цветная полоска слева по редкости
            context.fill(x - 2, ty, x - 1, ty + 9, entry.stripColor());

            String prefix = showIcons.getState() ? entry.rarityPrefix() : "";
            String nameStr = entry.name().length() > 15
                    ? entry.name().substring(0, 15) + "..." : entry.name();
            String distStr = String.format("§8%.0fm", entry.dist());

            context.drawText(mc.textRenderer, prefix + "§f" + nameStr,
                    x + 4, ty, 0xFFFFFFFF, false);
            int dw = mc.textRenderer.getWidth(distStr);
            context.drawText(mc.textRenderer, distStr,
                    x + boxW - dw - 4, ty, 0xFF888888, false);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /** Возвращает [order, stripColor] */
    private int[] resolveRarity(Rarity r) {
        return switch (r) {
            case UNCOMMON -> new int[]{1, 0xFF55FF55};
            case RARE     -> new int[]{2, 0xFF55FFFF};
            case EPIC     -> new int[]{3, 0xFFFF55FF};
            default       -> new int[]{0, 0xFF666666};
        };
    }

    private String rarityPrefix(int order) {
        return switch (order) {
            case 1 -> "§a* ";   // Uncommon — зелёный *
            case 2 -> "§b** ";  // Rare — голубой **
            case 3 -> "§d*** "; // Epic — пурпурный ***
            default -> "§8. ";  // Common — серый .
        };
    }

    private int minRarityOrder() {
        return switch (rarityFilter.getCurrentOption()) {
            case ">= Uncommon" -> 1;
            case ">= Rare"     -> 2;
            case "Только Epic" -> 3;
            default            -> 0;
        };
    }
}
