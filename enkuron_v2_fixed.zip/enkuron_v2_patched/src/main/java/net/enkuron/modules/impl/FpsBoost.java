package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * FpsBoost v1 — модуль оптимизации FPS.
 *
 * Функции:
 *  - noParticles    — полностью отключает спавн всех частиц в мире
 *  - noWeather      — скрывает дождь и снег (рендер)
 *  - noEntityShadow — отключает тени сущностей (дорого на больших серверах)
 *  - noFog          — отключает туман (особенно важен в Nether)
 *  - entityCulling  — не рендерить сущностей за пределами поля зрения (FOV)
 *
 * Реализация:
 *  Флаги читаются из MixinParticleManager и MixinBackgroundRenderer через
 *  статические геттеры FpsBoost.is*().
 *  Это паттерн, уже используемый в проекте (см. NoRender → MixinWorldRenderer).
 */
public class FpsBoost extends Module {

    // ── Настройки ─────────────────────────────────────────────────────────────
    private final Setting noParticles    = new Setting("Отключить частицы",   true);
    private final Setting noWeather      = new Setting("Отключить погоду",    false);
    private final Setting noEntityShadow = new Setting("Тени сущностей",      true);
    private final Setting noFog          = new Setting("Отключить туман",     false);
    private final Setting entityCulling  = new Setting("Entity Culling",      true);

    // ── Singleton-доступ для Mixin-ов ────────────────────────────────────────
    private static FpsBoost INSTANCE;

    public FpsBoost() {
        super("FpsBoost", "Повышает FPS: отключает частицы, тени и лишние эффекты", Category.UTILITY);
        addSetting(noParticles);
        addSetting(noWeather);
        addSetting(noEntityShadow);
        addSetting(noFog);
        addSetting(entityCulling);
        INSTANCE = this;
    }

    // ── Статические геттеры для Mixin-ов ─────────────────────────────────────

    /** Возвращает true, если нужно заблокировать спавн частиц. */
    public static boolean isNoParticles() {
        return INSTANCE != null && INSTANCE.isEnabled()
                && INSTANCE.noParticles.getState();
    }

    /** Возвращает true, если нужно пропустить рендер погоды. */
    public static boolean isNoWeather() {
        return INSTANCE != null && INSTANCE.isEnabled()
                && INSTANCE.noWeather.getState();
    }

    /** Возвращает true, если нужно убрать тени сущностей. */
    public static boolean isNoEntityShadow() {
        return INSTANCE != null && INSTANCE.isEnabled()
                && INSTANCE.noEntityShadow.getState();
    }

    /** Возвращает true, если нужно отключить туман. */
    public static boolean isNoFog() {
        return INSTANCE != null && INSTANCE.isEnabled()
                && INSTANCE.noFog.getState();
    }

    /** Возвращает true, если включён Entity Culling. */
    public static boolean isEntityCulling() {
        return INSTANCE != null && INSTANCE.isEnabled()
                && INSTANCE.entityCulling.getState();
    }
}
