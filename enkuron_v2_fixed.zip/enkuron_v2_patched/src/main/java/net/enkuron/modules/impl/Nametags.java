package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.modules.SettingPresets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Nametags v2 — переведён на SettingPresets.
 */
public class Nametags extends Module {

    // ── Универсальные пресеты ─────────────────────────────────────────────────
    private final SettingPresets.TargetFilter targetFilter = new SettingPresets.TargetFilter();
    private final SettingPresets.Range        range        = new SettingPresets.Range(32.0, 8.0, 128.0);
    private final SettingPresets.UpdateRate   updateRate   = new SettingPresets.UpdateRate(3.0, 1.0, 10.0);

    // ── Собственные настройки ─────────────────────────────────────────────────
    private final Setting showHP    = new Setting("Полоса HP",        true);
    private final Setting showDist  = new Setting("Дистанция",        true);
    private final Setting showItem  = new Setting("Предмет в руке",   true);
    private final Setting showArmor = new Setting("Броня",            true);
    private final Setting scale     = new Setting("Масштаб",          1.0, 0.5, 2.0);

    private record TagEntry(
        String name, float hp, float maxHp, double dist,
        boolean isPlayer, String itemName, String armorStr,
        // Экранные координаты (обновляются в render)
        double worldX, double worldY, double worldZ
    ) {}

    private final List<TagEntry> cached = new ArrayList<>();

    public Nametags() {
        super("Nametags", "Кастомные теги над головами игроков и мобов", Category.VISUAL);
        targetFilter.addTo(this);  // Игроки / Враждебные / Пассивные / Животные
        range.addTo(this);         // Дальность
        updateRate.addTo(this);    // Обновление (тики)
        addSetting(showHP); addSetting(showDist);
        addSetting(showItem); addSetting(showArmor); addSetting(scale);
        this.x = 0; this.y = 0;
    }

    @Override
    public void onEnable() { cached.clear(); updateRate.reset(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (!updateRate.ready()) return;

        cached.clear();
        Vec3d pp = mc.player.getPos();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player) || !living.isAlive()) continue;
            if (!targetFilter.passes(living)) continue;
            if (!range.inRange(living, mc.player)) continue;

            boolean isPlayer = living instanceof PlayerEntity;
            String itemName = "";
            if (isPlayer && showItem.getState()) {
                ItemStack held = living.getMainHandStack();
                if (!held.isEmpty()) itemName = held.getName().getString();
            }
            String armorStr = (isPlayer && showArmor.getState())
                ? buildArmorString((PlayerEntity) living) : "";

            cached.add(new TagEntry(
                living.getName().getString(),
                living.getHealth(), living.getMaxHealth(),
                living.getPos().distanceTo(pp),
                isPlayer, itemName, armorStr,
                living.getX(), living.getY() + living.getHeight() + 0.35, living.getZ()
            ));
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || mc.gameRenderer == null) return;
        if (cached.isEmpty()) return;

        var camera = mc.gameRenderer.getCamera();
        if (camera == null) return;

        for (TagEntry tag : cached) {
            // Проецируем мировые координаты в экранные
            int[] screen = worldToScreen(tag.worldX(), tag.worldY(), tag.worldZ(), camera);
            if (screen == null) continue;

            int sx = screen[0];
            int sy = screen[1];

            renderTag(context, tag, sx, sy);
        }
    }

    // ── Отрисовка одного тега ────────────────────────────────────────────────

    private void renderTag(DrawContext ctx, TagEntry tag, int sx, int sy) {
        float sc = (float) scale.getValue();
        int lineH = (int)(10 * sc);

        // Строки тега
        List<String> lines = new ArrayList<>();

        // Имя с иконкой типа
        String icon = tag.isPlayer() ? "§b♟ " : (isHostileTag(tag) ? "§c♞ " : "§a✿ ");
        String nameLine = icon + "§f" + tag.name();
        if (showDist.getState()) nameLine += " §7" + String.format("%.0fm", tag.dist());
        lines.add(nameLine);

        // Предмет в руке
        if (!tag.itemName().isEmpty()) lines.add("§e⚔ §7" + tag.itemName());

        // Броня
        if (!tag.armorStr().isEmpty()) lines.add(tag.armorStr());

        // Размер бокса
        int maxW = 0;
        for (String l : lines) {
            int w = mc.textRenderer.getWidth(l);
            if (w > maxW) maxW = w;
        }
        if (showHP.getState()) maxW = Math.max(maxW, 50);

        int totalH = lines.size() * lineH + (showHP.getState() ? lineH + 2 : 0);
        int bx = sx - maxW / 2 - 3;
        int by = sy - totalH - 2;

        // Фон
        ctx.fill(bx, by, bx + maxW + 6, by + totalH + 4, 0xCC0D0D1E);
        // Цветная полоска слева по типу
        int accentColor = tag.isPlayer() ? 0xFF5599FF : isHostileTag(tag) ? 0xFFFF4444 : 0xFF44DD77;
        ctx.fill(bx, by, bx + 2, by + totalH + 4, accentColor);

        // Текстовые строки
        for (int i = 0; i < lines.size(); i++) {
            int lx = bx + 4;
            int ly = by + 2 + i * lineH;
            ctx.drawText(mc.textRenderer, lines.get(i), lx, ly, 0xFFFFFFFF, true);
        }

        // Полоса HP
        if (showHP.getState()) {
            float ratio = tag.maxHp() > 0 ? Math.min(tag.hp() / tag.maxHp(), 1f) : 0f;
            int barY = by + 2 + lines.size() * lineH;
            int barX = bx + 4;
            int barW = maxW;
            ctx.fill(barX, barY, barX + barW, barY + 5, 0xFF1A1A2E);
            int barFillW = (int)(barW * ratio);
            if (barFillW > 0)
                ctx.fill(barX, barY, barX + barFillW, barY + 5, hpBarColor(ratio));
            // HP текст
            String hpText = String.format("%.0f/%.0f", tag.hp(), tag.maxHp());
            int tw = mc.textRenderer.getWidth(hpText);
            ctx.drawText(mc.textRenderer, "§f" + hpText,
                barX + (barW - tw) / 2, barY - 1, 0xFFCCCCCC, true);
        }
    }

    // ── Утилиты ─────────────────────────────────────────────────────────────

    private boolean isHostileTag(TagEntry tag) {
        return tag.name() != null && !tag.isPlayer();
    }

    private String buildArmorString(PlayerEntity player) {
        // Слоты: 0=boots,1=legs,2=chest,3=head → getArmorStack(i)
        StringBuilder sb = new StringBuilder();
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = player.getInventory().getArmorStack(i);
            if (!stack.isEmpty()) {
                String n = stack.getName().getString();
                // Короткая аббревиатура
                String abbr = n.length() > 4 ? n.substring(0, 4) : n;
                // Цвет по прочности
                int dur = stack.getMaxDamage() > 0
                    ? (int)(100f * (1f - (float) stack.getDamage() / stack.getMaxDamage()))
                    : 100;
                String color = dur > 60 ? "§a" : dur > 30 ? "§e" : "§c";
                sb.append(color).append(abbr).append("§8 ");
            }
        }
        return sb.toString().trim();
    }

    private int hpBarColor(float ratio) {
        if (ratio > 0.6f) return 0xFF44EE77;
        if (ratio > 0.3f) return 0xFFFFAA22;
        return 0xFFEE3333;
    }

    /**
     * Проецирует мировые координаты в экранные.
     * Возвращает null если точка за камерой.
     */
    private int[] worldToScreen(double wx, double wy, double wz, net.minecraft.client.render.Camera camera) {
        if (mc.getWindow() == null) return null;

        Vec3d camPos = camera.getPos();
        double dx = wx - camPos.x;
        double dy = wy - camPos.y;
        double dz = wz - camPos.z;

        float yawRad   = (float) Math.toRadians(camera.getYaw());
        float pitchRad = (float) Math.toRadians(camera.getPitch());

        // Camera basis vectors
        double[] fwd   = cameraForward(yawRad, pitchRad);
        double[] right = cameraRight(yawRad);
        double[] up    = cameraUp(yawRad, pitchRad);

        // Check if point is in front of camera
        double dot = dx * fwd[0] + dy * fwd[1] + dz * fwd[2];
        if (dot <= 0.1) return null;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        double fovRad = Math.toRadians(mc.options.getFov().getValue());
        double aspect = (double) sw / sh;
        double tanHalfFov = Math.tan(fovRad / 2);

        // Project onto camera plane
        double px = (dx * right[0] + dy * right[1] + dz * right[2]) / dot;
        double py = -(dx * up[0]   + dy * up[1]   + dz * up[2])    / dot;

        int screenX = (int)(sw / 2.0 + px / (tanHalfFov * aspect) * sw / 2.0);
        int screenY = (int)(sh / 2.0 + py / tanHalfFov            * sh / 2.0);

        return new int[]{screenX, screenY};
    }

    private double[] cameraForward(float yawRad, float pitchRad) {
        return new double[]{
            -Math.sin(yawRad) * Math.cos(pitchRad),
            -Math.sin(pitchRad),
            Math.cos(yawRad) * Math.cos(pitchRad)
        };
    }

    private double[] cameraRight(float yawRad) {
        return new double[]{Math.cos(yawRad), 0, Math.sin(yawRad)};
    }

    private double[] cameraUp(float yawRad, float pitchRad) {
        double[] fwd   = cameraForward(yawRad, pitchRad);
        double[] right = cameraRight(yawRad);
        // up = right × forward
        return new double[]{
            right[1] * fwd[2] - right[2] * fwd[1],
            right[2] * fwd[0] - right[0] * fwd[2],
            right[0] * fwd[1] - right[1] * fwd[0]
        };
    }
}
