package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * CapeEffect — косметический плащ из частиц.
 *
 * Режимы:
 *   China Hat — конический веер (шляпа китайского стиля)
 *   Dragon     — развевающийся дракон-плащ
 *   Royal      — королевский плащ из звёзд
 *   Sakura     — лепестки сакуры
 *
 * Вдохновлено стилем "China Hat" (斗笠).
 */
public class CapeEffect extends Module {

    private static final String[] MODES         = {"China Hat", "Dragon", "Royal", "Sakura"};
    private static final String[] PARTICLE_NAMES = {"Enchant", "End Rod", "Portal", "Cherry", "Flame"};

    private final Setting mode        = new Setting("Режим",    MODES,          0);
    private final Setting particles   = new Setting("Частицы",  PARTICLE_NAMES, 1);
    private final Setting size        = new Setting("Размер",   1.2, 0.4, 2.5);
    private final Setting density     = new Setting("Плотность",10.0, 4.0, 24.0);

    private int tick = 0;
    private double wavePhase = 0;

    public CapeEffect() {
        super("CapeEffect", "Косметический плащ из частиц за спиной", Category.VISUAL);
        addSetting(mode);
        addSetting(particles);
        addSetting(size);
        addSetting(density);
    }

    @Override
    public void onEnable() {
        tick      = 0;
        wavePhase = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        wavePhase += 0.18;

        Vec3d pos   = mc.player.getPos();
        float yaw   = mc.player.getYaw();
        double rad  = Math.toRadians(yaw);
        double r    = size.getValue();
        int    cnt  = (int) density.getValue();

        // Позиция сзади игрока
        double bx = pos.x - Math.sin(rad) * 0.3;
        double bz = pos.z + Math.cos(rad) * 0.3;
        double by = pos.y + mc.player.getHeight() * 0.75;

        switch (mode.getCurrentOption()) {
            case "China Hat" -> spawnChinaHat(bx, by, bz, rad, r, cnt);
            case "Dragon"    -> spawnDragonCape(bx, by, bz, rad, r, cnt);
            case "Royal"     -> spawnRoyalCape(bx, by, bz, rad, r, cnt);
            case "Sakura"    -> spawnSakuraCape(bx, by, bz, rad, r, cnt);
        }
    }

    /** Конический веер — имитация плоской шляпы "доу-ли" */
    private void spawnChinaHat(double cx, double cy, double cz,
                                double yawRad, double r, int cnt) {
        // Верхушка конуса над головой
        double tipX = cx;
        double tipY = cy + 0.5;
        double tipZ = cz;
        spawnParticle(tipX, tipY, tipZ);

        // Кольца конуса (2 кольца для объёма)
        for (int ring = 1; ring <= 2; ring++) {
            double ringR = r * ring * 0.5;
            double ringY = cy - ring * 0.25;
            int ringCnt  = cnt + ring * 4;
            for (int i = 0; i < ringCnt; i++) {
                double a  = (2 * Math.PI * i) / ringCnt + wavePhase * 0.3;
                // Вращаем конус так, чтобы он «смотрел» по направлению движения
                double lx = Math.cos(a) * ringR;
                double lz = Math.sin(a) * ringR;
                // Поворот вокруг оси Y на yaw игрока
                double rx = lx * Math.cos(yawRad) - lz * Math.sin(yawRad);
                double rz = lx * Math.sin(yawRad) + lz * Math.cos(yawRad);
                spawnParticle(cx + rx, ringY, cz + rz);
            }
        }
    }

    /** Развевающийся плащ дракона — синусоидальная волна */
    private void spawnDragonCape(double cx, double cy, double cz,
                                  double yawRad, double r, int cnt) {
        double perpX =  Math.cos(yawRad);
        double perpZ =  Math.sin(yawRad);

        for (int i = 0; i < cnt; i++) {
            double t   = (double) i / cnt;          // 0..1 по ширине
            double side = (t - 0.5) * 2 * r;        // -r..+r
            double wave = Math.sin(wavePhase + t * Math.PI * 3) * 0.35;

            double wx = cx + perpX * side;
            double wz = cz + perpZ * side;
            double wy = cy - t * mc.player.getHeight() * 0.6 + wave;

            spawnParticle(wx, wy, wz);
        }
    }

    /** Королевский плащ — пятиконечная звезда + нижний шлейф */
    private void spawnRoyalCape(double cx, double cy, double cz,
                                 double yawRad, double r, int cnt) {
        // Корона над головой
        for (int i = 0; i < 5; i++) {
            double a  = (2 * Math.PI * i) / 5 + wavePhase * 0.2;
            double ox = Math.cos(a) * r * 0.4;
            double oz = Math.sin(a) * r * 0.4;
            spawnParticle(cx + ox, cy + 0.3, cz + oz);
        }
        // Нижний шлейф
        double perpX = Math.cos(yawRad);
        double perpZ = Math.sin(yawRad);
        for (int i = 0; i < cnt; i++) {
            double t    = (double) i / cnt;
            double side = (t - 0.5) * 2 * r;
            double fall = Math.sin(wavePhase * 0.7 + t * Math.PI) * 0.2;
            double wx   = cx + perpX * side;
            double wz   = cz + perpZ * side;
            double wy   = cy - t * 0.8 + fall;
            spawnParticle(wx, wy, wz);
        }
    }

    /** Сакура — случайные плавающие лепестки */
    private void spawnSakuraCape(double cx, double cy, double cz,
                                  double yawRad, double r, int cnt) {
        double perpX = Math.cos(yawRad);
        double perpZ = Math.sin(yawRad);

        for (int i = 0; i < cnt / 2; i++) {
            double t     = Math.random();
            double side  = (Math.random() - 0.5) * 2 * r;
            double vert  = Math.random() * mc.player.getHeight();
            double drift = Math.sin(wavePhase + i) * 0.3;

            double wx = cx + perpX * side + drift;
            double wz = cz + perpZ * side;
            double wy = cy - vert;

            spawnParticle(wx, wy, wz);
        }
    }

    private void spawnParticle(double x, double y, double z) {
        if (mc.world == null) return;
        var p = switch (particles.getCurrentOption()) {
            case "End Rod"  -> ParticleTypes.END_ROD;
            case "Portal"   -> ParticleTypes.PORTAL;
            case "Cherry"   -> ParticleTypes.CHERRY_LEAVES;
            case "Flame"    -> ParticleTypes.FLAME;
            default         -> ParticleTypes.ENCHANT;
        };
        mc.world.addParticle(p, x, y, z, 0, 0.01, 0);
    }
}
