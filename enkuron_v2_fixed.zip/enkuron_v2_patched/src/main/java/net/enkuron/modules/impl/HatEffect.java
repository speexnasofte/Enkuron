package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * HatEffect — косметический «головной убор» из частиц над игроком.
 *
 * Режимы:
 *   Halo      — светящееся кольцо-нимб (End Rod)
 *   Wizard Hat — конус из частиц (как шляпа волшебника)
 *   Crown     — зубчатая корона (несколько колец с «зубцами»)
 *   Storm     — грозовая туча над головой (Cloud + Lightning)
 *   Sakura    — рассыпающиеся лепестки
 *   Aurora    — северное сияние-купол
 *   Devil     — рога и кольцо (красная корона + два рога)
 */
public class HatEffect extends Module {

    private static final String[] MODES = {
        "Halo", "Wizard Hat", "Crown", "Storm", "Sakura", "Aurora", "Devil"
    };
    private static final String[] COLORS = {
        "Gold", "White", "Blue", "Purple", "Red", "Green", "Rainbow"
    };

    private final Setting mode    = new Setting("Тип шляпы", MODES,  0);
    private final Setting color   = new Setting("Цвет",      COLORS, 0);
    private final Setting size    = new Setting("Размер",    0.5, 0.2, 1.2);
    private final Setting density = new Setting("Плотность", 10.0, 4.0, 20.0);

    private double angle    = 0;
    private double rainbow  = 0;
    private int    tick     = 0;
    private double auroraPh = 0;

    public HatEffect() {
        super("HatEffect", "Косметический головной убор из частиц", Category.VISUAL);
        addSetting(mode); addSetting(color); addSetting(size); addSetting(density);
    }

    @Override public void onEnable() { angle = rainbow = auroraPh = 0; tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        angle   += 0.16;
        rainbow += 0.025;
        auroraPh += 0.08;

        Vec3d pos = mc.player.getPos();
        double headY = pos.y + mc.player.getHeight() + 0.15;
        double r = size.getValue();
        int cnt = (int) density.getValue();

        switch (mode.getCurrentOption()) {
            case "Halo"       -> spawnHalo      (pos, headY, r, cnt);
            case "Wizard Hat" -> spawnWizardHat (pos, headY, r, cnt);
            case "Crown"      -> spawnCrown     (pos, headY, r, cnt);
            case "Storm"      -> spawnStorm     (pos, headY, r, cnt);
            case "Sakura"     -> spawnSakura    (pos, headY, r, cnt);
            case "Aurora"     -> spawnAurora    (pos, headY, r, cnt);
            case "Devil"      -> spawnDevil     (pos, headY, r, cnt);
        }
    }

    // ── Halo: простое кольцо-нимб ────────────────────────────────────────────
    private void spawnHalo(Vec3d pos, double y, double r, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = angle + (2 * Math.PI * i) / cnt;
            spawn(pos.x + Math.cos(a) * r, y, pos.z + Math.sin(a) * r);
        }
    }

    // ── Wizard Hat: конус из колец ────────────────────────────────────────────
    private void spawnWizardHat(Vec3d pos, double y, double r, int cnt) {
        int layers = 5;
        for (int l = 0; l < layers; l++) {
            double t    = (double) l / layers;
            double rr   = r * (1.0 - t);
            double yy   = y + t * r * 2.0;  // высота конуса
            int    cc   = Math.max(cnt - l * 2, 3);
            for (int i = 0; i < cc; i++) {
                double a = angle * (1 + l * 0.3) + (2 * Math.PI * i) / cc;
                spawn(pos.x + Math.cos(a) * rr, yy, pos.z + Math.sin(a) * rr);
            }
        }
        // Звезда на верхушке
        spawn(pos.x, y + r * 2.1, pos.z);
    }

    // ── Crown: зубчатая корона ────────────────────────────────────────────────
    private void spawnCrown(Vec3d pos, double y, double r, int cnt) {
        // Основное кольцо
        for (int i = 0; i < cnt; i++) {
            double a = angle + (2 * Math.PI * i) / cnt;
            spawn(pos.x + Math.cos(a) * r, y, pos.z + Math.sin(a) * r);
        }
        // «Зубцы» — 5 точек выше основного кольца
        int spikes = 5;
        for (int s = 0; s < spikes; s++) {
            double a = angle + (2 * Math.PI * s) / spikes;
            double px = pos.x + Math.cos(a) * r;
            double pz = pos.z + Math.sin(a) * r;
            spawn(px, y + 0.15, pz);
            spawn(px, y + 0.28, pz);
        }
    }

    // ── Storm: туча + молния ──────────────────────────────────────────────────
    private void spawnStorm(Vec3d pos, double y, double r, int cnt) {
        // Облако из частиц
        for (int i = 0; i < cnt; i++) {
            double a  = Math.random() * Math.PI * 2;
            double rr = Math.random() * r;
            mc.world.addParticle(ParticleTypes.CLOUD,
                pos.x + Math.cos(a) * rr, y + Math.random() * 0.2, pos.z + Math.sin(a) * rr,
                0, 0, 0);
        }
        // Изредка молния
        if (tick % 10 == 0 && Math.random() < 0.5) {
            double lx = pos.x + (Math.random() - 0.5) * r * 0.5;
            double lz = pos.z + (Math.random() - 0.5) * r * 0.5;
            for (int j = 0; j < 4; j++) {
                mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    lx, y - j * 0.12, lz,
                    (Math.random() - 0.5) * 0.05, -0.06, (Math.random() - 0.5) * 0.05);
            }
        }
    }

    // ── Sakura: лепестки рассыпаются ─────────────────────────────────────────
    private void spawnSakura(Vec3d pos, double y, double r, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a  = angle + (2 * Math.PI * i) / cnt + Math.sin(tick * 0.08 + i) * 0.3;
            double rr = r * (0.8 + Math.sin(tick * 0.12 + i * 0.7) * 0.2);
            double yy = y + Math.cos(tick * 0.09 + i * 0.5) * 0.1;
            mc.world.addParticle(ParticleTypes.CHERRY_LEAVES,
                pos.x + Math.cos(a) * rr, yy, pos.z + Math.sin(a) * rr,
                0, 0.01, 0);
        }
    }

    // ── Aurora: купол-полукольца ──────────────────────────────────────────────
    private void spawnAurora(Vec3d pos, double y, double r, int cnt) {
        int bands = 3;
        for (int b = 0; b < bands; b++) {
            double phOff = b * (Math.PI * 2 / bands) + auroraPh;
            float  hue   = (float)(((rainbow + b * 0.33) % 1.0));
            int    rgb   = java.awt.Color.HSBtoRGB(hue, 0.8f, 1f);
            int cv  = rgb & 0xFFFFFF;
            int cc = cnt / bands;
            for (int i = 0; i < cc; i++) {
                double t  = (double) i / cc;
                double a  = phOff + t * Math.PI;
                double rr = r * Math.sin(t * Math.PI);
                double yy = y + Math.cos(t * Math.PI - Math.PI / 2) * r;
                double phR = phOff * 2 + t * Math.PI * 2;
                mc.world.addParticle(new DustParticleEffect(cv, 1.2f),
                    pos.x + Math.cos(phR) * rr, yy, pos.z + Math.sin(phR) * rr,
                    0, 0, 0);
            }
        }
    }

    // ── Devil: рога + красная корона ─────────────────────────────────────────
    private void spawnDevil(Vec3d pos, double y, double r, int cnt) {
        // Красное кольцо
        for (int i = 0; i < cnt; i++) {
            double a = angle + (2 * Math.PI * i) / cnt;
            mc.world.addParticle(new DustParticleEffect(enkuronDustColor(1f, 0.05f, 0.05f), 1.0f),
                pos.x + Math.cos(a) * r, y, pos.z + Math.sin(a) * r,
                0, 0, 0);
        }
        // Левый рог
        double yaw = Math.toRadians(mc.player.getYaw());
        double hornOffX = Math.cos(yaw - Math.PI / 2);
        double hornOffZ = Math.sin(yaw - Math.PI / 2);
        for (int j = 0; j < 4; j++) {
            double t = j / 3.0;
            mc.world.addParticle(new DustParticleEffect(enkuronDustColor(0.7f, 0f, 0f), 0.8f),
                pos.x + hornOffX * r * 0.55 + t * 0.0, y + t * r * 0.8, pos.z + hornOffZ * r * 0.55,
                0, 0, 0);
        }
        // Правый рог
        for (int j = 0; j < 4; j++) {
            double t = j / 3.0;
            mc.world.addParticle(new DustParticleEffect(enkuronDustColor(0.7f, 0f, 0f), 0.8f),
                pos.x - hornOffX * r * 0.55, y + t * r * 0.8, pos.z - hornOffZ * r * 0.55,
                0, 0, 0);
        }
    }

    // ── Spawn helper ─────────────────────────────────────────────────────────
    private void spawn(double x, double y, double z) {
        if (mc.world == null) return;
        mc.world.addParticle(resolveParticle(), x, y, z, 0, 0.005, 0);
    }

    private net.minecraft.particle.ParticleEffect resolveParticle() {
        rainbow = (rainbow + 0.0) % 1.0; // already incremented in onTick
        String c = color.getCurrentOption();
        if (c.equals("Rainbow")) {
            int rgb = java.awt.Color.HSBtoRGB((float)(rainbow % 1.0), 1f, 1f);
            return new DustParticleEffect(rgb & 0xFFFFFF, 1.2f);
        }
        return switch (c) {
            case "White"  -> ParticleTypes.END_ROD;
            case "Blue"   -> new DustParticleEffect(enkuronDustColor(0.1f, 0.4f, 1.0f), 1.2f);
            case "Purple" -> new DustParticleEffect(enkuronDustColor(0.7f, 0.1f, 1.0f), 1.2f);
            case "Red"    -> new DustParticleEffect(enkuronDustColor(1.0f, 0.1f, 0.1f), 1.2f);
            case "Green"  -> new DustParticleEffect(enkuronDustColor(0.1f, 1.0f, 0.3f), 1.2f);
            default       -> new DustParticleEffect(enkuronDustColor(1.0f, 0.8f, 0.0f), 1.2f); // Gold
        };
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
