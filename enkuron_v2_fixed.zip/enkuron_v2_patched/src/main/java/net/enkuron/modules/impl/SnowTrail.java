package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * SnowTrail (Trail) — оставляет частицы за игроком при движении.
 *
 * Настройки:
 *   Тип следа    — Snow / Flame / Portal / Heart / Enchant
 *   Количество   — кол-во частиц за спавн (1–8)
 *   Только земля — частицы только когда игрок на земле
 */
public class SnowTrail extends Module {

    private static final String[] MODES = {"Snow", "Flame", "Portal", "Heart", "Enchant"};

    private final Setting trailMode   = new Setting("Тип следа",    MODES, 0);
    private final Setting count       = new Setting("Количество",   3.0, 1.0, 8.0);
    private final Setting groundOnly  = new Setting("Только земля", false);

    private int tickCounter = 0;
    private static final int PARTICLE_INTERVAL = 2;

    public SnowTrail() {
        super("Trail", "Оставляет красивый след частиц за игроком", Category.VISUAL);
        addSetting(trailMode);
        addSetting(count);
        addSetting(groundOnly);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (groundOnly.getState() && !mc.player.isOnGround()) return;

        if (++tickCounter < PARTICLE_INTERVAL) return;
        tickCounter = 0;

        Vec3d pos = mc.player.getPos();
        int n = (int) count.getValue();
        for (int i = 0; i < n; i++) {
            double offX = (Math.random() - 0.5) * 0.4;
            double offZ = (Math.random() - 0.5) * 0.4;
            spawnParticle(pos.x + offX, pos.y + 0.1, pos.z + offZ);
        }
    }

    private void spawnParticle(double x, double y, double z) {
        switch (trailMode.getCurrentOption()) {
            case "Snow"    -> mc.world.addParticle(ParticleTypes.SNOWFLAKE,          x, y, z, 0, -0.05, 0);
            case "Flame"   -> mc.world.addParticle(ParticleTypes.FLAME,              x, y, z, 0,  0.05, 0);
            case "Portal"  -> mc.world.addParticle(ParticleTypes.PORTAL,             x, y, z, 0,  0.05, 0);
            case "Heart"   -> mc.world.addParticle(ParticleTypes.HEART,              x, y, z, 0,  0.05, 0);
            case "Enchant" -> mc.world.addParticle(ParticleTypes.ENCHANT,            x, y, z, 0,  0.1,  0);
        }
    }

    @Override
    public void onEnable() { tickCounter = 0; }
}
