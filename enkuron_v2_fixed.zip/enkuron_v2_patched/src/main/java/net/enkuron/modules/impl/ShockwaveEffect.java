package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * ShockwaveEffect — расширяющееся кольцо-шокволна при прыжке или ударе.
 *
 * Триггеры:
 *   При прыжке  — волна от ног при отрыве от земли
 *   При ударе   — волна при левом клике (атака)
 *
 * Режимы волн:
 *   Ring     — одно расширяющееся кольцо
 *   Double   — два кольца (большое + малое с задержкой)
 *   Ripple   — несколько колец с нарастающим интервалом (как рябь)
 *   Explode  — кольцо + частицы взрываются наружу
 *
 * Частицы: Flame / End Rod / Crit / Dust (цвет) / Electric Spark
 */
public class ShockwaveEffect extends Module {

    private static final String[] MODES    = {"Ring", "Double", "Ripple", "Explode"};
    private static final String[] PTYPES   = {"End Rod", "Flame", "Crit", "Colored", "Electric"};
    private static final String[] TRIGGERS = {"Прыжок", "Удар", "Оба"};
    private static final String[] COLORS   = {"Blue", "Purple", "Green", "Red", "Gold", "Rainbow"};

    private final Setting mode    = new Setting("Режим",    MODES,    0);
    private final Setting ptype   = new Setting("Частицы",  PTYPES,   0);
    private final Setting trigger = new Setting("Триггер",  TRIGGERS, 2);
    private final Setting color   = new Setting("Цвет",     COLORS,   0);
    private final Setting maxR    = new Setting("Макс радиус", 2.5, 0.8, 5.0);
    private final Setting density = new Setting("Плотность", 16.0, 8.0, 32.0);

    // Активные волны
    private record Wave(Vec3d origin, double radius, int age, int delay, String waveMode) {}
    private final List<Wave> waves = new ArrayList<>();

    private boolean wasOnGround = false;
    private boolean wasAttacking = false;
    private double  rainbow = 0;
    private int     tick = 0;

    public ShockwaveEffect() {
        super("ShockwaveEffect", "Шокволна при прыжке или ударе", Category.VISUAL);
        addSetting(mode); addSetting(ptype); addSetting(trigger);
        addSetting(color); addSetting(maxR); addSetting(density);
    }

    @Override public void onEnable()  { waves.clear(); wasOnGround = false; wasAttacking = false; tick = 0; }
    @Override public void onDisable() { waves.clear(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        rainbow = (rainbow + 0.03) % 1.0;

        boolean onGround   = mc.player.isOnGround();
        boolean attacking  = mc.options.attackKey.isPressed();
        String  trig       = trigger.getCurrentOption();
        String  wm         = mode.getCurrentOption();

        // Триггер прыжка: был на земле → теперь нет
        if (!onGround && wasOnGround && (trig.equals("Прыжок") || trig.equals("Оба"))) {
            triggerWave(wm);
        }
        // Триггер удара: edge-detect ЛКМ
        if (attacking && !wasAttacking && (trig.equals("Удар") || trig.equals("Оба"))) {
            triggerWave(wm);
        }

        wasOnGround  = onGround;
        wasAttacking = attacking;

        // Обновляем и рендерим активные волны
        Iterator<Wave> it = waves.iterator();
        List<Wave> next = new ArrayList<>();
        while (it.hasNext()) {
            Wave w = it.next();
            if (w.age() > 20) continue; // волна жила > 20 тиков — удаляем
            // Задержка для Double/Ripple
            if (w.age() >= w.delay()) {
                renderWave(w);
            }
            next.add(new Wave(w.origin(), w.radius() + maxR.getValue() / 20.0, w.age() + 1, w.delay(), w.waveMode()));
        }
        waves.clear();
        waves.addAll(next);
    }

    private void triggerWave(String wm) {
        Vec3d origin = mc.player.getPos();
        waves.add(new Wave(origin, 0.1, 0, 0, wm));
        if (wm.equals("Double")) {
            waves.add(new Wave(origin, 0.1, 0, 6, wm)); // вторая волна с задержкой
        }
        if (wm.equals("Ripple")) {
            for (int i = 0; i < 3; i++) {
                waves.add(new Wave(origin, 0.1 + i * 0.2, 0, i * 4, wm));
            }
        }
    }

    private void renderWave(Wave w) {
        Vec3d pos = w.origin();
        double r  = w.radius();
        int cnt   = (int) density.getValue();
        double max = maxR.getValue();
        // Прозрачность: исчезает по мере расширения
        float fade = (float)(1.0 - r / max);
        if (fade <= 0) return;

        for (int i = 0; i < cnt; i++) {
            double a = (2 * Math.PI * i) / cnt;
            double x = pos.x + Math.cos(a) * r;
            double z = pos.z + Math.sin(a) * r;

            if (mode.getCurrentOption().equals("Explode")) {
                mc.world.addParticle(resolveParticle(),
                    x, pos.y + 0.1, z,
                    Math.cos(a) * 0.12, 0.06 + Math.random() * 0.08, Math.sin(a) * 0.12);
            } else {
                mc.world.addParticle(resolveParticle(), x, pos.y + 0.05, z, 0, 0.01, 0);
            }
        }
    }

    private net.minecraft.particle.ParticleEffect resolveParticle() {
        return switch (ptype.getCurrentOption()) {
            case "Flame"    -> ParticleTypes.FLAME;
            case "Crit"     -> ParticleTypes.CRIT;
            case "Electric" -> ParticleTypes.ELECTRIC_SPARK;
            case "Colored"  -> {
                String c = color.getCurrentOption();
                if (c.equals("Rainbow")) {
                    int rgb = java.awt.Color.HSBtoRGB((float) rainbow, 1f, 1f);
                    yield new DustParticleEffect(rgb & 0xFFFFFF, 1.2f);
                }
                yield switch (c) {
                    case "Blue"   -> new DustParticleEffect(enkuronDustColor(0.1f, 0.4f, 1.0f), 1.2f);
                    case "Purple" -> new DustParticleEffect(enkuronDustColor(0.7f, 0.1f, 1.0f), 1.2f);
                    case "Green"  -> new DustParticleEffect(enkuronDustColor(0.1f, 1.0f, 0.3f), 1.2f);
                    case "Red"    -> new DustParticleEffect(enkuronDustColor(1.0f, 0.1f, 0.1f), 1.2f);
                    default       -> new DustParticleEffect(enkuronDustColor(1.0f, 0.8f, 0.0f), 1.2f);
                };
            }
            default -> ParticleTypes.END_ROD;
        };
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
