package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * Brightness v9 — единый модуль управления яркостью.
 *
 * Заменяет три отдельных модуля из v8:
 *   FullBright      → просто выставить уровень на 100%
 *   Brightness      → слайдер яркости
 *   SmartBrightness → авто-режим в пещерах
 *
 * Почему объединили:
 *   - Все три писали в mc.options.getGamma() и конфликтовали при одновременном включении
 *   - FullBright = Brightness с уровнем 100 — полный дубликат
 *   - SmartBrightness добавлял только одну фичу (autoCave) поверх Brightness
 *
 * Настройки:
 *   Уровень (%)      — 0–500, default 100  (слайдер)
 *   Авто в пещерах   — вкл/выкл           (чекбокс)
 *   Порог пещеры (Y) — 20–60, default 40  (слайдер, активен только если Авто включено)
 *   Авторестор       — вкл/выкл, default true
 */
public class Brightness extends Module {

    private final Setting level     = new Setting("Уровень (%)",      100.0, 0.0, 500.0);
    private final Setting autoCave  = new Setting("Авто в пещерах",   false);
    private final Setting caveY     = new Setting("Порог пещеры (Y)", 40.0,  20.0, 60.0);
    private final Setting restore   = new Setting("Авторестор",       true);

    private double savedGamma = -1;

    public Brightness() {
        super("Brightness", "Управление яркостью: слайдер + авто в пещерах", Category.VISUAL);
        addSetting(level);
        addSetting(autoCave);
        addSetting(caveY);
        addSetting(restore);
    }

    @Override
    public void onEnable() {
        if (mc.options == null) return;
        savedGamma = mc.options.getGamma().getValue();
        applyGamma();
    }

    @Override
    public void onTick() {
        applyGamma();
    }

    @Override
    public void onDisable() {
        if (mc.options == null) return;
        if (restore.getState() && savedGamma >= 0) {
            mc.options.getGamma().setValue(savedGamma);
        }
        savedGamma = -1;
    }

    private void applyGamma() {
        if (mc.options == null) return;

        double target = level.getValue() / 100.0;

        // Авто-режим: в пещерах (низкий Y) выставляем максимум
        if (autoCave.getState() && mc.player != null
                && mc.player.getY() < caveY.getValue()) {
            target = 5.0; // 500% — максимум как у старого FullBright
        }

        mc.options.getGamma().setValue(target);
    }
}
