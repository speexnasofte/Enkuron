package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;

/**
 * TotemCounter — количество тотемов бессмертия.
 *
 * Настройки:
 *   Порог предупреждения — при каком кол-ве мигать (1–5)
 *   Показ иконки         — рисовать иконку тотема
 */
public class TotemCounter extends Module {

    private final Setting warnThreshold = new Setting("Порог предупреждения", 2.0, 1.0, 5.0);
    private final Setting showIcon      = new Setting("Показ иконки",         true);

    private int blinkTick = 0;

    public TotemCounter() {
        super("TotemCounter", "Показывает количество тотемов в инвентаре", Category.HUD);
        addSetting(warnThreshold);
        addSetting(showIcon);
        this.x = 5;
        this.y = 200;
    }

    @Override public void onTick() { blinkTick++; }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int total = countTotems();
        boolean blink = (blinkTick / 10) % 2 == 0;

        if (total == 0 && !blink) return;

        int warn = (int) warnThreshold.getValue();
        int color = total >= warn + 1 ? 0xFF44FF44
                  : total >= 1       ? 0xFFFFDD44
                  : 0xFFFF4444;

        int iconW = showIcon.getState() ? 20 : 2;
        context.fill(x - 2, y - 2, x + 42 + iconW, y + 18, 0xBB111116);
        context.fill(x - 2, y - 2, x + 42 + iconW, y - 1, color & 0x77FFFFFF | 0x77000000);

        if (showIcon.getState()) {
            context.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), x, y);
        }

        String text = total > 0 ? "×" + total : "×0";
        context.drawText(mc.textRenderer, "§l" + text, x + iconW, y + 4, color, true);
    }

    private int countTotems() {
        if (mc.player == null) return 0;
        int count = 0;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) count++;
        }
        if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) count++;
        return count;
    }
}
