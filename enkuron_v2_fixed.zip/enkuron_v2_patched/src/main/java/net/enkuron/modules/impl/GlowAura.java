package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * GlowAura — визуальная аура частиц вокруг игрока.
 *
 * Режимы (mode):
 *   Circle  — круговое кольцо частиц на уровне ног
 *   Spiral  — спираль частиц снизу вверх
 *   Halo    — кольцо над головой
 *
 * Настройки:
 *   Режим       — Circle / Spiral / Halo
 *   Радиус      — 0.5 – 3.0 блока
 *   Плотность   — 4 – 20 частиц за тик
 *   Тип частиц  — Enchant / Portal / End Rod / Flame / Soul
 */
public class GlowAura extends Module {

    private static final String[] MODES        = {"Circle", "Spiral", "Halo"};
    private static final String[] PARTICLE_TYPES = {"Enchant", "Portal", "End Rod", "Flame", "Soul"};

    private final Setting mode        = new Setting("Режим",      MODES,         0);
    private final Setting particleType= new Setting("Частицы",    PARTICLE_TYPES, 0);
    private final Setting radius      = new Setting("Радиус",      1.2, 0.5, 3.0);
    private final Setting density     = new Setting("Плотность",   8.0, 4.0, 24.0);

    private int tickCount = 0;
    private double spiralAngle = 0;

    public GlowAura() {
        super("GlowAura", "Визуальная аура частиц вокруг игрока", Category.VISUAL);
        addSetting(mode);
        addSetting(particleType);
        addSetting(radius);
        addSetting(density);
    }

    @Override
    public void onEnable() {
        tickCount    = 0;
        spiralAngle  = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        tickCount++;
        // Пропускаем каждый второй тик для производительности
        if (tickCount % 2 != 0) return;

        Vec3d pos = mc.player.getPos();
        int   count   = (int) density.getValue();
        double r      = radius.getValue();

        switch (mode.getCurrentOption()) {
            case "Circle"  -> spawnCircle(pos, r, count, 0.1);
            case "Spiral"  -> spawnSpiral(pos, r, count);
            case "Halo"    -> spawnCircle(pos, r, count, mc.player.getHeight() + 0.2);
        }
    }

    /** Кольцо частиц на заданной высоте */
    private void spawnCircle(Vec3d center, double r, int count, double yOffset) {
        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI * i) / count;
            double ox = Math.cos(angle) * r;
            double oz = Math.sin(angle) * r;
            spawnParticle(center.x + ox, center.y + yOffset, center.z + oz);
        }
    }

    /** Спираль снизу вверх */
    private void spawnSpiral(Vec3d center, double r, int count) {
        spiralAngle += 0.3;
        double height = mc.player.getHeight();
        for (int i = 0; i < count; i++) {
            double t     = (double) i / count;
            double angle = spiralAngle + t * Math.PI * 4;
            double yOff  = t * height;
            double ox    = Math.cos(angle) * r * (1 - t * 0.3);
            double oz    = Math.sin(angle) * r * (1 - t * 0.3);
            spawnParticle(center.x + ox, center.y + yOff, center.z + oz);
        }
    }

    private void spawnParticle(double x, double y, double z) {
        if (mc.world == null) return;
        var particle = switch (particleType.getCurrentOption()) {
            case "Portal"   -> ParticleTypes.PORTAL;
            case "End Rod"  -> ParticleTypes.END_ROD;
            case "Flame"    -> ParticleTypes.FLAME;
            case "Soul"     -> ParticleTypes.SOUL;
            default         -> ParticleTypes.ENCHANT;
        };
        mc.world.addParticle(particle, x, y, z, 0, 0.02, 0);
    }
}
