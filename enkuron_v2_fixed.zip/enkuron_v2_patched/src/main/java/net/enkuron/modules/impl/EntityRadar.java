package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * EntityRadar v2 — мини-радар с зумированием и легендой.
 *
 * НОВОЕ v2:
 *   • Зумирование: колесо прокрутки (через setting) меняет радиус обзора
 *     — настройка "Зум" от 0.25x до 4.0x (множитель дальности)
 *   • Легенда в углу: цветные точки с подписями (Игрок / Враг / Нейтральный)
 *   • Счётчик по типам в заголовке: P:2 H:3 A:1
 *   • Точки игроков крупнее (3×3), мобов меньше (2×2)
 *   • Кольцо тревоги: если враг ближе 10 блоков — красный ободок радара
 */
public class EntityRadar extends Module {

    private static final String[] ZOOM_OPTS = {"0.25x", "0.5x", "1x", "2x", "4x"};

    private final Setting range       = new Setting("Радиус (блоки)",      64.0, 16.0, 128.0);
    private final Setting showPlayers = new Setting("Показывать игроков",   true);
    private final Setting showHostile = new Setting("Показывать мобов",     true);
    private final Setting showPassive = new Setting("Показывать пассивных", false);
    private final Setting radarSize   = new Setting("Размер радара",        80.0, 60.0, 140.0);
    private final Setting updateRate  = new Setting("Обновление (тики)",    4.0,  1.0, 10.0);
    private final Setting zoomSetting = new Setting("Зум",                  ZOOM_OPTS, 2); // default 1x
    private final Setting showLegend  = new Setting("Легенда",              true);

    private final List<RadarDot> cachedDots = new ArrayList<>();
    private int tickCounter = 0;
    private double cachedSin = 0, cachedCos = 1;
    private boolean dangerAlert = false;

    // Счётчики по типам
    private int cntPlayer, cntHostile, cntPassive;

    private record RadarDot(double rx, double rz, int color, boolean isPlayer) {}

    public EntityRadar() {
        super("EntityRadar", "Мини-радар с зумом и легендой", Category.HUD);
        this.x = 5; this.y = 160;
        addSetting(range); addSetting(showPlayers);
        addSetting(showHostile); addSetting(showPassive);
        addSetting(radarSize); addSetting(updateRate);
        addSetting(zoomSetting); addSetting(showLegend);
    }

    @Override
    public void onEnable() { cachedDots.clear(); tickCounter = 0; dangerAlert = false; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (++tickCounter < (int) updateRate.getValue()) return;
        tickCounter = 0;

        cachedDots.clear();
        cntPlayer = cntHostile = cntPassive = 0;
        dangerAlert = false;

        double baseRange = range.getValue();
        double zoomMul   = resolveZoom();
        double effectiveRange = baseRange / zoomMul;  // зум увеличивает масштаб, уменьшает видимый радиус
        double half  = radarSize.getValue() / 2.0;
        double scale = half / effectiveRange;

        double rad = Math.toRadians(mc.player.getYaw());
        cachedSin = Math.sin(rad);
        cachedCos = Math.cos(rad);

        Vec3d playerPos = mc.player.getPos();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player) || !living.isAlive()) continue;

            boolean isPlayer  = living instanceof PlayerEntity;
            boolean isHostile = living instanceof HostileEntity;
            boolean isPassive = living instanceof PassiveEntity;

            if (isPlayer  && !showPlayers.getState()) continue;
            if (isHostile && !showHostile.getState()) continue;
            if (isPassive && !showPassive.getState()) continue;
            if (!isPlayer && !isHostile && !isPassive) continue;

            double dx = living.getX() - playerPos.x;
            double dz = living.getZ() - playerPos.z;
            double distSq = dx * dx + dz * dz;
            if (distSq > effectiveRange * effectiveRange) continue;

            // Тревога: враг ближе 10 блоков
            if (isHostile && distSq < 100) dangerAlert = true;

            double rx = (dx * cachedCos + dz * cachedSin) * scale;
            double rz = (-dx * cachedSin + dz * cachedCos) * scale;

            int color = isPlayer ? 0xFFFF5555 : isHostile ? 0xFFFF9944 : 0xFF55FF55;
            cachedDots.add(new RadarDot(rx, rz, color, isPlayer));

            if (isPlayer)  cntPlayer++;
            else if (isHostile) cntHostile++;
            else cntPassive++;
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int size  = (int) radarSize.getValue();
        int half  = size / 2;
        this.width = size + 4; this.height = size + 4;

        // Фон
        context.fill(x, y, x + size, y + size, 0xCC0A0A14);

        // Ободок — красный при тревоге, фиолетовый в обычном режиме
        int borderColor = dangerAlert ? 0xFFFF3333 : 0xFF8844FF;
        context.fill(x,          y,          x + size, y + 1,          borderColor);
        context.fill(x,          y + size - 1, x + size, y + size,     borderColor);
        context.fill(x,          y,          x + 1,    y + size,       borderColor);
        context.fill(x + size - 1, y,        x + size, y + size,       borderColor);

        // Крестовины
        int cx = x + half, cy = y + half;
        context.fill(cx - 1, y + 2, cx + 1, y + size - 2, 0x22FFFFFF);
        context.fill(x + 2, cy - 1, x + size - 2, cy + 1, 0x22FFFFFF);

        // Центр (игрок) — белый треугольник (имитация стрелки вверх)
        context.fill(cx - 1, cy - 3, cx + 1, cy - 1, 0xFFFFFFFF);
        context.fill(cx - 2, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        // Концентрические круги (дистанция)
        drawCircle(context, cx, cy, half / 2);
        drawCircle(context, cx, cy, half * 3 / 4);

        // Точки сущностей
        for (RadarDot dot : cachedDots) {
            int ex = Math.max(x + 2, Math.min(x + size - 3, cx + (int) dot.rx()));
            int ey = Math.max(y + 2, Math.min(y + size - 3, cy + (int) dot.rz()));
            if (dot.isPlayer()) {
                // Игроки — крупная точка 3×3
                context.fill(ex - 1, ey - 1, ex + 2, ey + 2, dot.color());
                context.fill(ex,     ey - 2, ex + 1, ey - 1, dot.color()); // верхний пиксель
            } else {
                // Мобы — точка 2×2
                context.fill(ex, ey, ex + 2, ey + 2, dot.color());
            }
        }

        // Заголовок с счётчиками
        String header = String.format("§8P:%d H:%d A:%d", cntPlayer, cntHostile, cntPassive);
        context.drawText(mc.textRenderer, header, x + 2, y + size - 10, 0x88FFFFFF, false);

        // Зум-индикатор
        String zoomStr = "§8Z:" + zoomSetting.getCurrentOption();
        context.drawText(mc.textRenderer, zoomStr,
                x + size - mc.textRenderer.getWidth(zoomStr) - 2,
                y + size - 10, 0x88FFFFFF, false);

        // Легенда
        if (showLegend.getState()) {
            renderLegend(context, x, y + size + 2);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /** Рисует пунктирный круг (только по осям — 4 точки) для дистанции */
    private void drawCircle(DrawContext ctx, int cx, int cy, int r) {
        int steps = 32;
        for (int i = 0; i < steps; i += 2) {
            double a = (2 * Math.PI * i) / steps;
            int px = cx + (int)(Math.cos(a) * r);
            int py = cy + (int)(Math.sin(a) * r);
            ctx.fill(px, py, px + 1, py + 1, 0x33FFFFFF);
        }
    }

    /** Легенда снизу радара */
    private void renderLegend(DrawContext ctx, int lx, int ly) {
        int boxW = (int) radarSize.getValue();
        ctx.fill(lx, ly, lx + boxW, ly + 24, 0xBB0A0A14);

        // Игрок
        ctx.fill(lx + 3, ly + 3, lx + 7, ly + 7, 0xFFFF5555);
        ctx.drawText(mc.textRenderer, "§cИгрок", lx + 9, ly + 2, 0xFFFF5555, false);

        // Враг
        ctx.fill(lx + 3, ly + 13, lx + 7, ly + 17, 0xFFFF9944);
        ctx.drawText(mc.textRenderer, "§6Враг", lx + 9, ly + 12, 0xFFFF9944, false);

        // Нейтральный (справа)
        int col2x = lx + boxW / 2;
        ctx.fill(col2x, ly + 3, col2x + 4, ly + 7, 0xFF55FF55);
        ctx.drawText(mc.textRenderer, "§aМирный", col2x + 6, ly + 2, 0xFF55FF55, false);
    }

    private double resolveZoom() {
        return switch (zoomSetting.getCurrentOption()) {
            case "0.25x" -> 0.25;
            case "0.5x"  -> 0.5;
            case "2x"    -> 2.0;
            case "4x"    -> 4.0;
            default      -> 1.0;
        };
    }
}
