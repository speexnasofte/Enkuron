package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * PetOrbit — косметический питомец-орбита из частиц.
 * Маленький «шарик» из частиц вращается вокруг игрока,
 * оставляя за собой хвостик.
 *
 * Режимы питомцев:
 *   Wisp    — блуждающий огонёк
 *   Ghost   — призрак (мягкий белый шар)
 *   Dragon  — маленький дракончик (точки + хвост)
 *   Crystal — кристальный куб из частиц
 */
public class PetOrbit extends Module {

    private static final String[] PETS   = {"Wisp", "Ghost", "Dragon", "Crystal"};
    private static final String[] SPEEDS = {"Slow", "Normal", "Fast"};

    private final Setting pet    = new Setting("Питомец",  PETS,   0);
    private final Setting speed  = new Setting("Скорость", SPEEDS, 1);
    private final Setting height = new Setting("Высота",   0.8, 0.3, 2.0);
    private final Setting dist   = new Setting("Дистанция",1.3, 0.5, 2.5);

    private double angle   = 0;
    private double bobPhase= 0;
    private int    tick    = 0;

    // Позиция питомца (для хвоста)
    private double petX, petY, petZ;

    public PetOrbit() {
        super("PetOrbit", "Питомец из частиц, вращающийся вокруг игрока", Category.VISUAL);
        addSetting(pet);
        addSetting(speed);
        addSetting(height);
        addSetting(dist);
    }

    @Override public void onEnable() { angle = 0; bobPhase = 0; tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        double spd = switch (speed.getCurrentOption()) {
            case "Slow"  -> 0.04;
            case "Fast"  -> 0.13;
            default      -> 0.08;
        };
        angle    += spd;
        bobPhase += 0.12;

        Vec3d pos = mc.player.getPos();
        double r  = dist.getValue();
        double h  = height.getValue();

        // Позиция питомца
        petX = pos.x + Math.cos(angle) * r;
        petZ = pos.z + Math.sin(angle) * r;
        petY = pos.y + h + Math.sin(bobPhase) * 0.2;

        switch (pet.getCurrentOption()) {
            case "Wisp"    -> spawnWisp();
            case "Ghost"   -> spawnGhost();
            case "Dragon"  -> spawnDragon(pos);
            case "Crystal" -> spawnCrystal();
        }
    }

    /** Блуждающий огонёк — тёплые частицы + шлейф */
    private void spawnWisp() {
        // Тело
        for (int i = 0; i < 5; i++) {
            double ox = (Math.random() - 0.5) * 0.2;
            double oy = (Math.random() - 0.5) * 0.2;
            double oz = (Math.random() - 0.5) * 0.2;
            mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                petX + ox, petY + oy, petZ + oz, 0, 0.02, 0);
        }
        // Хвостик
        for (int i = 0; i < 3; i++) {
            double t  = (double)(i + 1) / 4;
            double ta = angle - t * 0.35;
            double r  = dist.getValue();
            mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                mc.player.getX() + Math.cos(ta) * r * (1 - t * 0.2),
                petY - t * 0.1,
                mc.player.getZ() + Math.sin(ta) * r * (1 - t * 0.2),
                0, 0, 0);
        }
    }

    /** Призрак — мягкое белое облачко */
    private void spawnGhost() {
        // Тело-круг
        for (int i = 0; i < 6; i++) {
            double a  = (2 * Math.PI * i) / 6;
            double ox = Math.cos(a) * 0.18;
            double oz = Math.sin(a) * 0.18;
            mc.world.addParticle(ParticleTypes.END_ROD, petX + ox, petY, petZ + oz, 0, 0.01, 0);
        }
        // «Глазки»
        mc.world.addParticle(ParticleTypes.GLOW, petX - 0.07, petY + 0.08, petZ, 0, 0, 0);
        mc.world.addParticle(ParticleTypes.GLOW, petX + 0.07, petY + 0.08, petZ, 0, 0, 0);
        // Нижние завитки
        for (int i = 0; i < 3; i++) {
            double ox = (i - 1) * 0.15;
            double oy = Math.sin(bobPhase + i) * 0.06 - 0.18;
            mc.world.addParticle(ParticleTypes.END_ROD, petX + ox, petY + oy, petZ, 0, 0, 0);
        }
    }

    /** Дракончик — тело + хвост-цепочка */
    private void spawnDragon(Vec3d playerPos) {
        // Голова
        mc.world.addParticle(ParticleTypes.DRAGON_BREATH, petX, petY, petZ, 0, 0.01, 0);
        mc.world.addParticle(ParticleTypes.FLAME, petX, petY + 0.12, petZ, 0, 0.02, 0);
        // Тело-хвост (4 сегмента по орбите назад)
        double r = dist.getValue();
        for (int i = 1; i <= 4; i++) {
            double ta = angle - i * 0.22;
            double sx = playerPos.x + Math.cos(ta) * r;
            double sy = petY - i * 0.08;
            double sz = playerPos.z + Math.sin(ta) * r;
            mc.world.addParticle(
                i < 3 ? ParticleTypes.DRAGON_BREATH : ParticleTypes.PORTAL,
                sx, sy, sz, 0, 0, 0);
        }
    }

    /** Кристалл — маленький вращающийся куб из точек */
    private void spawnCrystal() {
        double s   = 0.15;
        double rot = angle * 2;
        // 8 вершин куба, повёрнутых на rot
        int[][] corners = {
            {-1,-1,-1},{1,-1,-1},{-1,1,-1},{1,1,-1},
            {-1,-1, 1},{1,-1, 1},{-1,1, 1},{1,1, 1}
        };
        for (int[] c : corners) {
            double lx = c[0] * s;
            double ly = c[1] * s;
            double lz = c[2] * s;
            // Поворот Y
            double rx = lx * Math.cos(rot) - lz * Math.sin(rot);
            double rz = lx * Math.sin(rot) + lz * Math.cos(rot);
            mc.world.addParticle(ParticleTypes.END_ROD,
                petX + rx, petY + ly, petZ + rz, 0, 0, 0);
        }
    }
}
