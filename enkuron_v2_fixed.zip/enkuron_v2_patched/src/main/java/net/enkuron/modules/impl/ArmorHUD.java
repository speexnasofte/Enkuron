package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/**
 * ArmorHUD — прочность брони.
 *
 * Настройки:
 *   Показ прочности — полоски под иконками
 *   Скрывать пустые — не рисовать слоты без брони
 *   Порядок         — Helmet→Boots / Boots→Helmet
 */
public class ArmorHUD extends Module {

    private static final int SLOT_SIZE = 18;
    private static final int GAP       = 2;

    private static final String[] ORDERS = {"Helmet→Boots", "Boots→Helmet"};

    private final Setting showDurability = new Setting("Прочность",      true);
    private final Setting hideEmpty      = new Setting("Скрывать пустые", true);
    private final Setting order          = new Setting("Порядок",         ORDERS, 0);

    public ArmorHUD() {
        super("ArmorHUD", "Отображает прочность брони на экране", Category.HUD);
        addSetting(showDurability);
        addSetting(hideEmpty);
        addSetting(order);
        this.x = 5; this.y = 100;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        boolean helmetFirst = order.getCurrentOption().equals("Helmet→Boots");

        int count = 0;
        for (int i = 0; i <= 3; i++) {
            ItemStack s = mc.player.getInventory().getArmorStack(i);
            if (!s.isEmpty() || !hideEmpty.getState()) count++;
        }
        if (count == 0) return;

        int totalW = count * (SLOT_SIZE + GAP) - GAP;
        this.width  = totalW + 8;
        this.height = SLOT_SIZE + (showDurability.getState() ? 12 : 6);

        context.fill(x - 2, y - 2, x + totalW + 4, y + height, 0xBB111116);
        context.fill(x - 2, y - 2, x + totalW + 4, y - 1, 0xFF8844FF);

        int drawX = x;
        for (int idx = 0; idx < 4; idx++) {
            int i = helmetFirst ? (3 - idx) : idx;
            ItemStack stack = mc.player.getInventory().getArmorStack(i);
            if (stack.isEmpty() && hideEmpty.getState()) continue;

            if (!stack.isEmpty()) {
                context.drawItem(stack, drawX, y);
                context.drawStackOverlay(mc.textRenderer, stack, drawX, y);
            }

            if (showDurability.getState() && stack.isDamageable()) {
                float dur = 1f - (float) stack.getDamage() / stack.getMaxDamage();
                int barW  = (int)(SLOT_SIZE * dur);
                int barC  = durabilityColor(dur);
                context.fill(drawX, y + SLOT_SIZE + 2, drawX + SLOT_SIZE, y + SLOT_SIZE + 5, 0xFF222222);
                context.fill(drawX, y + SLOT_SIZE + 2, drawX + barW,      y + SLOT_SIZE + 5, barC);
            }

            drawX += SLOT_SIZE + GAP;
        }
    }

    private int durabilityColor(float ratio) {
        int r = (int)((1f - ratio) * 255);
        int g = (int)(ratio * 200);
        return EnkuronColor.toARGB(r, g, 0, 255);
    }
}
