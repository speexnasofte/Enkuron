package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * BlockInfo — HUD модуль, показывающий информацию о блоке под прицелом.
 *
 * Отображает:
 *  - Название блока
 *  - Namespace ID (minecraft:stone и т.п.)
 *  - Координаты блока
 *  - Инструмент, которым лучше всего ломать
 *  - Прочность (hardness) блока
 *
 * Полностью легальный, только чтение данных клиентского мира.
 */
public class BlockInfo extends Module {

    private final Setting showId       = new Setting("Показывать ID",         true);
    private final Setting showCoords   = new Setting("Показывать координаты", true);
    private final Setting showTool     = new Setting("Лучший инструмент",     true);
    private final Setting showHardness = new Setting("Прочность блока",       true);
    private final Setting onlyCrosshair = new Setting("Только под прицелом",  true);

    // Кэш последнего блока чтобы не пересчитывать каждый рендер
    private String cachedName     = "";
    private String cachedId       = "";
    private String cachedCoords   = "";
    private String cachedTool     = "";
    private String cachedHardness = "";
    private boolean hasTarget     = false;

    public BlockInfo() {
        super("BlockInfo", "Информация о блоке под прицелом", Category.HUD);
        addSetting(showId);
        addSetting(showCoords);
        addSetting(showTool);
        addSetting(showHardness);
        addSetting(onlyCrosshair);
        this.x = 5;
        this.y = 100;
    }

    @Override
    public void onEnable() {
        hasTarget = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.BLOCK) {
            hasTarget = false;
            return;
        }

        BlockHitResult blockHit = (BlockHitResult) hit;
        BlockPos pos = blockHit.getBlockPos();
        BlockState state = mc.world.getBlockState(pos);
        Block block = state.getBlock();

        // Название
        cachedName = block.getName().getString();

        // Namespace ID
        var id = Registries.BLOCK.getId(block);
        cachedId = id.getNamespace() + ":" + id.getPath();

        // Координаты
        cachedCoords = pos.getX() + ", " + pos.getY() + ", " + pos.getZ();

        // Прочность
        float hardness = state.getHardness(mc.world, pos);
        if (hardness < 0) {
            cachedHardness = "Unbreakable";
        } else {
            cachedHardness = String.format("%.1f", hardness);
        }

        // Лучший инструмент — определяем по типу блока
        cachedTool = getBestTool(cachedId);

        hasTarget = true;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;
        if (onlyCrosshair.getState() && !hasTarget) return;
        if (!hasTarget) return;

        int lineH = 10;
        int pad   = 4;

        // Собираем строки для отображения
        java.util.List<String> lines = new java.util.ArrayList<>();
        lines.add("§b§l" + cachedName);
        if (showId.getState())       lines.add("§8" + cachedId);
        if (showCoords.getState())   lines.add("§7Pos: §f" + cachedCoords);
        if (showHardness.getState()) lines.add("§7Прочность: §e" + cachedHardness);
        if (showTool.getState())     lines.add("§7Инструмент: §a" + cachedTool);

        int maxW = 0;
        for (String line : lines) {
            int w = mc.textRenderer.getWidth(line);
            if (w > maxW) maxW = w;
        }

        int boxW = maxW + pad * 2;
        int boxH = lines.size() * lineH + pad * 2 - 2;
        this.width  = boxW;
        this.height = boxH;

        // Фон
        context.fill(x - 1, y - 1, x + boxW + 1, y + boxH + 1, 0x55000000);
        context.fill(x, y, x + boxW, y + boxH, 0xCC0D0D1E);
        // Акцентная полоска сверху
        context.fill(x, y, x + boxW, y + 1, 0xFF55BBFF);

        for (int i = 0; i < lines.size(); i++) {
            context.drawText(mc.textRenderer, lines.get(i),
                    x + pad, y + pad + i * lineH, 0xFFFFFFFF, true);
        }
    }

    /**
     * Определяет лучший инструмент по namespace ID блока.
     * Не требует никаких серверных вызовов — только ID.
     */
    private String getBestTool(String id) {
        String path = id.contains(":") ? id.split(":")[1] : id;

        // Камень, руды, кирпич — кирка
        if (path.contains("stone")     || path.contains("cobblestone") ||
            path.contains("ore")       || path.contains("brick") ||
            path.contains("basalt")    || path.contains("andesite") ||
            path.contains("granite")   || path.contains("diorite") ||
            path.contains("deepslate") || path.contains("obsidian") ||
            path.contains("netherrack")|| path.contains("nether_brick")) {
            return "Кирка ⛏";
        }

        // Дерево, доски — топор
        if (path.contains("log")   || path.contains("planks") ||
            path.contains("wood")  || path.contains("stem") ||
            path.contains("hyphae")|| path.contains("chest") ||
            path.contains("barrel")|| path.contains("bookshelf") ||
            path.contains("fence") || path.contains("door") ||
            path.contains("trapdoor") || path.contains("crafting")) {
            return "Топор 🪓";
        }

        // Земля, трава, песок, гравий — лопата
        if (path.contains("dirt")  || path.contains("grass") ||
            path.contains("sand")  || path.contains("gravel") ||
            path.contains("soul_sand") || path.contains("soul_soil") ||
            path.contains("clay")  || path.contains("podzol") ||
            path.contains("mycelium") || path.contains("snow") ||
            path.contains("mud")) {
            return "Лопата 🪣";
        }

        // Листья, паутина — ножницы/меч
        if (path.contains("leaves") || path.contains("wool") ||
            path.contains("carpet")) {
            return "Ножницы ✂";
        }
        if (path.contains("cobweb")) {
            return "Меч 🗡";
        }

        return "Руки 🤲";
    }
}
