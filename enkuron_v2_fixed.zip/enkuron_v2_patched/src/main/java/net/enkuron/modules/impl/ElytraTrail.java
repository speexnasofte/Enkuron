package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * ElytraTrail — шлейф из частиц, оставляемый игроком при движении.
 *
 * Режимы:
 *   Comet    — яркий хвост кометы (частицы с угасанием по линии движения)
 *   Flame    — огненный след
 *   Rainbow  — радужный шлейф (плавная смена HSB)
 *   Smoke    — дымовой след
 *   Lightning — искры молнии
 *   Neon     — неоновая линия из цветных пылинок
 *   Confetti — конфетти разных цветов
 *
 * Работает всегда (не только при полёте на элитре).
 */
public class ElytraTrail extends Module {

    private static final String[] MODES = {
        "Comet", "Flame", "Rainbow", "Smoke", "Lightning", "Neon", "Confetti"
    };
    private static final String[] COLORS = {
        "White", "Blue", "Purple", "Green", "Red", "Gold"
    };

    private final Setting mode    = new Setting("Режим",    MODES,  0);
    private final Setting color   = new Setting("Цвет",     COLORS, 0);
    private final Setting density = new Setting("Плотность",8.0, 2.0, 20.0);
    private final Setting spread  = new Setting("Разброс",  0.15, 0.0, 0.6);
    private final Setting onlyFly = new Setting("Только полёт", false);

    private double rainbowHue = 0;
    private int    tick = 0;

    // Случайные цвета для конфетти
    private static final int[] CONFETTI_COLORS = {
        0xFF3333, 0x33CC33, 0x3366FF,
        0xFFE61A, 0xFF33E5, 0x1AE5FF
    };

    public ElytraTrail() {
        super("ElytraTrail", "Шлейф частиц за движущимся игроком", Category.VISUAL);
        addSetting(mode);
        addSetting(color);
        addSetting(density);
        addSetting(spread);
        addSetting(onlyFly);
    }

    @Override public void onEnable()  { rainbowHue = 0; tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;

        // Проверка скорости (не спавним если стоим на месте)
        Vec3d vel = mc.player.getVelocity();
        double speed = Math.sqrt(vel.x * vel.x + vel.z * vel.z + vel.y * vel.y);
        if (speed < 0.05) return;

        // Только при полёте на элитре
        if (onlyFly.getState() && !mc.player.isGliding()) return;

        rainbowHue = (rainbowHue + 0.03) % 1.0;

        Vec3d pos = mc.player.getPos();
        double h  = mc.player.getHeight() * 0.5;
        int cnt   = (int) density.getValue();
        double sp = spread.getValue();

        for (int i = 0; i < cnt; i++) {
            double ox = (Math.random() - 0.5) * sp;
            double oy = (Math.random() - 0.5) * sp;
            double oz = (Math.random() - 0.5) * sp;

            double px = pos.x + ox;
            double py = pos.y + h  + oy;
            double pz = pos.z + oz;

            // Скорость частицы — чуть обратная движению
            double vx = -vel.x * (0.1 + Math.random() * 0.1);
            double vy = -vel.y * 0.05 + (Math.random() - 0.5) * 0.02;
            double vz = -vel.z * (0.1 + Math.random() * 0.1);

            spawnModeParticle(px, py, pz, vx, vy, vz, i);
        }
    }

    private void spawnModeParticle(double x, double y, double z,
                                    double vx, double vy, double vz, int idx) {
        if (mc.world == null) return;
        switch (mode.getCurrentOption()) {
            case "Flame"     -> mc.world.addParticle(ParticleTypes.FLAME,     x, y, z, vx, vy, vz);
            case "Smoke"     -> mc.world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y, z, vx * 0.3, 0.02, vz * 0.3);
            case "Lightning" -> {
                if (Math.random() < 0.5)
                    mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK, x, y, z, vx * 2, vy, vz * 2);
            }
            case "Rainbow" -> {
                float h2 = (float)((rainbowHue + idx * 0.07) % 1.0);
                int rgb  = java.awt.Color.HSBtoRGB(h2, 1f, 1f);
                mc.world.addParticle(new DustParticleEffect(rgb & 0xFFFFFF, 1.2f), x, y, z, vx, vy, vz);
            }
            case "Neon" -> {
                mc.world.addParticle(new DustParticleEffect(colorInt(), 1.5f), x, y, z, vx, vy, vz);
            }
            case "Confetti" -> {
                int cc = CONFETTI_COLORS[idx % CONFETTI_COLORS.length];
                mc.world.addParticle(new DustParticleEffect(cc, 1.0f), x, y, z, vx, vy + 0.05, vz);
            }
            default -> // Comet
                mc.world.addParticle(ParticleTypes.END_ROD, x, y, z, vx * 0.5, vy * 0.5, vz * 0.5);
        }
    }

    private int colorInt() {
        return switch (color.getCurrentOption()) {
            case "Blue"   -> 0x1A66FF;
            case "Purple" -> 0xB21AFF;
            case "Green"  -> 0x1AFF4D;
            case "Red"    -> 0xFF1A1A;
            case "Gold"   -> 0xFFCC00;
            default       -> 0xFFFFFF;
        };
    }


}
