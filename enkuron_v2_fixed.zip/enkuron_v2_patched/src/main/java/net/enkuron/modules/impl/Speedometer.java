package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

/**
 * Speedometer — скорость передвижения.
 *
 * Настройки:
 *   Единицы      — b/s (блоки/с) / km/h (условно)
 *   Полоска      — показывать полоску скорости
 *   Макс. скорость — максимум для нормировки полоски (5–30)
 */
public class Speedometer extends Module {

    private static final String[] UNITS = {"b/s", "km/h"};

    private final Setting units     = new Setting("Единицы",       UNITS, 0);
    private final Setting showBar   = new Setting("Полоска",       true);
    private final Setting maxSpeed  = new Setting("Макс. скорость", 15.0, 5.0, 30.0);

    public Speedometer() {
        super("Speedometer", "Показывает скорость передвижения", Category.HUD);
        addSetting(units);
        addSetting(showBar);
        addSetting(maxSpeed);
        this.x = 5; this.y = 75;
        this.width = 80; this.height = 16;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        double dX = mc.player.getX() - mc.player.prevX;
        double dZ = mc.player.getZ() - mc.player.prevZ;
        float speed = (float)(Math.sqrt(dX * dX + dZ * dZ) * 20);

        String unit = units.getCurrentOption();
        float displaySpeed = unit.equals("km/h") ? speed * 3.6f : speed;
        String text = String.format("%.1f " + unit, displaySpeed);

        int tw = mc.textRenderer.getWidth(text) + mc.textRenderer.getWidth("▶ ") + 8;
        this.width  = tw + 4;
        this.height = showBar.getState() ? 16 : 13;

        int color;
        if      (speed < 4f)  color = 0xFFAAAAAA;
        else if (speed < 7f)  color = 0xFF44AAFF;
        else if (speed < 10f) color = 0xFF44EE77;
        else                  color = 0xFFFF9944;

        context.fill(x - 2, y - 1, x + tw + 2, y + 11, 0xBB111116);
        context.fill(x - 2, y - 1, x - 1,      y + 11, color);

        if (showBar.getState()) {
            float ratio = Math.min(speed / (float) maxSpeed.getValue(), 1f);
            context.fill(x + 2, y + 9, x + tw - 2, y + 11, 0xFF222233);
            context.fill(x + 2, y + 9, x + 2 + (int)((tw - 4) * ratio), y + 11, color);
        }

        context.drawText(mc.textRenderer, "▶ " + text, x + 2, y, color, true);
    }
}
