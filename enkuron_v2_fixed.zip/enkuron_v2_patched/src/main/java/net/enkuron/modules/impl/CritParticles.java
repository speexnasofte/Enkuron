package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * CritParticles v8 — новые эффекты: Lightning, Dragon, Void.
 *
 * Режимы:
 *   Stars    — оригинальные критические звёздочки
 *   Blood    — красные пылинки
 *   Sparks   — электрические искры
 *   Sakura   — лепестки сакуры
 *   Shatter  — осколки льда + End Rod
 *   Lightning — NEW: ярко-белые/жёлтые частицы молнии с звуковым всплеском
 *   Dragon   — NEW: фиолетово-чёрное облако дракона (DRAGON_BREATH + Portal)
 *   Void     — NEW: поглощение в пустоту — тёмные частицы летят вниз и внутрь
 *
 * FIX: edge-detect атаки (не спавнится каждый тик при зажатой ЛКМ).
 */
public class CritParticles extends Module {

    private static final String[] MODES = {
        "Stars", "Blood", "Sparks", "Sakura", "Shatter", "Lightning", "Dragon", "Void"
    };

    private final Setting mode  = new Setting("Эффект",        MODES, 0);
    private final Setting count = new Setting("Кол-во частиц", 12.0, 4.0, 30.0);

    private boolean wasAttackPressed = false;

    public CritParticles() {
        super("CritParticles", "Кастомные частицы при ударе по врагу", Category.VISUAL);
        addSetting(mode);
        addSetting(count);
    }

    @Override
    public void onEnable() { wasAttackPressed = false; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        boolean attackNow = mc.options.attackKey.isPressed();
        boolean justHit   = attackNow && !wasAttackPressed;
        wasAttackPressed  = attackNow;

        if (justHit &&
            mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult hit &&
            hit.getEntity() instanceof net.minecraft.entity.LivingEntity le) {
            Vec3d pos = le.getPos().add(0, le.getHeight() * 0.5, 0);
            spawnEffect(pos);
        }
    }

    private void spawnEffect(Vec3d pos) {
        int cnt = (int) count.getValue();
        switch (mode.getCurrentOption()) {
            case "Blood"     -> spawnBlood    (pos, cnt);
            case "Sparks"    -> spawnSparks   (pos, cnt);
            case "Sakura"    -> spawnSakura   (pos, cnt);
            case "Shatter"   -> spawnShatter  (pos, cnt);
            case "Lightning" -> spawnLightning(pos, cnt);
            case "Dragon"    -> spawnDragon   (pos, cnt);
            case "Void"      -> spawnVoid     (pos, cnt);
            default          -> spawnStars    (pos, cnt);
        }
    }

    // ── Оригинальные ─────────────────────────────────────────────────────────

    private void spawnStars(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.4, vy = Math.random()*0.35, vz = (Math.random()-0.5)*0.4;
            mc.world.addParticle(ParticleTypes.CRIT, p.x, p.y, p.z, vx, vy, vz);
        }
        mc.world.addParticle(ParticleTypes.FLASH, p.x, p.y, p.z, 0, 0, 0);
    }

    private void spawnBlood(Vec3d p, int cnt) {
        var red = new DustParticleEffect(enkuronDustColor(0.85f, 0.05f, 0.05f), 1.2f);
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.5, vy = Math.random()*0.4-0.1, vz = (Math.random()-0.5)*0.5;
            mc.world.addParticle(red, p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnSparks(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.6, vy = Math.random()*0.5, vz = (Math.random()-0.5)*0.6;
            mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnSakura(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.3, vy = Math.random()*0.25+0.05, vz = (Math.random()-0.5)*0.3;
            mc.world.addParticle(ParticleTypes.CHERRY_LEAVES, p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnShatter(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.7, vy = Math.random()*0.5, vz = (Math.random()-0.5)*0.7;
            mc.world.addParticle(ParticleTypes.SNOWFLAKE, p.x, p.y, p.z, vx, vy, vz);
        }
        mc.world.addParticle(ParticleTypes.END_ROD, p.x, p.y+0.2, p.z, 0, 0.1, 0);
    }

    // ── LIGHTNING (NEW) ───────────────────────────────────────────────────────
    /**
     * Мгновенная «вспышка» молнии:
     * - Белые/жёлтые пылинки расходятся лучами от точки удара
     * - Несколько Soul Fire Flame (синий) по сторонам
     * - Центральный FLASH + END_ROD
     * Имитирует разряд молнии визуально.
     */
    private void spawnLightning(Vec3d p, int cnt) {
        var white  = new DustParticleEffect(enkuronDustColor(1.0f, 1.0f, 0.9f), 0.8f);
        var yellow = new DustParticleEffect(enkuronDustColor(1.0f, 0.95f, 0.1f), 0.6f);

        // Основная вспышка — лучи во все стороны
        for (int i = 0; i < cnt; i++) {
            double ang = (2 * Math.PI * i) / cnt;
            double spd = 0.3 + Math.random() * 0.3;
            mc.world.addParticle(white, p.x, p.y, p.z, Math.cos(ang)*spd, (Math.random()-0.3)*0.2, Math.sin(ang)*spd);
        }
        // Жёлтые по диагоналям
        for (int i = 0; i < cnt / 2; i++) {
            double ang = Math.random() * Math.PI * 2;
            double spd = 0.15 + Math.random() * 0.2;
            mc.world.addParticle(yellow, p.x, p.y, p.z, Math.cos(ang)*spd, Math.random()*0.4, Math.sin(ang)*spd);
        }
        // Синие по бокам (Soul Fire Flame)
        for (int i = 0; i < 4; i++) {
            double ox = (Math.random()-0.5)*0.4, oz = (Math.random()-0.5)*0.4;
            mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, p.x+ox, p.y, p.z+oz, 0, 0.1, 0);
        }
        // Центр
        mc.world.addParticle(ParticleTypes.FLASH, p.x, p.y, p.z, 0, 0, 0);
        mc.world.addParticle(ParticleTypes.END_ROD, p.x, p.y, p.z, 0, 0.2, 0);
    }

    // ── DRAGON (NEW) ─────────────────────────────────────────────────────────
    /**
     * Дыхание дракона — тёмное фиолетовое облако.
     * - DRAGON_BREATH расходится во все стороны медленно
     * - PORTAL быстро крутится снизу
     * - Тёмно-фиолетовые пылинки (dust)
     * - Финальная частица EXPLOSION_EMITTER
     */
    private void spawnDragon(Vec3d p, int cnt) {
        var purple = new DustParticleEffect(enkuronDustColor(0.5f, 0.0f, 0.7f), 1.5f);
        var dark   = new DustParticleEffect(enkuronDustColor(0.2f, 0.0f, 0.3f), 1.0f);

        // Dragon breath облако
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.25, vy = Math.random()*0.15, vz = (Math.random()-0.5)*0.25;
            mc.world.addParticle(ParticleTypes.DRAGON_BREATH, p.x, p.y, p.z, vx, vy, vz);
        }
        // Portal снизу (воронка)
        for (int i = 0; i < cnt / 2; i++) {
            double ang = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.6;
            mc.world.addParticle(ParticleTypes.PORTAL,
                p.x + Math.cos(ang)*r, p.y - 0.2, p.z + Math.sin(ang)*r,
                -Math.cos(ang)*0.1, 0.05, -Math.sin(ang)*0.1);
        }
        // Пылинки
        for (int i = 0; i < cnt / 2; i++) {
            double vx = (Math.random()-0.5)*0.3, vy = Math.random()*0.2, vz = (Math.random()-0.5)*0.3;
            mc.world.addParticle(i % 2 == 0 ? purple : dark, p.x, p.y, p.z, vx, vy, vz);
        }
        // Финальная вспышка
        mc.world.addParticle(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 0, 0, 0);
    }

    // ── VOID (NEW) ────────────────────────────────────────────────────────────
    /**
     * Поглощение пустотой — частицы летят К точке удара и вниз.
     * - Тёмно-синие / чёрные пылинки с отрицательной скоростью (к центру)
     * - Witch-частицы спиралью вниз
     * - Финальный SONIC_BOOM (если доступен) или FLASH
     * - Несколько WARPED_SPORE разлетаются тихо
     */
    private void spawnVoid(Vec3d p, int cnt) {
        var darkBlue = new DustParticleEffect(enkuronDustColor(0.05f, 0.0f, 0.25f), 1.0f);
        var black    = new DustParticleEffect(enkuronDustColor(0.0f, 0.0f, 0.05f), 0.7f);

        // Частицы летят К центру (отрицательные скорости от периферии)
        for (int i = 0; i < cnt; i++) {
            double ang = (2 * Math.PI * i) / cnt;
            double r   = 0.8 + Math.random() * 0.6;
            double ox  = Math.cos(ang) * r, oz = Math.sin(ang) * r;
            double oy  = (Math.random() - 0.3) * 0.5;
            // Спавним на периферии, скорость — в сторону центра
            mc.world.addParticle(i % 2 == 0 ? darkBlue : black,
                p.x + ox, p.y + oy, p.z + oz,
                -ox * 0.15, -0.05 - Math.random()*0.1, -oz * 0.15);
        }
        // Witch-спираль вниз
        for (int i = 0; i < cnt / 2; i++) {
            double ang = (2 * Math.PI * i) / (cnt / 2.0) + 0.5;
            mc.world.addParticle(ParticleTypes.WITCH,
                p.x + Math.cos(ang)*0.3, p.y + 0.3, p.z + Math.sin(ang)*0.3,
                0, -0.1, 0);
        }
        // Warped spore тихим облаком
        for (int i = 0; i < 5; i++) {
            double ox = (Math.random()-0.5)*0.4, oz = (Math.random()-0.5)*0.4;
            mc.world.addParticle(ParticleTypes.WARPED_SPORE, p.x+ox, p.y, p.z+oz, 0, -0.05, 0);
        }
        // Финальная вспышка
        mc.world.addParticle(ParticleTypes.FLASH, p.x, p.y, p.z, 0, 0, 0);
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
