package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

/**
 * KillCounter — считает убийства за сессию.
 *
 * Детект: следит за сущностями в радиусе.
 * Если сущность была жива → стала мёртвой → прибавляем убийство.
 * Поддержка раздельного счёта: игроки / мобы.
 */
public class KillCounter extends Module {

    private final Setting onlyPlayers = new Setting("Только игроки", false);
    private final Setting showMobs    = new Setting("Показывать мобов", true);
    private final Setting resetOnDeath = new Setting("Сброс при смерти", true);

    private int killsPlayers = 0;
    private int killsMobs    = 0;
    private final Set<Integer> aliveSet = new HashSet<>();

    public KillCounter() {
        super("KillCounter", "Считает убийства за текущую сессию", Category.HUD);
        this.x = 5; this.y = 460;
        addSetting(onlyPlayers);
        addSetting(showMobs);
        addSetting(resetOnDeath);
    }

    @Override
    public void onEnable() {
        killsPlayers = 0;
        killsMobs    = 0;
        aliveSet.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        // Сброс при смерти игрока
        if (resetOnDeath.getState() && mc.player.isDead()) {
            killsPlayers = 0;
            killsMobs    = 0;
            aliveSet.clear();
            return;
        }

        Set<Integer> nowAlive = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le.equals(mc.player)) continue;
            if (!le.isAlive()) continue;
            nowAlive.add(le.getId());
        }

        // Ищем тех, кто был жив в прошлом тике и умер сейчас
        for (int id : aliveSet) {
            if (!nowAlive.contains(id)) {
                // Сущность умерла — ищем её (может вернуть null если уже выгружена)
                Entity died = mc.world.getEntityById(id);
                if (died == null) continue; // FIX: null-check — Entity может быть null
                if (died instanceof PlayerEntity) {
                    killsPlayers++;
                } else if (!onlyPlayers.getState()) {
                    killsMobs++;
                }
            }
        }

        aliveSet.clear();
        aliveSet.addAll(nowAlive);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        boolean showM = showMobs.getState() && !onlyPlayers.getState();
        int boxW = showM ? 120 : 90;
        int boxH = showM ? 30  : 20;
        this.width = boxW; this.height = boxH;

        context.fill(x - 2, y - 2, x + boxW, y + boxH, 0xBB0A0A14);
        context.fill(x - 2, y - 2, x - 1, y + boxH, 0xFFFF4444);

        context.drawText(mc.textRenderer, "§c⚔ Kills", x + 2, y, 0xFFFF6666, true);
        context.drawText(mc.textRenderer, "§fPlayers: §e" + killsPlayers, x + 2, y + 10, 0xFFFFFFFF, false);
        if (showM) {
            context.drawText(mc.textRenderer, "§fMobs: §a" + killsMobs, x + 2, y + 20, 0xFFFFFFFF, false);
        }
    }
}
