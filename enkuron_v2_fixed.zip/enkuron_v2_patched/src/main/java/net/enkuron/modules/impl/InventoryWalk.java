package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

public class InventoryWalk extends Module {
    private final Setting onlyForward = new Setting("Только вперёд", true);

    public InventoryWalk() {
        super("InventoryWalk", "Позволяет ходить с открытым инвентарём", Category.MOVEMENT);
        addSetting(onlyForward);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen == null) return;
        // Работаем только когда открыт инвентарь или контейнер
        boolean isInv = mc.currentScreen instanceof InventoryScreen
                     || mc.currentScreen instanceof GenericContainerScreen;
        if (!isInv) return;

        if (onlyForward.getState()) {
            // Только движение вперёд (W)
            if (mc.options.forwardKey.isPressed()) {
                mc.player.forwardSpeed = 0.98f;
            }
        } else {
            // Полное управление движением при открытом инвентаре
            float forward = mc.options.forwardKey.isPressed()  ? 0.98f :
                            mc.options.backKey.isPressed()     ? -0.98f : 0f;
            float strafe  = mc.options.leftKey.isPressed()     ? 0.98f :
                            mc.options.rightKey.isPressed()    ? -0.98f : 0f;
            mc.player.forwardSpeed = forward;
            mc.player.sidewaysSpeed = strafe;
        }
    }
}
