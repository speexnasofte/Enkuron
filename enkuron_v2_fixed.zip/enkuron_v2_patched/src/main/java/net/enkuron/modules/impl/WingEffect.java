package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * WingEffect — косметические крылья из частиц за спиной.
 *
 * Режимы:
 *   Angel    — пышные ангельские крылья
 *   Butterfly — крылья бабочки (симметричные лопасти)
 *   Demon    — острые демонические крылья
 *   Fairy    — маленькие феерические крылья
 */
public class WingEffect extends Module {

    private static final String[] MODES         = {"Angel", "Butterfly", "Demon", "Fairy"};
    private static final String[] PARTICLE_NAMES = {"End Rod", "Enchant", "Flame", "Soul", "Portal"};

    private final Setting mode      = new Setting("Тип крыльев", MODES,         0);
    private final Setting particles = new Setting("Частицы",     PARTICLE_NAMES, 0);
    private final Setting span      = new Setting("Размах",      1.5, 0.6, 3.0);
    private final Setting flap      = new Setting("Скорость мах",0.12, 0.04, 0.35);

    private int    tick      = 0;
    private double flapPhase = 0;

    public WingEffect() {
        super("WingEffect", "Косметические крылья из частиц", Category.VISUAL);
        addSetting(mode);
        addSetting(particles);
        addSetting(span);
        addSetting(flap);
    }

    @Override public void onEnable()  { tick = 0; flapPhase = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        flapPhase += flap.getValue();

        Vec3d pos  = mc.player.getPos();
        float yaw  = mc.player.getYaw();
        double rad = Math.toRadians(yaw);
        double s   = span.getValue();

        // Центр крыльев — спина игрока
        double bx  = pos.x - Math.sin(rad) * 0.2;
        double bz  = pos.z + Math.cos(rad) * 0.2;
        double by  = pos.y + mc.player.getHeight() * 0.65;

        switch (mode.getCurrentOption()) {
            case "Angel"     -> spawnAngel    (bx, by, bz, rad, s);
            case "Butterfly" -> spawnButterfly(bx, by, bz, rad, s);
            case "Demon"     -> spawnDemon    (bx, by, bz, rad, s);
            case "Fairy"     -> spawnFairy    (bx, by, bz, rad, s);
        }
    }

    /** Ангельские крылья — эллиптические лопасти с взмахом */
    private void spawnAngel(double cx, double cy, double cz, double yaw, double s) {
        double perpX = Math.cos(yaw);
        double perpZ = Math.sin(yaw);
        double flapY = Math.sin(flapPhase) * 0.4;

        for (int side = -1; side <= 1; side += 2) {
            int pts = 18;
            for (int i = 0; i < pts; i++) {
                double t  = (double) i / pts;
                // Эллипс крыла
                double wx = s * side * (0.3 + 0.7 * Math.sin(t * Math.PI));
                double wy = s * 0.7 * Math.sin(t * Math.PI) + flapY * side;
                // Поворот на yaw
                spawnParticle(
                    cx + perpX * wx,
                    cy + wy,
                    cz + perpZ * wx
                );
            }
        }
    }

    /** Крылья бабочки — 4 закруглённые лопасти */
    private void spawnButterfly(double cx, double cy, double cz, double yaw, double s) {
        double perpX = Math.cos(yaw);
        double perpZ = Math.sin(yaw);
        double flapY = Math.sin(flapPhase) * 0.25;

        // Верхние (большие) и нижние (меньшие) лопасти
        double[][] lobes = {
            { 1,  0.6,  0.5},  // правая верхняя
            {-1,  0.6,  0.5},  // левая  верхняя
            { 1, -0.35, 0.35}, // правая нижняя
            {-1, -0.35, 0.35}  // левая  нижняя
        };
        for (double[] lobe : lobes) {
            double sideSign = lobe[0];
            double yOff     = lobe[1] * s;
            double rx       = lobe[2] * s;
            int pts = 14;
            for (int i = 0; i < pts; i++) {
                double a  = Math.PI * i / pts;
                double wx = sideSign * (rx + Math.cos(a) * rx * 0.6);
                double wy = yOff + Math.sin(a) * rx * 0.7 + flapY * sideSign;
                spawnParticle(cx + perpX * wx, cy + wy, cz + perpZ * wx);
            }
        }
    }

    /** Демонические крылья — заострённые треугольники */
    private void spawnDemon(double cx, double cy, double cz, double yaw, double s) {
        double perpX = Math.cos(yaw);
        double perpZ = Math.sin(yaw);
        double flapY = Math.sin(flapPhase * 0.8) * 0.3;

        for (int side = -1; side <= 1; side += 2) {
            // Основное перо крыла
            int pts = 20;
            for (int i = 0; i < pts; i++) {
                double t  = (double) i / pts;
                // Треугольная форма с зазубринами
                double wx = side * s * (0.2 + t * 0.8);
                double wy = s * (0.6 - t * 1.1) + Math.sin(t * Math.PI * 3) * 0.15 + flapY;
                spawnParticle(cx + perpX * wx, cy + wy, cz + perpZ * wx);
            }
            // Маленький шип
            for (int i = 0; i < 6; i++) {
                double t  = (double) i / 6;
                double wx = side * s * (0.5 + t * 0.4);
                double wy = s * (0.05 - t * 0.55) + flapY * 0.5;
                spawnParticle(cx + perpX * wx, cy + wy, cz + perpZ * wx);
            }
        }
    }

    /** Крылья феи — маленькие стрекозиные */
    private void spawnFairy(double cx, double cy, double cz, double yaw, double s) {
        double perpX = Math.cos(yaw);
        double perpZ = Math.sin(yaw);
        double flapY = Math.sin(flapPhase * 1.6) * 0.15;

        double rs = s * 0.55;
        for (int side = -1; side <= 1; side += 2) {
            for (int wing = 0; wing < 2; wing++) {
                double yBase = (wing == 0) ? 0.3 * s : -0.2 * s;
                double rr    = (wing == 0) ? rs : rs * 0.6;
                int pts = 12;
                for (int i = 0; i < pts; i++) {
                    double a  = Math.PI * i / pts;
                    double wx = side * (rr * 0.4 + Math.cos(a) * rr);
                    double wy = yBase + Math.sin(a) * rr * 0.8 + flapY * side;
                    spawnParticle(cx + perpX * wx, cy + wy, cz + perpZ * wx);
                }
            }
        }
    }

    private void spawnParticle(double x, double y, double z) {
        if (mc.world == null) return;
        var p = switch (particles.getCurrentOption()) {
            case "Enchant"  -> ParticleTypes.ENCHANT;
            case "Flame"    -> ParticleTypes.FLAME;
            case "Soul"     -> ParticleTypes.SOUL;
            case "Portal"   -> ParticleTypes.PORTAL;
            default         -> ParticleTypes.END_ROD;
        };
        mc.world.addParticle(p, x, y, z, 0, 0.01, 0);
    }
}
