package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * RainbowTrail — радужный след из частиц за игроком.
 *
 * Режимы:
 *   Rainbow — цикличный RGB-переход
 *   Comet   — хвост кометы (белый → голубой → фиолетовый)
 *   Candy   — яркий конфетный стиль (розовый / желтый / голубой)
 *   Enkuron — фирменные цвета клиента (фиолетовый / синий)
 */
public class RainbowTrail extends Module {

    private static final String[] MODES = {"Rainbow", "Comet", "Candy", "Enkuron"};

    private final Setting mode    = new Setting("Режим",     MODES, 0);
    private final Setting width   = new Setting("Ширина",    0.3, 0.05, 1.0);
    private final Setting length  = new Setting("Плотность", 8.0, 3.0, 20.0);

    private int    tick    = 0;
    private double hue     = 0;   // 0..1 cycling rainbow hue

    public RainbowTrail() {
        super("RainbowTrail", "Радужный цветной след за игроком", Category.VISUAL);
        addSetting(mode);
        addSetting(width);
        addSetting(length);
    }

    @Override public void onEnable() { tick = 0; hue = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 1 != 0) return; // каждый тик для плавности

        hue = (hue + 0.015) % 1.0;

        Vec3d pos = mc.player.getPos();
        double x  = pos.x;
        double y  = pos.y + 0.1;
        double z  = pos.z;

        int cnt = (int) length.getValue();
        double w = width.getValue();

        for (int i = 0; i < cnt; i++) {
            double t   = (double) i / cnt;
            double ox  = (Math.random() - 0.5) * w;
            double oz  = (Math.random() - 0.5) * w;
            float[] rgb = getColor(mode.getCurrentOption(), (hue + t * 0.3) % 1.0, i);
            spawnDust(x + ox, y, z + oz, rgb[0], rgb[1], rgb[2]);
        }
    }

    private float[] getColor(String m, double h, int idx) {
        return switch (m) {
            case "Comet"   -> cometColor(h);
            case "Candy"   -> candyColor(idx);
            case "Enkuron" -> enkuronColor(h);
            default        -> hsvToRgb((float) h, 1f, 1f);
        };
    }

    private float[] hsvToRgb(float h, float s, float v) {
        int i = (int)(h * 6);
        float f = h * 6 - i;
        float p = v * (1 - s);
        float q = v * (1 - f * s);
        float t = v * (1 - (1 - f) * s);
        return switch (i % 6) {
            case 0 -> new float[]{v, t, p};
            case 1 -> new float[]{q, v, p};
            case 2 -> new float[]{p, v, t};
            case 3 -> new float[]{p, q, v};
            case 4 -> new float[]{t, p, v};
            default -> new float[]{v, p, q};
        };
    }

    private float[] cometColor(double h) {
        // Белый → голубой → синий → фиолетовый
        float t = (float) h;
        return new float[]{
            1f - t * 0.6f,
            1f - t * 0.4f,
            1f
        };
    }

    private float[] candyColor(int idx) {
        return switch (idx % 3) {
            case 0 -> new float[]{1f, 0.4f, 0.8f};  // розовый
            case 1 -> new float[]{1f, 0.95f, 0.3f}; // желтый
            default -> new float[]{0.35f, 0.85f, 1f}; // голубой
        };
    }

    private float[] enkuronColor(double h) {
        // Фиолетовый ↔ синий (фирменный стиль enkuron)
        float t = (float) h;
        return new float[]{
            0.4f + t * 0.2f,
            0.1f,
            1f - t * 0.3f
        };
    }

    private void spawnDust(double x, double y, double z, float r, float g, float b) {
        if (mc.world == null) return;
        var dust = new DustParticleEffect(enkuronDustColor(r, g, b), 1.0f);
        mc.world.addParticle(dust, x, y, z, 0, 0, 0);
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
