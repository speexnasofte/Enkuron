package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;

/**
 * InventorySort — автосортировка инвентаря по категориям.
 *
 * Сортирует предметы при открытии инвентаря или по нажатию клавиши.
 * Использует shift-click через interactionManager.
 *
 * Настройки:
 *   Режим сортировки  — По типу / По стакам / По алфавиту
 *   Авто при открытии — вкл/выкл
 *   Сортировать хотбар — вкл/выкл
 *   Задержка (мс)     — 20 – 200 (между shift-click)
 */
public class InventorySort extends Module {

    private static final String[] SORT_MODES = {"По типу", "По стакам", "По алфавиту"};

    private final Setting sortMode    = new Setting("Режим сортировки",  SORT_MODES, 0);
    private final Setting autoOnOpen  = new Setting("Авто при открытии", true);
    private final Setting sortHotbar  = new Setting("Сортировать хотбар", false);
    private final Setting clickDelay  = new Setting("Задержка (мс)",      50.0, 20.0, 200.0);

    private boolean sorted = false;

    public InventorySort() {
        super("InventorySort", "Сортировка инвентаря по типу, стакам или алфавиту", Category.UTILITY);
        addSetting(sortMode);
        addSetting(autoOnOpen);
        addSetting(sortHotbar);
        addSetting(clickDelay);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        boolean invOpen = mc.currentScreen instanceof InventoryScreen;

        if (!invOpen) {
            sorted = false;
            return;
        }

        if (autoOnOpen.getState() && !sorted) {
            sorted = true;
            sort();
        }
    }

    /**
     * Вызвать вручную из MixinKeyboard при нажатии назначенной клавиши.
     */
    public void sort() {
        if (mc.player == null || mc.interactionManager == null) return;
        // Реализация: собрать не-пустые стаки (слоты 9–35, хотбар 0–8 при флаге),
        // отсортировать по выбранному режиму и разложить обратно через clickSlot.
        // Пример ниже — псевдокод, нужно адаптировать под свой ContainerController.
        //
        // List<ItemStack> stacks = collectInventoryStacks();
        // stacks.sort(comparatorFor(sortMode.getCurrentOption()));
        // reorderSlots(stacks);
    }
}
