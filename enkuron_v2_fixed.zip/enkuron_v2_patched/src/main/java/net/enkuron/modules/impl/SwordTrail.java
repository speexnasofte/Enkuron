package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.SwordItem;
import net.minecraft.item.AxeItem;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * SwordTrail — светящийся след за оружием при атаке/движении.
 *
 * Режимы:
 *   Flame   — огненный след
 *   Ice     — ледяной синий
 *   Purple  — фиолетовый магический
 *   Rainbow — радужный
 *   Blood   — кровавый красный
 *
 * Работает только когда в руке меч или топор.
 */
public class SwordTrail extends Module {

    private static final String[] MODES   = {"Flame", "Ice", "Purple", "Rainbow", "Blood"};
    private static final String[] LENGTHS = {"Short", "Medium", "Long"};

    private final Setting mode   = new Setting("Режим",  MODES,   2);
    private final Setting length = new Setting("Длина",  LENGTHS, 1);

    private int    tick     = 0;
    private double hue      = 0;
    private Vec3d  lastPos  = null;

    public SwordTrail() {
        super("SwordTrail", "Светящийся след за оружием при атаке", Category.VISUAL);
        addSetting(mode);
        addSetting(length);
    }

    @Override public void onEnable() { tick = 0; hue = 0; lastPos = null; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        // Только если в руке меч или топор
        var held = mc.player.getMainHandStack();
        if (!(held.getItem() instanceof SwordItem) &&
            !(held.getItem() instanceof AxeItem)) return;

        tick++;
        hue = (hue + 0.04) % 1.0;

        Vec3d pos = mc.player.getPos().add(0, mc.player.getHeight() * 0.6, 0);

        int cnt = switch (length.getCurrentOption()) {
            case "Long"  -> 8;
            case "Short" -> 3;
            default      -> 5;
        };

        // Если есть предыдущая позиция — интерполируем след
        if (lastPos != null) {
            for (int i = 0; i < cnt; i++) {
                double t  = (double) i / cnt;
                double lx = lastPos.x + (pos.x - lastPos.x) * t;
                double ly = lastPos.y + (pos.y - lastPos.y) * t;
                double lz = lastPos.z + (pos.z - lastPos.z) * t;
                double ox = (Math.random() - 0.5) * 0.15;
                double oy = (Math.random() - 0.5) * 0.15;
                double oz = (Math.random() - 0.5) * 0.15;
                spawnAt(lx + ox, ly + oy, lz + oz);
            }
        }

        lastPos = pos;
    }

    private void spawnAt(double x, double y, double z) {
        if (mc.world == null) return;
        switch (mode.getCurrentOption()) {
            case "Flame"   -> mc.world.addParticle(ParticleTypes.FLAME,    x, y, z, 0, 0.02, 0);
            case "Ice"     -> mc.world.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0, 0.01, 0);
            case "Blood"   -> mc.world.addParticle(
                new DustParticleEffect(enkuronDustColor(0.8f, 0.05f, 0.05f), 1f), x, y, z, 0, 0, 0);
            case "Purple"  -> mc.world.addParticle(
                new DustParticleEffect(enkuronDustColor(0.6f, 0.1f, 1f), 1f),     x, y, z, 0, 0, 0);
            case "Rainbow" -> {
                float[] rgb = hsvToRgb((float) hue, 1f, 1f);
                mc.world.addParticle(
                    new DustParticleEffect(enkuronDustColor(rgb[0], rgb[1], rgb[2]), 1f), x, y, z, 0, 0, 0);
            }
        }
    }

    private float[] hsvToRgb(float h, float s, float v) {
        int i = (int)(h * 6); float f = h * 6 - i;
        float p = v*(1-s), q = v*(1-f*s), t = v*(1-(1-f)*s);
        return switch (i % 6) {
            case 0 -> new float[]{v,t,p}; case 1 -> new float[]{q,v,p};
            case 2 -> new float[]{p,v,t}; case 3 -> new float[]{p,q,v};
            case 4 -> new float[]{t,p,v}; default -> new float[]{v,p,q};
        };
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
