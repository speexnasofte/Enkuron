package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * SneakToggle — режим постоянного снизания (крадущегося хода) с умными исключениями.
 *
 * Отличие от ванильного Sneak: не прерывается при открытии инвентаря,
 * можно задать автоотключение при беге или низком HP.
 *
 * Настройки:
 *   Отключать при спринте — вкл/выкл
 *   Отключать при низком HP — вкл/выкл
 *   Порог HP (%)          — 20 – 70
 *   Тихий шаг            — вкл (совместимость с SafeWalk)
 */
public class SneakToggle extends Module {

    private final Setting disableOnSprint = new Setting("Откл. при спринте",      true);
    private final Setting disableOnLowHp  = new Setting("Откл. при низком HP",    false);
    private final Setting hpThreshold     = new Setting("Порог HP (%)",           30.0, 20.0, 70.0);
    private final Setting silentStep      = new Setting("Тихий шаг",              true);

    public SneakToggle() {
        super("SneakToggle", "Постоянное крадение с авто-отключением при спринте или низком HP", Category.MOVEMENT);
        addSetting(disableOnSprint);
        addSetting(disableOnLowHp);
        addSetting(hpThreshold);
        addSetting(silentStep);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        boolean shouldSneak = true;

        if (disableOnSprint.getState() && mc.player.isSprinting()) {
            shouldSneak = false;
        }

        if (disableOnLowHp.getState()) {
            float hpPercent = (mc.player.getHealth() / mc.player.getMaxHealth()) * 100f;
            if (hpPercent <= hpThreshold.getValue()) shouldSneak = false;
        }

        mc.options.sneakKey.setPressed(shouldSneak);
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.sneakKey.setPressed(false);
        }
    }
}
