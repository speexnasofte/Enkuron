package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * HitParticles v2 — расширенные типы + показ урона числом.
 *
 * Определяет хит по изменению HP цели под прицелом.
 *
 * Типы частиц:
 *   Crit / Heart / Enchant / Flame / Portal / Explosion
 *   Snowflake — NEW: ледяные осколки (SNOWFLAKE)
 *   Toxic     — NEW: зелёные ядовитые пузыри (SLIME + dust)
 *   Soul      — NEW: синие souls-частицы (SOUL + SOUL_FIRE_FLAME)
 *
 * Новые опции:
 *   Показ урона — отображение плавающего числа урона (§c-X.X) над целью
 *   Цвет по урону — зелёный <3, жёлтый 3-6, красный >6
 */
public class HitParticles extends Module {

    private static final String[] TYPES = {
        "Crit", "Heart", "Enchant", "Flame", "Portal", "Explosion",
        "Snowflake", "Toxic", "Soul"
    };

    private final Setting ptype      = new Setting("Тип частиц",   TYPES, 0);
    private final Setting count      = new Setting("Количество",   8.0, 3.0, 20.0);
    private final Setting spread     = new Setting("Разброс",      0.3, 0.1, 1.0);
    private final Setting showDamage = new Setting("Показ урона",  true);
    private final Setting colorDmg   = new Setting("Цвет по урону",true);

    private float lastHealth = -1;
    private LivingEntity lastTarget = null;

    // Плавающее число урона
    private record DamageLabel(float damage, Vec3d pos, int life) {}
    private final java.util.List<DamageLabel> labels = new java.util.ArrayList<>();

    public HitParticles() {
        super("HitParticles", "Кастомные частицы + показ урона при ударе по существу", Category.VISUAL);
        addSetting(ptype); addSetting(count); addSetting(spread);
        addSetting(showDamage); addSetting(colorDmg);
    }

    @Override public void onEnable()  { lastHealth = -1; lastTarget = null; labels.clear(); }
    @Override public void onDisable() { lastHealth = -1; lastTarget = null; labels.clear(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        // Удаляем устаревшие лейблы
        labels.removeIf(l -> l.life() <= 0);
        // Декрементируем жизнь (через новый record нельзя мутировать, используем List.replaceAll)
        labels.replaceAll(l -> new DamageLabel(l.damage(), l.pos().add(0, 0.015, 0), l.life() - 1));

        if (!(mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult hit)) {
            lastHealth = -1; lastTarget = null; return;
        }
        if (!(hit.getEntity() instanceof LivingEntity target)) {
            lastHealth = -1; lastTarget = null; return;
        }

        float hp = target.getHealth();

        if (lastTarget == target && lastHealth > 0 && hp < lastHealth) {
            float damage = lastHealth - hp;
            spawnParticles(target);
            if (showDamage.getState()) {
                Vec3d labelPos = target.getPos().add(
                    (Math.random()-0.5)*0.3,
                    target.getHeight() + 0.4,
                    (Math.random()-0.5)*0.3
                );
                labels.add(new DamageLabel(damage, labelPos, 40)); // 40 тиков ≈ 2 сек
            }
        }

        lastTarget = target;
        lastHealth = hp;
    }

    @Override
    public void render(net.minecraft.client.gui.DrawContext context) {
        // Лейблы рендерим в мировом пространстве через mc.inGameHud, но у нас нет доступа к WorldRenderer.
        // Используем альтернативу: отображаем в HUD как накладку (упрощённо).
        // Для full-3D текста нужен mixin; здесь показываем в 2D-оверлее у нижнего края экрана
        // как «последний урон» — просто, без лагов.
        if (!isEnabled() || !showDamage.getState() || labels.isEmpty()) return;

        DamageLabel latest = labels.get(labels.size() - 1);
        float alpha = Math.min(1f, latest.life() / 20f);
        int a = (int)(alpha * 255);

        String dmgStr = String.format("-%.1f", latest.damage());
        int col = 0xFF << 24;
        if (colorDmg.getState()) {
            float d = latest.damage();
            col = d < 3f ? (a << 24 | 0x44EE77) : d < 6f ? (a << 24 | 0xFFAA22) : (a << 24 | 0xEE3333);
        } else {
            col = (a << 24 | 0xFFFFFF);
        }

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int tw = mc.textRenderer.getWidth(dmgStr);
        int tx = sw / 2 - tw / 2;
        int ty = sh / 2 + 18 + (int)((1f - alpha) * 12); // уплывает вниз
        context.drawText(mc.textRenderer, "§l" + dmgStr, tx, ty, col, true);
    }

    private void spawnParticles(LivingEntity target) {
        if (mc.world == null) return;
        Vec3d pos = target.getPos().add(0, target.getHeight() / 2.0, 0);
        int n = (int) count.getValue();
        double s = spread.getValue();

        switch (ptype.getCurrentOption()) {
            case "Heart"     -> spawnType(pos, n, s, ParticleTypes.HEART);
            case "Enchant"   -> spawnType(pos, n, s, ParticleTypes.ENCHANT);
            case "Flame"     -> spawnType(pos, n, s, ParticleTypes.FLAME);
            case "Portal"    -> spawnType(pos, n, s, ParticleTypes.PORTAL);
            case "Explosion" -> spawnType(pos, n, s, ParticleTypes.EXPLOSION);
            case "Snowflake" -> spawnSnowflake(pos, n, s);
            case "Toxic"     -> spawnToxic    (pos, n, s);
            case "Soul"      -> spawnSoul     (pos, n, s);
            default          -> spawnType(pos, n, s, ParticleTypes.CRIT);
        }
    }

    private void spawnType(Vec3d pos, int n, double s,
                           net.minecraft.particle.ParticleEffect type) {
        for (int i = 0; i < n; i++) {
            double vx = (Math.random()-0.5)*s, vy = Math.random()*s, vz = (Math.random()-0.5)*s;
            mc.world.addParticle(type, pos.x, pos.y, pos.z, vx, vy, vz);
        }
    }

    // ── SNOWFLAKE (NEW) ───────────────────────────────────────────────────────
    /**
     * Ледяные осколки: SNOWFLAKE быстро разлетаются, белые пылинки + END_ROD.
     */
    private void spawnSnowflake(Vec3d p, int n, double s) {
        var white = new DustParticleEffect(enkuronDustColor(0.9f, 0.95f, 1.0f), 0.6f);
        for (int i = 0; i < n; i++) {
            double vx = (Math.random()-0.5)*s*1.5, vy = Math.random()*s*0.6, vz = (Math.random()-0.5)*s*1.5;
            mc.world.addParticle(ParticleTypes.SNOWFLAKE, p.x, p.y, p.z, vx, vy, vz);
            if (i % 3 == 0) mc.world.addParticle(white, p.x, p.y, p.z, vx*0.5, vy*0.5, vz*0.5);
        }
        mc.world.addParticle(ParticleTypes.END_ROD, p.x, p.y+0.1, p.z, 0, 0.08, 0);
    }

    // ── TOXIC (NEW) ───────────────────────────────────────────────────────────
    /**
     * Ядовитые пузыри: зелёные и кислотно-жёлтые пылинки + SLIME + SPORE_BLOSSOM_AIR.
     */
    private void spawnToxic(Vec3d p, int n, double s) {
        var green = new DustParticleEffect(enkuronDustColor(0.1f, 0.9f, 0.15f), 1.0f);
        var acid  = new DustParticleEffect(enkuronDustColor(0.7f, 1.0f, 0.0f), 0.8f);
        for (int i = 0; i < n; i++) {
            double vx = (Math.random()-0.5)*s, vy = Math.random()*s*0.5+0.05, vz = (Math.random()-0.5)*s;
            mc.world.addParticle(i % 2 == 0 ? green : acid, p.x, p.y, p.z, vx, vy, vz);
            if (i % 4 == 0) mc.world.addParticle(ParticleTypes.ITEM_SLIME, p.x, p.y, p.z, vx, vy, vz);
        }
        mc.world.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, p.x, p.y+0.2, p.z, 0, 0.05, 0);
    }

    // ── SOUL (NEW) ────────────────────────────────────────────────────────────
    /**
     * Синие Souls-частицы: SOUL поднимаются вверх, SOUL_FIRE_FLAME по бокам,
     * светло-синие пылинки.
     */
    private void spawnSoul(Vec3d p, int n, double s) {
        var lightBlue = new DustParticleEffect(enkuronDustColor(0.3f, 0.6f, 1.0f), 0.8f);
        for (int i = 0; i < n; i++) {
            double vx = (Math.random()-0.5)*s*0.6, vy = 0.1+Math.random()*0.2, vz = (Math.random()-0.5)*s*0.6;
            mc.world.addParticle(ParticleTypes.SOUL, p.x, p.y, p.z, vx, vy, vz);
            if (i % 2 == 0) {
                double ox = (Math.random()-0.5)*0.3, oz = (Math.random()-0.5)*0.3;
                mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, p.x+ox, p.y, p.z+oz, 0, 0.06, 0);
            }
        }
        for (int i = 0; i < n/2; i++) {
            double vx = (Math.random()-0.5)*s, vy = Math.random()*s*0.4, vz = (Math.random()-0.5)*s;
            mc.world.addParticle(lightBlue, p.x, p.y, p.z, vx, vy, vz);
        }
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
