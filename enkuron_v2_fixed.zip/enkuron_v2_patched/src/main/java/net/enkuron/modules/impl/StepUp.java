package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.util.Identifier;

/**
 * StepUp — заходит на блоки без прыжка.
 * В 1.21.4 высота шага управляется через атрибут EntityAttributes.STEP_HEIGHT.
 */
public class StepUp extends Module {

    private static final Identifier MODIFIER_ID = Identifier.of("enkuron", "step_height");

    private final Setting stepHeight = new Setting("Высота шага", 1.0, 0.6, 2.0);
    private final Setting onlySprint = new Setting("Только спринт", false);

    public StepUp() {
        super("StepUp", "Заходит на блоки без прыжка", Category.MOVEMENT);
        addSetting(stepHeight);
        addSetting(onlySprint);
    }

    @Override
    public void onEnable() {
        applyStep();
    }

    @Override
    public void onDisable() {
        removeModifier();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        // FIX: проверяем есть ли модификатор прежде чем что-то менять,
        // избегаем лишних вызовов каждый тик
        var instance = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (instance == null) return;
        boolean hasModifier = instance.getModifier(MODIFIER_ID) != null;

        if (onlySprint.getState() && !mc.player.isSprinting()) {
            if (hasModifier) removeModifier();
        } else {
            // Перерасчёт только если модификатор не установлен или значение изменилось
            if (!hasModifier) applyStep();
        }
    }

    private void applyStep() {
        if (mc.player == null) return;
        var instance = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (instance == null) return;
        removeModifier();
        double bonus = stepHeight.getValue() - 0.6;
        instance.addPersistentModifier(new EntityAttributeModifier(
            MODIFIER_ID, bonus, EntityAttributeModifier.Operation.ADD_VALUE
        ));
    }

    private void removeModifier() {
        if (mc.player == null) return;
        var instance = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (instance != null) instance.removeModifier(MODIFIER_ID);
    }
}
