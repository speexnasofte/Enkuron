package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * ComboTracker v7 — ФИКС: combo++ срабатывал каждый тик зажатия ЛКМ, а не на удар.
 * Теперь используется edge-detect (justPressed), сброс при смерти, настройка minShow.
 */
public class ComboTracker extends Module {

    private static final String[] STYLES = {"Classic", "Flame", "Street"};

    private final Setting style   = new Setting("Стиль",        STYLES, 1);
    private final Setting timeout = new Setting("Сброс (тики)", 40.0, 10.0, 120.0);
    private final Setting minShow = new Setting("Показывать от", 2.0,  1.0,  5.0);

    private int     combo            = 0;
    private int     ticksSince       = 0;
    private String  lastTarget       = "";
    private boolean wasAttackPressed = false; // FIX: edge-detect

    public ComboTracker() {
        super("ComboTracker", "Счётчик комбо-ударов по цели", Category.HUD);
        this.x = 10; this.y = 200;
        addSetting(style);
        addSetting(timeout);
        addSetting(minShow);
    }

    @Override
    public void onEnable() {
        combo = 0; lastTarget = ""; ticksSince = 0; wasAttackPressed = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.isDead()) { combo = 0; lastTarget = ""; return; }

        String cur = "";
        if (mc.crosshairTarget instanceof EntityHitResult hit &&
                hit.getEntity() instanceof LivingEntity le) {
            cur = le.getUuid().toString();
        }

        ticksSince++;
        if (ticksSince > (int) timeout.getValue()) { combo = 0; lastTarget = ""; }

        boolean attackNow  = mc.options.attackKey.isPressed();
        boolean justPressed = attackNow && !wasAttackPressed;
        wasAttackPressed   = attackNow;

        if (justPressed && mc.crosshairTarget instanceof EntityHitResult hit2 &&
                hit2.getEntity() instanceof LivingEntity) {
            if (!cur.equals(lastTarget)) combo = 0;
            combo++;
            lastTarget = cur;
            ticksSince = 0;
        }
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || combo < (int) minShow.getValue()) return;
        switch (style.getCurrentOption()) {
            case "Flame"  -> renderFlame(ctx);
            case "Street" -> renderStreet(ctx);
            default       -> renderClassic(ctx);
        }
    }

    private void renderClassic(DrawContext ctx) {
        String txt = "Combo: " + combo;
        int w = mc.textRenderer.getWidth(txt) + 8;
        ctx.fill(x-2, y-2, x+w, y+12, 0xBB111116);
        ctx.drawText(mc.textRenderer, txt, x+2, y, comboColor(), true);
        this.width = w; this.height = 12;
    }

    private void renderFlame(DrawContext ctx) {
        String num = String.valueOf(combo); String label = " HIT";
        int nw = mc.textRenderer.getWidth("§l" + num);
        int w  = nw + mc.textRenderer.getWidth(label) + 14;
        ctx.fill(x-2, y-2, x+w, y+14, 0xCC0A0A0A);
        ctx.fill(x-2, y-2, x+w, y-1,  comboColor());
        ctx.drawText(mc.textRenderer, "§l" + num, x+4,    y+1, comboColor(), true);
        ctx.drawText(mc.textRenderer, label,       x+4+nw, y+1, 0xFFCCCCCC, false);
        this.width = w; this.height = 14;
    }

    private void renderStreet(DrawContext ctx) {
        String txt = "×" + combo;
        String sub = combo >= 10 ? "INSANE!" : combo >= 5 ? "GREAT!" : "COMBO";
        int tw = mc.textRenderer.getWidth("§l" + txt); int sw = mc.textRenderer.getWidth(sub);
        int w  = Math.max(tw, sw) + 10;
        ctx.fill(x-2, y-2, x+w, y+24, 0xCC050510);
        ctx.drawText(mc.textRenderer, "§l" + txt, x+(w-tw)/2, y+2,  comboColor(), true);
        ctx.drawText(mc.textRenderer, sub,         x+(w-sw)/2, y+14, 0xFFFFFFAA, false);
        this.width = w; this.height = 24;
    }

    private int comboColor() {
        if (combo >= 15) return 0xFFFF4444;
        if (combo >= 10) return 0xFFFF8800;
        if (combo >=  5) return 0xFFFFDD00;
        return 0xFF44EEBB;
    }
}
