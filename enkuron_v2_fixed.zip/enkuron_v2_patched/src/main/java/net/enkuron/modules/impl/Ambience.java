package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * Ambience — изменяет время суток визуально для клиента.
 *
 * Режимы:
 *   Ambient — по умолчанию (6000 = полдень)
 *   Sunset  — закатное освещение (12000)
 *   Night   — ночь (18000)
 */
public class Ambience extends Module {
    private static final String[] MODES = {"Ambient", "Sunset", "Night"};
    private final Setting mode = new Setting("Режим", MODES, 0);

    private long savedTime = -1;

    public Ambience() {
        super("Ambience", "Изменяет время суток визуально", Category.VISUAL);
        addSetting(mode);
    }

    @Override
    public void onEnable() {
        if (mc.world != null) savedTime = mc.world.getTimeOfDay();
    }

    @Override
    public void onDisable() {
        savedTime = -1;
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        long targetTime = switch (mode.getCurrentOption()) {
            case "Sunset" -> 12000L;
            case "Night"  -> 18000L;
            default       -> 6000L; // Ambient = полдень
        };
        // Клиентская установка времени (Fabric 1.21.4)
        mc.world.setTimeOfDay(targetTime);
    }
}
