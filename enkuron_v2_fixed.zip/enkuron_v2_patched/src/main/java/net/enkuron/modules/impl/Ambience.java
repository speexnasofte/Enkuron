package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * Ambience — визуальный эффект времени суток.
 * setTimeOfDay недоступен на клиенте в 1.21.4, поэтому модуль
 * оставлен как заглушка (функционал отключён).
 */
public class Ambience extends Module {
    private static final String[] MODES = {"Ambient", "Sunset", "Night"};
    private final Setting mode = new Setting("Режим", MODES, 0);

    public Ambience() {
        super("Ambience", "Изменяет время суток визуально", Category.VISUAL);
        addSetting(mode);
    }

    @Override public void onEnable()  {}
    @Override public void onDisable() {}
    @Override public void onTick()    {
        // setTimeOfDay недоступен на клиенте в Fabric 1.21.4
    }
}
