package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * CrownAura — корона из частиц над головой игрока.
 *
 * Режимы:
 *   Classic — пятиконечная корона
 *   Halo    — светящийся нимб
 *   Galaxy  — вращающееся кольцо созвездий
 *   Lotus   — распускающийся цветок лотоса
 */
public class CrownAura extends Module {

    private static final String[] MODES         = {"Classic", "Halo", "Galaxy", "Lotus"};
    private static final String[] PARTICLE_NAMES = {"End Rod", "Enchant", "Soul Fire", "Portal", "Glow"};

    private final Setting mode      = new Setting("Форма",   MODES,         0);
    private final Setting particles = new Setting("Частицы", PARTICLE_NAMES, 0);
    private final Setting radius    = new Setting("Радиус",  0.55, 0.2, 1.2);
    private final Setting spin      = new Setting("Скорость вращения", 0.08, 0.01, 0.3);

    private double angle = 0;
    private int    tick  = 0;

    public CrownAura() {
        super("CrownAura", "Корона из частиц над головой", Category.VISUAL);
        addSetting(mode);
        addSetting(particles);
        addSetting(radius);
        addSetting(spin);
    }

    @Override public void onEnable() { angle = 0; tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        angle += spin.getValue();

        Vec3d pos = mc.player.getPos();
        double cx = pos.x;
        double cy = pos.y + mc.player.getHeight() + 0.25;
        double cz = pos.z;
        double r  = radius.getValue();

        switch (mode.getCurrentOption()) {
            case "Classic" -> spawnClassic(cx, cy, cz, r);
            case "Halo"    -> spawnHalo   (cx, cy, cz, r);
            case "Galaxy"  -> spawnGalaxy (cx, cy, cz, r);
            case "Lotus"   -> spawnLotus  (cx, cy, cz, r);
        }
    }

    /** Пятиконечная корона — острые шипы чередуются с низкими дугами */
    private void spawnClassic(double cx, double cy, double cz, double r) {
        int pts = 5;
        for (int i = 0; i < pts; i++) {
            double a = angle + (2 * Math.PI * i) / pts;
            // Кончик шипа
            spawnParticle(cx + Math.cos(a) * r, cy + 0.35, cz + Math.sin(a) * r);
            // Основание (дуга)
            double a2 = a + Math.PI / pts;
            spawnParticle(cx + Math.cos(a2) * r * 0.75, cy, cz + Math.sin(a2) * r * 0.75);
        }
        // Ободок
        int rim = 20;
        for (int i = 0; i < rim; i++) {
            double a = angle + (2 * Math.PI * i) / rim;
            spawnParticle(cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r);
        }
    }

    /** Нимб — тонкое кольцо, слегка наклонённое */
    private void spawnHalo(double cx, double cy, double cz, double r) {
        int pts = 28;
        for (int i = 0; i < pts; i++) {
            double a   = angle + (2 * Math.PI * i) / pts;
            double tilt = Math.sin(a) * 0.12; // небольшой наклон
            spawnParticle(cx + Math.cos(a) * r, cy + tilt, cz + Math.sin(a) * r);
        }
    }

    /** Галактика — двойная спираль вокруг головы */
    private void spawnGalaxy(double cx, double cy, double cz, double r) {
        int pts = 24;
        for (int arm = 0; arm < 2; arm++) {
            double armOff = arm * Math.PI;
            for (int i = 0; i < pts; i++) {
                double t   = (double) i / pts;
                double a   = angle + armOff + t * Math.PI * 3;
                double rr  = r * (0.3 + 0.7 * t);
                double vy  = Math.sin(a * 0.5) * 0.15;
                spawnParticle(cx + Math.cos(a) * rr, cy + vy, cz + Math.sin(a) * rr);
            }
        }
    }

    /** Лотос — лепестки раскрываются по кругу */
    private void spawnLotus(double cx, double cy, double cz, double r) {
        int petals = 8;
        for (int p = 0; p < petals; p++) {
            double baseA = angle + (2 * Math.PI * p) / petals;
            int pts = 8;
            for (int i = 0; i < pts; i++) {
                double t  = (double) i / (pts - 1); // 0..1
                double a  = baseA + (t - 0.5) * 0.6;
                double rr = r * Math.sin(t * Math.PI); // лепесток
                double vy = rr * 0.35;
                spawnParticle(cx + Math.cos(a) * rr, cy + vy, cz + Math.sin(a) * rr);
            }
        }
    }

    private void spawnParticle(double x, double y, double z) {
        if (mc.world == null) return;
        var p = switch (particles.getCurrentOption()) {
            case "Enchant"    -> ParticleTypes.ENCHANT;
            case "Soul Fire"  -> ParticleTypes.SOUL_FIRE_FLAME;
            case "Portal"     -> ParticleTypes.PORTAL;
            case "Glow"       -> ParticleTypes.GLOW;
            default           -> ParticleTypes.END_ROD;
        };
        mc.world.addParticle(p, x, y, z, 0, 0.01, 0);
    }
}
