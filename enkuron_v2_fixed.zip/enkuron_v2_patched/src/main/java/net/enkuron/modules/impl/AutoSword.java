package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.*;
import net.minecraft.util.hit.EntityHitResult;

/**
 * AutoSword — при атаке автоматически переключается на лучшее оружие в хотбаре.
 * Оценивает урон по attack damage компоненту.
 *
 * Настройки:
 *   Только мечи      — учитывать только мечи/топоры/трезубцы
 *   Авто-возврат     — возвращать слот после удара
 *   Задержка (тики)  — 1–5 тиков задержки переключения
 */
public class AutoSword extends Module {

    private final Setting swordOnly   = new Setting("Только мечи/топоры", true);
    private final Setting autoReturn  = new Setting("Авто-возврат слота", true);
    private final Setting delay       = new Setting("Задержка (тики)", 1.0, 1.0, 5.0);

    private int savedSlot   = -1;
    private boolean switched = false;
    private int returnTimer  = 0;

    public AutoSword() {
        super("AutoSword", "Переключается на лучшее оружие при атаке", Category.COMBAT);
        addSetting(swordOnly);
        addSetting(autoReturn);
        addSetting(delay);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        // Если нажата атака и смотрим на моба
        boolean attacking = mc.options.attackKey.isPressed()
                && mc.crosshairTarget instanceof EntityHitResult;

        if (attacking && !switched) {
            int best = findBestWeapon();
            if (best != -1 && best != mc.player.getInventory().selectedSlot) {
                savedSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = best;
                switched = true;
                returnTimer = (int) delay.getValue() + 5;
            }
        }

        if (switched && autoReturn.getState()) {
            returnTimer--;
            if (returnTimer <= 0 && !mc.options.attackKey.isPressed()) {
                restoreSlot();
            }
        }
    }

    private int findBestWeapon() {
        if (mc.player == null) return -1;
        int bestSlot = -1;
        float bestDmg = 0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            Item item = stack.getItem();

            if (swordOnly.getState()) {
                boolean isWeapon = item instanceof SwordItem
                        || item instanceof AxeItem
                        || item instanceof TridentItem;
                if (!isWeapon) continue;
            }

            float dmg = stack.getItem() instanceof SwordItem s
                    ? 4f // базовый урон меча
                    : stack.getItem() instanceof AxeItem
                    ? 5f : 1f;

            if (dmg > bestDmg) { bestDmg = dmg; bestSlot = i; }
        }
        return bestSlot;
    }

    private void restoreSlot() {
        if (savedSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
        }
        savedSlot = -1;
        switched = false;
    }

    @Override
    public void onDisable() {
        if (switched) restoreSlot();
    }
}
