package net.enkuron.modules;

import net.enkuron.modules.impl.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ModuleManager v2 — регистрирует и управляет всеми модулями.
 *
 * Категории:
 *   COMBAT   — боевые (AutoTotem, AutoShield, AutoSword, AutoGapple...)
 *   MOVEMENT — движение (Sprint, NoFall, SafeWalk, StepUp, AutoSprint...)
 *   VISUAL   — визуальные (Brightness, Zoom, GlowESP, Tracers, HitParticles...)
 *   PLAYER   — игрок (AutoArmor, AutoEat, AntiAFK, AntiPoison...)
 *   HUD      — интерфейс (Keystrokes, ArmorHUD, CpsCounter, FPSDisplay, Minimap...)
 *   UTILITY  — утилиты (AutoTool, FastPlace, AutoFish, ChestStealer, BetterChat...)
 *   MISC     — разное (InventorySort, ChatLogger, ThemeSelector...)
 */
public class ModuleManager {

    private static final List<Module> modules = new ArrayList<>();
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static void init() {
        // ── COMBAT ───────────────────────────────────────────────────────────
        register(new AutoTotem());      // Авто-тотем бессмертия в оффхенд
        register(new AutoShield());     // Авто-блок щитом при атаке
        register(new AutoSword());      // Авто-переключение на меч
        register(new AutoGapple());     // Авто-использование золотого яблока
        register(new AutoPotion());     // Авто-использование зелий

        // ── MOVEMENT ─────────────────────────────────────────────────────────
        register(new Sprint());         // Авто-бег
        register(new AutoSprint());     // Умный авто-бег (только вперёд)
        register(new NoFall());         // Защита от урона при падении
        register(new SafeWalk());       // Не ходим с края блоков
        register(new InventoryWalk());  // Движение при открытом инвентаре
        register(new Parkour());        // Авто-прыжок у края блока
        register(new StepUp());         // Подъём на 1 блок без прыжка
        register(new JumpBoost());      // Усиление прыжка
        register(new SneakToggle());    // Фиксация сника
        register(new AutoWalk());       // Авто-ходьба вперёд
        register(new FreeCam());        // Камера в произвольном направлении

        // ── VISUAL ───────────────────────────────────────────────────────────
        register(new Brightness());     // Яркость: слайдер + авто в пещерах
        register(new Zoom());           // Плавное приближение (клавиша C)
        register(new GlowESP());        // Подсветка игроков (Glow effect)
        register(new Tracers());        // Компас-радар до целей
        register(new ChestESP());       // Подсветка сундуков
        register(new Nametags());       // Кастомные имена над игроками
        register(new HitParticles());   // Частицы при ударе
        register(new CritParticles());  // Частицы крита
        register(new DamageNumbers());  // Числа урона над сущностями
        register(new NoHurtCam());      // Убирает тряску камеры при уроне
        register(new NoRender());       // Убирает оверлей огня, тотема
        register(new ViewModel());      // Настройка отображения рук
        register(new Trajectories());   // Траектории снарядов
        register(new ItemPhysics());    // Физика предметов на земле
        register(new BlockHighlight()); // Подсветка выбранного блока
        register(new BlockOverlay());   // Прозрачный оверлей на блоке
        register(new TimeChanger());    // Смена времени суток (клиентски)
        register(new NightVision());    // Ночное зрение без зелья
        register(new ItemESP());        // Подсветка предметов на земле
        register(new SnowTrail());      // Снежный след
        register(new SwordTrail());     // След от меча
        register(new ElytraTrail());    // Шлейф при полёте на элитрах
        register(new GlowAura());       // Световая аура вокруг игрока
        register(new EchoAura());       // Расширяющиеся эхо-кольца
        register(new CrownAura());      // Корона из частиц
        register(new AuraShield());     // Щит из частиц
        register(new GroundEffect());   // Эффекты под ногами
        register(new HatEffect());      // Головной убор из частиц
        register(new HandEffect());     // Частицы из рук
        register(new ShockwaveEffect());// Волна при прыжке/ударе
        register(new DeathEffect());    // Взрыв частиц при смерти
        register(new RainbowTrail());   // Радужный след
        register(new StarBurst());      // Вспышки звёзд вокруг
        register(new ScreenEffects());  // Эффекты экрана (виньетка, хроматика)
        register(new FpsBoost());       // Отключение тяжёлых эффектов для FPS
        register(new Blur());           // Размытие фона GUI
        register(new PulseVisuals());   // Пульсирующий цветной контур
        register(new WingEffect());     // Крылья из частиц
        register(new PetOrbit());       // Орбита питомца
        register(new CapeEffect());     // Эффект плаща
        register(new Ambience());       // Фоновые частицы окружения

        // ── PLAYER ───────────────────────────────────────────────────────────
        register(new AutoArmor());      // Авто-надевание лучшей брони
        register(new AutoEat());        // Авто-еда при голоде
        register(new AntiAFK());        // Защита от кика за AFK
        register(new AntiPoison());     // Авто-молоко при яде
        register(new AutoRespawn());    // Авто-кнопка Respawn

        // ── HUD ───────────────────────────────────────────────────────────────
        register(new Keystrokes());     // WASD + пробел на экране
        register(new CpsCounter());     // Клики в секунду
        register(new ArmorHUD());       // Броня + прочность
        register(new ReachDisplay());   // Дистанция до цели
        register(new CoordsHUD());      // Координаты X/Y/Z
        register(new Speedometer());    // Скорость в блоках/сек
        register(new MemoryUsage());    // Использование памяти
        register(new FPSDisplay());     // FPS на экране
        register(new HealthHUD());      // HP в числах + цвет
        register(new PingHUD());        // Пинг до сервера
        register(new HotbarHUD());      // Улучшенный хотбар
        register(new TargetHUD());      // Инфо о цели (HP, броня)
        register(new CompassHUD());     // Компас с сторонами света
        register(new WeatherHUD());     // Погода (день, ночь, дождь)
        register(new DirectionHUD());   // Направление взгляда
        register(new TotemCounter());   // Количество тотемов
        register(new DurabilityHUD());  // Прочность держимого предмета
        register(new ComboTracker());   // Комбо-счётчик ударов
        register(new RangeAlert());     // Оповещение о ближайших игроках
        register(new HudClock());       // Часы (реальное время)
        register(new EventAlert());     // Уведомления (игрок зашёл/вышел)
        register(new EntityRadar());    // Радар сущностей
        register(new HealthBar());      // Полоски HP ближайших игроков
        register(new KillCounter());    // Счётчик убийств за сессию
        register(new SessionStats());   // Статистика сессии
        register(new BlockInfo());      // Инфо о блоке под прицелом
        register(new Minimap());        // Мини-карта
        register(new net.enkuron.modules.impl.ArrayList()); // Список активных модулей
        register(new Watermark());      // Водяной знак клиента

        // ── UTILITY ──────────────────────────────────────────────────────────
        register(new AutoTool());       // Авто-выбор лучшего инструмента
        register(new FastPlace());      // Быстрая установка блоков
        register(new AutoFish());       // Авто-рыбалка
        register(new ChestStealer());   // Авто-выкачка сундуков
        register(new BetterChat());     // Улучшенный чат
        register(new ChatLogger());     // Логирование чата в файл
        register(new AutoCraft());      // Авто-крафт предметов
        register(new QuickDrop());      // Быстрый выброс стека
        register(new InventorySort());  // Сортировка инвентаря
        // ── MISC ─────────────────────────────────────────────────────────────
        register(new ThemeSelector());  // Выбор темы клиента
    }

    private static void register(Module module) {
        // Проверяем что такой модуль ещё не зарегистрирован
        for (Module m : modules) {
            if (m.getClass() == module.getClass()) return; // дубликат
        }
        modules.add(module);
    }

    /**
     * onTick — вызывается для всех включённых модулей.
     * Использует снимок списка чтобы избежать ConcurrentModificationException.
     */
    public static void onTick() {
        Module[] snapshot = modules.toArray(new Module[0]);
        for (Module m : snapshot) {
            if (m.isEnabled()) m.onTick();
        }
    }

    /**
     * onRender — вызывается из MixinInGameHud для HUD и VISUAL модулей.
     * ВАЖНО: не вызывать из HudRenderCallback во избежание двойного рендера.
     */
    public static void onRender(DrawContext context) {
        Module[] snapshot = modules.toArray(new Module[0]);
        for (Module m : snapshot) {
            if (!m.isEnabled()) continue;
            Module.Category cat = m.getCategory();
            if (cat == Module.Category.HUD || cat == Module.Category.VISUAL) {
                m.render(context);
            }
        }
    }

    /**
     * onKey — для кейбиндов, назначенных через GUI (не стандартные).
     * Стандартные кейбинды обрабатываются в Enkuron.java.
     */
    public static void onKey(int key, int action) {
        if (action == 1) { // GLFW_PRESS
            for (Module m : modules) {
                if (m.getKey() == key) m.toggle();
            }
        }
    }

    /** Найти модуль по имени (регистронезависимо). */
    public static Module getByName(String name) {
        for (Module m : modules)
            if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    /** Найти первый модуль нужного класса. */
    @SuppressWarnings("unchecked")
    public static <T extends Module> T getByClass(Class<T> cls) {
        for (Module m : modules)
            if (cls.isInstance(m)) return (T) m;
        return null;
    }

    /** Неизменяемый список всех модулей. */
    public static List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    /** Количество включённых модулей. */
    public static int countEnabled() {
        int n = 0;
        for (Module m : modules) if (m.isEnabled()) n++;
        return n;
    }

    /** Количество включённых модулей в категории. */
    public static int countEnabled(Module.Category cat) {
        int n = 0;
        for (Module m : modules)
            if (m.isEnabled() && m.getCategory() == cat) n++;
        return n;
    }

    /** Все модули заданной категории. */
    public static List<Module> getByCategory(Module.Category cat) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules)
            if (m.getCategory() == cat) result.add(m);
        return result;
    }
}
