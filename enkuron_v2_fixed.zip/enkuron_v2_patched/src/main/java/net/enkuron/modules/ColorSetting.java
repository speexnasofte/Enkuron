package net.enkuron.modules;

/**
 * ColorSetting — настройка цвета (ARGB int).
 * Хранит цвет в формате 0xAARRGGBB.
 * Предоставляет HSV-конвертацию для GUI colour picker.
 */
public class ColorSetting {

    private final String name;
    private int color;        // 0xAARRGGBB
    private boolean rainbow;  // радужный режим (цвет меняется со временем)
    private float rainbowSpeed = 0.002f;
    private transient float hueOffset = 0f;

    public ColorSetting(String name, int defaultColor) {
        this.name  = name;
        this.color = defaultColor;
    }

    public String getName()  { return name; }
    public int    getColor() {
        if (rainbow) {
            hueOffset = (hueOffset + rainbowSpeed) % 1f;
            return fromHSV(hueOffset, 0.9f, 1f, alpha());
        }
        return color;
    }
    public void   setColor(int color) { this.color = color; }

    public boolean isRainbow()         { return rainbow; }
    public void    setRainbow(boolean r) { this.rainbow = r; }
    public float   getRainbowSpeed()   { return rainbowSpeed; }
    public void    setRainbowSpeed(float s) { this.rainbowSpeed = s; }

    public int alpha()  { return (color >> 24) & 0xFF; }
    public int red()    { return (color >> 16) & 0xFF; }
    public int green()  { return (color >> 8)  & 0xFF; }
    public int blue()   { return  color        & 0xFF; }

    /** Возвращает цвет с переопределённым alpha */
    public int withAlpha(int a) { return (a << 24) | (color & 0x00FFFFFF); }

    /** RGB → HSV (возвращает float[3] = {h,s,v}, h in [0,1)) */
    public static float[] toHSV(int argb) {
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8)  & 0xFF) / 255f;
        float b = ( argb        & 0xFF) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float delta = max - min;
        float h = 0, s = max == 0 ? 0 : delta / max, v = max;
        if (delta != 0) {
            if (max == r)      h = ((g - b) / delta % 6) / 6f;
            else if (max == g) h = ((b - r) / delta + 2) / 6f;
            else               h = ((r - g) / delta + 4) / 6f;
            if (h < 0) h += 1f;
        }
        return new float[]{h, s, v};
    }

    /** HSV → ARGB */
    public static int fromHSV(float h, float s, float v, int alpha) {
        h = h % 1f; if (h < 0) h += 1f;
        int i = (int)(h * 6);
        float f = h * 6 - i, p = v*(1-s), q = v*(1-f*s), t = v*(1-(1-f)*s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default-> { r = v; g = p; b = q; }
        }
        return (alpha << 24) | ((int)(r*255) << 16) | ((int)(g*255) << 8) | (int)(b*255);
    }
}
