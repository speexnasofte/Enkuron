package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * WeatherHUD — показывает текущую погоду и время суток в мире.
 *
 * Настройки:
 *   Показывать время    — вкл/выкл
 *   24-часовой формат   — вкл/выкл
 */
public class WeatherHUD extends Module {

    private final Setting showTime   = new Setting("Показывать время", true);
    private final Setting format24h  = new Setting("24-часовой формат", false);

    public WeatherHUD() {
        super("WeatherHUD", "Показывает погоду и время суток", Category.HUD);
        this.x = 5;
        this.y = 35;
        addSetting(showTime);
        addSetting(format24h);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || mc.world == null) return;

        String weather = getWeatherStr();
        String time    = showTime.getState() ? "  " + getTimeStr() : "";
        String text    = weather + time;

        int weatherColor = getWeatherColor();
        int tw = mc.textRenderer.getWidth(text) + 8;
        this.width  = tw + 4;
        this.height = 14;

        context.fill(x - 2, y - 1, x + tw + 2, y + 10, 0xBB111116);
        context.fill(x - 2, y - 1, x - 1,      y + 10, weatherColor);
        context.drawText(mc.textRenderer, text, x + 2, y, weatherColor, true);
    }

    private String getWeatherStr() {
        if (mc.world.isThundering()) return "⚡ Гроза";
        if (mc.world.isRaining())    return "🌧 Дождь";
        return "☀ Ясно";
    }

    private int getWeatherColor() {
        if (mc.world.isThundering()) return 0xFFFFDD44;
        if (mc.world.isRaining())    return 0xFF44AAFF;
        return 0xFFFFFF77;
    }

    private String getTimeStr() {
        // Minecraft день = 24000 тиков, 0 = 6:00
        long ticks = mc.world.getTimeOfDay() % 24000;
        int  totalMinutes = (int)((ticks * 24 * 60) / 24000);
        int  h = (totalMinutes / 60 + 6) % 24;
        int  m = totalMinutes % 60;

        if (format24h.getState()) {
            return String.format("%02d:%02d", h, m);
        } else {
            String ampm = h < 12 ? "AM" : "PM";
            int h12 = h % 12;
            if (h12 == 0) h12 = 12;
            return String.format("%d:%02d %s", h12, m, ampm);
        }
    }
}
