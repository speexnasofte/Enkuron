package net.enkuron.modules;

import java.util.Arrays;

public class Setting {
    public enum Type { NUMBER, BOOLEAN, ENUM, DOUBLE, STRING_ARRAY } // Добавлены типы для совместимости

    private final String name;
    private final Type type;
    private double value, min, max, inc;
    private boolean state;
    private String[] options;
    private int index;

    public Setting(String name, double defaultValue, double min, double max, double inc) {
        this.name = name;
        this.type = Type.NUMBER;
        this.value = defaultValue;
        this.min = min;
        this.max = max;
        this.inc = inc;
    }

    /** Конструктор без шага: inc вычисляется автоматически как 1/100 диапазона (≥ 0.01). */
    public Setting(String name, double defaultValue, double min, double max) {
        this(name, defaultValue, min, max, Math.max(0.01, (max - min) / 100.0));
    }

    public Setting(String name, boolean defaultState) {
        this.name = name;
        this.type = Type.BOOLEAN;
        this.state = defaultState;
    }

    public Setting(String name, String[] options, int defaultIndex) {
        this.name = name;
        this.type = Type.ENUM;
        this.options = options;
        this.index = defaultIndex;
    }

    // --- Методы совместимости (чтобы GUI не ломался) ---
    public String getName() { return name; }
    public Type getType() { return type; }
    
    public double getValue() { return value; }
    public double getDoubleValue() { return value; } // Для GlassGUI
    public float getValueFloat() { return (float) value; }
    public int getValueInt() { return (int) value; }
    
    public boolean getState() { return state; }
    public boolean getBoolValue() { return state; } // Для GlassGUI
    
    public double getMinValue() { return min; } // Для GlassGUI
    public double getMaxValue() { return max; } // Для GlassGUI
    
    public String getCurrentOption() { return (options == null || options.length == 0) ? "" : options[index]; }
    public int getSelectedIndex() { return index; }
    public int getOptionIndex() { return index; } // Для ConfigManager

    // --- Сеттеры ---
    public void setValue(double v) { 
        double p = 1.0 / inc;
        this.value = Math.round(Math.max(min, Math.min(max, v)) * p) / p; 
    }
    public void setDoubleValue(double v) { setValue(v); } // Для GlassGUI
    public void setState(boolean s) { this.state = s; }
    public void setBoolValue(boolean s) { this.state = s; } // Для GlassGUI
    public void setOptionIndex(int i) { if (options != null && i >= 0 && i < options.length) this.index = i; }
    
    public void nextValue() { // Для GlassGUI (переключение ENUM)
        if (type == Type.ENUM && options != null) index = (index + 1) % options.length;
    }

    // --- Методы которых ожидают GUI файлы ---
    public double getMin() { return min; }
    public double getMax() { return max; }
    public void toggleState() { this.state = !this.state; }
    public void cycleOption() { 
        if (type == Type.ENUM && options != null) index = (index + 1) % options.length; 
    }

}