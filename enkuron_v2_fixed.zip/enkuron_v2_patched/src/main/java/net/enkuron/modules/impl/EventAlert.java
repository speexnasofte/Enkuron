package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * EventAlert — уведомления на экране при важных игровых событиях.
 *
 * Отслеживает истечение зелий, низкие ресурсы, смерть и т.д.
 * Уведомления появляются в виде тостов и исчезают через N секунд.
 *
 * Настройки:
 *   Позиция         — Top-Right / Top-Left / Bottom-Right / Bottom-Left
 *   Длительность (сек) — 2 – 8
 *   Зелья кончаются — вкл (предупреждение за 5 сек до исчезновения)
 *   Низкий заряд    — вкл (если инструмент < 10% прочности)
 *   Голод           — вкл (при сытости ≤ 6)
 */
public class EventAlert extends Module {

    private static final String[] POSITIONS = {"Top-Right", "Top-Left", "Bottom-Right", "Bottom-Left"};

    private final Setting position     = new Setting("Позиция",              POSITIONS, 0);
    private final Setting duration     = new Setting("Длительность (сек)",    4.0, 2.0, 8.0);
    private final Setting alertPotions = new Setting("Зелья кончаются",       true);
    private final Setting alertDurability = new Setting("Низкая прочность",   true);
    private final Setting alertHunger  = new Setting("Голод",                 true);

    private static class Toast {
        String text;
        int color;
        int ticksLeft;
        Toast(String text, int color, int ticks) {
            this.text = text; this.color = color; this.ticksLeft = ticks;
        }
    }

    private final List<Toast> toasts = new ArrayList<>();
    private int checkTimer = 0;

    public EventAlert() {
        super("EventAlert", "Уведомления о зельях, прочности и голоде на экране", Category.HUD);
        this.width  = 150;
        this.height = 18;
        addSetting(position);
        addSetting(duration);
        addSetting(alertPotions);
        addSetting(alertDurability);
        addSetting(alertHunger);
    }

    public void addToast(String message, int color) {
        toasts.removeIf(t -> t.text.equals(message));
        toasts.add(new Toast(message, color, (int)(duration.getValue() * 20)));
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        // Убываем таймеры
        Iterator<Toast> it = toasts.iterator();
        while (it.hasNext()) { if (--it.next().ticksLeft <= 0) it.remove(); }

        checkTimer++;
        if (checkTimer < 20) return;
        checkTimer = 0;

        // Зелья кончаются
        if (alertPotions.getState()) {
            for (StatusEffectInstance eff : mc.player.getStatusEffects()) {
                if (eff.getDuration() <= 100 && eff.getDuration() > 0) {
                    addToast("⚠ " + eff.getEffectType().value().getName().getString() + " кончается!", 0xFFFFAA00);
                }
            }
        }

        // Голод
        if (alertHunger.getState() && mc.player.getHungerManager().getFoodLevel() <= 6) {
            addToast("🍖 Голод! Съешь что-нибудь", 0xFFFF6644);
        }

        // Прочность инструмента
        if (alertDurability.getState()) {
            net.minecraft.item.ItemStack held = mc.player.getMainHandStack();
            if (!held.isEmpty() && held.isDamageable()) {
                float durability = 1f - (float) held.getDamage() / held.getMaxDamage();
                if (durability < 0.1f) {
                    addToast("🔧 Инструмент изнашивается!", 0xFFFF4444);
                }
            }
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || toasts.isEmpty()) return;

        int screenW = mc.getWindow().getScaledWidth();
        int screenH = mc.getWindow().getScaledHeight();
        String pos   = position.getCurrentOption();

        int baseX, baseY;
        int dy = 18;

        switch (pos) {
            case "Top-Left"     -> { baseX = 5;             baseY = 30; dy =  18; }
            case "Bottom-Right" -> { baseX = screenW - 155; baseY = screenH - 20 - toasts.size() * 18; dy = 18; }
            case "Bottom-Left"  -> { baseX = 5;             baseY = screenH - 20 - toasts.size() * 18; dy = 18; }
            default             -> { baseX = screenW - 155; baseY = 30; dy = 18; }
        }

        int yOff = 0;
        for (Toast t : toasts) {
            float fadeIn  = (float) Math.min(1f, (duration.getValue() * 20 - t.ticksLeft) / 10f);
            float fadeOut = Math.min(1f, t.ticksLeft / 20f);
            float alpha   = Math.min(fadeIn, fadeOut);
            int a = (int)(alpha * 0xAA);
            int bg = (a << 24);

            int w = mc.textRenderer.getWidth(t.text) + 8;
            context.fill(baseX, baseY + yOff, baseX + w, baseY + yOff + 14, bg | 0x000000);
            context.drawText(mc.textRenderer, t.text, baseX + 4, baseY + yOff + 3, t.color, true);
            yOff += dy;
        }
    }
}
