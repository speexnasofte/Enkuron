package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.gui.DrawContext;

/**
 * ScreenEffects v2 — фиксы + визуал апгрейд.
 *
 * FIX v2:
 *  - Вигнетта: попиксельные циклы заменены на 8 fill-блоков (огромная оптимизация)
 *    Было: ~(sw/4 * 4) = ~480 fill-вызовов/кадр → стало: 8 fill-вызовов/кадр
 *  - FOV Pulse: аналогично — цикл заменён на 4 блока
 *  - hitFlashAnim / killFlashAnim: добавлен порог snap (< 0.005 → 0)
 *  - alpha-clamp для всех fill-вызовов [0..255]
 *  - shakeStrength clamp [0..12] чтобы не улетало при большом уроне
 *
 * VISUAL v2:
 *  - Вигнетта: 4 угловых дополнительных блока (углы теперь темнее)
 *  - Hit Flash: оттенок слегка красный (был чисто белый)
 *  - Kill Flash: добавлен короткий белый вспыхивающий момент перед зелёным
 *  - Новый эффект: SpeedLines — тонкие полосы по бокам при спринте
 */
public class ScreenEffects extends Module {

    private final Setting lowHpVignette = new Setting("Low HP Vignette", true);
    private final Setting hitFlash      = new Setting("Hit Flash",        true);
    private final Setting killFlash     = new Setting("Kill Flash",       true);
    private final Setting fovPulse      = new Setting("FOV Pulse overlay",false);
    private final Setting speedLines    = new Setting("Speed Lines",      false);
    private final Setting vignetteAlpha = new Setting("Vignette сила",    0.6, 0.1, 1.0);

    // ── Состояние ─────────────────────────────────────────────────────────

    private float hitFlashAnim  = 0f;
    private float killFlashAnim = 0f;
    private float vigPhase      = 0f;
    private float speedLinePhase = 0f;

    private float lastHp = -1f;

    public static float shakeStrength = 0f;
    public static float shakeDecay    = 0.85f;

    private float shakeOffX = 0f;
    private float shakeOffY = 0f;

    private static boolean _killPending = false;

    public ScreenEffects() {
        super("ScreenEffects", "Визуальные эффекты экрана: вигнетка, вспышки, shake", Category.VISUAL);
        addSetting(lowHpVignette);
        addSetting(hitFlash);
        addSetting(killFlash);
        addSetting(fovPulse);
        addSetting(speedLines);
        addSetting(vignetteAlpha);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        // Затухание — snap к 0 при малых значениях
        hitFlashAnim  = hitFlashAnim  < 0.005f ? 0f : hitFlashAnim  * 0.75f;
        killFlashAnim = killFlashAnim < 0.005f ? 0f : killFlashAnim * 0.75f;

        vigPhase += 0.06f;
        if (vigPhase > Math.PI * 2) vigPhase -= (float)(Math.PI * 2);

        speedLinePhase += 0.04f;
        if (speedLinePhase > (float)(Math.PI * 2)) speedLinePhase -= (float)(Math.PI * 2);

        // FIX: clamp shakeStrength
        shakeStrength = Math.min(shakeStrength, 12f);
        shakeStrength *= shakeDecay;
        if (shakeStrength > 0.2f) {
            shakeOffX = (float)(Math.random() - 0.5) * shakeStrength * 2f;
            shakeOffY = (float)(Math.random() - 0.5) * shakeStrength * 2f;
        } else {
            shakeOffX = AnimationUtils.lerp(shakeOffX, 0f, 0.25f);
            shakeOffY = AnimationUtils.lerp(shakeOffY, 0f, 0.25f);
        }

        float hp = mc.player.getHealth();
        if (lastHp > 0 && hp < lastHp) {
            if (hitFlash.getState()) hitFlashAnim = 0.35f;
            shakeStrength = Math.min(8f, (lastHp - hp) * 1.2f);
        }
        lastHp = hp;
    }

    public static void triggerKillFlash() {
        _killPending = true;
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || mc.player == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        if (_killPending && killFlash.getState()) {
            killFlashAnim = 0.45f;
            _killPending  = false;
        }

        // ── Hit Flash (слегка красноватый белый) ──────────────────────────
        if (hitFlashAnim > 0f) {
            int alpha = clamp((int)(hitFlashAnim * 120));
            // VISUAL: чуть тёплый оттенок вместо чисто белого
            ctx.fill(0, 0, sw, sh, (alpha << 24) | 0xFFEEEE);
        }

        // ── Kill Flash (зелёный) ──────────────────────────────────────────
        if (killFlashAnim > 0f) {
            int alpha = clamp((int)(killFlashAnim * 100));
            ctx.fill(0, 0, sw, sh, (alpha << 24) | 0x00FF55);
        }

        // ── Low HP Vignette ───────────────────────────────────────────────
        if (lowHpVignette.getState()) {
            float hp    = mc.player.getHealth();
            float maxHp = mc.player.getMaxHealth();
            float ratio = hp / maxHp;

            if (ratio < 0.35f) {
                float pulse = (float)(0.6 + 0.4 * Math.sin(vigPhase));
                float base  = (1f - ratio / 0.35f) * (float) vignetteAlpha.getValue();
                int   a     = clamp((int)(base * pulse * 180));

                // FIX + VISUAL: 8 fill-блоков вместо ~480 попиксельных вызовов
                int edgeW = sw / 4;
                int edgeH = sh / 4;

                // Стороны (4 блока с градиентом через 2 слоя)
                ctx.fill(0,          0, edgeW,        sh, ((a / 2) << 24) | 0x880000);
                ctx.fill(0,          0, edgeW / 2,    sh, ((a)     << 24) | 0x880000);
                ctx.fill(sw - edgeW, 0, sw,            sh, ((a / 2) << 24) | 0x880000);
                ctx.fill(sw - edgeW/2,0,sw,            sh, ((a)     << 24) | 0x880000);
                ctx.fill(0,          0, sw, edgeH,        ((a / 2) << 24) | 0x880000);
                ctx.fill(0,          0, sw, edgeH / 2,    ((a)     << 24) | 0x880000);
                ctx.fill(0, sh - edgeH,  sw, sh,          ((a / 2) << 24) | 0x880000);
                ctx.fill(0, sh - edgeH/2,sw, sh,          ((a)     << 24) | 0x880000);

                // VISUAL: тёмные угловые акценты
                ctx.fill(0,          0,          edgeW/3, edgeH/3, ((a) << 24) | 0x440000);
                ctx.fill(sw-edgeW/3, 0,          sw,      edgeH/3, ((a) << 24) | 0x440000);
                ctx.fill(0,          sh-edgeH/3, edgeW/3, sh,      ((a) << 24) | 0x440000);
                ctx.fill(sw-edgeW/3, sh-edgeH/3, sw,      sh,      ((a) << 24) | 0x440000);
            }
        }

        // ── FOV Pulse overlay ─────────────────────────────────────────────
        if (fovPulse.getState()) {
            double speed = mc.player.getVelocity().horizontalLength();
            if (speed > 0.25) {
                int alpha = clamp((int)(Math.min(1, (speed - 0.25) * 2) * 30));
                // FIX: 4 fill-блока вместо цикла
                int rad = sw / 6;
                ctx.fill(0,       0, rad,     sh, (alpha << 24));
                ctx.fill(0,       0, rad / 2, sh, (alpha << 24));
                ctx.fill(sw-rad,  0, sw,      sh, (alpha << 24));
                ctx.fill(sw-rad/2,0, sw,      sh, (alpha << 24));
            }
        }

        // ── Speed Lines (VISUAL NEW) ──────────────────────────────────────
        if (speedLines.getState()) {
            double speed = mc.player.getVelocity().horizontalLength();
            if (speed > 0.2) {
                float intensity = (float) Math.min(1.0, (speed - 0.2) / 0.4);
                int lineAlpha = clamp((int)(intensity * 60));
                float pulse   = (float)(0.5 + 0.5 * Math.sin(speedLinePhase));

                // Горизонтальные линии по бокам (имитация скорости)
                int cx = sw / 2;
                int lineCount = 6;
                for (int i = 0; i < lineCount; i++) {
                    int ly = (int)(sh * (0.3f + i * 0.07f));
                    int len = (int)((sw / 6) * intensity * (0.6f + 0.4f * pulse));
                    int la  = clamp((int)(lineAlpha * (1f - (float) i / lineCount)));
                    // левая сторона
                    ctx.fill(cx - sw/4 - len, ly, cx - sw/4, ly+1, (la << 24) | 0xAAAAAA);
                    // правая сторона
                    ctx.fill(cx + sw/4, ly, cx + sw/4 + len, ly+1, (la << 24) | 0xAAAAAA);
                }
            }
        }
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}
