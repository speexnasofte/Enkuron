package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * NightVision — даёт эффект ночного зрения без зелёного оттенка.
 *
 * Настройки:
 *   strength  — сила эффекта (1–3, визуально одинаково, но 3 = максимум)
 *   refresh   — интервал обновления эффекта в секундах (1–10)
 */
public class NightVision extends Module {

    private final Setting strength = new Setting("Сила",   1.0, 1.0, 3.0);
    private final Setting refresh  = new Setting("Обновление (сек)", 5.0, 1.0, 10.0);

    private int tickCount = 0;

    public NightVision() {
        super("NightVision", "Ночное зрение без зелёного оттенка", Category.VISUAL);
        addSetting(strength);
        addSetting(refresh);
    }

    @Override
    public void onEnable() {
        tickCount = 0;
        applyEffect();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        tickCount++;
        int intervalTicks = (int)(refresh.getValue() * 20);
        if (tickCount >= intervalTicks) {
            tickCount = 0;
            applyEffect();
        }
    }

    private void applyEffect() {
        if (mc.player == null) return;
        // Применяем на 30 секунд, каждые N секунд обновляем — эффект никогда не пропадёт
        mc.player.addStatusEffect(new StatusEffectInstance(
                StatusEffects.NIGHT_VISION,
                600,                        // 30 секунд
                (int) strength.getValue() - 1,
                false, false               // не видно в инвентаре, нет частиц
        ));
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
