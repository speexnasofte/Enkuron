package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * QuickDrop — быстрый сброс предметов из инвентаря.
 *
 * Позволяет одной клавишей (или автоматически) выбросить:
 *   • только текущий предмет в руке
 *   • весь стак
 *   • все предметы определённого типа в инвентаре
 *
 * Настройки:
 *   Режим сброса      — Single / Stack / All Same
 *   Задержка (мс)     — 50 – 500 (защита от случайного нажатия)
 *   Пропускать броню  — вкл/выкл
 *   Пропускать еду    — вкл/выкл
 */
public class QuickDrop extends Module {

    private static final String[] MODES = {"Single", "Stack", "All Same"};

    private final Setting mode        = new Setting("Режим сброса",    MODES, 0);
    private final Setting delayMs     = new Setting("Задержка (мс)",   150.0, 50.0, 500.0);
    private final Setting skipArmor   = new Setting("Пропускать броню", true);
    private final Setting skipFood    = new Setting("Пропускать еду",   true);

    private long lastDrop = 0;

    public QuickDrop() {
        super("QuickDrop", "Быстрый сброс предметов: один, стак или все одинаковые", Category.UTILITY);
        addSetting(mode);
        addSetting(delayMs);
        addSetting(skipArmor);
        addSetting(skipFood);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        long now = System.currentTimeMillis();
        if (now - lastDrop < (long) delayMs.getValue()) return;

        // Вызывается только при нажатии через Mixin или KeyBinding
        // Реализация зависит от твоего ввода — см. MixinKeyboard
    }

    /**
     * Вызывать из MixinKeyboard при нажатии нужной клавиши.
     */
    public void triggerDrop() {
        if (!isEnabled() || mc.player == null || mc.interactionManager == null) return;

        long now = System.currentTimeMillis();
        if (now - lastDrop < (long) delayMs.getValue()) return;
        lastDrop = now;

        int slot = mc.player.getInventory().selectedSlot;
        net.minecraft.item.ItemStack held = mc.player.getInventory().getStack(slot);
        if (held.isEmpty()) return;

        // Защиты
        if (skipArmor.getState() && isArmor(held)) return;
        if (skipFood.getState() && held.contains(net.minecraft.component.DataComponentTypes.FOOD)) return;

        String m = mode.getCurrentOption();
        switch (m) {
            case "Single":
                // FIX: используем уже извлечённый held, не переспрашиваем getStack
                mc.player.dropItem(held, false);
                break;
            case "Stack":
                mc.player.dropItem(held, true);
                break;
            case "All Same":
                dropAllSame(held);
                break;
        }
    }

    private void dropAllSame(net.minecraft.item.ItemStack reference) {
        for (int i = 0; i < 9; i++) {
            net.minecraft.item.ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.getItem() == reference.getItem()) {
                mc.player.getInventory().selectedSlot = i;
                mc.player.dropItem(mc.player.getInventory().getStack(mc.player.getInventory().selectedSlot), true);
            }
        }
    }

    private boolean isArmor(net.minecraft.item.ItemStack stack) {
        return stack.getItem() instanceof net.minecraft.item.ArmorItem;
    }
}
