package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/**
 * Keystrokes — нажатые клавиши W/A/S/D + пробел.
 *
 * Настройки:
 *   Показ пробела  — отображать клавишу SPC
 *   Размер клавиши — Small (14) / Normal (20) / Large (26)
 *   Анимация       — включить плавный fade
 */
public class Keystrokes extends Module {

    private static final String[] KEY_SIZES = {"Small", "Normal", "Large"};

    private final Setting showSpace = new Setting("Показ пробела",  true);
    private final Setting keySize   = new Setting("Размер клавиши", KEY_SIZES, 1);
    private final Setting animation = new Setting("Анимация",       true);

    private float wAlpha, aAlpha, sAlpha, dAlpha, spaceAlpha;

    public Keystrokes() {
        super("Keystrokes", "Отображает нажатые клавиши управления на экране", Category.HUD);
        addSetting(showSpace);
        addSetting(keySize);
        addSetting(animation);
        this.width = 65;
        this.height = 65;
    }

    private int getSize() {
        return switch (keySize.getCurrentOption()) {
            case "Small" -> 14;
            case "Large" -> 26;
            default      -> 20;
        };
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        long win = mc.getWindow().getHandle();
        boolean w     = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_W) == 1;
        boolean a     = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_A) == 1;
        boolean s     = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_S) == 1;
        boolean d     = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_D) == 1;
        boolean space = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == 1;

        float speed = animation.getState() ? 0.2f : 1.0f;
        wAlpha     = AnimationUtils.lerp(wAlpha,     w     ? 1f : 0.3f, speed);
        aAlpha     = AnimationUtils.lerp(aAlpha,     a     ? 1f : 0.3f, speed);
        sAlpha     = AnimationUtils.lerp(sAlpha,     s     ? 1f : 0.3f, speed);
        dAlpha     = AnimationUtils.lerp(dAlpha,     d     ? 1f : 0.3f, speed);
        spaceAlpha = AnimationUtils.lerp(spaceAlpha, space ? 1f : 0.3f, speed);

        int ks  = getSize();
        int gap = 2;
        int bx  = this.x;
        int by  = this.y;

        drawKey(context, "W", bx + ks + gap, by, ks, wAlpha);
        drawKey(context, "A", bx, by + ks + gap, ks, aAlpha);
        drawKey(context, "S", bx + ks + gap, by + ks + gap, ks, sAlpha);
        drawKey(context, "D", bx + (ks + gap) * 2, by + ks + gap, ks, dAlpha);

        if (showSpace.getState()) {
            int spaceW = ks * 3 + gap * 2;
            drawKeyWide(context, "SPC", bx, by + (ks + gap) * 2, spaceW, ks / 2 + 2, spaceAlpha);
        }

        this.width  = ks * 3 + gap * 2 + 4;
        this.height = ks * 2 + gap * 2 + (showSpace.getState() ? ks / 2 + gap + 4 : 4);
    }

    private void drawKey(DrawContext ctx, String label, int x, int y, int size, float alpha) {
        int bg     = EnkuronColor.withAlpha(alpha > 0.7f ? EnkuronColor.PRIMARY : 0x202020, (int)(alpha * 180));
        int border = EnkuronColor.withAlpha(EnkuronColor.PRIMARY, (int)(alpha * 255));
        int text   = EnkuronColor.withAlpha(EnkuronColor.TEXT, (int)(alpha * 255));
        ctx.fill(x, y, x + size, y + size, bg);
        ctx.fill(x, y, x + size, y + 1, border);
        ctx.fill(x, y + size - 1, x + size, y + size, border);
        ctx.fill(x, y, x + 1, y + size, border);
        ctx.fill(x + size - 1, y, x + size, y + size, border);
        ctx.drawText(mc.textRenderer, label, x + (size - mc.textRenderer.getWidth(label)) / 2, y + (size - 8) / 2, text, false);
    }

    private void drawKeyWide(DrawContext ctx, String label, int x, int y, int w, int h, float alpha) {
        int bg     = EnkuronColor.withAlpha(alpha > 0.7f ? EnkuronColor.PRIMARY : 0x202020, (int)(alpha * 180));
        int border = EnkuronColor.withAlpha(EnkuronColor.PRIMARY, (int)(alpha * 255));
        int text   = EnkuronColor.withAlpha(EnkuronColor.TEXT, (int)(alpha * 255));
        ctx.fill(x, y, x + w, y + h, bg);
        ctx.fill(x, y, x + w, y + 1, border);
        ctx.fill(x, y + h - 1, x + w, y + h, border);
        ctx.fill(x, y, x + 1, y + h, border);
        ctx.fill(x + w - 1, y, x + w, y + h, border);
        ctx.drawText(mc.textRenderer, label, x + (w - mc.textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, text, false);
    }
}
