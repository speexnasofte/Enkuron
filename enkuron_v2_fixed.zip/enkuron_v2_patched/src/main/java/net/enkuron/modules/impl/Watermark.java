package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

/**
 * Watermark v3 — визуал апгрейд + фиксы.
 *
 * FIX v3:
 *  - null-check для ThemeManager.get()
 *  - ver обновлён до v14
 *  - Classic: градиент пиксель-за-пикселем заменён на 2 fill-блока (оптимизация)
 *  - Neon: alpha-clamp чтобы не уйти за [0..255]
 *  - Badge: выравнивание текста хвоста исправлено (был микросдвиг)
 *  - Minimal: подчёркивание теперь на 1px ниже (не налезает на текст)
 *  - slideIn анимация при первом открытии (x-easing)
 *
 * VISUAL v3:
 *  - Classic: двойная линия сверху (accent + accent2, толщина 2px)
 *  - Neon: фоновый тёмный прямоугольник добавлен (раньше текст висел в воздухе)
 *  - Badge: скруглённый вид через 3-слойный fill + тень
 *  - Minimal: вторая тонкая тень под подчёркиванием
 *  - Новый стиль «Glitch» — мигающие сдвинутые копии текста
 */
public class Watermark extends Module {

    private static final String[] STYLES    = {"Classic", "Neon", "Minimal", "Badge", "Glitch"};
    private static final String[] POSITIONS = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"};

    private final Setting style    = new Setting("Стиль",    STYLES,    0);
    private final Setting pos      = new Setting("Позиция",  POSITIONS, 0);
    private final Setting showFps  = new Setting("FPS",      true);
    private final Setting showTime = new Setting("Время",    false);
    private final Setting rainbow  = new Setting("Rainbow",  false);

    private float glowPhase  = 0f;
    private float glitchTime = 0f;
    // slide-in: начинаем с 1 (за экраном), едем к 0
    private float slideIn    = 1f;

    public Watermark() {
        super("Watermark", "Водяной знак клиента Enkuron", Category.HUD);
        addSetting(style); addSetting(pos);
        addSetting(showFps); addSetting(showTime); addSetting(rainbow);
    }

    @Override
    public void onTick() {
        glowPhase += 0.05f;
        if (glowPhase > (float)(Math.PI * 2)) glowPhase -= (float)(Math.PI * 2);

        glitchTime += 0.08f;
        if (glitchTime > (float)(Math.PI * 2)) glitchTime -= (float)(Math.PI * 2);

        // slide-in анимация
        slideIn = AnimationUtils.lerp(slideIn, 0f, 0.12f);
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled()) return;

        // FIX: null-check
        Theme t = ThemeManager.get();
        if (t == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        String clientName = "Enkuron";
        String ver        = " v14";
        String fps        = showFps.getState()  ? "  " + mc.getCurrentFps() + " fps" : "";
        String timeStr    = showTime.getState() ? "  " + getTime() : "";
        String full       = clientName + ver + fps + timeStr;

        int accent = rainbow.getState() ? EnkuronColor.rainbow(0) : (t.accent & 0xFFFFFF);

        int textW = mc.textRenderer.getWidth(full);
        int boxH  = 14;

        String p = pos.getCurrentOption();
        boolean right  = p.contains("RIGHT");
        boolean bottom = p.contains("BOTTOM");

        // slide-in offset: уезжаем за соответствующий край
        int slideOffset = (int)(slideIn * (textW + 20));

        int bx = right  ? sw - textW - 10 : 4;
        int by = bottom ? sh - boxH  - 2  : 4;

        // применяем slide-in
        if (right)  bx += slideOffset;
        else        bx -= slideOffset;

        switch (style.getCurrentOption()) {
            case "Neon"    -> renderNeon   (ctx, full, clientName, ver, bx, by, accent);
            case "Minimal" -> renderMinimal(ctx, full, bx, by, accent);
            case "Badge"   -> renderBadge  (ctx, full, clientName, ver, bx, by, t, accent, textW, boxH);
            case "Glitch"  -> renderGlitch (ctx, full, clientName, ver, bx, by, accent);
            default        -> renderClassic(ctx, full, clientName, ver, bx, by, t, accent, textW, boxH);
        }
    }

    // ── Classic v3 ────────────────────────────────────────────────────────────
    private void renderClassic(DrawContext ctx, String full, String name, String ver,
                                int x, int y, Theme t, int accent, int textW, int boxH) {
        int nameW = mc.textRenderer.getWidth(name);
        int x2 = x + textW + 6;

        // Тёмный фон с внешней тенью
        ctx.fill(x - 3, y - 2, x2 + 1, y + boxH,     0x44000000); // тень
        ctx.fill(x - 2, y - 1, x2,     y + boxH - 1, 0xCC0A0A14); // фон

        // Двойная верхняя линия: accent (2px) + accent2 (1px)
        // FIX: заменили попиксельный градиент на 2 fill-блока
        int half = (x2 - (x - 2)) / 2;
        ctx.fill(x - 2,        y - 1, x - 2 + half, y,     0xFF000000 | (accent & 0xFFFFFF));
        ctx.fill(x - 2 + half, y - 1, x2,            y,     0xFF000000 | (t.accent2 & 0xFFFFFF));
        // Нижняя тонкая линия (dim)
        ctx.fill(x - 2, y + boxH - 2, x2, y + boxH - 1, 0x33000000 | (accent & 0xFFFFFF));

        // Текст
        ctx.drawText(mc.textRenderer, name, x, y + 2, 0xFF000000 | accent, true);
        String rest = ver + full.substring((name + ver).length());
        ctx.drawText(mc.textRenderer, rest, x + nameW, y + 2, 0xFFCCCCCC, true);
    }

    // ── Neon v3 ───────────────────────────────────────────────────────────────
    private void renderNeon(DrawContext ctx, String full, String name, String ver,
                             int x, int y, int accent) {
        float pulse = (float)(0.5 + 0.5 * Math.sin(glowPhase));
        int   base  = (int)(60 + 100 * pulse);
        int   rgb   = accent & 0x00FFFFFF;

        // FIX: тёмный фон (раньше текст висел в воздухе)
        int w = mc.textRenderer.getWidth(full);
        ctx.fill(x - 4, y - 2, x + w + 4, y + 11, 0xBB0A0A14);
        // нижняя accent-полоска
        ctx.fill(x - 4, y + 10, x + w + 4, y + 11, 0xFF000000 | rgb);

        // 8-слойное свечение (радиус 1 и 2)
        // FIX: alpha clamp [0..255]
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                int dist  = Math.abs(dx) + Math.abs(dy);
                int alpha = Math.min(255, dist == 1 ? base : base / 2);
                ctx.drawText(mc.textRenderer, full, x + dx, y + dy, (alpha << 24) | rgb, false);
            }
        }
        // Радиус 2
        int outer = Math.min(255, base / 3);
        ctx.drawText(mc.textRenderer, full, x - 2, y,     (outer << 24) | rgb, false);
        ctx.drawText(mc.textRenderer, full, x + 2, y,     (outer << 24) | rgb, false);
        ctx.drawText(mc.textRenderer, full, x,     y - 2, (outer << 24) | rgb, false);
        ctx.drawText(mc.textRenderer, full, x,     y + 2, (outer << 24) | rgb, false);

        // Основной текст
        int nameW = mc.textRenderer.getWidth(name);
        ctx.drawText(mc.textRenderer, name, x, y, 0xFF000000 | accent, false);
        String rest = ver + full.substring((name + ver).length());
        ctx.drawText(mc.textRenderer, rest, x + nameW, y, 0xFFEEEEEE, false);
    }

    // ── Minimal v3 ────────────────────────────────────────────────────────────
    private void renderMinimal(DrawContext ctx, String full, int x, int y, int accent) {
        int w = mc.textRenderer.getWidth(full);
        // FIX: подчёркивание на y+10 (не налезает на текст высотой 9px)
        ctx.fill(x - 1, y + 10, x + w + 2, y + 11, 0xFF000000 | accent);
        // тонкая тень под линией
        ctx.fill(x - 1, y + 11, x + w + 2, y + 12, 0x44000000 | accent);
        ctx.drawText(mc.textRenderer, full, x, y, 0xCCFFFFFF, false);
    }

    // ── Badge v3 ──────────────────────────────────────────────────────────────
    private void renderBadge(DrawContext ctx, String full, String name, String ver,
                              int x, int y, Theme t, int accent, int textW, int boxH) {
        int nameW = mc.textRenderer.getWidth(name);
        // FIX: правильная ширина хвоста
        String rest = ver + full.substring((name + ver).length());
        int restW = mc.textRenderer.getWidth(rest);

        // 3-слойный бейдж (имитация скруглений через заливки)
        ctx.fill(x - 4, y - 2, x + nameW + 6, y + boxH,     0x44000000);              // внешняя тень
        ctx.fill(x - 3, y - 1, x + nameW + 5, y + boxH - 1, 0xCC000000 | (accent & 0xFFFFFF)); // средний слой
        ctx.fill(x - 2, y,     x + nameW + 4, y + boxH - 2, 0xFF000000 | (accent & 0xFFFFFF)); // основной
        ctx.drawText(mc.textRenderer, name, x, y + 2, 0xFFFFFFFF, false);

        // Хвост
        ctx.fill(x + nameW + 2, y - 1, x + nameW + restW + 8, y + boxH - 1, 0xAA0A0A14);
        // FIX: правильный отступ текста хвоста
        ctx.drawText(mc.textRenderer, rest, x + nameW + 4, y + 2, 0xFFCCCCCC, false);
    }

    // ── Glitch (NEW) ─────────────────────────────────────────────────────────
    private void renderGlitch(DrawContext ctx, String full, String name, String ver,
                               int x, int y, int accent) {
        int w = mc.textRenderer.getWidth(full);
        // фон
        ctx.fill(x - 3, y - 2, x + w + 3, y + 12, 0xCC0A0A14);

        // Случайный глитч-сдвиг (только иногда, через sin)
        float glitchT = (float) Math.sin(glitchTime * 3.7f);
        boolean doGlitch = glitchT > 0.7f;

        if (doGlitch) {
            int offX = (int)(glitchT * 3);
            // красный сдвиг
            ctx.drawText(mc.textRenderer, full, x - offX, y, 0x88FF3333, false);
            // синий сдвиг
            ctx.drawText(mc.textRenderer, full, x + offX, y, 0x883355FF, false);
        }

        // нижняя цветная полоска (мигает)
        float barPulse = (float)(0.5 + 0.5 * Math.sin(glitchTime));
        int barAlpha = (int)(180 + 60 * barPulse);
        ctx.fill(x - 3, y + 10, x + w + 3, y + 11, (barAlpha << 24) | accent);

        // основной текст
        int nameW = mc.textRenderer.getWidth(name);
        ctx.drawText(mc.textRenderer, name, x, y, 0xFF000000 | accent, false);
        String rest = ver + full.substring((name + ver).length());
        ctx.drawText(mc.textRenderer, rest, x + nameW, y, 0xFFDDDDDD, false);
    }

    private String getTime() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        return String.format("%02d:%02d",
                cal.get(java.util.Calendar.HOUR_OF_DAY),
                cal.get(java.util.Calendar.MINUTE));
    }
}
