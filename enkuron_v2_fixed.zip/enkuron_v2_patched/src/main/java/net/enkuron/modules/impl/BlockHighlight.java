package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * BlockHighlight — настраиваемая подсветка блока под прицелом.
 *
 * Заменяет стандартный серый контур ванилы на цветной.
 * Рисуется через WorldRenderer или аналогичный миксин.
 *
 * Настройки:
 *   Стиль             — Outline / Fill / Both
 *   Красный (R)       — 0 – 255
 *   Зелёный (G)       — 0 – 255
 *   Синий (B)         — 0 – 255
 *   Прозрачность (A)  — 0 – 255
 *   Ширина линии      — 1 – 5
 */
public class BlockHighlight extends Module {

    private static final String[] STYLES = {"Outline", "Fill", "Both"};

    private final Setting style  = new Setting("Стиль",            STYLES, 0);
    private final Setting red    = new Setting("Красный (R)",       255.0, 0.0, 255.0);
    private final Setting green  = new Setting("Зелёный (G)",       255.0, 0.0, 255.0);
    private final Setting blue   = new Setting("Синий (B)",         255.0, 0.0, 255.0);
    private final Setting alpha  = new Setting("Прозрачность (A)",   80.0, 0.0, 255.0);
    private final Setting lineW  = new Setting("Ширина линии",        2.0, 1.0, 5.0);

    public BlockHighlight() {
        super("BlockHighlight", "Цветная подсветка блока под прицелом", Category.VISUAL);
        addSetting(style);
        addSetting(red);
        addSetting(green);
        addSetting(blue);
        addSetting(alpha);
        addSetting(lineW);
    }

    /** Возвращает ARGB-цвет по текущим настройкам. */
    public int getColor() {
        int a = (int) alpha.getValue();
        int r = (int) red.getValue();
        int g = (int) green.getValue();
        int b = (int) blue.getValue();
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Текущий стиль рендера (Outline / Fill / Both). */
    public String getStyle() {
        return style.getCurrentOption();
    }

    /** Ширина линии обводки. */
    public float getLineWidth() {
        return (float) lineW.getValue();
    }

    /**
     * Целевой блок под прицелом (или null).
     * Используется в MixinWorldRenderer для отрисовки.
     */
    public BlockPos getTargetBlock() {
        if (mc.crosshairTarget == null) return null;
        if (mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return null;
        return ((BlockHitResult) mc.crosshairTarget).getBlockPos();
    }
}
