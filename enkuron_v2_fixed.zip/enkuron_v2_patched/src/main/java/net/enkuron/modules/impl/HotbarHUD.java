package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * HotbarHUD — кастомный хотбар.
 *
 * Настройки:
 *   Показ номера слота — текст "Слот X" под хотбаром
 *   Размер иконки      — 14 / 18 / 22 пикселя (Small / Normal / Large)
 *   Подсветка цвет     — фиолетовый / синий / зелёный
 */
public class HotbarHUD extends Module {

    private static final String[] SIZES   = {"Small", "Normal", "Large"};
    private static final String[] COLORS  = {"Фиолетовый", "Синий", "Зелёный"};

    private final Setting showSlotNum = new Setting("Номер слота", true);
    private final Setting iconSize    = new Setting("Размер",      SIZES, 1);
    private final Setting hlColor     = new Setting("Цвет подсветки", COLORS, 0);

    public HotbarHUD() {
        super("HotbarHUD", "Кастомный хотбар с подсветкой активного слота", Category.HUD);
        addSetting(showSlotNum);
        addSetting(iconSize);
        addSetting(hlColor);
        this.x = 60; this.y = 5;
    }

    private int getSlotSize() {
        return switch (iconSize.getCurrentOption()) {
            case "Small" -> 14;
            case "Large" -> 22;
            default      -> 18;
        };
    }

    private int getHlColor() {
        return switch (hlColor.getCurrentOption()) {
            case "Синий"   -> 0x664488FF;
            case "Зелёный" -> 0x6644EE77;
            default        -> 0x668844FF;
        };
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        int slotSize = getSlotSize();
        int gap      = 2;
        int selected = mc.player.getInventory().selectedSlot;
        int totalW   = 9 * (slotSize + gap) - gap;
        this.width   = totalW + 8;
        this.height  = slotSize + (showSlotNum.getState() ? 11 : 4);

        context.fill(x - 2, y - 2, x + totalW + 4, y + slotSize + 4, 0xBB111116);
        context.fill(x - 2, y - 2, x + totalW + 4, y - 1, 0xFF8844FF);

        int drawX = x;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);

            if (i == selected) {
                context.fill(drawX - 1, y - 1, drawX + slotSize + 1, y + slotSize + 1, getHlColor());
            }

            if (!stack.isEmpty()) {
                // FIX: центрируем иконку 16x16 внутри слота переменного размера
                int iconOffset = (slotSize - 16) / 2;
                context.drawItem(stack, drawX + iconOffset, y + iconOffset);
                context.drawStackOverlay(mc.textRenderer, stack, drawX + iconOffset, y + iconOffset);
            }

            drawX += slotSize + gap;
        }

        if (showSlotNum.getState()) {
            String slotStr = "Слот " + (selected + 1);
            int tw = mc.textRenderer.getWidth(slotStr);
            int cx = x + totalW / 2 - tw / 2;
            context.drawText(mc.textRenderer, slotStr, cx, y + slotSize + 3, 0xFF9955FF, true);
        }
    }
}
