package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * DeathEffect — эффект при смерти игрока (взрыв частиц).
 *
 * Режимы:
 *   Explosion  — взрыв огня и искр
 *   Soul       — разлёт душ
 *   Shatter    — осколки льда
 *   Petals     — дождь лепестков сакуры
 */
public class DeathEffect extends Module {

    private static final String[] MODES = {"Explosion", "Soul", "Shatter", "Petals"};

    private final Setting mode  = new Setting("Эффект",         MODES, 0);
    private final Setting count = new Setting("Кол-во частиц",  40.0, 10.0, 80.0);

    private boolean wasAlive  = true;
    private boolean triggered = false;
    private Vec3d   deathPos  = null;
    private int     deathTimer= 0;

    public DeathEffect() {
        super("DeathEffect", "Красивый взрыв частиц при смерти игрока", Category.VISUAL);
        addSetting(mode);
        addSetting(count);
    }

    @Override public void onEnable() { wasAlive = true; triggered = false; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        boolean alive = mc.player.getHealth() > 0;

        // Переход живой → мёртвый
        if (wasAlive && !alive && !triggered) {
            deathPos  = mc.player.getPos().add(0, mc.player.getHeight() * 0.5, 0);
            triggered = true;
            deathTimer= 0;
        }

        // Воспроизводим эффект в течение нескольких тиков
        if (triggered && deathPos != null) {
            deathTimer++;
            if (deathTimer <= 4) {
                spawnEffect(deathPos);
            } else {
                triggered = false;
                deathPos  = null;
            }
        }

        // Сброс при возрождении
        if (!wasAlive && alive) {
            triggered = false;
            deathPos  = null;
        }

        wasAlive = alive;
    }

    private void spawnEffect(Vec3d pos) {
        int cnt = (int) count.getValue();
        switch (mode.getCurrentOption()) {
            case "Soul"    -> spawnSoul   (pos, cnt);
            case "Shatter" -> spawnShatter(pos, cnt);
            case "Petals"  -> spawnPetals (pos, cnt);
            default        -> spawnExplosion(pos, cnt);
        }
    }

    private void spawnExplosion(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*1.2;
            double vy = Math.random()*0.9;
            double vz = (Math.random()-0.5)*1.2;
            mc.world.addParticle(
                i % 3 == 0 ? ParticleTypes.LARGE_SMOKE : ParticleTypes.FLAME,
                p.x, p.y, p.z, vx, vy, vz);
        }
        mc.world.addParticle(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 0, 0, 0);
        for (int i = 0; i < cnt/3; i++) {
            double vx = (Math.random()-0.5)*0.8;
            double vy = Math.random()*0.6;
            double vz = (Math.random()-0.5)*0.8;
            mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnSoul(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.6;
            double vy = Math.random()*1.0 + 0.2;
            double vz = (Math.random()-0.5)*0.6;
            mc.world.addParticle(
                i % 2 == 0 ? ParticleTypes.SOUL : ParticleTypes.SOUL_FIRE_FLAME,
                p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnShatter(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*1.5;
            double vy = Math.random()*1.0;
            double vz = (Math.random()-0.5)*1.5;
            mc.world.addParticle(ParticleTypes.SNOWFLAKE, p.x, p.y, p.z, vx, vy, vz);
        }
        for (int i = 0; i < cnt/4; i++) {
            double vx = (Math.random()-0.5)*0.8;
            double vy = Math.random()*0.5;
            double vz = (Math.random()-0.5)*0.8;
            mc.world.addParticle(ParticleTypes.END_ROD, p.x, p.y, p.z, vx, vy, vz);
        }
    }

    private void spawnPetals(Vec3d p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double vx = (Math.random()-0.5)*0.8;
            double vy = Math.random()*0.7 + 0.1;
            double vz = (Math.random()-0.5)*0.8;
            mc.world.addParticle(ParticleTypes.CHERRY_LEAVES, p.x, p.y, p.z, vx, vy, vz);
        }
        // Центральная вспышка
        mc.world.addParticle(ParticleTypes.FLASH, p.x, p.y, p.z, 0, 0, 0);
    }
}
