package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * AutoCraft — автоматическое крафтение предметов.
 *
 * Следит за инвентарём и крафтит выбранный предмет, если
 * достаточно материалов. Работает через открытый стол крафта
 * или сетку 2x2 игрока.
 *
 * Настройки:
 *   Предмет          — Torch / Plank / Stick / Chest / Crafting Table
 *   Мин. материалов  — 4 – 64 (крафтить только при наличии N+ материалов)
 *   Только в меню    — вкл (только при открытом столе крафта)
 *   Авто-повтор      — вкл/выкл (крафтить в цикле пока есть материалы)
 *   Задержка (тики)  — 5 – 40
 */
public class AutoCraft extends Module {

    private static final String[] ITEMS = {"Torch", "Plank", "Stick", "Chest", "Crafting Table"};

    private final Setting targetItem = new Setting("Предмет",         ITEMS, 0);
    private final Setting minMats    = new Setting("Мин. материалов", 8.0, 4.0, 64.0);
    private final Setting tableOnly  = new Setting("Только у стола",  false);
    private final Setting autoRepeat = new Setting("Авто-повтор",     true);
    private final Setting delay      = new Setting("Задержка (тики)", 10.0, 5.0, 40.0);

    private int timer = 0;

    public AutoCraft() {
        super("AutoCraft", "Автоматически крафтит выбранный предмет при наличии материалов", Category.UTILITY);
        addSetting(targetItem);
        addSetting(minMats);
        addSetting(tableOnly);
        addSetting(autoRepeat);
        addSetting(delay);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (tableOnly.getState() && mc.currentScreen == null) return;

        timer++;
        if (timer < (int) delay.getValue()) return;
        timer = 0;

        // Заглушка — реализация крафта через CraftingScreenHandler
        // зависит от версии Minecraft. Используй mc.interactionManager.clickSlot.
        // Пример подключения описан в wiki Fabric API.
    }
}
