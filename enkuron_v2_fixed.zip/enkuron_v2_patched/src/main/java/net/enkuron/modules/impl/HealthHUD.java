package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

/**
 * HealthHUD — HP и поглощение.
 *
 * Настройки:
 *   Показ полоски  — рисовать HP-бар внизу
 *   Показ макс. HP — отображать "/ maxHP"
 *   Иконка сердца  — ❤ / HP / ♥
 */
public class HealthHUD extends Module {

    private static final String[] ICONS = {"❤", "HP", "♥"};

    private final Setting showBar    = new Setting("Полоска",       true);
    private final Setting showMax    = new Setting("Макс. HP",      true);
    private final Setting icon       = new Setting("Иконка",        ICONS, 0);

    public HealthHUD() {
        super("HealthHUD", "Показывает HP и поглощение с полоской", Category.HUD);
        addSetting(showBar);
        addSetting(showMax);
        addSetting(icon);
        this.x = 5; this.y = 120;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        float hp  = mc.player.getHealth();
        float abs = mc.player.getAbsorptionAmount();
        float max = mc.player.getMaxHealth();

        String ico  = icon.getCurrentOption();
        String text = showMax.getState()
                ? String.format("%s %.1f / %.0f", ico, hp, max)
                : String.format("%s %.1f", ico, hp);
        if (abs > 0) text += String.format(" +%.0f", abs);

        int tw = mc.textRenderer.getWidth(text) + 8;
        this.width  = tw + 4;
        this.height = showBar.getState() ? 16 : 13;

        float ratio = Math.min(hp / max, 1f);
        int color;
        if      (ratio > 0.6f) color = 0xFF44EE77;
        else if (ratio > 0.3f) color = 0xFFFFAA22;
        else                   color = 0xFFEE3333;

        context.fill(x - 2, y - 1, x + tw + 2, y + 11, 0xBB111116);
        context.fill(x - 2, y - 1, x - 1,      y + 11, color);

        if (showBar.getState()) {
            context.fill(x + 2, y + 9, x + tw - 2, y + 11, 0xFF222222);
            context.fill(x + 2, y + 9, x + 2 + (int)((tw - 4) * ratio), y + 11, color);
            if (abs > 0) {
                float absRatio = Math.min(abs / max, 1f);
                context.fill(x + 2, y + 9, x + 2 + (int)((tw - 4) * absRatio), y + 11, 0xFFFFDD44);
            }
        }

        context.drawText(mc.textRenderer, text, x + 2, y, color, true);
    }
}
