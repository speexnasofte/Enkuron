package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.util.math.BlockPos;

public class Parkour extends Module {
    private final Setting onEdgeOnly = new Setting("Только на краю",  true);
    private final Setting onGround   = new Setting("Только на земле", true);

    // FIX: флаг чтобы не прыгать каждый тик пока игрок на краю
    private boolean wasOnGround = false;

    public Parkour() {
        super("Parkour", "Автоматически прыгает при достижении края блока", Category.MOVEMENT);
        addSetting(onEdgeOnly);
        addSetting(onGround);
    }

    @Override
    public void onEnable() { wasOnGround = false; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        boolean grounded = mc.player.isOnGround();
        if (onGround.getState() && !grounded) {
            wasOnGround = false;
            return;
        }
        if (mc.player.isSneaking()) return;

        // Прыгаем только один раз за приземление (leading edge)
        if (!grounded) { wasOnGround = false; return; }
        if (wasOnGround) return; // уже прыгнули после этого приземления
        wasOnGround = true;

        if (onEdgeOnly.getState()) {
            double x = mc.player.getX();
            double y = mc.player.getY();
            double z = mc.player.getZ();
            boolean edge = !isBlockBelow(x + 0.31, y, z)
                        || !isBlockBelow(x - 0.31, y, z)
                        || !isBlockBelow(x, y, z + 0.31)
                        || !isBlockBelow(x, y, z - 0.31);
            if (!edge) return;
        }

        mc.player.jump();
    }

    private boolean isBlockBelow(double x, double y, double z) {
        BlockPos pos = BlockPos.ofFloored(x, y - 0.05, z);
        return !mc.world.getBlockState(pos).isAir();
    }
}
