package net.enkuron.modules;

import net.enkuron.event.EventBus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Module v2 — базовый класс всех модулей Enkuron.
 *
 * Ключевые принципы:
 *  - toggle() автоматически подписывает/отписывает модуль от EventBus
 *  - setEnabled() используется ConfigManager при загрузке (без двойного toggle)
 *  - onTick() / render() оставлены для совместимости
 *  - getSetting(name) — поиск по имени для GUI и конфига
 *  - ColorSetting хранится отдельно от Setting
 */
public abstract class Module {

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final String   description;
    private final Category category;

    private int     key;
    private boolean enabled;

    // HUD-позиционирование
    public int    width  = 80;
    public int    height = 20;
    protected int x     = 20;
    protected int y     = 20;
    protected boolean dragging = false;

    // Настройки
    private final List<Setting>      settings      = new ArrayList<>();
    private final List<ColorSetting> colorSettings = new ArrayList<>();

    // ── Конструктор ──────────────────────────────────────────────────────────

    public Module(String name, String description, Category category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
    }

    // ── Управление настройками ───────────────────────────────────────────────

    protected void addSetting(Setting setting) {
        settings.add(setting);
    }

    protected void addColorSetting(ColorSetting cs) {
        colorSettings.add(cs);
    }

    public List<Setting> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public List<ColorSetting> getColorSettings() {
        return Collections.unmodifiableList(colorSettings);
    }

    public Setting getSetting(String name) {
        for (Setting s : settings)
            if (s.getName().equals(name)) return s;
        return null;
    }

    public ColorSetting getColorSetting(String name) {
        for (ColorSetting cs : colorSettings)
            if (cs.getName().equals(name)) return cs;
        return null;
    }

    // ── Жизненный цикл ──────────────────────────────────────────────────────

    /**
     * Переключить модуль вкл/выкл.
     * Автоматически подписывает/отписывает от EventBus.
     */
    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            EventBus.subscribe(this);
            onEnable();
        } else {
            onDisable();
            EventBus.unsubscribe(this);
        }
    }

    /**
     * Установить состояние напрямую (используется ConfigManager).
     * Не вызывает двойной toggle если состояние уже такое.
     */
    public void setEnabled(boolean value) {
        if (value != enabled) toggle();
    }

    public void onEnable()  {}
    public void onDisable() {}

    /** Вызывается каждый тик (только для включённых модулей). */
    public void onTick() {}

    /** Вызывается при рендере HUD (только для включённых HUD/VISUAL модулей). */
    public void render(DrawContext context) {}

    // ── Геттеры / Сеттеры ───────────────────────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isEnabled()      { return enabled; }

    public int  getKey()           { return key; }
    public void setKey(int key)    { this.key = key; }

    public int  getX()             { return x; }
    public void setX(int x)        { this.x = x; }
    public int  getY()             { return y; }
    public void setY(int y)        { this.y = y; }

    public boolean isDragging()                { return dragging; }
    public void    setDragging(boolean drag)   { this.dragging = drag; }

    // ── Категории ────────────────────────────────────────────────────────────

    public enum Category {
        COMBAT, MOVEMENT, VISUAL, PLAYER, HUD, UTILITY, MISC
    }
}
