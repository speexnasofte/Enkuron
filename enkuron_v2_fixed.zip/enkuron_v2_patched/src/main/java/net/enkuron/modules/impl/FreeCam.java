package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * FreeCam — свободная камера отдельно от тела.
 *
 * Настройки:
 *   Скорость     — множитель скорости полёта (1–10)
 *   NoClip       — отключить столкновения с блоками
 */
public class FreeCam extends Module {

    private final Setting speed   = new Setting("Скорость",  3.0, 1.0, 10.0);
    private final Setting noClip  = new Setting("NoClip",    true);

    public FreeCam() {
        super("FreeCam", "Позволяет осматривать местность отдельно от тела", Category.VISUAL);
        addSetting(speed);
        addSetting(noClip);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        mc.player.getAbilities().flying = true;
        // FIX: flySpeed устанавливаем напрямую, без каста через MixinPlayerAbilities
        // (каст мог не работать, если MixinPlayerAbilities не является интерфейсом)
        // Формула: 1.0 = 0.05f (дефолт), каждый уровень шкалы умножает пропорционально
        mc.player.getAbilities().setFlySpeed((float)(speed.getValue() * 0.05 / 5.0));
        mc.player.noClip = noClip.getState();
    }

    @Override
    public void onDisable() {
        if (mc.player == null) return;
        mc.player.getAbilities().flying = false;
        mc.player.getAbilities().setFlySpeed(0.05f);
        mc.player.noClip = false;
    }
}
