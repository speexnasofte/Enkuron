package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * Sprint — автоматический бег.
 *
 * Настройки:
 *   Режим         — Always (всегда) / Forward (только вперёд) / Omni (в любую сторону)
 *   В воде        — спринт при плавании
 */
public class Sprint extends Module {

    private static final String[] MODES = {"Always", "Forward", "Omni"};

    private final Setting sprintMode = new Setting("Режим",    MODES, 1);
    private final Setting inWater    = new Setting("В воде",   false);

    public Sprint() {
        super("Sprint", "Автоматически включает бег", Category.MOVEMENT);
        addSetting(sprintMode);
        addSetting(inWater);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (mc.player.isSneaking()) return;
        if (mc.player.isSwimming() && !inWater.getState()) return;

        boolean canSprint = switch (sprintMode.getCurrentOption()) {
            case "Always"  -> true;
            case "Omni"    -> mc.player.forwardSpeed != 0 || mc.player.sidewaysSpeed != 0;
            default        -> mc.player.forwardSpeed > 0; // Forward
        };

        if (canSprint) mc.player.setSprinting(true);
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.player.setSprinting(false);
    }
}
