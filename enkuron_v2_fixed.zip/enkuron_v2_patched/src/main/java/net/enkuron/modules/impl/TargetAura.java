package net.enkuron.modules.impl;

import net.enkuron.modules.SettingPresets;
import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class TargetAura extends Module {

    private static final String[] MODES = {
        "Ring", "Crown", "Orbit", "Rain", "Pulse", "DNA", "Firework", "Galaxy",
        "Tornado", "Cage", "Phoenix", "Matrix", "Halo", "Vortex", "Reaper", "Nova",
        "Lightning", "Snowstorm", "Sakura", "Comet", "Helix", "Wave", "Burst"
    };
    private static final String[] PTYPES = {
        "Enchant", "Portal", "End Rod", "Flame", "Soul", "Crit", "Witch",
        "Snowflake", "Electric", "Cherry", "Dragon Breath", "Custom Color"
    };
    private static final String[] TARGET_MODES = {"Crosshair", "AllInRange"};
    private static final String[] COLOR_MODES  = {"Static", "Rainbow", "ByHP", "Pulse", "Shift"};

    private final SettingPresets.TargetFilter targetFilter = new SettingPresets.TargetFilter();
    private final SettingPresets.Range        targetRange  = new SettingPresets.Range(8.0, 4.0, 32.0);
    private final SettingPresets.MaxTargets   maxTargets   = new SettingPresets.MaxTargets(3.0, 1.0, 8.0);
    private final SettingPresets.HPFilter     hpFilter     = new SettingPresets.HPFilter();

    private final Setting targetMode = new Setting("Режим целей",  TARGET_MODES, 0);
    private final Setting mode       = new Setting("Режим ауры",   MODES,        0);
    private final Setting ptype      = new Setting("Частицы",      PTYPES,       2);
    private final Setting colorMode  = new Setting("Цвет режим",   COLOR_MODES,  0);

    private final Setting radius     = new Setting("Радиус",         3.2,   1.0,  15.0);
    private final Setting density    = new Setting("Плотность",      12.0,  1.0,  50.0);
    private final Setting yOffset    = new Setting("Y-смещение",      0.0,  -2.0,  5.0);
    private final Setting orbitTilt  = new Setting("Наклон орбиты",   0.0, -45.0, 45.0);
    private final Setting waveHeight = new Setting("Высота волны",    1.0,   0.0,  5.0);
    private final Setting waveCount  = new Setting("Число волн",      1.0,   1.0,  5.0);
    private final Setting waveOffset = new Setting("Смещение волн",  90.0,   0.0,360.0);

    private final Setting speedMult  = new Setting("Скорость",        1.0,  0.1,  5.0);
    private final Setting pulseAmp   = new Setting("Пульс амплитуда", 0.3,  0.0,  2.0);
    private final Setting pulseSpeed = new Setting("Пульс скорость",  0.12, 0.05, 2.0);
    private final Setting colorShift = new Setting("Цвет сдвиг",      5.0,  1.0, 50.0);
    private final Setting fadeAnim   = new Setting("Fade анимация",   true);

    private final Setting colorR     = new Setting("Цвет R",         255.0, 0.0, 255.0);
    private final Setting colorG     = new Setting("Цвет G",         255.0, 0.0, 255.0);
    private final Setting colorB     = new Setting("Цвет B",         255.0, 0.0, 255.0);

    private final Setting dustSize   = new Setting("Размер частиц",   1.0,  0.1,  5.0);
    private final Setting hpColor    = new Setting("Цвет по HP",      true);

    private double orbitAngle, pulsePhase, dnaPhase, fwTimer;
    private double galAngle, tornAngle, cageAngle, reapAngle, novaPhase;
    private double vortAngle, lightPhase, snowPhase, sakPhase, cometAngle;
    private double helixPhase, wavePhase, burstPhase, colorHue;
    private int tick;

    private final java.util.Map<Integer, Float> fadeMap = new java.util.LinkedHashMap<>();
    private LivingEntity cachedTarget = null;
    private final List<LivingEntity> cachedTargets = new ArrayList<>();

    public TargetAura() {
        super("TargetAura", "Визуальная аура частиц вокруг целей (v6, 50+ настроек)", Category.VISUAL);
        addSetting(targetMode); targetFilter.addTo(this); targetRange.addTo(this);
        maxTargets.addTo(this); hpFilter.addTo(this); addSetting(mode);
        addSetting(ptype); addSetting(colorMode); addSetting(colorR);
        addSetting(colorG); addSetting(colorB); addSetting(colorShift);
        addSetting(radius); addSetting(density); addSetting(yOffset);
        addSetting(orbitTilt); addSetting(waveHeight); addSetting(waveCount);
        addSetting(waveOffset); addSetting(speedMult); addSetting(pulseAmp);
        addSetting(pulseSpeed); addSetting(fadeAnim); addSetting(dustSize);
        addSetting(hpColor);
    }

    @Override
    public void onEnable() {
        orbitAngle = pulsePhase = dnaPhase = galAngle = fwTimer = 0;
        tornAngle = cageAngle = reapAngle = novaPhase = vortAngle = 0;
        lightPhase = snowPhase = sakPhase = cometAngle = 0;
        helixPhase = wavePhase = burstPhase = colorHue = 0;
        tick = 0; cachedTargets.clear(); fadeMap.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;

        cachedTargets.clear();
        if (targetMode.getCurrentOption().equals("Crosshair")) {
            LivingEntity t = getCrosshairTarget();
            if (t != null) cachedTargets.add(t);
        } else {
            collectRangeTargets();
        }
        if (cachedTargets.isEmpty()) return;

        double spd = speedMult.getValue();
        orbitAngle += 0.18 * spd; pulsePhase += pulseSpeed.getValue() * spd;
        dnaPhase   += 0.22 * spd; galAngle   += 0.14 * spd; fwTimer    += 1;
        tornAngle  += 0.20 * spd; cageAngle  += 0.10 * spd; reapAngle  += 0.25 * spd;
        novaPhase  += 0.09 * spd; vortAngle  += 0.16 * spd; lightPhase += 0.30 * spd;
        snowPhase  += 0.17 * spd; sakPhase   += 0.13 * spd; cometAngle += 0.21 * spd;
        helixPhase += 0.15 * spd; wavePhase  += 0.19 * spd; burstPhase += 0.28 * spd;
        colorHue    = (colorHue + colorShift.getValue() * 0.1) % 360.0;

        for (LivingEntity target : cachedTargets) {
            cachedTarget = target;
            float alpha = 1.0f;
            if (fadeAnim.getState()) {
                int eid = target.getId();
                float cur = fadeMap.getOrDefault(eid, 0.0f);
                float next = AnimationUtils.lerp(cur, 1.0f, 0.12f);
                fadeMap.put(eid, next);
                alpha = next;
            }

            Vec3d pos = target.getPos();
            double h  = target.getHeight();
            double r  = radius.getValue() * alpha;
            int cnt   = (int) density.getValue();
            double yo = yOffset.getValue();
            double tilt = Math.toRadians(orbitTilt.getValue());
            int waves  = (int) waveCount.getValue();
            double woff = Math.toRadians(waveOffset.getValue());

            for (int w = 0; w < waves; w++) {
                spawnMode(pos, r, cnt, h, yo, tilt, w * woff);
            }
        }

        if (fadeAnim.getState()) {
            java.util.Set<Integer> alive = new java.util.HashSet<>();
            for (LivingEntity e : cachedTargets) alive.add(e.getId());
            fadeMap.keySet().retainAll(alive);
        }
    }

    private void spawnMode(Vec3d pos, double r, int cnt, double h, double yo, double tilt, double phOff) {
        switch (mode.getCurrentOption()) {
            case "Ring"      -> spawnRing(pos, r, cnt, yo + 0.1, phOff, tilt);
            case "Crown"     -> spawnRing(pos, r * 0.7, cnt, yo + h + 0.15, phOff, tilt);
            case "Orbit"     -> spawnOrbit(pos, r, cnt, yo + h / 2.0, phOff, tilt);
            case "Rain"      -> spawnRain(pos, r, cnt, h, yo);
            case "Pulse"     -> {
                double amp = pulseAmp.getValue();
                double pr = r * (1.0 - amp + amp * Math.abs(Math.sin(pulsePhase + phOff)));
                spawnRing(pos, pr, cnt, yo + 0.1, phOff, tilt);
            }
            case "DNA"       -> spawnDNA(pos, r, cnt, h, yo, phOff);
            case "Firework"  -> spawnFirework(pos, r, cnt, h, yo);
            case "Galaxy"    -> spawnGalaxy(pos, r, cnt, h, yo, phOff);
            case "Tornado"   -> spawnTornado(pos, r, cnt, h, yo, phOff);
            case "Cage"      -> spawnCage(pos, r, cnt, h, yo);
            case "Phoenix"   -> spawnPhoenix(pos, r, cnt, h, yo);
            case "Matrix"    -> spawnMatrix(pos, r, cnt, h, yo);
            case "Halo"      -> spawnHalo(pos, r, cnt, h, yo, phOff);
            case "Vortex"    -> spawnVortex(pos, r, cnt, h, yo, phOff);
            case "Reaper"    -> spawnReaper(pos, r, cnt, h, yo);
            case "Nova"      -> spawnNova(pos, r, cnt, h, yo);
            case "Lightning" -> spawnLightning(pos, r, cnt, h, yo);
            case "Snowstorm" -> spawnSnowstorm(pos, r, cnt, h, yo);
            case "Sakura"    -> spawnSakura(pos, r, cnt, h, yo);
            case "Comet"     -> spawnComet(pos, r, cnt, h, yo);
            case "Helix"     -> spawnHelix(pos, r, cnt, h, yo, phOff);
            case "Wave"      -> spawnWave(pos, r, cnt, h, yo, phOff);
            case "Burst"     -> spawnBurst(pos, r, cnt, h, yo);
        }
    }

    private void spawnHelix(Vec3d pos, double r, int cnt, double h, double yo, double phOff) {
        double wh = Math.max(waveHeight.getValue(), 0.5);
        for (int i = 0; i < cnt; i++) {
            double t = (double) i / cnt;
            double ang = helixPhase + phOff + t * Math.PI * 6;
            double y = pos.y + yo + (t * wh) % Math.max(h, 0.5);
            double rr = r * (0.5 + 0.5 * Math.sin(t * Math.PI));
            spawnAt(pos.x + Math.cos(ang) * rr, y, pos.z + Math.sin(ang) * rr);
        }
    }

    private void spawnWave(Vec3d pos, double r, int cnt, double h, double yo, double phOff) {
        double wh = waveHeight.getValue();
        for (int i = 0; i < cnt; i++) {
            double t = (double) i / cnt;
            double ang = wavePhase + phOff + t * Math.PI * 2;
            double yOsc = yo + h / 2.0 + Math.sin(wavePhase * 2 + t * Math.PI * 4) * wh * 0.5;
            double rr = r * (0.7 + 0.3 * Math.cos(t * Math.PI * 2));
            spawnAt(pos.x + Math.cos(ang) * rr, pos.y + yOsc, pos.z + Math.sin(ang) * rr);
        }
    }

    private void spawnBurst(Vec3d pos, double r, int cnt, double h, double yo) {
        double expansion = Math.pow(Math.sin(burstPhase / 2), 2);
        double cy = pos.y + yo + h / 2.0;
        double rr = r * 0.1 + r * 0.9 * expansion;
        for (int i = 0; i < cnt; i++) {
            double ang = (2 * Math.PI * i) / cnt + burstPhase * 0.3;
            spawnAt(pos.x + Math.cos(ang) * rr, cy, pos.z + Math.sin(ang) * rr);
        }
    }

    private void spawnRing(Vec3d c, double r, int count, double yOff, double phOff, double tilt) {
        for (int i = 0; i < count; i++) {
            double a = phOff + (2 * Math.PI * i) / count;
            double x = Math.cos(a) * r;
            double z = Math.sin(a) * r;
            spawnAt(c.x + x * Math.cos(tilt), c.y + yOff + x * Math.sin(tilt), c.z + z);
        }
    }

    private void spawnOrbit(Vec3d c, double r, int count, double yOff, double phOff, double tilt) {
        for (int i = 0; i < count; i++) {
            double a = orbitAngle + phOff + (2 * Math.PI * i) / count;
            double x = Math.cos(a) * r;
            double z = Math.sin(a) * r;
            spawnAt(c.x + x * Math.cos(tilt), c.y + yOff + x * Math.sin(tilt), c.z + z);
        }
    }

    private void spawnRain(Vec3d c, double r, int count, double h, double yo) {
        for (int i = 0; i < count; i++) {
            spawnAt(c.x + (Math.random() - 0.5) * r * 2, c.y + yo + h + 0.5, c.z + (Math.random() - 0.5) * r * 2);
        }
    }

    private void spawnDNA(Vec3d pos, double r, int count, double h, double yo, double phOff) {
        double wh = Math.max(waveHeight.getValue(), h);
        int steps = Math.max(count / 2, 4);
        for (int i = 0; i < steps; i++) {
            double t = (double) i / steps;
            double ang = dnaPhase + phOff + t * Math.PI * 3;
            double y = pos.y + yo + t * wh;
            spawnAt(pos.x + Math.cos(ang) * r, y, pos.z + Math.sin(ang) * r);
        }
    }

    private void spawnFirework(Vec3d pos, double r, int count, double h, double yo) {
        if (fwTimer >= 6) {
            fwTimer = 0;
            double bx = pos.x + (Math.random() - 0.5) * r * 2;
            double by = pos.y + yo + Math.random() * h;
            double bz = pos.z + (Math.random() - 0.5) * r * 2;
            for (int i = 0; i < count; i++) {
                if (mc.world != null) mc.world.addParticle(resolveParticle(), bx, by, bz, (Math.random()-0.5)*0.2, (Math.random()-0.5)*0.2, (Math.random()-0.5)*0.2);
            }
        }
    }

    private void spawnGalaxy(Vec3d pos, double r, int count, double h, double yo, double phOff) {
        double yC = pos.y + yo + h / 2.0;
        for (int i = 0; i < count; i++) {
            double a = galAngle + phOff + (2 * Math.PI * i) / count;
            spawnAt(pos.x + Math.cos(a) * r, yC, pos.z + Math.sin(a) * r);
        }
    }

    private void spawnTornado(Vec3d pos, double r, int cnt, double h, double yo, double phOff) {
        double wh = Math.max(waveHeight.getValue(), h);
        for (int i = 0; i < cnt; i++) {
            double t = (double) i / cnt;
            double a = tornAngle + phOff + t * Math.PI * 6;
            double rr = r * (1.0 - t * 0.7);
            spawnAt(pos.x + Math.cos(a) * rr, pos.y + yo + t * (wh + 0.5), pos.z + Math.sin(a) * rr);
        }
    }

    private void spawnCage(Vec3d pos, double r, int cnt, double h, double yo) {
        spawnRingOff(pos, r, cnt / 3, pos.y + yo + 0.1, cageAngle);
        spawnRingOff(pos, r, cnt / 3, pos.y + yo + h, cageAngle);
    }

    private void spawnPhoenix(Vec3d pos, double r, int cnt, double h, double yo) {
        double cy = pos.y + yo + h * 0.6;
        for (int i = 0; i < cnt / 2; i++) {
            double t = (double) i / (cnt / 2);
            double a = t * Math.PI * 0.8;
            spawnAt(pos.x + Math.cos(a) * r, cy, pos.z + Math.sin(a) * r);
        }
    }

    private void spawnMatrix(Vec3d pos, double r, int cnt, double h, double yo) {
        for (int c = 0; c < 5; c++) {
            double a = (2 * Math.PI * c) / 5;
            spawnAt(pos.x + Math.cos(a) * r, pos.y + yo + (tick * 0.1 % h), pos.z + Math.sin(a) * r);
        }
    }

    private void spawnHalo(Vec3d pos, double r, int cnt, double h, double yo, double phOff) {
        double haloY = pos.y + yo + h + 0.25;
        for (int i = 0; i < cnt; i++) {
            double a = orbitAngle * 0.5 + phOff + (2 * Math.PI * i) / cnt;
            spawnAt(pos.x + Math.cos(a) * r, haloY, pos.z + Math.sin(a) * r);
        }
    }

    private void spawnVortex(Vec3d pos, double r, int cnt, double h, double yo, double phOff) {
        for (int i = 0; i < cnt; i++) {
            double a = vortAngle + phOff + (2 * Math.PI * i) / cnt;
            spawnAt(pos.x + Math.cos(a) * r, pos.y + yo + 0.15, pos.z + Math.sin(a) * r);
        }
    }

    private void spawnReaper(Vec3d pos, double r, int cnt, double h, double yo) {
        double cy = pos.y + yo + h * 0.55;
        for (int i = 0; i < cnt; i++) {
            double a = reapAngle + (Math.PI * i / cnt);
            spawnAt(pos.x + Math.cos(a) * r, cy, pos.z + Math.sin(a) * r);
        }
    }

    private void spawnNova(Vec3d pos, double r, int cnt, double h, double yo) {
        double cy = pos.y + yo + h / 2.0;
        double amp = pulseAmp.getValue();
        double rr = r * (1.0 - amp + amp * Math.pow(Math.sin(novaPhase / 2), 2));
        for (int i = 0; i < cnt; i++) {
            double a = (2 * Math.PI * i) / cnt;
            spawnAt(pos.x + Math.cos(a) * rr, cy, pos.z + Math.sin(a) * rr);
        }
    }

    private void spawnLightning(Vec3d pos, double r, int cnt, double h, double yo) {
        for (int b = 0; b < 2; b++) {
            spawnAt(pos.x + (Math.random()-0.5)*r, pos.y + yo + Math.random()*h, pos.z + (Math.random()-0.5)*r);
        }
    }

    private void spawnSnowstorm(Vec3d pos, double r, int cnt, double h, double yo) {
        for (int i = 0; i < cnt / 2; i++) {
            spawnAt(pos.x + (Math.random()-0.5)*r*2, pos.y + yo + h, pos.z + (Math.random()-0.5)*r*2);
        }
    }

    private void spawnSakura(Vec3d pos, double r, int cnt, double h, double yo) {
        for (int i = 0; i < cnt / 2; i++) {
            spawnAt(pos.x + (Math.random()-0.5)*r*2, pos.y + yo + h, pos.z + (Math.random()-0.5)*r*2);
        }
    }

    private void spawnComet(Vec3d pos, double r, int cnt, double h, double yo) {
        double head = cometAngle * 2.5;
        spawnAt(pos.x + Math.cos(head) * r, pos.y + yo + h / 2.0, pos.z + Math.sin(head) * r);
    }

    private void spawnRingOff(Vec3d c, double r, int count, double y, double off) {
        for (int i = 0; i < count; i++) {
            double a = off + (2 * Math.PI * i) / count;
            spawnAt(c.x + Math.cos(a) * r, y, c.z + Math.sin(a) * r);
        }
    }

    private void spawnAt(double x, double y, double z) {
        if (mc.world == null) return;
        mc.world.addParticle(resolveParticle(), x, y, z, 0, 0.01, 0);
    }

    private net.minecraft.particle.ParticleEffect resolveParticle() {
        String cm = colorMode.getCurrentOption();
        float r, g, b;

        if (cm.equals("Rainbow") || cm.equals("Shift")) {
            float[] rgbArr = hsvToRgb((float) colorHue);
            r = rgbArr[0]; g = rgbArr[1]; b = rgbArr[2];
        } else if (cm.equals("Pulse")) {
            float bright = (float)(0.5 + 0.5 * Math.sin(pulsePhase));
            r = bright; g = bright * 0.8f; b = 1.0f;
        } else {
            r = (float)(colorR.getValue() / 255.0);
            g = (float)(colorG.getValue() / 255.0);
            b = (float)(colorB.getValue() / 255.0);
        }

        int argb = 0xFF000000 | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);

        String typeStr = ptype.getCurrentOption();
        if (typeStr.equals("Custom Color")) {
            return new DustParticleEffect(argb, (float) dustSize.getValue());
        }

        return switch (typeStr) {
            case "Portal"        -> ParticleTypes.PORTAL;
            case "End Rod"       -> ParticleTypes.END_ROD;
            case "Flame"         -> ParticleTypes.FLAME;
            case "Soul"          -> ParticleTypes.SOUL;
            case "Crit"          -> ParticleTypes.CRIT;
            case "Witch"         -> ParticleTypes.WITCH;
            case "Snowflake"     -> ParticleTypes.SNOWFLAKE;
            case "Electric"      -> ParticleTypes.ELECTRIC_SPARK;
            case "Cherry"        -> ParticleTypes.CHERRY_LEAVES;
            case "Dragon Breath" -> ParticleTypes.DRAGON_BREATH;
            default              -> ParticleTypes.ENCHANT;
        };
    }

    private float[] hsvToRgb(float hue) {
        float h = hue / 60f;
        float x = 1f - Math.abs(h % 2 - 1);
        if      (h < 1) return new float[]{1f, x,  0f};
        else if (h < 2) return new float[]{x,  1f, 0f};
        else if (h < 3) return new float[]{0f, 1f, x };
        else if (h < 4) return new float[]{0f, x,  1f};
        else if (h < 5) return new float[]{x,  0f, 1f};
        else            return new float[]{1f, 0f, x };
    }

    private void collectRangeTargets() {
        if (mc.player == null || mc.world == null) return;
        Vec3d pp = mc.player.getPos();
        List<LivingEntity> found = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player) || !living.isAlive()) continue;
            if (!targetFilter.passes(living)) continue;
            if (!targetRange.inRange(living, mc.player)) continue;
            if (!hpFilter.passes(living)) continue;
            found.add(living);
        }
        found.sort((a, b) -> Double.compare(a.getPos().distanceTo(pp), b.getPos().distanceTo(pp)));
        cachedTargets.addAll(maxTargets.limit(found));
    }

    private LivingEntity getCrosshairTarget() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            Entity e = hit.getEntity();
            if (e instanceof LivingEntity living && !living.equals(mc.player)) {
                if (!targetFilter.passes(living)) return null;
                if (!hpFilter.passes(living)) return null;
                return living;
            }
        }
        return null;
    }
}