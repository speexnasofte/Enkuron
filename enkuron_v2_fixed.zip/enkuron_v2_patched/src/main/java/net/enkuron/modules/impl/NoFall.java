package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * NoFall — защита от урона при падении.
 *
 * Настройки:
 *   Режим         — Packet (обманываем сервер) / Cancel (отменяем урон клиентски)
 *   Мин. высота   — с какой высоты падения включать защиту (1–10 блоков)
 */
public class NoFall extends Module {

    private static final String[] MODES = {"Packet", "Cancel"};

    private final Setting mode      = new Setting("Режим",        MODES, 0);
    private final Setting minHeight = new Setting("Мин. высота",  2.0, 1.0, 10.0);

    public NoFall() {
        super("NoFall", "Отключает урон от падения", Category.MOVEMENT);
        addSetting(mode);
        addSetting(minHeight);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        float minH = (float) minHeight.getValue();
        if (mc.player.fallDistance <= minH || mc.player.getVelocity().y > 0) return;

        switch (mode.getCurrentOption()) {
            case "Packet" -> mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.OnGroundOnly(true, false));
            case "Cancel" -> mc.player.fallDistance = 0;
        }
    }
}
