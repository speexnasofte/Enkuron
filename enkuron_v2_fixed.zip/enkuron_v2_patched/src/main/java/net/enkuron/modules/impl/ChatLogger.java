package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ChatLogger — сохраняет сообщения чата в файл.
 *
 * Настройки:
 *   Логировать системные — включает системные сообщения (смерть, достижения)
 *   Timestamp           — добавлять время к каждому сообщению
 *   Только игроки       — только сообщения от игроков (игнорировать сервер)
 */
public class ChatLogger extends Module {

    private final Setting logSystem   = new Setting("Системные сообщения", false);
    private final Setting timestamp   = new Setting("Время в логе",        true);
    private final Setting playersOnly = new Setting("Только игроки",       false);

    private static final String LOG_FILE = "enkuron_chat.log";
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("HH:mm:ss");

    public ChatLogger() {
        super("ChatLogger", "Сохраняет чат в файл enkuron_chat.log", Category.UTILITY);
        addSetting(logSystem);
        addSetting(timestamp);
        addSetting(playersOnly);
    }

    /**
     * Вызывается из Mixin чата при получении нового сообщения.
     * @param raw  сырой текст сообщения (без форматирования)
     * @param isSystem  true если это системное сообщение сервера
     */
    public void onChatMessage(String raw, boolean isSystem) {
        if (!isEnabled()) return;
        if (isSystem && !logSystem.getState()) return;

        // Простая эвристика: если нет "<" — скорее всего системное
        if (playersOnly.getState() && !raw.contains("<")) return;

        String line = timestamp.getState()
                ? "[" + LocalDateTime.now().format(FMT) + "] " + raw
                : raw;

        try (FileWriter fw = new FileWriter(LOG_FILE, true)) {
            fw.write(line + "\n");
        } catch (IOException ignored) {}
    }

    @Override
    public void onEnable() {
        // Создаём заголовок сессии в файле
        try (FileWriter fw = new FileWriter(LOG_FILE, true)) {
            fw.write("\n--- Session " +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
                    " ---\n");
        } catch (IOException ignored) {}
    }
}
