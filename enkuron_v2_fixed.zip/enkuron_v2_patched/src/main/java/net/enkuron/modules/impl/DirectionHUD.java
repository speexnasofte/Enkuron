package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * DirectionHUD — компактный HUD со стрелками сторон света.
 *
 * Показывает N / NE / E / SE / S / SW / W / NW стрелки,
 * текущее направление подсвечено ярче.
 *
 * Настройки:
 *   Показывать градусы — BOOLEAN
 *   Стиль             — Arrows / Text / Both
 */
public class DirectionHUD extends Module {

    private static final String[] DIRS   = {"N","NE","E","SE","S","SW","W","NW"};
    private static final String[] ARROWS = {"↑","↗","→","↘","↓","↙","←","↖"};
    private static final String[] STYLES = {"Arrows", "Text", "Both"};

    private final Setting showDeg = new Setting("Показывать градусы", true);
    private final Setting style   = new Setting("Стиль", STYLES, 2);

    public DirectionHUD() {
        super("DirectionHUD", "Показывает стороны света и направление взгляда", Category.HUD);
        addSetting(showDeg);
        addSetting(style);
        this.x = 80;
        this.y = 5;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        float yaw = mc.player.getYaw();
        // Нормализуем yaw в 0–360
        float deg = ((yaw % 360) + 360) % 360;
        // Minecraft: 0=юг, 90=запад, 180=север, 270=восток
        // Переводим в "обычный" индекс направлений (0=север)
        int dirIndex = (int)((deg + 22.5f) / 45f) % 8;
        // Скорректируем: MC 0° = S → наш индекс
        // MC: S=0, SW=45, W=90, NW=135, N=180, NE=225, E=270, SE=315
        int mcDirIndex = ((dirIndex + 4) % 8); // сдвиг чтобы 0=N

        // Фон
        int totalW = 90;
        context.fill(x - 2, y - 2, x + totalW, y + 20, 0xBB111116);
        context.fill(x - 2, y - 2, x + totalW, y - 1,  0xFF9944FF);

        // Текущее направление текстом
        String dirName  = DIRS[mcDirIndex];
        String arrow    = ARROWS[mcDirIndex];
        String degStr   = showDeg.getState() ? String.format(" %.0f°", deg) : "";
        String styleOpt = style.getCurrentOption();

        String line1 = switch (styleOpt) {
            case "Arrows" -> arrow + degStr;
            case "Text"   -> dirName + degStr;
            default       -> arrow + " " + dirName + degStr;
        };

        context.drawText(mc.textRenderer, "§b" + line1, x + 2, y + 2, 0xFFBBBBFF, true);

        // Мини-компас: все 8 направлений, текущее подсвечено
        int dx = x + 2;
        for (int i = 0; i < 8; i++) {
            String sym = styleOpt.equals("Text") ? DIRS[i] : ARROWS[i];
            int color  = (i == mcDirIndex) ? 0xFF88FFFF : 0xFF555566;
            context.drawText(mc.textRenderer, sym, dx, y + 11, color, false);
            dx += mc.textRenderer.getWidth(sym) + 2;
        }
    }
}
