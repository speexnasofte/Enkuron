package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

public class AutoRespawn extends Module {
    private final Setting delay = new Setting("Задержка (тики)", 0.0, 0.0, 20.0);
    private int waitTick = 0;

    public AutoRespawn() {
        super("AutoRespawn", "Мгновенное возрождение", Category.UTILITY);
        addSetting(delay);
    }

    @Override
    public void onTick() {
        if (mc.player == null || !mc.player.isDead()) { waitTick = 0; return; }
        if (waitTick++ >= (int) delay.getValue()) {
            mc.player.requestRespawn();
            // FIX: сбрасываем в большое число чтобы не вызывать requestRespawn каждый тик
            // пока игрок ещё числится мёртвым (смерть обрабатывается несколько тиков)
            waitTick = Integer.MIN_VALUE / 2;
        }
    }
}
