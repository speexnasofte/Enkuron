package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

public class ArrayList extends Module {

    private static final String[] POSITIONS   = {"TOP_RIGHT", "TOP_LEFT", "BOTTOM_RIGHT", "BOTTOM_LEFT"};
    private static final String[] COLOR_MODES = {"Gradient", "Rainbow", "Solid", "Theme"};
    private static final String[] SORT_MODES  = {"Length", "Alphabet", "Category"};
    private static final String[] SUFFIX_OPTS = {"None", "FPS", "HP", "FPS+HP"};

    private final Setting position   = new Setting("Позиция",     POSITIONS,   0);
    private final Setting colorMode  = new Setting("Цвет",        COLOR_MODES, 0);
    private final Setting sortMode   = new Setting("Сортировка",  SORT_MODES,  0);
    private final Setting suffix     = new Setting("Суффикс",     SUFFIX_OPTS, 0);
    private final Setting showTag    = new Setting("Иконка кат.", true);
    private final Setting bgAlpha    = new Setting("Прозрач. фона", 130.0, 0.0, 255.0);
    private final Setting gradR      = new Setting("Gradient R",  100.0, 0.0, 255.0);
    private final Setting gradG      = new Setting("Gradient G",  160.0, 0.0, 255.0);
    private final Setting gradB      = new Setting("Gradient B",  255.0, 0.0, 255.0);

    private static final Map<Category, String> CAT_ICON = new EnumMap<>(Category.class);
    static {
        CAT_ICON.put(Category.COMBAT,   "⚔");
        CAT_ICON.put(Category.MOVEMENT, "⚡");
        CAT_ICON.put(Category.VISUAL,   "✦");
        CAT_ICON.put(Category.PLAYER,   "♟");
        CAT_ICON.put(Category.HUD,      "◈");
        CAT_ICON.put(Category.MISC,     "★");
        CAT_ICON.put(Category.UTILITY,  "⚙");
    }

    private final Map<String, Float> slideAnims = new LinkedHashMap<>();
    private final Map<String, Float> rowYAnims  = new LinkedHashMap<>();
    private final Map<String, Integer> widthCache = new HashMap<>();

    private float rainbowPhase = 0f;

    public ArrayList() {
        super("ArrayList", "Премиум HUD список активных модулей v2", Category.HUD);
        addSetting(position);
        addSetting(colorMode);
        addSetting(sortMode);
        addSetting(suffix);
        addSetting(showTag);
        addSetting(bgAlpha);
        addSetting(gradR);
        addSetting(gradG);
        addSetting(gradB);
    }

    @Override
    public void onTick() {
        rainbowPhase = (rainbowPhase + 0.008f) % 1f;
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || mc.player == null) return;

        int sw  = mc.getWindow().getScaledWidth();
        int sh  = mc.getWindow().getScaledHeight();
        String pos = position.getCurrentOption();
        boolean right  = pos.contains("RIGHT");
        boolean bottom = pos.contains("BOTTOM");

        List<Module> enabled = ModuleManager.getModules().stream()
            .filter(m -> m.isEnabled() && m != this)
            .sorted(getSorter())
            .toList();

        Set<String> enabledNames = new HashSet<>();
        for (Module m : enabled) enabledNames.add(m.getName());

        slideAnims.keySet().removeIf(name -> !enabledNames.contains(name));
        rowYAnims.keySet().removeIf(name -> !enabledNames.contains(name));

        for (Module m : ModuleManager.getModules()) {
            String name = m.getName();
            if (name.equals(this.getName())) continue;
            float target = enabledNames.contains(name) ? 0f : 1f;
            float cur    = slideAnims.getOrDefault(name, target);
            slideAnims.put(name, AnimationUtils.clamp(AnimationUtils.lerp(cur, target, 0.15f), 0f, 1f));
        }

        int lineH   = 12;
        int totalH  = enabled.size() * lineH;
        int originY = bottom ? (sh - totalH - 4) : 4;

        for (int i = 0; i < enabled.size(); i++) {
            Module mod    = enabled.get(i);
            float targetY = (float) (originY + (bottom ? (enabled.size() - 1 - i) * lineH : i * lineH));
            rowYAnims.putIfAbsent(mod.getName(), targetY);
            float curY = rowYAnims.get(mod.getName());
            rowYAnims.put(mod.getName(), AnimationUtils.lerp(curY, targetY, 0.12f));
        }

        String sfx = buildSuffix();

        for (int i = 0; i < enabled.size(); i++) {
            Module mod   = enabled.get(i);
            String name  = mod.getName();
            String icon  = showTag.getState() ? (CAT_ICON.getOrDefault(mod.getCategory(), "") + " ") : "";
            String label = icon + name + sfx;

            int textW  = mc.textRenderer.getWidth(label);
            int pad    = 4;
            int boxW   = textW + pad * 2;

            float slideT   = slideAnims.getOrDefault(name, 0f);
            int   slideOff = (int)(slideT * (boxW + 6));
            int   drawX    = right ? (sw - boxW - 2 + slideOff) : (2 - slideOff);
            int   drawY    = (int) ((float) rowYAnims.getOrDefault(name, (float)(originY + i * lineH)));

            int accent = resolveColor(i, enabled.size());

            int shadowBg = EnkuronColor.toARGB(0, 0, 0, (int)(bgAlpha.getValue() * 0.45f));
            ctx.fill(drawX - 1, drawY - 1, drawX + boxW + 1, drawY + lineH + 1, shadowBg);
            ctx.fill(drawX, drawY, drawX + boxW, drawY + lineH, EnkuronColor.toARGB(8, 8, 13, (int) bgAlpha.getValue()));

            int solid = 0xFF000000 | (accent & 0xFFFFFF);
            if (right) ctx.fill(drawX + boxW - 1, drawY, drawX + boxW, drawY + lineH, solid);
            else       ctx.fill(drawX, drawY, drawX + 1, drawY + lineH, solid);

            int tx = right ? (drawX + pad) : (drawX + (showTag.getState() ? 6 : pad));
            int ty = drawY + 2;

            ctx.drawText(mc.textRenderer, icon + name, tx, ty, 0xFF000000 | accent, false);

            if (!sfx.isEmpty()) {
                int mainW = mc.textRenderer.getWidth(icon + name);
                ctx.drawText(mc.textRenderer, sfx, tx + mainW, ty, 0xFFAAAAAA, false);
            }
        }
    }

    private String buildSuffix() {
        if (mc.player == null) return "";
        String mode = suffix.getCurrentOption();
        if (mode.equals("None")) return "";
        StringBuilder sb = new StringBuilder();
        if (mode.contains("FPS")) sb.append(" ").append(mc.getCurrentFps()).append("fps");
        if (mode.contains("HP"))  sb.append(" ").append((int) mc.player.getHealth()).append("hp");
        return sb.toString();
    }

    private Comparator<Module> getSorter() {
        if ("Length".equals(sortMode.getCurrentOption())) {
            widthCache.clear();
            for (Module m : ModuleManager.getModules()) {
                widthCache.put(m.getName(), mc.textRenderer.getWidth(m.getName()));
            }
            return Comparator.comparingInt((Module m) -> widthCache.getOrDefault(m.getName(), 0)).reversed();
        }
        return switch (sortMode.getCurrentOption()) {
            case "Alphabet" -> Comparator.comparing(Module::getName);
            case "Category" -> Comparator.comparing(m -> m.getCategory().name());
            default         -> Comparator.comparingInt((Module m) -> mc.textRenderer.getWidth(m.getName())).reversed();
        };
    }

    private int resolveColor(int index, int total) {
        Theme t = ThemeManager.get();
        if (t == null) return 0x64B4FF;

        return switch (colorMode.getCurrentOption()) {
            case "Rainbow" -> {
                float hue = (rainbowPhase + index * (0.65f / Math.max(total, 1))) % 1f;
                java.awt.Color c = java.awt.Color.getHSBColor(hue, 0.85f, 1f);
                yield (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
            }
            case "Gradient" -> {
                int r1 = (int) gradR.getValue();
                int g1 = (int) gradG.getValue();
                int b1 = (int) gradB.getValue();
                float f = total > 1 ? (float) index / (total - 1) : 0f;
                yield ((int)(r1 * (1f - f * 0.55f)) << 16) | ((int)(g1 * (1f - f * 0.55f)) << 8) | (int)(b1 * (1f - f * 0.55f));
            }
            case "Solid" -> t.accent & 0xFFFFFF;
            default -> t.accent;
        };
    }
}