package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class ChestStealer extends Module {
    private final Setting delay       = new Setting("Задержка (мс)",   50.0, 0.0, 200.0);
    private final Setting leaveHotbar = new Setting("Оставить хотбар", false);

    private long lastStealTime = 0;

    public ChestStealer() {
        super("ChestStealer", "Быстро забирает вещи из сундуков", Category.MISC);
        addSetting(delay);
        addSetting(leaveHotbar);
    }

    @Override
    public void onEnable() { lastStealTime = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof GenericContainerScreen screen)) return;
        if (!(screen.getScreenHandler() instanceof GenericContainerScreenHandler handler)) return;

        long now = System.currentTimeMillis();
        if (now - lastStealTime < (long) delay.getValue()) return;
        lastStealTime = now;

        int containerSlots = handler.getRows() * 9;
        // Берём первый непустой слот из сундука через shift-click
        for (int i = 0; i < containerSlots; i++) {
            var slot = handler.getSlot(i);
            if (!slot.hasStack()) continue;
            // Если leaveHotbar — не берём вещи, если инвентарь полон (хотбар занят)
            if (leaveHotbar.getState()) {
                boolean hotbarFull = true;
                // FIX: хотбар = слоты 36-44 (9 штук, < 45 правильно), слот 45 = оффхенд
                // Проверяем слоты рюкзака (9-35) а не только хотбар для корректной логики
                for (int h = 9; h < 45; h++) {
                    if (!handler.getSlot(h).hasStack()) { hotbarFull = false; break; }
                }
                if (hotbarFull) return;
            }
            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            return; // один слот за тик с задержкой
        }
    }
}
