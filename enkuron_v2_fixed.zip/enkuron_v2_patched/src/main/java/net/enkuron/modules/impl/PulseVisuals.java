package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.visual.PulseManager;
import net.enkuron.visual.TrailEffect;

/**
 * PulseVisuals v3 — 50+ настроек.
 *
 * ══ ПУЛЬС-ВОЛНЫ ══
 *  • Тип эффекта — Ring / Star / Spiral / Hex / Shockwave / Grid
 *  • Цветовой режим — Статичный / Радуга / Пульс / Огонь / Лёд
 *  • Цвет R / G / B (ручной)
 *  • Прозрачность волны
 *  • Скорость расширения (lifetime в мс)
 *  • Высота волны Shockwave
 *  • Двойная волна (вторая со смещением)
 *  • Тип второй волны
 *  • Смещение по фазе 2-й волны
 *  • Инверт цвет 2-й волны
 *  • Цвет R/G/B второй волны (независимо)
 *  • Масштаб волны по HP (чем ниже HP — шире волна)
 *  • Макс. одновременных эффектов
 *  • Вращающаяся волна (rotation per tick)
 *
 * ══ ТРИГГЕРЫ ══
 *  • Пульс при спринте
 *  • Интервал спринта (тики)
 *  • Пульс при прыжке
 *  • Интервал прыжка (тики)
 *  • Пульс при приземлении
 *  • Пульс при атаке (нажатие ЛКМ)
 *  • Пульс в воде (каждые N тиков)
 *  • Пульс в лаве
 *  • Только при невидимости
 *  • Только при спринте (глобальный фильтр)
 *  • Только при низком HP
 *  • Порог низкого HP для триггера
 *  • Пульс при смене слота хотбара
 *
 * ══ СЛЕД ══
 *  • Включить след
 *  • Стиль следа — Ribbon / Line / Dots / Flames / Laser
 *  • Ширина следа
 *  • Длина следа (количество точек)
 *  • Радуга следа
 *  • Цвет следа R / G / B
 *  • Обновление следа (каждые N тиков)
 *  • Мин. скорость для след
 *  • Высота следа (Y-смещение от ног)
 *  • Мигание следа
 *  • Частота мигания
 *  • След при прыжке
 *  • След в воде
 *  • Яркость следа (alpha multiplier)
 *
 * ══ ОБЩИЕ ══
 *  • Скрыть в инвентаре
 *  • Счётчик активных эффектов (debug)
 */
public class PulseVisuals extends Module {

    // ── Типы / стили ──────────────────────────────────────────────────────────
    private static final String[] EFFECT_TYPES = {"Ring", "Star", "Spiral", "Hex", "Shockwave", "Grid"};
    private static final String[] COLOR_MODES  = {"Статичный", "Радуга", "Пульс", "Огонь", "Лёд"};
    private static final String[] TRAIL_STYLES = {"Ribbon", "Line", "Dots", "Flames", "Laser"};

    // ══════════════════════════════════════════════════════════════════════════
    // ПУЛЬС — внешний вид
    // ══════════════════════════════════════════════════════════════════════════
    private final Setting effectType      = new Setting("Тип эффекта",              EFFECT_TYPES, 0);
    private final Setting colorMode       = new Setting("Цветовой режим",            COLOR_MODES,  1);
    private final Setting colorR          = new Setting("Цвет R",                    160.0, 0.0, 255.0);
    private final Setting colorG          = new Setting("Цвет G",                    0.0,   0.0, 255.0);
    private final Setting colorB          = new Setting("Цвет B",                    255.0, 0.0, 255.0);
    private final Setting pulseAlpha      = new Setting("Прозрачность волны",        0.85,  0.1,  1.0);
    private final Setting pulseLifetime   = new Setting("Скорость расширения (мс)",  800.0, 200.0, 2000.0);
    private final Setting pulseHeight     = new Setting("Высота Shockwave",          0.4,   0.05,  2.0);
    private final Setting maxEffects      = new Setting("Макс. эффектов",            32.0,  8.0,  64.0);

    // ══════════════════════════════════════════════════════════════════════════
    // ПУЛЬС — двойная волна
    // ══════════════════════════════════════════════════════════════════════════
    private final Setting doubleWave      = new Setting("Двойная волна",             false);
    private final Setting wave2Type       = new Setting("Тип 2-й волны",             EFFECT_TYPES, 3);
    private final Setting waveOffset      = new Setting("Задержка 2-й волны (тики)", 5.0, 1.0, 20.0);
    private final Setting wave2Invert     = new Setting("Инверт цвет 2-й волны",     true);
    private final Setting wave2R          = new Setting("Цвет 2-й волны R",          255.0, 0.0, 255.0);
    private final Setting wave2G          = new Setting("Цвет 2-й волны G",          160.0, 0.0, 255.0);
    private final Setting wave2B          = new Setting("Цвет 2-й волны B",          0.0,   0.0, 255.0);

    // ══════════════════════════════════════════════════════════════════════════
    // ПУЛЬС — триггеры
    // ══════════════════════════════════════════════════════════════════════════
    private final Setting pulseOnSprint   = new Setting("Пульс при спринте",         true);
    private final Setting sprintInterval  = new Setting("Интервал спринта (тики)",   10.0,  2.0, 40.0);
    private final Setting pulseOnJump     = new Setting("Пульс при прыжке",          true);
    private final Setting jumpInterval    = new Setting("Интервал прыжка (тики)",    6.0,   2.0, 20.0);
    private final Setting pulseOnLand     = new Setting("Пульс при приземлении",     true);
    private final Setting pulseOnHit      = new Setting("Пульс при атаке (ЛКМ)",     false);
    private final Setting pulseInWater    = new Setting("Пульс в воде",              false);
    private final Setting waterInterval   = new Setting("Интервал воды (тики)",      15.0,  5.0, 40.0);
    private final Setting pulseInLava     = new Setting("Пульс в лаве",              false);
    private final Setting lavaInterval    = new Setting("Интервал лавы (тики)",      10.0,  5.0, 40.0);
    private final Setting onlyInvisible   = new Setting("Только при невидимости",    false);
    private final Setting onlySprinting   = new Setting("Только при спринте (глоб.)",false);
    private final Setting pulseOnLowHp    = new Setting("Пульс при низком HP",       false);
    private final Setting lowHpThreshold  = new Setting("Порог низкого HP",          8.0,   1.0, 18.0);
    private final Setting pulseOnSlotChange = new Setting("Пульс при смене слота",   false);
    private final Setting hpScale         = new Setting("Масштаб волны по HP",       false);

    // ══════════════════════════════════════════════════════════════════════════
    // СЛЕД — внешний вид
    // ══════════════════════════════════════════════════════════════════════════
    private final Setting trailEnabled    = new Setting("Включить след",             true);
    private final Setting trailStyle      = new Setting("Стиль следа",              TRAIL_STYLES, 0);
    private final Setting trailWidth      = new Setting("Ширина следа",              1.0,  0.5,  3.0);
    private final Setting trailLength     = new Setting("Длина следа (точки)",       20.0, 5.0,  60.0);
    private final Setting trailRainbow    = new Setting("Радуга следа",              true);
    private final Setting trailR          = new Setting("Цвет следа R",              255.0, 0.0, 255.0);
    private final Setting trailG          = new Setting("Цвет следа G",              80.0,  0.0, 255.0);
    private final Setting trailB_         = new Setting("Цвет следа B",              255.0, 0.0, 255.0);
    private final Setting trailBrightness = new Setting("Яркость следа",             0.8,  0.1,  1.0);
    private final Setting trailYOffset    = new Setting("Высота следа (Y-смещ.)",   0.05,  0.0,  1.0);

    // СЛЕД — поведение
    private final Setting trailUpdateEvery = new Setting("Обновление следа (тики)", 1.0,  1.0,  5.0);
    private final Setting trailMinSpeed   = new Setting("Мин. скорость для следа",  0.05, 0.01, 0.5);
    private final Setting trailOnJump     = new Setting("След в прыжке",             true);
    private final Setting trailInWater    = new Setting("След в воде",               false);
    private final Setting trailBlink      = new Setting("Мигание следа",             false);
    private final Setting trailBlinkFreq  = new Setting("Частота мигания (тики)",    10.0, 2.0, 30.0);

    // ══════════════════════════════════════════════════════════════════════════
    // ОБЩИЕ
    // ══════════════════════════════════════════════════════════════════════════
    private final Setting hideInInventory = new Setting("Скрыть в инвентаре",       true);
    private final Setting showDebugCount  = new Setting("Счётчик эффектов (debug)", false);

    // ══════════════════════════════════════════════════════════════════════════
    // Внутреннее состояние
    // ══════════════════════════════════════════════════════════════════════════
    private boolean wasOnGround   = true;
    private boolean wasAttacking  = false;
    private int     prevHotSlot   = -1;
    private int     sprintTick    = 0, jumpTick = 0;
    private int     waterTick     = 0, lavaTick = 0;
    private int     trailTick     = 0, blinkTick = 0;
    private boolean blinkVisible  = true;
    private int     wave2DelayTick = 0;
    private boolean wave2Pending  = false;

    // ══════════════════════════════════════════════════════════════════════════

    public PulseVisuals() {
        super("PulseVisuals", "Неоновые волны и след при движении (50+ настроек)", Category.VISUAL);

        // Волна — вид
        addSetting(effectType);     addSetting(colorMode);
        addSetting(colorR);         addSetting(colorG);          addSetting(colorB);
        addSetting(pulseAlpha);     addSetting(pulseLifetime);   addSetting(pulseHeight);
        addSetting(maxEffects);

        // Двойная волна
        addSetting(doubleWave);     addSetting(wave2Type);
        addSetting(waveOffset);     addSetting(wave2Invert);
        addSetting(wave2R);         addSetting(wave2G);          addSetting(wave2B);

        // Триггеры
        addSetting(pulseOnSprint);  addSetting(sprintInterval);
        addSetting(pulseOnJump);    addSetting(jumpInterval);
        addSetting(pulseOnLand);    addSetting(pulseOnHit);
        addSetting(pulseInWater);   addSetting(waterInterval);
        addSetting(pulseInLava);    addSetting(lavaInterval);
        addSetting(onlyInvisible);  addSetting(onlySprinting);
        addSetting(pulseOnLowHp);   addSetting(lowHpThreshold);
        addSetting(pulseOnSlotChange);
        addSetting(hpScale);

        // След
        addSetting(trailEnabled);   addSetting(trailStyle);
        addSetting(trailWidth);     addSetting(trailLength);
        addSetting(trailRainbow);
        addSetting(trailR);         addSetting(trailG);          addSetting(trailB_);
        addSetting(trailBrightness); addSetting(trailYOffset);
        addSetting(trailUpdateEvery); addSetting(trailMinSpeed);
        addSetting(trailOnJump);    addSetting(trailInWater);
        addSetting(trailBlink);     addSetting(trailBlinkFreq);

        // Общие
        addSetting(hideInInventory);
        addSetting(showDebugCount);
    }

    @Override
    public void onEnable() {
        if (mc.player != null) {
            wasOnGround  = mc.player.isOnGround();
            prevHotSlot  = mc.player.getInventory().selectedSlot;
        }
        wasAttacking = false;
        sprintTick = jumpTick = waterTick = lavaTick = trailTick = blinkTick = 0;
        wave2Pending = false; wave2DelayTick = 0;
        blinkVisible = true;
        PulseManager.clear();
        TrailEffect.clear();
    }

    @Override
    public void onDisable() {
        PulseManager.clear();
        TrailEffect.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (hideInInventory.getState() && mc.currentScreen != null) return;
        if (onlyInvisible.getState() && !mc.player.isInvisible()) return;
        if (onlySprinting.getState() && !mc.player.isSprinting()) return;

        boolean grounded  = mc.player.isOnGround();
        boolean inWater   = mc.player.isSubmergedInWater();
        boolean inLava    = mc.player.isInLava();
        boolean sprinting = mc.player.isSprinting();
        boolean attacking = mc.options.attackKey.isPressed();
        int     hotSlot   = mc.player.getInventory().selectedSlot;
        float   hp        = mc.player.getHealth();
        float   maxHp     = mc.player.getMaxHealth();

        // ── Спринт ───────────────────────────────────────────────────────────
        if (pulseOnSprint.getState() && sprinting && !inWater && !inLava) {
            sprintTick++;
            if (sprintTick >= (int) sprintInterval.getValue()) {
                sprintTick = 0;
                spawnPulse(effectType.getSelectedIndex(), false);
            }
        } else if (!sprinting) {
            sprintTick = 0;
        }

        // ── Прыжок (в момент отрыва) ─────────────────────────────────────────
        if (pulseOnJump.getState()) {
            jumpTick++;
            if (!grounded && wasOnGround && mc.player.getVelocity().y > 0
                    && jumpTick >= (int) jumpInterval.getValue()) {
                jumpTick = 0;
                spawnPulse(effectType.getSelectedIndex(), false);
            }
        }

        // ── Приземление ──────────────────────────────────────────────────────
        if (pulseOnLand.getState() && grounded && !wasOnGround) {
            spawnPulse(effectType.getSelectedIndex(), false);
            if (effectType.getSelectedIndex() != 4)
                spawnPulse(4, false); // + Shockwave при приземлении
        }

        // ── Атака ────────────────────────────────────────────────────────────
        if (pulseOnHit.getState() && attacking && !wasAttacking) {
            spawnPulse(effectType.getSelectedIndex(), false);
        }

        // ── Вода ─────────────────────────────────────────────────────────────
        if (pulseInWater.getState() && inWater) {
            waterTick++;
            if (waterTick >= (int) waterInterval.getValue()) {
                waterTick = 0;
                spawnPulse(0, false); // Ring в воде
            }
        } else { waterTick = 0; }

        // ── Лава ─────────────────────────────────────────────────────────────
        if (pulseInLava.getState() && inLava) {
            lavaTick++;
            if (lavaTick >= (int) lavaInterval.getValue()) {
                lavaTick = 0;
                spawnPulse(4, false); // Shockwave в лаве
            }
        } else { lavaTick = 0; }

        // ── Низкое HP ────────────────────────────────────────────────────────
        if (pulseOnLowHp.getState() && hp <= (float) lowHpThreshold.getValue()
                && mc.player.age % 20 == 0) {
            spawnPulse(effectType.getSelectedIndex(), false);
        }

        // ── Смена слота хотбара ───────────────────────────────────────────────
        if (pulseOnSlotChange.getState() && hotSlot != prevHotSlot) {
            spawnPulse(effectType.getSelectedIndex(), false);
        }

        // ── Двойная волна с задержкой ─────────────────────────────────────────
        if (wave2Pending) {
            wave2DelayTick++;
            if (wave2DelayTick >= (int) waveOffset.getValue()) {
                wave2Pending = false;
                wave2DelayTick = 0;
                spawnPulse(wave2Type.getSelectedIndex(), true);
            }
        }

        // ── Обновление состояний ──────────────────────────────────────────────
        wasOnGround  = grounded;
        wasAttacking = attacking;
        prevHotSlot  = hotSlot;

        // ── След ─────────────────────────────────────────────────────────────
        if (trailEnabled.getState()) {
            if (trailBlink.getState()) {
                blinkTick++;
                if (blinkTick >= (int) trailBlinkFreq.getValue()) {
                    blinkTick = 0;
                    blinkVisible = !blinkVisible;
                }
            } else {
                blinkVisible = true;
            }

            if (blinkVisible) {
                trailTick++;
                if (trailTick >= (int) trailUpdateEvery.getValue()) {
                    trailTick = 0;
                    double spd = mc.player.getVelocity().horizontalLength();
                    boolean fast   = spd > trailMinSpeed.getValue();
                    boolean inAir  = !grounded;
                    boolean useJump = trailOnJump.getState() && inAir;
                    boolean useWater = trailInWater.getState() && inWater;

                    if (fast || useJump || useWater) {
                        TrailEffect.configure(
                            trailStyle.getSelectedIndex(),
                            (float) trailWidth.getValue(),
                            (int) trailR.getValue(),
                            (int) trailG.getValue(),
                            (int) trailB_.getValue(),
                            trailRainbow.getState(),
                            (int) trailLength.getValue()
                        );
                        // Y-смещение: добавляем offset к позиции
                        double yOff = trailYOffset.getValue();
                        TrailEffect.addPoint(mc.player.getPos().add(0, yOff, 0));
                    }
                }
            }
        }

        PulseManager.update();
    }

    // ── Хелперы ──────────────────────────────────────────────────────────────

    private void spawnPulse(int type, boolean isSecondWave) {
        if (mc.player == null) return;
        if (PulseManager.getEffects().size() >= (int) maxEffects.getValue()) return;

        int cm = colorMode.getSelectedIndex();
        float lifetime = (float) pulseLifetime.getValue();

        if (hpScale.getState()) {
            float hp    = mc.player.getHealth();
            float maxHp = mc.player.getMaxHealth();
            float ratio = Math.max(0.01f, hp / maxHp);
            lifetime *= (0.7f + (1f - ratio) * 1.5f);
        }

        int r, g, b;
        if (isSecondWave) {
            if (wave2Invert.getState()) {
                r = 255 - (int) colorR.getValue();
                g = 255 - (int) colorG.getValue();
                b = 255 - (int) colorB.getValue();
            } else {
                r = (int) wave2R.getValue();
                g = (int) wave2G.getValue();
                b = (int) wave2B.getValue();
            }
        } else {
            r = (int) colorR.getValue();
            g = (int) colorG.getValue();
            b = (int) colorB.getValue();
        }

        PulseManager.spawn(
            mc.player.getX(), mc.player.getY(), mc.player.getZ(),
            type, cm, r, g, b, lifetime, (float) pulseHeight.getValue()
        );

        // Запланировать вторую волну (только от основного спавна, не от второй)
        if (!isSecondWave && doubleWave.getState()) {
            wave2Pending     = true;
            wave2DelayTick   = 0;
        }
    }

    public int getActiveEffectCount() { return PulseManager.getEffects().size(); }
    public boolean isDebugMode()       { return showDebugCount.getState(); }
}
