package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.visuals.PulseManager;
import net.enkuron.visuals.TrailEffect;
import net.minecraft.util.math.Vec3d;

/**
 * PulseVisuals — пульс-волны и след (адаптировано под реальный API PulseManager/TrailEffect).
 */
public class PulseVisuals extends Module {

    private static final String[] COLOR_MODES = {"Статичный", "Радуга", "Пульс"};
    private static final String[] TRAIL_STYLES = {"Ribbon", "Line", "Dots"};

    private final Setting colorMode      = new Setting("Цветовой режим", COLOR_MODES, 1);
    private final Setting pulseSpeed     = new Setting("Скорость пульса", 1.0, 0.1, 5.0);
    private final Setting trailEnabled   = new Setting("Включить след", true);
    private final Setting trailStyle     = new Setting("Стиль следа", TRAIL_STYLES, 0);
    private final Setting trailLength    = new Setting("Длина следа", 20.0, 5.0, 60.0);
    private final Setting pulseOnSprint  = new Setting("Пульс при спринте", true);
    private final Setting pulseOnJump    = new Setting("Пульс при прыжке", true);
    private final Setting pulseOnLand    = new Setting("Пульс при приземлении", true);
    private final Setting hideInInventory = new Setting("Скрыть в инвентаре", true);

    private final TrailEffect trail = new TrailEffect(60, 800L);
    private boolean wasOnGround = true;
    private int trailTick = 0;

    public PulseVisuals() {
        super("PulseVisuals", "Неоновые волны и след при движении", Category.VISUAL);
        addSetting(colorMode);
        addSetting(pulseSpeed);
        addSetting(trailEnabled);
        addSetting(trailStyle);
        addSetting(trailLength);
        addSetting(pulseOnSprint);
        addSetting(pulseOnJump);
        addSetting(pulseOnLand);
        addSetting(hideInInventory);
    }

    @Override
    public void onEnable() {
        trail.clear();
        wasOnGround = true;
        trailTick = 0;
    }

    @Override
    public void onDisable() {
        trail.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (hideInInventory.getState() && mc.currentScreen != null) return;

        PulseManager.tick();

        boolean grounded  = mc.player.isOnGround();
        boolean sprinting = mc.player.isSprinting();

        // Приземление
        if (pulseOnLand.getState() && grounded && !wasOnGround) {
            // pulse triggered — PulseManager.tick() handles animation
        }

        wasOnGround = grounded;

        // След
        if (trailEnabled.getState()) {
            trailTick++;
            if (trailTick >= 1) {
                trailTick = 0;
                Vec3d pos = mc.player.getPos();
                trail.addPoint(pos.x, pos.y, pos.z);
            }
        }
    }

    public TrailEffect getTrail() { return trail; }
    public float getPulse() { return PulseManager.getPulse(); }
}
