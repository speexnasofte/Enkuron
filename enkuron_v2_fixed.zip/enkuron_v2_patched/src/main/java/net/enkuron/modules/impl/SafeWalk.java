package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.util.math.BlockPos;

public class SafeWalk extends Module {
    private final Setting inWater   = new Setting("В воде",           false);
    private final Setting onlySneak = new Setting("Только в крадьбе", false);

    public SafeWalk() {
        super("SafeWalk", "Не даёт упасть с края блока", Category.MOVEMENT);
        addSetting(inWater);
        addSetting(onlySneak);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (onlySneak.getState() && !mc.player.isSneaking()) return;

        // Определяем: игрок стоит на краю блока?
        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        // Проверяем блок под ногами по всем 4 углам хитбокса (0.3 от центра)
        boolean safe = isBlockBelow(x + 0.3, y, z + 0.3)
                    && isBlockBelow(x - 0.3, y, z + 0.3)
                    && isBlockBelow(x + 0.3, y, z - 0.3)
                    && isBlockBelow(x - 0.3, y, z - 0.3);

        if (!safe && mc.player.isOnGround()) {
            // Эмулируем sneak чтобы игрок не упал
            mc.player.setSneaking(true);
        }
    }

    private boolean isBlockBelow(double x, double y, double z) {
        BlockPos pos = BlockPos.ofFloored(x, y - 0.01, z);
        // FIX: оригинальный код проверял флюид только когда inWater=false, но тогда
        // игнорировал воду как опору. Правильная логика:
        // - если это вода, считаем опорой только при inWater=true
        boolean hasFluid = !mc.world.getFluidState(pos).isEmpty();
        if (hasFluid) return inWater.getState();
        return !mc.world.getBlockState(pos).isAir();
    }
}
