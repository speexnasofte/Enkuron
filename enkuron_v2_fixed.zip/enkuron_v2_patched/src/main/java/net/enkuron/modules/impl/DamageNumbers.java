package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * DamageNumbers — числа урона в 3D.
 *
 * Отслеживает здоровье живых существ и отображает нанесённый урон
 * как плавающие 3D-числа над головой цели.
 *
 * Особенности:
 *   • Плавное всплывание вверх с fade-out
 *   • Цвет зависит от величины: зелёный (мало) → жёлтый → красный (много)
 *   • Критический урон (>8) — большой белый текст с восклицательным знаком
 *   • Показывает хил как зелёный "+N"
 *   • Настройка: только по игрокам / все
 *   • Максимум одновременных поплавков — не перегружает экран
 *
 * Реализация через HUD-overlay: конвертируем 3D координаты в экранные
 * через матрицу проекции (project()).
 */
public class DamageNumbers extends Module {

    private static final String[] TARGET_OPTS = {"Все сущности", "Только игроки", "Только враги"};

    private final Setting maxNumbers  = new Setting("Макс. чисел",      12.0, 4.0, 24.0);
    private final Setting lifetime    = new Setting("Время жизни (тики)", 30.0, 15.0, 60.0);
    private final Setting targetMode  = new Setting("Цели",             TARGET_OPTS, 0);
    private final Setting showHeal    = new Setting("Показывать хил",   true);
    private final Setting critThresh  = new Setting("Порог крита",       8.0, 3.0, 20.0);

    // Кэш здоровья: entityId -> lastHealth
    private final Map<Integer, Float> lastHealth = new HashMap<>();

    // Активные числа урона
    private final List<DmgFloat> floaters = new ArrayList<>();

    private int tick = 0;

    // ── DmgFloat ────────────────────────────────────────────────────────────

    private static class DmgFloat {
        double worldX, worldY, worldZ;
        float  damage;    // > 0: урон, < 0: хил
        int    born;      // тик рождения
        float  offsetY;   // вертикальный дрейф (нарастает)
        boolean isCrit;

        DmgFloat(double x, double y, double z, float dmg, int tick) {
            this.worldX = x; this.worldY = y; this.worldZ = z;
            this.damage = dmg;
            this.born   = tick;
            this.offsetY = 0;
            this.isCrit  = dmg > 0; // будет уточнено снаружи
        }
    }

    public DamageNumbers() {
        super("DamageNumbers", "Числа урона в 3D над головой цели", Category.VISUAL);
        addSetting(maxNumbers);
        addSetting(lifetime);
        addSetting(targetMode);
        addSetting(showHeal);
        addSetting(critThresh);
    }

    @Override
    public void onEnable() { lastHealth.clear(); floaters.clear(); tick = 0; }

    @Override
    public void onDisable() { lastHealth.clear(); floaters.clear(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;

        int maxF = (int) maxNumbers.getValue();
        int life = (int) lifetime.getValue();

        // Убираем устаревшие
        floaters.removeIf(f -> (tick - f.born) > life);

        // Плавное всплывание
        for (DmgFloat f : floaters) {
            f.offsetY += 0.045f;
        }

        String tMode = targetMode.getCurrentOption();

        // Сканируем сущности
        for (net.minecraft.entity.Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player) || !living.isAlive()) continue;

            // Фильтр по режиму
            if (tMode.equals("Только игроки") && !(living instanceof PlayerEntity)) continue;
            if (tMode.equals("Только враги")  && !(living instanceof net.minecraft.entity.mob.HostileEntity)) continue;

            float now  = living.getHealth();
            Float prev = lastHealth.get(living.getId());

            if (prev != null) {
                float delta = prev - now; // > 0: урон, < 0: хил
                float absDelta = Math.abs(delta);

                if (absDelta >= 0.5f) {  // минимальный порог — меньше 0.5 hp не показываем
                    boolean isHeal = delta < 0;
                    if (isHeal && !showHeal.getState()) {
                        lastHealth.put(living.getId(), now);
                        continue;
                    }

                    if (floaters.size() < maxF) {
                        // Немного рандомизируем горизонталь, чтобы числа не накладывались
                        double ox = (Math.random() - 0.5) * 0.4;
                        double oz = (Math.random() - 0.5) * 0.4;
                        DmgFloat df = new DmgFloat(
                                living.getX() + ox,
                                living.getY() + living.getHeight() + 0.3,
                                living.getZ() + oz,
                                delta,
                                tick
                        );
                        df.isCrit = (delta > critThresh.getValue());
                        floaters.add(df);
                    }
                }
            }

            lastHealth.put(living.getId(), now);
        }

        // Чистим кэш мёртвых/ушедших
        if (tick % 40 == 0) {
            lastHealth.entrySet().removeIf(kv -> mc.world.getEntityById(kv.getKey()) == null);
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || floaters.isEmpty()) return;
        if (mc.gameRenderer == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int life = (int) lifetime.getValue();

        for (DmgFloat f : floaters) {
            int age = tick - f.born;
            float t = (float) age / life;  // 0..1

            // Проецируем 3D -> 2D
            int[] screen = project(
                    f.worldX, f.worldY + f.offsetY, f.worldZ,
                    camera, sw, sh);
            if (screen == null) continue;

            int sx = screen[0];
            int sy = screen[1];
            if (sx < -100 || sx > sw + 100 || sy < -50 || sy > sh + 50) continue;

            // Прозрачность: fade-in 20%, fade-out последние 30%
            float alpha;
            if (t < 0.2f)      alpha = t / 0.2f;
            else if (t > 0.7f) alpha = 1f - (t - 0.7f) / 0.3f;
            else               alpha = 1f;
            int a = (int)(alpha * 255) & 0xFF;
            if (a < 10) continue;

            // Формируем строку
            String text;
            int textColor;

            if (f.damage < 0) {
                // Хил — зелёный
                text = "§a+" + String.format("%.1f", -f.damage);
                textColor = (a << 24) | 0x0055FF55;
            } else if (f.isCrit) {
                // Критический урон — белый крупный с !
                text = "§f" + String.format("%.1f", f.damage) + "!";
                textColor = (a << 24) | 0x00FFFFFF;
            } else {
                // Обычный урон: зелёный → жёлтый → красный
                textColor = (a << 24) | damageColor(f.damage);
                text = String.format("%.1f", f.damage);
            }

            // Масштаб: критический крупнее
            float scale = f.isCrit ? 1.6f : 1.0f;

            int tw = (int)(mc.textRenderer.getWidth(text) * scale);
            int drawX = sx - tw / 2;
            int drawY = sy;

            // Тень
            context.drawText(mc.textRenderer, text, drawX + 1, drawY + 1,
                    (a / 2) << 24, false);
            context.drawText(mc.textRenderer, text, drawX, drawY,
                    textColor, true);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Простая проекция мировой точки в экранные координаты.
     * Использует camerа-позицию и направление.
     * Возвращает null, если точка позади камеры.
     */
    private int[] project(double wx, double wy, double wz, Camera camera, int sw, int sh) {
        Vec3d camPos = camera.getPos();
        double dx = wx - camPos.x;
        double dy = wy - camPos.y;
        double dz = wz - camPos.z;

        // Поворот по yaw и pitch камеры
        float yaw   = camera.getYaw();
        float pitch = camera.getPitch();

        double ry = Math.toRadians(yaw);
        double rp = Math.toRadians(pitch);

        // Вращаем вектор (dx,dy,dz) в систему координат камеры
        double sinY = Math.sin(ry), cosY = Math.cos(ry);
        double sinP = Math.sin(rp), cosP = Math.cos(rp);

        // Локальные оси камеры
        double lx = dx * cosY - dz * sinY;
        double ly = dx * sinY * sinP + dy * cosP + dz * cosY * sinP;
        double lz = -dx * sinY * cosP + dy * sinP - dz * cosY * cosP;

        if (lz <= 0.1) return null; // позади камеры

        // Простая perspective projection
        double fov = Math.toRadians(mc.options.getFov().getValue());
        double f   = 1.0 / Math.tan(fov / 2.0);
        double aspect = (double) sw / sh;

        double projX = (lx / lz) * f / aspect;
        double projY = (ly / lz) * f;

        int sx = (int)((0.5 + projX * 0.5) * sw);
        int sy = (int)((0.5 - projY * 0.5) * sh);

        return new int[]{sx, sy};
    }

    /** Цвет урона: мало зелёный -> много красный */
    private int damageColor(float dmg) {
        float ratio = Math.min(dmg / 20f, 1f); // 0..1 от 20 hp макс
        int r = (int)(ratio * 255);
        int g = (int)((1f - ratio) * 255);
        return (r << 16) | (g << 8);
    }
}
