package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * HandEffect — частицы из рук игрока (левой и/или правой).
 *
 * Режимы:
 *   Magic    — волшебный поток (Witch + Enchant)
 *   Fire     — пламя с рук
 *   Ice      — ледяные кристаллы
 *   Plasma   — плазменные сгустки (цветные dust)
 *   Stars    — звёздная пыль (End Rod + Crit)
 *   Void     — тёмная материя (тёмные portal + пыль)
 *   Sakura   — лепестки с рук
 */
public class HandEffect extends Module {

    private static final String[] MODES  = {"Magic", "Fire", "Ice", "Plasma", "Stars", "Void", "Sakura"};
    private static final String[] HANDS  = {"Обе", "Правая", "Левая"};
    private static final String[] COLORS = {"Purple", "Blue", "Green", "Red", "Gold", "Rainbow"};

    private final Setting mode    = new Setting("Эффект",  MODES,  0);
    private final Setting hand    = new Setting("Рука",    HANDS,  0);
    private final Setting color   = new Setting("Цвет",    COLORS, 0);
    private final Setting density = new Setting("Интенсивность", 5.0, 2.0, 12.0);

    private double rainbow = 0;
    private int    tick    = 0;

    public HandEffect() {
        super("HandEffect", "Частицы из рук игрока", Category.VISUAL);
        addSetting(mode); addSetting(hand); addSetting(color); addSetting(density);
    }

    @Override public void onEnable()  { rainbow = 0; tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;
        if (tick % 2 != 0) return;
        rainbow = (rainbow + 0.04) % 1.0;

        Vec3d pos  = mc.player.getPos();
        float yaw  = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        double rad = Math.toRadians(yaw);
        double cnt = density.getValue();

        // Позиции рук относительно игрока
        double handSideX = Math.cos(rad);      // боковой вектор
        double handSideZ = Math.sin(rad);
        double fwdX      = -Math.sin(rad);     // вперёд
        double fwdZ      =  Math.cos(rad);

        // Правая рука
        double rx = pos.x + handSideX * 0.35 + fwdX * 0.3;
        double rz = pos.z + handSideZ * 0.35 + fwdZ * 0.3;
        double ry = pos.y + 1.1;

        // Левая рука
        double lx = pos.x - handSideX * 0.35 + fwdX * 0.3;
        double lz = pos.z - handSideZ * 0.35 + fwdZ * 0.3;
        double ly = pos.y + 1.1;

        String h = hand.getCurrentOption();
        if (!h.equals("Левая"))  spawnHandEffect(rx, ry, rz, (int) cnt);
        if (!h.equals("Правая")) spawnHandEffect(lx, ly, lz, (int) cnt);
    }

    private void spawnHandEffect(double x, double y, double z, int cnt) {
        switch (mode.getCurrentOption()) {
            case "Magic"  -> spawnMagic (x, y, z, cnt);
            case "Fire"   -> spawnFire  (x, y, z, cnt);
            case "Ice"    -> spawnIce   (x, y, z, cnt);
            case "Plasma" -> spawnPlasma(x, y, z, cnt);
            case "Stars"  -> spawnStars (x, y, z, cnt);
            case "Void"   -> spawnVoid  (x, y, z, cnt);
            case "Sakura" -> spawnSakura(x, y, z, cnt);
        }
    }

    private void spawnMagic(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.WITCH,   x, y, z, rnd(0.06), rnd(0.06), rnd(0.06));
            mc.world.addParticle(ParticleTypes.ENCHANT, x, y, z, rnd(0.04), 0.05 + Math.random()*0.05, rnd(0.04));
        }
    }

    private void spawnFire(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.FLAME, x, y, z,
                rnd(0.08), 0.04 + Math.random() * 0.08, rnd(0.08));
            if (i % 2 == 0)
                mc.world.addParticle(new DustParticleEffect(enkuronDustColor(1f, 0.5f, 0f), 0.8f),
                    x, y, z, rnd(0.05), 0.03, rnd(0.05));
        }
    }

    private void spawnIce(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, rnd(0.05), 0.03, rnd(0.05));
            if (i % 3 == 0)
                mc.world.addParticle(ParticleTypes.END_ROD,   x, y, z, rnd(0.04), 0.06, rnd(0.04));
        }
    }

    private void spawnPlasma(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            float hue = (float)((rainbow + i * 0.1) % 1.0);
            int rgb = java.awt.Color.HSBtoRGB(hue, 1f, 1f);
            mc.world.addParticle(
                new DustParticleEffect(rgb & 0xFFFFFF, 1.2f),
                x, y, z, rnd(0.07), 0.06 + Math.random()*0.06, rnd(0.07));
        }
    }

    private void spawnStars(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.END_ROD, x, y, z, rnd(0.07), 0.07, rnd(0.07));
            if (i % 2 == 0)
                mc.world.addParticle(ParticleTypes.CRIT,   x, y, z, rnd(0.05), 0.05, rnd(0.05));
        }
    }

    private void spawnVoid(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.PORTAL, x, y, z, rnd(0.05), -0.05, rnd(0.05));
            mc.world.addParticle(
                new DustParticleEffect(enkuronDustColor(0.1f, 0f, 0.2f), 1.0f),
                x, y, z, rnd(0.04), 0.02, rnd(0.04));
        }
    }

    private void spawnSakura(double x, double y, double z, int cnt) {
        for (int i = 0; i < cnt; i++) {
            mc.world.addParticle(ParticleTypes.CHERRY_LEAVES,
                x, y, z, rnd(0.06), 0.04 + Math.random() * 0.05, rnd(0.06));
        }
    }

    private double rnd(double scale) {
        return (Math.random() - 0.5) * scale * 2;
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
