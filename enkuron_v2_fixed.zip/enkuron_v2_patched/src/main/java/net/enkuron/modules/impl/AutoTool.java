package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.hit.BlockHitResult;

/**
 * AutoTool — автоматически выбирает лучший инструмент для копки блока.
 *
 * Настройки:
 *   Вернуть слот   — возвращать прежний слот после копки
 *   Только хотбар  — искать только в хотбаре (слоты 0-8)
 *   Учитывать зачар — учитывать Efficiency при выборе
 */
public class AutoTool extends Module {

    private final Setting returnSlot     = new Setting("Вернуть слот",    true);
    private final Setting hotbarOnly     = new Setting("Только хотбар",   true);
    private final Setting useEfficiency  = new Setting("Учитывать зачар", true);

    private int  savedSlot = -1;
    private boolean switched = false;

    public AutoTool() {
        super("AutoTool", "Автоматически выбирает лучший инструмент", Category.MISC);
        addSetting(returnSlot);
        addSetting(hotbarOnly);
        addSetting(useEfficiency);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        if (mc.interactionManager.isBreakingBlock()) {
            BlockPos target = getTargetBlock();
            if (target != null) {
                BlockState state = mc.world.getBlockState(target);
                int bestSlot = getBestToolSlot(state);

                if (bestSlot != -1 && bestSlot != mc.player.getInventory().selectedSlot && !switched) {
                    savedSlot = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = bestSlot;
                    switched = true;
                }
            }
        } else {
            if (switched && savedSlot != -1 && returnSlot.getState()) {
                mc.player.getInventory().selectedSlot = savedSlot;
                savedSlot = -1;
                switched = false;
            } else if (!returnSlot.getState()) {
                switched = false;
                savedSlot = -1;
            }
        }
    }

    private BlockPos getTargetBlock() {
        var hit = mc.crosshairTarget;
        return (hit instanceof BlockHitResult b) ? b.getBlockPos() : null;
    }

    private int getBestToolSlot(BlockState state) {
        int bestSlot  = -1;
        float bestSpeed = 1.0f;
        int slots = hotbarOnly.getState() ? 9 : 36;

        for (int i = 0; i < slots; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;

            float speed = stack.getMiningSpeedMultiplier(state);

            // Бонус за Efficiency (каждый уровень ~+1 блок/с субъективно)
            if (useEfficiency.getState()) {
                try {
                    var effOpt = mc.world.getRegistryManager()
                        .getOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT)
                        .getOptional(net.minecraft.enchantment.Enchantments.EFFICIENCY);
                    if (effOpt.isPresent()) {
                        int eff = net.minecraft.enchantment.EnchantmentHelper.getLevel(effOpt.get(), stack);
                        speed += eff * 0.5f;
                    }
                } catch (Exception ignored) {
                    // Registry not ready or enchantment not found — skip silently
                }
            }

            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot  = i;
            }
        }
        return bestSlot;
    }

    @Override
    public void onDisable() {
        if (switched && savedSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
            switched = false;
        }
    }
}
