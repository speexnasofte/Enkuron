package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * GroundEffect — эффект под ногами игрока при ходьбе/беге.
 *
 * Режимы:
 *   Sparks     — искры при каждом шаге
 *   Flowers    — цветочки (Cherry + Dust)
 *   Lava       — лавовые брызги
 *   Ice        — ледяные осколки (Snowflake + EndRod)
 *   Rose       — розовые лепестки
 *   Thunder    — электрические разряды при ударах ног
 *   Shadow     — тёмные тени-пятна
 *   Fairy Dust — золотая пыль феи
 */
public class GroundEffect extends Module {

    private static final String[] MODES = {
        "Sparks", "Flowers", "Lava", "Ice", "Rose", "Thunder", "Shadow", "Fairy Dust"
    };

    private final Setting mode    = new Setting("Эффект",    MODES, 0);
    private final Setting density = new Setting("Интенсивность", 6.0, 2.0, 16.0);
    private final Setting onMove  = new Setting("Только при движении", true);

    private int tick = 0;
    private boolean wasOnGround = false;

    public GroundEffect() {
        super("GroundEffect", "Частицы под ногами при ходьбе", Category.VISUAL);
        addSetting(mode);
        addSetting(density);
        addSetting(onMove);
    }

    @Override public void onEnable() { tick = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;

        boolean onGround = mc.player.isOnGround();

        // Если только при движении — проверяем горизонтальную скорость
        if (onMove.getState()) {
            Vec3d vel = mc.player.getVelocity();
            double spd = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            if (spd < 0.05 || !onGround) return;
        } else {
            if (!onGround) return;
        }

        if (tick % 3 != 0) return;

        Vec3d pos = mc.player.getPos();
        int cnt = (int) density.getValue();

        switch (mode.getCurrentOption()) {
            case "Sparks"     -> spawnSparks    (pos, cnt);
            case "Flowers"    -> spawnFlowers   (pos, cnt);
            case "Lava"       -> spawnLava       (pos, cnt);
            case "Ice"        -> spawnIce        (pos, cnt);
            case "Rose"       -> spawnRose       (pos, cnt);
            case "Thunder"    -> spawnThunder    (pos, cnt);
            case "Shadow"     -> spawnShadow     (pos, cnt);
            case "Fairy Dust" -> spawnFairyDust  (pos, cnt);
        }

        wasOnGround = onGround;
    }

    private void spawnSparks(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.4;
            mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK,
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                (Math.random() - 0.5) * 0.15, 0.12 + Math.random() * 0.1, (Math.random() - 0.5) * 0.15);
        }
    }

    private void spawnFlowers(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.5;
            mc.world.addParticle(ParticleTypes.CHERRY_LEAVES,
                pos.x + Math.cos(a) * r, pos.y + 0.1, pos.z + Math.sin(a) * r,
                (Math.random() - 0.5) * 0.05, 0.06, (Math.random() - 0.5) * 0.05);
            if (i % 2 == 0) {
                mc.world.addParticle(new DustParticleEffect(enkuronDustColor(1f, 0.6f, 0.8f), 0.8f),
                    pos.x + Math.cos(a + 0.5) * r * 0.8, pos.y + 0.05, pos.z + Math.sin(a + 0.5) * r * 0.8,
                    0, 0.04, 0);
            }
        }
    }

    private void spawnLava(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.45;
            mc.world.addParticle(ParticleTypes.FLAME,
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                (Math.random() - 0.5) * 0.1, 0.1 + Math.random() * 0.15, (Math.random() - 0.5) * 0.1);
            if (i % 3 == 0) {
                mc.world.addParticle(new DustParticleEffect(enkuronDustColor(1f, 0.3f, 0f), 1.2f),
                    pos.x + (Math.random() - 0.5) * 0.6, pos.y + 0.05, pos.z + (Math.random() - 0.5) * 0.6,
                    0, 0, 0);
            }
        }
    }

    private void spawnIce(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.5;
            mc.world.addParticle(ParticleTypes.SNOWFLAKE,
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                (Math.random() - 0.5) * 0.08, 0.08, (Math.random() - 0.5) * 0.08);
            if (i % 2 == 0) {
                mc.world.addParticle(ParticleTypes.END_ROD,
                    pos.x + (Math.random() - 0.5) * 0.4, pos.y + 0.1, pos.z + (Math.random() - 0.5) * 0.4,
                    0, 0.03, 0);
            }
        }
    }

    private void spawnRose(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.45;
            float hue = (float)(0.9 + Math.random() * 0.1); // красно-розовый
            int rgb = java.awt.Color.HSBtoRGB(hue, 0.8f, 1f);
            mc.world.addParticle(
                new DustParticleEffect(rgb & 0xFFFFFF, 1.0f),
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                (Math.random()-0.5)*0.04, 0.07, (Math.random()-0.5)*0.04);
        }
    }

    private void spawnThunder(Vec3d pos, int cnt) {
        // Только при каждом приземлении или редко
        if (tick % 6 != 0) return;
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.6;
            mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK,
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                Math.cos(a) * 0.2, 0.18, Math.sin(a) * 0.2);
        }
        mc.world.addParticle(ParticleTypes.FLASH, pos.x, pos.y + 0.1, pos.z, 0, 0, 0);
    }

    private void spawnShadow(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.5;
            mc.world.addParticle(
                new DustParticleEffect(enkuronDustColor(0.05f, 0.0f, 0.1f), 1.0f),
                pos.x + Math.cos(a) * r, pos.y + 0.02, pos.z + Math.sin(a) * r,
                0, 0, 0);
        }
        if (tick % 4 == 0) {
            mc.world.addParticle(ParticleTypes.PORTAL,
                pos.x + (Math.random()-0.5)*0.5, pos.y + 0.05, pos.z + (Math.random()-0.5)*0.5,
                0, -0.05, 0);
        }
    }

    private void spawnFairyDust(Vec3d pos, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * 0.5;
            mc.world.addParticle(
                new DustParticleEffect(enkuronDustColor(1f, 0.9f, 0.2f), 0.9f),
                pos.x + Math.cos(a) * r, pos.y + 0.05, pos.z + Math.sin(a) * r,
                (Math.random()-0.5)*0.04, 0.09 + Math.random()*0.06, (Math.random()-0.5)*0.04);
            if (i % 3 == 0) {
                mc.world.addParticle(ParticleTypes.END_ROD,
                    pos.x + Math.cos(a+1)*r*0.6, pos.y + 0.1, pos.z + Math.sin(a+1)*r*0.6,
                    0, 0.04, 0);
            }
        }
    }
    /** Helper: convert float RGB (0-1) to packed int for DustParticleEffect (1.21.4+) */
    private static int enkuronDustColor(float r, float g, float b) {
        return ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

}
