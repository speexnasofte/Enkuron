package net.enkuron.modules;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity; // Исправлено: пакет passive вместо mob
import net.minecraft.entity.player.PlayerEntity;
/**
 * SettingPresets — универсальные блоки настроек для переиспользования в любом модуле.
 *
 * Использование в модуле:
 *
 *   private final SettingPresets.TargetFilter targetFilter = new SettingPresets.TargetFilter();
 *   private final SettingPresets.Range        range        = new SettingPresets.Range(32, 8, 128);
 *   private final SettingPresets.UpdateRate   updateRate   = new SettingPresets.UpdateRate(5);
 *
 *   // В конструкторе:
 *   targetFilter.addTo(this);
 *   range.addTo(this);
 *   updateRate.addTo(this);
 *
 *   // В onTick():
 *   if (!updateRate.ready()) return;
 *   for (Entity e : mc.world.getEntities()) {
 *       if (!targetFilter.passes(living)) continue;
 *       if (!range.inRange(living, mc.player)) continue;
 *       ...
 *   }
 */
public final class SettingPresets {

    private SettingPresets() {}

    // ══════════════════════════════════════════════════════════════════════════
    // 1. TargetFilter — фильтр целей (Игрок / Моб / Враждебный / Пассивный / Все)
    //    Подходит для: TargetAura, GlowESP, Tracers, ChestESP, Nametags,
    //                  ESP-модулей, Combat-модулей
    // ══════════════════════════════════════════════════════════════════════════

    public static class TargetFilter {

        public static final String[] OPTIONS = {"Все", "Игроки", "Мобы", "Враждебные", "Пассивные"};

        private final Setting players  = new Setting("Игроки",      true);
        private final Setting hostile  = new Setting("Враждебные",  true);
        private final Setting passive  = new Setting("Пассивные",   false);
        private final Setting animals  = new Setting("Животные",    false);

        /** Добавить все настройки фильтра в модуль */
        public void addTo(Module module) {
            module.addSetting(players);
            module.addSetting(hostile);
            module.addSetting(passive);
            module.addSetting(animals);
        }

        /**
         * Проверить, проходит ли сущность фильтр.
         * Возвращает true если хотя бы один подходящий тип включён.
         */
        public boolean passes(LivingEntity e) {
            if (e instanceof PlayerEntity)  return players.getState();
            if (e instanceof HostileEntity) return hostile.getState();
            if (e instanceof PassiveEntity) return passive.getState() || animals.getState();
            return false;
        }

        /** Включён ли хоть один тип (для валидации) */
        public boolean anyEnabled() {
            return players.getState() || hostile.getState() || passive.getState();
        }

        // Прямой доступ если нужно
        public boolean showPlayers()  { return players.getState(); }
        public boolean showHostile()  { return hostile.getState(); }
        public boolean showPassive()  { return passive.getState(); }
        public boolean showAnimals()  { return animals.getState(); }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 2. Range — настройка дальности обнаружения
    //    Подходит для: любого ESP, Combat, Tracker модуля
    // ══════════════════════════════════════════════════════════════════════════

    public static class Range {

        private final Setting range;

        public Range(double defaultVal, double min, double max) {
            range = new Setting("Дальность (блоки)", defaultVal, min, max);
        }

        public Range(double defaultVal) {
            this(defaultVal, 4.0, 128.0);
        }

        public void addTo(Module module) {
            module.addSetting(range);
        }

        public double get() { return range.getValue(); }

        /** Проверить что сущность в радиусе от игрока */
        public boolean inRange(net.minecraft.entity.Entity target, net.minecraft.entity.Entity origin) {
            if (target == null || origin == null) return false;
            return target.getPos().distanceTo(origin.getPos()) <= range.getValue();
        }

        public boolean inRange(double dist) {
            return dist <= range.getValue();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 3. UpdateRate — ограничитель частоты обновления (в тиках)
    //    Подходит для: любого модуля с onTick() который не надо звать каждый тик
    // ══════════════════════════════════════════════════════════════════════════

    public static class UpdateRate {

        private final Setting rate;
        private int counter = 0;

        public UpdateRate(double defaultTicks, double min, double max) {
            rate = new Setting("Обновление (тики)", defaultTicks, min, max);
        }

        public UpdateRate(double defaultTicks) {
            this(defaultTicks, 1.0, 20.0);
        }

        public void addTo(Module module) {
            module.addSetting(rate);
        }

        /** Вызывать в onTick(). Возвращает true когда пора обновиться. */
        public boolean ready() {
            if (++counter >= (int) rate.getValue()) {
                counter = 0;
                return true;
            }
            return false;
        }

        public void reset() { counter = 0; }
        public double getTicks() { return rate.getValue(); }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 4. MaxTargets — ограничение количества целей
    //    Подходит для: TargetAura, Nametags, Tracers, ESP-модулей
    // ══════════════════════════════════════════════════════════════════════════

    public static class MaxTargets {

        private final Setting maxTargets;

        public MaxTargets(double defaultVal, double min, double max) {
            maxTargets = new Setting("Макс. целей", defaultVal, min, max);
        }

        public MaxTargets(double defaultVal) {
            this(defaultVal, 1.0, 16.0);
        }

        public void addTo(Module module) {
            module.addSetting(maxTargets);
        }

        public int get() { return (int) maxTargets.getValue(); }

        /** Обрезать список до лимита */
        public <T> java.util.List<T> limit(java.util.List<T> list) {
            int max = get();
            return list.size() > max ? list.subList(0, max) : list;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 5. HPFilter — фильтр по здоровью цели
    //    Подходит для: Combat, AutoTotem, AutoEat, GlowESP, TargetAura
    // ══════════════════════════════════════════════════════════════════════════

    public static class HPFilter {

        private final Setting minHP;
        private final Setting maxHP;

        public HPFilter() {
            minHP = new Setting("Мин. HP цели", 0.0,  0.0, 20.0);
            maxHP = new Setting("Макс. HP цели", 20.0, 1.0, 20.0);
        }

        public void addTo(Module module) {
            module.addSetting(minHP);
            module.addSetting(maxHP);
        }

        public boolean passes(LivingEntity e) {
            float hp = e.getHealth();
            return hp >= minHP.getValue() && hp <= maxHP.getValue();
        }

        public float getMin() { return (float) minHP.getValue(); }
        public float getMax() { return (float) maxHP.getValue(); }

        /** Нормализованный % HP (0.0 – 1.0) */
        public float ratio(LivingEntity e) {
            return e.getMaxHealth() > 0
                ? Math.min(e.getHealth() / e.getMaxHealth(), 1f)
                : 0f;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 6. RenderStyle — настройки отображения (цвет, прозрачность, толщина)
    //    Подходит для: ESP, Tracers, TargetAura, Nametags, ChestESP
    // ══════════════════════════════════════════════════════════════════════════

    public static class RenderStyle {

        private static final String[] COLOR_MODES = {
            "По типу", "По HP", "Радуга", "Один цвет"
        };

        private final Setting colorMode;
        private final Setting opacity;
        private final Setting thickness;

        public RenderStyle() {
            colorMode = new Setting("Цвет",         COLOR_MODES, 0);
            opacity   = new Setting("Прозрачность", 0.75, 0.1, 1.0);
            thickness = new Setting("Толщина",      1.5,  0.5, 4.0);
        }

        /** Упрощённый вариант без толщины (для HUD модулей) */
        public RenderStyle(boolean withThickness) {
            colorMode = new Setting("Цвет", COLOR_MODES, 0);
            opacity   = new Setting("Прозрачность", 0.75, 0.1, 1.0);
            thickness = withThickness
                ? new Setting("Толщина", 1.5, 0.5, 4.0)
                : null;
        }

        public void addTo(Module module) {
            module.addSetting(colorMode);
            module.addSetting(opacity);
            if (thickness != null) module.addSetting(thickness);
        }

        public String getColorMode() { return colorMode.getCurrentOption(); }
        public float  getOpacity()   { return (float) opacity.getValue(); }
        public float  getThickness() { return thickness != null ? (float) thickness.getValue() : 1.5f; }

        /**
         * Получить цвет с учётом режима и HP.
         * Возвращает ARGB int.
         */
        public int resolveColor(LivingEntity e, int tickCount) {
            int alpha = (int)(getOpacity() * 255) << 24;
            return switch (getColorMode()) {
                case "По HP" -> {
                    float ratio = e.getMaxHealth() > 0
                        ? Math.min(e.getHealth() / e.getMaxHealth(), 1f) : 0f;
                    yield alpha | lerpColor(0xEE3333, 0x44EE77, ratio);
                }
                case "Радуга" -> alpha | hsvToRgb((tickCount * 2f) % 360f);
                case "По типу" -> {
                    if (e instanceof PlayerEntity)  yield alpha | 0x5599FF;
                    if (e instanceof HostileEntity) yield alpha | 0xFF4444;
                    yield alpha | 0x44DD77;
                }
                default -> alpha | 0xFFFFFF;
            };
        }

        /** Цвет без сущности (для нейтральных элементов) */
        public int resolveColor(int tickCount) {
            int alpha = (int)(getOpacity() * 255) << 24;
            return switch (getColorMode()) {
                case "Радуга" -> alpha | hsvToRgb((tickCount * 2f) % 360f);
                default -> alpha | 0x5599FF;
            };
        }

        private static int lerpColor(int from, int to, float t) {
            int fr = (from >> 16) & 0xFF, fg = (from >> 8) & 0xFF, fb = from & 0xFF;
            int tr = (to   >> 16) & 0xFF, tg = (to   >> 8) & 0xFF, tb = to   & 0xFF;
            int r = (int)(fr + (tr - fr) * t);
            int g = (int)(fg + (tg - fg) * t);
            int b = (int)(fb + (tb - fb) * t);
            return (r << 16) | (g << 8) | b;
        }

        private static int hsvToRgb(float hue) {
            float h = hue / 60f;
            float x = 1f - Math.abs(h % 2 - 1);
            float r, g, b;
            if      (h < 1) { r = 1; g = x; b = 0; }
            else if (h < 2) { r = x; g = 1; b = 0; }
            else if (h < 3) { r = 0; g = 1; b = x; }
            else if (h < 4) { r = 0; g = x; b = 1; }
            else if (h < 5) { r = x; g = 0; b = 1; }
            else            { r = 1; g = 0; b = x; }
            return ((int)(r*255) << 16) | ((int)(g*255) << 8) | (int)(b*255);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 7. SelfFilter — исключать себя / союзников / мирных
    //    Подходит для: всех combat и ESP модулей
    // ══════════════════════════════════════════════════════════════════════════

    public static class SelfFilter {

        private final Setting ignoreSelf;
        private final Setting ignoreTeam;
        private final Setting ignoreInvisible;

        public SelfFilter() {
            ignoreSelf      = new Setting("Игнорировать себя",         true);
            ignoreTeam      = new Setting("Игнорировать команду",      false);
            ignoreInvisible = new Setting("Игнорировать невидимых",    false);
        }

        public void addTo(Module module) {
            module.addSetting(ignoreSelf);
            module.addSetting(ignoreTeam);
            module.addSetting(ignoreInvisible);
        }

        public boolean passes(LivingEntity e, net.minecraft.client.network.ClientPlayerEntity player) {
            if (ignoreSelf.getState() && e.equals(player)) return false;
            if (ignoreInvisible.getState() && e.isInvisible()) return false;
            if (ignoreTeam.getState() && player.isTeammate(e)) return false;
            return true;
        }
    }
}
