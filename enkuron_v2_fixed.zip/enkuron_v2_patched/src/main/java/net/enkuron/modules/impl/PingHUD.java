package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

/**
 * PingHUD — пинг до сервера.
 *
 * Настройки:
 *   Позиция      — TOP_LEFT / TOP_RIGHT / BOTTOM_LEFT / BOTTOM_RIGHT
 *   Суффикс      — показывать "ms" после числа
 *   Цвет по пингу — зелёный/жёлтый/красный в зависимости от пинга
 */
public class PingHUD extends Module {

    private static final String[] POSITIONS = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"};

    private final Setting position    = new Setting("Позиция",       POSITIONS, 0);
    private final Setting showSuffix  = new Setting("Суффикс ms",    true);
    private final Setting colorByPing = new Setting("Цвет по пингу", true);

    public PingHUD() {
        super("PingHUD", "Показывает пинг до сервера в реальном времени", Category.HUD);
        addSetting(position);
        addSetting(showSuffix);
        addSetting(colorByPing);
        this.x = 5; this.y = 20;
        this.width = 70; this.height = 14;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;

        int ping = getPing();
        String text = "Ping " + ping + (showSuffix.getState() ? " ms" : "");
        int tw = mc.textRenderer.getWidth(text) + 8;
        this.width = tw + 4;

        int color;
        if (colorByPing.getState()) {
            if      (ping < 80)  color = 0xFF44EE77;
            else if (ping < 150) color = 0xFFFFFF44;
            else if (ping < 300) color = 0xFFFF9944;
            else                 color = 0xFFEE4444;
        } else {
            color = 0xFFFFFFFF;
        }

        applyPosition();

        context.fill(x - 2, y - 1, x + tw + 2, y + 10, 0xBB111116);
        context.fill(x - 2, y - 1, x - 1,      y + 10, color);
        context.drawText(mc.textRenderer, text, x + 2, y, color, true);
    }

    private void applyPosition() {
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        switch (position.getCurrentOption()) {
            case "TOP_LEFT"     -> { x = 5;            y = 20; }
            case "TOP_RIGHT"    -> { x = sw - width - 5; y = 20; }
            case "BOTTOM_LEFT"  -> { x = 5;            y = sh - height - 5; }
            case "BOTTOM_RIGHT" -> { x = sw - width - 5; y = sh - height - 5; }
        }
    }

    private int getPing() {
        if (mc.player == null || mc.getNetworkHandler() == null) return 0;
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }
}
