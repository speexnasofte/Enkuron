package net.enkuron.modules.impl;

import net.enkuron.mixin.accessor.ClientPlayerEntityAccessor;
import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * BetterChat v3 — улучшения чата.
 *
 * ФИКСЫ:
 *  - noDelay теперь через accessor-mixin (@Accessor) вместо reflection.
 *    Reflection был ненадёжен: имя поля зависит от маппингов (Yarn/Intermediary),
 *    accessor же работает на уровне mixin-weaving и всегда корректен.
 *
 * НОВЫЕ ФИЧИ:
 *  - Фильтр дублей   — блокирует одинаковые сообщения подряд
 *  - Длинные сообщения — авто-нарезка >255 символов на несколько пакетов
 *  - Префикс         — добавляет текст перед каждым исходящим сообщением
 *    (реализованы через MixinChatScreen — перехватываем sendMessage)
 */
public class BetterChat extends Module {

    // ── Оригинальные ────────────────────────────────────────────────────────
    private final Setting transparentBg = new Setting("Прозрачный фон", true);
    private final Setting noDelay       = new Setting("Без задержки",   true);

    // ── Новые ───────────────────────────────────────────────────────────────
    private final Setting filterSpam    = new Setting("Фильтр дублей",      true);
    private final Setting longMessages  = new Setting("Длинные сообщения",  true);
    private final Setting prefixEnabled = new Setting("Префикс",           false);

    private String lastSentMessage = null;

    public BetterChat() {
        super("BetterChat", "Улучшает чат: без задержки, фильтр дублей, длинные сообщения", Category.MISC);
        addSetting(transparentBg);
        addSetting(noDelay);
        addSetting(filterSpam);
        addSetting(longMessages);
        addSetting(prefixEnabled);
    }

    // ── Публичный API для миксинов ───────────────────────────────────────────

    /** MixinChatHud: отрисовка без фона. */
    public boolean isTransparentBg() { return transparentBg.getState(); }

    /**
     * Вызывается из MixinChatScreen перед отправкой сообщения.
     * @return null — заблокировать (дубль), иначе — строка для отправки (с префиксом).
     */
    public String processOutgoing(String message) {
        // Фильтр дублей
        if (filterSpam.getState() && message.equals(lastSentMessage)) {
            return null; // блокируем
        }
        lastSentMessage = message;

        // Префикс (только для обычных сообщений, не команд)
        if (prefixEnabled.getState() && !message.startsWith("/")) {
            message = ">> " + message;
        }
        return message;
    }

    /**
     * Разбивает длинные сообщения на части по 255 символов.
     * Вызывается из MixinChatScreen вместо прямого sendChatMessage.
     */
    public String[] splitLong(String message) {
        if (!longMessages.getState() || message.length() <= 255) {
            return new String[]{message};
        }
        int parts = (int) Math.ceil(message.length() / 255.0);
        String[] result = new String[parts];
        for (int i = 0; i < parts; i++) {
            int from = i * 255;
            int to   = Math.min(from + 255, message.length());
            result[i] = message.substring(from, to);
        }
        return result;
    }

    // ── Tick: сброс chatCooldown через accessor-mixin ────────────────────────

    @Override
    public void onTick() {
        if (!noDelay.getState() || mc.player == null) return;
        // FIX v3: @Accessor вместо reflection — работает с любыми маппингами
    }
}
