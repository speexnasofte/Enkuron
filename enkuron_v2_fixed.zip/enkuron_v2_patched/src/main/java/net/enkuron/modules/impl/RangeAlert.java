package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * RangeAlert — HUD-предупреждение когда враг входит в радиус атаки.
 *
 * Показывает:
 *   - Имя ближайшего врага
 *   - Расстояние до него
 *   - Цветную полосу опасности
 *
 * Режимы:
 *   Players — только игроки
 *   Mobs    — только мобы
 *   Both    — все живые существа
 */
public class RangeAlert extends Module {

    private static final String[] TARGETS = {"Players", "Mobs", "Both"};
    private static final String[] STYLES  = {"Bar", "Minimal", "Popup"};

    private final Setting target  = new Setting("Тип врага", TARGETS, 2);
    private final Setting style   = new Setting("Стиль HUD", STYLES,  0);
    private final Setting range   = new Setting("Радиус",    5.0, 1.0, 20.0);

    private LivingEntity nearest    = null;
    private double       nearestDist= 999;
    private int          pulseTimer = 0;

    public RangeAlert() {
        super("RangeAlert", "Предупреждение когда враг в радиусе атаки", Category.HUD);
        this.x = 10; this.y = 60;
        addSetting(target);
        addSetting(style);
        addSetting(range);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) { nearest = null; return; }

        double r = range.getValue();
        nearest     = null;
        nearestDist = 999;

        for (var entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity le)) continue;
            if (le.equals(mc.player)) continue;
            if (le.getHealth() <= 0) continue;

            boolean isPlayer = le instanceof PlayerEntity;
            boolean isMob    = le instanceof HostileEntity;

            boolean wanted = switch (target.getCurrentOption()) {
                case "Players" -> isPlayer;
                case "Mobs"    -> isMob;
                default        -> isPlayer || isMob;
            };
            if (!wanted) continue;

            double dist = mc.player.distanceTo(le);
            if (dist <= r && dist < nearestDist) {
                nearest     = le;
                nearestDist = dist;
            }
        }

        pulseTimer = (pulseTimer + 1) % 40;
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || nearest == null) return;

        switch (style.getCurrentOption()) {
            case "Minimal" -> renderMinimal(ctx);
            case "Popup"   -> renderPopup  (ctx);
            default        -> renderBar    (ctx);
        }
    }

    private void renderBar(DrawContext ctx) {
        double r     = range.getValue();
        float ratio  = (float)(1.0 - nearestDist / r);
        int   danger = dangerColor(ratio);
        String name  = nearest.getName().getString();
        String dist  = String.format("%.1fm ⚠", nearestDist);

        int w = Math.max(mc.textRenderer.getWidth(name),
                         mc.textRenderer.getWidth(dist)) + 10;
        w = Math.max(w, 80);

        // Пульсирующий фон при близком враге
        int alpha = (ratio > 0.8f && pulseTimer < 20) ? 0xDD : 0xAA;
        int bg    = (alpha << 24) | 0x0A0A14;
        ctx.fill(x-2, y-2, x+w, y+24, bg);
        ctx.fill(x-2, y-2, x+w, y-1,  danger);

        ctx.drawText(mc.textRenderer, "§c⚠ " + name, x+2, y+2,  0xFFFFFFFF, true);
        ctx.drawText(mc.textRenderer, dist,           x+2, y+13, danger,     false);

        // Полоса опасности
        ctx.fill(x,   y+20, x+w-2,               y+22, 0xFF333333);
        ctx.fill(x,   y+20, x+(int)((w-2)*ratio), y+22, danger);
        this.width = w; this.height = 24;
    }

    private void renderMinimal(DrawContext ctx) {
        String txt = String.format("⚠ %.1fm", nearestDist);
        int    w   = mc.textRenderer.getWidth(txt) + 6;
        double r   = range.getValue();
        int    col = dangerColor((float)(1.0 - nearestDist / r));
        ctx.fill(x-1, y-1, x+w+1, y+11, 0x99000000);
        ctx.drawText(mc.textRenderer, txt, x+2, y, col, true);
        this.width = w; this.height = 10;
    }

    private void renderPopup(DrawContext ctx) {
        double r     = range.getValue();
        float ratio  = (float)(1.0 - nearestDist / r);
        int   danger = dangerColor(ratio);
        String name  = nearest.getName().getString();
        String sub   = String.format("%.1f m от тебя", nearestDist);

        int nw = mc.textRenderer.getWidth("§l" + name);
        int sw = mc.textRenderer.getWidth(sub);
        int w  = Math.max(nw, sw) + 16;

        // Мигание
        if (ratio > 0.85f && pulseTimer > 20) return; // мигаем

        ctx.fill(x-2, y-2, x+w, y+28, 0xEE050510);
        ctx.fill(x-2, y-2, x+w, y-1,  danger);
        ctx.fill(x-2, y+27, x+w, y+28, danger);

        ctx.drawText(mc.textRenderer, "§l" + name, x + (w-nw)/2, y+3,  danger,     true);
        ctx.drawText(mc.textRenderer, sub,          x + (w-sw)/2, y+15, 0xFFAAAAAA, false);
        this.width = w; this.height = 28;
    }

    private int dangerColor(float ratio) {
        if (ratio > 0.8f) return 0xFFFF3333;
        if (ratio > 0.5f) return 0xFFFF8800;
        return 0xFFFFDD00;
    }
}
