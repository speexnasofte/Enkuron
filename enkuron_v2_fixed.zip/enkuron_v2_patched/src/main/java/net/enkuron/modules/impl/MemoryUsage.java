package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

/**
 * MemoryUsage — использование RAM.
 *
 * Настройки:
 *   Единицы     — MB / GB
 *   Порог (%)   — при каком % использования подсвечивать красным (50–90)
 */
public class MemoryUsage extends Module {

    private static final String[] UNITS = {"MB", "GB"};

    private final Setting units    = new Setting("Единицы",  UNITS, 0);
    private final Setting warnPct  = new Setting("Порог (%)", 80.0, 50.0, 90.0);

    public MemoryUsage() {
        super("MemoryUsage", "Отображает использование оперативной памяти", Category.HUD);
        addSetting(units);
        addSetting(warnPct);
        this.x = 5; this.y = 94;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;

        long maxBytes   = Runtime.getRuntime().maxMemory();
        long totalBytes = Runtime.getRuntime().totalMemory();
        long freeBytes  = Runtime.getRuntime().freeMemory();
        long usedBytes  = totalBytes - freeBytes;
        float ratio     = (float) usedBytes / maxBytes;

        String text;
        if (units.getCurrentOption().equals("GB")) {
            text = String.format("%.1fG / %.1fG", usedBytes / 1073741824.0, maxBytes / 1073741824.0);
        } else {
            text = (usedBytes / 1048576) + "M / " + (maxBytes / 1048576) + "M";
        }

        int tw = mc.textRenderer.getWidth("RAM " + text) + 8;
        this.width  = tw + 4;
        this.height = 16;

        float warn = (float)(warnPct.getValue() / 100.0);
        int color = ratio > warn ? 0xFFEE4444
                  : ratio > warn * 0.8f ? 0xFFFF9944
                  : 0xFF8844FF;

        context.fill(x - 2, y - 1, x + tw + 2, y + 11, 0xBB111116);
        context.fill(x - 2, y - 1, x - 1,      y + 11, color);
        context.fill(x + 2, y + 9, x + tw - 2, y + 11, 0xFF222233);
        context.fill(x + 2, y + 9, x + 2 + (int)((tw - 4) * ratio), y + 11, color);
        context.drawText(mc.textRenderer, "RAM " + text, x + 2, y, color, true);
    }
}
