package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * StarBurst — периодические вспышки звёзд вокруг игрока.
 *
 * Режимы:
 *   Burst   — одиночная вспышка-взрыв из звёзд
 *   Orbit   — звёзды вращаются по орбите
 *   Meteor  — метеоры падают сверху вниз вокруг игрока
 *   Sparkle — постоянное мерцание/блёстки
 */
public class StarBurst extends Module {

    private static final String[] MODES = {"Burst", "Orbit", "Meteor", "Sparkle"};
    private static final String[] PARTICLE_NAMES = {"End Rod", "Glow", "Enchant", "Soul", "Flash"};

    private final Setting mode     = new Setting("Режим",     MODES,          0);
    private final Setting particle = new Setting("Частицы",   PARTICLE_NAMES, 1);
    private final Setting interval = new Setting("Интервал",  20.0, 5.0, 60.0);
    private final Setting count    = new Setting("Кол-во звёзд", 12.0, 4.0, 30.0);
    private final Setting radius   = new Setting("Радиус",    1.5, 0.5, 3.5);

    private int    tick  = 0;
    private double orbit = 0;

    public StarBurst() {
        super("StarBurst", "Вспышки звёзд и световые эффекты вокруг игрока", Category.VISUAL);
        addSetting(mode);
        addSetting(particle);
        addSetting(interval);
        addSetting(count);
        addSetting(radius);
    }

    @Override public void onEnable() { tick = 0; orbit = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;

        Vec3d pos = mc.player.getPos();
        double cx = pos.x;
        double cy = pos.y + mc.player.getHeight() * 0.5;
        double cz = pos.z;
        int    cnt = (int) count.getValue();
        double r   = radius.getValue();

        switch (mode.getCurrentOption()) {
            case "Burst"   -> {
                if (tick % (int) interval.getValue() == 0) spawnBurst(cx, cy, cz, r, cnt);
            }
            case "Orbit"   -> {
                orbit += 0.06;
                if (tick % 2 == 0) spawnOrbit(cx, cy, cz, r, cnt);
            }
            case "Meteor"  -> {
                if (tick % 3 == 0) spawnMeteor(cx, pos.y, cz, r, cnt);
            }
            case "Sparkle" -> {
                if (tick % 2 == 0) spawnSparkle(cx, pos.y, cz, r, cnt);
            }
        }
    }

    /** Взрыв-вспышка: все звёзды разлетаются от центра */
    private void spawnBurst(double cx, double cy, double cz, double r, int cnt) {
        for (int i = 0; i < cnt; i++) {
            double a   = (2 * Math.PI * i) / cnt;
            double vx  = Math.cos(a) * 0.25;
            double vz  = Math.sin(a) * 0.25;
            double vy  = 0.15 + Math.random() * 0.2;
            mc.world.addParticle(getParticle(), cx, cy, cz, vx, vy, vz);
        }
        // Центральный взрыв
        mc.world.addParticle(ParticleTypes.FLASH, cx, cy, cz, 0, 0, 0);
    }

    /** Орбитальные звёзды вращаются по двум кольцам */
    private void spawnOrbit(double cx, double cy, double cz, double r, int cnt) {
        // Нижнее кольцо
        for (int i = 0; i < cnt / 2; i++) {
            double a = orbit + (2 * Math.PI * i) / (cnt / 2);
            spawnAt(cx + Math.cos(a) * r, cy - 0.2, cz + Math.sin(a) * r);
        }
        // Верхнее кольцо (обратное вращение)
        for (int i = 0; i < cnt / 2; i++) {
            double a = -orbit + (2 * Math.PI * i) / (cnt / 2);
            spawnAt(cx + Math.cos(a) * r * 0.65, cy + 0.5, cz + Math.sin(a) * r * 0.65);
        }
    }

    /** Метеоры — падают сверху вниз с разных сторон */
    private void spawnMeteor(double cx, double by, double cz, double r, int cnt) {
        for (int i = 0; i < cnt / 4; i++) {
            double a   = Math.random() * Math.PI * 2;
            double ox  = Math.cos(a) * r * (0.5 + Math.random() * 0.5);
            double oz  = Math.sin(a) * r * (0.5 + Math.random() * 0.5);
            double top = by + 3.0 + Math.random() * 1.5;
            // Оставляем шлейф сверху вниз
            int trail = 6;
            for (int t = 0; t < trail; t++) {
                double ty = top - t * 0.3;
                spawnAt(cx + ox, ty, cz + oz);
            }
        }
    }

    /** Постоянное мерцание блёсток вокруг тела */
    private void spawnSparkle(double cx, double by, double cz, double r, int cnt) {
        double h = mc.player.getHeight();
        for (int i = 0; i < cnt; i++) {
            double a   = Math.random() * Math.PI * 2;
            double rr  = r * (0.3 + Math.random() * 0.7);
            double vy  = by + Math.random() * h;
            mc.world.addParticle(
                getParticle(),
                cx + Math.cos(a) * rr, vy, cz + Math.sin(a) * rr,
                0, 0.04 + Math.random() * 0.04, 0
            );
        }
    }

    private void spawnAt(double x, double y, double z) {
        if (mc.world == null) return;
        mc.world.addParticle(getParticle(), x, y, z, 0, 0.01, 0);
    }

    private net.minecraft.particle.ParticleEffect getParticle() {
        return switch (particle.getCurrentOption()) {
            case "Enchant" -> ParticleTypes.ENCHANT;
            case "Soul"    -> ParticleTypes.SOUL;
            case "Flash"   -> ParticleTypes.FLASH;
            case "Glow"    -> ParticleTypes.GLOW;
            default        -> ParticleTypes.END_ROD;
        };
    }
}
