package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * HudClock — показывает реальное системное время на экране.
 *
 * Можно выбрать формат и добавить дату. Удобно во время стримов
 * или когда не хочется сворачивать игру для проверки времени.
 *
 * Настройки:
 *   Формат          — 12ч / 24ч
 *   Показывать дату — вкл/выкл
 *   Фон             — вкл/выкл
 *   Цвет текста     — White / Purple / Cyan / Gold / Red
 */
public class HudClock extends Module {

    private static final String[] FORMATS = {"24ч", "12ч"};
    private static final String[] COLORS  = {"White", "Purple", "Cyan", "Gold", "Red"};

    private final Setting timeFormat = new Setting("Формат",          FORMATS, 0);
    private final Setting showDate   = new Setting("Показывать дату", false);
    private final Setting showBg     = new Setting("Фон",             true);
    private final Setting textColor  = new Setting("Цвет текста",     COLORS,  1);

    private static final DateTimeFormatter FMT24 = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter FMT12 = DateTimeFormatter.ofPattern("hh:mm:ss a");
    private static final DateTimeFormatter DATE  = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public HudClock() {
        super("HudClock", "Системное время и дата на экране HUD", Category.HUD);
        this.x = 5;
        this.y = 160;
        this.width  = 80;
        this.height = 22;
        addSetting(timeFormat);
        addSetting(showDate);
        addSetting(showBg);
        addSetting(textColor);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled()) return;

        LocalDateTime now = LocalDateTime.now();
        boolean is24 = timeFormat.getCurrentOption().equals("24ч");
        String timeStr = now.format(is24 ? FMT24 : FMT12);
        String dateStr = showDate.getState() ? now.format(DATE) : null;

        int w = mc.textRenderer.getWidth(timeStr) + 8;
        int h = showDate.getState() ? 22 : 14;
        this.width  = Math.max(w, 80);
        this.height = h;

        if (showBg.getState()) {
            context.fill(x, y, x + width, y + height, 0x88000000);
        }

        int color = resolveColor();
        context.drawText(mc.textRenderer, timeStr, x + 4, y + 3, color, true);
        if (dateStr != null) {
            context.drawText(mc.textRenderer, dateStr, x + 4, y + 13, 0xFFAAAAAA, false);
        }
    }

    private int resolveColor() {
        return switch (textColor.getCurrentOption()) {
            case "Purple" -> EnkuronColor.PRIMARY;
            case "Cyan"   -> 0xFF44FFEE;
            case "Gold"   -> 0xFFFFCC44;
            case "Red"    -> 0xFFFF4444;
            default       -> 0xFFFFFFFF;
        };
    }
}
