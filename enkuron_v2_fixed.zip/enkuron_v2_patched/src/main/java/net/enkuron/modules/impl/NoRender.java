package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;

/**
 * NoRender — отключает лишние визуальные эффекты.
 *
 * noParticles   — подавляет добавление vanilla-частиц в мир через MixinParticleManager.
 * noFire        — убирает наложение огня на экране (через MixinInGameHud или здесь).
 * noTotemAnim   — отменяет анимацию тотема бессмертия.
 *
 * Частицы и тотем подавляются через MixinParticleManager / check в InGameHud.
 * Огонь на экране управляется напрямую через gameOptions.
 */
public class NoRender extends Module {
    private final Setting noParticles = new Setting("Частицы",         true);
    private final Setting noFire      = new Setting("Огонь на экране", true);
    private final Setting noTotemAnim = new Setting("Анимация тотема", true);

    public NoRender() {
        super("NoRender", "Отключает лишние визуальные эффекты", Category.VISUAL);
        addSetting(noParticles);
        addSetting(noFire);
        addSetting(noTotemAnim);
    }

    public boolean isNoParticles() { return isEnabled() && noParticles.getState(); }
    public boolean isNoFire()      { return isEnabled() && noFire.getState(); }
    public boolean isNoTotemAnim() { return isEnabled() && noTotemAnim.getState(); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.options == null) return;
        // Огонь на экране управляется через рендер-опцию overlay
        // Реальное подавление — в MixinInGameHud: если NoRender.isNoFire() → cancel renderFireOverlay
    }
}
