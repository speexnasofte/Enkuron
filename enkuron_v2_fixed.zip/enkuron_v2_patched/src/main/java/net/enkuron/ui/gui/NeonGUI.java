package net.enkuron.ui.gui;

import net.enkuron.modules.ColorSetting;
import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * NeonGUI v2 — обновлённый неоновый GUI.
 *
 * Новшества v2:
 *  - Поддержка ColorSetting в панели настроек (цветовой превью + rainbow toggle)
 *  - Поиск модулей (Ctrl+F / нажатие на иконку 🔍)
 *  - Анимированная индикаторная полоска модуля (цвет плавно меняется при вкл/выкл)
 *  - Уведомление о кол-ве активных модулей в заголовке
 *  - Закрытие по Escape
 */
public class NeonGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── Размеры ──────────────────────────────────────────────────────────────
    private static final int PANEL_W    = 240;
    private static final int PANEL_H    = 410;
    private static final int HEADER_H   = 36;
    private static final int SEARCH_H   = 22;
    private static final int TAB_H      = 24;
    private static final int ROW_H      = 26;
    private static final int SETTINGS_W = 210;
    private static final int S_ROW_H    = 30;

    // ── Категории ────────────────────────────────────────────────────────────
    private static final Module.Category[] CATS = {
        Module.Category.COMBAT, Module.Category.MOVEMENT, Module.Category.VISUAL,
        Module.Category.PLAYER, Module.Category.HUD, Module.Category.UTILITY,
        Module.Category.MISC
    };
    private static final Map<Module.Category, String> CAT_ICON = new EnumMap<>(Module.Category.class);
    static {
        CAT_ICON.put(Module.Category.COMBAT,   "⚔");
        CAT_ICON.put(Module.Category.MOVEMENT, "⚡");
        CAT_ICON.put(Module.Category.VISUAL,   "✦");
        CAT_ICON.put(Module.Category.PLAYER,   "♟");
        CAT_ICON.put(Module.Category.HUD,      "◈");
        CAT_ICON.put(Module.Category.MISC,     "★");
        CAT_ICON.put(Module.Category.UTILITY,  "⚙");
    }

    // ── Состояние ────────────────────────────────────────────────────────────
    private int panelX = 50, panelY = 40;
    private Module.Category activeTab   = Module.Category.COMBAT;
    private float  scrollOff  = 0, openAnim = 0;
    private Module settingsModule = null;
    private float  settingsAnim   = 0;
    private Setting draggingSetting = null;
    private int sliderBx, sliderBw;
    private boolean draggingPanel = false;
    private int dragOX, dragOY;

    // Поиск
    private boolean searchMode  = false;
    private String  searchQuery = "";

    // Анимации toggle
    private final Map<String, Float> toggleAnims  = new HashMap<>();
    // Анимации цвета боковой полоски (0=disabled, 1=enabled)
    private final Map<String, Float> accentAnims  = new HashMap<>();

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        openAnim = AnimationUtils.lerp(openAnim, 1f, 0.12f);

        Theme t  = ThemeManager.get();
        int pw   = PANEL_W;
        int ph   = (int)(PANEL_H * openAnim);
        int px   = panelX, py = panelY;

        // Тень
        ctx.fill(px+5, py+5, px+pw+5, py+ph+5, 0x44000000);
        // Фон
        ctx.fill(px, py, px+pw, py+ph, t.bg);
        // Рамка
        ctx.fill(px,      py,      px+pw,    py+1,    t.accent);
        ctx.fill(px,      py+ph-1, px+pw,    py+ph,   t.accent2);
        ctx.fill(px,      py,      px+1,     py+ph,   t.accent);
        ctx.fill(px+pw-1, py,      px+pw,    py+ph,   t.accent2);

        // Заголовок
        ctx.fill(px, py, px+pw, py+HEADER_H, t.panel);
        long activeCount = ModuleManager.getModules().stream().filter(Module::isEnabled).count();
        String title = "§lEnkuron §8| §7" + GUIManager.getStyleName()
                       + " §8/ §7" + t.name
                       + " §8[§7" + activeCount + "§8]";
        ctx.drawText(mc.textRenderer, title, px+8, py+13, t.accent, false);
        // Иконка поиска
        String searchIcon = searchMode ? "§c✕" : "§7🔍";
        ctx.drawText(mc.textRenderer, searchIcon, px+pw-16, py+13, t.textMuted, false);

        if (ph < HEADER_H + TAB_H + ROW_H) return;

        // Поиск
        if (searchMode) {
            renderSearchBar(ctx, px, py, pw, t);
        }

        // Табы
        int tabYStart = py + HEADER_H + (searchMode ? SEARCH_H : 0);
        renderTabs(ctx, px, tabYStart, pw, t, mx, my);

        // Список
        int listYStart = tabYStart + TAB_H;
        int listH = ph - (listYStart - py);
        renderModuleList(ctx, px, listYStart, pw, listH, ph, t, mx, my);

        // Панель настроек
        if (settingsModule != null) {
            settingsAnim = AnimationUtils.lerp(settingsAnim, 1f, 0.15f);
            renderSettingsPanel(ctx, px, py, pw, ph, t, mx, my);
        } else {
            settingsAnim = AnimationUtils.lerp(settingsAnim, 0f, 0.15f);
        }
    }

    private void renderSearchBar(DrawContext ctx, int px, int py, int pw, Theme t) {
        int sy = py + HEADER_H;
        ctx.fill(px, sy, px+pw, sy+SEARCH_H, t.bgA(230));
        ctx.fill(px, sy+SEARCH_H-1, px+pw, sy+SEARCH_H, t.accent);
        String display = "§7🔍 §f" + (searchQuery.isEmpty() ? "§8Поиск..." : searchQuery);
        ctx.drawText(mc.textRenderer, display, px+6, sy+6, t.text, false);
    }

    private void renderTabs(DrawContext ctx, int px, int tabY, int pw, Theme t, int mx, int my) {
        int tabW = pw / CATS.length;
        ctx.fill(px, tabY, px+pw, tabY+TAB_H, t.panel);
        for (int i = 0; i < CATS.length; i++) {
            Module.Category cat = CATS[i];
            int tx = px + i * tabW;
            boolean active = cat == activeTab;
            boolean hover  = mx >= tx && mx < tx+tabW && my >= tabY && my < tabY+TAB_H;
            if (active) {
                ctx.fill(tx, tabY, tx+tabW, tabY+TAB_H, t.accentA(40));
                ctx.fill(tx, tabY+TAB_H-2, tx+tabW, tabY+TAB_H, t.accent);
            } else if (hover) {
                ctx.fill(tx, tabY, tx+tabW, tabY+TAB_H, t.accentA(18));
            }
            String icon = CAT_ICON.getOrDefault(cat, "?");
            int iw = mc.textRenderer.getWidth(icon);
            ctx.drawText(mc.textRenderer, icon, tx + (tabW-iw)/2, tabY+7,
                         active ? t.accent : t.textMuted, false);
        }
    }

    private void renderModuleList(DrawContext ctx, int px, int listY, int pw, int listH,
                                  int ph, Theme t, int mx, int my) {
        List<Module> mods = getVisibleModules();
        int y = listY + (int)(-scrollOff);
        for (Module mod : mods) {
            if (y + ROW_H < listY || y > listY + listH) { y += ROW_H; continue; }

            boolean on    = mod.isEnabled();
            boolean hover = mx >= px+2 && mx < px+pw-2 && my >= y && my < y+ROW_H-1;

            // Анимации
            String uid = mod.getName();
            float togAnim   = toggleAnims.getOrDefault(uid, on ? 1f : 0f);
            togAnim = AnimationUtils.lerp(togAnim, on ? 1f : 0f, 0.15f);
            toggleAnims.put(uid, togAnim);

            float accAnim = accentAnims.getOrDefault(uid, on ? 1f : 0f);
            accAnim = AnimationUtils.lerp(accAnim, on ? 1f : 0f, 0.10f);
            accentAnims.put(uid, accAnim);

            // Строка
            int rowBg = hover ? t.accentA(30) : t.bgA(200);
            ctx.fill(px+2, y, px+pw-2, y+ROW_H-1, rowBg);

            // Левая полоска — цвет анимирован
            int sideColor = interpolateColor(t.accent2 & 0x00FFFFFF | 0x55000000, t.accent, accAnim);
            ctx.fill(px+2, y, px+4, y+ROW_H-1, sideColor | 0xFF000000);

            // Имя
            ctx.drawText(mc.textRenderer, mod.getName(), px+10, y+9,
                         on ? t.text : t.textMuted, false);

            // Toggle switch
            drawToggle(ctx, px+pw-44, y+7, 30, 12, togAnim, t);

            // Кнопка настроек ►
            var settings = mod.getSettings();
            if (!settings.isEmpty()) {
                boolean settHov = mx >= px+pw-16 && mx < px+pw-4 && my >= y && my < y+ROW_H-1;
                ctx.fill(px+pw-16, y+4, px+pw-4, y+ROW_H-5, settHov ? t.accentA(80) : t.accentA(30));
                ctx.drawText(mc.textRenderer, settingsModule == mod ? "◄" : "►",
                             px+pw-14, y+9, t.accent, false);
            }
            y += ROW_H;
        }
    }

    private void drawToggle(DrawContext ctx, int x, int y, int w, int h, float anim, Theme t) {
        int bgColor = interpolateColor(0xFF333344, t.accent, anim);
        ctx.fill(x, y, x+w, y+h, bgColor);
        int circleX = x + 2 + (int)((w - h) * anim);
        int circleS = h - 4;
        ctx.fill(circleX, y+2, circleX+circleS, y+2+circleS, 0xFFFFFFFF);
    }

    private void renderSettingsPanel(DrawContext ctx, int px, int py, int pw, int ph,
                                     Theme t, int mx, int my) {
        if (settingsModule == null || settingsAnim < 0.02f) return;
        int sw = (int)(SETTINGS_W * settingsAnim);
        int sx = px + pw, sy = py;

        ctx.fill(sx, sy, sx+sw, sy+ph, t.panel);
        ctx.fill(sx, sy, sx+sw, sy+1,  t.accent);
        ctx.fill(sx, sy, sx+1,  sy+ph, t.accent2);

        ctx.fill(sx, sy, sx+sw, sy+HEADER_H, t.bg);
        ctx.drawText(mc.textRenderer, "§l" + settingsModule.getName(), sx+6, sy+13, t.accent, false);

        int ry = sy + HEADER_H + 4;
        for (Setting s : settingsModule.getSettings()) {
            if (ry > sy + ph - 10) break;
            ctx.drawText(mc.textRenderer, "§7" + s.getName(), sx+6, ry, t.textMuted, false);
            ry += 10;

            switch (s.getType()) {
                case BOOLEAN -> {
                    float ba = s.getState() ? 1f : 0f;
                    drawToggle(ctx, sx+6, ry, 28, 10, ba, t);
                    ctx.drawText(mc.textRenderer, s.getState() ? "§aВкл" : "§cВыкл",
                                 sx+38, ry, t.textMuted, false);
                    ry += 14;
                }
                case NUMBER -> {
                    int barW = sw - 12;
                    float ratio = (float)((s.getValue() - s.getMin()) / (s.getMax() - s.getMin()));
                    // Фон слайдера
                    ctx.fill(sx+6, ry+3, sx+6+barW, ry+7, 0xFF1A1A28);
                    // Заполненная часть
                    ctx.fill(sx+6, ry+3, sx+6+(int)(barW*ratio), ry+7, t.accent);
                    // Ручка
                    int hx = sx+6+(int)(barW*ratio);
                    ctx.fill(hx-3, ry, hx+3, ry+11, 0xFFFFFFFF);
                    ctx.fill(hx-2, ry+1, hx+2, ry+10, t.accent);
                    String val = String.format("%.2f", s.getValue());
                    ctx.drawText(mc.textRenderer, val, sx+sw-mc.textRenderer.getWidth(val)-4, ry+1, t.text, false);
                    ry += 17;
                }
                case ENUM -> {
                    int ex = sx+6;
                    for (String opt : s.getOptions()) {
                        boolean active = opt.equals(s.getCurrentOption());
                        int bw = mc.textRenderer.getWidth(opt) + 6;
                        if (ex + bw > sx + sw - 4) { ex = sx+6; ry += 12; }
                        ctx.fill(ex, ry, ex+bw, ry+11, active ? t.accent : t.accentA(45));
                        if (active) ctx.fill(ex, ry+10, ex+bw, ry+11, t.accent2);
                        ctx.drawText(mc.textRenderer, opt, ex+3, ry+2,
                                     active ? 0xFFFFFFFF : t.textMuted, false);
                        ex += bw + 3;
                    }
                    ry += 15;
                }
            }
            ry += 5;
        }
    }

    // ── Ввод ─────────────────────────────────────────────────────────────────

    @Override
    public void mouseClicked(double mx, double my, int btn) {
        int px = panelX, py = panelY;

        // Иконка поиска
        if (btn == 0 && mx >= px+PANEL_W-18 && mx < px+PANEL_W-2 && my >= py && my < py+HEADER_H) {
            searchMode = !searchMode;
            if (!searchMode) searchQuery = "";
            settingsModule = null;
            return;
        }

        // Перетаскивание заголовка
        if (btn == 0 && mx >= px && mx < px+PANEL_W && my >= py && my < py+HEADER_H) {
            draggingPanel = true; dragOX = (int)(mx-px); dragOY = (int)(my-py); return;
        }

        // Табы
        int searchExtra = searchMode ? SEARCH_H : 0;
        int tabY = py + HEADER_H + searchExtra;
        if (my >= tabY && my < tabY + TAB_H && mx >= px && mx < px+PANEL_W) {
            int tabW = PANEL_W / CATS.length;
            int idx  = (int)((mx - px) / tabW);
            if (idx >= 0 && idx < CATS.length) { activeTab = CATS[idx]; settingsModule = null; return; }
        }

        // Клик по строке модуля
        int listY = tabY + TAB_H;
        List<Module> mods = getVisibleModules();
        int y = listY + (int)(-scrollOff);
        for (Module mod : mods) {
            if (my >= y && my < y + ROW_H - 1 && mx >= px+2 && mx < px+PANEL_W-2) {
                var settings = mod.getSettings();
                if (!settings.isEmpty() && mx >= px+PANEL_W-16 && mx < px+PANEL_W-4) {
                    settingsModule = settingsModule == mod ? null : mod;
                } else {
                    mod.toggle();
                }
                return;
            }
            y += ROW_H;
        }

        // Клик в настройках
        if (settingsModule != null) {
            int sw = SETTINGS_W, sx = px+PANEL_W, sy = py;
            if (mx >= sx && mx < sx+sw) {
                int ry = sy + HEADER_H + 4;
                for (Setting s : settingsModule.getSettings()) {
                    ry += 10;
                    if (s.getType() == Setting.Type.BOOLEAN && my >= ry && my < ry+10) {
                        s.toggleState(); return;
                    }
                    if (s.getType() == Setting.Type.NUMBER && my >= ry && my < ry+11) {
                        int barW = sw-12;
                        double ratio = Math.max(0, Math.min(1, (mx-sx-6)/barW));
                        s.setValue(s.getMin() + ratio*(s.getMax()-s.getMin()));
                        draggingSetting = s; sliderBx = sx+6; sliderBw = barW; return;
                    }
                    if (s.getType() == Setting.Type.ENUM && my >= ry && my < ry+11) {
                        s.cycleOption(); return;
                    }
                    ry += switch (s.getType()) { case BOOLEAN -> 14; case NUMBER -> 17; case ENUM -> 15; default -> 14; } + 5;
                }
            }
        }
    }

    @Override
    public void mouseReleased(double mx, double my, int btn) {
        draggingPanel = false; draggingSetting = null;
    }

    @Override
    public void mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingPanel) { panelX = (int)(mx-dragOX); panelY = (int)(my-dragOY); return; }
        if (draggingSetting != null) {
            double ratio = Math.max(0, Math.min(1, (mx-sliderBx)/(double)sliderBw));
            draggingSetting.setValue(draggingSetting.getMin() + ratio*(draggingSetting.getMax()-draggingSetting.getMin()));
        }
    }

    @Override
    public void mouseScrolled(double mx, double my, double sx, double sy) {
        int px = panelX, py = panelY;
        if (mx >= px && mx < px+PANEL_W && my >= py && my < py+PANEL_H) {
            long count = getVisibleModules().size();
            float maxScroll = Math.max(0, (float)(count * ROW_H - (PANEL_H - HEADER_H - TAB_H)));
            scrollOff = Math.max(0, Math.min(maxScroll, scrollOff - (float)(sy * 15)));
        }
    }

    @Override
    public void keyPressed(int key, int scan, int mods) {
        // Escape закрывает GUI
        if (key == 256) { mc.setScreen(null); return; }
        // Backspace в режиме поиска
        if (searchMode && key == 259 && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length()-1);
        }
    }

    @Override
    public void charTyped(char c, int mods) {
        if (searchMode && Character.isLetterOrDigit(c) || c == ' ') {
            searchQuery += c;
        }
    }

    // ── Утилиты ──────────────────────────────────────────────────────────────

    private List<Module> getVisibleModules() {
        return ModuleManager.getModules().stream()
            .filter(m -> m.getCategory() == activeTab)
            .filter(m -> searchQuery.isEmpty() ||
                         m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
            .toList();
    }

    private int interpolateColor(int c1, int c2, float t) {
        int r = (int)(((c1>>16)&0xFF)*(1-t) + ((c2>>16)&0xFF)*t);
        int g = (int)(((c1>> 8)&0xFF)*(1-t) + ((c2>> 8)&0xFF)*t);
        int b = (int)(( c1     &0xFF)*(1-t) + ( c2     &0xFF)*t);
        return (r<<16)|(g<<8)|b;
    }
}
