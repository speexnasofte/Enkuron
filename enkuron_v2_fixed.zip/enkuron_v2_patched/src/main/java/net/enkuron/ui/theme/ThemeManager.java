package net.enkuron.ui.theme;

/**
 * ThemeManager v2 — система тем для всего клиента.
 *
 * Темы задают все цвета GUI: фон, акцент, текст, полосы и т.д.
 * Любой GUI считывает цвета через ThemeManager.get().
 *
 * Встроенные темы:
 *   NEON    — фиолетовый неон (дефолт)
 *   BLUE    — синий / кибер
 *   RED     — красный / бойцовый
 *   MINT    — бирюзовый / минимал
 *   DARK    — тёмный монохром
 *   GOLD    — золотой премиум
 *   AURORA  — аврора (зелёно-голубой северный свет) [НОВОЕ]
 *   SAKURA  — розово-белый японский стиль [НОВОЕ]
 */
public class ThemeManager {

    public enum ThemeType { NEON, BLUE, RED, MINT, DARK, GOLD, AURORA, SAKURA }

    private static ThemeType current = ThemeType.NEON;

    // ── Встроенные темы ───────────────────────────────────────────────────────

    public static final Theme THEME_NEON = new Theme(
        "Neon",
        0xEE0D0D18,   // bg
        0xFF8844FF,   // accent
        0xFF6622CC,   // accent2
        0xFFFFFFFF,   // text
        0xFFAAAAAA,   // textMuted
        0xFF44EE88,   // positive
        0xFFEE3333,   // negative
        0xBB151520    // panel
    );

    public static final Theme THEME_BLUE = new Theme(
        "Blue",
        0xEE0A0F1E,
        0xFF2299FF,
        0xFF1166CC,
        0xFFFFFFFF,
        0xFF99BBDD,
        0xFF44DDFF,
        0xFFFF4455,
        0xBB0D1428
    );

    public static final Theme THEME_RED = new Theme(
        "Red",
        0xEE180808,
        0xFFCC2233,
        0xFF881122,
        0xFFFFEEEE,
        0xFFBB9999,
        0xFFFF6666,
        0xFFFF2222,
        0xBB1A0808
    );

    public static final Theme THEME_MINT = new Theme(
        "Mint",
        0xEE080F10,
        0xFF00CCAA,
        0xFF008877,
        0xFFEEFFFF,
        0xFF88BBBB,
        0xFF44FFCC,
        0xFFFF5566,
        0xBB081212
    );

    public static final Theme THEME_DARK = new Theme(
        "Dark",
        0xEE0A0A0A,
        0xFF555555,
        0xFF333333,
        0xFFDDDDDD,
        0xFF888888,
        0xFFAAAAAA,
        0xFFEE4444,
        0xBB111111
    );

    public static final Theme THEME_GOLD = new Theme(
        "Gold",
        0xEE0F0C00,
        0xFFFFAA00,
        0xFFCC8800,
        0xFFFFEECC,
        0xFFBBAA88,
        0xFFFFCC44,
        0xFFFF4444,
        0xBB130F00
    );

    // ── НОВЫЕ ТЕМЫ ────────────────────────────────────────────────────────────

    /**
     * AURORA — тема "Северное сияние".
     * Тёмный тёмно-синий фон, акцент — переливающийся зелёно-голубой.
     * Идеально для ночных сессий и PvP.
     */
    public static final Theme THEME_AURORA = new Theme(
        "Aurora",
        0xEE050F12,   // bg — почти чёрный с синим отливом
        0xFF00FFB0,   // accent — аквамариновый неон
        0xFF007A9E,   // accent2 — насыщенный бирюзовый
        0xFFEAFFFF,   // text — холодный белый
        0xFF5BBBCC,   // textMuted — голубоватый серый
        0xFF44FFAA,   // positive — светло-зелёный
        0xFFFF3355,   // negative — розово-красный
        0xBB071520    // panel — почти чёрный
    );

    /**
     * SAKURA — тема "Цветение сакуры".
     * Тёмно-фиолетовый фон, нежные розово-белые акценты.
     * Мягкий и элегантный стиль.
     */
    public static final Theme THEME_SAKURA = new Theme(
        "Sakura",
        0xEE110910,   // bg — тёмно-фиолетовый
        0xFFFF88BB,   // accent — сакурово-розовый
        0xFFCC5599,   // accent2 — тёмно-розовый
        0xFFFFF0F5,   // text — молочно-белый
        0xFFCCABBB,   // textMuted — розово-серый
        0xFFFFAACC,   // positive — светло-розовый
        0xFFFF4477,   // negative — яркий малиновый
        0xBB190D18    // panel — тёмно-фиолетовый
    );

    private static final Theme[] ALL = {
        THEME_NEON, THEME_BLUE, THEME_RED, THEME_MINT,
        THEME_DARK, THEME_GOLD, THEME_AURORA, THEME_SAKURA
    };

    // ── API ───────────────────────────────────────────────────────────────────

    public static Theme get() {
        return switch (current) {
            case BLUE   -> THEME_BLUE;
            case RED    -> THEME_RED;
            case MINT   -> THEME_MINT;
            case DARK   -> THEME_DARK;
            case GOLD   -> THEME_GOLD;
            case AURORA -> THEME_AURORA;
            case SAKURA -> THEME_SAKURA;
            default     -> THEME_NEON;
        };
    }

    public static ThemeType getCurrent()             { return current; }
    public static void       setCurrent(ThemeType t) { current = t; }

    public static void next() {
        ThemeType[] vals = ThemeType.values();
        current = vals[(current.ordinal() + 1) % vals.length];
    }

    public static Theme[] getAll() { return ALL; }

    public static void setByName(String name) {
        for (ThemeType t : ThemeType.values()) {
            if (t.name().equalsIgnoreCase(name)) { current = t; return; }
        }
    }

    /** Имя текущей темы для отображения */
    public static String getCurrentName() { return get().name; }
}
