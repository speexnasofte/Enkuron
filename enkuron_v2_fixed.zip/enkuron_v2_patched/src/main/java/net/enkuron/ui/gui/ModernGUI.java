package net.enkuron.ui.gui;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.LivingEntity;

import java.util.*;

/**
 * ModernGUI v3 — Топовый ClickGUI.
 *
 * Что нового в v3:
 *  - Поиск по ВСЕМ категориям одновременно (не только текущей)
 *  - Keybind отображается в строке модуля ([CTRL+K])
 *  - Счётчик включённых в бейдже категории плавно анимирован
 *  - Боковая полоска у активной категории = gradient accent→accent2
 *  - Settings panel: слайдеры реагируют на drag (mouseSliderDrag)
 *  - Панель прокручивается колёсиком с momentum (плавное замедление)
 *  - Header-кнопка закрыть (×) в правом углу панели модулей
 *  - Общий счётчик включённых модулей в заголовке
 *  - Esc: сначала закрывает settings, потом search, потом GUI
 *  - Весь render-код без тяжёлых вычислений (логика только в tick)
 */
public class ModernGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── Размеры ────────────────────────────────────────────────────────────
    private static final int CAT_W    = 116;
    private static final int MOD_W    = 162;
    private static final int SET_W    = 204;
    private static final int PANEL_H  = 380;
    private static final int HEADER_H = 36;
    private static final int CAT_ROW  = 28;
    private static final int MOD_ROW  = 24;
    private static final int SEARCH_H = 22;

    // ── Цвета (статичные, акценты берём из Theme) ─────────────────────────
    private static final int BG_DARK   = 0xF01A1A22;
    private static final int BG_PANEL  = 0xF0222230;
    private static final int BG_HOVER  = 0xFF2C2C3E;
    private static final int BG_ACTIVE = 0xFF30304A;
    private static final int BG_SEARCH = 0xFF1E1E2A;
    private static final int COL_WHITE = 0xFFFFFFFF;
    private static final int COL_GRAY  = 0xFF9999AA;
    private static final int COL_DIM   = 0xFF555566;

    // ── Категории ─────────────────────────────────────────────────────────
    private static final Module.Category[] CATS = {
        Module.Category.COMBAT, Module.Category.MOVEMENT, Module.Category.VISUAL,
        Module.Category.PLAYER, Module.Category.HUD,      Module.Category.UTILITY,
        Module.Category.MISC
    };
    private static final String[] CAT_ICON = {"⚔","⚡","✦","♟","◈","⚙","★"};
    private static final String[] CAT_NAME = {"Combat","Movement","Visual","Player","HUD","Utility","Misc"};

    // ── Состояние ─────────────────────────────────────────────────────────
    private int     panelX = Integer.MIN_VALUE;
    private int     panelY;
    private boolean centered = false;

    private int    activeCatIdx  = 0;
    private Module settingsMod   = null;

    // Анимации
    private float openAnim     = 0f;  // 0→1 при открытии
    private float settingsAnim = 0f;  // 0→1 при открытии panel settings

    // Анимации toggle-переключателей: uid → [0,1]
    private final Map<String, Float> toggleAnims = new HashMap<>();
    // Fade-in строк модулей
    private final Map<String, Float> fadeAnims   = new HashMap<>();
    // Анимация бейджа категорий (плавный счётчик)
    private final Map<Integer, Float> badgeAnims = new HashMap<>();

    // Drag панели
    private boolean draggingPanel = false;
    private int     dragOffX, dragOffY;

    // Scroll: текущий и целевой + momentum
    private float scrollCur = 0f;
    private float scrollTgt = 0f;
    private float scrollMomentum = 0f;

    // Поиск
    private boolean searchActive = false;
    private String  searchQuery  = "";
    private boolean searchAll    = false; // если true — ищем по всем категориям

    // Slider drag
    private Setting draggingSlider = null;
    private int     sliderX0, sliderW0;

    // Entity viewer в settings
    private float entityYaw   = 35f;
    private float entityPitch = -10f;
    private boolean draggingEntity = false;

    // Кэш для предыдущей категории (сброс scroll при смене)
    private int lastCatIdx = -1;

    // Hover-кэш для button ×
    private boolean hoverClose = false;

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Центрируем панель один раз
        if (!centered) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            panelX = (sw - CAT_W - MOD_W) / 2 - CAT_W / 2;
            panelY = (sh - PANEL_H) / 2;
            centered = true;
        }

        // Анимация открытия (easeInOut)
        openAnim = AnimationUtils.lerp(openAnim, 1f, 0.12f);
        int ph = (int)(PANEL_H * AnimationUtils.easeInOut(openAnim));
        if (ph < 8) return;

        // Анимация settings-панели
        float saTarget = settingsMod != null ? 1f : 0f;
        settingsAnim   = AnimationUtils.lerp(settingsAnim, saTarget, 0.14f);
        int settingsW  = (int)(SET_W * AnimationUtils.smoothStep(settingsAnim));

        // Momentum scroll
        scrollMomentum *= 0.85f;
        scrollTgt += scrollMomentum;
        scrollTgt = Math.max(0f, scrollTgt);
        scrollCur = AnimationUtils.lerp(scrollCur, scrollTgt, 0.18f);

        // Hover кнопки ×
        int closeX = panelX + CAT_W + MOD_W - 14;
        int closeY = panelY + 10;
        hoverClose = inBox(mx, my, closeX, closeY, 12, 12);

        Theme t = ThemeManager.get();

        // Тень GUI
        drawShadow(ctx, panelX, panelY, CAT_W + MOD_W + settingsW, ph);

        // Три колонки
        drawCategoryPanel(ctx, panelX,          panelY, ph, t, mx, my);
        drawModulePanel  (ctx, panelX + CAT_W,  panelY, ph, t, mx, my, settingsW);
        if (settingsW > 4) {
            drawSettingsPanel(ctx, panelX + CAT_W + MOD_W, panelY, ph, settingsW, t, mx, my);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ПАНЕЛЬ КАТЕГОРИЙ
    // ═══════════════════════════════════════════════════════════════════════

    private void drawCategoryPanel(DrawContext ctx, int px, int py, int ph, Theme t, int mx, int my) {
        fill(ctx, px, py, CAT_W, ph, BG_DARK);

        // Верхний акцент-бордер
        ctx.fill(px, py, px + CAT_W, py + 2, t.accent);

        // Логотип
        ctx.drawText(mc.textRenderer, "§lEnkuron", px + 10, py + 10, t.accent, false);

        // Счётчик включённых
        long total = ModuleManager.getModules().stream().filter(Module::isEnabled).count();
        ctx.drawText(mc.textRenderer, "§8" + total + " active", px + 10, py + 22, COL_DIM, false);

        ctx.fill(px + 6, py + HEADER_H, px + CAT_W - 6, py + HEADER_H + 1, 0xFF2A2A3A);

        // Список категорий
        int cy = py + HEADER_H + 4;
        for (int i = 0; i < CATS.length; i++) {
            final int ci = i;
            boolean active = (i == activeCatIdx) && !searchAll;
            boolean hover  = !active && inBox(mx, my, px + 4, cy, CAT_W - 8, CAT_ROW);

            if (active)     fill(ctx, px + 4, cy, CAT_W - 8, CAT_ROW, BG_ACTIVE);
            else if (hover) fill(ctx, px + 4, cy, CAT_W - 8, CAT_ROW, BG_HOVER);

            // Градиентная боковая полоска для активной категории
            if (active) {
                for (int yy = cy; yy < cy + CAT_ROW; yy++) {
                    float f = (float)(yy - cy) / CAT_ROW;
                    int c = lerpColor(t.accent, t.accent2, f);
                    ctx.fill(px + 4, yy, px + 6, yy + 1, 0xFF000000 | (c & 0xFFFFFF));
                }
            }

            ctx.drawText(mc.textRenderer, CAT_ICON[i], px + 12, cy + 9, active ? t.accent : COL_GRAY, false);
            ctx.drawText(mc.textRenderer, CAT_NAME[i], px + 26, cy + 9, active ? COL_WHITE : COL_GRAY, false);

            // Бейдж включённых с плавной анимацией
            long catOn = ModuleManager.getModules().stream()
                .filter(m -> m.getCategory() == CATS[ci] && m.isEnabled()).count();
            float badgeTgt = (float) catOn;
            float badgeCur = AnimationUtils.lerp(badgeAnims.getOrDefault(i, badgeTgt), badgeTgt, 0.2f);
            badgeAnims.put(i, badgeCur);

            if (badgeCur > 0.05f) {
                int bVal = Math.round(badgeCur);
                String b  = String.valueOf(bVal);
                int bw    = mc.textRenderer.getWidth(b) + 6;
                int bx    = px + CAT_W - bw - 6;
                int ba    = (int)(Math.min(1f, badgeCur) * 180);
                ctx.fill(bx, cy + 7, bx + bw, cy + 20, (ba << 24) | (t.accent & 0xFFFFFF));
                ctx.drawText(mc.textRenderer, b, bx + 3, cy + 10, applyAlpha(t.accent, 255), false);
            }

            cy += CAT_ROW;
        }

        // Кнопка Search (внизу)
        int sy = py + ph - SEARCH_H - 4;
        boolean sh = inBox(mx, my, px + 6, sy, CAT_W - 12, SEARCH_H);
        fill(ctx, px + 6, sy, CAT_W - 12, SEARCH_H,
             searchActive ? BG_ACTIVE : (sh ? BG_HOVER : BG_SEARCH));

        String sqText = searchActive
            ? (searchQuery.isEmpty() ? "§8search..." : "§f" + searchQuery) + "§7|"
            : "§8⌕ Search";
        ctx.drawText(mc.textRenderer, sqText, px + 12, sy + 7, COL_GRAY, false);

        // Индикатор "All" если ищем по всем
        if (searchActive && searchAll) {
            ctx.drawText(mc.textRenderer, "§8all", px + CAT_W - 22, sy + 7, t.accent, false);
        }

        // Нижний accent2 бордер
        ctx.fill(px, py + ph - 2, px + CAT_W, py + ph, t.accent2);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ПАНЕЛЬ МОДУЛЕЙ
    // ═══════════════════════════════════════════════════════════════════════

    private void drawModulePanel(DrawContext ctx, int px, int py, int ph, Theme t,
                                  int mx, int my, int settingsW) {
        fill(ctx, px, py, MOD_W, ph, BG_PANEL);
        ctx.fill(px, py, px + MOD_W, py + 2, t.accent);

        // Заголовок
        String title = searchActive
            ? "§7⌕ " + (searchQuery.isEmpty() ? "search..." : searchQuery)
            : CAT_ICON[activeCatIdx] + " §l" + CAT_NAME[activeCatIdx];
        ctx.drawText(mc.textRenderer, title, px + 10, py + 13, searchActive ? COL_GRAY : t.accent, false);

        // Кнопка закрыть (×)
        int closeX = px + MOD_W - 14;
        ctx.drawText(mc.textRenderer, hoverClose ? "§c×" : "§8×", closeX, py + 12, COL_GRAY, false);

        ctx.fill(px + 4, py + HEADER_H, px + MOD_W - 4, py + HEADER_H + 1, 0xFF2A2A3A);

        List<Module> mods = getVisible();

        // Лимит scroll
        int listH  = ph - HEADER_H - 4;
        float maxSc = Math.max(0f, mods.size() * MOD_ROW - listH);
        scrollTgt  = Math.max(0f, Math.min(scrollTgt, maxSc));

        // Сброс при смене категории
        if (lastCatIdx != activeCatIdx) {
            lastCatIdx = activeCatIdx;
            fadeAnims.clear();
            scrollTgt = 0; scrollCur = 0; scrollMomentum = 0;
        }

        int listStartY = py + HEADER_H + 2;
        int y0         = listStartY - (int) scrollCur;

        for (int i = 0; i < mods.size(); i++) {
            Module mod = mods.get(i);
            int ry = y0 + i * MOD_ROW;
            if (ry + MOD_ROW < listStartY || ry > py + ph - 4) continue;

            boolean on  = mod.isEnabled();
            boolean sel = mod == settingsMod;
            boolean hov = !sel && inBox(mx, my, px + 2, ry, MOD_W - 4, MOD_ROW - 1);

            // Fade-in при открытии
            String uid = mod.getName();
            float ftgt = Math.max(0f, Math.min(1f, openAnim * 5f - i * 0.06f));
            float fade = AnimationUtils.lerp(fadeAnims.getOrDefault(uid, 0f), ftgt, 0.15f);
            fadeAnims.put(uid, fade);
            int fa = (int)(fade * 255);

            // Фон строки
            if (sel) {
                fill(ctx, px + 2, ry, MOD_W - 4, MOD_ROW - 1, applyAlpha(BG_ACTIVE, fa));
                ctx.fill(px + 2, ry, px + 4, ry + MOD_ROW - 1, applyAlpha(t.accent, fa));
            } else if (hov) {
                fill(ctx, px + 2, ry, MOD_W - 4, MOD_ROW - 1, applyAlpha(BG_HOVER, fa));
            }

            // Toggle animation
            float togTarget = on ? 1f : 0f;
            float togCur = AnimationUtils.lerp(toggleAnims.getOrDefault(uid, togTarget), togTarget, 0.14f);
            toggleAnims.put(uid, togCur);

            // Название
            ctx.drawText(mc.textRenderer, mod.getName(), px + 10, ry + 8,
                         applyAlpha(on ? COL_WHITE : COL_GRAY, fa), false);

            // Keybind (если есть)
            if (mod.getKey() > 0) {
                String kb = "§8[" + net.minecraft.client.util.InputUtil.fromKeyCode(mod.getKey(), 0).getLocalizedText().getString() + "]";
                int kbW = mc.textRenderer.getWidth(kb);
                ctx.drawText(mc.textRenderer, kb, px + MOD_W - kbW - 38, ry + 8, applyAlpha(COL_DIM, fa), false);
            }

            // Toggle-пиктограмма
            drawToggle(ctx, px + MOD_W - 36, ry + 7, 28, 10, togCur, t, fa);

            // Стрелка настроек
            if (!mod.getSettings().isEmpty()) {
                boolean arH = inBox(mx, my, px + MOD_W - 52, ry, 14, MOD_ROW - 1);
                ctx.drawText(mc.textRenderer,
                             sel ? "§7◀" : (arH ? "§f▶" : "§8▶"),
                             px + MOD_W - 52, ry + 8, applyAlpha(sel ? t.accent : COL_DIM, fa), false);
            }
        }

        // Scroll-индикатор
        if (maxSc > 0) {
            float ratio   = scrollCur / maxSc;
            int   barH    = Math.max(20, (int)(listH * ((float)listH / (mods.size() * MOD_ROW))));
            int   barY    = listStartY + (int)((listH - barH) * ratio);
            ctx.fill(px + MOD_W - 3, barY, px + MOD_W - 1, barY + barH, t.accentA(100));
        }

        ctx.fill(px, py + ph - 2, px + MOD_W, py + ph, t.accent2);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ПАНЕЛЬ НАСТРОЕК
    // ═══════════════════════════════════════════════════════════════════════

    private void drawSettingsPanel(DrawContext ctx, int px, int py, int ph, int sw,
                                    Theme t, int mx, int my) {
        fill(ctx, px, py, sw, ph, BG_DARK);
        ctx.fill(px, py, px + sw, py + 2, t.accent2);

        if (settingsMod == null) return;

        // Заголовок
        ctx.drawText(mc.textRenderer, "§l" + settingsMod.getName(), px + 8, py + 10, t.accent, false);
        String desc = trunc(settingsMod.getDescription(), sw - 16);
        ctx.drawText(mc.textRenderer, "§8" + desc, px + 8, py + 22, COL_DIM, false);
        ctx.fill(px + 4, py + HEADER_H, px + sw - 4, py + HEADER_H + 1, 0xFF2A2A3A);

        // Entity viewer
        int eH  = 100;
        int eY  = py + HEADER_H + 4;
        fill(ctx, px + 4, eY, sw - 8, eH, 0xFF181820);

        LivingEntity ent = mc.player;
        if (ent != null) {
            if (inBox(mx, my, px + 4, eY, sw - 8, eH) && draggingEntity) {
                entityYaw   = AnimationUtils.lerp(entityYaw,   (float)((px + sw / 2f - mx) * 0.6f), 0.15f);
                entityPitch = AnimationUtils.lerp(entityPitch, (float)((eY + eH / 2f - my) * 0.4f), 0.15f);
            }
            try {
                InventoryScreen.drawEntity(ctx, px + 4, eY, px + sw - 4, eY + eH,
                        38, 0f, entityYaw, entityPitch, ent);
            } catch (Exception ignored) {}
        }

        // Настройки
        int ry = eY + eH + 8;
        for (Setting s : settingsMod.getSettings()) {
            if (ry + 32 > py + ph - 6) break;

            ctx.drawText(mc.textRenderer, "§8" + s.getName(), px + 8, ry, COL_DIM, false);
            ry += 12;

            switch (s.getType()) {
                case BOOLEAN -> {
                    String bKey = "__s_" + s.getName();
                    float ba = AnimationUtils.lerp(
                        toggleAnims.getOrDefault(bKey, s.getState() ? 1f : 0f),
                        s.getState() ? 1f : 0f, 0.14f);
                    toggleAnims.put(bKey, ba);
                    drawToggle(ctx, px + 8, ry, 34, 12, ba, t, 255);
                    ctx.drawText(mc.textRenderer,
                                 s.getState() ? "§aВкл" : "§cВыкл",
                                 px + 46, ry + 2, COL_GRAY, false);
                    ry += 18;
                }
                case NUMBER -> {
                    int bw   = sw - 18;
                    float r  = (float)((s.getValue() - s.getMin()) / (s.getMax() - s.getMin()));
                    r = Math.max(0f, Math.min(1f, r));
                    int filled = (int)(bw * r);

                    // Трек
                    ctx.fill(px + 8, ry + 4, px + 8 + bw, ry + 10, 0xFF1A1A24);
                    // Заполнение — gradient accent→accent2
                    for (int px2 = 0; px2 < filled; px2++) {
                        float f  = bw > 0 ? (float) px2 / bw : 0f;
                        int  col = lerpColor(t.accent, t.accent2, f);
                        ctx.fill(px + 8 + px2, ry + 4, px + 8 + px2 + 1, ry + 10, 0xFF000000 | (col & 0xFFFFFF));
                    }
                    // Ручка
                    int hx = px + 8 + filled;
                    ctx.fill(hx - 4, ry, hx + 4, ry + 14, 0xFF252530);
                    ctx.fill(hx - 3, ry + 1, hx + 3, ry + 13, 0xFF000000 | (t.accent & 0xFFFFFF));

                    // Значение
                    String val = fmtVal(s.getValue());
                    ctx.drawText(mc.textRenderer, "§f" + val,
                                 px + sw - mc.textRenderer.getWidth(val) - 6, ry + 1, COL_WHITE, false);

                    // Запоминаем позицию для drag
                    if (draggingSlider == s) {
                        double ratio2 = Math.max(0, Math.min(1, (mx - sliderX0) / (double) sliderW0));
                        double newVal = s.getMin() + (s.getMax() - s.getMin()) * ratio2;
                        s.setValue(newVal);
                    }
                    ry += 24;
                }
                case ENUM -> {
                    int ex = px + 8;
                    for (String opt : s.getOptions()) {
                        boolean act = opt.equals(s.getCurrentOption());
                        int ow = mc.textRenderer.getWidth(opt) + 10;
                        if (ex + ow > px + sw - 6) { ex = px + 8; ry += 14; }
                        fill(ctx, ex, ry, ow, 13, act ? t.accentA(180) : 0xFF202028);
                        ctx.drawText(mc.textRenderer, opt, ex + 5, ry + 2,
                                     act ? COL_WHITE : COL_GRAY, false);
                        ex += ow + 3;
                    }
                    ry += 18;
                }
            }
            ry += 4;
        }
        ctx.fill(px, py + ph - 2, px + sw, py + ph, t.accent2);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ═══════════════════════════════════════════════════════════════════════

    private void drawToggle(DrawContext ctx, int x, int y, int w, int h, float anim, Theme t, int alpha) {
        int bg = applyAlpha(lerpColor(0xFF2A2A3A, t.accent, anim), alpha);
        fill(ctx, x, y, w, h, bg);
        int cx = x + 2 + (int)((w - h) * anim);
        fill(ctx, cx, y + 2, h - 4, h - 4, applyAlpha(COL_WHITE, alpha));
    }

    private void drawShadow(DrawContext ctx, int x, int y, int w, int h) {
        // Мягкая многослойная тень
        int[] alphas = {30, 22, 16, 10, 6, 4, 2};
        for (int i = 0; i < alphas.length; i++) {
            int d = i + 1;
            ctx.fill(x + d, y + d, x + w + d, y + h + d, (alphas[i] << 24));
        }
    }

    private void fill(DrawContext ctx, int x, int y, int w, int h, int color) {
        if (w > 0 && h > 0) ctx.fill(x, y, x + w, y + h, color);
    }

    private boolean inBox(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int applyAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private int lerpColor(int c1, int c2, float t) {
        int r = (int)(((c1>>16&0xFF)*(1-t)) + ((c2>>16&0xFF)*t));
        int g = (int)(((c1>> 8&0xFF)*(1-t)) + ((c2>> 8&0xFF)*t));
        int b = (int)(((c1    &0xFF)*(1-t)) + ((c2    &0xFF)*t));
        return 0xFF000000|(r<<16)|(g<<8)|b;
    }

    private List<Module> getVisible() {
        String q = searchQuery.toLowerCase();
        if (searchActive && searchAll && !q.isEmpty()) {
            // Поиск по ВСЕМ категориям
            return ModuleManager.getModules().stream()
                .filter(m -> m.getName().toLowerCase().contains(q))
                .toList();
        }
        return ModuleManager.getModules().stream()
            .filter(m -> m.getCategory() == CATS[activeCatIdx])
            .filter(m -> q.isEmpty() || m.getName().toLowerCase().contains(q))
            .toList();
    }

    private String fmtVal(double v) {
        return (v == (long) v) ? String.valueOf((long) v) : String.format("%.2f", v);
    }

    private String trunc(String s, int maxPx) {
        if (s == null) return "";
        if (mc.textRenderer.getWidth(s) <= maxPx) return s;
        while (s.length() > 1 && mc.textRenderer.getWidth(s + "…") > maxPx)
            s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    // ═══════════════════════════════════════════════════════════════════════
    // INPUT
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void mouseClicked(double mx, double my, int btn) {
        int imx = (int) mx, imy = (int) my;

        // Drag панели (header категорий)
        if (btn == 0 && inBox(imx, imy, panelX, panelY, CAT_W, HEADER_H)) {
            draggingPanel = true; dragOffX = imx - panelX; dragOffY = imy - panelY; return;
        }

        // Кнопка × закрыть settings
        int closeX = panelX + CAT_W + MOD_W - 14;
        if (btn == 0 && inBox(imx, imy, closeX, panelY + 10, 12, 12)) {
            settingsMod = null; return;
        }

        // Категории
        int cy = panelY + HEADER_H + 4;
        for (int i = 0; i < CATS.length; i++) {
            if (inBox(imx, imy, panelX + 4, cy, CAT_W - 8, CAT_ROW)) {
                if (activeCatIdx != i) {
                    activeCatIdx = i; settingsMod = null;
                    scrollTgt = 0; scrollMomentum = 0;
                    searchAll = false;
                }
                return;
            }
            cy += CAT_ROW;
        }

        // Search toggle
        int sy = panelY + PANEL_H - SEARCH_H - 4;
        if (inBox(imx, imy, panelX + 6, sy, CAT_W - 12, SEARCH_H)) {
            if (!searchActive) { searchActive = true; searchQuery = ""; }
            else               { searchActive = false; searchQuery = ""; searchAll = false; }
            return;
        }

        // Модули
        int modPX = panelX + CAT_W;
        List<Module> mods = getVisible();
        int y0 = panelY + HEADER_H + 2 - (int) scrollCur;

        for (int i = 0; i < mods.size(); i++) {
            Module mod = mods.get(i);
            int ry = y0 + i * MOD_ROW;
            if (!inBox(imx, imy, modPX + 2, ry, MOD_W - 4, MOD_ROW - 1)) continue;

            // Стрелка настроек
            if (!mod.getSettings().isEmpty() && inBox(imx, imy, modPX + MOD_W - 52, ry, 14, MOD_ROW)) {
                settingsMod = (settingsMod == mod) ? null : mod; return;
            }
            // Toggle модуля
            mod.toggle(); return;
        }

        // Settings panel: слайдеры
        if (settingsMod != null) {
            int sPX = panelX + CAT_W + MOD_W;
            int ry  = panelY + HEADER_H + 4 + 100 + 8; // eH=100
            if (!inBox(imx, imy, sPX, panelY, (int)(SET_W * settingsAnim), PANEL_H)) return;

            // Entity drag
            if (inBox(imx, imy, sPX + 4, panelY + HEADER_H + 4, (int)(SET_W * settingsAnim) - 8, 100)) {
                draggingEntity = true; return;
            }

            for (Setting s : settingsMod.getSettings()) {
                if (s.getType() == Setting.Type.NUMBER) {
                    int bw = (int)(SET_W * settingsAnim) - 18;
                    if (inBox(imx, imy, sPX + 8, ry + 4, bw, 14)) {
                        draggingSlider = s;
                        sliderX0 = sPX + 8;
                        sliderW0 = bw;
                        double r = Math.max(0, Math.min(1, (imx - sliderX0) / (double) sliderW0));
                        s.setValue(s.getMin() + (s.getMax() - s.getMin()) * r);
                        return;
                    }
                    ry += 24 + 4 + 12;
                } else if (s.getType() == Setting.Type.BOOLEAN) {
                    ry += 18 + 4 + 12;
                } else {
                    // ENUM
                    int ex = sPX + 8;
                    for (String opt : s.getOptions()) {
                        int ow = mc.textRenderer.getWidth(opt) + 10;
                        if (ex + ow > sPX + (int)(SET_W * settingsAnim) - 6) { ex = sPX + 8; ry += 14; }
                        if (inBox(imx, imy, ex, ry, ow, 13)) { s.setCurrentOption(opt); return; }
                        ex += ow + 3;
                    }
                    ry += 18 + 4 + 12;
                }
            }
        }
    }

    @Override
    public void mouseReleased(double mx, double my, int btn) {
        draggingPanel  = false;
        draggingSlider = null;
        draggingEntity = false;
    }

    @Override
    public void mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingPanel)  { panelX = (int)(mx - dragOffX); panelY = (int)(my - dragOffY); }
        if (draggingEntity) { entityYaw -= (float)dx * 0.8f; entityPitch -= (float)dy * 0.5f; }
        if (draggingSlider != null) {
            double r = Math.max(0, Math.min(1, (mx - sliderX0) / (double) sliderW0));
            draggingSlider.setValue(draggingSlider.getMin() + (draggingSlider.getMax() - draggingSlider.getMin()) * r);
        }
    }

    @Override
    public void mouseScrolled(double mx, double my, double sx, double sy) {
        if (inBox((int)mx, (int)my, panelX + CAT_W, panelY, MOD_W, PANEL_H)) {
            scrollMomentum -= (float)(sy * 18f);
        }
    }

    @Override
    public void keyPressed(int key, int scan, int mods) {
        if (key == 256) { // Escape
            if (settingsMod != null) { settingsMod = null; return; }
            if (searchActive)        { searchActive = false; searchQuery = ""; searchAll = false; return; }
            mc.setScreen(null);
        }
        // Backspace в поиске
        if (searchActive && key == 259 && !searchQuery.isEmpty())
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
        // Tab — переключить "поиск по всем категориям"
        if (searchActive && key == 258)
            searchAll = !searchAll;
    }

    @Override
    public void charTyped(char c, int mods) {
        if (searchActive && (Character.isLetterOrDigit(c) || c == ' '))
            searchQuery += c;
    }
}
