package net.enkuron.ui.theme;

/**
 * Theme — набор цветов для одной темы.
 * Все цвета в формате 0xAARRGGBB.
 */
public final class Theme {
    public final String name;
    public final int bg;       // фон панелей
    public final int accent;   // основной акцентный цвет
    public final int accent2;  // вторичный акцентный цвет
    public final int text;     // основной текст
    public final int textMuted;// приглушённый текст
    public final int positive; // зелёный (включён, ОК)
    public final int negative; // красный (выключен, ошибка)
    public final int panel;    // фон модальной панели

    public Theme(String name, int bg, int accent, int accent2,
                 int text, int textMuted, int positive, int negative, int panel) {
        this.name      = name;
        this.bg        = bg;
        this.accent    = accent;
        this.accent2   = accent2;
        this.text      = text;
        this.textMuted = textMuted;
        this.positive  = positive;
        this.negative  = negative;
        this.panel     = panel;
    }

    /** Акцент с заданным alpha (0..255) */
    public int accentA(int alpha) { return (alpha << 24) | (accent & 0x00FFFFFF); }
    public int bgA(int alpha)     { return (alpha << 24) | (bg     & 0x00FFFFFF); }
}
