package net.enkuron.ui.gui;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * GlassGUI v1 — Glassmorphism ClickGUI для Enkuron v15.
 *
 * Дизайн-концепция:
 *  - Полупрозрачные "стеклянные" панели (frosted glass effect)
 *  - Белые/светлые границы с низкой непрозрачностью
 *  - Мягкие тени вместо жёстких рамок
 *  - Категории — вертикальная sidebar с иконками
 *  - Модули — центральная карточка с hover-эффектом
 *  - Настройки — правая выдвижная панель
 *  - Анимация открытия: scale + fade
 *  - Backdrop blur имитируется слоями с alpha
 *
 * Особенности:
 *  - Поиск по всем категориям (Ctrl+F)
 *  - Toggle-пилюля (pill switch) с плавной анимацией
 *  - Keybind бейдж справа от имени модуля
 *  - Скролл с инерцией
 *  - Drag & Drop панели
 *  - Esc: закрыть настройки → закрыть поиск → закрыть GUI
 */
public class GlassGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── Размеры ──────────────────────────────────────────────────────────────
    private static final int SIDE_W   = 52;   // ширина sidebar с иконками
    private static final int MOD_W    = 180;  // ширина списка модулей
    private static final int SET_W    = 198;  // ширина панели настроек
    private static final int PANEL_H  = 360;  // высота всей панели
    private static final int HEADER_H = 40;   // высота заголовка
    private static final int CAT_ROW  = 42;   // высота строки категории
    private static final int MOD_ROW  = 28;   // высота строки модуля
    private static final int SEARCH_H = 26;   // высота строки поиска
    private static final int PILL_W   = 28;   // ширина toggle-пилюли
    private static final int PILL_H   = 14;   // высота toggle-пилюли
    private static final int CORNER   = 8;    // радиус "скругления" (рисуем вручную)

    // ── Стеклянные цвета (независимо от темы, опираемся на alpha) ────────────
    // Фон стекла: очень тёмный с высокой прозрачностью
    private static final int GLASS_BG      = 0xCC0D0D18;  // ~80% прозрачность
    private static final int GLASS_PANEL   = 0xBB12121E;  // чуть светлее
    private static final int GLASS_HOVER   = 0x33FFFFFF;  // белый hover
    private static final int GLASS_ACTIVE  = 0x22FFFFFF;  // белый active
    private static final int GLASS_BORDER  = 0x30FFFFFF;  // белая рамка (тонкая)
    private static final int GLASS_SHADOW  = 0x66000000;  // тень
    private static final int GLASS_SEARCH  = 0x44000000;  // строка поиска
    private static final int WHITE         = 0xFFFFFFFF;
    private static final int WHITE_DIM     = 0xAAFFFFFF;
    private static final int WHITE_MUTED   = 0x66FFFFFF;

    // ── Категории ────────────────────────────────────────────────────────────
    private static final Module.Category[] CATS = {
        Module.Category.COMBAT,   Module.Category.MOVEMENT, Module.Category.VISUAL,
        Module.Category.PLAYER,   Module.Category.HUD,      Module.Category.UTILITY,
        Module.Category.MISC
    };
    private static final String[] CAT_ICONS = { "⚔", "⚡", "✦", "♟", "◈", "⚙", "★" };
    private static final String[] CAT_NAMES = {
        "Combat", "Movement", "Visual", "Player", "HUD", "Utility", "Misc"
    };

    // ── Состояние ────────────────────────────────────────────────────────────
    private int     panelX = Integer.MIN_VALUE;
    private int     panelY = 0;
    private boolean centered = false;

    private int    activeCatIdx = 0;
    private Module settingsMod  = null;

    // Анимации
    private float openAnim     = 0f;  // 0→1 при открытии GUI
    private float settingsAnim = 0f;  // 0→1 при открытии настроек

    // Toggle-пилюли: uid → [0,1]
    private final Map<String, Float> toggleAnims  = new HashMap<>();
    // Fade модулей
    private final Map<String, Float> fadeAnims    = new HashMap<>();
    // Hover подсветка категорий
    private final Map<Integer, Float> catHovAnims = new HashMap<>();
    // Hover подсветка модулей
    private final Map<String, Float> modHovAnims  = new HashMap<>();

    // Drag
    private boolean draggingPanel = false;
    private int dragOffX, dragOffY;

    // Scroll
    private float scrollCur = 0f;
    private float scrollTgt = 0f;

    // Поиск
    private boolean searchActive = false;
    private String  searchQuery  = "";

    // Slider drag
    private Setting draggingSlider = null;
    private int sliderX0, sliderW0;

    // ── Кнопка закрыть ───────────────────────────────────────────────────────
    private boolean hoverClose = false;

    // ── Кэш ──────────────────────────────────────────────────────────────────
    private int lastCatIdx = -1;

    // ════════════════════════════════════════════════════════════════════════
    // RENDER
    // ════════════════════════════════════════════════════════════════════════

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Центровка при первом открытии
        if (!centered) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            panelX = (sw - SIDE_W - MOD_W) / 2;
            panelY = (sh - PANEL_H) / 2;
            centered = true;
        }

        // Сброс скролла при смене категории
        if (activeCatIdx != lastCatIdx) {
            scrollTgt = 0; scrollCur = 0;
            lastCatIdx = activeCatIdx;
        }

        // Инерционный скролл
        scrollCur = AnimationUtils.lerp(scrollCur, scrollTgt, 0.18f);

        // Анимация открытия
        openAnim = AnimationUtils.lerp(openAnim, 1f, 0.14f);
        float scaleY = openAnim;

        Theme t = ThemeManager.get();

        int totalW = SIDE_W + MOD_W + (settingsMod != null ? (int)(SET_W * settingsAnim) : 0);
        int pH = (int)(PANEL_H * scaleY);
        int px = panelX, py = panelY;

        // ── Backdrop (имитация blur) ─────────────────────────────────────────
        drawBackdrop(ctx, px, py, totalW, pH);

        // ── Sidebar ──────────────────────────────────────────────────────────
        drawSidebar(ctx, px, py, pH, t, mx, my);

        // ── Панель модулей ───────────────────────────────────────────────────
        drawModulePanel(ctx, px + SIDE_W, py, pH, t, mx, my);

        // ── Панель настроек ──────────────────────────────────────────────────
        if (settingsMod != null || settingsAnim > 0.01f) {
            settingsAnim = AnimationUtils.lerp(settingsAnim, settingsMod != null ? 1f : 0f, 0.15f);
            if (settingsAnim > 0.01f)
                drawSettingsPanel(ctx, px + SIDE_W + MOD_W, py, pH, t, mx, my);
        }
    }

    // ── Backdrop blur имитация ───────────────────────────────────────────────
    private void drawBackdrop(DrawContext ctx, int px, int py, int w, int h) {
        // Тень под панелью
        ctx.fill(px+6, py+8, px+w+6, py+h+8, 0x55000000);
        ctx.fill(px+3, py+4, px+w+3, py+h+4, 0x33000000);
        // Фон
        ctx.fill(px, py, px+w, py+h, GLASS_BG);
        // Верхняя и левая "бликовая" линия (имитация стекла)
        ctx.fill(px, py, px+w, py+1, GLASS_BORDER);
        ctx.fill(px, py, px+1, py+h, GLASS_BORDER);
        // Правая и нижняя более тёмная
        ctx.fill(px+w-1, py, px+w, py+h, 0x18FFFFFF);
        ctx.fill(px, py+h-1, px+w, py+h, 0x18FFFFFF);
    }

    // ── Sidebar с иконками категорий ─────────────────────────────────────────
    private void drawSidebar(DrawContext ctx, int px, int py, int ph, Theme t, int mx, int my) {
        // Фон sidebar — чуть темнее
        ctx.fill(px, py, px+SIDE_W, py+ph, 0x28000000);
        ctx.fill(px+SIDE_W-1, py, px+SIDE_W, py+ph, GLASS_BORDER);

        // Логотип / заголовок
        ctx.fill(px, py, px+SIDE_W, py+HEADER_H, 0x22FFFFFF);
        ctx.fill(px, py+HEADER_H-1, px+SIDE_W, py+HEADER_H, t.accentA(120));
        // "E" в центре заголовка
        ctx.drawText(mc.textRenderer, "§lE",
                     px + SIDE_W/2 - 3, py + HEADER_H/2 - 4,
                     t.accent, false);

        int searchYOffset = searchActive ? SEARCH_H : 0;

        // Поисковая строка
        if (searchActive) {
            int sy = py + HEADER_H;
            ctx.fill(px, sy, px+SIDE_W, sy+SEARCH_H, GLASS_SEARCH);
            ctx.fill(px, sy+SEARCH_H-1, px+SIDE_W, sy+SEARCH_H, t.accentA(80));
            // Иконка поиска по центру
            ctx.drawText(mc.textRenderer, "§7🔍",
                         px + SIDE_W/2 - 4, sy + SEARCH_H/2 - 4, WHITE_DIM, false);
        }

        // Категории
        for (int i = 0; i < CATS.length; i++) {
            int ry = py + HEADER_H + searchYOffset + i * CAT_ROW;
            if (ry + CAT_ROW > py + ph) break;

            boolean active = activeCatIdx == i;
            boolean hover  = !searchActive && mx >= px && mx < px+SIDE_W
                             && my >= ry && my < ry+CAT_ROW;

            // Hover анимация
            float hov = catHovAnims.getOrDefault(i, 0f);
            hov = AnimationUtils.lerp(hov, hover ? 1f : 0f, 0.2f);
            catHovAnims.put(i, hov);

            if (active) {
                // Левая цветная полоска для активной категории
                ctx.fill(px, ry, px+3, ry+CAT_ROW, t.accent);
                // Мягкий фон
                ctx.fill(px+3, ry, px+SIDE_W, ry+CAT_ROW, t.accentA(30));
            } else if (hov > 0.01f) {
                int hovAlpha = (int)(hov * 25);
                ctx.fill(px+3, ry, px+SIDE_W, ry+CAT_ROW, (hovAlpha << 24) | 0xFFFFFF);
            }

            // Иконка
            int iconColor = active ? t.accent : (hover ? WHITE_DIM : WHITE_MUTED);
            ctx.drawText(mc.textRenderer, CAT_ICONS[i],
                         px + SIDE_W/2 - 4, ry + CAT_ROW/2 - 4, iconColor, false);

            // Разделитель
            if (i < CATS.length - 1) {
                ctx.fill(px+8, ry+CAT_ROW-1, px+SIDE_W-8, ry+CAT_ROW, 0x15FFFFFF);
            }
        }

        // Нижняя кнопка закрыть (×)
        int closeY = py + ph - 22;
        hoverClose = mx >= px+4 && mx < px+SIDE_W-4 && my >= closeY && my < closeY+18;
        ctx.fill(px, closeY-2, px+SIDE_W, closeY+18, hoverClose ? 0x33FF4444 : 0x00000000);
        ctx.drawText(mc.textRenderer, hoverClose ? "§c×" : "§8×",
                     px+SIDE_W/2-3, closeY+4, WHITE, false);
    }

    // ── Панель модулей ───────────────────────────────────────────────────────
    private void drawModulePanel(DrawContext ctx, int px, int py, int ph, Theme t, int mx, int my) {
        // Заголовок
        ctx.fill(px, py, px+MOD_W, py+HEADER_H, 0x18FFFFFF);
        ctx.fill(px, py+HEADER_H-1, px+MOD_W, py+HEADER_H, t.accentA(60));

        // Название категории
        String catLabel = searchActive
            ? ("§7🔍 §f" + (searchQuery.isEmpty() ? "Поиск..." : searchQuery))
            : ("§7" + CAT_ICONS[activeCatIdx] + " §f" + CAT_NAMES[activeCatIdx]);

        ctx.drawText(mc.textRenderer, catLabel, px+10, py+14, WHITE, false);

        // Кол-во активных
        long activeCount = ModuleManager.getModules().stream().filter(Module::isEnabled).count();
        String badge = "§7[§f" + activeCount + "§7]";
        int bw = mc.textRenderer.getWidth(badge);
        ctx.drawText(mc.textRenderer, badge, px + MOD_W - bw - 8, py+14, WHITE_DIM, false);

        // Поиск строка в заголовке
        if (searchActive) {
            int sy = py + HEADER_H;
            ctx.fill(px, sy, px+MOD_W, sy+SEARCH_H, GLASS_SEARCH);
            ctx.fill(px, sy+SEARCH_H-1, px+MOD_W, sy+SEARCH_H, t.accentA(60));
            String qDisp = "§7🔍 §f" + (searchQuery.isEmpty() ? "§8Поиск модулей..." : searchQuery + "§7|");
            ctx.drawText(mc.textRenderer, qDisp, px+8, sy+7, WHITE, false);
        }

        int searchYOffset = searchActive ? SEARCH_H : 0;
        int listY  = py + HEADER_H + searchYOffset;
        int listH  = ph - HEADER_H - searchYOffset;

        // Список модулей (с clip по высоте)
        List<Module> mods = getFilteredModules();
        int scrollMax = Math.max(0, mods.size() * MOD_ROW - listH + 4);
        scrollTgt = AnimationUtils.clamp(scrollTgt, 0, scrollMax);

        int rowY = listY - (int) scrollCur;

        for (Module mod : mods) {
            if (rowY + MOD_ROW < listY) { rowY += MOD_ROW; continue; }
            if (rowY >= listY + listH)  break;

            String uid = mod.getName();
            boolean enabled = mod.isEnabled();
            boolean hover = mx >= px && mx < px+MOD_W && my >= rowY && my < rowY+MOD_ROW
                            && rowY >= listY && rowY+MOD_ROW <= listY+listH+2;

            // Hover fade
            float hov = modHovAnims.getOrDefault(uid, 0f);
            hov = AnimationUtils.lerp(hov, hover ? 1f : 0f, 0.22f);
            modHovAnims.put(uid, hov);

            // Toggle анимация
            float tog = toggleAnims.getOrDefault(uid, enabled ? 1f : 0f);
            tog = AnimationUtils.lerp(tog, enabled ? 1f : 0f, 0.18f);
            toggleAnims.put(uid, tog);

            // Fade-in строки
            float fade = fadeAnims.getOrDefault(uid, 0f);
            fade = AnimationUtils.lerp(fade, 1f, 0.15f);
            fadeAnims.put(uid, fade);

            // Hover фон
            if (hov > 0.01f) {
                int hovAlpha = (int)(hov * 30);
                ctx.fill(px, rowY, px+MOD_W, rowY+MOD_ROW, (hovAlpha << 24) | 0xFFFFFF);
            }

            // Левая цветная полоска у включённых
            if (tog > 0.01f) {
                int barAlpha = (int)(tog * 255);
                ctx.fill(px, rowY, px+2, rowY+MOD_ROW, (barAlpha << 24) | (t.accent & 0x00FFFFFF));
            }

            // Имя модуля
            int nameColor = enabled ? WHITE : WHITE_MUTED;
            int nameAlpha = (int)(fade * 255);
            // Применяем fade к alpha цвета
            int fadedColor = (nameAlpha << 24) | (nameColor & 0x00FFFFFF);
            ctx.drawText(mc.textRenderer, mod.getName(), px+10, rowY+MOD_ROW/2-4, fadedColor, false);

            // Toggle-пилюля (pill switch)
            drawPill(ctx, px+MOD_W-PILL_W-8, rowY+MOD_ROW/2-PILL_H/2, tog, t);

            // Разделитель
            ctx.fill(px+4, rowY+MOD_ROW-1, px+MOD_W-4, rowY+MOD_ROW, 0x12FFFFFF);

            rowY += MOD_ROW;
        }

        // Полоса прокрутки
        if (scrollMax > 0) {
            int scrollBarH = Math.max(20, (int)((float)listH / (mods.size() * MOD_ROW) * listH));
            int scrollBarY = listY + (int)((float)scrollCur / scrollMax * (listH - scrollBarH));
            ctx.fill(px+MOD_W-3, listY, px+MOD_W-1, listY+listH, 0x20FFFFFF);
            ctx.fill(px+MOD_W-3, scrollBarY, px+MOD_W-1, scrollBarY+scrollBarH, t.accentA(160));
        }
    }

    // ── Toggle-пилюля ────────────────────────────────────────────────────────
    private void drawPill(DrawContext ctx, int px, int py, float tog, Theme t) {
        // Фон пилюли
        int bgCol = tog > 0.5f ? t.accentA(180) : 0x55FFFFFF;
        ctx.fill(px, py, px+PILL_W, py+PILL_H, bgCol);
        // Круглые края (имитация скруглений 2px сверху/снизу)
        ctx.fill(px, py, px+1, py+1, 0x00000000);
        ctx.fill(px, py+PILL_H-1, px+1, py+PILL_H, 0x00000000);
        ctx.fill(px+PILL_W-1, py, px+PILL_W, py+1, 0x00000000);
        ctx.fill(px+PILL_W-1, py+PILL_H-1, px+PILL_W, py+PILL_H, 0x00000000);

        // Ручка (circle thumb)
        int thumbX = px + 2 + (int)(tog * (PILL_W - PILL_H));
        int thumbColor = tog > 0.5f ? WHITE : WHITE_DIM;
        ctx.fill(thumbX, py+2, thumbX+PILL_H-4, py+PILL_H-2, thumbColor);
    }

    // ── Панель настроек ──────────────────────────────────────────────────────
    private void drawSettingsPanel(DrawContext ctx, int px, int py, int ph, Theme t, int mx, int my) {
        int w = (int)(SET_W * settingsAnim);
        if (w < 10 || settingsMod == null) return;

        // Стеклянный фон
        ctx.fill(px, py, px+w, py+ph, GLASS_PANEL);
        ctx.fill(px, py, px+1, py+ph, GLASS_BORDER);
        ctx.fill(px, py, px+w, py+1, GLASS_BORDER);

        // Заголовок настроек
        ctx.fill(px, py, px+w, py+HEADER_H, 0x22FFFFFF);
        ctx.fill(px, py+HEADER_H-1, px+w, py+HEADER_H, t.accentA(60));
        ctx.drawText(mc.textRenderer, "§f⚙ §7" + settingsMod.getName(),
                     px+8, py+14, WHITE, false);

        // Кнопка закрыть настройки
        ctx.drawText(mc.textRenderer, "§8←", px+w-14, py+14, WHITE_MUTED, false);

        // Настройки
        List<Setting> settings = settingsMod.getSettings();
        int sy = py + HEADER_H + 6;

        for (Setting s : settings) {
            if (sy + 24 > py + ph - 4) break;

            ctx.drawText(mc.textRenderer, "§7" + s.getName(),
                         px+10, sy, WHITE_MUTED, false);

            if (s.getType() == Setting.Type.BOOLEAN) {
                // Toggle пилюля настройки
                boolean val = s.getBoolValue();
                float tog = val ? 1f : 0f;
                drawPill(ctx, px+w-PILL_W-8, sy-2, tog, t);
                sy += 18;

            } else if (s.getType() == Setting.Type.DOUBLE) {
                sy += 10;
                // Слайдер
                double min = s.getMinValue(), max = s.getMaxValue(), cur = s.getDoubleValue();
                float pct = (float)((cur - min) / (max - min));
                int barX = px+10, barW = w-20;
                // Фон слайдера
                ctx.fill(barX, sy, barX+barW, sy+6, 0x33FFFFFF);
                // Заполнение
                ctx.fill(barX, sy, barX+(int)(pct*barW), sy+6, t.accentA(200));
                // Ручка
                int hx = barX + (int)(pct*barW) - 3;
                ctx.fill(hx, sy-2, hx+6, sy+8, WHITE);
                // Значение
                String valStr = String.format("%.1f", cur);
                ctx.drawText(mc.textRenderer, "§8" + valStr, px+w-30, sy-10, WHITE_MUTED, false);
                sy += 18;

            } else if (s.getType() == Setting.Type.STRING_ARRAY) {
                sy += 10;
                // Dropdown button
                String cur = s.getStringValue();
                int bX = px+10, bW = w-20, bH = 16;
                boolean hovBtn = mx>=bX && mx<bX+bW && my>=sy && my<sy+bH;
                ctx.fill(bX, sy, bX+bW, sy+bH, hovBtn ? 0x44FFFFFF : 0x22FFFFFF);
                ctx.fill(bX, sy, bX+bW, sy+1, t.accentA(80));
                ctx.drawText(mc.textRenderer, "§f" + cur + " §7▾",
                             bX+6, sy+4, WHITE, false);
                sy += 22;
            }

            sy += 4;
        }
    }

    // ── Вспомогательные ─────────────────────────────────────────────────────
    private List<Module> getFilteredModules() {
        if (searchActive && !searchQuery.isEmpty()) {
            String q = searchQuery.toLowerCase();
            return ModuleManager.getModules().stream()
                .filter(m -> m.getName().toLowerCase().contains(q)
                          || m.getDescription().toLowerCase().contains(q))
                .sorted(Comparator.comparing(Module::getName))
                .toList();
        }
        return ModuleManager.getModulesByCategory(CATS[activeCatIdx]);
    }

    // ════════════════════════════════════════════════════════════════════════
    // INPUT HANDLERS
    // ════════════════════════════════════════════════════════════════════════

    @Override
    public void mouseClicked(double mx, double my, int btn) {
        int imx = (int) mx, imy = (int) my;
        int searchYOffset = searchActive ? SEARCH_H : 0;

        // Drag панели
        if (btn == 0) {
            int totalW = SIDE_W + MOD_W + (settingsMod != null ? SET_W : 0);
            if (imx >= panelX && imx < panelX+totalW
             && imy >= panelY && imy < panelY+HEADER_H) {
                draggingPanel = true;
                dragOffX = imx - panelX;
                dragOffY = imy - panelY;
                return;
            }
        }

        // Кнопка закрыть
        if (hoverClose && btn == 0) {
            mc.setScreen(null);
            return;
        }

        // Sidebar: выбор категории
        if (imx >= panelX && imx < panelX+SIDE_W) {
            int catAreaY = panelY + HEADER_H + searchYOffset;
            int relY = imy - catAreaY;
            if (relY >= 0 && relY < CATS.length * CAT_ROW) {
                int idx = relY / CAT_ROW;
                if (idx < CATS.length) {
                    activeCatIdx = idx;
                    settingsMod = null;
                }
            }
            return;
        }

        // Иконка поиска в заголовке (правый угол)
        int headerSearchX = panelX + SIDE_W + MOD_W - 18;
        if (imx >= headerSearchX && imx < headerSearchX+14
         && imy >= panelY && imy < panelY+HEADER_H && btn == 0) {
            searchActive = !searchActive;
            searchQuery  = "";
            return;
        }

        // Панель модулей: клик по модулю
        if (imx >= panelX+SIDE_W && imx < panelX+SIDE_W+MOD_W) {
            int listY = panelY + HEADER_H + searchYOffset;
            int rowY  = listY - (int) scrollCur;
            for (Module mod : getFilteredModules()) {
                if (rowY + MOD_ROW < listY) { rowY += MOD_ROW; continue; }
                if (rowY > panelY + PANEL_H) break;
                if (imy >= rowY && imy < rowY+MOD_ROW) {
                    if (btn == 0) {
                        mod.toggle();
                    } else if (btn == 1) {
                        settingsMod = (settingsMod == mod) ? null : mod;
                    }
                    return;
                }
                rowY += MOD_ROW;
            }
        }

        // Панель настроек: клик по настройкам
        if (settingsMod != null) {
            int spx = panelX + SIDE_W + MOD_W;
            int sw  = SET_W;
            // Закрыть кнопка
            if (imx >= spx+sw-20 && imx < spx+sw-4
             && imy >= panelY+8 && imy < panelY+HEADER_H-8 && btn == 0) {
                settingsMod = null;
                return;
            }
            // Клики по настройкам
            if (imx >= spx && imx < spx+sw) {
                int sy = panelY + HEADER_H + 6;
                for (Setting s : settingsMod.getSettings()) {
                    if (s.getType() == Setting.Type.BOOLEAN) {
                        int pillX = spx+sw-PILL_W-8;
                        if (imx>=pillX && imx<pillX+PILL_W && imy>=sy-2 && imy<sy+PILL_H) {
                            s.setBoolValue(!s.getBoolValue());
                        }
                        sy += 22;
                    } else if (s.getType() == Setting.Type.DOUBLE) {
                        sy += 10;
                        int barX = spx+10, barW = sw-20;
                        if (imy>=sy-2 && imy<sy+10 && imx>=barX && imx<barX+barW) {
                            draggingSlider = s;
                            sliderX0 = barX; sliderW0 = barW;
                        }
                        sy += 22;
                    } else if (s.getType() == Setting.Type.STRING_ARRAY) {
                        sy += 10;
                        int bX = spx+10, bW = sw-20;
                        if (imy>=sy && imy<sy+16 && imx>=bX && imx<bX+bW) {
                            s.nextValue();
                        }
                        sy += 26;
                    }
                    sy += 4;
                }
            }
        }
    }

    @Override
    public void mouseReleased(double mx, double my, int btn) {
        draggingPanel  = false;
        draggingSlider = null;
    }

    @Override
    public void mouseDragged(double mx, double my, int btn, double dx, double dy) {
        int imx = (int) mx, imy = (int) my;
        if (draggingPanel) {
            panelX = imx - dragOffX;
            panelY = imy - dragOffY;
            return;
        }
        if (draggingSlider != null) {
            float pct = AnimationUtils.clamp((float)(imx - sliderX0) / sliderW0, 0f, 1f);
            double newVal = draggingSlider.getMinValue()
                          + pct * (draggingSlider.getMaxValue() - draggingSlider.getMinValue());
            draggingSlider.setDoubleValue(newVal);
        }
    }

    @Override
    public void mouseScrolled(double mx, double my, double sx, double sy) {
        scrollTgt -= (float) sy * 16f;
    }

    @Override
    public void keyPressed(int key, int scan, int mods) {
        // Ctrl+F — поиск
        if (key == 70 && (mods & 2) != 0) {
            searchActive = !searchActive;
            searchQuery  = "";
            return;
        }
        // Esc
        if (key == 256) {
            if (settingsMod != null)  { settingsMod = null; return; }
            if (searchActive)          { searchActive = false; searchQuery = ""; return; }
            mc.setScreen(null);
            return;
        }
        // Backspace в поиске
        if (searchActive && key == 259 && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length()-1);
        }
    }

    @Override
    public void charTyped(char c, int mods) {
        if (searchActive && c >= 32 && searchQuery.length() < 24) {
            searchQuery += c;
        }
    }
}
