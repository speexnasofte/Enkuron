package net.enkuron.ui.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * GUIManager v4 — менеджер GUI стилей.
 *
 * Стили:
 *   AURORA  — северное сияние GUI v1 [НОВОЕ — самый красивый]
 *   MODERN  — трёхпанельный GUI v3
 *   NEON    — неоновый GUI v2
 *   GLASS   — glassmorphism GUI v1
 *   MINIMAL — минималистичный
 *   CLASSIC — классический список
 *
 * Переключение: клавиша G в меню, или GUIManager.setStyle(...)
 */
public class GUIManager {

    public enum GUIStyle { AURORA, MODERN, NEON, GLASS, MINIMAL, CLASSIC }

    private static GUIStyle currentStyle = GUIStyle.AURORA; // Aurora — по умолчанию
    private static ClickGUI auroraGUI;
    private static ClickGUI modernGUI;
    private static ClickGUI neonGUI;
    private static ClickGUI glassGUI;
    private static ClickGUI minimalGUI;
    private static ClickGUI classicGUI;

    public static void init() {
        auroraGUI  = new AuroraGUI();
        modernGUI  = new ModernGUI();
        neonGUI    = new NeonGUI();
        glassGUI   = new GlassGUI();
        minimalGUI = new MinimalGUI();
        classicGUI = new ClassicGUI();
    }

    public static ClickGUI getCurrent() {
        return switch (currentStyle) {
            case AURORA  -> auroraGUI;
            case NEON    -> neonGUI;
            case GLASS   -> glassGUI;
            case MINIMAL -> minimalGUI;
            case CLASSIC -> classicGUI;
            default      -> modernGUI;
        };
    }

    public static GUIStyle getStyle()           { return currentStyle; }
    public static void     setStyle(GUIStyle s) {
        currentStyle = s;
        switch (s) {
            case AURORA  -> auroraGUI  = new AuroraGUI();
            case MODERN  -> modernGUI  = new ModernGUI();
            case NEON    -> neonGUI    = new NeonGUI();
            case GLASS   -> glassGUI   = new GlassGUI();
            case MINIMAL -> minimalGUI = new MinimalGUI();
            case CLASSIC -> classicGUI = new ClassicGUI();
        }
    }

    public static void nextStyle() {
        GUIStyle[] vals = GUIStyle.values();
        setStyle(vals[(currentStyle.ordinal() + 1) % vals.length]);
    }

    public static String getStyleName() {
        return switch (currentStyle) {
            case AURORA  -> "✦ Aurora";
            case MODERN  -> "Modern";
            case NEON    -> "Neon";
            case GLASS   -> "Glass";
            case MINIMAL -> "Minimal";
            case CLASSIC -> "Classic";
        };
    }

    public static void render(DrawContext ctx, int mx, int my, float delta)               { getCurrent().render(ctx, mx, my, delta); }
    public static void mouseClicked(double mx, double my, int btn)                        { getCurrent().mouseClicked(mx, my, btn); }
    public static void mouseReleased(double mx, double my, int btn)                       { getCurrent().mouseReleased(mx, my, btn); }
    public static void mouseDragged(double mx, double my, int btn, double dx, double dy)  { getCurrent().mouseDragged(mx, my, btn, dx, dy); }
    public static void mouseScrolled(double mx, double my, double sx, double sy)          { getCurrent().mouseScrolled(mx, my, sx, sy); }
    public static void keyPressed(int key, int scan, int mods)                            { getCurrent().keyPressed(key, scan, mods); }
    public static void charTyped(char c, int mods) {
    getCurrent().charTyped(c, mods);
}

} // ← ВОТ ЭТА СКОБКА ОБЯЗАТЕЛЬНО ДОЛЖНА БЫТЬ