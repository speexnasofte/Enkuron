package net.enkuron.ui.gui;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * ClassicGUI — классический стиль, как у старых клиентов (Nodus, Wurst).
 * Каждая категория — отдельная колонка. Простые прямоугольники, без blur.
 *
 * FIX: settingsScrollOffset — скролл списка настроек развёрнутого модуля,
 *      чтобы слайдеры не уходили за нижний край экрана при большом числе настроек.
 */
public class ClassicGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final int COL_W  = 100;
    private static final int ROW_H  = 16;
    private static final int HEAD_H = 14;
    private static final int GAP    = 4;
    private static final int START_X = 4;
    private static final int START_Y = 4;
    private static final int SETTING_H = 20;

    private Module expandedModule = null;
    private Setting draggingSetting = null;
    private int sliderBx, sliderBw;

    /** Смещение скролла панели настроек развёрнутого модуля (в px, >= 0). */
    private float settingsScrollOffset = 0f;

    private static final Module.Category[] CATS = {
        Module.Category.COMBAT,   Module.Category.MOVEMENT,
        Module.Category.VISUAL,   Module.Category.PLAYER,
        Module.Category.HUD,      Module.Category.UTILITY,
        Module.Category.MISC
    };
    private static final String[] CAT_NAMES = {
        "Combat", "Movement", "Visual", "Player", "HUD", "Utility", "Misc"
    };

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        Theme t = ThemeManager.get();
        int screenH = mc.getWindow().getScaledHeight();
        int x = START_X;

        for (int ci = 0; ci < CATS.length; ci++) {
            Module.Category cat = CATS[ci];
            List<Module> mods = ModuleManager.getModules().stream()
                .filter(m -> m.getCategory() == cat).toList();

            boolean hasExpanded = expandedModule != null && expandedModule.getCategory() == cat;
            int settingsCount = hasExpanded ? expandedModule.getSettings().size() : 0;

            // Высота колонки без скролла (для фона): только сколько войдёт
            int maxSettingsVisible = settingsCount; // рендерим все, но со скроллом
            int colH = HEAD_H + mods.size() * ROW_H + maxSettingsVisible * SETTING_H;

            // Фон колонки
            ctx.fill(x, START_Y, x+COL_W, START_Y+colH, 0xCC1A1A1A);
            // Заголовок
            ctx.fill(x, START_Y, x+COL_W, START_Y+HEAD_H, 0xFF333333);
            ctx.fill(x, START_Y, x+COL_W, START_Y+1, t.accent);
            ctx.drawText(mc.textRenderer, CAT_NAMES[ci], x+4, START_Y+3, t.accent, false);

            int y = START_Y + HEAD_H;
            for (Module mod : mods) {
                boolean on    = mod.isEnabled();
                boolean hover = mx >= x && mx < x+COL_W && my >= y && my < y+ROW_H;
                int bgColor   = hover ? 0xFF2A2A2A : 0xFF222222;
                ctx.fill(x, y, x+COL_W, y+ROW_H, bgColor);
                ctx.fill(x, y+ROW_H-1, x+COL_W, y+ROW_H, 0xFF111111);
                ctx.drawText(mc.textRenderer, mod.getName(), x+4, y+4,
                             on ? t.accent : 0xFF888888, false);
                y += ROW_H;

                // Настройки развёрнутого модуля — со скроллом
                if (expandedModule == mod) {
                    int scroll = (int) settingsScrollOffset;
                    int settingY = y - scroll;
                    for (Setting s : mod.getSettings()) {
                        // Не рисуем то что выше заголовка или ниже экрана
                        if (settingY + SETTING_H > START_Y + HEAD_H && settingY < screenH) {
                            ctx.fill(x, settingY, x+COL_W, settingY+SETTING_H, 0xFF1C1C1C);
                            ctx.drawText(mc.textRenderer, "§8" + s.getName(),
                                         x+4, settingY+2, 0xFF999999, false);
                            switch (s.getType()) {
                                case BOOLEAN -> {
                                    ctx.fill(x+COL_W-20, settingY+4, x+COL_W-4, settingY+14,
                                             s.getState() ? t.accent : 0xFF444444);
                                    ctx.drawText(mc.textRenderer, s.getState() ? "ON" : "OFF",
                                                 x+COL_W-17, settingY+6, 0xFFFFFFFF, false);
                                }
                                case NUMBER -> {
                                    int bw = COL_W - 8;
                                    float ratio = (float)((s.getValue()-s.getMin())
                                                          /(s.getMax()-s.getMin()));
                                    ctx.fill(x+4, settingY+11, x+4+bw, settingY+15, 0xFF333333);
                                    ctx.fill(x+4, settingY+11, x+4+(int)(bw*ratio),
                                             settingY+15, t.accent);
                                }
                                case ENUM -> {
                                    ctx.drawText(mc.textRenderer,
                                                 "< " + s.getCurrentOption() + " >",
                                                 x+4, settingY+11, t.text, false);
                                }
                            }
                        }
                        settingY += SETTING_H;
                    }
                    // Двигаем y вперёд на полную высоту панели (без скролла) для mouseClicked
                    y += settingsCount * SETTING_H;
                }
            }
            x += COL_W + GAP;
        }
    }

    @Override
    public void mouseClicked(double mx, double my, int btn) {
        int x = START_X;
        for (int ci = 0; ci < CATS.length; ci++) {
            Module.Category cat = CATS[ci];
            List<Module> mods = ModuleManager.getModules().stream()
                .filter(m -> m.getCategory() == cat).toList();
            int y = START_Y + HEAD_H;
            for (Module mod : mods) {
                if (mx >= x && mx < x+COL_W && my >= y && my < y+ROW_H) {
                    if (btn == 0) mod.toggle();
                    else if (btn == 1) {
                        expandedModule = expandedModule == mod ? null : mod;
                        settingsScrollOffset = 0f; // сбросить скролл при смене
                    }
                    return;
                }
                y += ROW_H;
                if (expandedModule == mod) {
                    int scroll = (int) settingsScrollOffset;
                    int settingY = y - scroll;
                    for (Setting s : mod.getSettings()) {
                        if (mx >= x && mx < x+COL_W
                                && my >= settingY && my < settingY+SETTING_H) {
                            switch (s.getType()) {
                                case BOOLEAN -> s.toggleState();
                                case ENUM    -> s.cycleOption();
                                case NUMBER  -> {
                                    int bw = COL_W - 8;
                                    double r = Math.max(0, Math.min(1, (mx-x-4)/bw));
                                    s.setValue(s.getMin() + r*(s.getMax()-s.getMin()));
                                    draggingSetting = s;
                                    sliderBx = x+4;
                                    sliderBw = bw;
                                }
                            }
                            return;
                        }
                        settingY += SETTING_H;
                    }
                    y += mod.getSettings().size() * SETTING_H;
                }
            }
            x += COL_W + GAP;
        }
    }

    @Override public void mouseReleased(double mx, double my, int btn) { draggingSetting = null; }

    @Override public void mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingSetting != null) {
            double r = Math.max(0, Math.min(1, (mx-sliderBx)/(double)sliderBw));
            draggingSetting.setValue(
                draggingSetting.getMin() + r*(draggingSetting.getMax()-draggingSetting.getMin()));
        }
    }

    /**
     * Скролл работает только тогда, когда развёрнут модуль с настройками.
     * Ограничиваем снизу (0) и сверху (общая высота настроек минус видимая зона).
     */
    @Override
    public void mouseScrolled(double mx, double my, double sx, double sy) {
        if (expandedModule == null) return;
        int settingsCount = expandedModule.getSettings().size();
        if (settingsCount == 0) return;

        int screenH = mc.getWindow().getScaledHeight();
        // Точка, с которой начинается панель настроек для expandedModule
        // (грубо: весь контент до неё — START_Y + HEAD_H + индекс модуля * ROW_H)
        List<Module> catMods = ModuleManager.getModules().stream()
            .filter(m -> m.getCategory() == expandedModule.getCategory()).toList();
        int modIndex = catMods.indexOf(expandedModule);
        int panelStartY = START_Y + HEAD_H + (modIndex + 1) * ROW_H;

        int visibleH = Math.max(0, screenH - panelStartY);
        int totalH   = settingsCount * SETTING_H;
        float maxScroll = Math.max(0, totalH - visibleH);

        settingsScrollOffset = Math.max(0, Math.min(maxScroll,
            settingsScrollOffset - (float)(sy * 12)));
    }

    @Override public void keyPressed(int key, int scan, int mods) {}
    @Override public void charTyped(char c, int mods) {}
}
