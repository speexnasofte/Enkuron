package net.enkuron.ui.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * ClickGUI — интерфейс для всех реализаций GUI клиента.
 * Каждый GUI должен реализовать три метода:
 *   render       — отрисовка каждый кадр
 *   mouseClicked — обработка кликов мышью
 *   keyPressed   — обработка клавиш
 */
public interface ClickGUI {
    void render(DrawContext context, int mouseX, int mouseY, float delta);
    void mouseClicked(double mouseX, double mouseY, int button);
    void mouseReleased(double mouseX, double mouseY, int button);
    void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY);
    void mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY);
    void keyPressed(int keyCode, int scanCode, int modifiers);
    void charTyped(char chr, int modifiers);
}
