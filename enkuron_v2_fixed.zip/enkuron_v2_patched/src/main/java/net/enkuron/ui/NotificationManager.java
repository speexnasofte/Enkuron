package net.enkuron.ui;

import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * NotificationManager v2 — улучшенные тост-уведомления.
 *
 * Новшества v2:
 *  - Стеклянный дизайн (glassmorphism) в тон теме
 *  - Иконка типа: ✔ (INFO), ✦ (SUCCESS), ✗ (WARNING), ⚡ (TOGGLE)
 *  - Slide-in анимация справа + fade-out
 *  - Цветная полоска слева (цвет акцента темы)
 *  - Progress bar снизу (таймер жизни)
 *  - Стакинг: несколько уведомлений друг под другом с offset
 *  - Максимум 5 уведомлений одновременно
 */
public class NotificationManager {

    // Типы уведомлений
    public enum Type {
        INFO,    // ◈ серый
        SUCCESS, // ✔ зелёный
        WARNING, // ✗ красный
        TOGGLE   // ⚡ акцентный (вкл/выкл модуля)
    }

    // ── Константы ────────────────────────────────────────────────────────────
    private static final int WIDTH     = 200;
    private static final int HEIGHT    = 42;
    private static final int MARGIN    = 8;    // отступ от края экрана
    private static final int GAP       = 4;    // зазор между уведомлениями
    private static final int MAX_NOTIF = 5;

    private static final int BG_COLOR     = 0xCC0D0D18;
    private static final int BORDER_COLOR = 0x30FFFFFF;
    private static final int WHITE        = 0xFFFFFFFF;
    private static final int WHITE_DIM    = 0xAAFFFFFF;
    private static final int WHITE_MUTED  = 0x66FFFFFF;

    // ── Уведомления ──────────────────────────────────────────────────────────
    private static final List<Notification> notifications = new ArrayList<>();

    /**
     * Добавить уведомление с типом
     */
    public static void push(String title, String message, Type type, long durationMs) {
        if (notifications.size() >= MAX_NOTIF) {
            notifications.remove(0);
        }
        notifications.add(new Notification(title, message, type, durationMs));
    }

    /** Быстрое уведомление INFO на 2.5с */
    public static void push(String title, String message) {
        push(title, message, Type.INFO, 2500);
    }

    /** Уведомление о переключении модуля */
    public static void pushToggle(String moduleName, boolean enabled) {
        push(moduleName, enabled ? "Включён" : "Выключен", Type.TOGGLE, 1800);
    }

    /** Успех */
    public static void pushSuccess(String title, String message) {
        push(title, message, Type.SUCCESS, 2500);
    }

    /** Предупреждение */
    public static void pushWarning(String title, String message) {
        push(title, message, Type.WARNING, 3000);
    }

    /**
     * Отрисовка всех уведомлений
     */
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        Theme t = ThemeManager.get();

        Iterator<Notification> it = notifications.iterator();
        int stackIdx = 0;

        while (it.hasNext()) {
            Notification n = it.next();
            if (n.isExpired()) { it.remove(); continue; }

            float alpha   = n.getAlpha();          // 0→1 при появлении, 1→0 при угасании
            float slideIn = n.getSlideIn();         // 0=за экраном, 1=на месте

            int baseX = sw - WIDTH - MARGIN;
            int baseY = sh - MARGIN - HEIGHT - stackIdx * (HEIGHT + GAP);

            // Offset slide: едет справа
            int x = baseX + (int)((1f - slideIn) * (WIDTH + MARGIN));
            int y = baseY;

            // Тень
            int shadowAlpha = (int)(alpha * 60);
            ctx.fill(x+3, y+4, x+WIDTH+3, y+HEIGHT+4, (shadowAlpha << 24));

            // Фон (стеклянный)
            int bgA = (int)(alpha * 0xCC);
            ctx.fill(x, y, x+WIDTH, y+HEIGHT, (bgA << 24) | (BG_COLOR & 0x00FFFFFF));

            // Верхняя и левая граница (стекло)
            int borderA = (int)(alpha * 0x30);
            ctx.fill(x, y, x+WIDTH, y+1, (borderA << 24) | 0xFFFFFF);
            ctx.fill(x, y, x+1, y+HEIGHT, (borderA << 24) | 0xFFFFFF);
            ctx.fill(x+WIDTH-1, y, x+WIDTH, y+HEIGHT, (borderA << 24 / 2) | 0xFFFFFF);

            // Левая цветная полоска (тип уведомления)
            int stripColor = getTypeColor(n.type, t);
            int stripA = (int)(alpha * 255);
            ctx.fill(x, y, x+3, y+HEIGHT, (stripA << 24) | (stripColor & 0x00FFFFFF));

            // Иконка
            String icon = getTypeIcon(n.type);
            int iconColor = (stripA << 24) | (stripColor & 0x00FFFFFF);
            ctx.drawText(mc.textRenderer, icon, x+8, y+HEIGHT/2-4, iconColor, false);

            // Заголовок
            int titleAlpha = (int)(alpha * 255);
            ctx.drawText(mc.textRenderer, n.title,
                         x+20, y+8, (titleAlpha << 24) | (WHITE & 0x00FFFFFF), false);

            // Сообщение
            int msgAlpha = (int)(alpha * 180);
            ctx.drawText(mc.textRenderer, n.message,
                         x+20, y+HEIGHT-14, (msgAlpha << 24) | (WHITE_DIM & 0x00FFFFFF), false);

            // Progress bar (оставшееся время)
            float progress = n.getProgress(); // 1.0=только появилось, 0.0=сейчас умрёт
            int barW = (int)(progress * (WIDTH - 6));
            int barAlpha = (int)(alpha * 120);
            ctx.fill(x+3, y+HEIGHT-2, x+WIDTH-3, y+HEIGHT-1, (barAlpha/2 << 24) | 0xFFFFFF);
            if (barW > 0) {
                int progressColor = getTypeColor(n.type, t);
                ctx.fill(x+3, y+HEIGHT-2, x+3+barW, y+HEIGHT-1,
                         (barAlpha << 24) | (progressColor & 0x00FFFFFF));
            }

            stackIdx++;
        }
    }

    // ── Вспомогательные ──────────────────────────────────────────────────────

    private static int getTypeColor(Type type, Theme t) {
        return switch (type) {
            case SUCCESS -> t.positive  & 0x00FFFFFF;
            case WARNING -> t.negative  & 0x00FFFFFF;
            case TOGGLE  -> t.accent    & 0x00FFFFFF;
            default      -> 0xAAAAAA;
        };
    }

    private static String getTypeIcon(Type type) {
        return switch (type) {
            case SUCCESS -> "✔";
            case WARNING -> "✗";
            case TOGGLE  -> "⚡";
            default      -> "◈";
        };
    }

    // ════════════════════════════════════════════════════════════════════════
    // Notification — внутренний класс
    // ════════════════════════════════════════════════════════════════════════

    private static class Notification {
        final String title;
        final String message;
        final Type   type;
        final long   duration;
        final long   startTime;

        // Анимации
        float slideIn = 0f;

        Notification(String title, String message, Type type, long duration) {
            this.title     = title;
            this.message   = message;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration + 500;
        }

        /** Прозрачность: fade-in 200ms, fade-out 400ms в конце */
        float getAlpha() {
            long elapsed = System.currentTimeMillis() - startTime;
            float fadeInMs  = 200f;
            float fadeOutMs = 400f;
            if (elapsed < fadeInMs)
                return elapsed / fadeInMs;
            if (elapsed > duration - fadeOutMs)
                return AnimationUtils.clamp((duration - elapsed) / fadeOutMs, 0f, 1f);
            return 1f;
        }

        /** Slide-in: 0=за экраном, 1=на месте (easing) */
        float getSlideIn() {
            slideIn = AnimationUtils.lerp(slideIn, 1f, 0.2f);
            return slideIn;
        }

        /** Progress: 1.0→0.0 за время duration */
        float getProgress() {
            long elapsed = System.currentTimeMillis() - startTime;
            return AnimationUtils.clamp(1f - (float) elapsed / duration, 0f, 1f);
        }
    }
}
