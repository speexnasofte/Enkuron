package net.enkuron.ui;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * HudEditorScreen — красивый редактор позиций HUD элементов.
 * Поддерживает перетаскивание, snap-to-grid, ПКМ вкл/выкл, [G] сброс.
 */
public class HudEditorScreen extends Screen {

    private static final int GRID_STEP   = 25;
    private static final int SNAP_DIST   = 5;
    private static final int BAR_H       = 22;

    private static final int COL_BG        = 0x99000000;
    private static final int COL_GRID      = 0x18FFFFFF;
    private static final int COL_BOX_IDLE  = 0x44FFFFFF;
    private static final int COL_BOX_HOV   = 0x88FFFFFF;
    private static final int COL_BOX_DRAG  = 0x66AA55FF;
    private static final int COL_BORDER_ON  = 0xFF8844FF;
    private static final int COL_BORDER_OFF = 0xFF555577;
    private static final int COL_TOOLTIP_BG = 0xEE141419;

    private Module draggingModule = null;
    private int    dragOffsetX, dragOffsetY;
    private Module hoveredModule  = null;
    private float  openAnim       = 0f;

    public HudEditorScreen() {
        super(Text.literal("Enkuron HUD Editor"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        openAnim = AnimationUtils.lerp(openAnim, 1f, 0.12f);

        // Фон
        ctx.fill(0, 0, width, height, COL_BG);
        drawGrid(ctx);

        // Двигаем перетаскиваемый модуль
        if (draggingModule != null) {
            int nx = snap(mouseX - dragOffsetX);
            int ny = snap(mouseY - dragOffsetY);
            nx = clamp(nx, 0, width  - Math.max(draggingModule.width,  60));
            ny = clamp(ny, 0, height - Math.max(draggingModule.height, 20) - BAR_H);
            draggingModule.setX(nx);
            draggingModule.setY(ny);
        }

        // Определяем hovered
        hoveredModule = null;
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() != Module.Category.HUD) continue;
            int bw = Math.max(m.width, 60), bh = Math.max(m.height, 20);
            if (mouseX >= m.getX() && mouseX <= m.getX() + bw
             && mouseY >= m.getY() && mouseY <= m.getY() + bh) {
                hoveredModule = m;
            }
        }

        // Рисуем блоки
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() != Module.Category.HUD) continue;
            drawHudBox(ctx, m, mouseX, mouseY);
        }

        drawBottomBar(ctx, mouseX, mouseY);

        if (hoveredModule != null && draggingModule == null) {
            drawTooltip(ctx, hoveredModule, mouseX, mouseY);
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawGrid(DrawContext ctx) {
        for (int gx = 0; gx < width;  gx += GRID_STEP) ctx.fill(gx, 0, gx + 1, height - BAR_H, COL_GRID);
        for (int gy = 0; gy < height - BAR_H; gy += GRID_STEP) ctx.fill(0, gy, width, gy + 1, COL_GRID);
    }

    private void drawHudBox(DrawContext ctx, Module m, int mx, int my) {
        int x = m.getX(), y = m.getY();
        int w = Math.max(m.width, 60), h = Math.max(m.height, 20);
        boolean drag = (m == draggingModule);
        boolean hov  = (m == hoveredModule);

        int bg  = drag ? COL_BOX_DRAG : hov ? COL_BOX_HOV : COL_BOX_IDLE;
        int brd = m.isEnabled() ? COL_BORDER_ON : COL_BORDER_OFF;
        if (drag) brd = 0xFFAA66FF;

        ctx.fill(x, y, x + w, y + h, bg);
        // Рамка
        ctx.fill(x,         y,         x + w, y + 1,     brd);
        ctx.fill(x,         y + h - 1, x + w, y + h,     brd);
        ctx.fill(x,         y,         x + 1, y + h,     brd);
        ctx.fill(x + w - 1, y,         x + w, y + h,     brd);

        // Угловые акценты при hover/drag
        if (hov || drag) {
            int ac = drag ? 0xFFDD99FF : 0xFFCCAAFF;
            ctx.fill(x,         y,         x + 5,     y + 1,     ac);
            ctx.fill(x,         y,         x + 1,     y + 5,     ac);
            ctx.fill(x + w - 5, y,         x + w,     y + 1,     ac);
            ctx.fill(x + w - 1, y,         x + w,     y + 5,     ac);
            ctx.fill(x,         y + h - 1, x + 5,     y + h,     ac);
            ctx.fill(x,         y + h - 5, x + 1,     y + h,     ac);
            ctx.fill(x + w - 5, y + h - 1, x + w,     y + h,     ac);
            ctx.fill(x + w - 1, y + h - 5, x + w,     y + h,     ac);
        }

        // Статус-точка
        int dot = m.isEnabled() ? 0xFF44EE77 : 0xFFEE4444;
        ctx.fill(x + 4, y + h/2 - 2, x + 8, y + h/2 + 2, dot);

        // Имя модуля
        int textCol = m.isEnabled() ? 0xFFFFFFFF : 0xFFAAAAAA;
        ctx.drawText(client.textRenderer, m.getName(), x + 13, y + (h - 8) / 2, textCol, false);

        // Координаты при hover
        if (hov || drag) {
            String pos = x + "," + y;
            int pw = client.textRenderer.getWidth(pos);
            ctx.drawText(client.textRenderer, pos, x + w - pw - 3, y + h - 9, 0xFF888888, false);
        }
    }

    private void drawBottomBar(DrawContext ctx, int mx, int my) {
        int barY = height - BAR_H;
        ctx.fill(0, barY, width, height, 0xEE0A0A0F);
        for (int i = 0; i < width; i++) {
            ctx.fill(i, barY, i + 1, barY + 1, EnkuronColor.rainbow(i * 8L));
        }
        String hint = "[ЛКМ] Переместить   [ПКМ] Вкл/Выкл   [G] Сбросить   [ESC] Выйти";
        ctx.drawCenteredTextWithShadow(client.textRenderer, hint, width / 2, barY + 7, 0xFFBBBBCC);
        ctx.drawTextWithShadow(client.textRenderer, "ENKURON HUD", width - 82, barY + 7, 0xFF8844FF);
    }

    private void drawTooltip(DrawContext ctx, Module m, int mx, int my) {
        String name  = m.getName();
        String desc  = m.getDescription();
        String state = m.isEnabled() ? "§aВключён" : "§cВыключен";
        int tw = Math.max(client.textRenderer.getWidth(name), client.textRenderer.getWidth(desc)) + 10;
        int th = 34;
        int tx = Math.min(mx + 12, width - tw - 4);
        int ty = Math.max(my - th - 6, 4);

        ctx.fill(tx, ty, tx + tw, ty + th, COL_TOOLTIP_BG);
        ctx.fill(tx, ty, tx + tw, ty + 1, 0xFF8844FF);
        ctx.drawText(client.textRenderer, "§f§l" + name, tx + 4, ty + 4, 0xFFFFFFFF, false);
        ctx.drawText(client.textRenderer, "§7" + desc,   tx + 4, ty + 14, 0xFFAAAAAA, false);
        ctx.drawText(client.textRenderer, state,          tx + 4, ty + 24, 0xFFFFFFFF, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() != Module.Category.HUD) continue;
            int x = m.getX(), y = m.getY();
            int w = Math.max(m.width, 60), h = Math.max(m.height, 20);
            if (mx >= x && mx <= x + w && my >= y && my <= y + h) {
                if (button == 0) {
                    draggingModule = m;
                    dragOffsetX = (int) mx - x;
                    dragOffsetY = (int) my - y;
                    return true;
                } else if (button == 1) {
                    m.toggle();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingModule = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 71) { // G — сброс позиций
            resetPositions();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void resetPositions() {
        int cx = 10, cy = 10;
        for (Module m : ModuleManager.getModules()) {
            if (m.getCategory() != Module.Category.HUD) continue;
            m.setX(cx);
            m.setY(cy);
            cy += Math.max(m.height, 20) + 6;
            if (cy > height - BAR_H - 60) { cy = 10; cx += 100; }
        }
    }

    private int snap(int v) { return Math.round((float) v / SNAP_DIST) * SNAP_DIST; }
    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    @Override
    public boolean shouldPause() { return false; }
}
