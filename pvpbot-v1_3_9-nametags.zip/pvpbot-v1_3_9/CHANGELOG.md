# PVPBot v1.3.9 — Changelog (улучшения от v1.3.8-improved)

## 🐛 Баги исправлены

### Fix 1: `AutoPearl` — полный rewrite на серверную сторону
- **Файл:** `AutoPearl.java`
- **Проблема:** AutoPearl использовал `Minecraft` client, `KeyMapping` reflection и
  `gameMode.useItem()` — клиентский код недоступен/некорректен для серверного NPC-бота.
  На dedicated сервере это вызывало `NullPointerException` (Minecraft.getInstance() = null).
- **Фикс:** Полный rewrite: удалены все client-side зависимости. Перл спавнится через
  `ThrownEnderpearl` entity на `ServerLevel`. Сигнатура изменена:
  `tick(Minecraft)` → `tick(BotEntity)`.

### Fix 2: `PatternAI` — `new Random()` каждый тик (GC waste)
- **Файл:** `PatternAI.java`
- **Проблема:** В `tickAntiPattern()` каждые 30–80 тиков создавался `new Random()` —
  короткоживущий объект без нужды. На серверах с сотнями ботов — постоянный GC pressure.
- **Фикс:** Добавлено поле `private final Random rnd = new Random()` — единственный
  экземпляр на весь жизненный цикл PatternAI.

### Fix 3: `MotionPredictor` — накопление velocity на земле
- **Файл:** `MotionPredictor.java`
- **Проблема:** В цикле предсказания `onGround` не обновлялся при приземлении цели.
  Гравитация продолжала уменьшать `vel.y` даже "под землёй" → предсказанная позиция
  уходила вниз → промахи при метании зелий/перлов.
- **Фикс:** Добавлена проверка приземления в каждой итерации: при `pos.y <= groundY`
  и `vel.y <= 0` — `vy = 0`, `onGround = true`. Трение переключается корректно.

### Fix 4: `WeaponSwitcher` — END_CRYSTAL в mainhand
- **Файл:** `WeaponSwitcher.java`
- **Проблема:** `Items.END_CRYSTAL` — это блок, не оружие. `new ItemStack(Items.END_CRYSTAL)`
  в mainhand через `setItemSlot` ломало анимацию удара, melee-логику и краш в некоторых
  серверных конфигурациях. `WeaponSwitcher` не должен управлять кристаллами.
- **Фикс:** В CRYSTAL/TPC режиме на средней дистанции WeaponSwitcher даёт `NETHERITE_SWORD`.
  Кристальной логикой управляет `CrystalBotLogic` независимо.

### Fix 5: `AutoRetreat` — лечение продолжается после смерти цели
- **Файл:** `AutoRetreat.java`
- **Проблема:** `tickHealing()` не проверял `target.isAlive()`. Если цель умирала пока
  бот лечился — healTimer доматывался до конца, потом бот шёл к трупу в RETURNING фазе.
- **Фикс:** В начале `tickHealing()` добавлена проверка: если `target == null || !isAlive()`
  → `phase = FIGHTING`, `healTimer = 0`, выход.

## ✨ Улучшения

### Improvement 1: `TargetPriority` — динамический abandon range
- **Файл:** `TargetPriority.java`
- **Было:** фиксированный `ABANDON_RANGE = 32.0` блоков для всех сложностей.
- **Стало:** `getDynamicAbandonRange()` — зависит от `cfg.difficulty`:
  - `EASY`:   24 блока (не гоняется далеко)
  - `NORMAL`: 32 блока (базовое)
  - `HARD/EXPERT`: 48 блоков (агрессивное преследование)
  - `FOCUS` режим: 64 блока (никогда не бросает принудительную цель)

### Improvement 2: `AdaptiveCooldown` — правильный подсчёт TPS
- **Файл:** `AdaptiveCooldown.java`
- **Было:** `System.nanoTime()` измерял wall clock между тиками — включал время
  обработки других сущностей → TPS был занижен → кулдаун завышен даже без лага.
- **Стало:** Используется `MinecraftServer.getAverageTickTimeNanos()` — официальный
  серверный TPS. Fallback на wall clock если API недоступно.

### Improvement 3: `FakeAttack` — умное срабатывание
- **Файл:** `FakeAttack.java`
- **Было:** фиксированный 18% шанс фейк-атаки независимо от ситуации.
- **Стало:** Учитывается контекст:
  - Цель блокирует щитом → +15% (фейк заставит убрать щит)
  - Цель с высоким HP (>15) → -5% (не спешим)
  - Цель почти мертва (<4 HP) → 0% (не тратим тик, добиваем)
  - Бот при критическом HP (<6) → 0% (нужен реальный урон или retreat)

### Check 8: `BotLearning` — `patternFreq` unbounded growth
- **Файл:** `BotLearning.java`
- **Проблема:** `prunePatterns()` содержал мёртвый код (первый `stream().forEach(e→{})`)
  и обрезал Map только до `TOP_PATTERNS * 2 = 16` записей, порог был `TOP_PATTERNS * 3 = 24`.
- **Фикс:** Удалён мёртвый stream. Порог снижен до `TOP_PATTERNS * 2 = 16`,
  обрезка до `TOP_PATTERNS = 8`. Map больше не растёт бесконечно.

### Fix 7: `FakeAttack` — небезопасный каст `ServerLevel` в `tick()`
- **Файл:** `FakeAttack.java`
- **Проблема:** В `tick()` при нанесении настоящего удара после фейка использовался прямой
  каст `(ServerLevel) bot.level()` без проверки `instanceof`. Это `ClassCastException`
  при вызове из клиентского контекста или некоторых серверных конфигураций.
  Ниже в том же блоке уже был корректный `instanceof ServerLevel sw` — каст дублировал логику
  и был опасен.
- **Фикс:** Оба вызова (`doHurtTarget` и `playSound`) объединены в одну защищённую ветку
  `if (... && bot.level() instanceof ServerLevel sw)`. Лишний `instanceof` удалён.

### Fix 8: `BotLearning` — `lastOnGround` не обновляется при JUMP (`sampleAction`)
- **Файл:** `BotLearning.java`
- **Проблема:** В `sampleAction()` после определения прыжка (`!player.onGround() && lastOnGround`)
  метод немедленно возвращал `Action.JUMP` без обновления `lastOnGround = false`.
  `lastOnGround` обновлялся только в конце метода, до которого выполнение не доходило.
  Следствие: при любом прыжке `Action.JUMP` фиксировался каждый тик пока игрок в воздухе,
  а не один раз при отрыве от земли — паттерн «переспамлен» прыжками.
- **Фикс:** `lastOnGround = false` перемещён перед `return Action.JUMP`.

## 📝 Изменённые файлы
- `AutoPearl.java` (полный rewrite)
- `PatternAI.java`
- `MotionPredictor.java`
- `WeaponSwitcher.java`
- `AutoRetreat.java`
- `TargetPriority.java`
- `AdaptiveCooldown.java`
- `FakeAttack.java`
- `BotLearning.java`

### Fix 6: `BotEntityRenderer` — броня не отображалась на модели бота
- **Файл:** `client/BotEntityRenderer.java`
- **Проблема:** `HumanoidMobRenderer` рендерит только базовую модель (тело Стива).
  Броня в MC рендерится отдельным слоем — `HumanoidArmorLayer`. Без него
  `setItemSlot(HEAD/CHEST/LEGS/FEET, ...)` работает на сервере (защита считается),
  но клиент ничего не рисует → бот всегда выглядит как голый Стив.
- **Фикс:** В конструктор добавлен `this.addLayer(new HumanoidArmorLayer(...))` с
  `PLAYER_INNER_ARMOR` и `PLAYER_OUTER_ARMOR` слоями.
