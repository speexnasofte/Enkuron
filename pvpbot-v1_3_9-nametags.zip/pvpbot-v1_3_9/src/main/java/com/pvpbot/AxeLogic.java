package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * AxeLogic v5.0 — УЛУЧШЕНО
 *
 * Исправления:
 *   - WTapLogic (серверный) вместо ничего
 *   - IDEAL_DIST 2.6 → 2.3 (держимся ближе)
 *   - AXE_CD 22 → 18 (топор чуть быстрее в рамках реализма)
 *   - BURST_CD 8 → 5 (бёрст мечом агрессивнее после слома щита)
 *   - BURST_COUNT 3 → 4 (4 удара мечом пока щит сломан)
 *   - Прыжок-крит каждые CRIT_EVERY=3 удара (было нет явной цифры)
 *   - Navigation: спринт только при dist > 6 (не дёргается рядом)
 *   - Щит бота: блок только когда цель атакует (было всегда)
 */
public class AxeLogic {

    private static final double MELEE_RANGE    = 3.2;
    private static final double IDEAL_DIST     = 2.3;  // FIX: было 2.6
    private static final double RANGED_DIST    = 10.0;
    private static final int    AXE_CD         = 18;   // FIX: было 22
    private static final int    SHIELD_DIS_DUR = 100;
    private static final int    BURST_CD       = 5;    // FIX: было 8
    private static final int    BURST_COUNT    = 4;    // FIX: было 3
    private static final int    DASH_CD        = 60;   // FIX: было 70
    private static final int    CRIT_EVERY     = 3;
    private static final int    XBOW_CD        = 32;   // FIX: было 35

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;           // FIX: серверный W-tap
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int  attackCd       = 0;
    private int  dashCd         = 0;
    private int  shieldDisabled = 0;
    private int  burstHits      = 0;
    private int  burstCd        = 0;
    private int  hitCount       = 0;
    private int  xbowCd         = 0;
    private boolean inBurst     = false;
    private boolean critPending = false;

    public AxeLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) {
            critPending = false; // FIX: сбрасываем зависший крит
            wTap.reset();
            return;
        }

        if (attackCd       > 0) attackCd--;
        if (shieldDisabled > 0) shieldDisabled--;
        if (burstCd        > 0) burstCd--;
        if (dashCd         > 0) dashCd--;
        if (xbowCd         > 0) xbowCd--;

        double dist    = bot.distanceTo(target);
        boolean blocking = isTargetBlocking(target);

        // Щит в оффхенд
        equipShieldOffhand();

        // Дальний бой: арбалет если цель держит щит
        if (dist > MELEE_RANGE || (blocking && shieldDisabled <= 0)) {
            if (dist <= RANGED_DIST && xbowCd <= 0 && blocking) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
                bot.getLookControl().setLookAt(target, 60f, 60f);
                if (target.isAlive()) target.hurt(sw.damageSources().mobAttack(bot), 9.0f); // FIX: arrow(null) → NPE
                sw.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY()+1, target.getZ(), 4, 0.2,0.2,0.2,0.1);
                xbowCd = XBOW_CD;
            } else if (dist > MELEE_RANGE) {
                // FIX: спринт только при dist > 6
                if (dist > 6.0 && dashCd <= 0) {
                    bot.getNavigation().moveTo(target, 1.4);
                    bot.setSprinting(true);
                    dashCd = DASH_CD;
                } else {
                    bot.getNavigation().moveTo(target, 1.05);
                }
            }
        }

        // Страф
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive && dist < MELEE_RANGE + 2.0 && cfg.strafeEnabled) strafe.tick(target);
        if (dist > MELEE_RANGE) return;

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Ломаем щит топором
        if (blocking && attackCd <= 0 && !wTapActive) {
            equipAxe();
            doAxeHit(sw, target, false);
            shieldDisabled = SHIELD_DIS_DUR;
            inBurst = true; burstHits = 0;
        }
        // Бёрст мечом пока щит сломан
        else if (shieldDisabled > 0 && inBurst && !wTapActive) {
            doBurstSword(sw, target);
        }
        // Обычная атака топором с крит-прыжком
        else if (!blocking && attackCd <= 0 && !wTapActive) {
            equipAxe();
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAxeHit(sw, target, true);
                critPending = false;
            } else if (!doCrit) {
                doAxeHit(sw, target, false);
                critPending = false;
            }
        }
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 6, 0.3,0.3,0.3,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.85f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
            bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : AXE_CD;
        // FIX: серверный W-tap после удара
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    private void doBurstSword(ServerLevel sw, LivingEntity target) {
        if (burstCd > 0) return;
        if (burstHits < BURST_COUNT) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            burstCd = BURST_CD;
            burstHits++;
            if (cfg.wTapEnabled) wTap.onAttack();
        } else {
            inBurst = false;
            burstHits = 0;
        }
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled > 0) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_AXE));
    }

    private void equipShieldOffhand() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }
}
