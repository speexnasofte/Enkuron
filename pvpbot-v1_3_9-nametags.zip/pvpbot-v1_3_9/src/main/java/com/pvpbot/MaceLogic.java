package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * MaceLogic v5.0 — MCTiers Mace PvP. ПОЛНОСТЬЮ ПЕРЕПИСАН.
 *
 * ИСПРАВЛЕНИЯ v5.0:
 *  - Бот ВСЕГДА держит булаву в руке (не меч!)
 *  - Wind Charge бросается как снаряд (velocity + звук + частицы)
 *  - Смэш: прыжок → пик → падение → удар булавой с бонусом высоты
 *  - Бот смотрит на цель и приближается к ней
 *  - НЕТ отступления — только атака
 *  - Тотем в оффхенд всегда
 */
public class MaceLogic {

    private static final double MELEE_RANGE  = 3.5;
    private static final double IDEAL_DIST   = 2.8;
    private static final double WIND_DIST    = 6.0;
    private static final int    SMASH_EVERY  = 4;   // каждые N ударов — смэш
    private static final int    SMASH_CD     = 25;
    private static final int    WIND_CD      = 35;
    private static final int    GAP_CD       = 200;
    private static final int    ATTACK_CD    = 8;
    private static final float  SMASH_BASE   = 10.0f;
    private static final float  FALL_BONUS   = 2.0f;
    private static final float  MAX_DAMAGE   = 40.0f;

    private enum State { FIGHTING, JUMP_UP, FALLING, SMASH, COOLDOWN }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int smashCd  = 0;
    private int windCd   = 0;
    private int gapCd    = 0;
    private int attackCd = 0;
    private int hitCount = 0;
    private double jumpStartY = 0;
    private double peakY      = 0;

    public MaceLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { state = State.FIGHTING; return; }

        if (smashCd  > 0) smashCd--;
        if (windCd   > 0) windCd--;
        if (gapCd    > 0) gapCd--;
        if (attackCd > 0) attackCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Тотем в оффхенд всегда ──────────────────────────────
        ensureTotem();

        // ── Golden Apple при низком HP ───────────────────────────
        if (myHp < 10.0f && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
        }

        // ── Всегда смотрим на цель ───────────────────────────────
        bot.getLookControl().setLookAt(target, 30f, 30f);

        switch (state) {
            case FIGHTING -> tickFighting(sw, target, dist);
            case JUMP_UP  -> tickJumpUp(target);
            case FALLING  -> tickFalling(sw, target);
            case SMASH    -> tickSmash(sw, target);
            case COOLDOWN -> { if (smashCd <= 0) state = State.FIGHTING; }
            default -> {}
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        // ── Навигация — ВСЕГДА двигаемся к цели ─────────────────
        if (dist > IDEAL_DIST + 0.5) {
            bot.getNavigation().moveTo(target, 1.1);
            bot.setSprinting(dist > 5.0);
        } else {
            bot.getNavigation().stop();
            bot.setSprinting(false);
        }

        // ── Страф если близко ───────────────────────────────────
        if (dist < MELEE_RANGE + 2.5 && cfg.strafeEnabled) strafe.tick(target);

        // ── Wind Charge — бросаем снаряд который отталкивает цель вверх ──
        if (windCd <= 0 && dist <= WIND_DIST) {
            throwWindCharge(sw, target);
            windCd = WIND_CD;
        }

        if (dist > MELEE_RANGE) return;

        // ── Каждые SMASH_EVERY ударов — прыжок со смэшем ────────
        if (hitCount > 0 && hitCount % SMASH_EVERY == 0 && smashCd <= 0 && bot.onGround()) {
            jumpStartY = bot.getY();
            peakY      = jumpStartY;
            bot.getJumpControl().jump();
            bot.setSprinting(false);
            state = State.JUMP_UP;
            bot.getNavigation().stop();
            return;
        }

        // ── Обычный удар булавой ─────────────────────────────────
        if (attackCd <= 0) {
            equipMace();
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 4, 0.2,0.2,0.2,0.05);
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
            hitCount++;
            attackCd = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
        }
    }

    private void tickJumpUp(LivingEntity target) {
        double y = bot.getY();
        if (y > peakY) peakY = y;
        // Направляемся к цели во время прыжка
        bot.getLookControl().setLookAt(target, 30f, 30f);
        // Начали падать → FALLING
        if (y < peakY - 0.15 || (!bot.onGround() && bot.getDeltaMovement().y < -0.05))
            state = State.FALLING;
    }

    private void tickFalling(ServerLevel sw, LivingEntity target) {
        double dist     = bot.distanceTo(target);
        double vertDiff = bot.getY() - target.getY();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        // Двигаемся к цели пока падаем
        if (dist > 1.5) bot.getNavigation().moveTo(target, 1.2);
        if (vertDiff <= 2.0 && dist <= MELEE_RANGE + 1.5) {
            state = State.SMASH;
            tickSmash(sw, target);
        } else if (bot.onGround()) {
            // Промахнулись — кд и назад в FIGHTING
            state = State.COOLDOWN;
            smashCd = SMASH_CD / 2;
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        if (target == null || !target.isAlive()) { state = State.COOLDOWN; smashCd = SMASH_CD; return; }

        double fallBlocks = Math.max(0, peakY - bot.getY());
        float  damage     = Math.min(MAX_DAMAGE, SMASH_BASE + (float)(fallBlocks * FALL_BONUS));

        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Knockback от смэша
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive()) target.setDeltaMovement(kb.x * 2.2, 1.6, kb.z * 2.2);

        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 24, 0.6,0.6,0.6,0.3);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.75f);

        // Тормозим после смэша
        Vec3 v = bot.getDeltaMovement();
        bot.setDeltaMovement(v.x * 0.2, Math.max(v.y, 0), v.z * 0.2);

        notifyOwner(String.format("§6[Mace] §cSmash! §e%.1f dmg §7(fall: %.1f)", damage, fallBlocks));

        hitCount++;
        smashCd = SMASH_CD;
        state   = State.COOLDOWN;
    }

    /** FIX: Wind Charge — бросаем снаряд velocity-импульсом на цель */
    private void throwWindCharge(ServerLevel sw, LivingEntity target) {
        Vec3 dir = target.getEyePosition().subtract(bot.getEyePosition()).normalize();
        // Создаём WindCharge entity
        try {
            var wc = new net.minecraft.world.entity.projectile.WindCharge(
                net.minecraft.world.entity.EntityType.WIND_CHARGE, sw);
            wc.setOwner(bot);
            wc.setPos(bot.getX(), bot.getEyeY() - 0.1, bot.getZ());
            wc.shoot(dir.x, dir.y + 0.1, dir.z, 1.5f, 0.5f);
            sw.addFreshEntity(wc);
        } catch (Exception e) {
            // Fallback: ручной импульс если WindCharge entity не доступен
            target.setDeltaMovement(
                target.getDeltaMovement().add(dir.x * 1.5, 1.8, dir.z * 1.5));
        }
        sw.sendParticles(ParticleTypes.GUST,
            bot.getX() + dir.x, bot.getEyeY(), bot.getZ() + dir.z,
            10, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(SoundEvents.WIND_CHARGE_THROW, 1.0f, 1.0f);
    }

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.MACE, bot.level().registryAccess())
                    .enchant("density", 5).enchant("breach", 4)
                    .enchant("unbreaking", 3).build());
    }

    private void ensureTotem() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    public boolean isSmashing() {
        return state == State.JUMP_UP || state == State.FALLING || state == State.SMASH;
    }

    public String getStateLabel() {
        return switch (state) {
            case FIGHTING -> "MACE:FIGHT";
            case JUMP_UP  -> "MACE:JUMP";
            case FALLING  -> "MACE:FALL";
            case SMASH    -> "MACE:SMASH!";
            case COOLDOWN -> "MACE:CD";
            default       -> "?";
        };
    }
}