package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;

/**
 * ModeLogicDispatcher v5.1 — Полный диспетчер всех режимов.
 *
 * Режимы: SWORD, AXE, MACE, MACE_ELYTRA, UHC, NETHOP, POT, SMP, CRYSTAL
 * Полная поддержка всех режимов: SWORD, AXE, MACE, MACE_ELYTRA, UHC, NETHOP, NETHPOT, POT, SMP, CRYSTAL, TPC, SNOWBALL, TRIDENT, BEEHIVE, CROSSBOW, TOTEM
 */
public class ModeLogicDispatcher {

    private final BotEntity bot;

    private SwordLogic      swordLogic;
    private AxeLogic        axeLogic;
    private UhcLogic        uhcLogic;
    private NethPotLogic    nethPotLogic;   // используется для POT и NETHOP
    private SmpLogic        smpLogic;
    private MaceLogic       maceLogic;
    private MaceElytraLogic maceElytraLogic;
    private CrystalBotLogic crystalBotLogic;
    private TpcLogic        tpcLogic;
    private SnowballLogic   snowballLogic;
    private TridentLogic    tridentLogic;
    private BeehiveLogic    beehiveLogic;
    private CrossbowLogic   crossbowLogic;
    private TotemLogic      totemLogic;

    private PVPBotConfig.Mode lastMode = null;

    public ModeLogicDispatcher(BotEntity bot) {
        this.bot = bot;
    }

    public boolean tick(LivingEntity target) {
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;
        if (mode == null) return false;

        if (mode != lastMode) {
            onModeChanged();
            lastMode = mode;
        }

        // УЛУЧШЕНИЕ: SWORD/AXE возвращают false → BotDifficultyAI управляет ими через tickEasy/Medium/Hard/Expert
        // Специализированные киты (SMP, CRYSTAL, TPC и др.) → dispatcher ведёт их сам (возвращает true)
        switch (mode) {
            case SWORD, AXE  -> { return false; } // BotDifficultyAI.tickXxx() управляет
            case UHC         -> getUhc().tick(target);
            case POT, NETHOP -> getNethPot().tick(target);
            case SMP         -> getSmp().tick(target);
            case MACE_ELYTRA -> getMaceElytra().tick(target);
            case CRYSTAL     -> getCrystal().tick(
                (net.minecraft.server.level.ServerLevel) bot.level(), target);
            case TPC         -> getTpc().tick(target);
            case SNOWBALL    -> getSnowball().tick(target);
            case TRIDENT     -> getTrident().tick(target);
            case BEEHIVE     -> getBeehive().tick(target);
            case CROSSBOW    -> getCrossbow().tick(target);
            case TOTEM       -> getTotem().tick(target);
            case NETHPOT     -> getNethPot().tick(target);
            default -> { return false; } // неизвестный режим → BotDifficultyAI
        }
        return true;
    }

    private SwordLogic      getSword()     { if (swordLogic      == null) swordLogic      = new SwordLogic(bot);      return swordLogic;      }
    private AxeLogic        getAxe()       { if (axeLogic        == null) axeLogic        = new AxeLogic(bot);        return axeLogic;        }
    private UhcLogic        getUhc()       { if (uhcLogic        == null) uhcLogic        = new UhcLogic(bot);        return uhcLogic;        }
    private NethPotLogic    getNethPot()   { if (nethPotLogic    == null) nethPotLogic    = new NethPotLogic(bot);    return nethPotLogic;    }
    private SmpLogic        getSmp()       { if (smpLogic        == null) smpLogic        = new SmpLogic(bot);        return smpLogic;        }
    private MaceLogic       getMace()      { if (maceLogic       == null) maceLogic       = new MaceLogic(bot);       return maceLogic;       }
    private MaceElytraLogic getMaceElytra(){ if (maceElytraLogic == null) maceElytraLogic = new MaceElytraLogic(bot); return maceElytraLogic; }
    private CrystalBotLogic getCrystal()  { if (crystalBotLogic == null) crystalBotLogic = new CrystalBotLogic(bot); return crystalBotLogic; }
    private TpcLogic        getTpc()       { if (tpcLogic        == null) tpcLogic        = new TpcLogic(bot);        return tpcLogic;        }
    private SnowballLogic   getSnowball()  { if (snowballLogic   == null) snowballLogic   = new SnowballLogic(bot);   return snowballLogic;   }
    private TridentLogic    getTrident()   { if (tridentLogic    == null) tridentLogic    = new TridentLogic(bot);    return tridentLogic;    }
    private BeehiveLogic    getBeehive()   { if (beehiveLogic    == null) beehiveLogic    = new BeehiveLogic(bot);    return beehiveLogic;    }
    private CrossbowLogic   getCrossbow()  { if (crossbowLogic   == null) crossbowLogic   = new CrossbowLogic(bot);   return crossbowLogic;   }
    private TotemLogic      getTotem()     { if (totemLogic      == null) totemLogic      = new TotemLogic(bot);      return totemLogic;      }

    private void onModeChanged() {
        // Сбрасываем все логики при смене режима
        swordLogic      = null;
        axeLogic        = null;
        uhcLogic        = null;
        nethPotLogic    = null;
        smpLogic        = null;
        maceLogic       = null;
        maceElytraLogic = null;
        crystalBotLogic = null;
        tpcLogic        = null;
        snowballLogic   = null;
        tridentLogic    = null;
        beehiveLogic    = null;
        crossbowLogic   = null;
        totemLogic      = null;
    }

    public String getStatusLabel() {
        return switch (PVPBotConfig.INSTANCE.mode) {
            case SWORD       -> "SWORD";
            case AXE         -> "AXE";
            case UHC         -> "UHC";
            case POT         -> "POT";
            case NETHOP      -> "NETHOP";
            case SMP         -> "SMP";
            case MACE        -> maceLogic != null ? getMace().getStateLabel() : "MACE:INIT";
            case MACE_ELYTRA -> maceElytraLogic != null ? getMaceElytra().getStateLabel() : "ME:INIT";
            case CRYSTAL     -> crystalBotLogic != null ? getCrystal().getPhaseLabel() : "CRYS:INIT";
            case TPC         -> tpcLogic      != null ? "TPC"         : "TPC:INIT";
            case SNOWBALL    -> snowballLogic != null ? getSnowball().getStateLabel() : "SNOW:INIT";
            case TRIDENT     -> tridentLogic  != null ? getTrident().getStateLabel()  : "TRI:INIT";
            case BEEHIVE     -> "BEEHIVE";
            case CROSSBOW    -> "CROSSBOW";
            case TOTEM       -> "TOTEM";
            case NETHPOT     -> "NETHPOT";
            default          -> "?";
        };
    }
}
