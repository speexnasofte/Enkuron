package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * SwordLogic v5.0 — УЛУЧШЕНО
 *
 * Исправления:
 *   - W-tap через серверный WTapLogic (не KeyMapping)
 *   - Крит-логика: прыжок только когда бот на земле и дистанция позволяет
 *   - NAV_SPEED: 1.05 → 1.08 (чуть агрессивнее)
 *   - IDEAL_DIST: 2.4 → 2.2 (держимся ближе к цели)
 *   - BOW_CD: 20 → 18 (чуть быстрее лук)
 */
public class SwordLogic {

    private static final double MELEE_RANGE = 3.2;
    private static final double IDEAL_DIST  = 2.2; // FIX: было 2.4
    private static final double BOW_RANGE   = 7.0;
    private static final int    CRIT_EVERY  = 3;
    private static final int    BOW_CD      = 18; // FIX: было 20
    private static final double NAV_SPEED   = 1.08; // FIX: было 1.05

    private int     attackCd    = 0;
    private int     hitCount    = 0;
    private int     bowCd       = 0;
    private boolean critPending = false;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap; // FIX: серверный W-tap
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public SwordLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(switch (cfg.difficulty) {
            case EASY   -> StrafeAI.StrafeStyle.RANDOM;
            case MEDIUM -> StrafeAI.StrafeStyle.CIRCLE;
            case HARD, EXPERT -> StrafeAI.StrafeStyle.ZIGZAG;
            default     -> StrafeAI.StrafeStyle.CIRCLE;
        });
    }

    /**
     * Получить уровень зачарования Sharpness/Smite/Bane на мечe бота.
     * Используется для корректного расчёта урона через doHurtTarget.
     * doHurtTarget в 1.21.x читает зачарования из ItemStack через DataComponents,
     * поэтому если меч построен через EnchantUtil — зачарования УЧИТЫВАЮТСЯ автоматически.
     * Но для bow/прямых hurt() вызовов — считаем вручную.
     */
    private float calcSharpnessBonus(ItemStack sword) {
        // В 1.21.1 зачарования в DataComponents — читаем через ItemEnchantments
        var enchData = sword.get(net.minecraft.core.component.DataComponents.ENCHANTMENTS);
        if (enchData == null) return 0f;
        // Sharpness: +0.5 * level + 0.5 (начиная с уровня 1)
        // Ищем sharpness через ключ
        for (var entry : enchData.entrySet()) {
            var rl = entry.getKey().unwrapKey().map(k -> k.location().getPath()).orElse("");
            if (rl.equals("sharpness")) {
                int lvl = entry.getIntValue();
                return lvl >= 1 ? 0.5f * lvl + 0.5f : 0f;
            }
            if (rl.equals("smite") || rl.equals("bane_of_arthropods")) {
                // Эти зачарования ванилла учитывает сама через doHurtTarget
                return 0f;
            }
        }
        return 0f;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) {
            strafe.tick(null);
            critPending = false; // FIX: сбрасываем зависший крит если цель ушла
            wTap.reset();
            return;
        }

        if (attackCd > 0) attackCd--;
        if (bowCd    > 0) bowCd--;

        double dist = bot.distanceTo(target);

        // Лук на дальней дистанции
        if (dist > BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                    .enchant("power", 5).enchant("unbreaking", 3).build());
            bot.getLookControl().setLookAt(target, 60f, 60f);
            float dmg = (float) Math.max(1.5, 9.0 - dist * 0.3);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            bowCd = BOW_CD;
            return;
        }

        equipSword();

        // FIX: W-tap тик — блокирует движение и Navigation если активен
        boolean wTapActive = wTap.tick(target);

        if (!wTapActive) {
            if (dist > IDEAL_DIST + 0.8)
                bot.getNavigation().moveTo(target, NAV_SPEED);
            else if (dist < IDEAL_DIST - 0.5)
                bot.getNavigation().stop();

            // FIX: страф только если strafeEnabled = true
            if (cfg.strafeEnabled && dist < MELEE_RANGE + 3.0) strafe.tick(target);
        }

        // Атака
        if (dist <= MELEE_RANGE && attackCd <= 0 && !wTapActive) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAttack(sw, target, true);
                critPending = false;
            } else if (!doCrit) {
                doAttack(sw, target, false);
                critPending = false;
            }
        }
    }

    private void doAttack(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.getLookControl().setLookAt(target, 30f, 30f);
        // FIX: гарантируем что зачарованный меч экипирован ДО doHurtTarget.
        // 1.21.x считает урон от Sharpness через DataComponents на ItemStack в mainhand.
        // Без этого вызова бот мог держать не-зачарованный меч → урон как без шарпа.
        equipSword();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 6, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;

        // FIX: серверный W-tap после удара
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    /**
     * FIX: equipSword() ВСЕГДА ставит меч с правильными зачарованиями.
     * Раньше: if (!is(DIAMOND_SWORD)) — условие было true даже для незачарованного меча,
     * поэтому бот никогда не обновлял ItemStack и наносил одинаковый урон независимо от шарпа.
     * Теперь: проверяем наличие зачарования sharpness в стаке.
     */
    private void equipSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        boolean needsReequip = !cur.is(Items.DIAMOND_SWORD);
        if (!needsReequip) {
            // Проверяем что на мече есть Sharpness (не просто алмазный меч без зачарований)
            var enchData = cur.get(net.minecraft.core.component.DataComponents.ENCHANTMENTS);
            if (enchData == null || enchData.isEmpty()) {
                needsReequip = true;
            } else {
                boolean hasSharpness = enchData.entrySet().stream()
                    .anyMatch(e -> e.getKey().unwrapKey()
                        .map(k -> k.location().getPath().equals("sharpness"))
                        .orElse(false));
                if (!hasSharpness) needsReequip = true;
            }
        }
        if (needsReequip) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.DIAMOND_SWORD, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("unbreaking", 3).build());
        }
    }
}
