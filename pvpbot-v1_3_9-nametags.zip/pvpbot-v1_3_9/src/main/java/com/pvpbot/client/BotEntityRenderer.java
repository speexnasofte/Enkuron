package com.pvpbot.client;

import com.pvpbot.BotEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.ResourceLocation;

/**
 * BotEntityRenderer v10 — рендерит бота с моделью игрока, скином и бронёй.
 *
 * FIX v1.3.9: добавлен HumanoidArmorLayer — без него броня (шлем, нагрудник,
 * штаны, ботинки) не рендерилась на модели и бот выглядел как голый Стив.
 */
public class BotEntityRenderer extends HumanoidMobRenderer<BotEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {

    private static final ResourceLocation STEVE_TEXTURE =
        ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/player/wide/steve.png");

    public BotEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)),
            0.5f);

        // FIX: добавляем слой брони — без него броня не отображается на модели.
        // HumanoidArmorLayer читает EquipmentSlot.HEAD/CHEST/LEGS/FEET из entity
        // и рендерит соответствующие текстуры поверх базовой модели.
        this.addLayer(new HumanoidArmorLayer<>(
            this,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
            ctx.getEquipmentRenderer()
        ));
    }

    @Override
    public ResourceLocation getTextureLocation(HumanoidRenderState state) {
        return STEVE_TEXTURE;
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }
}
