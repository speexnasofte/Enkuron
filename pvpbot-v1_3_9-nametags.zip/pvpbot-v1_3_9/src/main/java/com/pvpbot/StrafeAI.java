package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

/**
 * StrafeAI v5.0 — полный переврайт.
 *
 * НОВОЕ v5.0:
 *  - CIRCLE/ZIGZAG/RANDOM всегда идут ВПЕРЁД к цели пока далеко
 *  - Страф начинается только когда dist < STRAFE_START_DIST
 *  - Стейт-машина: APPROACH → STRAFE → WALL_AVOID
 *  - W-tap интегрирован: сброс кулдауна атаки через короткий рывок
 *  - Angle-based страф — бот движется по дуге вокруг цели (не хаотично)
 *  - Нет velocity override — используем только navigation + setDeltaMovement
 *    для точного угла; не конфликтует с pathfinder
 */
public class StrafeAI {

    public enum StrafeStyle { CIRCLE, RANDOM, ZIGZAG, RETREAT }

    private static final double APPROACH_SPEED   = 1.15;
    private static final double STRAFE_SPEED     = 0.95;
    private static final double STRAFE_START     = 5.0;   // начало страфа
    private static final double IDEAL_DIST       = 2.6;   // идеальная дистанция в бою
    private static final double MAX_HORIZ_SPEED  = 0.22;
    private static final int    DIR_MIN          = 12;
    private static final int    DIR_MAX          = 26;
    private static final int    HIGH_GROUND_CD   = 45;
    private static final int    WTAP_INTERVAL    = 5;     // W-tap каждые N ударов

    private StrafeStyle style      = StrafeStyle.CIRCLE;
    private boolean     strafeLeft = true;
    private int         dirTimer   = DIR_MIN;
    private int         blockCd    = 0;
    private int         highGroundCd = 0;
    private int         wTapTimer  = 0;
    private float       adaptedYawOffset = 0f;

    private final BotEntity bot;

    public StrafeAI(BotEntity bot) {
        this.bot = bot;
        dirTimer = DIR_MIN + bot.level().getRandom().nextInt(DIR_MAX - DIR_MIN);
    }

    public void setStyle(StrafeStyle s) { this.style = s; }
    public StrafeStyle getStyle()       { return style; }
    public boolean isStrafeLeft()       { return strafeLeft; }
    public void setAdaptedYaw(float y)  { this.adaptedYawOffset = y; }

    // FIX: crystal-режим — не применяем velocity, Navigation управляет движением
    private boolean crystalMode = false;
    public void setCrystalMode(boolean v) { this.crystalMode = v; }

    public void tick(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            bot.getNavigation().stop();
            bot.setSprinting(false);
            return;
        }
        if (bot.level().isClientSide) return;

        // FIX: в crystal-режиме Navigation управляется CrystalBotLogic — не вмешиваемся
        if (crystalMode) return;

        double dist = bot.distanceTo(target);

        // ── Всегда смотрим на цель ────────────────────────────────
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Фаза APPROACH: просто идём к цели быстро ─────────────
        if (dist > STRAFE_START) {
            bot.getNavigation().moveTo(target, APPROACH_SPEED);
            bot.setSprinting(dist > 8.0);
            return;
        }

        // ── Фаза STRAFE ───────────────────────────────────────────
        if (blockCd > 0) blockCd--;

        // Уменьшаем таймер смены направления
        dirTimer--;
        if (dirTimer <= 0 && blockCd <= 0) {
            boolean wouldBlock = isSideBlocked(!strafeLeft, target);
            if (wouldBlock) {
                strafeLeft = !strafeLeft;
                blockCd    = 8;
                dirTimer   = 4;
            } else {
                strafeLeft = !strafeLeft;
                dirTimer = DIR_MIN + bot.level().getRandom().nextInt(DIR_MAX - DIR_MIN);
            }
        }

        // ── Высота — пытаемся быть выше цели ─────────────────────
        if (highGroundCd > 0) highGroundCd--;
        tickHighGround(target);

        // ── W-tap ─────────────────────────────────────────────────
        if (wTapTimer > 0) wTapTimer--;

        // ── Движение по стилю ─────────────────────────────────────
        switch (style) {
            case CIRCLE  -> doCircle(target, dist);
            case ZIGZAG  -> doZigzag(target, dist);
            case RANDOM  -> doRandom(target, dist);
            case RETREAT -> doCircle(target, dist); // retreat убран — ведём как circle
        }
    }

    // ── CIRCLE: движемся по дуге вокруг цели ──────────────────────
    private void doCircle(LivingEntity target, double dist) {
        Vec3 toBot   = bot.position().subtract(target.position());
        double angle = Math.atan2(toBot.z, toBot.x);
        double step  = strafeLeft ? 0.09 : -0.09; // ~5° за тик

        double newAngle = angle + step + Math.toRadians(adaptedYawOffset);
        double targetR  = IDEAL_DIST + 0.3;
        double nx = target.getX() + Math.cos(newAngle) * targetR;
        double nz = target.getZ() + Math.sin(newAngle) * targetR;

        // Проверяем что позиция не в блоке
        BlockPos destFoot = BlockPos.containing(nx, bot.getY() + 0.1, nz);
        BlockPos destHead = BlockPos.containing(nx, bot.getY() + 1.0, nz);
        if (bot.level().getBlockState(destFoot).isSolid() ||
            bot.level().getBlockState(destHead).isSolid()) {
            // Попытка в обратную сторону
            newAngle = angle - step;
            nx = target.getX() + Math.cos(newAngle) * targetR;
            nz = target.getZ() + Math.sin(newAngle) * targetR;
            strafeLeft = !strafeLeft;
            blockCd = 10;
        }

        // УЛУЧШЕНИЕ: spiral approach — если далеко, смещаем целевую точку ближе к цели
        // вместо прямого рывка к цели (убирает рывок-стоп паттерн)
        if (dist > IDEAL_DIST + 1.0) {
            double blendT = Math.min(1.0, (dist - IDEAL_DIST) / 4.0);
            double bx = nx + (target.getX() - nx) * blendT * 0.35;
            double bz = nz + (target.getZ() - nz) * blendT * 0.35;
            bot.getNavigation().moveTo(bx, bot.getY(), bz, APPROACH_SPEED);
        } else {
            bot.getNavigation().moveTo(nx, bot.getY(), nz, STRAFE_SPEED);
        }
    }

    // ── ZIGZAG: резкие смены направления ──────────────────────────
    private int zigzagFlipTimer = 0;
    private void doZigzag(LivingEntity target, double dist) {
        // FIX: выделенный таймер смены направления (не piggyback на dirTimer % modulo)
        if (zigzagFlipTimer-- <= 0) {
            strafeLeft = !strafeLeft;
            zigzagFlipTimer = DIR_MIN / 2 + bot.level().getRandom().nextInt(4);
        }
        Vec3 side = getSideVector(target, strafeLeft);
        Vec3 forward = target.position().subtract(bot.position()).normalize();

        // Зигзаг = диагональ (страф + движение к цели)
        Vec3 move = forward.add(side).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + move.x * 2.5,
            bot.getY(),
            bot.getZ() + move.z * 2.5,
            STRAFE_SPEED * 1.1
        );
        if (dist > IDEAL_DIST + 1.0)
            bot.getNavigation().moveTo(target, STRAFE_SPEED * 1.1);
    }

    // ── RANDOM: непредсказуемый страф ─────────────────────────────
    private void doRandom(LivingEntity target, double dist) {
        boolean rnd = (bot.level().getRandom().nextInt(3) == 0)
            ? !strafeLeft : strafeLeft;
        Vec3 side    = getSideVector(target, rnd);
        Vec3 forward = target.position().subtract(bot.position()).normalize();
        double blend = bot.level().getRandom().nextFloat() * 0.5 + 0.3;
        Vec3 move = side.scale(blend).add(forward.scale(1.0 - blend)).normalize();

        bot.getNavigation().moveTo(
            bot.getX() + move.x * 2.0,
            bot.getY(),
            bot.getZ() + move.z * 2.0,
            STRAFE_SPEED
        );
        if (dist > IDEAL_DIST + 1.5)
            bot.getNavigation().moveTo(target, STRAFE_SPEED);
    }

    // ── High Ground ───────────────────────────────────────────────
    private void tickHighGround(LivingEntity target) {
        if (highGroundCd > 0) return;
        if (bot.getY() >= target.getY() + 0.5) return; // уже выше

        BlockPos bp = bot.blockPosition();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (Math.sqrt(dx*dx + dz*dz) > 2.5) continue;
                BlockPos up = bp.offset(dx, 1, dz);
                if (!bot.level().getBlockState(up).isAir()) continue;
                if (!bot.level().getBlockState(up.below()).isSolid()) continue;
                if (!bot.level().getBlockState(up.above()).isAir()) continue;
                bot.getNavigation().moveTo(up.getX()+0.5, up.getY(), up.getZ()+0.5, 1.1);
                if (bot.onGround()) bot.getJumpControl().jump();
                highGroundCd = HIGH_GROUND_CD;
                return;
            }
        }
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private Vec3 getSideVector(LivingEntity target, boolean left) {
        Vec3 to = target.position().subtract(bot.position()).normalize();
        Vec3 side = left
            ? new Vec3(-to.z, 0,  to.x)
            : new Vec3( to.z, 0, -to.x);
        if (adaptedYawOffset != 0f) {
            double rad = Math.toRadians(adaptedYawOffset);
            double cos = Math.cos(rad), sin = Math.sin(rad);
            side = new Vec3(side.x*cos - side.z*sin, 0, side.x*sin + side.z*cos);
        }
        return side;
    }

    private boolean isSideBlocked(boolean left, LivingEntity target) {
        Vec3 side = getSideVector(target, left).scale(1.3);
        Vec3 p    = bot.position().add(side);
        BlockPos foot = BlockPos.containing(p.x, bot.getY()+0.1, p.z);
        BlockPos head = BlockPos.containing(p.x, bot.getY()+1.0, p.z);
        return bot.level().getBlockState(foot).isSolid()
            || bot.level().getBlockState(head).isSolid();
    }
}
