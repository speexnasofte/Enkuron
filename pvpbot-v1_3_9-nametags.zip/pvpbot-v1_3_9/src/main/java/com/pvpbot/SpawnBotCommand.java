package com.pvpbot;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

/**
 * Команды для управления ботом (v4):
 *   /bot spawn [count]  — заспавнить 1–N ботов рядом
 *   /bot kill           — убить всех ботов этого игрока
 *   /bot mode           — переключить режим GUARD / AGGRESSIVE / PASSIVE
 *   /bot tp             — телепортировать ботов к себе
 *   /bot equip          — выдать ботам снаряжение (netherite)
 *   /bot whitelist add <nick>
 *   /bot whitelist remove <nick>
 *   /bot whitelist on|off
 *
 * ✅ Whitelist: если включён, только перечисленные ники могут использовать /bot.
 * ✅ Multi-spawn: /bot spawn 3 спавнит 3 бота сразу (до maxBots).
 */
public class SpawnBotCommand {

    private static final Map<UUID, List<BotEntity>> playerBots = new HashMap<>();
    private static final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    /** Последний применённый кит — выдаётся новым ботам при спавне. */
    private static BotKit lastUsedKit = null;

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            registerCommands(dispatcher)
        );
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("bot")
            // /bot spawn [count] | /bot spawn <nick> [count]
            .then(Commands.literal("spawn")
                .executes(ctx -> spawnBotsWithSkin(ctx.getSource(), null, 1))
                .then(Commands.argument("count", IntegerArgumentType.integer(1, 25))
                    .executes(ctx -> spawnBotsWithSkin(ctx.getSource(), null,
                        IntegerArgumentType.getInteger(ctx, "count"))))
                // /bot spawn <nick>  — спавн со скином игрока
                .then(Commands.argument("nick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> spawnBotsWithSkin(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick"), 1))
                    .then(Commands.argument("count2", IntegerArgumentType.integer(1, 25))
                        .executes(ctx -> spawnBotsWithSkin(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick"),
                            IntegerArgumentType.getInteger(ctx, "count2"))))
                )
            )
            .then(Commands.literal("kill").executes(ctx -> killBots(ctx.getSource())))
            .then(Commands.literal("mode").executes(ctx -> cycleMode(ctx.getSource())))
            .then(Commands.literal("tp").executes(ctx -> tpBot(ctx.getSource())))
            .then(Commands.literal("help").executes(ctx -> help(ctx.getSource())))
            // /bot formation <follow|line|flank|surround>  (v10)
            .then(Commands.literal("formation")
                .then(Commands.literal("follow")  .executes(ctx -> setFormation(ctx.getSource(), "follow")))
                .then(Commands.literal("line")    .executes(ctx -> setFormation(ctx.getSource(), "line")))
                .then(Commands.literal("flank")   .executes(ctx -> setFormation(ctx.getSource(), "flank")))
                .then(Commands.literal("surround").executes(ctx -> setFormation(ctx.getSource(), "surround")))
            )
            // /bot regroup [teleport|pathfind|formation]  (v10)
            .then(Commands.literal("regroup")
                .executes(ctx -> regroupBots(ctx.getSource(), "pathfind"))
                .then(Commands.literal("teleport") .executes(ctx -> regroupBots(ctx.getSource(), "teleport")))
                .then(Commands.literal("pathfind") .executes(ctx -> regroupBots(ctx.getSource(), "pathfind")))
                .then(Commands.literal("formation").executes(ctx -> regroupBots(ctx.getSource(), "formation")))
            )
            // /bot equip smart  (v10) — умная экипировка
            .then(Commands.literal("equip")
                .executes(ctx -> equipBot(ctx.getSource()))
                .then(Commands.literal("smart").executes(ctx -> equipBotSmart(ctx.getSource())))
            )
            // ── v12: /bot clone ───────────────────────────────────
            .then(Commands.literal("clone")
                .executes(ctx -> cloneToggle(ctx.getSource()))
                .then(Commands.literal("on") .executes(ctx -> cloneSet(ctx.getSource(), true)))
                .then(Commands.literal("off").executes(ctx -> cloneSet(ctx.getSource(), false)))
            )
            // ── v12: /bot target <priority> ───────────────────────
            .then(Commands.literal("target")
                .then(Commands.literal("nearest")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.NEAREST)))
                .then(Commands.literal("lowhp")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.LOWEST_HP)))
                .then(Commands.literal("items")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.MOST_ITEMS)))
                .then(Commands.argument("forcedNick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> setForcedTarget(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "forcedNick"))))
            )
            // ── v12: /bot strafe <style> ──────────────────────────
            .then(Commands.literal("strafe")
                .then(Commands.literal("circle") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.CIRCLE)))
                .then(Commands.literal("random") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.RANDOM)))
                .then(Commands.literal("zigzag") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.ZIGZAG)))
                .then(Commands.literal("retreat").executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.RETREAT)))
            )
            // ── v12: /bot sync ────────────────────────────────────
            .then(Commands.literal("sync")
                // /bot sync attack [ник]
                .then(Commands.literal("attack")
                    .executes(ctx -> syncAttack(ctx.getSource(), null))
                    .then(Commands.argument("targetName",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> syncAttack(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "targetName"))))
                )
                // /bot sync stop
                .then(Commands.literal("stop")
                    .executes(ctx -> syncStop(ctx.getSource())))
                // /bot sync mode <focus|surround>
                .then(Commands.literal("mode")
                    .then(Commands.literal("focus")
                        .executes(ctx -> syncMode(ctx.getSource(), BotSyncAttack.SyncMode.FOCUS)))
                    .then(Commands.literal("surround")
                        .executes(ctx -> syncMode(ctx.getSource(), BotSyncAttack.SyncMode.SURROUND)))
                )
                // /bot sync auto <on|off>
                .then(Commands.literal("auto")
                    .then(Commands.literal("on")
                        .executes(ctx -> syncAuto(ctx.getSource(), true)))
                    .then(Commands.literal("off")
                        .executes(ctx -> syncAuto(ctx.getSource(), false)))
                )
                // /bot sync status
                .then(Commands.literal("status")
                    .executes(ctx -> syncStatus(ctx.getSource())))
            )
            // ── v12: /bot kit <name> ─────────────────────────────
            .then(Commands.literal("kit")
                .executes(ctx -> listKits(ctx.getSource()))
                .then(Commands.argument("kitName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> applyKit(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "kitName"))))
            )
            // ── v14: /bot pattern ────────────────────────────────
            .then(Commands.literal("pattern")
                .then(Commands.literal("on").executes(ctx -> {
                    PVPBotConfig.INSTANCE.patternAIEnabled = true;
                    PVPBotConfig.INSTANCE.antiPatternEnabled = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§aPatternAI §fвключён (обучение + антипаттерн)");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    PVPBotConfig.INSTANCE.patternAIEnabled = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7PatternAI выключен");
                    return 1;
                }))
            )
            // /bot difficulty <EASY|MEDIUM|HARD|EXPERT>
            .then(Commands.literal("difficulty")
                .then(Commands.literal("easy").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EASY)))
                .then(Commands.literal("medium").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.MEDIUM)))
                .then(Commands.literal("hard").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.HARD)))
                .then(Commands.literal("expert").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EXPERT)))
                .then(Commands.literal("status").executes(ctx ->
                    showDifficulty(ctx.getSource())))
            )
            // ── v14: /bot train [on|off] ──────────────────────────
            .then(Commands.literal("train")
                .executes(ctx -> trainStatus(ctx.getSource()))
                .then(Commands.literal("on").executes(ctx -> {
                    TrainingMode.INSTANCE.setActive(true);
                    PVPBotConfig.INSTANCE.trainingMode = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§a🎓 Обучающий режим §fвключён! Бот будет учить тебя PvP.");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    TrainingMode.INSTANCE.setActive(false);
                    PVPBotConfig.INSTANCE.trainingMode = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7Обучающий режим выключен.");
                    return 1;
                }))
            )
            // ── v14: /bot kitstats ────────────────────────────────
            .then(Commands.literal("kitstats")
                .executes(ctx -> showKitStats(ctx.getSource()))
                .then(Commands.literal("heatmap").executes(ctx -> showHeatmap(ctx.getSource())))
                .then(Commands.literal("reset").executes(ctx -> {
                    KitStatsTracker.INSTANCE.reset();
                    feedback(ctx.getSource(), "§eKitStats сброшены!");
                    return 1;
                }))
            )
            // /bot stats [reset]
            .then(Commands.literal("stats")
                .executes(ctx -> showStats(ctx.getSource()))
                .then(Commands.literal("reset").executes(ctx -> {
                    KillDeathTracker.reset();
                    feedback(ctx.getSource(), "§eСтатистика сброшена!");
                    return 1;
                }))
            )
            // /bot whitelist ...
            .then(Commands.literal("whitelist")
                .then(Commands.literal("on").executes(ctx -> {
                    cfg.whitelistEnabled = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§aWhitelist §fвключён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    cfg.whitelistEnabled = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7Whitelist §fвыключен");
                    return 1;
                }))
                .then(Commands.literal("add")
                    .then(Commands.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        if (!cfg.whitelist.contains(nick)) cfg.whitelist.add(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), "§a" + nick + " §fдобавлен в whitelist");
                        return 1;
                    }))
                )
                .then(Commands.literal("remove")
                    .then(Commands.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        cfg.whitelist.remove(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), "§c" + nick + " §fудалён из whitelist");
                        return 1;
                    }))
                )
                .then(Commands.literal("list").executes(ctx -> {
                    feedback(ctx.getSource(), "§eWhitelist (" + (cfg.whitelistEnabled ? "ВКЛ" : "ВЫКЛ") + "): §f"
                        + (cfg.whitelist.isEmpty() ? "(пусто)" : String.join(", ", cfg.whitelist)));
                    return 1;
                }))
            )
            // ── v8: /bot profile <name> ──────────────────────────────
            .then(Commands.literal("profile")
                .then(Commands.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                    boolean ok = ModuleManager.INSTANCE.loadProfile(name);
                    if (ok) {
                        BotConfig.save();
                        feedback(ctx.getSource(), "§aПрофиль §e" + name + " §aзагружен!");
                    } else {
                        feedback(ctx.getSource(), "§cПрофиль §e" + name + " §cне найден. Доступные: "
                            + String.join(", ", ModuleManager.INSTANCE.listProfiles()));
                    }
                    return ok ? 1 : 0;
                }))
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§eПрофили: §f"
                        + String.join(", ", ModuleManager.INSTANCE.listProfiles())
                        + "  §7Текущий: §e" + ModuleManager.INSTANCE.getActiveProfile());
                    return 1;
                })
            )
            // ── v8: /bot module <name> [on|off|toggle] ────────────
            .then(Commands.literal("module")
                .executes(ctx -> {
                    StringBuilder sb = new StringBuilder("§e§lМодули PVPBot v8:\n");
                    for (String mod : ModuleManager.INSTANCE.getModuleNames()) {
                        boolean en = ModuleManager.INSTANCE.isEnabled(mod);
                        sb.append(en ? "§a✔ " : "§c✘ ").append("§f").append(mod).append("\n");
                    }
                    if (ctx.getSource().getEntity() instanceof ServerPlayer p) {
                        p.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
                    }
                    return 1;
                })
                .then(Commands.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.ModuleState s = ModuleManager.INSTANCE.get(name);
                    if (s == null) {
                        feedback(ctx.getSource(), "§cМодуль §e" + name + " §cне найден.");
                        return 0;
                    }
                    feedback(ctx.getSource(), "§7Модуль §e" + name
                        + "§7: " + (s.enabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §8priority=" + s.priority);
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, true);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§a" + name + " §fвключён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, false);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§c" + name + " §fвыключён");
                    return 1;
                }))
                .then(Commands.literal("toggle").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.toggle(name);
                    boolean en = ModuleManager.INSTANCE.isEnabled(name);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§e" + name + " §f→ " + (en ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                }))
                )
            )
            // ── v11: /bot autolog [on|off|hp <val>] ──────────────
            .then(Commands.literal("autolog")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_AUTO_LOG))
                .then(Commands.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_LOG, true);
                    feedback(ctx.getSource(), "§aAutoLog §fвключён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_LOG, false);
                    feedback(ctx.getSource(), "§cAutoLog §fвыключён");
                    return 1;
                }))
                .then(Commands.literal("hp")
                    .then(Commands.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 20f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_LOG);
                        if (s != null) s.set("hp_threshold", (double) val);
                        feedback(ctx.getSource(), "§eAutoLog HP порог: §f" + val);
                        return 1;
                    }))
                )
            )
            // ── v11: /bot autopearl [on|off|mode <type>] ─────────
            .then(Commands.literal("autopearl")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_AUTO_PEARL))
                .then(Commands.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_PEARL, true);
                    feedback(ctx.getSource(), "§aAutoPearl §fвключён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_PEARL, false);
                    feedback(ctx.getSource(), "§cAutoPearl §fвыключён");
                    return 1;
                }))
                .then(Commands.literal("mode")
                    .then(Commands.literal("gap_close").executes(ctx -> {
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_PEARL);
                        if (s != null) s.set("mode", "gap_close");
                        feedback(ctx.getSource(), "§eAutoPearl режим: §fgap_close");
                        return 1;
                    }))
                    .then(Commands.literal("escape").executes(ctx -> {
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_PEARL);
                        if (s != null) s.set("mode", "escape");
                        feedback(ctx.getSource(), "§eAutoPearl режим: §fescape");
                        return 1;
                    }))
                )
            )
            // ── v1.3.1: /bot pearl [on|off] — жемчуг в SMP/Crystal китах ──
            // FIX: управление pearlEnabled — бот будет спринтовать вместо телепорта
            .then(Commands.literal("pearl")
                .executes(ctx -> {
                    boolean cur = PVPBotConfig.INSTANCE.pearlEnabled;
                    feedback(ctx.getSource(), "§ePearl (SMP/Crystal): §f" + (cur ? "§aвкл" : "§cвыкл"));
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    PVPBotConfig.INSTANCE.pearlEnabled = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§aPearl §fвключён — бот будет сближаться через жемчуг");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    PVPBotConfig.INSTANCE.pearlEnabled = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§cPearl §fвыключён — бот будет просто бежать к цели");
                    return 1;
                }))
            )
            // ── v11: /bot tracers [on|off|range <val>] ───────────
            .then(Commands.literal("tracers")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_TRACERS))
                .then(Commands.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_TRACERS, true);
                    feedback(ctx.getSource(), "§aTracers §fвключены");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_TRACERS, false);
                    feedback(ctx.getSource(), "§cTracers §fвыключены");
                    return 1;
                }))
                .then(Commands.literal("range")
                    .then(Commands.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(10f, 128f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_TRACERS);
                        if (s != null) s.set("range", (double) val);
                        feedback(ctx.getSource(), "§eTracers радиус: §f" + val);
                        return 1;
                    }))
                )
            )
            // ── v15: /bot owner add|remove|list ───────────────────
            .then(Commands.literal("owner")
                .then(Commands.literal("add")
                    .then(Commands.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        ServerPlayer p = ctx.getSource().getPlayer();
                        if (p == null) return 0;
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        boolean ok = MultiOwner.INSTANCE.addCoOwner(
                            p.getUUID(), nick, ctx.getSource().getServer());
                        feedback(ctx.getSource(), ok
                            ? "§a✔ §f" + nick + " §aтеперь совладелец ботов"
                            : "§c✘ Игрок §f" + nick + " §cне найден онлайн");
                        return ok ? 1 : 0;
                    }))
                )
                .then(Commands.literal("remove")
                    .then(Commands.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        ServerPlayer p = ctx.getSource().getPlayer();
                        if (p == null) return 0;
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        boolean ok = MultiOwner.INSTANCE.removeCoOwner(p.getUUID(), nick);
                        feedback(ctx.getSource(), ok
                            ? "§c✘ §f" + nick + " §cудалён из совладельцев"
                            : "§7" + nick + " не найден в совладельцах");
                        return ok ? 1 : 0;
                    }))
                )
                .then(Commands.literal("list").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    ServerPlayer p = ctx.getSource().getPlayer();
                    if (p == null) return 0;
                    var nicks = MultiOwner.INSTANCE.getCoOwnerNicks(p.getUUID());
                    feedback(ctx.getSource(), nicks.isEmpty()
                        ? "§7Совладельцев нет"
                        : "§6Совладельцы: §f" + String.join(", ", nicks));
                    return 1;
                }))
            )
            // ── v15: /bot webconfig [on|off|port <N>] ─────────────
            .then(Commands.literal("webconfig")
                .executes(ctx -> {
                    boolean run = WebConfig.INSTANCE.isRunning();
                    feedback(ctx.getSource(), "§6WebConfig: §f" + (run ? "§aОН" : "§cОФФ")
                        + (run ? " §7(http://localhost:" + WebConfig.INSTANCE.getPort() + ")" : ""));
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    int port = cfg.webConfigPort;
                    boolean ok = WebConfig.INSTANCE.start(port);
                    cfg.webConfigEnabled = ok;
                    feedback(ctx.getSource(), ok
                        ? "§aWebConfig запущен §7→ §fhttp://localhost:" + port
                        : "§cОшибка запуска WebConfig (порт занят?)");
                    return ok ? 1 : 0;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    WebConfig.INSTANCE.stop();
                    cfg.webConfigEnabled = false;
                    feedback(ctx.getSource(), "§cWebConfig остановлен");
                    return 1;
                }))
                .then(Commands.literal("port")
                    .then(Commands.argument("num", IntegerArgumentType.integer(1024, 65535))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int p = IntegerArgumentType.getInteger(ctx, "num");
                        cfg.webConfigPort = p;
                        feedback(ctx.getSource(), "§eWebConfig порт: §f" + p + " §7(перезапусти /bot webconfig on)");
                        return 1;
                    }))
                )
            )
            // ── v15: /bot bunker [on|off|hp <val>] ────────────────
            .then(Commands.literal("bunker")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6Bunker: §f" + (cfg.bunkerEnabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §7(HP≤" + cfg.bunkerHpThreshold + ")");
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    cfg.bunkerEnabled = true;
                    feedback(ctx.getSource(), "§a🧱 Bunker Mode включён (HP≤" + cfg.bunkerHpThreshold + ")");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    cfg.bunkerEnabled = false;
                    feedback(ctx.getSource(), "§c🧱 Bunker Mode выключен");
                    return 1;
                }))
                .then(Commands.literal("hp")
                    .then(Commands.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 39f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        cfg.bunkerHpThreshold = val;
                        feedback(ctx.getSource(), "§eBunker HP порог: §f" + val);
                        return 1;
                    }))
                )
            )

            // ── v16: /bot hunt [on|off|range <N>] ─────────────────
            .then(Commands.literal("hunt")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6Hunt: §f" + (cfg.huntEnabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §7(радиус " + (int) cfg.huntRange + "м)");
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    cfg.huntEnabled = true;
                    feedback(ctx.getSource(), "§a🎯 Hunt Mode включён (радиус " + (int) cfg.huntRange + "м)");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    cfg.huntEnabled = false;
                    feedback(ctx.getSource(), "§c🎯 Hunt Mode выключен");
                    return 1;
                }))
                .then(Commands.literal("range")
                    .then(Commands.argument("val",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(16, 512))
                    .executes(ctx -> {
                        int val = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "val");
                        cfg.huntRange = val;
                        feedback(ctx.getSource(), "§eHunt радиус: §f" + val + "м");
                        return 1;
                    }))
                )
            )

            // ── v1.3: /bot standby — боты стоят в ряд и ждут ────────
            .then(Commands.literal("standby")
                .executes(ctx -> setBotStandby(ctx.getSource(), true))
            )
            // ── v1.3: /bot attack [ник] — начать атаку ────────────
            .then(Commands.literal("attack")
                .executes(ctx -> setBotStandby(ctx.getSource(), false))
                .then(Commands.argument("targetName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> startAttackTarget(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "targetName")))
                )
            )

            // ── v16: /bot fake [on|off] ────────────────────────────
            .then(Commands.literal("fake")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6FakeAttack: §f" + (cfg.fakeAttackEnabled ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    cfg.fakeAttackEnabled = true;
                    feedback(ctx.getSource(), "§a🎭 Fake Attack включён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    cfg.fakeAttackEnabled = false;
                    feedback(ctx.getSource(), "§c🎭 Fake Attack выключен");
                    return 1;
                }))
            )

            // ── v16: /bot adaptive [on|off] ───────────────────────
            .then(Commands.literal("adaptive")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6AdaptiveCooldown: §f"
                        + (cfg.adaptiveCooldownEnabled ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    cfg.adaptiveCooldownEnabled = true;
                    feedback(ctx.getSource(), "§a⚡ Adaptive Cooldown включён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    cfg.adaptiveCooldownEnabled = false;
                    feedback(ctx.getSource(), "§c⚡ Adaptive Cooldown выключен");
                    return 1;
                }))
            )

            // ── v16: /bot replay ──────────────────────────────────
            .then(Commands.literal("replay")
                .executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    net.minecraft.server.level.ServerPlayer p = ctx.getSource().getPlayer();
                    if (p == null) return 0;
                    java.util.List<BotEntity> bots = getBots(ctx.getSource());
                    if (bots.isEmpty()) { feedback(ctx.getSource(), "§cНет ботов"); return 0; }
                    // Показываем replay первого бота
                    bots.get(0).getReplay().printReplayToPlayer(p);
                    return 1;
                })
            )

            // ── v16: /bot duel [start|stop|score|round] ───────────
            .then(Commands.literal("duel")
                .executes(ctx -> {
                    feedback(ctx.getSource(), DuelTimer.INSTANCE.getScoreText());
                    return 1;
                })
                .then(Commands.literal("start")
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        net.minecraft.server.level.ServerPlayer p = ctx.getSource().getPlayer();
                        String name = p != null ? p.getName().getString() : "Игрок";
                        UUID ownerUUID = p != null ? p.getUUID() : null;
                        DuelTimer.INSTANCE.start(10, ownerUUID, name);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §75 мин, 3 раунда");
                        return 1;
                    })
                    .then(Commands.argument("minutes",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 60))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int mins = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "minutes");
                        net.minecraft.server.level.ServerPlayer p = ctx.getSource().getPlayer();
                        String name = p != null ? p.getName().getString() : "Игрок";
                        UUID ownerUUID = p != null ? p.getUUID() : null;
                        DuelTimer.INSTANCE.start(10, ownerUUID, name);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §f" + mins + " мин, 3 раунда");
                        return 1;
                    }))
                )
                .then(Commands.literal("stop").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    DuelTimer.INSTANCE.stop(ctx.getSource().getServer());
                    return 1;
                }))
                .then(Commands.literal("score").executes(ctx -> {
                    feedback(ctx.getSource(), DuelTimer.INSTANCE.getScoreText());
                    return 1;
                }))
                .then(Commands.literal("round")
                    .then(Commands.argument("rounds",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 20))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int rounds = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "rounds");
                        var src = ctx.getSource();
                        String pName = src.getPlayerOrException().getName().getString();
                        java.util.UUID uid = src.getPlayerOrException().getUUID();
                        DuelTimer.INSTANCE.start(rounds, uid, pName);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §f" + rounds + " раундов (без таймера)");
                        return 1;
                    }))
                )
            )

            // ── v17: /bot squad ─────────────────────────────────
            .then(Commands.literal("squad")
                .executes(ctx -> squadInfo(ctx.getSource()))
                .then(Commands.literal("create")
                    .executes(ctx -> squadCreate(ctx.getSource(), "Squad-1"))
                    .then(Commands.argument("name",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> squadCreate(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
                )
                .then(Commands.literal("disband")
                    .executes(ctx -> {
                        if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
                        SquadManager.INSTANCE.disband(p);
                        feedback(ctx.getSource(), "§7Отряд расформирован.");
                        return 1;
                    })
                )
                .then(Commands.literal("commander")
                    .then(Commands.literal("attack")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.ATTACK)))
                    .then(Commands.literal("stand")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.STAND)))
                    .then(Commands.literal("retreat")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.RETREAT)))
                    .then(Commands.literal("flank")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.FLANK)))
                    // v2.0 — новые тактические приказы
                    .then(Commands.literal("surround")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.SURROUND)))
                    .then(Commands.literal("focus")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.FOCUS)))
                    .then(Commands.literal("heal")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.HEAL)))
                    .then(Commands.literal("cover")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.COVER)))
                    .then(Commands.literal("push")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.PUSH)))
                    .then(Commands.literal("bait")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.BAIT)))
                    .then(Commands.literal("split")
                        .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.SPLIT)))
                )
                .then(Commands.literal("info")
                    .executes(ctx -> squadInfo(ctx.getSource()))
                )
                // ── v7.0: новые команды отряда ───────────────────
                .then(Commands.literal("save")
                    .then(Commands.argument("name", com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> squadSave(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
                )
                .then(Commands.literal("load")
                    .then(Commands.argument("name", com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> squadLoad(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
                )
                .then(Commands.literal("presets")
                    .executes(ctx -> squadPresets(ctx.getSource()))
                )
                .then(Commands.literal("tp")
                    .executes(ctx -> squadTp(ctx.getSource()))
                )
                .then(Commands.literal("ambush")
                    .executes(ctx -> squadAmbush(ctx.getSource()))
                )
                .then(Commands.literal("wavedefense")
                    .then(Commands.literal("start")
                        .executes(ctx -> squadWaveDefense(ctx.getSource(), true)))
                    .then(Commands.literal("stop")
                        .executes(ctx -> squadWaveDefense(ctx.getSource(), false)))
                )
                // /bot squad role <ROLE> <0-100>  — настройка процента роли
                .then(Commands.literal("role")
                    .then(Commands.argument("role", com.mojang.brigadier.arguments.StringArgumentType.word())
                        .then(Commands.argument("value", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 100))
                            .executes(ctx -> squadSetRole(ctx.getSource(),
                                com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "role"),
                                com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "value")))))
                )
                .then(Commands.literal("roles")
                    .executes(ctx -> squadRolesInfo(ctx.getSource()))
                )
                .then(Commands.literal("rolesauto")
                    .executes(ctx -> { PVPBotConfig.INSTANCE.roleConfig.resetToAuto(); BotConfig.save();
                        feedback(ctx.getSource(), "§aРоли сброшены на авторежим."); return 1; })
                )
            )

            // ── v17: /bot learn [start|stop|reset|status] ────────
            .then(Commands.literal("learn")
                .executes(ctx -> { feedback(ctx.getSource(), BotLearning.INSTANCE.formatStatus()); return 1; })
                .then(Commands.literal("start")
                    .executes(ctx -> { BotLearning.INSTANCE.startRecording();
                        feedback(ctx.getSource(), "§a🎓 BotLearning: запись началась!"); return 1; }))
                .then(Commands.literal("stop")
                    .executes(ctx -> { BotLearning.INSTANCE.stopRecording();
                        feedback(ctx.getSource(), "§7BotLearning: остановлен. Паттернов: " + BotLearning.INSTANCE.getPatternCount()); return 1; }))
                .then(Commands.literal("reset")
                    .executes(ctx -> { BotLearning.INSTANCE.reset();
                        feedback(ctx.getSource(), "§eBotLearning сброшен."); return 1; }))
                .then(Commands.literal("status")
                    .executes(ctx -> { feedback(ctx.getSource(), BotLearning.INSTANCE.formatStatus()); return 1; }))
            )

            // ── v17: /bot gapple [on|off|hp|notch] ───────────────
            .then(Commands.literal("gapple")
                .executes(ctx -> { feedback(ctx.getSource(), GappleOptimizer.INSTANCE.formatStatus()); return 1; })
                .then(Commands.literal("on")
                    .executes(ctx -> { GappleOptimizer.INSTANCE.setEnabled(true);
                        feedback(ctx.getSource(), "§a🍎 GappleOptimizer включён"); return 1; }))
                .then(Commands.literal("off")
                    .executes(ctx -> { GappleOptimizer.INSTANCE.setEnabled(false);
                        feedback(ctx.getSource(), "§c🍎 GappleOptimizer выключен"); return 1; }))
                .then(Commands.literal("hp")
                    .then(Commands.argument("val", com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 39f))
                        .executes(ctx -> { GappleOptimizer.INSTANCE.defaultGappleHp =
                            com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                            feedback(ctx.getSource(), "§eГапл HP: §f" + GappleOptimizer.INSTANCE.defaultGappleHp); return 1; })))
                .then(Commands.literal("notch")
                    .then(Commands.argument("val", com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 15f))
                        .executes(ctx -> { GappleOptimizer.INSTANCE.notchAppleHp =
                            com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                            feedback(ctx.getSource(), "§eНотч HP: §f" + GappleOptimizer.INSTANCE.notchAppleHp); return 1; })))
            )

            // ── v17: /bot autodiff [on|off|status|reset] ─────────
            .then(Commands.literal("autodiff")
                .executes(ctx -> { feedback(ctx.getSource(), AdaptiveDifficulty.INSTANCE.formatStatus()); return 1; })
                .then(Commands.literal("on")
                    .executes(ctx -> { AdaptiveDifficulty.INSTANCE.setEnabled(true);
                        feedback(ctx.getSource(), "§a📊 AdaptiveDifficulty включён"); return 1; }))
                .then(Commands.literal("off")
                    .executes(ctx -> { AdaptiveDifficulty.INSTANCE.setEnabled(false);
                        feedback(ctx.getSource(), "§c📊 AdaptiveDifficulty выключен"); return 1; }))
                .then(Commands.literal("reset")
                    .executes(ctx -> { AdaptiveDifficulty.INSTANCE.reset();
                        feedback(ctx.getSource(), "§eAdaptiveDifficulty сброшен до MEDIUM"); return 1; }))
                .then(Commands.literal("status")
                    .executes(ctx -> { feedback(ctx.getSource(), AdaptiveDifficulty.INSTANCE.formatStatus()); return 1; }))
            )
        );
    }

    /** Выводит статус модуля в чат. */
    private static int moduleStatus(CommandSourceStack src, String modName) {
        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(modName);
        if (s == null) { feedback(src, "§cМодуль не найден: " + modName); return 0; }
        feedback(src, "§e" + modName + " §7→ " + (s.enabled ? "§aВКЛ" : "§cВЫКЛ")
            + " §8params=" + s.params);
        return 1;
    }

    // ── /bot spawn [skin] [count] ─────────────────────────────────
    private static int spawnBotsWithSkin(CommandSourceStack src, String skin, int count) {
        currentSkinNick = skin;
        int result = spawnBots(src, count);
        currentSkinNick = null;
        return result;
    }

    private static String currentSkinNick = null;

    // ── /bot spawn [count] ────────────────────────────────────────
    private static int spawnBots(CommandSourceStack src, int count) {
        if (!(src.getEntity() instanceof ServerPlayer player)) {
            src.sendFailure(Component.literal("Только игрок может спавнить бота!"));
            return 0;
        }
        if (!checkWhitelist(player, src)) return 0;

        var world = player.serverLevel();
        List<BotEntity> existing = getActiveBots(player);

        int canSpawn = Math.max(0, cfg.maxBots - existing.size());
        int toSpawn  = Math.min(count, canSpawn);

        if (toSpawn <= 0) {
            feedback(src, "§cДостигнут лимит ботов §e(" + cfg.maxBots + ")§f. §7/bot kill — удалить.");
            return 0;
        }

        for (int i = 0; i < toSpawn; i++) {
            BotEntity bot = BotEntityType.BOT_ENTITY.create(world, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
            if (bot == null) continue;

            // Спавним в кольце вокруг игрока с шагом угла
            double angle = Math.toRadians(player.getYRot() + 90 + i * (360.0 / toSpawn));
            double radius = 2.0 + i * 0.5;
            Vec3 pos = player.position().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            bot.moveTo(pos.x, pos.y, pos.z);
            bot.setOwner(player);
            if (currentSkinNick != null) bot.setSkinNick(currentSkinNick); // v9
            // Применяем последний кит если был задан, иначе дефолт
            if (lastUsedKit != null) {
                bot.setKit(lastUsedKit);
            } else {
                giveDefaultEquipment(bot);
            }
            world.addFreshEntity(bot);
            playerBots.computeIfAbsent(player.getUUID(), k -> new ArrayList<>()).add(bot);
            // v15: запоминаем глобального владельца (первый спавн)
            if (cfg.globalOwnerUUID == null) cfg.globalOwnerUUID = player.getUUID();
        }

        feedback(src, "§aЗаспавнено ботов: §e" + toSpawn
            + (toSpawn < count ? " §7(лимит: " + cfg.maxBots + ")" : "")
            + "§f. §7/bot help — команды");
        BotConfig.save(); // сохраняем состояние (whitelist, maxBots)
        return toSpawn;
    }

    // ── /bot kill ─────────────────────────────────────────────────
    private static int killBots(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = playerBots.getOrDefault(player.getUUID(), List.of());
        int count = 0;
        for (BotEntity bot : new ArrayList<>(bots)) {
            if (!bot.isRemoved()) { BotEntity.onBotRemoved(); bot.discard(); count++; }
        }
        playerBots.remove(player.getUUID());
        feedback(src, "§cУдалено ботов: §e" + count);
        return count;
    }

    // ── /bot mode ─────────────────────────────────────────────────
    private static int cycleMode(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов! §7/bot spawn"); return 0; }
        for (BotEntity bot : bots) bot.cycleMode();

        String modeColored = switch (bots.get(0).getBotMode()) {
            case GUARD      -> "§a⚔ GUARD §7(защищает владельца)";
            case AGGRESSIVE -> "§c🗡 AGGRESSIVE §7(атакует всех игроков)";
            case PASSIVE    -> "§7☮ PASSIVE §7(не атакует)";
            default     -> "?";
        };
        feedback(src, "§eРежим: " + modeColored);
        return 1;
    }

    // ── /bot tp ───────────────────────────────────────────────────
    private static int tpBot(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (int i = 0; i < bots.size(); i++) {
            bots.get(i).teleportTo(player.getX() + i, player.getY(), player.getZ());
        }
        feedback(src, "§aБоты телепортированы к тебе");
        return 1;
    }

    // ── /bot equip ────────────────────────────────────────────────
    private static int equipBot(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (BotEntity bot : bots) giveDefaultEquipment(bot);
        feedback(src, "§aБотам выдано снаряжение!");
        return 1;
    }

    // ── /bot stats ────────────────────────────────────────────────
    private static int showStats(CommandSourceStack src) {
        if (src.getEntity() instanceof ServerPlayer player) {
            double kd = KillDeathTracker.deaths == 0
                ? KillDeathTracker.kills
                : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
            player.sendSystemMessage(Component.literal(
                "§e§l⚔ PVP Bot — Статистика\n" +
                "§aУбийств:  §f" + KillDeathTracker.kills + "\n" +
                "§cСмертей:  §f" + KillDeathTracker.deaths + "\n" +
                "§eАссистов: §f" + KillDeathTracker.assists + "\n" +
                "§6K/D: §f" + String.format("%.2f", kd) + "\n" +
                "§7/bot stats reset — сброс"
            ));
        }
        return 1;
    }

    // ── /bot help ─────────────────────────────────────────────────
    private static int help(CommandSourceStack src) {
        if (src.getEntity() instanceof ServerPlayer player) {
            player.sendSystemMessage(Component.literal(
                "§e§l⚔ PVP Bot v11 — Команды\n" +
                "§f/bot spawn [ник] [N] §7— Заспавнить N ботов со скином ника\n" +
                "§f/bot kill        §7— Удалить ботов\n" +
                "§f/bot mode        §7— Сменить режим (GUARD/AGRO/PASSIVE)\n" +
                "§f/bot tp          §7— Телепортировать ботов к себе\n" +
                "§f/bot equip       §7— Выдать бронь и меч\n" +
                "§f/bot equip smart §7— Умная экипировка из инвентаря бота\n" +
                "§f/bot formation <follow|line|flank|surround> §7— Построение\n" +
                "§f/bot regroup [teleport|pathfind|formation] §7— Сбор ботов\n" +
                "§f/bot stats       §7— K/D статистика\n" +
                "§f/bot whitelist   §7— on|off|add <ник>|remove <ник>|list\n" +
                "§f/bot difficulty  §7— easy|medium|hard|expert|player|status\n" +
                "§f/bot profile [name] §7— загрузить профиль (pvp/pve/crystal/passive)\n" +
                "§f/bot module <name> [on|off|toggle] §7— управление модулями\n" +
                "§e§lv11 новое:\n" +
                "§f/bot autolog [on|off|hp <val>]              §7— выход при низком HP\n" +
                "§f/bot autopearl [on|off|mode <gap_close|escape>] §7— авто-перл\n" +
                "§f/bot tracers [on|off|range <val>]           §7— трассеры к сущностям\n" +
                "§e§lv12 новое:\n" +
                "§f/bot kit               §7— список китов (smp/uhc/nethpot/axe/tpc/sword/crystal)\n" +
                "§f/bot kit <название>    §7— применить кит + снаряжение + профиль AI\n" +
                "§e§lv12 синхроатака:\n" +
                "§f/bot sync attack [ник] §7— запустить синхроатаку\n" +
                "§f/bot sync stop         §7— остановить синхроатаку\n" +
                "§f/bot sync mode <focus|surround> §7— режим атаки\n" +
                "§f/bot sync auto <on|off> §7— авто-синхро\n" +
                "§f/bot sync status       §7— текущий статус\n" +
                "§e§lv12 новое (AI):\n" +
                "§f/bot clone [on|off]    §7— бот копирует твои атаки\n" +
                "§f/bot target <nearest|lowhp|items|ник> §7— приоритет цели\n" +
                "§f/bot strafe <circle|random|zigzag|retreat> §7— стиль уклонения\n" +
                "§e§lv14 новое:\n" +
                "§f/bot kit <beehive|firework|crossbow> §7— новые режимы\n" +
                "§f/bot train [on|off]         §7— обучающий режим (крит/w-tap)\n" +
                "§f/bot kitstats               §7— win/loss таблица по китам\n" +
                "§f/bot kitstats heatmap       §7— карта смертей бота\n" +
                "§f/bot kitstats reset         §7— сброс статистики\n" +
                "§f/bot pattern [on|off]       §7— AI обучение паттернам движения\n" +
                "§e§lv1.3 новое:\n" +
                "§f/bot standby               §7— боты выстраиваются в ряд и ЖДУТ\n" +
                "§f/bot attack [ник]          §7— дать команду атаковать\n" +
                "§f/bot kit obsidian_crystal  §7— кладёт обсидиан + взрывает кристаллы\n" +
                "§f/bot kit snowball          §7— снежки + меч\n" +
                "§f/bot kit shield_sword      §7— меч + щит\n" +
                "§7По умолчанию боты в STANDBY — не атакуют до /bot attack"
            ));
        }
        return 1;
    }

    private static boolean checkAccess(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return false;
        return checkWhitelist(player, src);
    }

    private static java.util.List<BotEntity> getBots(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return java.util.List.of();
        return getActiveBots(player);
    }

    // ── Whitelist проверка ─────────────────────────────────────────
    private static boolean checkWhitelist(ServerPlayer player, CommandSourceStack src) {
        if (!cfg.whitelistEnabled) return true;
        if (cfg.whitelist.contains(player.getName().getString())) return true;
        src.sendFailure(Component.literal("§c[PVPBot] §fВы не в whitelist!"));
        return false;
    }

    // ── Вспомогательные ───────────────────────────────────────────
    public static List<BotEntity> getBotsFor(net.minecraft.server.level.ServerPlayer player) { return getActiveBots(player); }

    private static List<BotEntity> getActiveBots(ServerPlayer player) {
        var list = playerBots.getOrDefault(player.getUUID(), List.of());
        var alive = new ArrayList<BotEntity>();
        for (BotEntity b : list) if (!b.isRemoved()) alive.add(b);
        playerBots.put(player.getUUID(), alive);
        return alive;
    }

    // ── v12: /bot clone ───────────────────────────────────────────

    private static int cloneToggle(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotClone.INSTANCE.toggle();
        feedback(src, "§aКлон-режим: " + (BotClone.INSTANCE.isActive() ? "§aВКЛ" : "§7ВЫКЛ"));
        return 1;
    }

    private static int cloneSet(CommandSourceStack src, boolean on) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotClone.INSTANCE.setActive(on);
        feedback(src, "§aКлон-режим: " + (on ? "§aВКЛ" : "§7ВЫКЛ")
            + " §7— бот " + (on ? "копирует твои атаки" : "действует самостоятельно"));
        return 1;
    }

    // ── v12: /bot target ──────────────────────────────────────────

    private static int setTargetPriority(CommandSourceStack src, TargetPriority.PriorityMode mode) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getTargetPriority().setMode(mode);
        String name = switch (mode) {
            case NEAREST   -> "§fБлижайший";
            case LOWEST_HP -> "§cМинимум HP";
            case MOST_ITEMS -> "§6Максимум лута";
            default        -> mode.name();
        };
        feedback(src, "§aПриоритет цели: " + name);
        return 1;
    }

    private static int setForcedTarget(CommandSourceStack src, String nick) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!(src.getLevel() instanceof net.minecraft.server.level.ServerLevel sw)) return 0;
        net.minecraft.world.entity.player.Player target = sw.getPlayers(
            p -> p.getName().getString().equalsIgnoreCase(nick)).stream().findFirst().orElse(null);
        if (target == null) { feedback(src, "§cИгрок не найден: §f" + nick); return 0; }
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getTargetPriority().setForcedTarget(target.getUUID());
        feedback(src, "§aПринудительная цель: §f" + nick);
        return 1;
    }

    // ── v12: /bot strafe ──────────────────────────────────────────

    private static int setStrafeStyle(CommandSourceStack src, StrafeAI.StrafeStyle style) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getStrafeAI().setStyle(style);
        String name = switch (style) {
            case CIRCLE  -> "§bКруговой";
            case RANDOM  -> "§eСлучайный";
            case ZIGZAG  -> "§aЗигзаг";
            case RETREAT -> "§6Hit-and-Run";
            default     -> "?";
        };
        feedback(src, "§aСтиль стрейфа: " + name);
        return 1;
    }

    // ── v12: /bot sync ────────────────────────────────────────────

    private static int syncAttack(CommandSourceStack src, String targetName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }

        // Найти цель по нику если указан
        net.minecraft.world.entity.LivingEntity target = null;
        if (targetName != null && !targetName.isEmpty() && player.serverLevel() != null) {
            net.minecraft.server.level.ServerLevel sw = player.serverLevel();
            target = sw.getPlayers(p -> p.getName().getString().equalsIgnoreCase(targetName))
                       .stream().findFirst().orElse(null);
            if (target == null) {
                feedback(src, "§cИгрок '§f" + targetName + "§c' не найден!");
                return 0;
            }
        }

        BotSyncAttack.INSTANCE.start(bots, target, player);
        return 1;
    }

    private static int syncStop(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotSyncAttack.INSTANCE.stop();
        feedback(src, "§7⚡ Синхроатака остановлена.");
        return 1;
    }

    private static int syncMode(CommandSourceStack src, BotSyncAttack.SyncMode mode) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotSyncAttack.INSTANCE.setMode(mode);
        String name = mode == BotSyncAttack.SyncMode.SURROUND ? "§6Окружение" : "§cФокус";
        feedback(src, "§aРежим синхроатаки: " + name);
        return 1;
    }

    private static int syncAuto(CommandSourceStack src, boolean on) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotSyncAttack.INSTANCE.setAutoSync(on);
        feedback(src, "§aАвто-синхро: " + (on ? "§aВКЛ" : "§7ВЫКЛ"));
        return 1;
    }

    private static int syncStatus(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        BotSyncAttack sync = BotSyncAttack.INSTANCE;
        String target = sync.getTarget() != null
            ? "§f" + sync.getTarget().getName().getString()
            : "§7нет";
        String mode = sync.getMode() == BotSyncAttack.SyncMode.SURROUND ? "§6Окружение" : "§cФокус";
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
            "§e§l⚡ Синхроатака — Статус\n" +
            "§7Активна:   " + (sync.isActive() ? "§aДА" : "§7НЕТ") + "\n" +
            "§7Режим:     " + mode + "\n" +
            "§7Цель:      " + target + "\n" +
            "§7Авто-синхро: " + (sync.isAutoSync() ? "§aВКЛ" : "§7ВЫКЛ")
        ));
        return 1;
    }

    // ── v12: /bot kit ─────────────────────────────────────────────

    /** Показать список доступных китов. */
    private static int listKits(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        StringBuilder sb = new StringBuilder("§e§l⚔ PVP Bot — Киты\n");
        for (BotKit kit : BotKit.values()) {
            sb.append("§f").append(kit.id).append(" §7— ").append(kit.displayName).append("\n");
        }
        sb.append("§7Использование: §f/bot kit <название>");
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    /** Применить кит: сменить снаряжение ботов + загрузить профиль модулей. */
    private static int applyKit(CommandSourceStack src, String kitId) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        BotKit kit = BotKit.byId(kitId);
        if (kit == null) {
            feedback(src, "§cНеизвестный кит '§f" + kitId + "§c'! Доступные: §f" + BotKit.listIds());
            return 0;
        }

        // Применить снаряжение всем ботам и сохранить кит
        var bots = getActiveBots(player);
        if (bots.isEmpty()) {
            feedback(src, "§cНет активных ботов!");
            return 0;
        }
        lastUsedKit = kit;
        for (BotEntity bot : bots) {
            bot.setKit(kit);
        }

        // FIX: Выдаём кит и ИГРОКУ в инвентарь
        kit.applyToPlayer(player);

        // Загрузить профиль модулей
        boolean profileLoaded = ModuleManager.INSTANCE.loadProfile(kit.profileName);
        BotConfig.save();

        feedback(src, "§a✔ Кит §f" + kit.id.toUpperCase() + " §a— §7" + kit.displayName
            + " §8(выдан боту и тебе)"
            + (profileLoaded ? " §8[профиль загружен]" : ""));
        return 1;
    }

    private static void giveDefaultEquipment(BotEntity bot) {
        bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND,
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERITE_SWORD));
        bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD,
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERITE_HELMET));
        bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST,
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERITE_CHESTPLATE));
        bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.LEGS,
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERITE_LEGGINGS));
        bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.FEET,
            new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.NETHERITE_BOOTS));
    }

    // ── /bot equip smart (v10) ────────────────────────────────────
    private static int equipBotSmart(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        if (!(src.getLevel() instanceof net.minecraft.server.level.ServerLevel sw)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (BotEntity bot : bots) SmartEquip.equip(bot, sw);
        feedback(src, "§aУмная экипировка применена!");
        return 1;
    }

    // ── /bot formation (v10) ──────────────────────────────────────
    private static int setFormation(CommandSourceStack src, String type) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        BotFormations.Formation f = BotFormations.fromString(type);
        BotFormations.INSTANCE.setCurrent(f);
        feedback(src, "§aПостроение: §f" + f.name());
        return 1;
    }

    // ── /bot regroup (v10) ────────────────────────────────────────
    private static int regroupBots(CommandSourceStack src, String modeStr) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        if (!(src.getLevel() instanceof net.minecraft.server.level.ServerLevel sw)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }

        BotRegroup.RegroupMode mode = BotRegroup.fromString(modeStr);
        int count = BotRegroup.INSTANCE.regroup(bots, player, mode, sw);
        feedback(src, "§aСбор! §f" + count + " бот(ов) → " + mode.name());
        return count;
    }

    // ── v1.3: /bot standby & /bot attack ────────────────────────

    private static int setBotStandby(CommandSourceStack src, boolean standby) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        PVPBotConfig.INSTANCE.standbyMode = standby;
        BotConfig.save();

        if (standby) {
            // Встаём в построение LINE
            BotFormations.INSTANCE.setCurrent(BotFormations.Formation.LINE);
            var bots = getActiveBots(player);
            for (BotEntity bot : bots) {
                bot.setTarget(null);
                bot.getNavigation().stop();
            }
            feedback(src, "§7⚔ Боты в режиме ожидания. Построение LINE. §f/bot attack — начать атаку.");
        } else {
            feedback(src, "§c⚔ Боты начинают атаку!");
        }
        return 1;
    }

    private static int startAttackTarget(CommandSourceStack src, String targetName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        if (!(src.getLevel() instanceof net.minecraft.server.level.ServerLevel sw)) return 0;

        net.minecraft.world.entity.player.Player target = sw.getPlayers(
            p -> p.getName().getString().equalsIgnoreCase(targetName)
        ).stream().findFirst().orElse(null);

        if (target == null) {
            feedback(src, "§cИгрок '§f" + targetName + "§c' не найден!");
            return 0;
        }

        PVPBotConfig.INSTANCE.standbyMode = false;
        BotConfig.save();

        // Назначить принудительную цель всем ботам
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) {
            bot.getTargetPriority().setForcedTarget(target.getUUID());
        }

        feedback(src, "§c⚔ Атака на §f" + targetName + "§c!");
        return 1;
    }

    private static void feedback(CommandSourceStack src, String msg) {
        if (src.getEntity() instanceof ServerPlayer p) {
            p.sendSystemMessage(Component.literal("§e[PVPBot] §f" + msg));
        }
    }

    // ── /bot difficulty ───────────────────────────────────────────
    private static int setDifficulty(CommandSourceStack src, PVPBotConfig.Difficulty diff) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        cfg.difficulty = diff;
        cfg.applyDifficulty();
        BotConfig.save();

        String label = switch (diff) {
            case EASY   -> "§7[EASY] §f— базовая атака, без перлов/кристаллов";
            case MEDIUM -> "§e[MEDIUM] §f— лук на дистанции, стрейф";
            case HARD   -> "§c[HARD] §f— перлы, улучшенный стрейф, крит-прыжки";
            case EXPERT -> "§4§l[EXPERT] §f— кристаллы, перлы, предсказание, комбо";
            case PLAYER -> "§a§l[PLAYER] §f— неотличим от игрока: блоки, промахи, без читов";
            default     -> "?";
        };
        feedback(src, "§eСложность бота: " + label);

        // Применяем к уже живым ботам
        var bots = getActiveBots(player);
        if (!bots.isEmpty()) {
            feedback(src, "§7Применено к §e" + bots.size() + " §7активным ботам.");
        }
        return 1;
    }

    private static int showDifficulty(CommandSourceStack src) {
        if (src.getEntity() instanceof ServerPlayer player) {
            PVPBotConfig.Difficulty d = cfg.difficulty;
            String label = switch (d) {
                case EASY   -> "§7EASY";
                case MEDIUM -> "§eMEDIUM";
                case HARD   -> "§cHARD";
                case EXPERT -> "§4§lEXPERT";
                case PLAYER -> "§a§lPLAYER";
            default     -> "?";
            };
            player.sendSystemMessage(Component.literal(
                "§e§l⚔ PVP Bot — Сложность бота\n" +
                "§fТекущий уровень: " + label + "\n\n" +
                "§7EASY   §f— атака, без перлов/кристаллов\n" +
                "§7MEDIUM §f— + лук на дистанции\n" +
                "§7HARD   §f— + перлы (рывок/отрыв)\n" +
                "§7EXPERT §f— + кристаллы, предсказание, комбо\n" +
                "§aПЛАЙЕР §f— неотличим от игрока: ставит блоки, без читов\n\n" +
                "§7Параметры: pearls=" + cfg.diffUsePearls +
                " crystals=" + cfg.diffUseCrystals +
                " bowRange=" + cfg.diffBowSwitchRange
            ));
        }
        return 1;
    }


    // ── v14: /bot train status ───────────────────────────────────
    private static int trainStatus(CommandSourceStack src) {
        boolean on = TrainingMode.INSTANCE.isActive();
        feedback(src, "§e🎓 Обучающий режим: " + (on ? "§aВКЛ" : "§7ВЫКЛ")
            + "\n§7/bot train on|off — управление");
        return 1;
    }

    // ── v14: /bot kitstats ────────────────────────────────────────
    private static int showKitStats(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(KitStatsTracker.INSTANCE.formatTable()));
        return 1;
    }

    private static int showHeatmap(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(KitStatsTracker.INSTANCE.formatHeatmap()));
        return 1;
    }



    // ── v17: /bot squad ──────────────────────────────────────────

    private static int squadCreate(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        List<BotEntity> bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет ботов для отряда! §7/bot spawn сначала."); return 0; }
        SquadManager.INSTANCE.assignBots(player, bots);
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        StringBuilder msg = new StringBuilder("§a⚔ Отряд §e" + name + " §aсоздан!\n");
        msg.append("§f§l[Командир] §c").append(squad.commander != null ? "Бот #1" : "нет")
           .append(" §7+ §f").append(squad.soldiers.size()).append(" §7бойцов\n");
        if (squad.size() >= 20) {
            long elites  = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.ELITE).count();
            long medics  = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.MEDIC).count();
            long tankers = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.TANKER).count();
            msg.append("§6§lЭлиты (топор): §f").append(elites)
               .append("  §c§lТанкеры: §f").append(tankers)
               .append("  §a§lМедики: §f").append(medics).append("\n");
            msg.append("§7Медики бафают: §aСила II §7/ §aЛечение II §7/ §aОгнестойкость §7/ §aСкорость II");
        } else {
            msg.append("§7Командир стоит ВПЕРЕДИ, солдаты в шеренге позади.\n");
            msg.append("§7(При отряде ≥ 20 бойцов — авто-роли: Элита/Медик/Танкер)");
        }
        feedback(src, msg.toString());
        return 1;
    }

    private static int squadInfo(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) {
            feedback(src, "§7Нет отряда. §f/bot squad create §7— создать.");
            return 0;
        }
        StringBuilder sb = new StringBuilder("§e§l⚔ Отряд — Статус\n");
        sb.append("§7Всего ботов: §f").append(squad.size()).append("\n");
        sb.append("§7Приказ:      §f").append(squad.currentOrder.name()).append("\n");
        // Роли
        if (squad.size() >= 5) {
            java.util.Map<BotRole, Long> roleCounts = new java.util.LinkedHashMap<>();
            for (BotRole r : BotRole.values()) roleCounts.put(r, 0L);
            for (BotEntity b : squad.soldiers) {
                BotRole r = b.getSquadRole() != null ? b.getSquadRole() : BotRole.SOLDIER;
                roleCounts.merge(r, 1L, Long::sum);
            }
            sb.append("§7Роли: ");
            for (BotRole r : BotRole.values()) {
                long cnt = roleCounts.getOrDefault(r, 0L);
                if (cnt > 0) sb.append(r.displayName).append("§f×").append(cnt).append(" ");
            }
            sb.append("\n");
            // Потери из CasualtyTracker
            CasualtyTracker.BattleRecord rec = CasualtyTracker.INSTANCE.getCurrent();
            if (rec != null) {
                sb.append("§c☠ Потери: §f").append(rec.casualties).append(" из §f").append(rec.initialSize).append("\n");
            }
        }
        if (squad.commander != null) {
            sb.append("§c[Командир] §fHP:").append((int)squad.commander.getHealth())
              .append(" Цель:").append(squad.commander.getTarget() != null ? squad.commander.getTarget().getName().getString() : "нет").append("\n");
        }
        for (int i = 0; i < squad.soldiers.size(); i++) {
            BotEntity s = squad.soldiers.get(i);
            String roleTag = squad.size() >= 20 ? s.getSquadRole().displayName + " " : "§7";
            sb.append(roleTag).append("§f#").append(i+1)
              .append(" HP:").append((int)s.getHealth())
              .append(s.isAlive() ? "" : " §cМЁРТВ").append("\n");
        }
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    private static int squadOrder(CommandSourceStack src, SquadManager.CommanderOrder order) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) {
            feedback(src, "§cНет отряда! §f/bot squad create");
            return 0;
        }
        SquadManager.INSTANCE.issueOrder(player, order);
        feedback(src, "§aПриказ командиру: §f" + order.name());
        return 1;
    }


    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — Новые команды отряда
    // ═══════════════════════════════════════════════════════════════

    /** /bot squad save <name> */
    private static int squadSave(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "§cНет отряда для сохранения."); return 0; }
        boolean isNew = SquadPreset.INSTANCE.save(name, squad, PVPBotConfig.INSTANCE);
        BotConfig.save();
        feedback(src, (isNew ? "§aСохранён новый пресет: §f" : "§eПерезаписан пресет: §f") + name
            + " §7(" + squad.size() + " бойцов, " + PVPBotConfig.INSTANCE.mode + ")");
        return 1;
    }

    /** /bot squad load <name> */
    private static int squadLoad(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadPreset.SquadSnapshot snap = SquadPreset.INSTANCE.load(name, PVPBotConfig.INSTANCE);
        if (snap == null) {
            feedback(src, "§cПресет §f" + name + " §cне найден. §7Список: §f/bot squad presets");
            return 0;
        }
        BotConfig.save();
        feedback(src, "§aПресет §f" + snap.name + " §aзагружен! §7"
            + snap.size + " бойцов, кит §f" + snap.kitMode
            + "§7. Запустите §f/bot spawn " + snap.size + " §7→ §f/bot squad create");
        return 1;
    }

    /** /bot squad presets */
    private static int squadPresets(CommandSourceStack src) {
        java.util.Set<String> names = SquadPreset.INSTANCE.listNames();
        if (names.isEmpty()) {
            feedback(src, "§7Сохранённых пресетов нет. §f/bot squad save <имя> §7— сохранить.");
            return 1;
        }
        StringBuilder sb = new StringBuilder("§e§l⚔ Сохранённые пресеты:\n");
        for (String n : names) {
            SquadPreset.SquadSnapshot s = SquadPreset.INSTANCE.get(n);
            sb.append("  §f").append(s.summary()).append("\n");
        }
        if (src.getEntity() instanceof ServerPlayer player)
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    /** /bot squad tp — телепортировать весь отряд к себе */
    private static int squadTp(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "§cНет отряда."); return 0; }
        int count = 0;
        net.minecraft.world.phys.Vec3 pos = player.position();
        for (BotEntity bot : squad.allBots()) {
            if (bot.isAlive()) {
                bot.teleportTo(pos.x + (Math.random() * 4 - 2), pos.y, pos.z + (Math.random() * 4 - 2));
                count++;
            }
        }
        feedback(src, "§aТелепортировано §f" + count + " §aбойцов к вам.");
        return 1;
    }

    /** /bot squad ambush — режим засады */
    private static int squadAmbush(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "§cНет отряда."); return 0; }
        if (CommanderAI.INSTANCE.isAmbushMode()) {
            CommanderAI.INSTANCE.disableAmbush(squad);
            feedback(src, "§eЗасада отменена. Отряд атакует.");
        } else {
            CommanderAI.INSTANCE.enableAmbush(squad, player);
        }
        BotConfig.save();
        return 1;
    }

    /** /bot squad wavedefense start|stop */
    private static int squadWaveDefense(CommandSourceStack src, boolean start) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (start) {
            if (squad == null) { feedback(src, "§cСначала создайте отряд: §f/bot squad create"); return 0; }
            WaveDefense.INSTANCE.start(player, squad);
            PVPBotConfig.INSTANCE.waveDefenseActive = true;
            BotConfig.save();
        } else {
            WaveDefense.INSTANCE.stop(player);
            PVPBotConfig.INSTANCE.waveDefenseActive = false;
            BotConfig.save();
        }
        return 1;
    }

    /**
     * /bot squad role <ROLE> <0-100>
     * Задаёт процент бойцов данной роли.
     * 0 = отключить роль, 100 = все бойцы этой роли.
     * Пример: /bot squad role MEDIC 20  →  20% медиков
     *         /bot squad role MEDIC 0   →  ни одного медика
     */
    private static int squadSetRole(CommandSourceStack src, String roleName, int value) {
        BotRole role;
        try {
            role = BotRole.valueOf(roleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            feedback(src, "§cНеизвестная роль: §f" + roleName
                + "§7. Доступны: §f" + java.util.Arrays.toString(BotRole.values()));
            return 0;
        }
        PVPBotConfig.INSTANCE.roleConfig.usePercent = true;
        PVPBotConfig.INSTANCE.roleConfig.roleCounts.put(role, value);
        BotConfig.save();
        String msg = value == 0
            ? "§7Роль §f" + role.displayName + " §7отключена (0%)."
            : "§aРоль §f" + role.displayName + " §a→ §f" + value + "%";
        feedback(src, msg + " §7(вступит в силу при следующем §f/bot squad create§7)");
        return 1;
    }

    /** /bot squad roles — показать текущий конфиг ролей */
    private static int squadRolesInfo(CommandSourceStack src) {
        BotRole.RoleConfig cfg = PVPBotConfig.INSTANCE.roleConfig;
        StringBuilder sb = new StringBuilder("§e§l⚔ Конфиг ролей "
            + (cfg.usePercent ? "§7(% от отряда)" : "§7(штуки)") + "\n");
        for (BotRole r : BotRole.values()) {
            Integer v = cfg.roleCounts.get(r);
            String val = (v == null || v == -1) ? "§7авто" : (v == 0 ? "§cвыкл" : "§a" + v + (cfg.usePercent ? "%" : "шт"));
            sb.append("  ").append(r.displayName).append(" §f→ ").append(val).append("\n");
        }
        sb.append("§7Команда: §f/bot squad role <РОЛЬ> <0-100>\n");
        sb.append("§7Сброс на авто: §f/bot squad rolesauto");
        if (src.getEntity() instanceof ServerPlayer player)
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

}