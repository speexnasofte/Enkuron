package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;

/**
 * SmpLogic v6.0 — УЛУЧШЕНО
 *
 * Исправления v6:
 *   - WTapLogic серверный вместо wTapPause самописного (унифицировано)
 *   - tickBlocking: Navigation вместо setDeltaMovement при отходе
 *   - tickRetreating: zigzag-уклонение (не прямолинейное бегство)
 *   - ATTACK_CD: 10 → 8 (чуть агрессивнее)
 *   - CRIT_EVERY: 3 → 3 (без изменений, уже хорошо)
 *   - GAP_CD: 200 → 180 (немного чаще)
 *   - doAxeHit: добавляем WTap после удара топором
 *   - tickFighting: navigation при dist < IDEAL_DIST теперь через Navigation.stop() не velocity
 *   - state BLOCKING: уходит в FIGHTING быстрее если щит у цели сломан
 */
public class SmpLogic {

    private static final double MELEE_RANGE  = 3.0;
    private static final double AXE_RANGE    = 3.5;
    private static final double BOW_RANGE    = 8.0;
    private static final double PEARL_RANGE  = 11.0;
    private static final double IDEAL_DIST   = 2.4;

    private static final float  GAP_HP       = 12.0f;
    private static final float  SHIELD_HP    = 14.0f;
    private static final float  RETREAT_HP   = 5.0f;

    private static final int    ATTACK_CD    = 8;    // FIX: было 10
    private static final int    AXE_CD       = 20;
    private static final int    BOW_CD       = 18;
    private static final int    SHIELD_DUR   = 18;   // FIX: было 20
    private static final int    GAP_CD       = 180;  // FIX: было 200
    private static final int    PEARL_CD     = 80;
    private static final int    SPEED_CD     = 400;
    private static final int    STR_CD       = 400;
    private static final int    FIRE_RES_CD  = 600;
    private static final int    RETREAT_CD   = 100;
    private static final int    CRIT_EVERY   = 3;
    private static final int    COMBO_AXE_AT = 3;

    private enum State { FIGHTING, BLOCKING, RETREATING }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;  // FIX: серверный W-tap
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd     = 0;
    private int axeCd        = 0;
    private int bowCd        = 0;
    private int shieldTimer  = 0;
    private int gapCd        = 0;
    private int pearlCd      = 0;
    private int speedCd      = 0;
    private int strCd        = 0;
    private int fireResCd    = 0;
    private int retreatCd    = 0;
    private int hitCount     = 0;
    private int comboCount   = 0;
    private boolean critPending    = false;
    private boolean shieldDisabled = false;
    private int shieldDisTimer     = 0;
    private int zigzagTimer        = 0;
    private boolean zigzagLeft     = true;

    // Отслеживаем урон для умного retreat
    private float lastReceivedDamage = 0;
    private int   lastDamageTick     = 0;
    private int   tickCount          = 0;

    public SmpLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void onDamageReceived(float amount) {
        lastReceivedDamage = amount;
        lastDamageTick     = tickCount;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        tickCount++;

        if (attackCd     > 0) attackCd--;
        if (axeCd        > 0) axeCd--;
        if (bowCd        > 0) bowCd--;
        if (shieldTimer  > 0) shieldTimer--;
        if (gapCd        > 0) gapCd--;
        if (pearlCd      > 0) pearlCd--;
        if (speedCd      > 0) speedCd--;
        if (strCd        > 0) strCd--;
        if (fireResCd    > 0) fireResCd--;
        if (retreatCd    > 0) retreatCd--;
        if (zigzagTimer  > 0) zigzagTimer--;
        if (shieldDisTimer > 0) { shieldDisTimer--; if (shieldDisTimer <= 0) shieldDisabled = false; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // Тотем в оффхенд ВСЕГДА
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // Баффы
        if (speedCd <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); speedCd = SPEED_CD; }
        if (strCd   <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,   800, 1)); strCd   = STR_CD; }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }

        // Golden Apple при низком HP
        if (myHp < GAP_HP && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
            if (state == State.RETREATING) state = State.FIGHTING;
        }

        // Эндер жемчуг для сближения
        if (cfg.pearlEnabled && dist > PEARL_RANGE && pearlCd <= 0) {
            bot.setSprinting(true);
            bot.getNavigation().moveTo(target, 1.6);
            if (bot.level() instanceof ServerLevel swp)
                swp.sendParticles(ParticleTypes.PORTAL,
                    bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
            return;
        }

        // Переходы состояний
        boolean recentlyDamaged = (tickCount - lastDamageTick) < 40;
        if (myHp < RETREAT_HP && retreatCd <= 0 && recentlyDamaged) {
            state     = State.RETREATING;
            retreatCd = RETREAT_CD;
            zigzagLeft = bot.level().getRandom().nextBoolean();
        }
        if (myHp < SHIELD_HP && myHp >= RETREAT_HP && shieldTimer <= 0 && state == State.FIGHTING) {
            state      = State.BLOCKING;
            shieldTimer = SHIELD_DUR;
            strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        }
        if (state == State.BLOCKING && (shieldTimer <= 0 || shieldDisabled)) {
            state = State.FIGHTING;
            strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
        }
        if (state == State.RETREATING && (dist > 9.0 || myHp > SHIELD_HP)) {
            state = State.FIGHTING;
        }

        switch (state) {
            case FIGHTING   -> tickFighting(sw, target, dist);
            case BLOCKING   -> tickBlocking(sw, target);
            case RETREATING -> tickRetreating(target);
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        boolean wTapActive = wTap.tick(target);

        if (!wTapActive) {
            if (dist > IDEAL_DIST + 0.8)       bot.getNavigation().moveTo(target, 1.05);
            else if (dist < IDEAL_DIST - 0.4)  bot.getNavigation().stop(); // FIX: Navigation не velocity
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (!wTapActive && dist < MELEE_RANGE + 2.0 && cfg.strafeEnabled) strafe.tick(target);

        boolean blocking = isTargetBlocking(target);

        // Лук на дальней дистанции
        if (dist > BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW, bot.level().registryAccess()).enchant("power", 5).enchant("infinity", 1).build());
            bot.getLookControl().setLookAt(target, 60f, 60f);
            float bowDmg = (float) Math.max(2.0, 9.5 - dist * 0.25);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), bowDmg);
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
            HitHighlightTracker.INSTANCE.onHit(target.getId());
            bowCd = BOW_CD;
            return;
        }

        // Combo: топор после COMBO_AXE_AT ударов мечом
        if (comboCount >= COMBO_AXE_AT && dist <= AXE_RANGE && axeCd <= 0 && !wTapActive) {
            doAxeHit(sw, target);
            comboCount = 0;
            return;
        }

        // Топор для слома щита
        if (blocking && dist <= AXE_RANGE && axeCd <= 0 && !wTapActive) {
            doAxeHit(sw, target);
            return;
        }

        // Меч DPS
        if (dist <= MELEE_RANGE && attackCd <= 0 && !wTapActive) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doSwordHit(sw, target, true);
                critPending = false;
            } else if (!doCrit) {
                doSwordHit(sw, target, false);
                critPending = false;
            }
        }
    }

    private void doSwordHit(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("knockback", 1).enchant("fire_aspect", 2).build());
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (target.getRemainingFireTicks() <= 0) target.setRemainingFireTicks(80);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+0.8, target.getZ(), 6, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        comboCount++;
        attackCd = cfg.adaptiveCooldownEnabled ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
        if (cfg.wTapEnabled) wTap.onAttack(); // FIX: серверный W-tap
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("efficiency", 5).build());
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        shieldDisabled = true;
        shieldDisTimer = 100;
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        axeCd = AXE_CD;
        if (cfg.wTapEnabled) wTap.onAttack(); // FIX: W-tap после топора тоже
    }

    private void tickBlocking(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.SHIELD));
        double dist = bot.distanceTo(target);
        // FIX: Navigation.stop() вместо setDeltaMovement при близкой цели
        if (dist < 2.5) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(bot.getX() + away.x * 3, bot.getY(), bot.getZ() + away.z * 3, 1.1);
        }
        if (cfg.strafeEnabled) strafe.tick(target);
    }

    private void tickRetreating(LivingEntity target) {
        // FIX: zigzag-уклонение при побеге
        if (zigzagTimer <= 0) {
            zigzagLeft  = !zigzagLeft;
            zigzagTimer = 5 + bot.level().getRandom().nextInt(6);
        }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side = zigzagLeft
            ? new Vec3(-away.z, 0, away.x).scale(0.45)
            : new Vec3(away.z, 0, -away.x).scale(0.45);
        Vec3 dest = bot.position().add(away.scale(9)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.25);
        bot.setSprinting(true);
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }
}
