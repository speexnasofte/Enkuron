package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;

/**
 * WTapLogic v2.0 — СЕРВЕРНЫЙ W-tap (не клиентский KeyMapping!)
 *
 * Исправления v2:
 *   - Убрана вся KeyMapping-рефлексия (не работала на сервере)
 *   - Реализовано через setSprinting() + Navigation.stop() + таймер
 *   - S-tap: микропауза движения после удара (снижает входящий KB)
 *   - Работает для server-side NPC бота
 *
 * Механика:
 *   После удара: бот останавливается на WTAP_TICKS тиков (сброс скорости),
 *   затем продолжает движение. Это сбрасывает momentum и позволяет
 *   следующему удару иметь выгодный угол для критической атаки.
 */
public class WTapLogic {

    private static final int WTAP_STOP_TICKS = 2; // тиков паузы после удара
    private static final int STAP_TICKS      = 1; // тиков паузы S-tap

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final BotEntity bot;

    private int stopTimer = 0;
    private boolean wasActive = false;

    public WTapLogic(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Вызывать ПОСЛЕ успешного удара.
     * Останавливает бота на несколько тиков (W-tap).
     */
    public void onAttack() {
        if (!cfg.wTapEnabled) return;
        stopTimer = cfg.sTapEnabled ? WTAP_STOP_TICKS + STAP_TICKS : WTAP_STOP_TICKS;
        bot.setSprinting(false);
        bot.getNavigation().stop();
        wasActive = true;
    }

    /**
     * Тик W-tap. Возвращает true если W-tap активен сейчас
     * (навигация заблокирована).
     */
    public boolean tick(LivingEntity target) {
        if (!cfg.wTapEnabled || stopTimer <= 0) {
            if (wasActive && target != null && target.isAlive()) {
                // Возобновляем движение
                bot.getNavigation().moveTo(target, 1.1);
                bot.setSprinting(true);
                wasActive = false;
            }
            return false;
        }
        stopTimer--;
        // Держим навигацию остановленной
        bot.getNavigation().stop();
        return true;
    }

    public boolean isActive() { return stopTimer > 0; }

    public void reset() {
        stopTimer = 0;
        wasActive = false;
    }
}
