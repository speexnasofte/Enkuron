package com.pvpbot.gui.tab;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Рендерер вкладки HISTORY — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class HistoryTabRenderer {

    private HistoryTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // ── Секция 1: История отрядных боёв ──────────────────────
        g.drawString(font, "BATTLE HISTORY (Отряд)", sx, sy, ACCENT_BLUE); sy += 14;

        java.util.List<CasualtyTracker.BattleRecord> history = CasualtyTracker.INSTANCE.getHistory();
        if (history.isEmpty()) {
            g.drawString(font, "Ещё не было отрядных боёв.", sx, sy, TEXT_GRAY);
            sy += 12;
        } else {
            g.drawString(font, "Дата         Кит        Бойцов  Потери  Итог", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;
            int shown = Math.min(history.size(), 6);
            for (int i = 0; i < shown; i++) {
                CasualtyTracker.BattleRecord rec = history.get(i);
                if (i % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);
                int rc = rec.victory ? ACCENT_GREEN : ACCENT_RED;
                g.drawString(font, rec.dateStr(),                          sx,       sy, TEXT_GRAY);
                g.drawString(font, padRight(rec.squadKit, 10),             sx + 72,  sy, ACCENT_YEL);
                g.drawString(font, padLeft(String.valueOf(rec.initialSize), 4), sx + 148, sy, TEXT_BRIGHT);
                g.drawString(font, padLeft(String.valueOf(rec.casualties),  4), sx + 184, sy, ACCENT_RED);
                g.drawString(font, rec.victory ? "Победа" : "Пораж.",      sx + 220, sy, rc);
                sy += 12;
            }
            if (history.size() > 6)
                g.drawString(font, "...ещё " + (history.size() - 6), sx, sy, TEXT_DARK);
            sy += 14;
        }

        // ── Секция 2: История личных боёв (FightAnalyzer) ─────────
        g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 6;
        g.drawString(font, "FIGHT LOG (Личный бой)", sx, sy, ACCENT_CYAN); sy += 14;

        java.util.List<FightAnalyzer.FightRecord> fights = FightAnalyzer.INSTANCE.getHistory();
        if (fights.isEmpty()) {
            g.drawString(font, "Ещё не было боёв. Убей цель для записи.", sx, sy, TEXT_GRAY);
        } else {
            // Шапка
            g.drawString(font, "Игрок           Точн%  Урон ↑  Урон ↓  DPS    Время", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;

            for (int i = 0; i < Math.min(fights.size(), 8); i++) {
                FightAnalyzer.FightRecord r = fights.get(i);
                if (sy > winY + WIN_H - FOOT_H - 14) break;
                if (i % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);

                // Полоска победы
                int wc = r.won ? 0xFF00CC44 : 0xFF888888;
                fr(g, sx - 4, sy, 2, 10, wc);

                String name = r.target.length() > 14 ? r.target.substring(0, 13) + "…" : r.target;
                g.drawString(font, padRight(name, 15),                         sx,       sy, r.won ? TEXT_WHITE : TEXT_GRAY);
                g.drawString(font, padLeft(r.accuracy() + "%", 5),             sx + 120, sy, ACCENT_GREEN);
                g.drawString(font, padLeft(String.format("%.0f", r.totalDamage), 6), sx + 162, sy, ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f", r.damageTaken), 6), sx + 200, sy, 0xFFFF8844);
                g.drawString(font, padLeft(String.format("%.1f", r.avgDps), 5), sx + 238, sy, ACCENT_YEL);
                g.drawString(font, String.format("%.1fs", r.durationSec),      sx + 278, sy, TEXT_GRAY);
                sy += 12;
            }

            // Кнопка очистить историю
            sy += 4;
            boolean hovClr = mx >= sx && mx < sx + 100 && my >= sy && my < sy + 14;
            float aClr = AnimationUtil.tick("clr_fights", hovClr ? 1f : 0f, 0.2f);
            fr(g, sx, sy, 100, 14, AnimationUtil.lerpColor(BG_CARD, 0x20EF4444, aClr));
            bd(g, sx, sy, 100, 14, AnimationUtil.lerpColor(BORDER_CARD, 0xFFEF4444, aClr));
            g.drawString(font, "🗑 Очистить историю", sx + 4, sy + 3,
                AnimationUtil.lerpColor(TEXT_GRAY, 0xFFEF4444, aClr));
        }

        // ── Текущий бой (если идёт) ──────────────────────────────
        CasualtyTracker.BattleRecord cur = CasualtyTracker.INSTANCE.getCurrent();
        if (cur != null) {
            int panY = winY + WIN_H - FOOT_H - 54;
            fr(g, sx - 2, panY, cw - 16, 20, 0xFF0C1A0C);
            bd(g, sx - 2, panY, cw - 16, 20, ACCENT_GREEN);
            g.drawString(font,
                "⚔ Бой идёт: " + cur.squadKit
                + "  Бойцов: " + cur.initialSize
                + "  Потери: " + cur.casualties,
                sx + 2, panY + 6, ACCENT_GREEN);
        }

        // ── Секция 3: BotReplay (последние 5 сек боя) ───────────
        int replayPanY = winY + WIN_H - FOOT_H - 28;
        g.fill(sx, replayPanY - 8, cx + cw - 10, replayPanY - 7, BORDER_SEP);
        g.drawString(font, "⏱ REPLAY (последние 5с)", sx, replayPanY - 6, ACCENT_YEL);

        java.util.List<String> replayLines = new java.util.ArrayList<>(BotReplay.CLIENT_SUMMARY);
        if (replayLines.isEmpty()) {
            g.drawString(font, "Нет данных — нужен активный бой", sx, replayPanY + 4, TEXT_GRAY);
        } else {
            // Рисуем компактную полоску событий
            int rx = sx;
            for (String line : replayLines) {
                // Цвет по действию
                int lc = TEXT_GRAY;
                if (line.contains("ATTACK"))  lc = ACCENT_RED;
                else if (line.contains("DODGE"))   lc = ACCENT_CYAN;
                else if (line.contains("RETREAT")) lc = ACCENT_YEL;
                else if (line.contains("FAKE"))    lc = 0xFFCC88FF;
                g.drawString(font, line, rx, replayPanY + 4, lc);
                rx += font.width(line) + 8;
                if (rx > cx + cw - 20) break; // не вылезаем за панель
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — Мини-карта отряда (точки по ролям)
    // ═══════════════════════════════════════════════════════════════

    /**
     * Рисует мини-карту отряда — точки цветом по роли.
     * Центр = позиция командира / владельца.
     * Масштаб: 1 блок = 2 пикселя, радиус = 40px = 20 блоков.
     */
    private void renderSquadMinimap(GuiGraphics g, int cx, int cy) {

}
