package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;

/**
 * BotArenaMode v1.0 — режим 1v1 арены с центрированием и раундами.
 *
 * Активируется командой: !arena [on|off|center x y z]
 *
 * Поведение:
 *  - Бот не выходит за пределы арены (radius от центра)
 *  - При потере цели — возвращается к центру арены
 *  - Ведёт счёт раундов: выигрыш = kill, проигрыш = смерть бота
 *  - После 3 раундов — объявляет итог
 *  - При выходе за границу — телепортируется на край (не в центр сразу)
 *
 * Интеграция:
 *   BotArenaMode arena = bot.getArenaMode();
 *   arena.enable(center, radius);
 *   // В тике:
 *   arena.tick(sw, target);
 *   // В onKill / onDeath:
 *   arena.onBotKill(); arena.onBotDeath();
 */
public class BotArenaMode {

    // ── Константы ─────────────────────────────────────────────────
    private static final int    DEFAULT_RADIUS  = 20;   // блоков
    private static final int    ROUNDS_TO_WIN   = 3;    // раундов до финала
    private static final double BORDER_SLOWDOWN = 0.6;  // множитель скорости у края
    private static final int    CENTER_RETURN_TICKS = 40; // тиков без цели → возврат к центру

    private final BotEntity bot;

    // ── Настройки ─────────────────────────────────────────────────
    private boolean enabled   = false;
    private Vec3    center    = Vec3.ZERO;
    private double  radius    = DEFAULT_RADIUS;

    // ── Счёт раундов ──────────────────────────────────────────────
    private int botWins    = 0;
    private int botLosses  = 0;
    private int totalRounds = 0;

    // ── Состояние ─────────────────────────────────────────────────
    private int noTargetTimer = 0;

    public BotArenaMode(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Включение / настройка
    // ══════════════════════════════════════════════════════════════

    public void enable(Vec3 center, double radius) {
        this.enabled = true;
        this.center  = center;
        this.radius  = radius;
        resetScore();
        notifyOwner("§a✔ Arena Mode включён. Центр: " + fmtVec(center) + " R=" + (int) radius);
    }

    public void disable() {
        this.enabled = false;
        notifyOwner("§7Arena Mode выключен. Итог: " + botWins + "W / " + botLosses + "L");
    }

    public boolean isEnabled() { return enabled; }

    // ══════════════════════════════════════════════════════════════
    //  Тик (вызывать из PVPBotLogic каждый тик если enabled)
    // ══════════════════════════════════════════════════════════════

    public void tick(ServerLevel sw, LivingEntity target) {
        if (!enabled) return;

        double distFromCenter = bot.position().distanceTo(center);

        // ── Граница арены: замедление у края ─────────────────────
        if (distFromCenter > radius * 0.85) {
            Vec3 toCenter = center.subtract(bot.position()).normalize();
            double pushStrength = (distFromCenter - radius * 0.85) / (radius * 0.15) * 0.08;
            pushStrength = Math.min(pushStrength, 0.12);
            bot.setDeltaMovement(bot.getDeltaMovement().add(
                toCenter.x * pushStrength, 0, toCenter.z * pushStrength));
        }

        // ── Выход за границу: принудительный возврат ─────────────
        if (distFromCenter > radius + 3) {
            Vec3 safePos = center.add(
                center.subtract(bot.position()).normalize().scale(-(radius - 2)));
            bot.teleportTo(safePos.x, safePos.y, safePos.z);
            notifyOwner("§e⚠ Бот вышел за границу арены — возврат.");
        }

        // ── Нет цели → возврат к центру ──────────────────────────
        if (target == null || !target.isAlive()) {
            noTargetTimer++;
            if (noTargetTimer >= CENTER_RETURN_TICKS) {
                bot.getNavigation().moveTo(center.x, center.y, center.z, 1.1);
            }
        } else {
            noTargetTimer = 0;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  События раунда
    // ══════════════════════════════════════════════════════════════

    /** Вызывать когда бот убил противника. */
    public void onBotKill() {
        if (!enabled) return;
        botWins++;
        totalRounds++;
        notifyOwner("§a⚔ Раунд " + totalRounds + ": Победа! [" + botWins + "W/" + botLosses + "L]");
        checkMatchEnd();
    }

    /** Вызывать при смерти бота. */
    public void onBotDeath() {
        if (!enabled) return;
        botLosses++;
        totalRounds++;
        notifyOwner("§c☠ Раунд " + totalRounds + ": Поражение! [" + botWins + "W/" + botLosses + "L]");
        checkMatchEnd();
    }

    private void checkMatchEnd() {
        if (botWins >= ROUNDS_TO_WIN || botLosses >= ROUNDS_TO_WIN) {
            String result = botWins > botLosses
                ? "§a§lБОТ ПОБЕДИЛ §r§7(" + botWins + "/" + totalRounds + ")"
                : "§c§lБОТ ПРОИГРАЛ §r§7(" + botLosses + "/" + totalRounds + ")";
            notifyOwner("§e§l=== Матч завершён! " + result + " §e§l===");
            resetScore();
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательное
    // ══════════════════════════════════════════════════════════════

    public void resetScore() {
        botWins    = 0;
        botLosses  = 0;
        totalRounds = 0;
        noTargetTimer = 0;
    }

    public int getBotWins()   { return botWins; }
    public int getBotLosses() { return botLosses; }
    public Vec3 getCenter()   { return center; }
    public double getRadius() { return radius; }

    private void notifyOwner(String msg) {
        Player owner = bot.getOwner();
        if (owner != null) owner.sendSystemMessage(Component.literal(
            "§7[Arena] §f" + bot.getName().getString() + ": " + msg));
    }

    private static String fmtVec(Vec3 v) {
        return String.format("(%.0f, %.0f, %.0f)", v.x, v.y, v.z);
    }
}
