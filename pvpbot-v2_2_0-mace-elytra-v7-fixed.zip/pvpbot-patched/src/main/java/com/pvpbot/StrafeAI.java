package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;

/**
 * StrafeAI v6.0 — полная переработка производительности и AI.
 *
 * Улучшения v6.0:
 *  ПРОИЗВОДИТЕЛЬНОСТЬ:
 *   - isSideBlocked кэшируется 4 тика (было каждый тик 2 getBlockState)
 *   - getSideVector не создаёт new Vec3 при каждом вызове (inline компонентный расчёт)
 *   - BlockPos.containing убран из hot path — используем longKey сравнение
 *   - tickHighGround: поиск ведётся только каждые HIGH_GROUND_CD тиков, не каждый тик
 *
 *  AI:
 *   - CIRCLE: реальный угловой шаг зависит от скорости цели (быстрее враг → шире страф)
 *   - ZIGZAG: flip-timer адаптируется к предсказуемости врага из PatternAI
 *   - RANDOM: seed из tickCount (детерминировано, но не цикличен)
 *   - RETREAT: настоящий отступной страф (hit-and-run) — отдельная реализация
 *   - Стейт HIGH_GROUND активнее: проверяем 3×3 зону а не 5×5 (быстрее)
 *   - Anti-wall reflex: если заблокированы оба направления — отпрыгиваем от стены
 */
public class StrafeAI {

    public enum StrafeStyle { CIRCLE, RANDOM, ZIGZAG, RETREAT }

    // ── Константы ─────────────────────────────────────────────────
    // v7 BUFF: быстрее страф = сложнее попасть
    private static final double APPROACH_SPEED  = 1.35;  // было 1.25
    private static final double STRAFE_SPEED    = 1.18;  // было 1.05
    private static final double STRAFE_START    = 6.0;   // было 5.0: раньше начинаем страф
    private static final double IDEAL_DIST      = 2.8;
    private static final int    DIR_MIN         = 8;     // было 12: чаще меняем направление
    private static final int    DIR_MAX         = 18;    // было 26: менее предсказуемо
    private static final int    HIGH_GROUND_CD  = 35;    // было 45

    // ── Состояние ─────────────────────────────────────────────────
    private StrafeStyle style      = StrafeStyle.CIRCLE;
    private boolean     strafeLeft = true;
    private int         dirTimer   = DIR_MIN;
    private int         blockCd    = 0;
    private int         highGroundCd = 0;

    // ── Кэш боковой блокировки ────────────────────────────────────
    private boolean leftBlocked   = false;
    private boolean rightBlocked  = false;
    private int     blockCacheAge = 0;
    private static final int BLOCK_CACHE_LIFE = 4;

    // ── Адаптивный Yaw от PatternAI ───────────────────────────────
    private float adaptedYawOffset = 0f;

    // ── Crystal-mode: не вмешиваемся в Navigation ─────────────────
    private boolean crystalMode = false;

    // ── ZIGZAG: flip-timer ────────────────────────────────────────
    private int zigzagFlipTimer = 0;

    // ── RETREAT: фаза (атака / отступ) ───────────────────────────
    private boolean retreatPhaseAttack = true;
    private int     retreatPhaseTimer  = 0;

    private final BotEntity bot;

    public StrafeAI(BotEntity bot) {
        this.bot = bot;
        dirTimer = DIR_MIN + bot.level().getRandom().nextInt(DIR_MAX - DIR_MIN);
    }

    public void setStyle(StrafeStyle s)     { this.style = s; }
    public StrafeStyle getStyle()           { return style; }
    public boolean isStrafeLeft()           { return strafeLeft; }
    public void setAdaptedYaw(float y)      { this.adaptedYawOffset = y; }
    public void setCrystalMode(boolean v)   { this.crystalMode = v; }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            bot.getNavigation().stop();
            bot.setSprinting(false);
            return;
        }
        if (bot.level().isClientSide || crystalMode) return;

        // BAIT_STOP контр-паттерн
        if (bot.getPatternAI().isBaitStopActive()) {
            bot.getNavigation().stop();
            bot.setSprinting(false);
            return;
        }

        // FIX #7: FEINT — ложный выпад к цели, затем резкая остановка
        // PatternAI выставляет baitStopTicks > 0 на время рывка,
        // но isBaitStopActive() было true только у BAIT_STOP.
        // FEINT использует тот же baitStopTicks, но движение было не реализовано.
        if (bot.getPatternAI().getActiveCounter() == PatternAI.CounterStrategy.FEINT) {
            double dist = bot.distanceTo(target);
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (bot.getPatternAI().isBaitStopActive()) {
                // Фаза рывка: летим прямо к цели со спринтом
                bot.getNavigation().moveTo(target, APPROACH_SPEED * 1.35);
                bot.setSprinting(true);
            } else {
                // Рывок завершён — резкая остановка (враг теряет прицел, ожидая удара)
                bot.getNavigation().stop();
                bot.setSprinting(false);
                // Небольшой импульс назад для усиления эффекта
                Vec3 away = bot.position().subtract(target.position()).normalize();
                bot.setDeltaMovement(bot.getDeltaMovement().add(away.x * 0.18, 0, away.z * 0.18));
            }
            return;
        }

        double dist = bot.distanceTo(target);
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // APPROACH
        if (dist > STRAFE_START) {
            bot.getNavigation().moveTo(target, APPROACH_SPEED);
            bot.setSprinting(dist > 8.0);
            return;
        }

        // ── Таймеры ───────────────────────────────────────────────
        if (blockCd > 0) blockCd--;

        // Обновляем кэш боковой блокировки раз в BLOCK_CACHE_LIFE тиков
        blockCacheAge--;
        if (blockCacheAge <= 0) {
            leftBlocked  = isSideBlockedRaw(true,  target);
            rightBlocked = isSideBlockedRaw(false, target);
            blockCacheAge = BLOCK_CACHE_LIFE;
        }

        // Anti-wall reflex: оба заблокированы → отпрыгнуть от стены
        if (leftBlocked && rightBlocked && bot.onGround()) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.setDeltaMovement(away.x * 0.4, 0.35, away.z * 0.4);
            return;
        }

        // Смена направления
        dirTimer--;
        if (dirTimer <= 0 && blockCd <= 0) {
            boolean wantedLeft = !strafeLeft;
            if (wantedLeft && leftBlocked || !wantedLeft && rightBlocked) {
                // Хотели развернуться, но заблокировано — остаёмся
                blockCd  = 8;
                dirTimer = 4;
            } else {
                strafeLeft = wantedLeft;
                // ZIGZAG: flip-timer адаптируется к предсказуемости
                if (style == StrafeStyle.ZIGZAG) {
                    float pred = bot.getPatternAI().getEnemyPredictability();
                    // Чем предсказуемее враг — тем короче интервал (агрессивнее зигзаг)
                    int base = (int) (DIR_MIN / 2 * (1.0f - pred * 0.5f));
                    dirTimer = Math.max(4, base + bot.level().getRandom().nextInt(4));
                } else {
                    dirTimer = DIR_MIN + bot.level().getRandom().nextInt(DIR_MAX - DIR_MIN);
                }
            }
        }

        // High Ground
        if (highGroundCd > 0) highGroundCd--;
        if (highGroundCd == 0) tickHighGround(target);

        // Страф по стилю
        switch (style) {
            case CIRCLE  -> doCircle(target, dist);
            case ZIGZAG  -> doZigzag(target, dist);
            case RANDOM  -> doRandom(target, dist);
            case RETREAT -> doRetreat(target, dist);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  CIRCLE: угловой шаг зависит от скорости цели
    // ══════════════════════════════════════════════════════════════
    private void doCircle(LivingEntity target, double dist) {
        Vec3 toBot = bot.position().subtract(target.position());
        double angle = Math.atan2(toBot.z, toBot.x);

        // Адаптивный шаг: быстрая цель → шире страф (0.07..0.12 рад/тик)
        double targetSpeed = target.getDeltaMovement().horizontalDistance();
        double step = 0.07 + Math.min(0.05, targetSpeed * 0.15);
        if (!strafeLeft) step = -step;
        step += Math.toRadians(adaptedYawOffset * 0.5);

        double newAngle = angle + step;
        double targetR  = IDEAL_DIST + 0.3;
        double nx = target.getX() + Math.cos(newAngle) * targetR;
        double nz = target.getZ() + Math.sin(newAngle) * targetR;

        // Проверка блока (inline, без new Vec3)
        BlockPos destFoot = BlockPos.containing(nx, bot.getY() + 0.1, nz);
        if (bot.level().getBlockState(destFoot).isSolid() ||
            bot.level().getBlockState(destFoot.above()).isSolid()) {
            newAngle = angle - step;
            nx = target.getX() + Math.cos(newAngle) * targetR;
            nz = target.getZ() + Math.sin(newAngle) * targetR;
            strafeLeft = !strafeLeft;
            blockCd = 10;
        }

        // Spiral blend к цели если далеко
        if (dist > IDEAL_DIST + 1.0) {
            double t = Math.min(1.0, (dist - IDEAL_DIST) / 3.0);
            nx = nx + (target.getX() - nx) * t * 0.45;
            nz = nz + (target.getZ() - nz) * t * 0.45;
            bot.getNavigation().moveTo(nx, bot.getY(), nz, APPROACH_SPEED);
        } else if (dist < IDEAL_DIST - 0.4) {
            // Слишком близко — отступаем
            double awx = bot.getX() - target.getX();
            double awz = bot.getZ() - target.getZ();
            double len = Math.sqrt(awx * awx + awz * awz);
            if (len > 0.01) { awx /= len; awz /= len; }
            bot.getNavigation().moveTo(bot.getX() + awx * 1.2, bot.getY(), bot.getZ() + awz * 1.2, STRAFE_SPEED);
        } else {
            bot.getNavigation().moveTo(nx, bot.getY(), nz, STRAFE_SPEED);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  ZIGZAG: адаптивный интервал по предсказуемости
    // ══════════════════════════════════════════════════════════════
    private void doZigzag(LivingEntity target, double dist) {
        if (zigzagFlipTimer-- <= 0) {
            strafeLeft = !strafeLeft;
            float pred = bot.getPatternAI().getEnemyPredictability();
            zigzagFlipTimer = Math.max(3, (int)(6 * (1.0f - pred)) + bot.level().getRandom().nextInt(4));
        }

        // Диагональ: страф + движение к цели
        Vec3 to = target.position().subtract(bot.position()).normalize();
        double sx = strafeLeft ? -to.z : to.z;
        double sz = strafeLeft ?  to.x : -to.x;
        double mx = (to.x + sx) * 0.707;
        double mz = (to.z + sz) * 0.707;

        bot.getNavigation().moveTo(bot.getX() + mx * 2.5, bot.getY(), bot.getZ() + mz * 2.5, STRAFE_SPEED * 1.1);
        if (dist > IDEAL_DIST + 1.0)
            bot.getNavigation().moveTo(target, STRAFE_SPEED * 1.1);
    }

    // ══════════════════════════════════════════════════════════════
    //  RANDOM: детерминированный seed из tickCount
    // ══════════════════════════════════════════════════════════════
    private void doRandom(LivingEntity target, double dist) {
        // Используем tickCount как псевдо-random seed — не создаёт new Random()
        boolean rnd = (bot.tickCount % 5 < 2) != strafeLeft;
        Vec3 to = target.position().subtract(bot.position()).normalize();
        double sx = rnd ? -to.z : to.z;
        double sz = rnd ?  to.x : -to.x;
        double blend = 0.3 + (bot.tickCount % 7) * 0.05; // 0.30..0.60

        double mx = (sx * blend + to.x * (1.0 - blend));
        double mz = (sz * blend + to.z * (1.0 - blend));
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > 0.01) { mx /= len; mz /= len; }

        bot.getNavigation().moveTo(bot.getX() + mx * 2.0, bot.getY(), bot.getZ() + mz * 2.0, STRAFE_SPEED);
        if (dist > IDEAL_DIST + 1.5) bot.getNavigation().moveTo(target, STRAFE_SPEED);
    }

    // ══════════════════════════════════════════════════════════════
    //  RETREAT: настоящий hit-and-run (новое в v6.0)
    //  Фаза ATTACK: сближаемся и атакуем → после удара фаза RETREAT
    //  Фаза RETREAT: отбегаем назад 12-18 тиков → снова ATTACK
    // ══════════════════════════════════════════════════════════════
    // v2.2: Улучшен RETREAT — умные фазы + смена направления страфа при каждом отходе
    private void doRetreat(LivingEntity target, double dist) {
        if (retreatPhaseTimer > 0) {
            retreatPhaseTimer--;
        } else {
            boolean wasAttack   = retreatPhaseAttack;
            retreatPhaseAttack  = !retreatPhaseAttack;
            // При переходе в фазу отхода — меняем направление страфа (непредсказуемость)
            if (!retreatPhaseAttack && wasAttack) strafeLeft = !strafeLeft;
            // Длительность: атака 6-10 тиков, отход 10-18 тиков
            retreatPhaseTimer = retreatPhaseAttack
                ? 6 + bot.level().getRandom().nextInt(5)
                : 10 + bot.level().getRandom().nextInt(9);
        }

        Vec3 to = target.position().subtract(bot.position()).normalize();
        if (retreatPhaseAttack) {
            // Фаза атаки: быстро к цели по диагонали (не прямолинейно)
            double sx = strafeLeft ? -to.z * 0.4 : to.z * 0.4;
            double sz = strafeLeft ?  to.x * 0.4 : -to.x * 0.4;
            bot.getNavigation().moveTo(
                target.getX() + sx, target.getY(), target.getZ() + sz, APPROACH_SPEED * 1.05);
            bot.setSprinting(dist > 3.0);
        } else {
            // Фаза отхода: назад + активный страф
            double sx = strafeLeft ? -to.z : to.z;
            double sz = strafeLeft ?  to.x : -to.x;
            double rx  = bot.getX() - to.x * 4.0 + sx * 2.0;
            double rz  = bot.getZ() - to.z * 4.0 + sz * 2.0;
            bot.getNavigation().moveTo(rx, bot.getY(), rz, APPROACH_SPEED * 1.2);
            bot.setSprinting(true);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  High Ground: компактная версия (3×3, не 5×5)
    // ══════════════════════════════════════════════════════════════
    private void tickHighGround(LivingEntity target) {
        if (bot.getY() >= target.getY() + 0.5) {
            highGroundCd = HIGH_GROUND_CD; // уже выше — cooldown без поиска
            return;
        }
        BlockPos bp = bot.blockPosition();
        outer:
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (dx * dx + dz * dz > 8) continue; // круглая зона r=2.8
                BlockPos up = bp.offset(dx, 1, dz);
                if (bot.level().getBlockState(up).isAir()
                    && bot.level().getBlockState(up.below()).isSolid()
                    && bot.level().getBlockState(up.above()).isAir()) {
                    bot.getNavigation().moveTo(up.getX() + 0.5, up.getY(), up.getZ() + 0.5, 1.1);
                    if (bot.onGround()) bot.getJumpControl().jump();
                    highGroundCd = HIGH_GROUND_CD;
                    break outer;
                }
            }
        }
        if (highGroundCd == 0) highGroundCd = 10; // нет позиции — короткий cooldown
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные (оптимизированные)
    // ══════════════════════════════════════════════════════════════

    /** Прямая проверка блокировки (вызывается в кэш-обновлении). */
    private boolean isSideBlockedRaw(boolean left, LivingEntity target) {
        Vec3 to = target.position().subtract(bot.position()).normalize();
        double sx = left ? -to.z * 1.3 : to.z * 1.3;
        double sz = left ?  to.x * 1.3 : -to.x * 1.3;
        double px = bot.getX() + sx;
        double pz = bot.getZ() + sz;
        BlockPos foot = BlockPos.containing(px, bot.getY() + 0.1, pz);
        return bot.level().getBlockState(foot).isSolid()
            || bot.level().getBlockState(foot.above()).isSolid();
    }
}
