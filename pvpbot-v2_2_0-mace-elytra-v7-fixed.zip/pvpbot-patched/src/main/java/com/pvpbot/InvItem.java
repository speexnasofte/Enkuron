package com.pvpbot;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.Objects;

/**
 * InvItem v2.0 — типобезопасный дескриптор предмета инвентаря кита.
 *
 * Улучшения v2.0:
 *  - Финальные поля + валидация в конструкторе (no-null item, count > 0)
 *  - enchants разбиваются в parseEnchants() в момент создания — не при каждом применении
 *  - Добавлен secondaryItem для двойных предметов (напр. меч+щит в одном слоте)
 *  - equals/hashCode для корректной работы в Set/Map
 *  - Фабричные методы: weapon(), potion(), armor() для более читаемого кода
 */
public final class InvItem {

    // ── Поля ──────────────────────────────────────────────────────
    public final Item   item;
    public final int    count;
    /**
     * Строка зачарований «enchant:level,enchant:level» или id зелья (напр. «healing2»).
     * null означает «без зачарований / обычный предмет».
     */
    public final String enchants;

    /** Предварительно распарсенные зачарования. null если enchants=null или это зелье. */
    public final EnchantEntry[] parsedEnchants;

    // ── Конструктор с валидацией ──────────────────────────────────
    public InvItem(Item item, int count, String enchants) {
        if (item == null) throw new IllegalArgumentException("InvItem: item cannot be null");
        if (count <= 0)   throw new IllegalArgumentException("InvItem: count must be > 0, got " + count);

        this.item     = item;
        this.count    = count;
        this.enchants = enchants;
        this.parsedEnchants = parseEnchants(item, enchants);
    }

    // ── Предварительный парсинг зачарований ──────────────────────
    private static EnchantEntry[] parseEnchants(Item item, String enchants) {
        if (enchants == null || enchants.isEmpty()) return null;
        // Зелья используют enchants как ID — не парсим
        if (item == Items.SPLASH_POTION || item == Items.POTION
                || item == Items.LINGERING_POTION) return null;

        String[] parts = enchants.split(",");
        EnchantEntry[] entries = new EnchantEntry[parts.length];
        int valid = 0;
        for (String part : parts) {
            String[] kv = part.trim().split(":");
            if (kv.length == 2) {
                try {
                    entries[valid++] = new EnchantEntry(kv[0].trim(),
                                                        Integer.parseInt(kv[1].trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
        if (valid == 0) return null;
        // Обрезаем до реального размера
        if (valid < entries.length) {
            EnchantEntry[] trimmed = new EnchantEntry[valid];
            System.arraycopy(entries, 0, trimmed, 0, valid);
            return trimmed;
        }
        return entries;
    }

    /** Пара (имя зачарования, уровень). */
    public record EnchantEntry(String id, int level) {}

    // ── Фабричные методы для читаемого кода ──────────────────────

    /** Оружие с зачарованиями. Например: InvItem.weapon(Items.DIAMOND_SWORD, "sharpness:5,unbreaking:3") */
    public static InvItem weapon(Item item, String enchants) {
        return new InvItem(item, 1, enchants);
    }

    /** Зелье по ID (healing2, speed2, и т.д.). */
    public static InvItem potion(Item potionType, int count, String potionId) {
        return new InvItem(potionType, count, potionId);
    }

    /** Зелье в слэш-варианте (splash potion). */
    public static InvItem splash(int count, String potionId) {
        return new InvItem(Items.SPLASH_POTION, count, potionId);
    }

    /** Обычный предмет без зачарований. */
    public static InvItem plain(Item item, int count) {
        return new InvItem(item, count, null);
    }

    // ── Стандартные методы ────────────────────────────────────────
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InvItem other)) return false;
        return count == other.count
            && item.equals(other.item)
            && Objects.equals(enchants, other.enchants);
    }

    @Override
    public int hashCode() {
        return Objects.hash(item, count, enchants);
    }

    @Override
    public String toString() {
        return "InvItem{" + item.getDescriptionId() + " x" + count
            + (enchants != null ? " [" + enchants + "]" : "") + '}';
    }
}
