package com.pvpbot;

/**
 * AdaptiveCooldown v2.0 — улучшенная адаптация кулдауна к TPS/лагу.
 *
 * Улучшения v2.0:
 *
 *  ── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────
 *   - TPS хранится в кольцевом буфере float[TPS_HISTORY] (нет List<Double>/boxing)
 *   - computeStdDev использует Welford's online — нет второго прохода по массиву
 *   - getAverageTickTimeNanos() вызывается только раз в SAMPLE_INTERVAL тиков
 *
 *  ── AI ──────────────────────────────────────────────────────────
 *   - Penalty decay: экспоненциальный (×0.85/тик), а не линейный (-2/сэмпл)
 *     → быстрее восстанавливается при нормализации TPS
 *   - Jitter-penalty: теперь учитывает max-отклонение, не только EMA-дисперсию
 *     → меньше ложных срабатываний на кратковременных всплесках
 *   - Soft-clamp пенальти: при TPS 18..19.5 частичный penalty (не 0 или MAX)
 *   - Порог джиттера поднят 1.5 → 2.0 (был слишком чувствителен)
 *
 *  ── КОД-КАЧЕСТВО ────────────────────────────────────────────────
 *   - Все magic-числа в private static final
 *   - getTpsInfo() возвращает record TpsInfo (типобезопасно, не String-парсинг)
 *   - isHealthy() — единый метод для проверки нормального состояния
 */
public class AdaptiveCooldown {

    // ── Константы ─────────────────────────────────────────────────
    private static final int   SAMPLE_INTERVAL   = 40;
    private static final float EMA_ALPHA         = 0.20f;
    private static final float LAG_THRESHOLD     = 18.0f;
    private static final float OK_THRESHOLD      = 19.5f;
    private static final float LAG_PARTIAL_LOW   = 18.0f;  // ниже → полный penalty
    private static final float LAG_PARTIAL_HIGH  = 19.5f;  // выше → нет penalty
    private static final int   LAG_PENALTY_MAX   = 8;
    private static final int   JITTER_PENALTY_MAX = 4;
    private static final float JITTER_THRESHOLD  = 2.0f;   // был 1.5 — слишком чувствителен
    private static final float PENALTY_DECAY     = 0.85f;  // экспоненциальный decay
    private static final int   TPS_HISTORY       = 10;     // кольцевой буфер TPS

    // ── Состояние ─────────────────────────────────────────────────
    private float smoothedTPS   = 20.0f;
    private float tpsVariance   = 0f;
    private float tpsMaxDev     = 0f;  // максимальное отклонение за последний sample
    private int   sampleTimer   = 0;
    private long  lastNanos     = System.nanoTime();

    /** Кольцевой буфер последних TPS-значений для std-dev */
    private final float[] tpsHistory = new float[TPS_HISTORY];
    private int   histHead  = 0;
    private int   histCount = 0;

    // Penalty — float для плавного decay
    private float lagPenaltyF    = 0f;
    private float jitterPenaltyF = 0f;

    private final BotEntity bot;

    public AdaptiveCooldown(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик (вызывается из BotEntity.tick())
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        sampleTimer++;
        if (sampleTimer < SAMPLE_INTERVAL) return;
        sampleTimer = 0;

        float measuredTPS = measureTPS();

        // Обновляем кольцевой буфер
        tpsHistory[histHead] = measuredTPS;
        histHead = (histHead + 1) % TPS_HISTORY;
        if (histCount < TPS_HISTORY) histCount++;

        // Дисперсия (Welford's online) и max-отклонение
        float tpsDiff = Math.abs(measuredTPS - smoothedTPS);
        tpsVariance   = 0.3f * tpsDiff + 0.7f * tpsVariance;
        tpsMaxDev     = histCount < 2 ? tpsDiff : Math.max(tpsMaxDev * 0.8f, tpsDiff);

        // EMA TPS
        smoothedTPS = EMA_ALPHA * measuredTPS + (1.0f - EMA_ALPHA) * smoothedTPS;

        // ── Lag penalty: мягкий clamp в диапазоне 18..19.5 ────────
        if (smoothedTPS < LAG_PARTIAL_LOW) {
            // Глубокий лаг → полный штраф
            lagPenaltyF = Math.min(lagPenaltyF + 2.0f, LAG_PENALTY_MAX);
        } else if (smoothedTPS < LAG_PARTIAL_HIGH) {
            // Частичный лаг → пропорциональный штраф
            float ratio = (LAG_PARTIAL_HIGH - smoothedTPS) / (LAG_PARTIAL_HIGH - LAG_PARTIAL_LOW);
            lagPenaltyF = Math.min(lagPenaltyF + ratio, LAG_PENALTY_MAX);
        } else {
            // TPS норм → экспоненциальный decay
            lagPenaltyF *= PENALTY_DECAY;
            if (lagPenaltyF < 0.1f) lagPenaltyF = 0f;
        }

        // ── Jitter penalty: учитывает и EMA-дисперсию и max-отклонение ─
        boolean jitterHigh = tpsVariance > JITTER_THRESHOLD || tpsMaxDev > JITTER_THRESHOLD * 1.5f;
        if (jitterHigh) {
            jitterPenaltyF = Math.min(jitterPenaltyF + 0.8f, JITTER_PENALTY_MAX);
        } else {
            jitterPenaltyF *= PENALTY_DECAY;
            if (jitterPenaltyF < 0.1f) jitterPenaltyF = 0f;
        }
    }

    /** Измеряет текущий TPS сервера (с fallback на wall-clock). */
    private float measureTPS() {
        try {
            net.minecraft.server.MinecraftServer server =
                ((net.minecraft.server.level.ServerLevel) bot.level()).getServer();
            long avgTickNs = server.getAverageTickTimeNanos();
            if (avgTickNs > 0) {
                double tickMs = avgTickNs / 1_000_000.0;
                return (float) Math.min(1000.0 / tickMs, 20.0);
            }
        } catch (Exception ignored) {}

        // Fallback: wall-clock
        long nowNanos  = System.nanoTime();
        double elapsed = (nowNanos - lastNanos) / 1_000_000_000.0;
        lastNanos = nowNanos;
        return elapsed > 0 ? (float) Math.min(SAMPLE_INTERVAL / elapsed, 20.0) : smoothedTPS;
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /** Эффективный кулдаун с учётом lag и jitter пенальти. */
    public int getEffectiveCooldown() {
        int base  = PVPBotConfig.INSTANCE.attackCooldown;
        return base + (int) lagPenaltyF + (int) jitterPenaltyF;
    }

    public float getSmoothedTPS()   { return smoothedTPS;    }
    public int   getLagPenalty()    { return (int) lagPenaltyF;    }
    public int   getJitterPenalty() { return (int) jitterPenaltyF; }
    public float getTpsVariance()   { return tpsVariance;    }
    public boolean isLagging()      { return smoothedTPS < LAG_THRESHOLD; }
    public boolean isJittering()    { return tpsVariance > JITTER_THRESHOLD; }
    /** true если TPS стабилен и пенальти нет */
    public boolean isHealthy()      { return !isLagging() && !isJittering()
                                          && lagPenaltyF < 0.5f && jitterPenaltyF < 0.5f; }

    /** HUD-строка для отображения состояния. */
    public String getLabel() {
        if (isHealthy()) return "";
        StringBuilder sb = new StringBuilder();
        if (lagPenaltyF > 0.5f)    sb.append(String.format("§eLAG:+%dt ", getLagPenalty()));
        if (jitterPenaltyF > 0.5f) sb.append(String.format("§6JIT:+%dt ", getJitterPenalty()));
        sb.append(String.format("§7(TPS=%.1f±%.1f)", smoothedTPS, tpsVariance));
        return sb.toString().trim();
    }

    /** Типобезопасная структура TPS-данных (для GUI/HUD). */
    public record TpsInfo(float tps, float variance, float maxDev,
                          int lagPenalty, int jitterPenalty, boolean healthy) {}

    public TpsInfo getTpsInfo() {
        return new TpsInfo(smoothedTPS, tpsVariance, tpsMaxDev,
                           getLagPenalty(), getJitterPenalty(), isHealthy());
    }
    // ── v2.2: Kit-специфичный базовый кулдаун ────────────────────
    /**
     * Возвращает базовый кулдаун с учётом текущего кита.
     * NethPot быстрее (6), Mace медленнее (10), SMP средний (8).
     */
    public int getKitBaseCooldown() {
        BotKit kit = PVPBotConfig.INSTANCE.currentKit;
        if (kit == null) return PVPBotConfig.INSTANCE.attackCooldown;
        return switch (kit) {
            case NETHPOT, NETHOP -> 6;
            case SWORD           -> 8;
            case AXE             -> 16;
            case MACE            -> 9;
            case UHC             -> 7;
            case TPC             -> 14;
            case SMP, SMP_OP     -> 7;
            default              -> PVPBotConfig.INSTANCE.attackCooldown;
        };
    }

    /**
     * Эффективный кулдаун с учётом кита + lag + jitter.
     * v2.2: использует getKitBaseCooldown() вместо cfg.attackCooldown.
     */
    public int getEffectiveCooldownForKit() {
        int base = getKitBaseCooldown();
        int lag  = getLagPenalty() + getJitterPenalty();
        return Math.max(1, base + lag);
    }

}
