package net.enkuron.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * TargetManager v1 — централизованное ядро выбора цели для всех модулей.
 *
 * Алгоритм выбора:
 *   score = distance * distWeight + (maxHp - hp) * hpWeight + (inFov ? 0 : fovPenalty)
 *   Меньше = приоритетнее.
 *
 * Особенности:
 *  - Сброс цели при смерти / выходе за range / если умер
 *  - Задержка смены цели (switchDelay мс) — нет дёргания
 *  - Фильтр по FOV (опционально)
 *  - Фильтр LoS (canSee) опционально
 *  - Singleton с ленивой инициализацией
 *  - Thread-safe чтение (volatile)
 */
public class TargetManager {

    // ── Singleton ─────────────────────────────────────────────────────────────

    private static volatile TargetManager instance;

    public static TargetManager getInstance() {
        if (instance == null) {
            synchronized (TargetManager.class) {
                if (instance == null) instance = new TargetManager();
            }
        }
        return instance;
    }

    // ── Параметры ─────────────────────────────────────────────────────────────

    /** Дальность в блоках (можно менять в рантайме) */
    public double range = 6.0;

    /** Включить LoS-фильтр (canSee) */
    public boolean requireLos = true;

    /** Включить FOV-фильтр */
    public boolean requireFov = false;

    /** Угол FOV (градусы, от центра взгляда) */
    public float fovAngle = 90f;

    /** Задержка смены цели (мс) */
    public long switchDelay = 300;

    /** Вес дистанции в формуле score */
    public double distWeight = 1.0;

    /** Вес HP (низкий HP = выше приоритет) */
    public double hpWeight = 0.4;

    /** Штраф за нахождение вне FOV */
    public double fovPenalty = 5.0;

    /** Игроки как цели */
    public boolean targetPlayers = true;

    /** Враждебные мобы как цели */
    public boolean targetHostile = true;

    // ── Состояние ─────────────────────────────────────────────────────────────

    private volatile LivingEntity currentTarget = null;
    private volatile LivingEntity pendingTarget = null;
    private long lastSwitch = 0;
    private long pendingTime = 0;

    // ── API ───────────────────────────────────────────────────────────────────

    /** Вызывать каждый тик. Возвращает текущую цель (или null). */
    public LivingEntity update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) {
            currentTarget = null;
            return null;
        }

        // Сброс если цель умерла или ушла
        if (currentTarget != null) {
            if (!currentTarget.isAlive()
                    || mc.player.distanceTo(currentTarget) > range + 1.0) {
                currentTarget = null;
            }
        }

        LivingEntity best = findBest(mc);

        // Обработка смены цели с задержкой
        if (best != currentTarget) {
            long now = System.currentTimeMillis();
            if (best != pendingTarget) {
                pendingTarget = best;
                pendingTime   = now;
            } else if (now - pendingTime >= switchDelay) {
                if (now - lastSwitch >= switchDelay) {
                    currentTarget = pendingTarget;
                    lastSwitch    = now;
                }
            }
        } else {
            pendingTarget = null;
        }

        return currentTarget;
    }

    /** Текущая цель без обновления (безопасно с любого потока). */
    public LivingEntity getTarget() {
        return currentTarget;
    }

    /** Принудительно сбросить цель. */
    public void reset() {
        currentTarget = null;
        pendingTarget = null;
    }

    /** Список всех кандидатов в радиусе (отсортирован по score). */
    public List<LivingEntity> getCandidates() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return List.of();
        return collectCandidates(mc);
    }

    // ── Логика выбора ─────────────────────────────────────────────────────────

    private LivingEntity findBest(MinecraftClient mc) {
        List<LivingEntity> candidates = collectCandidates(mc);
        if (candidates.isEmpty()) return null;

        LivingEntity best     = null;
        double       bestScore = Double.MAX_VALUE;

        for (LivingEntity e : candidates) {
            double score = score(e, mc);
            if (score < bestScore) {
                bestScore = score;
                best      = e;
            }
        }
        return best;
    }

    private List<LivingEntity> collectCandidates(MinecraftClient mc) {
        List<LivingEntity> result = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living.equals(mc.player)) continue;
            if (!living.isAlive()) continue;
            if (!isValidType(living)) continue;
            if (mc.player.distanceTo(living) > range) continue;
            if (requireLos && !mc.player.canSee(living)) continue;
            if (requireFov && !isInFov(living, mc)) continue;
            result.add(living);
        }
        return result;
    }

    private boolean isValidType(LivingEntity e) {
        if (targetPlayers && e instanceof PlayerEntity) return true;
        if (targetHostile && e instanceof HostileEntity) return true;
        return false;
    }

    private double score(LivingEntity e, MinecraftClient mc) {
        double dist  = mc.player.distanceTo(e);
        double hp    = e.getHealth();
        double maxHp = e.getMaxHealth();
        double fovP  = (requireFov || !isInFov(e, mc)) ? fovPenalty : 0.0;
        return dist * distWeight + (maxHp - hp) * hpWeight + fovP;
    }

    // ── FOV ──────────────────────────────────────────────────────────────────

    public static boolean isInFov(Entity entity, MinecraftClient mc) {
        if (mc.player == null) return false;
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        Vec3d dir  = entity.getPos()
                .add(0, entity.getHeight() * 0.5, 0)
                .subtract(mc.player.getEyePos())
                .normalize();
        double dot = look.dotProduct(dir);
        if (dot < -1.0) dot = -1.0;
        if (dot > 1.0)  dot = 1.0;
        return Math.toDegrees(Math.acos(dot)) < 90.0; // широкий FOV по умолчанию
    }

    public static boolean isInFov(Entity entity, MinecraftClient mc, float halfFovDeg) {
        if (mc.player == null) return false;
        Vec3d look = mc.player.getRotationVec(1.0f).normalize();
        Vec3d dir  = entity.getPos()
                .add(0, entity.getHeight() * 0.5, 0)
                .subtract(mc.player.getEyePos())
                .normalize();
        double dot = Math.max(-1.0, Math.min(1.0, look.dotProduct(dir)));
        return Math.toDegrees(Math.acos(dot)) < halfFovDeg;
    }
}
