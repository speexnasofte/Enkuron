package net.enkuron.ui;

import net.enkuron.utils.ConfigManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * ProfileScreen — экран управления профилями конфигурации.
 *
 * Открывается кнопкой "Профили" в EnkuronMenu (клавиша P).
 *
 * Функции:
 *  - Список сохранённых профилей
 *  - Загрузка профиля (клик)
 *  - Сохранение текущего конфига как нового профиля (поле ввода + Enter)
 *  - Удаление профиля (кнопка × рядом с именем)
 */
public class ProfileScreen extends Screen {

    private static final int BG        = 0xF01A1A22;
    private static final int PANEL     = 0xF0222230;
    private static final int HOVER     = 0xFF2C2C3E;
    private static final int ACCENT    = 0xFF7766FF;
    private static final int ACCENT2   = 0xFF44CCFF;
    private static final int TEXT_W    = 0xFFFFFFFF;
    private static final int TEXT_G    = 0xFF9999AA;
    private static final int DELETE_C  = 0xFFEE4444;

    private final Screen parent;

    private List<String> profiles;
    private int          hoveredIdx   = -1;
    private int          hoveredDel   = -1; // индекс профиля, на чьей кнопке × мышь
    private boolean      typing       = false;
    private StringBuilder newName     = new StringBuilder();
    private String        statusMsg   = "";
    private int           statusTimer = 0;

    // Layout
    private int panelX, panelY, panelW, panelH;
    private static final int ROW_H = 28;
    private static final int PAD   = 12;

    public ProfileScreen(Screen parent) {
        super(Text.literal("Enkuron — Профили"));
        this.parent   = parent;
        this.profiles = ConfigManager.listProfiles();
    }

    @Override
    protected void init() {
        super.init();
        panelW = 280;
        panelH = Math.min(400, 80 + profiles.size() * ROW_H + 60);
        panelX = (this.width  - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Фон
        ctx.fill(0, 0, this.width, this.height, 0xAA000000);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, BG);

        // Заголовок
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 36, PANEL);
        ctx.drawText(this.textRenderer, "§b⊞ §fПрофили конфигурации",
            panelX + PAD, panelY + 12, TEXT_W, true);

        int y = panelY + 44;

        if (profiles.isEmpty()) {
            ctx.drawText(this.textRenderer, "§7Нет сохранённых профилей",
                panelX + PAD, y + 6, TEXT_G, false);
            y += ROW_H;
        } else {
            for (int i = 0; i < profiles.size(); i++) {
                String name = profiles.get(i);
                boolean hov    = mx >= panelX + PAD && mx < panelX + panelW - PAD - 28
                              && my >= y && my < y + ROW_H - 2;
                boolean hovDel = mx >= panelX + panelW - PAD - 22 && mx < panelX + panelW - PAD
                              && my >= y && my < y + ROW_H - 2;

                hoveredIdx = hov    ? i : (hoveredIdx == i ? -1 : hoveredIdx);
                hoveredDel = hovDel ? i : (hoveredDel == i ? -1 : hoveredDel);

                // Строка профиля
                int rowBg = hov ? HOVER : 0x00000000;
                ctx.fill(panelX + 4, y, panelX + panelW - 4, y + ROW_H - 2, rowBg);

                // Иконка
                ctx.drawText(this.textRenderer, "§7⊟ ", panelX + PAD, y + 8, TEXT_G, false);
                ctx.drawText(this.textRenderer, name,   panelX + PAD + 14, y + 8, hov ? TEXT_W : TEXT_G, false);

                // Кнопка удаления
                int delColor = hovDel ? DELETE_C : 0xFF553333;
                ctx.fill(panelX + panelW - PAD - 20, y + 4, panelX + panelW - PAD, y + ROW_H - 6, delColor);
                ctx.drawText(this.textRenderer, "§f×", panelX + panelW - PAD - 14, y + 8, TEXT_W, true);

                y += ROW_H;
            }
        }

        // Разделитель
        y += 6;
        ctx.fill(panelX + PAD, y, panelX + panelW - PAD, y + 1, 0xFF333344);
        y += 8;

        // Поле ввода нового профиля
        ctx.drawText(this.textRenderer, "§7Сохранить текущий как:", panelX + PAD, y, TEXT_G, false);
        y += 14;
        int fieldBg = typing ? 0xFF1E1E2A : 0xFF16161E;
        ctx.fill(panelX + PAD, y, panelX + panelW - PAD - 70, y + 20, fieldBg);
        if (typing) {
            ctx.fill(panelX + PAD, y + 19, panelX + panelW - PAD - 70, y + 20, ACCENT);
        }
        String displayName = newName.toString() + (typing && (System.currentTimeMillis() / 500) % 2 == 0 ? "§7|" : "");
        ctx.drawText(this.textRenderer,
            displayName.isEmpty() ? "§7имя профиля..." : displayName,
            panelX + PAD + 4, y + 5,
            newName.length() > 0 ? TEXT_W : TEXT_G, false);

        // Кнопка Save
        boolean hovSave = mx >= panelX + panelW - PAD - 64 && mx < panelX + panelW - PAD
                       && my >= y && my < y + 20;
        int saveBg = hovSave ? ACCENT : 0xFF2A2A44;
        ctx.fill(panelX + panelW - PAD - 64, y, panelX + panelW - PAD, y + 20, saveBg);
        ctx.drawText(this.textRenderer, "§f✔ Сохранить",
            panelX + panelW - PAD - 58, y + 5, TEXT_W, false);

        y += 28;

        // Статус-сообщение
        if (statusTimer > 0) {
            statusTimer--;
            ctx.drawText(this.textRenderer, statusMsg, panelX + PAD, y, ACCENT2, false);
        }

        // Подсказка Esc
        ctx.drawText(this.textRenderer, "§7[Esc] назад",
            panelX + PAD, panelY + panelH - 16, TEXT_G, false);

        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (btn != 0) return super.mouseClicked(mx, my, btn);

        int y = panelY + 44;
        for (int i = 0; i < profiles.size(); i++) {
            // Кнопка удаления
            if (mx >= panelX + panelW - PAD - 20 && mx < panelX + panelW - PAD
             && my >= y && my < y + ROW_H - 2) {
                ConfigManager.deleteProfile(profiles.get(i));
                profiles = ConfigManager.listProfiles();
                status("§cПрофиль удалён.");
                init(); return true;
            }
            // Загрузка профиля
            if (mx >= panelX + PAD && mx < panelX + panelW - PAD - 28
             && my >= y && my < y + ROW_H - 2) {
                boolean ok = ConfigManager.loadProfile(profiles.get(i));
                status(ok ? "§aПрофиль загружен: §f" + profiles.get(i) : "§cОшибка загрузки.");
                return true;
            }
            y += ROW_H;
        }

        // Клик по полю ввода
        y += 6 + 8 + 14;
        if (mx >= panelX + PAD && mx < panelX + panelW - PAD - 70
         && my >= y && my < y + 20) {
            typing = true; return true;
        }

        // Кнопка Save
        if (mx >= panelX + panelW - PAD - 64 && mx < panelX + panelW - PAD
         && my >= y && my < y + 20) {
            trySave(); return true;
        }

        typing = false;
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (typing) { typing = false; return true; }
            this.client.setScreen(parent);
            return true;
        }
        if (typing) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                trySave(); return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE && newName.length() > 0) {
                newName.deleteCharAt(newName.length() - 1); return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char chr, int mods) {
        if (typing && newName.length() < 32 && isValidChar(chr)) {
            newName.append(chr); return true;
        }
        return super.charTyped(chr, mods);
    }

    private void trySave() {
        String name = newName.toString().trim();
        if (name.isEmpty()) { status("§cВведите имя профиля."); return; }
        ConfigManager.saveProfile(name);
        profiles = ConfigManager.listProfiles();
        newName.setLength(0);
        typing = false;
        status("§aПрофиль сохранён: §f" + name);
        init();
    }

    private void status(String msg) {
        statusMsg   = msg;
        statusTimer = 80; // 4 секунды
    }

    private boolean isValidChar(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
            || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == ' ';
    }

    @Override
    public boolean shouldPause() { return false; }
}
