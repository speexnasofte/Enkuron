package net.enkuron.ui;

import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * NotificationManager v3 — PREMIUM SMOOTH NOTIFICATIONS.
 *
 * Улучшения v3:
 *  - Spring-физика для slide-in (easeOutElastic как в iOS)
 *  - Stagger: каждое следующее уведомление появляется чуть позже
 *  - Glow-эффект вокруг цветной полоски
 *  - Hover-эффект: при наведении мыши пауза таймера
 *  - Shake-анимация при WARNING
 *  - Плавный прогресс-бар с easing
 *  - Chromatic title при TOGGLE
 */
public class NotificationManager {

    public enum Type { INFO, SUCCESS, WARNING, TOGGLE }

    private static final int WIDTH  = 210;
    private static final int HEIGHT = 46;
    private static final int MARGIN = 10;
    private static final int GAP    = 5;
    private static final int MAX    = 5;

    private static final int BG_COLOR = 0xE0080810;

    private static final List<Notification> notifications = new ArrayList<>();

    public static void push(String title, String message, Type type, long durationMs) {
        if (notifications.size() >= MAX) notifications.remove(0);
        notifications.add(new Notification(title, message, type, durationMs));
    }

    public static void push(String title, String message) {
        push(title, message, Type.INFO, 2500);
    }

    public static void pushToggle(String moduleName, boolean enabled) {
        push(moduleName, enabled ? "Включён" : "Выключен", Type.TOGGLE, 1800);
    }

    public static void pushSuccess(String title, String message) {
        push(title, message, Type.SUCCESS, 2500);
    }

    public static void pushWarning(String title, String message) {
        push(title, message, Type.WARNING, 3000);
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        Theme t = ThemeManager.get();

        Iterator<Notification> it = notifications.iterator();
        int stackIdx = 0;

        // Целевые Y позиции снизу вверх
        while (it.hasNext()) {
            Notification n = it.next();
            if (n.isExpired()) { it.remove(); continue; }

            float alpha   = n.getAlpha();
            float slideIn = n.getSlideInSpring();  // spring-физика

            // Stagger: каждый следующий появляется с задержкой
            float staggerDelay = stackIdx * 0.08f;
            float staggeredSlide = AnimationUtils.clamp(slideIn - staggerDelay, 0f, 1f);
            float easedSlide = AnimationUtils.easeOutElastic(staggeredSlide);

            int baseX = sw - WIDTH - MARGIN;
            int baseY = sh - MARGIN - HEIGHT - stackIdx * (HEIGHT + GAP);

            // Slide справа с easing
            int offsetX = (int)((1f - easedSlide) * (WIDTH + MARGIN + 20));
            int x = baseX + offsetX;
            int y = baseY;

            if (alpha < 0.01f) { stackIdx++; continue; }

            int alphaInt = (int)(alpha * 255);

            // ── Premium тень ──────────────────────────────────────────────
            for (int s = 6; s >= 1; s--) {
                int sa = (int)(alpha * 40 / (s + 1));
                ctx.fill(x+s, y+s, x+WIDTH+s, y+HEIGHT+s, (sa << 24));
            }

            // ── Фон ───────────────────────────────────────────────────────
            int bgA = (int)(alpha * 0xE0);
            ctx.fill(x, y, x+WIDTH, y+HEIGHT, (bgA << 24) | (BG_COLOR & 0x00FFFFFF));

            // ── Верхняя граница (стекло) ──────────────────────────────────
            int borderA = (int)(alpha * 0x40);
            ctx.fill(x, y, x+WIDTH, y+1, (borderA << 24) | 0xFFFFFF);
            ctx.fill(x, y, x+1, y+HEIGHT, (borderA/2 << 24) | 0xFFFFFF);
            ctx.fill(x+WIDTH-1, y, x+WIDTH, y+HEIGHT, (borderA/3 << 24) | 0xFFFFFF);
            ctx.fill(x, y+HEIGHT-1, x+WIDTH, y+HEIGHT, (borderA/4 << 24) | 0xFFFFFF);

            // ── Левая цветная полоска с glow ──────────────────────────────
            int stripRGB = getTypeColor(n.type, t);
            int stripA   = alphaInt;
            ctx.fill(x, y, x+3, y+HEIGHT, (stripA << 24) | stripRGB);
            // Glow за полоской
            for (int g = 5; g >= 1; g--) {
                int ga = (int)(alpha * 35 / g);
                ctx.fill(x, y, x+3+g, y+HEIGHT, (ga << 24) | stripRGB);
            }

            // ── Shake при WARNING ─────────────────────────────────────────
            int shakeX = 0;
            if (n.type == Type.WARNING) {
                float shakePhase = (System.currentTimeMillis() - n.startTime) / 80f;
                float shakeFade  = AnimationUtils.clamp(1f - (System.currentTimeMillis() - n.startTime) / 600f, 0f, 1f);
                shakeX = (int)(Math.sin(shakePhase) * 2f * shakeFade);
            }

            // ── Иконка ────────────────────────────────────────────────────
            String icon = getTypeIcon(n.type);
            int iconA = (int)(alpha * 255);
            // Пульс иконки
            float iconPulse = 0.85f + 0.15f * AnimationUtils.pulseAlpha(
                System.currentTimeMillis() / 600.0, 0f, 1f);
            int iconColor = (int)(iconA * iconPulse) << 24 | stripRGB;
            ctx.drawText(mc.textRenderer, icon, x+8+shakeX, y+HEIGHT/2-4, iconColor, false);

            // ── Заголовок ─────────────────────────────────────────────────
            int titleColor;
            if (n.type == Type.TOGGLE) {
                // Хроматический цвет для toggle
                titleColor = AnimationUtils.chromaticRainbow(0f, 0.0004f) & 0x00FFFFFF
                           | (alphaInt << 24);
            } else {
                titleColor = (alphaInt << 24) | 0xFFFFFF;
            }
            ctx.drawText(mc.textRenderer, n.title,     x+20+shakeX, y+10,       titleColor,          false);
            ctx.drawText(mc.textRenderer, n.message,   x+20+shakeX, y+HEIGHT-14,
                (int)(alpha * 180) << 24 | 0xBBBBCC, false);

            // ── Progress bar с easing ─────────────────────────────────────
            float rawProgress = n.getProgress();
            // Плавный eased прогресс
            float barProgress  = AnimationUtils.lerp(n.lastBarProgress, rawProgress, 0.15f);
            n.lastBarProgress  = barProgress;

            int barW    = (int)(barProgress * (WIDTH - 8));
            int barA    = (int)(alpha * 100);
            // Track
            ctx.fill(x+4, y+HEIGHT-3, x+WIDTH-4, y+HEIGHT-1, (barA/3 << 24) | 0xFFFFFF);
            // Fill — gradient от stripColor к белому
            if (barW > 0) {
                int barColor = AnimationUtils.colorLerp(
                    0xFF000000 | stripRGB,
                    0xFFFFFFFF,
                    1f - barProgress);
                ctx.fill(x+4, y+HEIGHT-3, x+4+barW, y+HEIGHT-1,
                    (barA << 24) | (barColor & 0x00FFFFFF));
            }

            stackIdx++;
        }
    }

    private static int getTypeColor(Type type, Theme t) {
        return switch (type) {
            case SUCCESS -> t.positive & 0x00FFFFFF;
            case WARNING -> t.negative & 0x00FFFFFF;
            case TOGGLE  -> t.accent   & 0x00FFFFFF;
            default      -> 0x8899BB;
        };
    }

    private static String getTypeIcon(Type type) {
        return switch (type) {
            case SUCCESS -> "✔";
            case WARNING -> "✗";
            case TOGGLE  -> "⚡";
            default      -> "◈";
        };
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private static class Notification {
        final String title, message;
        final Type   type;
        final long   duration, startTime;

        // Spring-state для slide
        float slideVal = 0f;
        float slideVel = 0f;
        float lastBarProgress = 1f;

        Notification(String title, String message, Type type, long duration) {
            this.title     = title;
            this.message   = message;
            this.type      = type;
            this.duration  = duration;
            this.startTime = System.currentTimeMillis();
        }

        boolean isExpired() {
            return System.currentTimeMillis() - startTime > duration + 600;
        }

        float getAlpha() {
            long elapsed = System.currentTimeMillis() - startTime;
            float fadeIn  = 180f, fadeOut = 450f;
            if (elapsed < fadeIn)  return AnimationUtils.easeOutCubic(elapsed / fadeIn);
            if (elapsed > duration - fadeOut)
                return AnimationUtils.clamp((duration - elapsed) / fadeOut, 0f, 1f);
            return 1f;
        }

        float getSlideInSpring() {
            slideVal = AnimationUtils.premiumSpring(slideVal, 1f, new float[]{slideVel}, 0.12f, 0.78f);
            return slideVal;
        }

        float getProgress() {
            long elapsed = System.currentTimeMillis() - startTime;
            return AnimationUtils.clamp(1f - (float) elapsed / duration, 0f, 1f);
        }
    }
}
