package net.enkuron.ui.gui;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.ScissorStack;
import net.enkuron.utils.SoundEngine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * MinimalGUI — чистый минималистичный стиль.
 * Серые тона, никаких градиентов, простые прямоугольники.
 * Все модули одного списка, без вкладок — максимум читаемости.
 *
 * FIX 1: ПКМ по модулю открывает панель настроек (settingsModule).
 * FIX 2: Панель настроек рендерится справа от основного списка.
 * FIX 3: keyPressed/charTyped подключены к поиску (searchQuery).
 */
public class MinimalGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final int W       = 160;
    private static final int ROW_H   = 20;
    private static final int PAD     = 6;
    private static final int SETT_W  = 140;  // ширина панели настроек
    private static final int SETT_H  = 20;   // высота строки настройки

    private int panelX = 20, panelY = 20;
    private Module.Category filterCat = null;
    private float scrollOff = 0;
    private Module settingsModule = null;
    private Setting draggingSetting = null;
    private int sliderBx, sliderBw;
    private boolean draggingPanel = false;
    private int dragOX, dragOY;

    /** Поисковый запрос — FIX: keyPressed/charTyped теперь работают */
    private String searchQuery = "";

    // Smooth animations
    private float openAnim     = 0f;
    private float settingsAnim = 0f;
    private final java.util.Map<String, Float> toggleAnims = new java.util.HashMap<>();
    private final java.util.Map<String, Float> hoverAnims  = new java.util.HashMap<>();

    private static final Module.Category[] CATS = Module.Category.values();

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Smooth opening animation
        openAnim = AnimationUtils.lerp(openAnim, 1f, 0.12f);
        float easedOpen = AnimationUtils.easeOutBack(openAnim);

        Theme t = ThemeManager.get();
        List<Module> mods = ModuleManager.getModules().stream()
            .filter(m -> filterCat == null || m.getCategory() == filterCat)
            .filter(m -> searchQuery.isEmpty()
                    || m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
            .toList();

        int h = 24 + 22 + 20 + mods.size() * ROW_H + 4; // +20 для строки поиска
        ctx.fill(panelX, panelY, panelX+W, panelY+h, 0xEE111116);
        ctx.fill(panelX, panelY, panelX+W, panelY+1, t.accent);

        // Заголовок
        ctx.drawText(mc.textRenderer, "§lEnkuron §8[Minimal]",
                     panelX+PAD, panelY+8, t.accent, false);

        // Категории — горизонтальный фильтр
        int catY = panelY + 22;
        ctx.fill(panelX, catY, panelX+W, catY+18, 0x55000000);
        boolean allActive = filterCat == null;
        if (allActive) ctx.fill(panelX, catY+16, panelX+20, catY+18, t.accent);
        ctx.drawText(mc.textRenderer, "All", panelX+4, catY+5,
                     allActive ? t.text : t.textMuted, false);
        int cx = panelX + 24;
        for (Module.Category cat : CATS) {
            String s = cat.name().substring(0,2).toUpperCase();
            int sw = mc.textRenderer.getWidth(s) + 4;
            boolean active = filterCat == cat;
            if (active) ctx.fill(cx, catY+16, cx+sw, catY+18, t.accent);
            ctx.drawText(mc.textRenderer, s, cx+2, catY+5,
                         active ? t.text : t.textMuted, false);
            cx += sw + 2;
        }

        // Строка поиска
        int searchY = catY + 20;
        ctx.fill(panelX, searchY, panelX+W, searchY+18, 0x44000000);
        ctx.fill(panelX, searchY, panelX+W, searchY+1, 0xFF333344);
        String searchDisplay = searchQuery.isEmpty() ? "§8Search..." : "§f" + searchQuery + "§7|";
        ctx.drawText(mc.textRenderer, searchDisplay, panelX+PAD, searchY+5, t.textMuted, false);

        // Список модулей
        int listY = searchY + 20;
        int y = listY + (int)(-scrollOff);
        int listH = Math.max(0, mods.size() * ROW_H);
        if (listH > 0) ScissorStack.push(panelX, listY, W, listH);
        for (Module mod : mods) {
            if (y + ROW_H < listY || y > listY + h) { y += ROW_H; continue; }
            boolean on    = mod.isEnabled();
            boolean hover = mx >= panelX && mx < panelX+W && my >= y && my < y+ROW_H-1;
            boolean isSettingsOpen = settingsModule == mod;

            ctx.fill(panelX, y, panelX+W, y+ROW_H-2, hover ? 0x22FFFFFF : 0x00000000);
            // Индикатор вкл/выкл — жёлтый если открыты настройки
            int sideColor = isSettingsOpen ? t.accent : (on ? t.accent : t.accentA(60));
            ctx.fill(panelX, y, panelX+2, y+ROW_H-2, sideColor);
            ctx.drawText(mc.textRenderer, mod.getName(), panelX+6, y+6,
                         on ? t.text : t.textMuted, false);
            // Иконка настроек справа если есть настройки
            if (!mod.getSettings().isEmpty()) {
                ctx.drawText(mc.textRenderer, isSettingsOpen ? "§b⚙" : "§8⚙",
                             panelX+W-14, y+6, 0xFFFFFFFF, false);
            }
            ctx.fill(panelX+W-8, y+8, panelX+W-5, y+11, on ? t.positive : 0xFF444455);
            y += ROW_H;
        }
        if (listH > 0) ScissorStack.pop();

        // FIX 2: Панель настроек открытого модуля — рисуем справа
        if (settingsModule != null) {
            renderSettingsPanel(ctx, mx, my, t);
        }
    }

    /** Рендер панели настроек справа от основного списка. */
    private void renderSettingsPanel(DrawContext ctx, int mx, int my, Theme t) {
        List<Setting> settings = settingsModule.getSettings();
        if (settings.isEmpty()) return;

        // Animate settings panel
        settingsAnim = AnimationUtils.lerp(settingsAnim, 1f, 0.13f);
        float easedSettings = AnimationUtils.smoothStep(settingsAnim);
        int settingsW = (int)(SETT_W * easedSettings);
        if (settingsW < 4) return;

        int sx = panelX + W + 4;
        int sy = panelY;
        int sh = 22 + settings.size() * SETT_H + 4;

        // Shadow
        for (int i = 4; i >= 1; i--) {
            int sa = 30 / (i + 1);
            ctx.fill(sx+i, sy+i, sx+settingsW+i, sy+sh+i, (sa << 24));
        }

        ctx.fill(sx, sy, sx+settingsW, sy+sh, 0xEE111116);
        ctx.fill(sx, sy, sx+settingsW, sy+1, t.accent);
        ctx.fill(sx, sy, sx+1, sy+sh, (int)(easedSettings * 0x30) << 24 | (t.accent & 0xFFFFFF));
        ctx.drawText(mc.textRenderer, "§7" + settingsModule.getName() + " §8settings",
                     sx+PAD, sy+8, t.textMuted, false);

        int y = sy + 22;
        for (Setting s : settings) {
            ctx.fill(sx, y, sx+SETT_W, y+SETT_H, 0xFF181820);
            ctx.fill(sx, y+SETT_H-1, sx+SETT_W, y+SETT_H, 0xFF222233);
            ctx.drawText(mc.textRenderer, s.getName(), sx+PAD, y+2, t.textMuted, false);

            switch (s.getType()) {
                case BOOLEAN -> {
                    int btnX = sx + SETT_W - 28;
                    ctx.fill(btnX, y+4, btnX+24, y+14,
                             s.getState() ? t.accent : 0xFF333344);
                    ctx.drawText(mc.textRenderer, s.getState() ? "ON" : "OFF",
                                 btnX+3, y+6, 0xFFFFFFFF, false);
                }
                case NUMBER -> {
                    int bw = SETT_W - PAD*2;
                    float ratio = (float)((s.getValue()-s.getMin())/(s.getMax()-s.getMin()));
                    ctx.fill(sx+PAD, y+12, sx+PAD+bw, y+16, 0xFF2A2A3A);
                    ctx.fill(sx+PAD, y+12, sx+PAD+(int)(bw*ratio), y+16, t.accent);
                    String val = String.format("%.1f", s.getValue());
                    ctx.drawText(mc.textRenderer, val,
                                 sx+SETT_W-mc.textRenderer.getWidth(val)-PAD, y+2,
                                 t.text, false);
                }
                case ENUM -> {
                    String opt = "< " + s.getCurrentOption() + " >";
                    ctx.drawText(mc.textRenderer, opt,
                                 sx+SETT_W-mc.textRenderer.getWidth(opt)-PAD, y+2,
                                 t.text, false);
                }
            }
            y += SETT_H;
        }
    }

    @Override
    public void mouseClicked(double mx, double my, int btn) {
        // Клик по панели настроек
        if (settingsModule != null) {
            List<Setting> settings = settingsModule.getSettings();
            int sx = panelX + W + 4;
            int sy = panelY + 22;
            for (Setting s : settings) {
                if (mx >= sx && mx < sx+SETT_W && my >= sy && my < sy+SETT_H) {
                    switch (s.getType()) {
                        case BOOLEAN -> s.toggleState();
                        case ENUM    -> { if (btn == 0) s.cycleOption(); }
                        case NUMBER  -> {
                            int bw = SETT_W - PAD*2;
                            double r = Math.max(0, Math.min(1, (mx-sx-PAD)/bw));
                            s.setValue(s.getMin() + r*(s.getMax()-s.getMin()));
                            draggingSetting = s;
                            sliderBx = sx + PAD;
                            sliderBw = bw;
                        }
                    }
                    return;
                }
                sy += SETT_H;
            }
            // Клик вне панели настроек — закрыть
            if (mx < panelX + W + 4) settingsModule = null;
        }

        if (btn == 0 && mx >= panelX && mx < panelX+W && my >= panelY && my < panelY+22) {
            draggingPanel = true; dragOX = (int)(mx-panelX); dragOY = (int)(my-panelY); return;
        }
        // Фильтр по категории
        int catY = panelY + 22;
        if (my >= catY && my < catY+18) {
            if (mx >= panelX && mx < panelX+20) { filterCat = null; SoundEngine.playCategoryChange(); return; }
            int cx = panelX + 24;
            for (Module.Category cat : CATS) {
                String s = cat.name().substring(0,2);
                int sw = mc.textRenderer.getWidth(s) + 4;
                if (mx >= cx && mx < cx+sw) { filterCat = cat; SoundEngine.playCategoryChange(); return; }
                cx += sw + 2;
            }
        }
        // Тоглы модулей
        List<Module> mods = ModuleManager.getModules().stream()
            .filter(m -> filterCat == null || m.getCategory() == filterCat)
            .filter(m -> searchQuery.isEmpty()
                    || m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
            .toList();
        int listY = catY + 20 + 20; // +20 за строку поиска
        int y = listY + (int)(-scrollOff);
        for (Module mod : mods) {
            if (my >= y && my < y+ROW_H-1 && mx >= panelX && mx < panelX+W) {
                // FIX 1: ПКМ открывает панель настроек
                if (btn == 1) {
                    settingsModule = settingsModule == mod ? null : mod;
                    SoundEngine.playSettingsOpen();
                    return;
                }
                mod.toggle();
                if (mod.isEnabled()) SoundEngine.playModuleOn();
                else                 SoundEngine.playModuleOff();
                return;
            }
            y += ROW_H;
        }
    }

    @Override public void mouseReleased(double mx, double my, int btn) {
        draggingPanel = false;
        draggingSetting = null;
    }

    @Override public void mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingPanel) { panelX = (int)(mx-dragOX); panelY = (int)(my-dragOY); }
        if (draggingSetting != null) {
            double r = Math.max(0, Math.min(1, (mx-sliderBx)/(double)sliderBw));
            draggingSetting.setValue(
                draggingSetting.getMin() + r*(draggingSetting.getMax()-draggingSetting.getMin()));
        }
    }

    @Override public void mouseScrolled(double mx, double my, double sx, double sy) {
        if (mx >= panelX && mx < panelX+W) scrollOff = Math.max(0, scrollOff - (float)(sy*10));
    }

    /** FIX 3: Поиск по нажатию клавиш — Backspace стирает, остальные символы добавляют. */
    @Override
    public void keyPressed(int key, int scan, int mods) {
        if (key == 259 /* BACKSPACE */ && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
        } else if (key == 256 /* ESCAPE */) {
            searchQuery = "";
        }
    }

    @Override
    public void charTyped(char c, int mods) {
        if (c >= 32 && searchQuery.length() < 24) {
            searchQuery += c;
        }
    }
}
