package net.enkuron.ui.clickgui;

import net.enkuron.ui.gui.GUIManager;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.ConfigManager;
import net.enkuron.utils.ScissorStack;
import net.enkuron.utils.SoundEngine;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * EnkuronMenu v11 — обёртка над GUIManager.
 *
 * Клавиши:
 *   G      — сменить GUI стиль (Modern → Neon → Minimal → Classic)
 *   T      — сменить тему
 *   P      — открыть экран профилей (сохранение/загрузка/удаление конфигов)
 *   Escape — закрыть и сохранить
 */
public class EnkuronMenu extends Screen {

    public EnkuronMenu() {
        super(Text.literal("Enkuron"));
        // FIX: GUIManager.init() убран отсюда — он вызывался при КАЖДОМ открытии меню,
        // что сбрасывало все позиции, скролл и состояние GUI (searchQuery, expandedModule и т.д.)
        // init() теперь вызывается один раз из Enkuron.onInitializeClient().
    }

    @Override
    protected void init() {
        super.init();
        // ── Пункт 9: Звук открытия GUI ───────────────────────────────────
        SoundEngine.playGuiOpen();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Убираем дефолтный тёмный оверлей — BlurShader в AuroraGUI сам рисует фон
        GUIManager.render(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) { GUIManager.mouseClicked(mx, my, btn); return true; }
    @Override public boolean mouseReleased(double mx, double my, int btn) { GUIManager.mouseReleased(mx, my, btn); return true; }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) { GUIManager.mouseDragged(mx, my, btn, dx, dy); return true; }
    @Override public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) { GUIManager.mouseScrolled(mx, my, hAmt, vAmt); return true; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_G) { GUIManager.nextStyle(); return true; }
        if (keyCode == GLFW.GLFW_KEY_T) { ThemeManager.next(); return true; }
        if (keyCode == GLFW.GLFW_KEY_P) { this.client.setScreen(new net.enkuron.ui.ProfileScreen(this)); return true; }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { ConfigManager.save(); this.client.setScreen(null); return true; }
        GUIManager.keyPressed(keyCode, scanCode, modifiers);
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean charTyped(char chr, int modifiers) { GUIManager.charTyped(chr, modifiers); return super.charTyped(chr, modifiers); }

    @Override
    public void close() {
        // ── Пункт 9: Звук закрытия GUI ───────────────────────────────────
        SoundEngine.playGuiClose();
        ScissorStack.clear(); // очистить scissor-стек на случай незавершённого render
        ConfigManager.save();
        super.close();
    }

    @Override public boolean shouldPause() { return false; }
}

