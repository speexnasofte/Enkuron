package net.enkuron.ui.gui;

import net.enkuron.modules.ColorSetting;
import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.enkuron.utils.ScissorStack;
import net.enkuron.utils.SoundEngine;
import net.enkuron.visuals.BlurShader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;

/**
 * AuroraGUI v1 — Эксклюзивный GUI «Северное Сияние» для Enkuron v2.
 *
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  УНИКАЛЬНЫЕ ФИЧИ (нет ни в одном другом GUI клиента):           ║
 * ║  • Aurora background — живые волны северного сияния             ║
 * ║  • Flowing particles — частицы плывут по панели                 ║
 * ║  • Ripple-эффект при клике на модуль (круговая волна)           ║
 * ║  • Liquid toggle — переключатель плывёт как жидкость            ║
 * ║  • Breathing panel — панель «дышит» (пульсирует alpha)          ║
 * ║  • Staggered entrance — каждый модуль влетает с задержкой       ║
 * ║  • Aurora glow за иконками категорий                            ║
 * ║  • Color wave — имя каждого модуля переливается цветом          ║
 * ║  • Slide-to-search — поиск вылетает сбоку                      ║
 * ╠══════════════════════════════════════════════════════════════════╣
 * ║  СТАНДАРТНЫЕ ФИЧИ:                                              ║
 * ║  • Drag & Drop панели                                           ║
 * ║  • Scroll с инерцией + momentum                                 ║
 * ║  • Настройки: слайдер, булево, enum, ColorSetting              ║
 * ║  • Поиск по всем категориям (Ctrl+F)                            ║
 * ║  • Escape-цепочка: настройки → поиск → закрытие                ║
 * ║  • Keybind бейдж у каждого модуля                               ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * Дизайн-концепция: чёрная панель + aurora-волны поверх (зелёный/голубой/фиолетовый).
 * Все цвета «полярного сияния» заданы внутри GUI — не зависят от Theme.
 */
public class AuroraGUI implements ClickGUI {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ─────────────────────────────────────────────────────────────────────────
    // РАЗМЕРЫ
    // ─────────────────────────────────────────────────────────────────────────
    private static final int SIDE_W   = 56;
    private static final int MOD_W    = 186;
    private static final int SET_W    = 206;
    private static final int PANEL_H  = 390;
    private static final int HEADER_H = 44;
    private static final int CAT_ROW  = 46;
    private static final int MOD_ROW  = 28;
    private static final int SEARCH_H = 26;

    // ─────────────────────────────────────────────────────────────────────────
    // AURORA ЦВЕТА
    // ─────────────────────────────────────────────────────────────────────────
    private static final int AUR_BG      = 0xF2080C14;  // почти чёрный с синим оттенком
    private static final int AUR_PANEL   = 0xE80C1020;  // тёмно-синяя панель
    private static final int AUR_SIDE    = 0xF0060A12;  // sidebar чуть темнее
    private static final int AUR_HOVER   = 0x2000E5CC;  // aurora-cyan hover
    private static final int AUR_ACTIVE  = 0x3000AAAA;  // активный фон
    private static final int AUR_SEARCH  = 0xCC050810;  // фон строки поиска

    // Aurora-цвета волн (используются в gradients)
    private static final int[] AURORA_COLORS = {
        0xFF00E5CC,  // aurora-cyan
        0xFF00FF88,  // aurora-green
        0xFF8844FF,  // aurora-violet
        0xFF0088FF,  // aurora-blue
        0xFF00FFAA,  // aurora-mint
        0xFFAA44FF,  // aurora-purple
    };

    // ─────────────────────────────────────────────────────────────────────────
    // КАТЕГОРИИ
    // ─────────────────────────────────────────────────────────────────────────
    private static final Module.Category[] CATS = {
        Module.Category.COMBAT,   Module.Category.MOVEMENT, Module.Category.VISUAL,
        Module.Category.PLAYER,   Module.Category.HUD,      Module.Category.UTILITY,
        Module.Category.MISC
    };
    private static final String[] CAT_ICONS = { "⚔", "⚡", "✦", "♟", "◈", "⚙", "★" };
    private static final String[] CAT_NAMES = {
        "Combat", "Movement", "Visual", "Player", "HUD", "Utility", "Misc"
    };
    // Aurora-цвет для каждой категории (для sidebar glow)
    private static final int[] CAT_AURA = {
        0xFFFF4466,  // Combat — красный
        0xFF44DDFF,  // Movement — голубой
        0xFF00E5CC,  // Visual — cyan
        0xFF8844FF,  // Player — фиолетовый
        0xFF00FF88,  // HUD — зелёный
        0xFFFFAA00,  // Utility — золотой
        0xFFAA44FF,  // Misc — пурпурный
    };

    // ─────────────────────────────────────────────────────────────────────────
    // СОСТОЯНИЕ
    // ─────────────────────────────────────────────────────────────────────────
    private int     panelX    = Integer.MIN_VALUE;
    private int     panelY    = 0;
    private boolean centered  = false;

    private int    activeCatIdx  = 0;
    private int    lastCatIdx    = -1;
    private Module settingsMod   = null;

    // ── Анимации открытия/закрытия ────────────────────────────────────────
    private float openAnim      = 0f;  // 0→1 при открытии GUI
    private float settingsAnim  = 0f;  // 0→1 при открытии настроек
    private float searchSlide   = 0f;  // 0→1 поиск вылетает сбоку

    // ── Toggle «жидкость» ─────────────────────────────────────────────────
    // uid → позиция бегунка [0..1] (анимируется плавно)
    private final Map<String, Float>  togglePos   = new HashMap<>();
    // uid → velocity для spring-эффекта
    private final Map<String, float[]> toggleVel  = new HashMap<>();

    // ── Staggered entrance ────────────────────────────────────────────────
    // uid → [0..1] каждый модуль влетает по очереди
    private final Map<String, Float>  staggerAnim = new HashMap<>();
    // uid → стартовое время появления (мс)
    private final Map<String, Long>   staggerTime = new HashMap<>();

    // ── Ripple (волна при клике) ──────────────────────────────────────────
    private static class Ripple {
        int cx, cy;             // центр
        float progress = 0f;   // 0→1
        int color;
        Ripple(int cx, int cy, int color) { this.cx = cx; this.cy = cy; this.color = color; }
    }
    private final List<Ripple> ripples = new ArrayList<>();

    // ── Частицы aurora ────────────────────────────────────────────────────
    private static class AuroraParticle {
        float x, y, vx, vy;
        float life = 1f; // 1→0
        int color;
        AuroraParticle(float x, float y, int color) {
            this.x = x; this.y = y;
            this.vx = (float)(Math.random() * 0.4 - 0.2);
            this.vy = (float)(Math.random() * -0.6 - 0.1);
            this.color = color;
        }
    }
    private final List<AuroraParticle> particles = new ArrayList<>();
    private long lastParticleSpawn = 0;

    // ── Hover-анимации ─────────────────────────────────────────────────────
    private final Map<Integer,  Float> catHovAnim  = new HashMap<>(); // cat idx → 0..1
    private final Map<String,   Float> modHovAnim  = new HashMap<>(); // uid → 0..1
    // ── Icon wobble (пункт 10) ────────────────────────────────────────────
    // Иконки покачиваются/пульсируют при наведении
    private final Map<Integer, Float>   catWobble   = new HashMap<>(); // cat idx → wobble phase
    private final Map<Integer, Float>   catWobbleV  = new HashMap<>(); // cat idx → velocity
    // ── Blur за GUI (пункт 6) ─────────────────────────────────────────────
    private float blurAnim = 0f; // 0→1 при открытии GUI

    // ── Scroll ────────────────────────────────────────────────────────────
    private float scrollCur = 0f;
    private float scrollTgt = 0f;
    private float scrollMom = 0f;

    // ── Drag ──────────────────────────────────────────────────────────────
    private boolean draggingPanel = false;
    private int dragOffX, dragOffY;

    // ── Поиск ─────────────────────────────────────────────────────────────
    private boolean searchActive = false;
    private String  searchQuery  = "";

    // ── Settings slider drag ───────────────────────────────────────────────
    private Setting draggingSlider = null;
    private int     sliderX0, sliderW0;

    // ── Время (для aurora-волн) ───────────────────────────────────────────
    private float timeMs = 0f; // обновляется каждый кадр

    // ── Category change flash ─────────────────────────────────────────────
    private float catFlash = 0f;  // 1→0 вспышка при смене категории

    // ── Keybind binding mode ──────────────────────────────────────────────
    // null = не в режиме биндинга; иначе — модуль ожидающий клавишу
    private Module bindingModule = null;
    private float  bindingPulse  = 0f; // sin-фаза для мигания

    // ── Tooltip при hover ─────────────────────────────────────────────────
    private Module tooltipMod    = null;  // текущий модуль под курсором
    private long   tooltipHoverStart = 0L; // когда начали наводить
    private float  tooltipAlpha  = 0f;   // 0→1 плавное появление

    // ─────────────────────────────────────────────────────────────────────────
    // RENDER
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        timeMs = (System.currentTimeMillis() % 1_000_000) / 1000f;

        // ── Пункт 1: FPS-независимые анимации через delta-time ─────────────
        // delta приходит от Minecraft как partialTick (0..1 между тиками).
        // Нормализуем в реальное время кадра в секундах.
        float dt = delta / 20f; // 20 ticks/sec → секунды на кадр

        // Центрирование при первом показе
        if (!centered) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            panelX = (sw - SIDE_W - MOD_W) / 2 - SIDE_W / 2;
            panelY = (sh - PANEL_H) / 2;
            centered = true;
        }

        // ── Анимация открытия (spring bounce) — delta-time ───────────────
        openAnim = AnimationUtils.lerpDelta(openAnim, 1f, 0.09f, dt * 60f);
        float easedOpen = AnimationUtils.easeOutBack(AnimationUtils.smootherStep(openAnim));
        int ph = (int)(PANEL_H * easedOpen);
        if (ph < 4) return;

        // ── Пункт 6: Blur за GUI ─────────────────────────────────────────
        // Анимируем blur вместе с открытием
        blurAnim = AnimationUtils.lerpDelta(blurAnim, 1f, 0.12f, dt * 60f);
        if (blurAnim > 0.02f) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            BlurShader.setRadius(10f);
            BlurShader.setAlpha(blurAnim * 0.65f);
            BlurShader.drawBlurredBackground(ctx, 0, 0, sw, sh);
        }

        // ── Анимация настроек ─────────────────────────────────────────────
        float saTarget = settingsMod != null ? 1f : 0f;
        settingsAnim   = AnimationUtils.lerpDelta(settingsAnim, saTarget, 0.12f, dt * 60f);
        int settingsW  = (int)(SET_W * AnimationUtils.smoothStep(settingsAnim));

        // ── Анимация поиска (slide из-за правого края) ────────────────────
        float searchTarget = searchActive ? 1f : 0f;
        // Пункт 1: delta-time независимая анимация поиска
        searchSlide = AnimationUtils.lerpDelta(searchSlide, searchTarget, 0.16f, dt * 60f);

        // ── Пункт 7: Momentum scroll — обновляется каждый render-кадр ────
        // scrollMom обновляется здесь (render), а не в onTick — правильно!
        scrollMom *= (float)Math.pow(0.78f, dt * 60f); // FPS-независимое затухание
        scrollTgt += scrollMom;
        scrollTgt  = Math.max(0f, scrollTgt);
        scrollCur  = AnimationUtils.lerpDelta(scrollCur, scrollTgt, 0.14f, dt * 60f);

        // ── Вспышка смены категории ────────────────────────────────────────
        catFlash = AnimationUtils.lerpDelta(catFlash, 0f, 0.07f, dt * 60f);

        // ── Обновить частицы ─────────────────────────────────────────────
        updateParticles(panelX, panelY, ph, ph > 20);

        // ── Ripple ────────────────────────────────────────────────────────
        ripples.removeIf(r -> r.progress >= 1f);
        for (Ripple r : ripples) r.progress = AnimationUtils.lerp(r.progress, 1f, 0.055f);

        Theme t = ThemeManager.get();
        int totalW = SIDE_W + MOD_W + settingsW;

        // ── Мягкая тень GUI ───────────────────────────────────────────────
        drawSoftShadow(ctx, panelX - 6, panelY - 6, totalW + 12, ph + 12, 6);

        // ── Основной фон ──────────────────────────────────────────────────
        ctx.fill(panelX, panelY, panelX + totalW, panelY + ph, AUR_BG);

        // ── Aurora-волны поверх фона ──────────────────────────────────────
        drawAuroraWaves(ctx, panelX, panelY, totalW, ph);

        // ── Частицы ───────────────────────────────────────────────────────
        drawParticles(ctx, panelX, panelY, ph);

        // ── Три колонки ───────────────────────────────────────────────────
        drawSidebar(ctx, panelX, panelY, ph, mx, my, t);
        drawModuleList(ctx, panelX + SIDE_W, panelY, ph, mx, my, t);
        if (settingsW > 4) {
            drawSettingsPanel(ctx, panelX + SIDE_W + MOD_W, panelY, ph, settingsW, mx, my, t);
        }

        // ── Ripple-волны (поверх всего) ────────────────────────────────────
        drawRipples(ctx, panelX, panelY, totalW, ph);

        // ── Tooltip при hover на модуль (0.5с задержка) ──────────────────
        drawTooltip(ctx, mx, my);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AURORA WAVES — ЖИВЫЕ ВОЛНЫ СЕВЕРНОГО СИЯНИЯ
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Рисует несколько синусоидальных «слоёв» aurora.
     * Каждая волна — набор горизонтальных полос с alpha, сдвинутых по фазе.
     * Уникальная фича — нет ни в одном другом GUI Fabric.
     */
    private void drawAuroraWaves(DrawContext ctx, int x, int y, int w, int h) {
        // Рисуем 3 слоя aurora с разными скоростями и цветами
        drawAuroraLayer(ctx, x, y, w, h,
            AURORA_COLORS[0], AURORA_COLORS[4],
            0.35f, 0.6f, timeMs * 0.4f, 0.20f);
        drawAuroraLayer(ctx, x, y, w, h,
            AURORA_COLORS[2], AURORA_COLORS[3],
            0.55f, 0.9f, timeMs * 0.25f + 1.5f, 0.14f);
        drawAuroraLayer(ctx, x, y, w, h,
            AURORA_COLORS[5], AURORA_COLORS[1],
            0.15f, 0.45f, timeMs * 0.55f + 3.0f, 0.10f);
    }

    /**
     * Один слой aurora: цветная горизонтальная волна.
     * yCenter — относительная позиция центра [0..1]
     * yWidth  — ширина волны [0..1]
     */
    private void drawAuroraLayer(DrawContext ctx, int x, int y, int w, int h,
                                  int col1, int col2, float yCenter, float yWidth,
                                  float phase, float maxAlphaFrac) {
        int maxAlpha = (int)(255 * maxAlphaFrac);
        int stripH = 2;
        int steps = h / stripH + 1;
        for (int i = 0; i < steps; i++) {
            float fy = (float) i / steps;
            // Волнообразное смещение центра по X
            float waveShift = (float) Math.sin(fy * 6.0 + phase) * 0.08f;
            float adjustedCenter = yCenter + (float) Math.sin(phase * 0.5f + fy * 2.0f) * 0.06f;
            // Гауссово распределение alpha от центра волны
            float dist = Math.abs(fy - adjustedCenter) / (yWidth * 0.5f);
            float gaussAlpha = (float) Math.exp(-dist * dist * 2.0f);
            // Дополнительная пульсация
            float pulse = 0.7f + 0.3f * (float) Math.sin(phase * 1.3f + fy * 4.0f);
            int alpha = (int)(maxAlpha * gaussAlpha * pulse);
            if (alpha < 3) continue;
            // Интерполяция цвета по X + волновой сдвиг
            float tColor = 0.5f + 0.5f * (float) Math.sin(fy * 4.0f + phase * 0.7f + waveShift * 10f);
            int color = lerpColor(col1, col2, tColor, alpha);
            int sy = y + i * stripH;
            ctx.fill(x, sy, x + w, sy + stripH, color);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PARTICLES — ПЛАВАЮЩИЕ ЧАСТИЦЫ
    // ─────────────────────────────────────────────────────────────────────────

    private void updateParticles(int px, int py, int ph, boolean active) {
        if (!active) { particles.clear(); return; }
        long now = System.currentTimeMillis();
        if (now - lastParticleSpawn > 180 && particles.size() < 28) {
            lastParticleSpawn = now;
            int spawnX = (int)(px + Math.random() * (SIDE_W + MOD_W));
            int spawnY = py + ph;
            int col = AURORA_COLORS[(int)(Math.random() * AURORA_COLORS.length)];
            particles.add(new AuroraParticle(spawnX, spawnY, col));
        }
        Iterator<AuroraParticle> it = particles.iterator();
        while (it.hasNext()) {
            AuroraParticle p = it.next();
            p.x  += p.vx;
            p.y  += p.vy;
            p.vx += (float)(Math.random() * 0.06 - 0.03);
            p.life -= 0.012f;
            if (p.life <= 0 || p.y < py - 4) it.remove();
        }
    }

    private void drawParticles(DrawContext ctx, int px, int py, int ph) {
        for (AuroraParticle p : particles) {
            int alpha = (int)(p.life * 140);
            if (alpha < 5) continue;
            int color = (alpha << 24) | (p.color & 0x00FFFFFF);
            int ix = (int) p.x;
            int iy = (int) p.y;
            ctx.fill(ix, iy, ix + 2, iy + 2, color);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // RIPPLE — ВОЛНА ПРИ КЛИКЕ
    // ─────────────────────────────────────────────────────────────────────────

    private void drawRipples(DrawContext ctx, int px, int py, int totalW, int ph) {
        for (Ripple r : ripples) {
            float t  = AnimationUtils.easeOutQuad(r.progress);
            int   radius = (int)(t * 60);
            int   alpha  = (int)((1f - t) * 55);
            if (alpha < 2 || radius < 2) continue;
            int color = (alpha << 24) | (r.color & 0x00FFFFFF);
            // Рисуем кольца концентрически
            for (int ring = 0; ring < 3; ring++) {
                int ro = radius - ring * 8;
                if (ro < 2) continue;
                int ra = alpha / (ring + 1);
                int rc = (ra << 24) | (r.color & 0x00FFFFFF);
                drawCircleOutline(ctx, r.cx, r.cy, ro, rc);
            }
        }
    }

    /** Рисует окружность пиксельными горизонтальными отрезками */
    private void drawCircleOutline(DrawContext ctx, int cx, int cy, int radius, int color) {
        int thickness = 1;
        for (int angle = 0; angle < 360; angle += 5) {
            double rad = Math.toRadians(angle);
            int rx = (int)(cx + radius * Math.cos(rad));
            int ry = (int)(cy + radius * Math.sin(rad));
            ctx.fill(rx, ry, rx + thickness, ry + thickness, color);
        }
    }

    /**
     * Tooltip — описание модуля появляется через 0.5с после наведения.
     * Обновляет tooltipMod по позиции мыши, затем рисует всплывающий бокс.
     */
    private void drawTooltip(DrawContext ctx, int mx, int my) {
        // Найти модуль под мышью
        Module hovered = null;
        int searchPanelH = (int)(SEARCH_H * searchSlide);
        int listY = panelY + HEADER_H + searchPanelH;
        List<Module> displayMods = searchActive && !searchQuery.isEmpty()
            ? ModuleManager.getAll().stream()
                .filter(m -> m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                .toList()
            : ModuleManager.getByCategory(CATS[activeCatIdx]);

        int scroll = (int) scrollCur;
        for (int i = 0; i < displayMods.size(); i++) {
            Module mod = displayMods.get(i);
            int my2 = listY + i * MOD_ROW - scroll;
            if (inBox(mx, my, panelX + SIDE_W, my2, MOD_W, MOD_ROW)) {
                hovered = mod;
                break;
            }
        }

        // Обновляем hover-таймер
        if (hovered != tooltipMod) {
            tooltipMod = hovered;
            tooltipHoverStart = System.currentTimeMillis();
            tooltipAlpha = 0f;
        }

        if (tooltipMod == null) { tooltipAlpha = 0f; return; }

        // 0.5с задержка
        long elapsed = System.currentTimeMillis() - tooltipHoverStart;
        if (elapsed < 500) { tooltipAlpha = 0f; return; }

        // Плавное появление
        tooltipAlpha = Math.min(1f, tooltipAlpha + 0.08f);
        if (tooltipAlpha < 0.02f) return;

        String desc = tooltipMod.getDescription();
        if (desc == null || desc.isEmpty()) return;

        int a = (int)(tooltipAlpha * 220);
        int tw = mc.textRenderer.getWidth(desc);
        int bw = tw + 10;
        int bh = 14;

        // Позиция: справа от курсора, не выходить за экран
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int tx = mx + 10;
        int ty = my + 4;
        if (tx + bw > sw - 4) tx = mx - bw - 4;
        if (ty + bh > sh - 4) ty = my - bh - 4;

        // Фон
        ctx.fill(tx - 1, ty - 1, tx + bw + 1, ty + bh + 1, (a/2) << 24 | 0x000000);
        ctx.fill(tx, ty, tx + bw, ty + bh, (int)(a * 0.85f) << 24 | 0x080C18);
        // Aurora-линия сверху
        ctx.fill(tx, ty, tx + bw, ty + 1, a << 24 | 0x00E5CC);
        // Текст
        ctx.drawText(mc.textRenderer, desc, tx + 5, ty + 3,
            (a << 24) | 0xAABBCC, false);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SIDEBAR — ЛЕВАЯ ПАНЕЛЬ С КАТЕГОРИЯМИ
    // ─────────────────────────────────────────────────────────────────────────

    private void drawSidebar(DrawContext ctx, int x, int y, int ph, int mx, int my, Theme t) {
        // Фон sidebar темнее основного
        ctx.fill(x, y, x + SIDE_W, y + ph, AUR_SIDE);

        // Разделительная линия справа (aurora-gradient)
        drawVerticalAuroraLine(ctx, x + SIDE_W - 1, y, ph, 0.6f);

        // Заголовок «ENKURON»
        int headerBot = y + HEADER_H;
        String logo = "✦";
        int lw = mc.textRenderer.getWidth(logo);
        // Переливающийся цвет заголовка
        int logoColor = auroraRainbow(0f, 0.5f);
        ctx.drawText(mc.textRenderer, logo, x + (SIDE_W - lw) / 2, y + 8, logoColor, false);
        String ver = "v2";
        int vw = mc.textRenderer.getWidth(ver);
        ctx.drawText(mc.textRenderer, ver, x + (SIDE_W - vw) / 2, y + 20, 0x6600E5CC, false);

        // Линия под заголовком
        ctx.fill(x + 6, headerBot - 1, x + SIDE_W - 6, headerBot, 0x3000E5CC);

        // Категории
        for (int i = 0; i < CATS.length; i++) {
            int cy2 = headerBot + i * CAT_ROW;
            boolean hover   = mx >= x && mx < x + SIDE_W && my >= cy2 && my < cy2 + CAT_ROW;
            boolean isActive = (i == activeCatIdx);

            // Hover-анимация
            float hov = catHovAnim.getOrDefault(i, 0f);
            hov = AnimationUtils.lerp(hov, hover ? 1f : 0f, 0.20f);
            catHovAnim.put(i, hov);

            // Active фон с aurora-цветом категории
            if (isActive) {
                int auraCol = CAT_AURA[i];
                // Боковая полоска — aurora-цвет
                ctx.fill(x, cy2, x + 2, cy2 + CAT_ROW, auraCol);
                // Фон активной категории
                int bgAlpha = 40 + (int)(catFlash * 60);
                ctx.fill(x + 2, cy2, x + SIDE_W, cy2 + CAT_ROW,
                    (bgAlpha << 24) | (auraCol & 0x00FFFFFF));
                // Glow: aurora-halo вокруг иконки
                drawAuroraGlow(ctx, x + SIDE_W / 2, cy2 + CAT_ROW / 2, 18, auraCol, 0.25f);
            } else if (hov > 0.01f) {
                int hovCol = CAT_AURA[i];
                ctx.fill(x + 2, cy2, x + SIDE_W, cy2 + CAT_ROW,
                    ((int)(hov * 25) << 24) | (hovCol & 0x00FFFFFF));
                ctx.fill(x, cy2, x + 1, cy2 + CAT_ROW,
                    ((int)(hov * 160) << 24) | (hovCol & 0x00FFFFFF));
            }

            // Иконка — aurora-цвет при активном, серый при неактивном
            int iconColor = isActive
                ? auroraRainbow((float)i / CATS.length, 0.3f)
                : lerpColor(0xFF666688, CAT_AURA[i], hov, 255);
            String icon = CAT_ICONS[i];
            int iw = mc.textRenderer.getWidth(icon);

            // ── Пункт 10: Анимированные иконки — wobble при наведении ────
            // При hover иконка покачивается (spring-осциллятор)
            // При active иконка пульсирует (breathing scale)
            float wobble = catWobble.getOrDefault(i, 0f);
            float wobbleV = catWobbleV.getOrDefault(i, 0f);

            if (hover) {
                // Spring-осциллятор: при наведении — толчок
                wobbleV += 0.18f;
            }
            // Dampened spring oscillation
            wobbleV -= wobble * 0.35f;  // spring
            wobbleV *= 0.72f;           // damping
            wobble += wobbleV;
            catWobble.put(i, wobble);
            catWobbleV.put(i, wobbleV);

            // Пульсация активной иконки
            float pulse = isActive
                ? (float)(Math.sin(timeMs * 2.2f + i) * 0.5f + 0.5f) * 0.8f  // breathing
                : 0f;

            // Итоговое смещение Y: wobble + pulse
            int iconOffsetY = (int)(wobble * 2.5f);
            int iconOffsetX = (int)(wobble * 1.2f);
            // Пульс — лёгкое вертикальное покачивание активной иконки
            iconOffsetY += (int)(pulse * 1.5f);

            ctx.drawText(mc.textRenderer, icon,
                x + (SIDE_W - iw) / 2 + iconOffsetX,
                cy2 + (CAT_ROW - 8) / 2 + iconOffsetY,
                iconColor, false);

            // Бейдж включённых модулей
            List<Module> mods = ModuleManager.getByCategory(CATS[i]);
            long enabled = mods.stream().filter(Module::isEnabled).count();
            if (enabled > 0) {
                String badge = String.valueOf(enabled);
                int bw = mc.textRenderer.getWidth(badge) + 4;
                int bx = x + SIDE_W - bw - 3;
                int by = cy2 + 3;
                int badgeCol = isActive ? CAT_AURA[i] : 0xFF444466;
                ctx.fill(bx, by, bx + bw, by + 9, (0xCC000000 | (badgeCol & 0x00FFFFFF)));
                ctx.drawText(mc.textRenderer, badge, bx + 2, by + 1, 0xFFFFFFFF, false);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MODULE LIST — ЦЕНТРАЛЬНАЯ ПАНЕЛЬ МОДУЛЕЙ
    // ─────────────────────────────────────────────────────────────────────────

    private void drawModuleList(DrawContext ctx, int x, int y, int ph, int mx, int my, Theme t) {
        ctx.fill(x, y, x + MOD_W, y + ph, AUR_PANEL);

        int headerBot = y + HEADER_H;

        // Header: название категории + счётчик + поиск
        String catName = CAT_NAMES[activeCatIdx];
        int catNameColor = auroraRainbow(0f, 0f);
        ctx.drawText(mc.textRenderer, catName, x + 10, y + 8, catNameColor, false);

        // Количество включённых
        List<Module> allMods = ModuleManager.getByCategory(CATS[activeCatIdx]);
        long enabledCount = allMods.stream().filter(Module::isEnabled).count();
        String countStr = enabledCount + "/" + allMods.size();
        ctx.drawText(mc.textRenderer, countStr,
            x + 10, y + 19, 0xFF666688, false);

        // Кнопка поиска
        int searchBtnX = x + MOD_W - 20;
        boolean hoverSearch = inBox(mx, my, searchBtnX, y + 8, 16, 12);
        int searchBtnCol = searchActive ? auroraRainbow(0.2f, 0f) : (hoverSearch ? 0xFFAAAAAA : 0xFF555577);
        ctx.drawText(mc.textRenderer, "⌕", searchBtnX, y + 8, searchBtnCol, false);

        // Кнопка закрыть настройки (×)
        if (settingsMod != null) {
            int closeBtnX = x + MOD_W - 36;
            boolean hoverClose = inBox(mx, my, closeBtnX, y + 8, 10, 10);
            ctx.drawText(mc.textRenderer, "✕", closeBtnX, y + 8,
                hoverClose ? 0xFFFF4466 : 0xFF555566, false);
        }

        // Кнопка Edit HUD (◈) и Профили (☰) в футере header
        int hudBtnX = x + MOD_W - 36;
        int proBtnX = x + MOD_W - 22;
        boolean hoverHud = inBox(mx, my, hudBtnX, y + 28, 12, 10);
        boolean hoverPro = inBox(mx, my, proBtnX, y + 28, 12, 10);
        ctx.drawText(mc.textRenderer, "◈", hudBtnX, y + 28,
            hoverHud ? auroraRainbow(0.3f, 0f) : 0xFF445566, false);
        ctx.drawText(mc.textRenderer, "☰", proBtnX, y + 28,
            hoverPro ? auroraRainbow(0.6f, 0f) : 0xFF445566, false);

        // Линия под header
        ctx.fill(x, headerBot - 1, x + MOD_W, headerBot, 0x3000E5CC);

        // Поисковая строка (slide-анимация)
        int searchY = headerBot;
        int searchPanelH = (int)(SEARCH_H * searchSlide);
        if (searchPanelH > 2) {
            ctx.fill(x, searchY, x + MOD_W, searchY + searchPanelH, AUR_SEARCH);
            int searchBorderAlpha = (int)(searchSlide * 60);
            ctx.fill(x, searchY + searchPanelH - 1, x + MOD_W, searchY + searchPanelH,
                (searchBorderAlpha << 24) | 0x00E5CC);
            if (searchSlide > 0.5f) {
                String qDisplay = "⌕ " + (searchQuery.isEmpty() ? "Search..." : searchQuery);
                int qColor = searchQuery.isEmpty() ? 0xFF444466 : 0xFFCCEEFF;
                ctx.drawText(mc.textRenderer, qDisplay, x + 6, searchY + (SEARCH_H - 8) / 2, qColor, false);
            }
        }
        int listY = searchY + searchPanelH;
        int listH  = ph - (listY - y);

        // Список модулей
        List<Module> displayMods = searchActive && !searchQuery.isEmpty()
            ? ModuleManager.getAll().stream()
                .filter(m -> m.getName().toLowerCase().contains(searchQuery.toLowerCase())
                          || m.getDescription().toLowerCase().contains(searchQuery.toLowerCase()))
                .toList()
            : allMods;

        // Сбросить stagger при смене категории
        if (lastCatIdx != activeCatIdx) {
            staggerAnim.clear();
            staggerTime.clear();
            scrollTgt = 0;
            lastCatIdx = activeCatIdx;
            catFlash = 1f;
        }

        // Скролл-ограничение
        int totalModH = displayMods.size() * MOD_ROW;
        float maxScroll = Math.max(0, totalModH - listH);
        scrollTgt = Math.min(scrollTgt, maxScroll);
        int scroll = (int) scrollCur;

        // ── Пункт 4: ScissorStack — правильный клиппинг скролл-области ────
        // Без этого модули вылезают за края панели при скролле!
        ScissorStack.push(x, listY, MOD_W, listH);

        // Clip (ручной culling — оставляем для производительности)
        int clipTop    = listY;
        int clipBottom = listY + listH;

        long now = System.currentTimeMillis();
        for (int i = 0; i < displayMods.size(); i++) {
            Module mod = displayMods.get(i);
            String uid = mod.getName();
            int my2  = listY + i * MOD_ROW - scroll;
            int mx2  = x;
            if (my2 + MOD_ROW < clipTop || my2 > clipBottom) continue;

            // Staggered entrance — каждый модуль появляется с задержкой
            if (!staggerTime.containsKey(uid)) {
                staggerTime.put(uid, now + i * 35L);
            }
            float stAnim = staggerAnim.getOrDefault(uid, 0f);
            if (now >= staggerTime.get(uid)) {
                stAnim = AnimationUtils.lerp(stAnim, 1f, 0.14f);
            }
            staggerAnim.put(uid, stAnim);

            // Сдвиг slide-in по X
            int slideX = (int)((1f - AnimationUtils.easeInOut(stAnim)) * 18f);
            int modDrawX = mx2 + slideX;
            float modAlpha = stAnim;

            // Hover
            boolean hover = !draggingPanel && inBox(mx, my, x, my2, MOD_W, MOD_ROW)
                && my2 >= clipTop && my2 + MOD_ROW <= clipBottom + 4;
            float hov = modHovAnim.getOrDefault(uid, 0f);
            hov = AnimationUtils.lerp(hov, hover ? 1f : 0f, 0.20f);
            modHovAnim.put(uid, hov);

            // Фон модуля
            boolean isActive = mod.isEnabled();
            if (isActive) {
                int aurCat = CAT_AURA[activeCatIdx];
                ctx.fill(modDrawX, my2, modDrawX + MOD_W - slideX, my2 + MOD_ROW,
                    mulAlpha(AUR_ACTIVE, (int)(modAlpha * 200)));
                ctx.fill(modDrawX, my2, modDrawX + 2, my2 + MOD_ROW,
                    mulAlpha(aurCat, (int)(modAlpha * 200)));
            } else if (hov > 0.01f) {
                ctx.fill(modDrawX, my2, modDrawX + MOD_W - slideX, my2 + MOD_ROW,
                    mulAlpha(AUR_HOVER, (int)(hov * modAlpha * 180)));
            }

            // Линия-разделитель (тонкая, aurora-цвет слабый)
            ctx.fill(mx2 + 8, my2 + MOD_ROW - 1, mx2 + MOD_W - 8, my2 + MOD_ROW,
                mulAlpha(0x00E5CC, (int)(modAlpha * 18)));

            // Название модуля — color wave при включённом
            String name = mod.getName();
            int nameColor;
            if (isActive) {
                // Переливание: каждая буква сдвинута по фазе
                nameColor = auroraRainbow((float)i / displayMods.size() + timeMs * 0.1f, 0f);
            } else {
                nameColor = lerpColor(0xFF666688, 0xFFCCDDFF, hov, (int)(modAlpha * 255));
            }
            ctx.drawText(mc.textRenderer, name,
                modDrawX + 10, my2 + (MOD_ROW - 8) / 2, nameColor, false);

            // Liquid Toggle — справа
            drawLiquidToggle(ctx, modDrawX + MOD_W - 32, my2 + (MOD_ROW - 10) / 2,
                mod, modAlpha);

            // Keybind бейдж / режим биндинга
            if (bindingModule == mod) {
                // Мигающий "Press a key..."
                bindingPulse += 0.15f;
                float pulse = (float)(Math.sin(bindingPulse) * 0.5 + 0.5);
                int blinkAlpha = (int)(modAlpha * (0.6f + 0.4f * pulse) * 255) << 24;
                String bindTxt = "Press a key...";
                ctx.fill(modDrawX + 6, my2 + MOD_ROW - 12,
                    modDrawX + 6 + mc.textRenderer.getWidth(bindTxt) + 4, my2 + MOD_ROW - 2,
                    0x8800E5CC | (blinkAlpha & 0xFF000000));
                ctx.drawText(mc.textRenderer, bindTxt,
                    modDrawX + 8, my2 + MOD_ROW - 11,
                    0xFF000000 | (blinkAlpha & 0xFF000000) | 0x00E5FF, false);
            } else if (mod.getKey() > 0) {
                String kn = org.lwjgl.glfw.GLFW.glfwGetKeyName(mod.getKey(), 0);
                String kb = kn != null ? "[" + kn.toUpperCase() + "]" : "[?]";
                int kbColor = (int)(modAlpha * 0x55) << 24 | 0x0088AA;
                ctx.drawText(mc.textRenderer, kb,
                    modDrawX + 10, my2 + MOD_ROW - 9, kbColor, false);
            }

            // Стрелка «есть настройки»
            if (!mod.getSettings().isEmpty() || !mod.getColorSettings().isEmpty()) {
                boolean isCurrent = (settingsMod == mod);
                int arrColor = isCurrent
                    ? auroraRainbow(0.5f, 0f)
                    : (int)(modAlpha * 0x88) << 24 | 0x00AABB;
                ctx.drawText(mc.textRenderer, isCurrent ? "◀" : "▶",
                    modDrawX + MOD_W - 46, my2 + (MOD_ROW - 8) / 2, arrColor, false);
            }
        }

        // ── Закрыть ScissorStack (ОБЯЗАТЕЛЬНО после push!) ───────────────
        ScissorStack.pop();

        // Скроллбар
        if (totalModH > listH) {
            float frac = scrollCur / Math.max(1, totalModH - listH);
            int sbH   = Math.max(16, (int)((float)listH / totalModH * listH));
            int sbY   = listY + (int)(frac * (listH - sbH));
            ctx.fill(x + MOD_W - 3, sbY, x + MOD_W - 1, sbY + sbH,
                0x4400E5CC);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LIQUID TOGGLE — анимированный переключатель
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * «Жидкий» toggle: кружок плавно перекатывается с пружинным overshoot.
     * Уникальная фича — аналогов нет в Fabric-клиентах.
     */
    private void drawLiquidToggle(DrawContext ctx, int x, int y, Module mod, float alpha) {
        String uid = mod.getName();
        boolean on = mod.isEnabled();

        // Позиция бегунка через spring
        float target = on ? 1f : 0f;
        float[] vel  = toggleVel.computeIfAbsent(uid, k -> new float[]{0f});
        float   pos  = togglePos.getOrDefault(uid, target);
        pos = AnimationUtils.premiumSpring(pos, target, vel, 0.14f, 0.76f);
        pos = AnimationUtils.clamp(pos, 0f, 1.06f);
        togglePos.put(uid, pos);

        int trackW = 24, trackH = 10;
        int trackX = x, trackY = y;

        // ── Пункт 8: Скруглённый track ────────────────────────────────────
        int trackCol = on
            ? lerpColor(0xFF223344, CAT_AURA[activeCatIdx], pos, (int)(alpha * 220))
            : mulAlpha(0xFF1A1A2E, (int)(alpha * 180));
        // Радиус = trackH/2 → полностью скруглённый (pill shape)
        drawRoundedRect(ctx, trackX, trackY, trackW, trackH, trackH / 2, trackCol);
        // Track border
        int borderCol = on
            ? mulAlpha(CAT_AURA[activeCatIdx], (int)(pos * alpha * 160))
            : mulAlpha(0xFF334455, (int)(alpha * 120));
        drawRoundedRectOutline(ctx, trackX, trackY, trackW, trackH, trackH / 2, 0, borderCol);

        // ── Кружок бегунка — squish + скруглённый ─────────────────────────
        float speed = Math.abs(vel[0]);
        int   squishW = trackH + (int)(speed * 8);
        int   squishH = trackH - (int)(speed * 3);
        squishW = Math.max(trackH, Math.min(squishW, trackH + 6));
        squishH = Math.max(4, squishH);
        int knobX = trackX + 1 + (int)(pos * (trackW - trackH - 2)) - (squishW - trackH) / 2;
        int knobY = trackY + (trackH - squishH) / 2;
        int knobCol = on
            ? auroraRainbow(pos * 0.3f + timeMs * 0.15f, 0f)
            : mulAlpha(0xFF888899, (int)(alpha * 200));
        // Скруглённый knob (pill)
        drawRoundedRect(ctx, knobX, knobY, squishW, squishH, squishH / 2, knobCol);

        // Glow под кружком при включении
        if (on && pos > 0.5f) {
            int glowAlpha = (int)((pos - 0.5f) * 2f * alpha * 80);
            ctx.fill(knobX - 1, knobY - 1, knobX + squishW + 1, knobY + squishH + 1,
                (glowAlpha << 24) | (CAT_AURA[activeCatIdx] & 0x00FFFFFF));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SETTINGS PANEL — ПРАВАЯ ПАНЕЛЬ НАСТРОЕК
    // ─────────────────────────────────────────────────────────────────────────

    private void drawSettingsPanel(DrawContext ctx, int x, int y, int ph, int sw, int mx, int my, Theme t) {
        ctx.fill(x, y, x + sw, y + ph, AUR_SIDE);

        // Aurora-линия слева
        drawVerticalAuroraLine(ctx, x, y, ph, 0.4f);

        if (settingsMod == null || settingsAnim < 0.05f) return;
        int alpha = (int)(settingsAnim * 255);

        // Заголовок
        String modName = settingsMod.getName();
        int hColor = auroraRainbow(0.6f, 0f);
        ctx.drawText(mc.textRenderer, modName, x + 8, y + 10, mulAlpha(hColor, alpha), false);
        ctx.drawText(mc.textRenderer, settingsMod.getDescription(),
            x + 8, y + 21, mulAlpha(0xFF666688, alpha), false);
        ctx.fill(x + 4, y + HEADER_H - 1, x + sw - 4, y + HEADER_H,
            mulAlpha(0x0044AAFF, alpha));

        int sy = y + HEADER_H + 4;
        int sRowH = 32;

        // Settings
        for (Setting s : settingsMod.getSettings()) {
            if (sy + sRowH > y + ph - 4) break;
            drawSetting(ctx, x + 4, sy, sw - 8, sRowH, s, mx, my, alpha);
            sy += sRowH;
        }

        // ColorSettings
        for (ColorSetting cs : settingsMod.getColorSettings()) {
            if (sy + sRowH > y + ph - 4) break;
            drawColorSetting(ctx, x + 4, sy, sw - 8, sRowH, cs, alpha);
            sy += sRowH;
        }
    }

    private void drawSetting(DrawContext ctx, int x, int y, int w, int h,
                             Setting s, int mx, int my, int panelAlpha) {
        // ── Пункт 8: Скруглённый фон setting-строки ──────────────────────
        drawRoundedRect(ctx, x, y, w, h - 2, 3, mulAlpha(0xFF0D1020, panelAlpha));

        String label = s.getName();
        ctx.drawText(mc.textRenderer, label, x + 4, y + 3, mulAlpha(0xFFCCDDFF, panelAlpha), false);

        switch (s.getType()) {
            case NUMBER -> {
                double v   = s.getValue(), mn = s.getMin(), mx2 = s.getMax();
                float  frac = (float)((v - mn) / (mx2 - mn));
                int    bx  = x + 4, bw = w - 8, by = y + 14, bh = 8;
                // ── Пункт 8: Скруглённый slider track ─────────────────────
                drawRoundedRect(ctx, bx, by, bw, bh, bh / 2, mulAlpha(0xFF0A0A18, panelAlpha));
                // Fill — aurora-gradient (скруглённый)
                int fillW = Math.max(bh, (int)(frac * bw)); // минимум = radius
                int fc1 = auroraRainbow(frac * 0.3f, 0f);
                int fc2 = auroraRainbow(frac * 0.3f + 0.15f, 0f);
                drawRoundedRect(ctx, bx, by, fillW, bh, bh / 2, mulAlpha(fc1, panelAlpha));
                // Knob — скруглённый маркер
                int knobW = 4, knobH = bh + 2;
                int knobX = bx + fillW - knobW / 2;
                int knobY = by - 1;
                drawRoundedRect(ctx, knobX, knobY, knobW, knobH, knobW / 2, mulAlpha(fc2, panelAlpha));
                // Value label
                String valStr = String.format("%.2f", v);
                ctx.drawText(mc.textRenderer, valStr,
                    x + w - mc.textRenderer.getWidth(valStr) - 4, y + 14,
                    mulAlpha(0xFF88AACC, panelAlpha), false);
            }
            case BOOLEAN -> {
                drawLiquidToggle(ctx, x + w - 30, y + (h - 10) / 2,
                    new BoolProxy(s), panelAlpha / 255f);
            }
            case ENUM -> {
                String opt = s.getCurrentOption();
                int ow = mc.textRenderer.getWidth(opt) + 8;
                int ox = x + w - ow - 2, oy = y + 14;
                // ── Пункт 8: Скруглённый enum-selector ────────────────────
                drawRoundedRect(ctx, ox, oy, ow, 11, 3, mulAlpha(0xFF0D1525, panelAlpha));
                ctx.drawText(mc.textRenderer, "◀", ox + 2, oy + 2, mulAlpha(0xFF0088BB, panelAlpha), false);
                ctx.drawText(mc.textRenderer, opt, ox + 10, oy + 2, mulAlpha(0xFFCCEEFF, panelAlpha), false);
                ctx.drawText(mc.textRenderer, "▶", ox + ow - 8, oy + 2, mulAlpha(0xFF0088BB, panelAlpha), false);
            }
        }
    }

    private void drawColorSetting(DrawContext ctx, int x, int y, int w, int h,
                                  ColorSetting cs, int panelAlpha) {
        ctx.fill(x, y, x + w, y + h - 2, mulAlpha(0xFF0D1020, panelAlpha));
        ctx.drawText(mc.textRenderer, cs.getName(), x + 4, y + 3, mulAlpha(0xFFCCDDFF, panelAlpha), false);
        // Цветовой превью
        int previewColor = cs.getColor();
        ctx.fill(x + w - 22, y + 12, x + w - 4, y + 22, 0xFF000000);
        ctx.fill(x + w - 21, y + 13, x + w - 5, y + 21, previewColor);
        // Rainbow toggle
        String rb = cs.isRainbow() ? "✦ Rainbow" : "○ Static";
        ctx.drawText(mc.textRenderer, rb, x + 4, y + 16,
            mulAlpha(cs.isRainbow() ? auroraRainbow(timeMs * 0.2f, 0f) : 0xFF446688, panelAlpha), false);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ РИСОВАНИЯ
    // ─────────────────────────────────────────────────────────────────────────

    /** Вертикальная aurora-линия (градиентная по Y, анимированная) */
    private void drawVerticalAuroraLine(DrawContext ctx, int x, int y, int h, float intensity) {
        int steps = h / 3;
        for (int i = 0; i < steps; i++) {
            float fy = (float) i / steps;
            float phase = timeMs * 0.5f + fy * 6.0f;
            float bright = 0.4f + 0.6f * (float) Math.abs(Math.sin(phase));
            int   col = auroraRainbow(fy + timeMs * 0.05f, 0f);
            int   alpha = (int)(intensity * bright * 120);
            ctx.fill(x, y + i * 3, x + 1, y + i * 3 + 3, (alpha << 24) | (col & 0x00FFFFFF));
        }
    }

    /** Aurora glow — мягкое сияние вокруг точки */
    private void drawAuroraGlow(DrawContext ctx, int cx, int cy, int radius, int color, float intensity) {
        int layers = 5;
        for (int i = layers; i >= 1; i--) {
            int r  = radius * i / layers;
            int a  = (int)(intensity * 255 / (i + 1));
            int c  = (a << 24) | (color & 0x00FFFFFF);
            ctx.fill(cx - r, cy - r, cx + r, cy + r, c);
        }
    }

    private void drawSoftShadow(DrawContext ctx, int x, int y, int w, int h, int layers) {
        for (int i = layers; i >= 1; i--) {
            int a = 80 / (i + 1);
            ctx.fill(x - i, y - i, x + w + i, y + h + i, (a << 24));
        }
    }

    private void drawSoftShadow(DrawContext ctx, int x, int y, int w, int h, int layers) {
        for (int i = layers; i >= 1; i--) {
            int a = 80 / (i + 1);
            ctx.fill(x - i, y - i, x + w + i, y + h + i, (a << 24));
        }
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    // ── Пункт 8: Скруглённые углы ─────────────────────────────────────────
    /**
     * Рисует прямоугольник со скруглёнными углами.
     * В Minecraft DrawContext нет встроенного метода — рисуем вручную пикселями.
     * radius: 1..6 (больше 6 медленно, т.к. per-pixel).
     */
    private void drawRoundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w / 2, h / 2));
        // Центральный прямоугольник (без углов)
        ctx.fill(x + r, y,     x + w - r, y + h,     color); // вертикальная полоса
        ctx.fill(x,     y + r, x + r,     y + h - r, color); // левый край
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color); // правый край
        // Скруглённые углы — попиксельно через circle test
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                double dist = Math.sqrt((double)(r - i) * (r - i) + (double)(r - j) * (r - j));
                if (dist <= r) {
                    // Верхний левый угол
                    ctx.fill(x + i, y + j, x + i + 1, y + j + 1, color);
                    // Верхний правый угол
                    ctx.fill(x + w - i - 1, y + j, x + w - i, y + j + 1, color);
                    // Нижний левый угол
                    ctx.fill(x + i, y + h - j - 1, x + i + 1, y + h - j, color);
                    // Нижний правый угол
                    ctx.fill(x + w - i - 1, y + h - j - 1, x + w - i, y + h - j, color);
                }
            }
        }
    }

    /**
     * Скруглённый прямоугольник с обводкой.
     */
    private void drawRoundedRectOutline(DrawContext ctx, int x, int y, int w, int h,
                                         int r, int fill, int border) {
        drawRoundedRect(ctx, x, y, w, h, r, fill);
        // Обводка — рисуем чуть больший контур поверх
        // Верхняя и нижняя линии (без углов)
        ctx.fill(x + r, y, x + w - r, y + 1, border);
        ctx.fill(x + r, y + h - 1, x + w - r, y + h, border);
        // Левая и правая линии
        ctx.fill(x, y + r, x + 1, y + h - r, border);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, border);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ЦВЕТ
    // ─────────────────────────────────────────────────────────────────────────

    /** Aurora-радуга: плавная смена зелёный→голубой→фиолетовый */
    private int auroraRainbow(float offset, float speedMult) {
        float hue = ((System.currentTimeMillis() * 0.0003f * (1f + speedMult)) + offset) % 1f;
        if (hue < 0) hue += 1f;
        // Aurora диапазон: 120°–270° (зелёный→голубой→синий→фиолетовый)
        float aurHue = 0.33f + hue * 0.42f;
        return AnimationUtils.hsvToArgb(aurHue * 360f, 0.7f, 1.0f, 255);
    }

    private int lerpColor(int from, int to, float t, int alpha) {
        int fr = (from >> 16) & 0xFF, fg = (from >> 8) & 0xFF, fb = from & 0xFF;
        int tr = (to   >> 16) & 0xFF, tg = (to   >> 8) & 0xFF, tb = to   & 0xFF;
        int r = (int)(fr + (tr - fr) * t);
        int g = (int)(fg + (tg - fg) * t);
        int b = (int)(fb + (tb - fb) * t);
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    private int lerpColor(int from, int to, float t) {
        return lerpColor(from, to, t, 255);
    }

    /** Задать alpha у цвета ARGB */
    private int mulAlpha(int color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private boolean inBox(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MOUSE & KEYBOARD
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void mouseClicked(double mx, double my, int button) {
        int imx = (int) mx, imy = (int) my;
        int totalW = SIDE_W + MOD_W + (int)(SET_W * AnimationUtils.smoothStep(settingsAnim));

        // Drag начало
        if (inBox(imx, imy, panelX, panelY, totalW, HEADER_H) && button == 0) {
            draggingPanel = true;
            dragOffX = imx - panelX;
            dragOffY = imy - panelY;
            return;
        }

        // Sidebar: смена категории
        for (int i = 0; i < CATS.length; i++) {
            int cy = panelY + HEADER_H + i * CAT_ROW;
            if (inBox(imx, imy, panelX, cy, SIDE_W, CAT_ROW)) {
                if (activeCatIdx != i) {
                    // ── Пункт 9: Звук смены категории ────────────────────
                    SoundEngine.playCategoryChange();
                    // ── Пункт 10: Wobble-импульс на иконку при клике ─────
                    catWobbleV.put(i, catWobbleV.getOrDefault(i, 0f) + 0.4f);
                }
                activeCatIdx = i;
                settingsMod  = null;
                return;
            }
        }

        // Кнопка поиска
        int searchBtnX = panelX + SIDE_W + MOD_W - 20;
        if (inBox(imx, imy, searchBtnX, panelY + 8, 16, 12)) {
            searchActive = !searchActive;
            if (!searchActive) searchQuery = "";
            return;
        }

        // Кнопка Edit HUD (◈)
        int hudBtnX = panelX + SIDE_W + MOD_W - 36;
        if (inBox(imx, imy, hudBtnX, panelY + 28, 12, 10)) {
            mc.setScreen(new net.enkuron.ui.HudEditorScreen());
            return;
        }

        // Кнопка Профили (☰)
        int proBtnX = panelX + SIDE_W + MOD_W - 22;
        if (inBox(imx, imy, proBtnX, panelY + 28, 12, 10)) {
            mc.setScreen(new net.enkuron.ui.ProfileScreen());
            return;
        }

        // Кнопка × закрыть настройки
        if (settingsMod != null) {
            int closeBtnX = panelX + SIDE_W + MOD_W - 36;
            if (inBox(imx, imy, closeBtnX, panelY + 8, 10, 10)) {
                settingsMod = null;
                return;
            }
        }

        // Клик по модулю
        int searchPanelH = (int)(SEARCH_H * searchSlide);
        int listY = panelY + HEADER_H + searchPanelH;
        List<Module> displayMods = searchActive && !searchQuery.isEmpty()
            ? ModuleManager.getAll().stream()
                .filter(m -> m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                .toList()
            : ModuleManager.getByCategory(CATS[activeCatIdx]);

        int scroll = (int) scrollCur;
        for (int i = 0; i < displayMods.size(); i++) {
            Module mod = displayMods.get(i);
            int my2 = listY + i * MOD_ROW - scroll;
            if (!inBox(imx, imy, panelX + SIDE_W, my2, MOD_W, MOD_ROW)) continue;

            if (button == 0) {
                // Клик на toggle (правая сторона)
                if (imx > panelX + SIDE_W + MOD_W - 40) {
                    mod.toggle();
                    // ── Пункт 9: Звук включения/выключения ──────────────
                    if (mod.isEnabled()) SoundEngine.playModuleOn();
                    else                 SoundEngine.playModuleOff();
                    // Ripple-эффект
                    int auraCol = CAT_AURA[activeCatIdx];
                    ripples.add(new Ripple(imx, imy, auraCol));
                } else if (imx < panelX + SIDE_W + MOD_W - 40) {
                    // Открыть/закрыть настройки
                    if (!mod.getSettings().isEmpty() || !mod.getColorSettings().isEmpty()) {
                        settingsMod = (settingsMod == mod) ? null : mod;
                        SoundEngine.playSettingsOpen(); // звук открытия настроек
                    } else {
                        mod.toggle();
                        // ── Пункт 9: Звук ────────────────────────────────
                        if (mod.isEnabled()) SoundEngine.playModuleOn();
                        else                 SoundEngine.playModuleOff();
                        ripples.add(new Ripple(imx, imy, CAT_AURA[activeCatIdx]));
                    }
                }
            } else if (button == 1) {
                // ПКМ — войти в режим назначения клавиши
                if (bindingModule == mod) {
                    bindingModule = null; // отмена
                } else {
                    bindingModule = mod;
                    bindingPulse  = 0f;
                }
            }
            return;
        }

        // Клик по настройкам (ENUM cycle)
        if (settingsMod != null) {
            int sx = panelX + SIDE_W + MOD_W;
            int sw = (int)(SET_W * AnimationUtils.smoothStep(settingsAnim));
            int sy = panelY + HEADER_H + 4;
            for (Setting s : settingsMod.getSettings()) {
                if (s.getType() == Setting.Type.ENUM) {
                    if (inBox(imx, imy, sx + 4, sy + 14, sw - 12, 11)) {
                        s.cycleOption();
                    }
                } else if (s.getType() == Setting.Type.BOOLEAN) {
                    if (inBox(imx, imy, sx + sw - 34, sy + 9, 24, 10)) {
                        s.toggleState();
                    }
                } else if (s.getType() == Setting.Type.NUMBER) {
                    if (inBox(imx, imy, sx + 4, sy + 14, sw - 8, 8)) {
                        draggingSlider = s;
                        sliderX0 = sx + 4;
                        sliderW0 = sw - 8;
                    }
                }
                sy += 32;
            }
        }
    }

    @Override
    public void mouseReleased(double mx, double my, int button) {
        draggingPanel = false;
        if (draggingSlider != null) {
            // Тихий тост со значением слайдера при отпускании
            NotificationManager.push(
                draggingSlider.getName(),
                String.format("%.1f", draggingSlider.getValue()),
                NotificationManager.Type.INFO,
                1000
            );
            draggingSlider = null;
        }
    }

    @Override
    public void mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingPanel) {
            panelX = (int) mx - dragOffX;
            panelY = (int) my - dragOffY;
        }
        if (draggingSlider != null) {
            float frac = AnimationUtils.clamp((float)(mx - sliderX0) / sliderW0, 0f, 1f);
            draggingSlider.setValue(
                draggingSlider.getMin() + frac * (draggingSlider.getMax() - draggingSlider.getMin())
            );
            SoundEngine.playSliderTick();
        }
    }

    @Override
    public void mouseScrolled(double mx, double my, double sx, double sy) {
        scrollMom -= (float) sy * 10f;
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        // ── Keybind binding mode ─────────────────────────────────────────
        if (bindingModule != null) {
            if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
                // ESC — сброс биндинга (клавиша = 0)
                bindingModule.setKey(0);
            } else {
                bindingModule.setKey(keyCode);
                NotificationManager.push(
                    bindingModule.getName(),
                    "Бинд: " + (org.lwjgl.glfw.GLFW.glfwGetKeyName(keyCode, 0) != null
                        ? org.lwjgl.glfw.GLFW.glfwGetKeyName(keyCode, 0).toUpperCase()
                        : "?"),
                    NotificationManager.Type.SUCCESS, 1800
                );
            }
            bindingModule = null;
            net.enkuron.utils.ConfigManager.scheduleAutosave();
            return;
        }
        // Ctrl+F — toggle поиск
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_F &&
            (modifiers & org.lwjgl.glfw.GLFW.GLFW_MOD_CONTROL) != 0) {
            searchActive = !searchActive;
            if (!searchActive) searchQuery = "";
            return;
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            if (settingsMod != null) { settingsMod = null; return; }
            if (searchActive)        { searchActive = false; searchQuery = ""; return; }
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE && searchActive && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
        }
    }

    @Override
    public void charTyped(char chr, int modifiers) {
        if (searchActive && chr >= 32 && searchQuery.length() < 24) {
            searchQuery += chr;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PROXY-КЛАСС ДЛЯ BOOLEAN-SETTING В LIQUID TOGGLE
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Прокси для Setting.BOOLEAN, реализующий интерфейс Module
     * для переиспользования drawLiquidToggle в панели настроек.
     */
    private class BoolProxy extends Module {
        private final Setting s;
        BoolProxy(Setting s) {
            super(s.getName(), "", Module.Category.MISC);
            this.s = s;
        }
        @Override public boolean isEnabled() { return s.getState(); }
        @Override public void toggle() { s.toggleState(); }
    }
}
