package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.BetterChat;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.lwjgl.glfw.GLFW;

/**
 * MixinChatScreen — перехватывает отправку сообщений и навигацию истории.
 */
@Mixin(ChatScreen.class)
public abstract class MixinChatScreen {

    @Shadow protected TextFieldWidget chatField;

    @Inject(method = "sendMessage(Ljava/lang/String;Z)V", at = @At("HEAD"), cancellable = true)
    private void onSendMessage(String message, boolean addToHistory, CallbackInfo ci) {
        BetterChat mod = (BetterChat) ModuleManager.getByName("BetterChat");
        if (mod == null || !mod.isEnabled()) return;

        // Применяем фильтр дублей и префикс
        String processed = mod.processOutgoing(message);
        if (processed == null) {
            ci.cancel(); // дубль — блокируем
            return;
        }

        // Если сообщение изменилось или нужна нарезка — отменяем оригинал и шлём сами
        String[] parts = mod.splitLong(processed);
        if (parts.length > 1 || !processed.equals(message)) {
            ci.cancel();
            for (String part : parts) {
                net.minecraft.client.MinecraftClient.getInstance()
                    .getNetworkHandler()
                    .sendChatMessage(part);
            }
        }
        // Если parts.length == 1 и processed == message — пускаем оригинальный вызов
    }

    /**
     * История команд ↑↓ — перехватываем keyPressed.
     * ↑ = более старое сообщение, ↓ = более новое.
     */
    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        BetterChat mod = (BetterChat) ModuleManager.getByName("BetterChat");
        if (mod == null || !mod.isEnabled()) return;
        if (chatField == null) return;

        if (keyCode == GLFW.GLFW_KEY_UP) {
            String prev = mod.historyUp(chatField.getText());
            if (prev != null) {
                chatField.setText(prev);
                chatField.setCursorToEnd(false);
            }
            cir.setReturnValue(true);
        } else if (keyCode == GLFW.GLFW_KEY_DOWN) {
            String next = mod.historyDown();
            chatField.setText(next != null ? next : "");
            chatField.setCursorToEnd(false);
            cir.setReturnValue(true);
        }
    }
}
