package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.BlockHighlight;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinWorldRenderer — перехватывает рендер контура блока под прицелом.
 * FIX 1.21.4: WorldRenderer.drawBox удалён; рисуем контур вручную через VertexConsumer.
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRenderer {

    @Inject(
        method = "drawBlockOutline",
        at = @At("HEAD"),
        cancellable = true,
        remap = true
    )
    private void onDrawBlockOutline(
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            Entity entity,
            double cameraX, double cameraY, double cameraZ,
            BlockPos pos,
            BlockState state,
            CallbackInfo ci) {

        BlockHighlight bh = (BlockHighlight) ModuleManager.getByName("BlockHighlight");
        if (bh == null || !bh.isEnabled()) return;

        ci.cancel();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        var shape = state.getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;

        int color = bh.getColor();
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ((color      ) & 0xFF) / 255f;

        double ox = pos.getX() - cameraX;
        double oy = pos.getY() - cameraY;
        double oz = pos.getZ() - cameraZ;

        matrices.push();
        matrices.translate(ox, oy, oz);

        Matrix4f mat = matrices.peek().getPositionMatrix();
        String style = bh.getStyle();

        shape.forEachBox((x1, y1, z1, x2, y2, z2) -> {
            if ("Fill".equals(style) || "Both".equals(style)) {
                drawBoxLines(vertexConsumer, mat,
                    (float)x1, (float)y1, (float)z1,
                    (float)x2, (float)y2, (float)z2,
                    r, g, b, a * 0.3f);
            }
            if (!"Fill".equals(style)) {
                float e = 0.002f;
                drawBoxLines(vertexConsumer, mat,
                    (float)x1 - e, (float)y1 - e, (float)z1 - e,
                    (float)x2 + e, (float)y2 + e, (float)z2 + e,
                    r, g, b, a);
            }
        });

        matrices.pop();
    }

    /** Рисует 12 рёбер AABB через VertexConsumer (LINES topology). */
    private static void drawBoxLines(VertexConsumer vc, Matrix4f mat,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            float r, float g, float b, float a) {
        // 4 рёбра по Y=y1
        line(vc, mat, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(vc, mat, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(vc, mat, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(vc, mat, x1,y1,z2, x1,y1,z1, r,g,b,a);
        // 4 рёбра по Y=y2
        line(vc, mat, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(vc, mat, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(vc, mat, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(vc, mat, x1,y2,z2, x1,y2,z1, r,g,b,a);
        // 4 вертикальных ребра
        line(vc, mat, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(vc, mat, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(vc, mat, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(vc, mat, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private static void line(VertexConsumer vc, Matrix4f mat,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            float r, float g, float b, float a) {
        vc.vertex(mat, x1, y1, z1).color(r, g, b, a);
        vc.vertex(mat, x2, y2, z2).color(r, g, b, a);
    }
}
