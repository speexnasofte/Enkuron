package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.BlockHighlight;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinWorldRenderer — перехватывает рендер контура блока под прицелом.
 *
 * FIX 1.21.4: drawBlockOutline существует в WorldRenderer с сигнатурой:
 *   private void drawBlockOutline(MatrixStack, VertexConsumer, Entity,
 *                                  double, double, double, BlockPos, BlockState)
 *
 * Используем remap=true (имя совпадает в Yarn), cancellable=true чтобы
 * заменить ванильный серый контур на цветной из BlockHighlight.
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRenderer {

    @Inject(
        method = "drawBlockOutline",
        at = @At("HEAD"),
        cancellable = true,
        remap = true
    )
    private void onDrawBlockOutline(
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            Entity entity,
            double cameraX, double cameraY, double cameraZ,
            BlockPos pos,
            BlockState state,
            CallbackInfo ci) {

        BlockHighlight bh = (BlockHighlight) ModuleManager.getByName("BlockHighlight");
        if (bh == null || !bh.isEnabled()) return;

        // Отменяем стандартный серый контур
        ci.cancel();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        var shape = state.getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;

        int color = bh.getColor();
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ((color      ) & 0xFF) / 255f;

        double ox = pos.getX() - cameraX;
        double oy = pos.getY() - cameraY;
        double oz = pos.getZ() - cameraZ;

        matrices.push();
        matrices.translate(ox, oy, oz);

        String style = bh.getStyle();

        shape.forEachBox((x1, y1, z1, x2, y2, z2) -> {
            if ("Fill".equals(style) || "Both".equals(style)) {
                WorldRenderer.drawBox(matrices, vertexConsumer,
                    x1, y1, z1, x2, y2, z2,
                    r, g, b, a * 0.3f);
            }
            if (!"Fill".equals(style)) {
                // Outline или Both — с небольшим отступом наружу
                WorldRenderer.drawBox(matrices, vertexConsumer,
                    x1 - 0.002, y1 - 0.002, z1 - 0.002,
                    x2 + 0.002, y2 + 0.002, z2 + 0.002,
                    r, g, b, a);
            }
        });

        matrices.pop();
    }
}
