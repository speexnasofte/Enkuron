package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.CustomCrosshair;
import net.enkuron.modules.impl.NoRender;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class MixinInGameHud {

    /** Основной рендер — рисуем все HUD-модули поверх. */
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        ModuleManager.onRender(context);
    }

    /**
     * Подавляем рендер ванильного прицела если CustomCrosshair включён.
     */
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        CustomCrosshair cc = (CustomCrosshair) ModuleManager.getByName("CustomCrosshair");
        if (cc != null && cc.isEnabled()) {
            ci.cancel();
        }
    }

    /**
     * NoRender — убираем анимацию тотема бессмертия.
     * renderOverlay существует в 1.21.4 и используется для тотема.
     */
    @Inject(method = "renderOverlay(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/util/Identifier;F)V",
            at = @At("HEAD"), cancellable = true)
    private void onRenderOverlay(DrawContext context, Identifier texture, float opacity, CallbackInfo ci) {
        if (texture != null && texture.getPath().contains("totem")) {
            NoRender noRender = (NoRender) ModuleManager.getByName("NoRender");
            if (noRender != null && noRender.isEnabled() && noRender.isNoTotemAnim()) {
                ci.cancel();
            }
        }
    }
}
