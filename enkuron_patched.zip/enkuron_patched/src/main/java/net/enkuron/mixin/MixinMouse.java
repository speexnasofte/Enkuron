package net.enkuron.mixin;

import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.Zoom;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinMouse — перехват scroll для Zoom-модуля.
 * Если Zoom включён и нажата клавиша C — колёсико регулирует зум вместо скролла.
 */
@Mixin(Mouse.class)
public class MixinMouse {

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        Zoom zoom = (Zoom) ModuleManager.getByName("Zoom");
        if (zoom == null || !zoom.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        boolean zoomKeyHeld = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_C) == 1;
        if (!zoomKeyHeld) return;

        zoom.onScroll(vertical);
        ci.cancel(); // блокируем стандартный скролл (смену слотов / zoom inventory)
    }
}
