package net.enkuron.mixin;

import net.enkuron.modules.impl.FpsBoost;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MixinWorldRendererFps — отключает рендер погоды (дождь/снег) для FPS.
 *
 * FIX v4 (1.21.4):
 *  - Используем remap=false и точный intermediary дескриптор метода
 *    чтобы обойти неправильный рематч компилятора.
 *    Expected: (class_9909, class_243, float, class_9958, CallbackInfo)
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRendererFps {

    @Inject(
        method = "renderWeather",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onRenderWeather(LightmapTextureManager manager,
                                  Camera camera,
                                  float tickProgress,
                                  RenderTickCounter tickCounter,
                                  CallbackInfo ci) {
        if (FpsBoost.isNoWeather()) {
            ci.cancel();
        }
    }
}
