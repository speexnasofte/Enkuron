package net.enkuron.mixin;

import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.modules.impl.SafeWalk;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * MixinClientPlayerEntity — хуки на методы игрока.
 *
 * isUsingItem перехватываем чтобы SafeWalk мог форсировать sneak-флаг
 * до того как движок MC проверяет не нужно ли разрешить движение с края.
 *
 * FIX: вместо tickMovement (нет нужного CIR) используем isSneaking(),
 * который MC вызывает при расчёте движения — возвращаем true когда
 * SafeWalk обнаружил что игрок на краю блока.
 */
@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    @Inject(method = "isSneaking", at = @At("RETURN"), cancellable = true)
    private void onIsSneaking(CallbackInfoReturnable<Boolean> cir) {
        // Если результат уже true — не трогаем (игрок и так крадётся)
        if (Boolean.TRUE.equals(cir.getReturnValue())) return;

        SafeWalk sw = (SafeWalk) ModuleManager.getByName("SafeWalk");
        if (sw != null && sw.isEnabled() && sw.isOnEdge()) {
            cir.setReturnValue(true);
        }
    }
}
