package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.util.math.BlockPos;

public class SafeWalk extends Module {
    private final Setting inWater   = new Setting("В воде",           false);
    private final Setting onlySneak = new Setting("Только в крадьбе", false);

    // Флаг для MixinClientPlayerEntity.isSneaking()
    private boolean onEdge = false;

    public SafeWalk() {
        super("SafeWalk", "Не даёт упасть с края блока", Category.MOVEMENT);
        addSetting(inWater);
        addSetting(onlySneak);
    }

    /** Вызывается из MixinClientPlayerEntity.isSneaking() */
    public boolean isOnEdge() { return onEdge; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            onEdge = false;
            return;
        }
        if (onlySneak.getState() && !mc.player.isSneaking()) {
            onEdge = false;
            return;
        }

        // Проверяем блок под ногами по всем 4 углам хитбокса (0.3 от центра)
        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        boolean safe = isBlockBelow(x + 0.3, y, z + 0.3)
                    && isBlockBelow(x - 0.3, y, z + 0.3)
                    && isBlockBelow(x + 0.3, y, z - 0.3)
                    && isBlockBelow(x - 0.3, y, z - 0.3);

        onEdge = !safe && mc.player.isOnGround();
    }

    @Override
    public void onDisable() {
        onEdge = false;
    }

    private boolean isBlockBelow(double x, double y, double z) {
        BlockPos pos = BlockPos.ofFloored(x, y - 0.01, z);
        boolean hasFluid = !mc.world.getFluidState(pos).isEmpty();
        if (hasFluid) return inWater.getState();
        return !mc.world.getBlockState(pos).isAir();
    }
}
