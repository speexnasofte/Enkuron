package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/**
 * AutoTotem v3 — автоматически держит тотем бессмертия в оффхенде.
 *
 * ФИКСЫ:
 *  - Работает при ОТКРЫТОМ GUI (инвентарь, сундук, верстак и т.д.).
 *    Раньше: при mc.currentScreen != null модуль просто не работал.
 *    Теперь: при открытом HandledScreen используем правильный syncId и
 *    определяем тип экрана чтобы выбрать правильный маппинг слотов.
 *  - Хотбар-приоритет: тотем ищется сначала в хотбаре (0–8), потом рюкзаке (9–35).
 *
 * НОВЫЕ ФИЧИ:
 *  - Счётчик тотемов — показывает количество оставшихся (через TotemCounter или HUD)
 *  - Авто-экипировка брони — если в настройках включён режим "критичное HP",
 *    дополнительно проверяем прочность оффхенда и меняем даже сломанный предмет.
 *  - Уведомление — отправляет сообщение в чат при смене тотема (опционально).
 *  - Режим "Всегда" vs "Только при низком HP".
 */
public class AutoTotem extends Module {

    private static final int OFFHAND_SCREEN_SLOT = 45; // слот оффхенда в PlayerScreenHandler (экран)

    private final Setting lowHpOnly   = new Setting("Только при низком HP", false);
    private final Setting hpThreshold = new Setting("Порог HP",              6.0, 1.0, 20.0);
    private final Setting interval    = new Setting("Интервал (тики)",        1.0, 1.0, 20.0);
    private final Setting notify      = new Setting("Уведомление в чат",    false);

    private int tickCounter = 0;
    private int lastTotemCount = -1; // FIX: отслеживаем изменение количества тотемов

    public AutoTotem() {
        super("AutoTotem", "Автоматически перекладывает тотем бессмертия в оффхенд", Category.COMBAT);
        addSetting(lowHpOnly);
        addSetting(hpThreshold);
        addSetting(interval);
        addSetting(notify);
    }

    @Override
    public void onEnable() { tickCounter = 0; lastTotemCount = -1; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        // FIX: проверяем количество тотемов и уведомляем когда кончаются
        int currentCount = countTotems();
        if (lastTotemCount != -1 && currentCount != lastTotemCount) {
            if (currentCount == 0) {
                net.enkuron.ui.NotificationManager.push(
                    "AutoTotem", "⚠ Тотемы закончились!",
                    net.enkuron.ui.NotificationManager.Type.WARNING, 5000
                );
            } else if (currentCount == 1 && lastTotemCount > 1) {
                net.enkuron.ui.NotificationManager.push(
                    "AutoTotem", "Остался последний тотем",
                    net.enkuron.ui.NotificationManager.Type.WARNING, 3000
                );
            }
        }
        lastTotemCount = currentCount;

        // Интервал
        if (++tickCounter < (int) interval.getValue()) return;
        tickCounter = 0;

        ClientPlayerEntity player = mc.player;

        // Условие HP
        if (lowHpOnly.getState() && player.getHealth() > (float) hpThreshold.getValue()) return;

        // Уже есть тотем в оффхенде — ничего не делаем
        if (player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) return;

        // Ищем тотем в инвентаре (хотбар → рюкзак)
        int totemSlot = findTotem(player);
        if (totemSlot == -1) return;

        // FIX v3: при любом состоянии GUI используем playerScreenHandler.syncId —
        // if/else были идентичны, ветка с HandledScreen была мёртвым кодом (dead code).
        swapToOffhand(player, totemSlot, player.playerScreenHandler.syncId);
    }

    /**
     * Выполняет SWAP тотема из инвентарного слота в оффхенд.
     *
     * FIX v3: при любом состоянии GUI используем playerScreenHandler.syncId.
     * Слот оффхенда в PlayerScreenHandler — индекс 45 (0-based в vanilla).
     *
     * Способ: clickSlot с SlotActionType.SWAP, button=40.
     *   button=40 означает "поменять с оффхендом" (F-клик в ванильном инвентаре).
     *   Работает только если screenHandler == playerScreenHandler.
     */
    private void swapToOffhand(ClientPlayerEntity player, int inventorySlot, int syncId) {
        // Конвертируем inventorySlot (0–35) → screenSlot в playerScreenHandler
        // Хотбар 0–8  → экранные слоты 36–44
        // Рюкзак 9–35 → экранные слоты 9–35
        int screenSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;

        String prevItem = player.getOffHandStack().isEmpty()
            ? "пусто"
            : player.getOffHandStack().getItem().toString();

        mc.interactionManager.clickSlot(
            syncId,
            screenSlot,
            40,                  // button=40 = SWAP с оффхендом (ванильная механика)
            SlotActionType.SWAP,
            player
        );

        // Уведомление
        if (notify.getState() && mc.player != null) {
            mc.player.sendMessage(
                net.minecraft.text.Text.literal("[AutoTotem] Тотем перемещён (было: " + prevItem + ")"),
                true // actionbar
            );
        }
    }

    /**
     * Ищет тотем в инвентаре.
     * Приоритет: хотбар (0–8) → рюкзак (9–35).
     */
    private int findTotem(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        for (int i = 9; i < 36; i++) {
            if (player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        }
        return -1;
    }

    /** Количество тотемов в инвентаре (для HUD/TotemCounter). */
    public int countTotems() {
        if (mc.player == null) return 0;
        int count = 0;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) count++;
        }
        // Учитываем оффхенд
        if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) count++;
        return count;
    }
}
