package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.AnimationUtils;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom — плавное приближение камеры.
 *
 * Настройки:
 *   Множитель     — уровень зума (0.1–0.8, меньше = сильнее)
 *   Плавность     — скорость интерполяции (0.05–0.3)
 *   Скролл-зум    — регулировать зум колёсиком мыши
 */
public class Zoom extends Module {

    private final Setting zoomFactor  = new Setting("Множитель",   0.3, 0.1, 0.8);
    private final Setting smoothSpeed = new Setting("Плавность",   0.1, 0.05, 0.3);
    private final Setting scrollZoom  = new Setting("Скролл-зум",  true);

    private float currentFov    = 1.0f;
    private float scrolledFactor = -1f; // -1 = использовать zoomFactor из настроек

    public Zoom() {
        super("Zoom", "Плавное приближение камеры на клавишу C", Category.VISUAL);
        addSetting(zoomFactor);
        addSetting(smoothSpeed);
        addSetting(scrollZoom);
    }

    public float getFovModifier() {
        boolean pressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_C) == 1;

        float target;
        if (pressed) {
            // Если скролл-зум активен и было значение — используем его
            target = (scrollZoom.getState() && scrolledFactor > 0)
                    ? scrolledFactor
                    : (float) zoomFactor.getValue();
        } else {
            target = 1.0f;
            scrolledFactor = -1f; // сброс после отпускания
        }

        currentFov = AnimationUtils.lerp(currentFov, target, (float) smoothSpeed.getValue());
        return currentFov;
    }

    /** Вызывается из миксина при прокрутке колеса мыши во время зума */
    public void onScroll(double delta) {
        if (!scrollZoom.getState()) return;
        float base = scrolledFactor > 0 ? scrolledFactor : (float) zoomFactor.getValue();
        scrolledFactor = Math.max(0.05f, Math.min(1.0f, base - (float)(delta * 0.05)));
    }

    @Override
    public void onDisable() {
        currentFov    = 1.0f;
        scrolledFactor = -1f;
    }
}
