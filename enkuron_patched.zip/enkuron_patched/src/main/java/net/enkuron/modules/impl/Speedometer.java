package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * Speedometer — скорость в блоках/секунду на экране.
 *
 * FIX 1.21.4: Entity.prevX/prevZ — protected, не доступны извне.
 * Решение: храним позицию сами в lastX/lastZ.
 */
public class Speedometer extends Module {

    private static final String[] UNITS = {"Блоки/сек", "Km/h", "mph"};

    private final Setting unit    = new Setting("Единицы", UNITS, 0);
    private final Setting showY   = new Setting("Вертикальная", false);

    private double lastX = 0, lastY = 0, lastZ = 0;
    private boolean hasLast = false;
    private double smoothSpeed = 0;

    public Speedometer() {
        super("Speedometer", "Скорость игрока в блоках/сек", Category.HUD);
        addSetting(unit);
        addSetting(showY);
        this.x = 5; this.y = 170;
    }

    @Override
    public void onTick() {
        if (mc.player == null) { hasLast = false; return; }

        double cx = mc.player.getX();
        double cy = mc.player.getY();
        double cz = mc.player.getZ();

        if (hasLast) {
            double dX = cx - lastX;
            double dZ = cz - lastZ;
            double dY = cy - lastY;

            double horSpeed = Math.sqrt(dX * dX + dZ * dZ) * 20; // блоки/сек
            double rawSpeed = showY.getState()
                ? Math.sqrt(dX * dX + dY * dY + dZ * dZ) * 20
                : horSpeed;

            // Плавное сглаживание
            smoothSpeed = smoothSpeed * 0.7 + rawSpeed * 0.3;
        }

        lastX = cx; lastY = cy; lastZ = cz;
        hasLast = true;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        double display = switch (unit.getCurrentOption()) {
            case "Km/h" -> smoothSpeed * 3.6;
            case "mph"  -> smoothSpeed * 2.237;
            default     -> smoothSpeed;
        };

        String suffix = switch (unit.getCurrentOption()) {
            case "Km/h" -> " km/h";
            case "mph"  -> " mph";
            default     -> " b/s";
        };

        String text = String.format("%.1f", display) + suffix;
        this.width  = mc.textRenderer.getWidth(text) + 8;
        this.height = 14;

        context.fill(x - 2, y - 2, x + this.width, y + this.height, 0xBB111116);
        context.fill(x - 2, y - 2, x + this.width, y - 1, 0xFF8844FF);
        context.drawText(mc.textRenderer, text, x + 2, y + 2, 0xFFFFFFFF, true);
    }

    @Override
    public void onDisable() { hasLast = false; smoothSpeed = 0; }
}
