package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * OffhandSwap — мгновенная смена предмета в оффхенд по кнопке.
 *
 * Режимы:
 *   Тотем ↔ Гапл   — переключает между тотемом бессмертия и золотым яблоком
 *   Тотем ↔ Щит    — переключает между тотемом и щитом
 *   Вручную        — просто меняет текущий слот хотбара с оффхендом
 *
 * Настройки:
 *   Режим      — Тотем↔Гапл / Тотем↔Щит / Вручную
 *   Авто-тотем — автоматически возвращает тотем когда гапл/щит израсходован
 *   Кулдаун    — задержка между свапами (тики)
 */
public class OffhandSwap extends Module {

    private static final String[] MODES = {"Тотем↔Гапл", "Тотем↔Щит", "Вручную"};

    private final Setting swapMode   = new Setting("Режим",       MODES, 0);
    private final Setting autoTotem  = new Setting("Авто-тотем",  true);
    private final Setting cooldownT  = new Setting("Кулдаун (т)", 5.0, 1.0, 20.0);

    private int  cooldown       = 0;
    private boolean gaplActive  = false; // текущий режим: гапл/щит в руке?

    public OffhandSwap() {
        super("OffhandSwap", "Быстрая смена предмета в оффхенд (тотем ↔ гапл/щит)", Category.COMBAT);
        addSetting(swapMode);
        addSetting(autoTotem);
        addSetting(cooldownT);
    }

    @Override
    public void onEnable() {
        cooldown    = 0;
        gaplActive  = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }

        // Авто-возврат тотема: если гапл/щит в оффхенде израсходован
        if (autoTotem.getState() && gaplActive) {
            ItemStack offhand = mc.player.getOffHandStack();
            boolean offhandEmpty = offhand.isEmpty()
                || offhand.getItem() == Items.TOTEM_OF_UNDYING;
            if (offhandEmpty) {
                gaplActive = false;
                putTotemInOffhand();
                cooldown = (int) cooldownT.getValue();
            }
        }
    }

    /**
     * Вызывается снаружи (из MixinKeyboard или Enkuron) при нажатии кнопки.
     * Производит swap в зависимости от текущего режима.
     */
    public void doSwap() {
        if (mc.player == null || cooldown > 0) return;

        switch (swapMode.getCurrentOption()) {
            case "Тотем↔Гапл" -> swapWith(Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE);
            case "Тотем↔Щит"  -> swapWith(Items.SHIELD);
            case "Вручную"    -> swapCurrentSlot();
        }
        cooldown = (int) cooldownT.getValue();
    }

    // ── Внутренние методы ────────────────────────────────────────────────────

    /** Ищет нужный предмет в хотбаре и меняет с оффхендом через F-клавишу. */
    private void swapWith(net.minecraft.item.Item... targets) {
        ItemStack offhand = mc.player.getOffHandStack();

        // Если нужный предмет уже в оффхенде — вернуть тотем
        for (net.minecraft.item.Item t : targets) {
            if (offhand.getItem() == t) {
                gaplActive = false;
                putTotemInOffhand();
                return;
            }
        }

        // Иначе — найти в хотбаре и поставить в оффхенд
        for (net.minecraft.item.Item target : targets) {
            int slot = findInHotbar(target);
            if (slot != -1) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = slot;
                sendSwapPacket();
                mc.player.getInventory().selectedSlot = prev;
                gaplActive = true;
                return;
            }
        }
    }

    /** Свапает текущий слот хотбара с оффхендом. */
    private void swapCurrentSlot() {
        sendSwapPacket();
        gaplActive = !gaplActive;
    }

    /** Ищет тотем в инвентаре и ставит его в оффхенд. */
    private void putTotemInOffhand() {
        int slot = findInHotbar(Items.TOTEM_OF_UNDYING);
        if (slot == -1) slot = findInInventory(Items.TOTEM_OF_UNDYING);
        if (slot == -1) return;

        if (slot < 9) {
            int prev = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = slot;
            sendSwapPacket();
            mc.player.getInventory().selectedSlot = prev;
        }
        // Примечание: для предметов в основном инвентаре нужен экран —
        // реализация через хотбар покрывает 90% случаев.
    }

    /** Отправляет пакет SWAP_ITEM_WITH_OFFHAND (аналог нажатия F). */
    private void sendSwapPacket() {
        mc.player.networkHandler.sendPacket(
            new PlayerActionC2SPacket(
                PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                BlockPos.ORIGIN,
                Direction.DOWN
            )
        );
    }

    private int findInHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return i;
        }
        return -1;
    }

    private int findInInventory(net.minecraft.item.Item item) {
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return i;
        }
        return -1;
    }
}
