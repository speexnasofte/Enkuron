package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/**
 * StackRefill — автоматически пополняет расходуемые предметы в хотбаре.
 *
 * Когда стак в хотбаре заканчивается (или опускается ниже порога),
 * модуль ищет такой же предмет в основном инвентаре и перекладывает его.
 *
 * Настройки:
 *   Порог стака   — пополнять при количестве ≤ N (1–16)
 *   Стрелы        — следить за стрелами
 *   Еда           — следить за едой
 *   Зелья         — следить за зельями
 *   Блоки         — следить за блоками (любыми)
 *   Кулдаун (т)   — задержка между пополнениями (5–40 тиков)
 */
public class StackRefill extends Module {

    private final Setting threshold  = new Setting("Порог стака",  1.0,  1.0, 16.0);
    private final Setting refillArrows= new Setting("Стрелы",      true);
    private final Setting refillFood  = new Setting("Еда",         true);
    private final Setting refillPotions=new Setting("Зелья",       true);
    private final Setting refillBlocks= new Setting("Блоки",       false);
    private final Setting cooldownT   = new Setting("Кулдаун (т)", 10.0,  5.0, 40.0);

    private int cooldown = 0;

    public StackRefill() {
        super("StackRefill", "Пополняет расходуемые предметы из инвентаря в хотбар", Category.UTILITY);
        addSetting(threshold);
        addSetting(refillArrows);
        addSetting(refillFood);
        addSetting(refillPotions);
        addSetting(refillBlocks);
        addSetting(cooldownT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }

        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            ItemStack hotbarStack = mc.player.getInventory().getStack(hotbarSlot);
            if (hotbarStack.isEmpty()) continue;
            if (hotbarStack.getCount() > (int) threshold.getValue()) continue;
            if (!shouldRefill(hotbarStack)) continue;

            // Ищем такой же предмет в основном инвентаре (слоты 9–35)
            int invSlot = findInInventory(hotbarStack.getItem());
            if (invSlot == -1) continue;

            // Перекладываем через pickup → place
            if (mc.player.currentScreenHandler != null) {
                // Нажимаем shift+click на слот инвентаря → он летит в хотбар
                mc.interactionManager.clickSlot(
                    mc.player.currentScreenHandler.syncId,
                    invSlot + 9, // смещение экрана инвентаря
                    hotbarSlot,
                    SlotActionType.SWAP,
                    mc.player
                );
                cooldown = (int) cooldownT.getValue();
                return; // по одному за тик
            }
        }
    }

    private boolean shouldRefill(ItemStack stack) {
        net.minecraft.item.Item item = stack.getItem();

        if (refillArrows.getState() && item == net.minecraft.item.Items.ARROW) return true;
        if (refillArrows.getState() && item == net.minecraft.item.Items.SPECTRAL_ARROW) return true;
        if (refillArrows.getState() && item instanceof net.minecraft.item.ArrowItem) return true;

        if (refillFood.getState() && item.isFood()) return true;

        if (refillPotions.getState() && (
            item == net.minecraft.item.Items.POTION ||
            item == net.minecraft.item.Items.SPLASH_POTION ||
            item == net.minecraft.item.Items.LINGERING_POTION
        )) return true;

        if (refillBlocks.getState() && item instanceof net.minecraft.item.BlockItem) return true;

        return false;
    }

    private int findInInventory(net.minecraft.item.Item item) {
        for (int i = 9; i < 36; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.getItem() == item && s.getCount() > 1) return i;
        }
        return -1;
    }
}
