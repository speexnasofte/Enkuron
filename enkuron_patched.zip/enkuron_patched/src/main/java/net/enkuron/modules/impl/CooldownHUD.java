package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * CooldownHUD — отображает кулдауны способностей на экране.
 *
 * Отслеживает Minecraft-кулдаун предметов (EnderPearl, ChorusFruit, Totem,
 * FireworkRocket, WindCharge) и рисует круговой / линейный прогресс-бар
 * с обратным отсчётом в секундах.
 *
 * Настройки:
 *   Стиль    — Круговой / Линейный
 *   Показать время — цифры под иконкой
 *   Ориентация — Горизонтально / Вертикально
 *   Размер иконок — Small (14) / Normal (18) / Large (22)
 *   Скрыть готовые — не показывать предметы без кулдауна
 */
public class CooldownHUD extends Module {

    private static final String[] STYLES  = {"Круговой", "Линейный"};
    private static final String[] ORIENTS = {"Горизонтально", "Вертикально"};
    private static final String[] SIZES   = {"Small", "Normal", "Large"};

    private final Setting style      = new Setting("Стиль",          STYLES,  0);
    private final Setting showTime   = new Setting("Показать время",  true);
    private final Setting orient     = new Setting("Ориентация",      ORIENTS, 0);
    private final Setting sizeOpt    = new Setting("Размер",          SIZES,   1);
    private final Setting hideReady  = new Setting("Скрыть готовые",  true);

    // Предметы с кулдаунами, которые нужно отслеживать
    private static final net.minecraft.item.Item[] TRACKED = {
        Items.ENDER_PEARL,
        Items.CHORUS_FRUIT,
        Items.TOTEM_OF_UNDYING,
        Items.WIND_CHARGE,
        Items.FIREWORK_ROCKET,
        Items.GOLDEN_APPLE,
        Items.ENCHANTED_GOLDEN_APPLE
    };

    private static final String[] LABELS = {
        "Эндер", "Хорус", "Тотем", "Ветер", "Ракета", "ГЯблоко", "ЗЯблоко"
    };

    public CooldownHUD() {
        super("CooldownHUD", "Показывает кулдауны предметов с обратным отсчётом", Category.HUD);
        addSetting(style);
        addSetting(showTime);
        addSetting(orient);
        addSetting(sizeOpt);
        addSetting(hideReady);
        this.x = 5;
        this.y = 300;
    }

    private int getIconSize() {
        return switch (sizeOpt.getCurrentOption()) {
            case "Small" -> 14;
            case "Large" -> 22;
            default      -> 18;
        };
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        // Собираем данные кулдаунов
        record CdEntry(net.minecraft.item.Item item, String label, float progress) {}
        var entries = new java.util.ArrayList<CdEntry>();

        for (int i = 0; i < TRACKED.length; i++) {
            net.minecraft.item.Item item = TRACKED[i];
            float progress = mc.player.getItemCooldownManager().getCooldownProgress(item, mc.getRenderTickCounter().getLastFrameDuration());
            // progress == 0 означает готов, > 0 значит ещё идёт кулдаун
            if (progress <= 0f && hideReady.getState()) continue;
            entries.add(new CdEntry(item, LABELS[i], progress));
        }

        if (entries.isEmpty()) return;

        int iconSize  = getIconSize();
        int gap       = 4;
        int timeH     = showTime.getState() ? mc.textRenderer.fontHeight + 2 : 0;
        boolean horiz = "Горизонтально".equals(orient.getCurrentOption());

        int cellW = iconSize + gap * 2;
        int cellH = iconSize + timeH + gap;

        if (horiz) {
            this.width  = entries.size() * (cellW + 2) - 2 + 8;
            this.height = cellH + 6;
        } else {
            this.width  = cellW + 8;
            this.height = entries.size() * (cellH + 2) - 2 + 6;
        }

        // Фон
        context.fill(x - 3, y - 3, x + this.width, y + this.height, 0xBB111116);
        context.fill(x - 3, y - 3, x + this.width, y - 2, 0xFF8844FF);

        int drawX = x;
        int drawY = y;

        for (CdEntry entry : entries) {
            boolean ready = entry.progress() <= 0f;

            // Иконка предмета
            int iconX = drawX + gap;
            int iconY = drawY + gap;

            // Тёмная подложка
            context.fill(iconX - 1, iconY - 1, iconX + iconSize + 1, iconY + iconSize + 1, 0xFF1A1A1A);

            // Рисуем иконку (16x16, смещаем если iconSize > 16)
            int off = Math.max(0, (iconSize - 16) / 2);
            ItemStack stack = new ItemStack(entry.item());
            context.drawItem(stack, iconX + off, iconY + off);

            if (!ready) {
                // Оверлей кулдауна
                if ("Круговой".equals(style.getCurrentOption())) {
                    drawCircularCooldown(context, iconX, iconY, iconSize, entry.progress());
                } else {
                    drawLinearCooldown(context, iconX, iconY, iconSize, entry.progress());
                }

                // Текст обратного отсчёта в центре
                if (showTime.getState()) {
                    // Получаем тики кулдауна через reflection не обязательно — рисуем просто прогресс %
                    String timeStr = formatProgress(entry.progress());
                    int tw = mc.textRenderer.getWidth(timeStr);
                    context.drawText(mc.textRenderer, timeStr,
                        iconX + iconSize / 2 - tw / 2,
                        iconY + iconSize + 2,
                        0xFFFF5555, true);
                }
            } else {
                // Зелёная галочка или "Готов"
                if (showTime.getState()) {
                    String rdyStr = "Готов";
                    int tw = mc.textRenderer.getWidth(rdyStr);
                    context.drawText(mc.textRenderer, rdyStr,
                        iconX + iconSize / 2 - tw / 2,
                        iconY + iconSize + 2,
                        0xFF55FF55, true);
                }
            }

            if (horiz) {
                drawX += cellW + 2;
            } else {
                drawY += cellH + 2;
            }
        }
    }

    // ── Рисование кулдауна ────────────────────────────────────────────────────

    /**
     * Круговой оверлей (сектор затемнения поверх иконки).
     * progress: 1.0 = только начался, 0.0 = завершён.
     */
    private void drawCircularCooldown(DrawContext context, int x, int y, int size, float progress) {
        int centerX = x + size / 2;
        int centerY = y + size / 2;
        int radius  = size / 2;

        // Затемняем весь квадрат иконки с прозрачностью
        int alpha = (int)(150 * progress);
        context.fill(x, y, x + size, y + size, (alpha << 24) | 0x000000);

        // Рисуем текстовый прогресс в центре иконки
        String pct = (int)((1f - progress) * 100) + "%";
        if (size >= 16) {
            int tw = mc.textRenderer.getWidth(pct);
            context.drawText(mc.textRenderer, pct,
                centerX - tw / 2, centerY - mc.textRenderer.fontHeight / 2,
                0xFFFFFFFF, true);
        }
    }

    /**
     * Линейная полоска снизу иконки.
     */
    private void drawLinearCooldown(DrawContext context, int x, int y, int size, float progress) {
        int barY  = y + size - 2;
        int barH  = 3;
        int filled = (int)(size * (1f - progress));

        // Фон полоски
        context.fill(x, barY, x + size, barY + barH, 0xFF222222);
        // Заполненная часть
        int r = (int)(progress * 255);
        int g = (int)((1f - progress) * 200);
        context.fill(x, barY, x + filled, barY + barH, EnkuronColor.toARGB(r, g, 50, 255));
    }

    private String formatProgress(float progress) {
        // progress 1.0 = начало, 0.0 = конец; показываем сколько уже прошло
        // Без доступа к реальным тикам показываем процент готовности
        int pct = (int)((1f - progress) * 100);
        return pct + "%";
    }
}
