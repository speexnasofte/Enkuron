package net.enkuron.modules.impl;

import net.enkuron.combat.TargetManager;
import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.modules.SettingPresets;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * TargetESP v1 — визуальная подсветка активной цели от TargetManager.
 *
 * Возможности:
 *  - 2D HUD-рамка в экранных координатах (проекция AABB)
 *  - Цвет рамки зависит от HP (зелёный → жёлтый → красный)
 *  - Пульсирующие угловые акценты (sin-анимация)
 *  - Линия-трейсер к цели (от центра экрана)
 *  - Имя + HP над рамкой
 *  - Fade-in/out при появлении/исчезновении цели
 *  - Поддержка темы ThemeManager
 */
public class TargetESP extends Module {

    private static final String[] STYLES = {"Corners", "Full", "Minimal", "Glow"};
    private static final String[] LINE_MODES = {"Выкл", "Центр", "Низ экрана"};

    private final Setting style      = new Setting("Стиль рамки",  STYLES,     0);
    private final Setting lineMode   = new Setting("Линия",        LINE_MODES, 1);
    private final Setting showName   = new Setting("Имя над рамкой", true);
    private final Setting showHpBar  = new Setting("HP под рамкой",  true);
    private final Setting useTheme   = new Setting("Цвет из темы",   false);
    private final Setting pulseCorners = new Setting("Пульс углов",  true);
    private final Setting padding    = new Setting("Отступ рамки", 2.0, 0.0, 10.0);

    private final SettingPresets.Range rangePreset = new SettingPresets.Range(16.0, 4.0, 48.0);

    // анимация
    private float fadeAnim  = 0f;
    private float pulsePhase = 0f;
    private LivingEntity lastTarget = null;

    public TargetESP() {
        super("TargetESP", "ESP-рамка вокруг выбранной цели (TargetManager)", Category.VISUAL);
        addSetting(style);
        addSetting(lineMode);
        addSetting(showName);
        addSetting(showHpBar);
        addSetting(useTheme);
        addSetting(pulseCorners);
        addSetting(padding);
        rangePreset.addTo(this);
    }

    @Override
    public void onEnable() {
        fadeAnim  = 0f;
        pulsePhase = 0f;
        lastTarget = null;
    }

    @Override
    public void onTick() {
        pulsePhase += 0.12f;
        if (pulsePhase > (float)(Math.PI * 2)) pulsePhase -= (float)(Math.PI * 2);

        LivingEntity target = TargetManager.getInstance().getTarget();
        if (target != lastTarget) {
            fadeAnim  = 0f;
            lastTarget = target;
        }
        fadeAnim = AnimationUtils.lerp(fadeAnim, target != null ? 1f : 0f, 0.15f);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || mc.world == null) return;

        LivingEntity target = TargetManager.getInstance().getTarget();
        if (target == null && fadeAnim < 0.01f) return;
        if (target == null) target = lastTarget;
        if (target == null) return;

        // Проверка дальности
        if (mc.player.distanceTo(target) > rangePreset.get()) return;

        // Получить 2D AABB цели
        int[] box = projectEntityBox(target);
        if (box == null) return;

        int bx = box[0], by = box[1], bx2 = box[2], by2 = box[3];
        int pad = (int) padding.getValue();
        bx -= pad; by -= pad; bx2 += pad; by2 += pad;

        // Цвет
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int alpha = (int)(fadeAnim * 0xFF);
        int hpColor = hpColor(ratio, alpha);

        int mainColor = hpColor;
        if (useTheme.getState()) {
            Theme theme = ThemeManager.get();
            if (theme != null) mainColor = withAlpha(theme.accent, alpha);
        }

        // Рендер по стилю
        switch (style.getCurrentOption()) {
            case "Full"    -> renderFull(context, bx, by, bx2, by2, mainColor, alpha);
            case "Minimal" -> renderMinimal(context, bx, by, bx2, by2, mainColor, alpha);
            case "Glow"    -> renderGlow(context, bx, by, bx2, by2, mainColor, alpha);
            default        -> renderCorners(context, bx, by, bx2, by2, mainColor, alpha);
        }

        // Линия трейсер
        renderLine(context, bx, by, bx2, by2, mainColor, alpha);

        // Имя
        if (showName.getState()) {
            String name = (target instanceof PlayerEntity ? "§e" : "§c") + target.getName().getString();
            int nameW = mc.textRenderer.getWidth(name);
            int nx = bx + (bx2 - bx) / 2 - nameW / 2;
            context.drawText(mc.textRenderer, name, nx, by - 10, withAlpha(0xFFFFFF, alpha), true);
        }

        // HP полоска под рамкой
        if (showHpBar.getState()) {
            int barW = bx2 - bx;
            int barY = by2 + 2;
            context.fill(bx, barY, bx2, barY + 3, withAlpha(0x222222, alpha));
            context.fill(bx, barY, bx + (int)(barW * ratio), barY + 3, hpColor);
        }
    }

    // ── Стили рамки ──────────────────────────────────────────────────────────

    private void renderCorners(DrawContext ctx, int x, int y, int x2, int y2, int color, int alpha) {
        int len = Math.max(5, (Math.min(x2 - x, y2 - y)) / 4);
        float pulse = pulseCorners.getState()
            ? (float)(0.7 + 0.3 * Math.sin(pulsePhase))
            : 1f;
        int c = withAlpha(color, (int)(alpha * pulse));
        int c2 = withAlpha(color, (int)(alpha * 0.4f));

        // Тонкая тень-рамка
        ctx.fill(x - 1, y - 1, x2 + 1, y,    withAlpha(0x000000, (int)(alpha * 0.5f)));
        ctx.fill(x - 1, y2,    x2 + 1, y2 + 1, withAlpha(0x000000, (int)(alpha * 0.5f)));
        ctx.fill(x - 1, y,     x,       y2,    withAlpha(0x000000, (int)(alpha * 0.5f)));
        ctx.fill(x2,    y,     x2 + 1,  y2,    withAlpha(0x000000, (int)(alpha * 0.5f)));

        // Угловые линии — top-left
        ctx.fill(x, y,       x + len, y + 1,   c);
        ctx.fill(x, y,       x + 1,   y + len, c);
        // top-right
        ctx.fill(x2 - len, y,     x2,     y + 1,   c);
        ctx.fill(x2 - 1,   y,     x2,     y + len, c);
        // bottom-left
        ctx.fill(x, y2 - 1,  x + len, y2,      c);
        ctx.fill(x, y2 - len, x + 1,  y2,      c);
        // bottom-right
        ctx.fill(x2 - len, y2 - 1, x2,    y2,      c);
        ctx.fill(x2 - 1,   y2 - len, x2,  y2,      c);

        // Сторонние слабые линии между углами
        ctx.fill(x + len, y,      x2 - len, y + 1,      c2);
        ctx.fill(x + len, y2 - 1, x2 - len, y2,         c2);
        ctx.fill(x,       y + len, x + 1,   y2 - len,   c2);
        ctx.fill(x2 - 1,  y + len, x2,      y2 - len,   c2);
    }

    private void renderFull(DrawContext ctx, int x, int y, int x2, int y2, int color, int alpha) {
        // Тонкая рамка целиком
        ctx.fill(x, y,    x2, y + 1,  withAlpha(color, alpha));
        ctx.fill(x, y2-1, x2, y2,     withAlpha(color, alpha));
        ctx.fill(x,    y, x + 1,  y2, withAlpha(color, alpha));
        ctx.fill(x2-1, y, x2,    y2,  withAlpha(color, alpha));
        // Внутренний полупрозрачный фон
        ctx.fill(x + 1, y + 1, x2 - 1, y2 - 1, withAlpha(0x000000, (int)(alpha * 0.25f)));
    }

    private void renderMinimal(DrawContext ctx, int x, int y, int x2, int y2, int color, int alpha) {
        int c = withAlpha(color, alpha);
        // Только горизонтальные линии
        ctx.fill(x, y,    x2, y + 1, c);
        ctx.fill(x, y2-1, x2, y2,    c);
    }

    private void renderGlow(DrawContext ctx, int x, int y, int x2, int y2, int color, int alpha) {
        // Многослойный glow эффект
        for (int i = 4; i >= 1; i--) {
            int ga = (int)(alpha * (0.08f * (5 - i)));
            int gc = withAlpha(color, ga);
            int ofs = i;
            ctx.fill(x - ofs, y - ofs, x2 + ofs, y - ofs + 1, gc);
            ctx.fill(x - ofs, y2 + ofs - 1, x2 + ofs, y2 + ofs, gc);
            ctx.fill(x - ofs, y - ofs, x - ofs + 1, y2 + ofs, gc);
            ctx.fill(x2 + ofs - 1, y - ofs, x2 + ofs, y2 + ofs, gc);
        }
        renderCorners(ctx, x, y, x2, y2, color, alpha);
    }

    // ── Линия трейсер ────────────────────────────────────────────────────────

    private void renderLine(DrawContext ctx, int bx, int by, int bx2, int by2, int color, int alpha) {
        String lm = lineMode.getCurrentOption();
        if (lm.equals("Выкл")) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        int startX = sw / 2;
        int startY = lm.equals("Низ экрана") ? sh : sh / 2;
        int endX   = bx + (bx2 - bx) / 2;
        int endY   = by + (by2 - by) / 2;

        drawLine(ctx, startX, startY, endX, endY, withAlpha(color, (int)(alpha * 0.6f)));
    }

    // ── Проекция AABB → экран ────────────────────────────────────────────────

    private int[] projectEntityBox(LivingEntity entity) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null || mc.world == null) return null;

        Box box = entity.getBoundingBox();
        double[] xs = {box.minX, box.maxX};
        double[] ys = {box.minY, box.maxY};
        double[] zs = {box.minZ, box.maxZ};

        int minSX = Integer.MAX_VALUE, minSY = Integer.MAX_VALUE;
        int maxSX = Integer.MIN_VALUE, maxSY = Integer.MIN_VALUE;

        // Частичный тик для интерполяции
        float tickDelta = mc.getRenderTickCounter().getTickDelta(false);
        Vec3d camPos = mc.gameRenderer.getCamera().getPos();

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        for (double ex : xs) for (double ey : ys) for (double ez : zs) {
            int[] sc = worldToScreen(ex, ey, ez, camPos, w, h, mc);
            if (sc == null) return null; // за спиной
            if (sc[0] < minSX) minSX = sc[0];
            if (sc[1] < minSY) minSY = sc[1];
            if (sc[0] > maxSX) maxSX = sc[0];
            if (sc[1] > maxSY) maxSY = sc[1];
        }

        if (minSX == Integer.MAX_VALUE) return null;
        return new int[]{minSX, minSY, maxSX, maxSY};
    }

    /**
     * Простая проекция: берём вектор от камеры до точки,
     * смотрим на dot с вектором взгляда. Если за камерой — null.
     * Используем FOV и размер окна для преобразования.
     */
    private int[] worldToScreen(double wx, double wy, double wz, Vec3d cam, int sw, int sh, MinecraftClient mc) {
        // Вектор от камеры к точке в мировом пространстве
        double dx = wx - cam.x;
        double dy = wy - cam.y;
        double dz = wz - cam.z;

        // Получить угловые параметры камеры
        float yaw   = mc.gameRenderer.getCamera().getYaw();
        float pitch = mc.gameRenderer.getCamera().getPitch();

        double yawR   = Math.toRadians(yaw);
        double pitchR = Math.toRadians(pitch);

        // Поворот в пространство камеры (правосторонняя система)
        double sinYaw   = Math.sin(yawR);
        double cosYaw   = Math.cos(yawR);
        double sinPitch = Math.sin(pitchR);
        double cosPitch = Math.cos(pitchR);

        // Camera-space X, Y, Z
        double cx = dx * cosYaw  - dz * (-sinYaw);
        double cy = -dx * sinYaw * sinPitch + dy * cosPitch - dz * cosYaw * sinPitch;
        double cz = dx * sinYaw * cosPitch + dy * sinPitch + dz * (-cosYaw) * cosPitch;

        if (cz < 0.1) return null; // за камерой

        // Проекция через FOV
        float fovY = mc.options.getFov().getValue();
        double f = (sh / 2.0) / Math.tan(Math.toRadians(fovY / 2.0));

        int sx = (int)(sw / 2.0 + cx / cz * f);
        int sy = (int)(sh / 2.0 - cy / cz * f);

        return new int[]{sx, sy};
    }

    // ── Утилиты ──────────────────────────────────────────────────────────────

    private void drawLine(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        // Реализация линии через заполнение пикселей по алгоритму Брезенхема
        int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        int steps = Math.max(dx, dy);
        // Лимит шагов чтобы не тормозило при огромных расстояниях
        int limit = Math.min(steps, 1200);
        for (int i = 0; i < limit; i++) {
            ctx.fill(x1, y1, x1 + 1, y1 + 1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx)  { err += dx; y1 += sy; }
        }
    }

    private int hpColor(float ratio, int alpha) {
        int r, g;
        if (ratio > 0.5f) {
            float t = (ratio - 0.5f) * 2f;
            r = (int)((1f - t) * 255);
            g = 238;
        } else {
            float t = ratio * 2f;
            r = 238;
            g = (int)(t * 200);
        }
        return (alpha << 24) | (r << 16) | (g << 8) | 0x22;
    }

    private static int withAlpha(int rgb, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }
}
