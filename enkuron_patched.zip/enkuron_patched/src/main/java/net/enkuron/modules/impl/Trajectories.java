package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Trajectories — рассчитывает и показывает траекторию снаряда.
 *
 * Настройки:
 *   Длина линии   — количество симулируемых тиков (20–120)
 *   Цвет линии    — Normal / Rainbow / Team
 *   Показ точки   — отображать точку удара
 */
public class Trajectories extends Module {

    private static final double ARROW_GRAVITY = 0.05;
    private static final double THROW_GRAVITY = 0.03;

    private static final String[] COLOR_MODES = {"Normal", "Rainbow", "Team"};

    private final Setting lineLength   = new Setting("Длина линии",   60.0, 20.0, 120.0);
    private final Setting colorMode    = new Setting("Цвет линии",    COLOR_MODES, 0);
    private final Setting showImpact   = new Setting("Точка удара",   true);

    // FIX: volatile + immutable snapshot вместо изменяемых публичных static полей.
    // Рендер-поток читает snapshot, тик-поток создаёт новый список и атомарно заменяет ссылку.
    public static volatile List<Vec3d> trajectoryPoints = new ArrayList<>();
    public static volatile Vec3d       impactPoint      = null;

    public Trajectories() {
        super("Trajectories", "Показывает линию полёта лука, жемчуга и снежков", Category.VISUAL);
        addSetting(lineLength);
        addSetting(colorMode);
        addSetting(showImpact);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) {
            trajectoryPoints = new ArrayList<>();
            impactPoint = null;
            return;
        }

        ItemStack held = mc.player.getMainHandStack();
        if (!isProjectileItem(held)) {
            trajectoryPoints = new ArrayList<>();
            impactPoint = null;
            return;
        }

        Vec3d pos = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1.0f);
        double speed = getProjectileSpeed(held);
        Vec3d velocity = look.multiply(speed);

        double gravity = isArrow(held) ? ARROW_GRAVITY : THROW_GRAVITY;
        int ticks = (int) lineLength.getValue();

        // FIX: строим локальный список, затем атомарно меняем ссылку
        List<Vec3d> newPoints = new ArrayList<>(ticks);
        Vec3d newImpact = null;

        for (int i = 0; i < ticks; i++) {
            newPoints.add(pos);
            pos = pos.add(velocity);
            velocity = velocity.add(0, -gravity, 0);
            velocity = velocity.multiply(0.99);

            BlockPos bPos = BlockPos.ofFloored(pos.x, pos.y, pos.z);
            if (!mc.world.getBlockState(bPos).isAir()) {
                if (showImpact.getState()) newImpact = pos;
                break;
            }
        }

        // Атомарная замена — рендер-поток никогда не получит частично заполненный список
        trajectoryPoints = newPoints;
        impactPoint = newImpact;
    }

    @Override
    public void onDisable() {
        trajectoryPoints = new ArrayList<>();
        impactPoint = null;
    }

    private boolean isProjectileItem(ItemStack stack) {
        Item item = stack.getItem();
        return item instanceof BowItem || item instanceof CrossbowItem
            || item instanceof TridentItem || item instanceof SnowballItem
            || item instanceof EggItem || item instanceof EnderPearlItem;
    }

    private boolean isArrow(ItemStack stack) {
        Item item = stack.getItem();
        return item instanceof BowItem || item instanceof CrossbowItem;
    }

    private double getProjectileSpeed(ItemStack stack) {
        Item item = stack.getItem();
        if (item instanceof BowItem)       return 1.5;
        if (item instanceof CrossbowItem)  return 1.6;
        if (item instanceof TridentItem)   return 2.5;
        return 1.0;
    }
}
