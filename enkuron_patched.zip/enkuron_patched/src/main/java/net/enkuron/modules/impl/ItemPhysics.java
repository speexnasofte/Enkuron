package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.entity.ItemEntity;

/**
 * ItemPhysics — визуальная физика предметов на земле.
 *
 * FIX 1.21.4: Entity.prevPitch — protected, не доступен напрямую.
 * Решение: убираем запись в prevPitch (она нужна только для интерполяции
 * рендера, без неё предмет просто резко встанет — визуально приемлемо).
 * Вместо этого используем только setYaw/setPitch публичные методы.
 *
 * rotation — предметы поворачиваются плоско (pitch=90°) и вращаются
 * bounce    — лёгкий отскок при появлении предмета
 */
public class ItemPhysics extends Module {
    private final Setting rotation = new Setting("Вращение", true);
    private final Setting bounce   = new Setting("Отскок",   true);

    public ItemPhysics() {
        super("ItemPhysics", "Реалистичная физика предметов на земле", Category.VISUAL);
        addSetting(rotation);
        addSetting(bounce);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;

        for (ItemEntity item : mc.world.getEntitiesByClass(ItemEntity.class,
                mc.player.getBoundingBox().expand(32), e -> true)) {

            if (rotation.getState()) {
                // Pitch = 90° — предмет лежит плоско
                // FIX: не трогаем prevPitch (protected) — просто ставим pitch
                item.setPitch(90f);

                // Медленное вращение по yaw при движении
                if (item.getVelocity().horizontalLengthSquared() > 1e-4) {
                    item.setYaw(item.getYaw() + 8f);
                }
            }

            if (bounce.getState() && item.age == 1) {
                // При появлении — небольшой импульс вверх
                var vel = item.getVelocity();
                item.setVelocity(vel.x, Math.max(vel.y, 0.25), vel.z);
            }
        }
    }
}
