package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.NotificationManager;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;

/**
 * MaceHelper — помощник для булавы (Mace, MC 1.21+).
 *
 * Функции:
 *  1. HUD        — высота падения + прогноз урона + шкала
 *  2. AutoEquip  — берёт булаву при достижении нужной высоты падения
 *  3. Alert      — тост при достаточной высоте
 *  4. WeaponCombo — удар мечом/топором → свап на булаву → удар булавой
 *
 * WeaponCombo:
 *   Вы бьёте мечом или топором по игроку/мобу.
 *   Модуль засекает удар, ждёт N тиков (цель получила knockback),
 *   мгновенно ставит булаву в руку и атакует ту же цель ещё раз.
 *   Затем возвращает исходный слот обратно.
 *   Результат: два удара подряд — меч + булава — максимальный burst урон.
 */
public class MaceHelper extends Module {

    private final Setting showHUD      = new Setting("Показать HUD",        true);
    private final Setting autoEquip    = new Setting("Авто-экип",           true);
    private final Setting minHeight    = new Setting("Мин. высота (блок)",  5.0,  2.0, 50.0);
    private final Setting maxDisplay   = new Setting("Макс. шкала (блок)", 30.0, 10.0, 100.0);
    private final Setting alertMode    = new Setting("Уведомление",         true);
    private final Setting onlyTarget   = new Setting("Только цель",         true);
    private final Setting targetRange  = new Setting("Радиус цели",         12.0,  4.0, 24.0);
    private final Setting weaponCombo  = new Setting("Weapon Combo",        true);
    private final Setting comboDelay   = new Setting("Задержка комбо (т)",  2.0,   1.0, 10.0);
    private final Setting comboRestore = new Setting("Возврат слота (т)",   4.0,   2.0, 20.0);

    // Состояние падения
    private double  fallStart    = Double.MIN_VALUE;
    private double  fallBlocks   = 0;
    private boolean wasFalling   = false;
    private boolean alerted      = false;
    private int     prevSlot     = -1;
    private boolean equipped     = false;

    // Состояние WeaponCombo
    private enum ComboPhase { IDLE, WAITING, SWAPPED }
    private ComboPhase   comboPhase    = ComboPhase.IDLE;
    private int          comboTimer    = 0;
    private int          comboSlotSave = -1;
    private LivingEntity comboTarget   = null;

    // HUD анимация
    private float displayRatio = 0f;
    private int   comboFlash   = 0;

    public MaceHelper() {
        super("MaceHelper", "Помощник булавы: HUD, авто-экип, комбо меч/топор -> булава", Category.COMBAT);
        addSetting(showHUD);
        addSetting(autoEquip);
        addSetting(minHeight);
        addSetting(maxDisplay);
        addSetting(alertMode);
        addSetting(onlyTarget);
        addSetting(targetRange);
        addSetting(weaponCombo);
        addSetting(comboDelay);
        addSetting(comboRestore);
        this.x = 5;
        this.y = 300;
    }

    @Override
    public void onEnable() {
        fallStart = Double.MIN_VALUE; fallBlocks = 0;
        wasFalling = false; alerted = false;
        prevSlot = -1; equipped = false;
        comboPhase = ComboPhase.IDLE; comboTimer = 0;
        comboSlotSave = -1; comboTarget = null;
        displayRatio = 0f; comboFlash = 0;
    }

    @Override
    public void onDisable() {
        restoreEquipSlot();
        cancelCombo();
        alerted = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tickFall();
        tickCombo();
        float t = (float) Math.min(fallBlocks / maxDisplay.getValue(), 1.0);
        displayRatio += (t - displayRatio) * 0.15f;
        if (comboFlash > 0) comboFlash--;
    }

    // Логика падения
    private void tickFall() {
        boolean falling  = mc.player.isFalling() || mc.player.getVelocity().y < -0.1;
        boolean onGround = mc.player.isOnGround();

        if (falling && !onGround) {
            if (!wasFalling) fallStart = mc.player.getY();
            fallBlocks = Math.max(0, fallStart - mc.player.getY());
            wasFalling = true;
        } else {
            if (wasFalling) {
                fallBlocks = 0; fallStart = Double.MIN_VALUE;
                alerted = false; restoreEquipSlot();
            }
            wasFalling = false; fallBlocks = 0;
        }

        if (autoEquip.getState() && wasFalling && fallBlocks >= minHeight.getValue()
                && !equipped && hasMaceInHotbar()) {
            if (!onlyTarget.getState() || hasNearbyTarget()) equipMaceForFall();
        }

        if (alertMode.getState() && wasFalling && !alerted && fallBlocks >= minHeight.getValue()) {
            if (!onlyTarget.getState() || hasNearbyTarget()) {
                NotificationManager.push("MaceHelper",
                    String.format("Удар: ~%.0f урона! (%.1f бл.)", estimateDamage(fallBlocks), fallBlocks),
                    NotificationManager.Type.WARNING, 2000);
                alerted = true;
            }
        }
    }

    // Логика WeaponCombo
    private void tickCombo() {
        if (!weaponCombo.getState()) return;

        switch (comboPhase) {
            case IDLE -> {
                // Ждём: держим меч/топор, кнопка атаки нажата, рядом есть цель
                if (!isMeleeWeaponHeld()) return;
                if (!mc.options.attackKey.isPressed()) return;
                if (!hasMaceInHotbar()) return;
                LivingEntity target = findAttackTarget();
                if (target == null) return;
                // Запускаем комбо
                comboTarget   = target;
                comboSlotSave = mc.player.getInventory().selectedSlot;
                comboPhase    = ComboPhase.WAITING;
                comboTimer    = (int) comboDelay.getValue();
            }
            case WAITING -> {
                if (--comboTimer <= 0) {
                    int maceSlot = findMaceInHotbar();
                    if (maceSlot == -1 || comboTarget == null || !comboTarget.isAlive()) {
                        cancelCombo(); return;
                    }
                    // Свапаем на булаву и бьём
                    mc.player.getInventory().selectedSlot = maceSlot;
                    mc.interactionManager.attackEntity(mc.player, comboTarget);
                    mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                    comboFlash = 8;
                    comboPhase = ComboPhase.SWAPPED;
                    comboTimer = (int) comboRestore.getValue();
                }
            }
            case SWAPPED -> {
                if (--comboTimer <= 0) {
                    // Возвращаем слот меча
                    if (comboSlotSave != -1)
                        mc.player.getInventory().selectedSlot = comboSlotSave;
                    cancelCombo();
                }
            }
        }
    }

    private void cancelCombo() {
        comboPhase = ComboPhase.IDLE; comboTimer = 0;
        comboSlotSave = -1; comboTarget = null;
    }

    // Рендер HUD
    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || !showHUD.getState() || mc.player == null) return;
        if (!hasMaceEquipped() && !hasMaceInHotbar()) return;

        double dmg   = estimateDamage(fallBlocks);
        boolean ready= fallBlocks >= minHeight.getValue();
        boolean combo = comboPhase != ComboPhase.IDLE;

        int w = 120, h = 52;
        this.width = w + 4; this.height = h + 4;
        int bx = x, by = y;

        context.fill(bx - 2, by - 2, bx + w + 2, by + h + 2, 0xBB0A0A12);

        int hColor = combo && (comboFlash % 4 < 2) ? 0xFFFFCC44
                   : ready ? 0xFF44DD88 : 0xFF8844FF;
        context.fill(bx - 2, by - 2, bx + w + 2, by - 1, hColor);
        context.drawText(mc.textRenderer, "* Mace Helper", bx, by + 1, hColor, true);

        // Статус комбо или высота
        if (combo) {
            String cs = comboPhase == ComboPhase.WAITING ? "Combo: ожидание..." : "Combo: удар булавой!";
            int cc = comboPhase == ComboPhase.WAITING ? 0xFFFFCC44 : 0xFF44FF88;
            context.drawText(mc.textRenderer, cs, bx, by + 12, cc, false);
        } else {
            context.drawText(mc.textRenderer,
                String.format("Высота: %.1f блок", fallBlocks), bx, by + 12, 0xFFAAAAAA, false);
        }

        int dmgColor = dmg < 10 ? 0xFFFFFFFF : dmg < 25 ? 0xFFFFCC44 : 0xFFFF4444;
        context.drawText(mc.textRenderer, String.format("Урон: ~%.0f", dmg), bx, by + 22, dmgColor, false);

        // Статус оружий
        String ws = "[" + (isMeleeWeaponHeld() ? "Меч OK" : "Нет меча") + " | "
                      + (hasMaceInHotbar()     ? "Булава OK" : "Нет булавы") + "]";
        int wc = (isMeleeWeaponHeld() && hasMaceInHotbar()) ? 0xFF44FF88 : 0xFFFF5555;
        context.drawText(mc.textRenderer, ws, bx, by + 32, wc, false);

        // Шкала
        int barY = by + h - 6;
        context.fill(bx, barY, bx + w, barY + 4, 0xFF1A1A2A);
        context.fill(bx, barY, bx + (int)(w * displayRatio), barY + 4, barColor(displayRatio));

        double minRatio = Math.min(minHeight.getValue() / maxDisplay.getValue(), 1.0);
        int minX = bx + (int)(w * minRatio);
        if (minX < bx + w) context.fill(minX, barY - 1, minX + 1, barY + 5, 0xFFFFFFAA);
    }

    // Вспомогательные
    private double estimateDamage(double fall) {
        if (fall <= 0) return 0;
        return 8.0 + Math.floor(fall) * 1.5 + Math.pow(fall, 1.4) * 0.3;
    }

    private boolean isMeleeWeaponHeld() {
        if (mc.player == null) return false;
        ItemStack held = mc.player.getMainHandStack();
        return !held.isEmpty() && (held.getItem() instanceof SwordItem || held.getItem() instanceof AxeItem);
    }

    private LivingEntity findAttackTarget() {
        return mc.world.getEntitiesByClass(
            LivingEntity.class,
            mc.player.getBoundingBox().expand(3.5),
            e -> e != mc.player && e.isAlive()
              && (e instanceof PlayerEntity || e instanceof net.minecraft.entity.mob.HostileEntity)
        ).stream()
         .min((a, b) -> Double.compare(a.squaredDistanceTo(mc.player), b.squaredDistanceTo(mc.player)))
         .orElse(null);
    }

    private void equipMaceForFall() {
        int slot = findMaceInHotbar();
        if (slot == -1 || equipped) return;
        prevSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
        equipped = true;
    }

    private void restoreEquipSlot() {
        if (equipped && prevSlot != -1 && mc.player != null)
            mc.player.getInventory().selectedSlot = prevSlot;
        equipped = false; prevSlot = -1;
    }

    private boolean hasMaceInHotbar() { return findMaceInHotbar() != -1; }

    private int findMaceInHotbar() {
        for (int i = 0; i < 9; i++)
            if (mc.player.getInventory().getStack(i).getItem() == Items.MACE) return i;
        return -1;
    }

    private boolean hasMaceEquipped() {
        ItemStack held = mc.player.getMainHandStack();
        return !held.isEmpty() && held.getItem() == Items.MACE;
    }

    private boolean hasNearbyTarget() {
        return !mc.world.getEntitiesByClass(
            LivingEntity.class,
            mc.player.getBoundingBox().expand(targetRange.getValue()),
            e -> e != mc.player && e.isAlive()
              && (e instanceof PlayerEntity || e instanceof net.minecraft.entity.mob.HostileEntity)
        ).isEmpty();
    }

    private int barColor(float ratio) {
        if (ratio < 0.33f) {
            float t = ratio / 0.33f;
            return EnkuronColor.toARGB((int)(t * 68), (int)(100 + t * 122), (int)(255 - t * 200), 255);
        } else if (ratio < 0.66f) {
            float t = (ratio - 0.33f) / 0.33f;
            return EnkuronColor.toARGB((int)(68 + t * 187), (int)(222 - t * 22), (int)(55 - t * 35), 255);
        } else {
            float t = (ratio - 0.66f) / 0.34f;
            return EnkuronColor.toARGB(255, (int)(200 - t * 200), 20, 255);
        }
    }
}
