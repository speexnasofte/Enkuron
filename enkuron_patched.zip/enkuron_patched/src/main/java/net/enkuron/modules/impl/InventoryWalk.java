package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

/**
 * InventoryWalk — движение при открытом инвентаре.
 *
 * FIX 1.21.4: LivingEntity.forwardSpeed / sidewaysSpeed — protected.
 * Решение: используем Input через mc.player.input вместо прямой записи.
 * В 1.21.4 у ClientPlayerEntity есть поле input типа Input,
 * у которого можно установить movementForward / movementSideways.
 * Но это тоже может быть protected — безопасный путь: simulate key presses
 * через KeyBinding.setPressed() который обрабатывается в tickMovement.
 */
public class InventoryWalk extends Module {
    private final Setting onlyForward = new Setting("Только вперёд", true);

    public InventoryWalk() {
        super("InventoryWalk", "Позволяет ходить с открытым инвентарём", Category.MOVEMENT);
        addSetting(onlyForward);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen == null) return;

        // Работаем только когда открыт инвентарь или контейнер
        boolean isInv = mc.currentScreen instanceof InventoryScreen
                     || mc.currentScreen instanceof GenericContainerScreen;
        if (!isInv) return;

        // FIX: используем KeyBinding.setPressed() — это работает в 1.21.4.
        // setPressed() устанавливает флаг timesPressed и isPressed,
        // которые читает ClientPlayerEntity.tickMovement().
        if (onlyForward.getState()) {
            if (mc.options.forwardKey.isPressed()) {
                // Клавиша уже зажата пользователем — движение будет работать
                // даже при открытом GUI если мы снимем блокировку экрана.
                // В 1.21.4 MC блокирует ввод при currentScreen != null,
                // поэтому форсируем через setPressed.
                mc.options.forwardKey.setPressed(true);
            }
        } else {
            // Передаём все направления
            mc.options.forwardKey.setPressed(isKeyDown(mc.options.forwardKey));
            mc.options.backKey.setPressed(isKeyDown(mc.options.backKey));
            mc.options.leftKey.setPressed(isKeyDown(mc.options.leftKey));
            mc.options.rightKey.setPressed(isKeyDown(mc.options.rightKey));
            mc.options.jumpKey.setPressed(isKeyDown(mc.options.jumpKey));
        }
    }

    @Override
    public void onDisable() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }

    /** Проверяет физически нажата ли клавиша через GLFW (FIX 1.21.4: KeyBinding.isKeyPressed удалён). */
    private boolean isKeyDown(net.minecraft.client.option.KeyBinding key) {
        net.minecraft.client.util.InputUtil.Key boundKey =
            net.minecraft.client.util.InputUtil.fromTranslationKey(key.getBoundKeyTranslationKey());
        long window = net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle();
        return org.lwjgl.glfw.GLFW.glfwGetKey(window, boundKey.getCode()) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
    }
}
