package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * PotionHUD — отображает активные эффекты игрока на экране.
 *
 * Показывает иконку эффекта (или цветной квадрат), название и таймер.
 * Эффекты с истекающим временем подсвечиваются красным.
 *
 * Настройки:
 *   Показать иконки   — рисовать иконки эффектов
 *   Показать время    — отображать оставшееся время
 *   Показать название — отображать название эффекта
 *   Порог (сек)       — подсветка при N секундах до конца (5–60)
 *   Сортировка        — По времени / По названию / По уровню
 *   Ориентация        — Вертикально / Горизонтально
 */
public class PotionHUD extends Module {

    private static final String[] SORTS   = {"По времени", "По названию", "По уровню"};
    private static final String[] ORIENTS = {"Вертикально", "Горизонтально"};

    private final Setting showIcons  = new Setting("Иконки",       true);
    private final Setting showTime   = new Setting("Время",        true);
    private final Setting showName   = new Setting("Название",     true);
    private final Setting warnSec    = new Setting("Порог (сек)",  10.0, 5.0, 60.0);
    private final Setting sortMode   = new Setting("Сортировка",   SORTS, 0);
    private final Setting orient     = new Setting("Ориентация",   ORIENTS, 0);

    private static final int ICON_SIZE = 16;
    private static final int PAD       = 3;
    private static final int ROW_H     = ICON_SIZE + PAD + 2;

    public PotionHUD() {
        super("PotionHUD", "Показывает активные эффекты зелий на экране", Category.HUD);
        addSetting(showIcons);
        addSetting(showTime);
        addSetting(showName);
        addSetting(warnSec);
        addSetting(sortMode);
        addSetting(orient);
        this.x = 5;
        this.y = 200;
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        List<StatusEffectInstance> effects = getSortedEffects();
        if (effects.isEmpty()) return;

        boolean horizontal = "Горизонтально".equals(orient.getCurrentOption());
        int warnTicks = (int)(warnSec.getValue() * 20);

        // Вычисляем размер HUD
        int textWidth = 0;
        if (showName.getState() || showTime.getState()) {
            for (StatusEffectInstance e : effects) {
                String label = buildLabel(e);
                int w = mc.textRenderer.getWidth(label);
                if (w > textWidth) textWidth = w;
            }
        }

        int iconW = showIcons.getState() ? ICON_SIZE + PAD : 0;
        int rowW  = iconW + textWidth + 4;

        if (horizontal) {
            this.width  = effects.size() * (rowW + 4) - 4;
            this.height = ROW_H + 4;
        } else {
            this.width  = rowW + 6;
            this.height = effects.size() * (ROW_H + 2) + 2;
        }

        // Фон
        context.fill(x - 2, y - 2, x + this.width, y + this.height, 0xBB111116);
        context.fill(x - 2, y - 2, x + this.width, y - 1, 0xFF8844FF);

        int drawX = x;
        int drawY = y;

        for (StatusEffectInstance eff : effects) {
            boolean expiring = eff.getDuration() < warnTicks && eff.getDuration() > 0;
            int textColor = expiring ? 0xFFFF5555 : 0xFFFFFFFF;

            // Иконка — цветной прямоугольник с первой буквой (упрощённо)
            if (showIcons.getState()) {
                int effColor = getEffectColor(eff);
                context.fill(drawX, drawY, drawX + ICON_SIZE, drawY + ICON_SIZE,
                    expiring ? pulse(effColor) : effColor);
                // Первая буква эффекта
                String letter = getEffectName(eff).substring(0, 1).toUpperCase();
                context.drawText(mc.textRenderer, letter,
                    drawX + 4, drawY + 4, 0xFFFFFFFF, true);
            }

            // Текст
            int textX = drawX + (showIcons.getState() ? ICON_SIZE + PAD : 0);
            int textY = drawY + (ROW_H - mc.textRenderer.fontHeight) / 2;

            if (showName.getState() || showTime.getState()) {
                String label = buildLabel(eff);
                context.drawText(mc.textRenderer, label, textX, textY, textColor, true);
            }

            if (horizontal) {
                drawX += rowW + 4;
            } else {
                drawY += ROW_H + 2;
            }
        }
    }

    // ── Вспомогательные ─────────────────────────────────────────────────────

    private List<StatusEffectInstance> getSortedEffects() {
        List<StatusEffectInstance> list = new ArrayList<>(
            mc.player.getStatusEffects()
        );

        switch (sortMode.getCurrentOption()) {
            case "По времени"  -> list.sort(Comparator.comparingInt(StatusEffectInstance::getDuration));
            case "По названию" -> list.sort(Comparator.comparing(e -> getEffectName(e)));
            case "По уровню"   -> list.sort(Comparator.comparingInt(StatusEffectInstance::getAmplifier).reversed());
        }
        return list;
    }

    private String buildLabel(StatusEffectInstance eff) {
        StringBuilder sb = new StringBuilder();
        if (showName.getState()) {
            sb.append(getEffectName(eff));
            if (eff.getAmplifier() > 0) sb.append(" ").append(toRoman(eff.getAmplifier() + 1));
        }
        if (showTime.getState()) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(formatTime(eff.getDuration()));
        }
        return sb.toString();
    }

    private String getEffectName(StatusEffectInstance eff) {
        // Получаем translatable key и берём последнюю часть
        String key = eff.getEffectType().value().getTranslationKey();
        String[] parts = key.split("\\.");
        String raw = parts[parts.length - 1];
        // snake_case → заглавная первая
        return Character.toUpperCase(raw.charAt(0)) + raw.substring(1).replace('_', ' ');
    }

    private int getEffectColor(StatusEffectInstance eff) {
        int c = eff.getEffectType().value().getColor();
        return 0xFF000000 | (c & 0xFFFFFF);
    }

    /** Мигающий цвет для истекающего эффекта. */
    private int pulse(int baseColor) {
        double t = (System.currentTimeMillis() % 1000) / 1000.0;
        int alpha = (int)(150 + 105 * Math.sin(t * Math.PI * 2));
        return (alpha << 24) | (baseColor & 0x00FFFFFF);
    }

    private String formatTime(int ticks) {
        if (ticks == Integer.MAX_VALUE) return "∞";
        int sec = ticks / 20;
        if (sec >= 60) return (sec / 60) + ":" + String.format("%02d", sec % 60);
        return sec + "с";
    }

    private String toRoman(int n) {
        return switch (n) {
            case 2  -> "II";
            case 3  -> "III";
            case 4  -> "IV";
            case 5  -> "V";
            default -> String.valueOf(n);
        };
    }
}
