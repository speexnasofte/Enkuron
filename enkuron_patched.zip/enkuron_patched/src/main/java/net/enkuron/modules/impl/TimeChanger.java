package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * TimeChanger — меняет время суток визуально (клиентски).
 *
 * Реализация: каждый тик принудительно устанавливаем
 * mc.world.setTimeOfDay() — метод публичен в ClientWorld (Fabric 1.21.4).
 * Изменение видно только локально; на сервере время не меняется.
 *
 * Настройки:
 *   Время дня    — Полдень / Рассвет / Закат / Полночь / Пользователь
 *   Час (0–23)   — только при режиме "Пользователь"
 */
public class TimeChanger extends Module {

    private static final String[] TIMES = {"Полдень", "Рассвет", "Закат", "Полночь", "Пользователь"};

    private final Setting timeOfDay  = new Setting("Время дня", TIMES, 0);
    private final Setting customHour = new Setting("Час",        12.0, 0.0, 23.0);

    public TimeChanger() {
        super("TimeChanger", "Меняет время суток визуально для игрока", Category.VISUAL);
        addSetting(timeOfDay);
        addSetting(customHour);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        mc.world.setTimeOfDay(getTargetTime());
    }

    @Override
    public void onDisable() {
        // Сервер сам вышлет актуальное время при следующем пакете
    }

    /** Целевое время в игровых тиках (0–24000). */
    public long getTargetTime() {
        return switch (timeOfDay.getCurrentOption()) {
            case "Рассвет"      -> 0L;
            case "Закат"        -> 12000L;
            case "Полночь"      -> 18000L;
            case "Пользователь" -> (long)(customHour.getValue() / 24.0 * 24000);
            default             -> 6000L; // Полдень
        };
    }
}
