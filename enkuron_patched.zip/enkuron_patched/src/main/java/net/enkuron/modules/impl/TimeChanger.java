package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.world.GameRules;

/**
 * TimeChanger — меняет время суток визуально (клиентски).
 *
 * FIX 1.21.4: ClientWorld.setTimeOfDay() не существует.
 * Используем mc.world.getLevelProperties().getTimeOfDay() read-only,
 * а для клиентского override — пишем напрямую в поле timeOfDay через
 * reflection (единственный способ без миксина на ClientWorld).
 */
public class TimeChanger extends Module {

    private static final String[] TIMES = {"Полдень", "Рассвет", "Закат", "Полночь", "Пользователь"};

    private final Setting timeOfDay  = new Setting("Время дня", TIMES, 0);
    private final Setting customHour = new Setting("Час",        12.0, 0.0, 23.0);

    public TimeChanger() {
        super("TimeChanger", "Меняет время суток визуально для игрока", Category.VISUAL);
        addSetting(timeOfDay);
        addSetting(customHour);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        forceClientTime(getTargetTime());
    }

    @Override
    public void onDisable() {
        // Сервер вышлет актуальное время при следующем пакете — ничего делать не нужно
    }

    /** Целевое время в игровых тиках (0–24000). */
    public long getTargetTime() {
        return switch (timeOfDay.getCurrentOption()) {
            case "Рассвет"      -> 0L;
            case "Закат"        -> 12000L;
            case "Полночь"      -> 18000L;
            case "Пользователь" -> (long)(customHour.getValue() / 24.0 * 24000);
            default             -> 6000L; // Полдень
        };
    }

    /**
     * Принудительно устанавливает клиентское время через reflection.
     * ClientWorld хранит время в поле timeOfDay (mapped: "timeOfDay" / обфускация меняется).
     * Если reflection сломается — тихо игнорируем (модуль просто не будет работать).
     */
    private void forceClientTime(long ticks) {
        try {
            var world = mc.world;
            // Yarn mapping 1.21.4: net.minecraft.client.world.ClientWorld -> field timeOfDay (long)
            var field = world.getClass().getSuperclass().getDeclaredField("timeOfDay");
            field.setAccessible(true);
            field.setLong(world, ticks);
        } catch (Exception e) {
            // Fallback: пробуем поля с другим именем (obf/intermediary)
            try {
                for (var f : mc.world.getClass().getSuperclass().getDeclaredFields()) {
                    if (f.getType() == long.class) {
                        f.setAccessible(true);
                        // Ищем поле со значением близким к текущему времени суток (0..24000)
                        long val = f.getLong(mc.world);
                        if (val >= 0 && val < 24000) {
                            f.setLong(mc.world, ticks);
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
    }
}
