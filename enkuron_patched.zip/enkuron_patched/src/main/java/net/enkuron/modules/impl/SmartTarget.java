package net.enkuron.modules.impl;

import net.enkuron.combat.TargetManager;
import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

/**
 * SmartTarget v1 — управляет TargetManager и отображает минималистичный HUD.
 *
 * Это "мозг" системы таргетинга:
 *  - Тикает TargetManager каждый тик
 *  - Рендерит простой "lock-on" индикатор в HUD
 *  - Настраивает параметры TargetManager через свои Setting'и
 *  - Другие модули (TargetESP, TargetHUD) читают цель из TargetManager.getInstance()
 *
 * 📌 Не путать с TargetHUD — тот показывает подробную инфо о цели под прицелом.
 *    SmartTarget выбирает цель из мира (не только под прицелом).
 */
public class SmartTarget extends Module {

    private static final String[] PRIORITY_MODES = {"Score (дист+HP)", "Ближайший", "Низкий HP", "Последний удар", "Агрессивный"};

    private final Setting range        = new Setting("Дальность",        6.0,  2.0, 20.0);
    private final Setting fovFilter    = new Setting("FOV фильтр",        false);
    private final Setting fovAngle     = new Setting("FOV угол",          90.0, 10.0, 180.0);
    private final Setting switchDelay  = new Setting("Задержка смены мс", 300.0, 0.0, 2000.0);
    private final Setting requireLos   = new Setting("Только LoS",        true);
    private final Setting targetPlayers= new Setting("Цели: игроки",      true);
    private final Setting targetHostile= new Setting("Цели: враждебные",  true);
    private final Setting priorityMode = new Setting("Приоритет",         PRIORITY_MODES, 0);
    private final Setting showHUD      = new Setting("Показать Lock HUD",  true);
    private final Setting hudX         = new Setting("HUD X",              5.0, 0.0, 400.0);
    private final Setting hudY         = new Setting("HUD Y",              80.0, 0.0, 300.0);

    // анимация HUD
    private float lockAnim  = 0f;
    private float lockRotate = 0f;
    private LivingEntity prevTarget = null;

    public SmartTarget() {
        super("SmartTarget", "Умный таргетинг: выбирает цель по score + HUD-индикатор Lock-on", Category.COMBAT);
        addSetting(range);
        addSetting(fovFilter);
        addSetting(fovAngle);
        addSetting(switchDelay);
        addSetting(requireLos);
        addSetting(targetPlayers);
        addSetting(targetHostile);
        addSetting(priorityMode);
        addSetting(showHUD);
        addSetting(hudX);
        addSetting(hudY);
    }

    @Override
    public void onEnable() {
        TargetManager.getInstance().reset();
        lockAnim  = 0f;
        lockRotate = 0f;
    }

    @Override
    public void onDisable() {
        TargetManager.getInstance().reset();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        // Обновляем параметры TargetManager
        TargetManager tm = TargetManager.getInstance();
        tm.range         = range.getValue();
        tm.switchDelay   = (long) switchDelay.getValue();
        tm.requireLos    = requireLos.getState();
        tm.targetPlayers = targetPlayers.getState();
        tm.targetHostile = targetHostile.getState();
        tm.fovFilter     = fovFilter.getState();
        tm.fovAngle      = fovAngle.getValue();

        // Корректируем веса по режиму приоритета
        switch (priorityMode.getCurrentOption()) {
            case "Ближайший"      -> { tm.distWeight = 2.0; tm.hpWeight = 0.0; }
            case "Низкий HP"      -> { tm.distWeight = 0.3; tm.hpWeight = 1.5; }
            case "Последний удар" -> { tm.distWeight = 0.5; tm.hpWeight = 0.8; }
            case "Агрессивный"    -> { tm.distWeight = 1.2; tm.hpWeight = 0.2; tm.switchDelay = 0; }
            default               -> { tm.distWeight = 1.0; tm.hpWeight = 0.4; }
        }

        // Тикаем — обновляем цель
        LivingEntity target = tm.update();

        // Анимация HUD
        lockRotate += 2.5f;
        if (lockRotate >= 360f) lockRotate -= 360f;

        if (target != prevTarget) {
            lockAnim  = 0f;
            prevTarget = target;
        }
        lockAnim = AnimationUtils.lerp(lockAnim, target != null ? 1f : 0f, 0.12f);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || !showHUD.getState() || mc.player == null) return;
        if (lockAnim < 0.01f) return;

        LivingEntity target = TargetManager.getInstance().getTarget();
        if (target == null) target = prevTarget;
        if (target == null) return;

        int hx = (int) hudX.getValue();
        int hy = (int) hudY.getValue();
        int alpha = (int)(lockAnim * 0xFF);

        // Цвет из темы
        Theme theme = ThemeManager.get();
        int accent = theme != null ? (theme.accent & 0xFFFFFF) : 0x00CCFF;

        float hp = target.getHealth(), maxHp = target.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int hpColor = hpColor(ratio);

        // ── Lock-on индикатор ────────────────────────────────────────────────
        // Фон
        context.fill(hx, hy, hx + 110, hy + 30, withAlpha(0x08080F, (int)(lockAnim * 0xCC)));

        // Вращающиеся угловые акценты (имитация lock-on)
        float phase = (float) Math.toRadians(lockRotate);
        float pulse = 0.6f + 0.4f * (float) Math.sin(phase * 2);
        int ca = (int)(alpha * pulse);

        int cLen = 8;
        // top-left
        context.fill(hx,         hy,          hx + cLen,  hy + 1,    withAlpha(accent, ca));
        context.fill(hx,         hy,          hx + 1,     hy + cLen, withAlpha(accent, ca));
        // top-right
        context.fill(hx + 110 - cLen, hy,    hx + 110,   hy + 1,    withAlpha(accent, ca));
        context.fill(hx + 110 - 1,    hy,    hx + 110,   hy + cLen, withAlpha(accent, ca));
        // bottom-left
        context.fill(hx,         hy + 30 - 1, hx + cLen,  hy + 30,  withAlpha(accent, ca));
        context.fill(hx,         hy + 30 - cLen, hx + 1,  hy + 30,  withAlpha(accent, ca));
        // bottom-right
        context.fill(hx + 110 - cLen, hy + 30 - 1, hx + 110, hy + 30, withAlpha(accent, ca));
        context.fill(hx + 110 - 1, hy + 30 - cLen, hx + 110, hy + 30, withAlpha(accent, ca));

        // Левая цветовая полоска
        context.fill(hx, hy, hx + 2, hy + 30, withAlpha(hpColor, alpha));

        // Имя цели
        String prefix = target instanceof PlayerEntity ? "§e⊕ " : "§c⊕ ";
        String name = prefix + target.getName().getString();
        context.drawText(mc.textRenderer, name, hx + 6, hy + 4, withAlpha(0xFFFFFF, alpha), true);

        // HP текст
        String hpStr = String.format("§f%.1f§7/§f%.0f ❤", hp, maxHp);
        context.drawText(mc.textRenderer, hpStr, hx + 6, hy + 14, withAlpha(hpColor, alpha), false);

        // Weapon icon
        ItemStack weapon = target.getMainHandStack();
        if (!weapon.isEmpty()) {
            context.drawItem(weapon, hx + 94, hy + 7);
        }

        // HP bar внизу
        int barW = 106;
        context.fill(hx + 2, hy + 27, hx + 2 + barW,              hy + 29, withAlpha(0x1A1A1A, alpha));
        context.fill(hx + 2, hy + 27, hx + 2 + (int)(barW * ratio), hy + 29, withAlpha(hpColor, alpha));

        // Lock-on статус
        String lockText = lockAnim > 0.95f ? "§a● LOCKED" : "§e◌ LOCKING";
        int lw = mc.textRenderer.getWidth(lockText);
        context.drawText(mc.textRenderer, lockText, hx + 110 - lw - 3, hy + 4,
                withAlpha(lockAnim > 0.95f ? 0x44FF88 : 0xFFCC44, alpha), false);
    }

    // ── Утилиты ──────────────────────────────────────────────────────────────

    private int hpColor(float ratio) {
        if (ratio > 0.6f) return 0xFF44EE77;
        if (ratio > 0.3f) return 0xFFFFAA22;
        return 0xFFEE3333;
    }

    private static int withAlpha(int rgb, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }
}
