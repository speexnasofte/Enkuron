package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimap — мини-карта с радаром сущностей.
 *
 * Исправление: карта теперь вращается по yaw игрока (север не всегда вверх).
 * Логика вращения аналогична EntityRadar (cachedSin/cachedCos).
 *
 * Настройки:
 *   Масштаб      — zoom (1–5 блоков/пиксель)
 *   Размер       — ширина/высота карты (80–200 пикселей)
 *   Координаты   — отображать XZ внизу карты
 *   Вращение     — вращать карту по направлению взгляда
 */
public class Minimap extends Module {

    private final Setting zoom        = new Setting("Масштаб",     2.0, 1.0, 5.0);
    private final Setting mapSize     = new Setting("Размер",      110.0, 80.0, 200.0);
    private final Setting showCoords  = new Setting("Координаты",  true);
    private final Setting rotate      = new Setting("Вращение",    true); // FIX: новая настройка

    private int tickCounter = 0;
    private int textTick    = 0;
    private String cachedCoords = "";

    // FIX: хранит угол поворота для правильного вращения точек
    private double cachedSin = 0, cachedCos = 1;

    private record MinimapDot(int dx, int dz, int color) {}
    private final List<MinimapDot> cachedDots = new ArrayList<>();

    public Minimap() {
        super("Minimap", "Мини-карта с радаром сущностей", Category.HUD);
        addSetting(zoom);
        addSetting(mapSize);
        addSetting(showCoords);
        addSetting(rotate);
        this.x = 10; this.y = 10;
        this.width = 110; this.height = 110;
    }

    @Override public void onEnable() { cachedDots.clear(); cachedCoords = ""; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        int size = (int) mapSize.getValue();
        this.width = size; this.height = size;

        if (++textTick >= 10) {
            textTick = 0;
            cachedCoords = (int)mc.player.getX() + ", " + (int)mc.player.getZ();
        }

        if (++tickCounter < 3) return;
        tickCounter = 0;

        // FIX: пересчитываем sin/cos от yaw каждый update-цикл
        if (rotate.getState()) {
            double rad = Math.toRadians(mc.player.getYaw());
            cachedSin = Math.sin(rad);
            cachedCos = Math.cos(rad);
        } else {
            cachedSin = 0;
            cachedCos = 1;
        }

        cachedDots.clear();
        float z = (float) zoom.getValue();
        int half = size / 2;
        Vec3d playerPos = mc.player.getPos();

        // FIX: используем getEntitiesByClass с bounding box вместо полного обхода мира
        double worldRadius = half / z + 2.0;
        net.minecraft.util.math.Box searchBox = mc.player.getBoundingBox().expand(worldRadius, 64, worldRadius);
        java.util.List<LivingEntity> entities = mc.world.getEntitiesByClass(
            LivingEntity.class, searchBox, e -> e != mc.player && e.isAlive()
        );

        for (LivingEntity entity : entities) {
            double rawX = (entity.getX() - playerPos.x) * z;
            double rawZ = (entity.getZ() - playerPos.z) * z;

            // FIX: поворачиваем точку по yaw игрока
            int dx, dz;
            if (rotate.getState()) {
                dx = (int)( rawX * cachedCos + rawZ * cachedSin);
                dz = (int)(-rawX * cachedSin + rawZ * cachedCos);
            } else {
                dx = (int) rawX;
                dz = (int) rawZ;
            }

            if (Math.abs(dx) >= half - 4 || Math.abs(dz) >= half - 4) continue;

            int color;
            if      (entity instanceof PlayerEntity)   color = 0xFF6A0DAD;
            else if (entity instanceof CreeperEntity)  color = 0xFF00FF00;
            else if (entity instanceof SkeletonEntity) color = 0xFFCCCCCC;
            else if (entity instanceof HostileEntity)  color = 0xFFFF4444;
            else                                       color = 0xFFFFFFFF;

            cachedDots.add(new MinimapDot(dx, dz, color));
        }
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null || mc.world == null) return;

        int size = (int) mapSize.getValue();
        context.fill(x, y, x + size, y + size, 0xAA000000);
        // Рамка
        context.fill(x - 1, y - 1, x + size + 1, y,          EnkuronColor.PRIMARY);
        context.fill(x - 1, y + size, x + size + 1, y + size + 1, EnkuronColor.PRIMARY);
        context.fill(x - 1, y - 1, x, y + size + 1,           EnkuronColor.PRIMARY);
        context.fill(x + size, y - 1, x + size + 1, y + size + 1, EnkuronColor.PRIMARY);

        int centerX = x + size / 2;
        int centerY = y + size / 2;

        for (MinimapDot dot : cachedDots) {
            int ex = centerX + dot.dx();
            int ey = centerY + dot.dz();
            context.fill(ex - 1, ey - 1, ex + 1, ey + 1, dot.color());
        }

        // Игрок — всегда стрелка вверх (в центре)
        context.fill(centerX - 1, centerY - 2, centerX + 1, centerY + 2, 0xFFFFFFFF);
        context.fill(centerX,     centerY - 3, centerX + 1, centerY - 2, 0xFFFFFFFF);

        // Север (N) — только если вращение выключено
        if (!rotate.getState()) {
            context.drawText(mc.textRenderer, "§7N", x + size / 2 - 3, y + 2, 0xFFAAAAAA, false);
        }

        if (showCoords.getState()) {
            context.drawText(mc.textRenderer, cachedCoords, x + 3, y + size - 10, 0xFFBBBBBB, false);
        }
    }
}

