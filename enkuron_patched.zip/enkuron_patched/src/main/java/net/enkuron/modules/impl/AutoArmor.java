package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.screen.slot.SlotActionType;

public class AutoArmor extends Module {

    private final Setting interval = new Setting("Интервал (тики)", 10.0, 1.0, 40.0);
    private final Setting onlyBetter = new Setting("Только лучше", true);

    private int tickCounter = 0;

    public AutoArmor() {
        super("AutoArmor", "Автоматически надевает лучшую броню (1.21.4)", Category.PLAYER);
        addSetting(interval);
        addSetting(onlyBetter);
    }

    @Override 
    public void onEnable() { 
        tickCounter = 0; 
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        if (mc.player.playerScreenHandler == null) return; // FIX: NPE при инициализации
        if (++tickCounter < (int) interval.getValue()) return;
        tickCounter = 0;

        ClientPlayerEntity player = mc.player;

        // В 1.21.4 индексы брони в инвентаре: 0=ботинки, 1=штаны, 2=грудак, 3=шлем
        for (int i = 0; i < 4; i++) {
            ItemStack current = player.getInventory().getArmorStack(i);
            int bestSlot = findBestArmor(player, i, current);
            
            if (bestSlot != -1) {
                equipArmor(bestSlot, i);
            }
        }
    }

    private void equipArmor(int inventorySlot, int armorType) {
        int slotForClick = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;

        // Слоты PlayerScreenHandler: 5-Head, 6-Chest, 7-Legs, 8-Feet
        int targetSlot = switch (armorType) {
            case 3 -> 5;
            case 2 -> 6;
            case 1 -> 7;
            case 0 -> 8;
            default -> -1;
        };

        if (targetSlot != -1) {
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotForClick, 0, SlotActionType.QUICK_MOVE, mc.player);
        }
    }

    private int findBestArmor(ClientPlayerEntity player, int type, ItemStack current) {
        int bestSlot = -1;
        int bestValue = onlyBetter.getState() ? getArmorWeight(current) : -1;

        for (int i = 0; i < 36; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor)) continue;
            
            if (isCorrectType(armor, type)) {
                int value = getArmorWeight(stack);
                if (value > bestValue) {
                    bestValue = value;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    private boolean isCorrectType(ArmorItem armor, int type) {
        // В 1.21.4 самый надежный способ проверки типа — через название ключа предмета,
        // так как методы слотов постоянно меняют названия в маппингах.
        String key = armor.getTranslationKey().toLowerCase();
        return switch (type) {
            case 0 -> key.contains("boots");
            case 1 -> key.contains("leggings");
            case 2 -> key.contains("chestplate");
            case 3 -> key.contains("helmet");
            default -> false;
        };
    }

    private int getArmorWeight(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem)) return 0;

        // Базовый вес по материалу
        String name = stack.getItem().getTranslationKey().toLowerCase();
        int base;
        if      (name.contains("netherite")) base = 60;
        else if (name.contains("diamond"))   base = 50;
        else if (name.contains("iron"))      base = 40;
        else if (name.contains("gold"))      base = 30;
        else if (name.contains("chainmail")) base = 20;
        else if (name.contains("leather"))   base = 10;
        else return 0;

        // Бонус за зачарования (Protection, Blast Protection, Fire Protection, Projectile Protection)
        int enchBonus = 0;
        try {
            var reg = mc.world != null ? mc.world.getRegistryManager() : null;
            if (reg != null) {
                var enchReg = reg.getOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT);
                var prot   = enchReg.getOptional(net.minecraft.enchantment.Enchantments.PROTECTION);
                var blastP = enchReg.getOptional(net.minecraft.enchantment.Enchantments.BLAST_PROTECTION);
                var fireP  = enchReg.getOptional(net.minecraft.enchantment.Enchantments.FIRE_PROTECTION);
                if (prot.isPresent())   enchBonus += net.minecraft.enchantment.EnchantmentHelper.getLevel(prot.get(),   stack) * 4;
                if (blastP.isPresent()) enchBonus += net.minecraft.enchantment.EnchantmentHelper.getLevel(blastP.get(), stack) * 2;
                if (fireP.isPresent())  enchBonus += net.minecraft.enchantment.EnchantmentHelper.getLevel(fireP.get(),  stack) * 2;
            }
        } catch (Exception ignored) {}

        return base + enchBonus;
    }
}