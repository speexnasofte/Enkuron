package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.NotificationManager;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * AntiWeakness — автоматически пьёт молоко при эффекте Слабости.
 *
 * В PvP эффект Слабости резко снижает урон от меча (−4 ед.).
 * Модуль отслеживает эффект и мгновенно его снимает молоком.
 *
 * Настройки:
 *   Только в бою   — срабатывает только при наличии цели рядом
 *   Радиус врага   — радиус проверки (8–32 блока)
 *   Уведомление    — показывать тост при обнаружении Слабости
 *   Кулдаун (сек)  — пауза после выпивания молока (1–15)
 */
public class AntiWeakness extends Module {

    private final Setting onlyInCombat = new Setting("Только в бою",   true);
    private final Setting enemyRange   = new Setting("Радиус врага",   16.0, 8.0, 32.0);
    private final Setting notify       = new Setting("Уведомление",    true);
    private final Setting cooldownSec  = new Setting("Кулдаун (сек)",   3.0, 1.0, 15.0);

    private int     cooldown     = 0;
    private int     prevSlot     = -1;
    private boolean drinking     = false;
    private boolean notified     = false;

    public AntiWeakness() {
        super("AntiWeakness", "Пьёт молоко при эффекте Слабости, сохраняя PvP-урон", Category.COMBAT);
        addSetting(onlyInCombat);
        addSetting(enemyRange);
        addSetting(notify);
        addSetting(cooldownSec);
    }

    @Override
    public void onDisable() {
        stopDrinking();
        notified = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }

        boolean hasWeakness = mc.player.getStatusEffect(StatusEffects.WEAKNESS) != null;

        // Уведомляем один раз при появлении эффекта
        if (hasWeakness && !notified && notify.getState()) {
            NotificationManager.push(
                "AntiWeakness",
                "Обнаружена Слабость!",
                NotificationManager.Type.WARNING,
                2500
            );
            notified = true;
        }
        if (!hasWeakness) notified = false;

        // Если нет слабости — остановить питьё
        if (!hasWeakness) {
            if (drinking) stopDrinking();
            return;
        }

        // Проверка: только в бою
        if (onlyInCombat.getState() && !hasNearbyPlayer()) return;

        // Начать пить молоко
        if (!drinking) {
            int milkSlot = findMilk();
            if (milkSlot == -1) return;
            prevSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = milkSlot;
            drinking = true;
        }

        if (drinking) {
            mc.options.useKey.setPressed(true);

            // Проверяем: молоко ещё есть?
            if (findMilk() == -1) {
                stopDrinking();
            }
        }

        // Слабость снята — прекратить
        if (!hasWeakness && drinking) {
            stopDrinking();
            cooldown = (int)(cooldownSec.getValue() * 20);
        }
    }

    private void stopDrinking() {
        if (mc.player == null) return;
        mc.options.useKey.setPressed(false);
        drinking = false;
        if (prevSlot != -1) {
            mc.player.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    private int findMilk() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && s.getItem() == Items.MILK_BUCKET) return i;
        }
        return -1;
    }

    private boolean hasNearbyPlayer() {
        double r = enemyRange.getValue();
        return !mc.world.getEntitiesByClass(
            net.minecraft.entity.player.PlayerEntity.class,
            mc.player.getBoundingBox().expand(r),
            e -> e != mc.player
        ).isEmpty();
    }
}
