package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.BowItem;
import net.minecraft.item.ShieldItem;

/**
 * CustomCrosshair — кастомный прицел.
 *
 * Стили: Крест, Точка, Круг, T-форма, Угловой
 * Настройки: размер, толщина, цвет, радужный режим
 * Авто-скрытие: при блоке щитом, при натяжении лука
 */
public class CustomCrosshair extends Module {

    private static final String[] STYLES = {"Крест", "Точка", "Круг", "T-форма", "Угловой"};

    private final Setting style       = new Setting("Стиль",         STYLES,  0);
    private final Setting size        = new Setting("Размер",        5.0, 1.0, 20.0);
    private final Setting thickness   = new Setting("Толщина",       1.0, 1.0, 4.0);
    private final Setting gap         = new Setting("Зазор",         2.0, 0.0, 10.0);
    private final Setting red         = new Setting("Красный",       255.0, 0.0, 255.0);
    private final Setting green       = new Setting("Зелёный",       255.0, 0.0, 255.0);
    private final Setting blue        = new Setting("Синий",         255.0, 0.0, 255.0);
    private final Setting rainbow     = new Setting("Радуга",        false);
    private final Setting hideOnBlock = new Setting("Скрыть щит",   true);
    private final Setting hideOnBow   = new Setting("Скрыть лук",   true);
    private final Setting dot         = new Setting("Центр. точка",  false);

    private float rainbowHue = 0f;

    public CustomCrosshair() {
        super("CustomCrosshair", "Кастомный прицел: стиль, цвет, авто-скрытие", Category.VISUAL);
        addSetting(style);
        addSetting(size);
        addSetting(thickness);
        addSetting(gap);
        addSetting(red);
        addSetting(green);
        addSetting(blue);
        addSetting(rainbow);
        addSetting(hideOnBlock);
        addSetting(hideOnBow);
        addSetting(dot);
    }

    @Override
    public void onTick() {
        rainbowHue = (rainbowHue + 0.012f) % 1f;
    }

    @Override
    public void render(DrawContext ctx) {
        if (!isEnabled() || mc.player == null || mc.options.hudHidden) return;

        // Авто-скрытие
        if (hideOnBlock.getState() && mc.player.isBlocking()) return;
        if (hideOnBow.getState()) {
            var active = mc.player.getActiveItem();
            if (!active.isEmpty() && active.getItem() instanceof BowItem) return;
        }

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int cx = sw / 2;
        int cy = sh / 2;

        int color = getColor();
        int s  = (int) size.getValue();
        int t  = (int) thickness.getValue();
        int g  = (int) gap.getValue();

        switch (style.getCurrentOption()) {
            case "Крест"    -> drawCross(ctx, cx, cy, s, t, g, color);
            case "Точка"    -> drawDotOnly(ctx, cx, cy, t + 1, color);
            case "Круг"     -> drawCircle(ctx, cx, cy, s, color);
            case "T-форма"  -> drawTShape(ctx, cx, cy, s, t, g, color);
            case "Угловой"  -> drawCorners(ctx, cx, cy, s, t, g, color);
        }

        // Центральная точка поверх любого стиля
        if (dot.getState() && !style.getCurrentOption().equals("Точка")) {
            drawDotOnly(ctx, cx, cy, 1, color);
        }
    }

    // ── Крест (классика) ─────────────────────────────────────────────────────
    private void drawCross(DrawContext ctx, int cx, int cy, int s, int t, int g, int color) {
        // горизонталь
        ctx.fill(cx - s - g, cy - t/2, cx - g,     cy + t/2 + 1, color);
        ctx.fill(cx + g,     cy - t/2, cx + s + g, cy + t/2 + 1, color);
        // вертикаль
        ctx.fill(cx - t/2, cy - s - g, cx + t/2 + 1, cy - g,     color);
        ctx.fill(cx - t/2, cy + g,     cx + t/2 + 1, cy + s + g, color);
    }

    // ── Точка ────────────────────────────────────────────────────────────────
    private void drawDotOnly(DrawContext ctx, int cx, int cy, int r, int color) {
        ctx.fill(cx - r, cy - r, cx + r + 1, cy + r + 1, color);
    }

    // ── Круг (аппроксимация через квадраты) ──────────────────────────────────
    private void drawCircle(DrawContext ctx, int cx, int cy, int r, int color) {
        for (int angle = 0; angle < 360; angle += 6) {
            double rad = Math.toRadians(angle);
            int px = cx + (int)(Math.cos(rad) * r);
            int py = cy + (int)(Math.sin(rad) * r);
            ctx.fill(px - 1, py - 1, px + 1, py + 1, color);
        }
    }

    // ── T-форма ───────────────────────────────────────────────────────────────
    private void drawTShape(DrawContext ctx, int cx, int cy, int s, int t, int g, int color) {
        // горизонталь полная
        ctx.fill(cx - s - g, cy - t/2, cx + s + g, cy + t/2 + 1, color);
        // только нижняя вертикаль
        ctx.fill(cx - t/2, cy + g, cx + t/2 + 1, cy + s + g, color);
    }

    // ── Угловой (4 уголка) ────────────────────────────────────────────────────
    private void drawCorners(DrawContext ctx, int cx, int cy, int s, int t, int g, int color) {
        int inner = g;
        int outer = g + s;
        // top-left
        ctx.fill(cx - outer, cy - inner - t, cx - inner, cy - inner, color);
        ctx.fill(cx - inner - t, cy - outer, cx - inner, cy - inner, color);
        // top-right
        ctx.fill(cx + inner, cy - inner - t, cx + outer, cy - inner, color);
        ctx.fill(cx + inner, cy - outer, cx + inner + t, cy - inner, color);
        // bottom-left
        ctx.fill(cx - outer, cy + inner, cx - inner, cy + inner + t, color);
        ctx.fill(cx - inner - t, cy + inner, cx - inner, cy + outer, color);
        // bottom-right
        ctx.fill(cx + inner, cy + inner, cx + outer, cy + inner + t, color);
        ctx.fill(cx + inner, cy + inner, cx + inner + t, cy + outer, color);
    }

    private int getColor() {
        if (rainbow.getState()) {
            java.awt.Color c = java.awt.Color.getHSBColor(rainbowHue, 0.9f, 1f);
            return 0xFF000000 | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
        }
        return 0xFF000000 | ((int)red.getValue() << 16) | ((int)green.getValue() << 8) | (int)blue.getValue();
    }
}
