package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.utils.EnkuronColor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/**
 * InventoryHUD — отображает инвентарь игрока прямо на экране (без открытия GUI).
 *
 * Показывает 27 слотов основного инвентаря (3×9) + 4 слота брони + оффхенд.
 * Предметы кликать нельзя — только визуальный обзор содержимого без открытия E.
 *
 * Настройки:
 *   Показать броню  — 4 слота брони слева
 *   Показать оффхенд — слот оффхенда
 *   Компактный       — меньший размер слотов (14px вместо 18px)
 *   Фон              — Тёмный / Стекло / Нет
 *   Подсветка пустых — обводка пустых слотов
 *   Автоскрытие      — скрывать при открытом GUI
 */
public class InventoryHUD extends Module {

    private static final String[] BG_STYLES = {"Тёмный", "Стекло", "Нет"};

    private final Setting showArmor    = new Setting("Броня",            true);
    private final Setting showOffhand  = new Setting("Оффхенд",          true);
    private final Setting compact      = new Setting("Компактный",        false);
    private final Setting bgStyle      = new Setting("Фон",              BG_STYLES, 0);
    private final Setting hlEmpty      = new Setting("Пустые слоты",     true);
    private final Setting autoHide     = new Setting("Авто-скрытие",     true);

    public InventoryHUD() {
        super("InventoryHUD", "Инвентарь игрока прямо на экране (только просмотр)", Category.HUD);
        addSetting(showArmor);
        addSetting(showOffhand);
        addSetting(compact);
        addSetting(bgStyle);
        addSetting(hlEmpty);
        addSetting(autoHide);
        this.x = 5;
        this.y = 50;
    }

    private int slotSize() { return compact.getState() ? 14 : 18; }
    private int gap()      { return compact.getState() ? 1  :  2; }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;

        // Автоскрытие при открытом GUI (инвентарь, сундуки и т.д.)
        if (autoHide.getState() && mc.currentScreen != null) return;

        int sz  = slotSize();
        int g   = gap();
        int row = 9;  // слотов в строке
        int col = 3;  // строк инвентаря

        // Рассчитываем размеры
        int invW = row * (sz + g) - g;
        int invH = col * (sz + g) - g;

        // Дополнительная колонка: броня + оффхенд
        int extraW  = (showArmor.getState() || showOffhand.getState()) ? (sz + g * 2 + 4) : 0;
        int totalW  = invW + extraW + 8;
        int totalH  = invH + 10;

        this.width  = totalW;
        this.height = totalH;

        // Фон
        drawBackground(context, totalW, totalH);

        // Заголовок
        context.drawText(mc.textRenderer, "§7Инвентарь",
            x + 3, y + 2, 0xFFAAAAAA, false);

        int startY  = y + mc.textRenderer.fontHeight + 4;
        int startX  = x + (extraW > 0 ? extraW : 3);

        // ── Основной инвентарь (слоты 9–35: строки 0-2) ──────────────────────
        for (int rowIdx = 0; rowIdx < col; rowIdx++) {
            for (int colIdx = 0; colIdx < row; colIdx++) {
                int slotIndex = 9 + rowIdx * row + colIdx;  // слоты 9–35
                int sx = startX + colIdx * (sz + g);
                int sy = startY + rowIdx * (sz + g);
                drawSlot(context, sx, sy, sz, mc.player.getInventory().getStack(slotIndex));
            }
        }

        // ── Броня (слоты 36–39: голова, грудь, ноги, ботинки) ────────────────
        if (showArmor.getState()) {
            String[] armorLabels = {"H", "C", "L", "B"};
            for (int i = 0; i < 4; i++) {
                // getArmorStack: 0=feet, 1=legs, 2=chest, 3=head → рисуем сверху вниз (3→0)
                ItemStack armorStack = mc.player.getInventory().getArmorStack(3 - i);
                int ax = x + 3;
                int ay = startY + i * (sz + g);
                drawSlot(context, ax, ay, sz, armorStack);
                // Маленький лейбл
                if (sz >= 16) {
                    context.drawText(mc.textRenderer, armorLabels[i],
                        ax, ay, 0xFF888888, false);
                }
            }
        }

        // ── Оффхенд ──────────────────────────────────────────────────────────
        if (showOffhand.getState()) {
            ItemStack offhand = mc.player.getOffHandStack();
            int ox = x + 3;
            int oy = startY + 4 * (sz + g) + g;
            drawSlot(context, ox, oy, sz, offhand);
        }

        // ── Счётчик предметов ────────────────────────────────────────────────
        int itemCount = 0;
        for (int i = 9; i < 36; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) itemCount++;
        }
        String countStr = itemCount + "/27";
        context.drawText(mc.textRenderer, countStr,
            x + totalW - mc.textRenderer.getWidth(countStr) - 4,
            y + 2, 0xFF666666, false);
    }

    // ── Вспомогательные ──────────────────────────────────────────────────────

    private void drawSlot(DrawContext context, int sx, int sy, int sz, ItemStack stack) {
        // Фон слота
        if (!"Нет".equals(bgStyle.getCurrentOption())) {
            context.fill(sx - 1, sy - 1, sx + sz + 1, sy + sz + 1,
                "Стекло".equals(bgStyle.getCurrentOption()) ? 0x44FFFFFF : 0xFF1E1E22);
        }

        if (stack.isEmpty()) {
            // Подсветка пустого слота
            if (hlEmpty.getState()) {
                context.fill(sx, sy, sx + sz, sy + sz, 0x22FFFFFF);
                // Тонкая обводка
                context.fill(sx, sy, sx + sz, sy + 1, 0x33FFFFFF);
                context.fill(sx, sy + sz - 1, sx + sz, sy + sz, 0x33FFFFFF);
                context.fill(sx, sy, sx + 1, sy + sz, 0x33FFFFFF);
                context.fill(sx + sz - 1, sy, sx + sz, sy + sz, 0x33FFFFFF);
            }
        } else {
            // Рисуем предмет (центрируем 16x16 иконку внутри слота)
            int off = Math.max(0, (sz - 16) / 2);
            context.drawItem(stack, sx + off, sy + off);
            context.drawStackOverlay(mc.textRenderer, stack, sx + off, sy + off);
        }
    }

    private void drawBackground(DrawContext context, int totalW, int totalH) {
        switch (bgStyle.getCurrentOption()) {
            case "Тёмный" -> {
                context.fill(x - 3, y - 3, x + totalW, y + totalH, 0xCC0D0D10);
                context.fill(x - 3, y - 3, x + totalW, y - 2, 0xFF8844FF);
                context.fill(x - 3, y - 3, x - 2, y + totalH, 0xFF8844FF);
            }
            case "Стекло" -> {
                context.fill(x - 3, y - 3, x + totalW, y + totalH, 0x66AABBCC);
                context.fill(x - 3, y - 3, x + totalW, y - 2, 0xAADDEEFF);
            }
            // "Нет" — без фона
        }
    }
}
