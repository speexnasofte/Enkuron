package net.enkuron.modules.impl;

import net.enkuron.mixin.accessor.ClientPlayerEntityAccessor;
import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

import java.util.ArrayList;
import java.util.List;

/**
 * BetterChat v3 — улучшения чата.
 *
 * НОВЫЕ ФИЧИ v4:
 *  - История команд ↑↓ — навигация по отправленным сообщениям
 */
public class BetterChat extends Module {

    // ── Оригинальные ────────────────────────────────────────────────────────
    private final Setting transparentBg = new Setting("Прозрачный фон", true);
    private final Setting noDelay       = new Setting("Без задержки",   true);

    // ── Новые ───────────────────────────────────────────────────────────────
    private final Setting filterSpam    = new Setting("Фильтр дублей",      true);
    private final Setting longMessages  = new Setting("Длинные сообщения",  true);
    private final Setting prefixEnabled = new Setting("Префикс",           false);
    private final Setting historyEnabled = new Setting("История ↑↓",       true);

    private String lastSentMessage = null;

    // ── История команд ───────────────────────────────────────────────────────
    private final List<String> history   = new ArrayList<>();
    private int historyIndex = -1; // -1 = не в режиме истории
    private String currentDraft = null; // черновик текущего ввода

    private static final int MAX_HISTORY = 50;

    public BetterChat() {
        super("BetterChat", "Улучшает чат: без задержки, фильтр дублей, история ↑↓", Category.MISC);
        addSetting(transparentBg);
        addSetting(noDelay);
        addSetting(filterSpam);
        addSetting(longMessages);
        addSetting(prefixEnabled);
        addSetting(historyEnabled);
    }

    // ── Публичный API для миксинов ───────────────────────────────────────────

    /** MixinChatHud: отрисовка без фона. */
    public boolean isTransparentBg() { return transparentBg.getState(); }

    /**
     * Вызывается из MixinChatScreen перед отправкой сообщения.
     * @return null — заблокировать (дубль), иначе — строка для отправки.
     */
    public String processOutgoing(String message) {
        // Фильтр дублей
        if (filterSpam.getState() && message.equals(lastSentMessage)) return null;
        lastSentMessage = message;

        // Сохраняем в историю
        if (historyEnabled.getState() && !message.isBlank()) {
            history.remove(message); // убираем дубль если был
            history.add(0, message);
            if (history.size() > MAX_HISTORY) history.remove(history.size() - 1);
        }
        historyIndex = -1;
        currentDraft = null;

        // Префикс (только для обычных сообщений, не команд)
        if (prefixEnabled.getState() && !message.startsWith("/")) {
            message = ">> " + message;
        }
        return message;
    }

    /**
     * ↑ — более старое сообщение.
     * @param currentText текст в поле на момент нажатия (сохраняем как черновик)
     * @return строка из истории или null если история пуста
     */
    public String historyUp(String currentText) {
        if (!historyEnabled.getState() || history.isEmpty()) return null;
        if (historyIndex == -1) currentDraft = currentText;
        historyIndex = Math.min(historyIndex + 1, history.size() - 1);
        return history.get(historyIndex);
    }

    /**
     * ↓ — более новое сообщение / возврат к черновику.
     * @return строка из истории, черновик или null (вернуться к пустому полю)
     */
    public String historyDown() {
        if (!historyEnabled.getState()) return null;
        if (historyIndex <= 0) {
            historyIndex = -1;
            return currentDraft;
        }
        historyIndex--;
        return history.get(historyIndex);
    }

    /**
     * Разбивает длинные сообщения на части по 255 символов.
     */
    public String[] splitLong(String message) {
        if (!longMessages.getState() || message.length() <= 255) return new String[]{message};
        int parts = (int) Math.ceil(message.length() / 255.0);
        String[] result = new String[parts];
        for (int i = 0; i < parts; i++) {
            int from = i * 255;
            int to   = Math.min(from + 255, message.length());
            result[i] = message.substring(from, to);
        }
        return result;
    }

    @Override
    public void onTick() {
        if (!noDelay.getState() || mc.player == null) return;
    }
}
