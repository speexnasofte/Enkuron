package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;

/**
 * BurstClick — стабилизирует CPS в заданном диапазоне.
 *
 * Не кликает за игрока — лишь добавляет дополнительные клики
 * сразу после настоящего клика мыши, имитируя burst-паттерн.
 *
 * Настройки:
 *   Мин. CPS    — нижняя граница случайного диапазона (4–20)
 *   Макс. CPS   — верхняя граница (5–20)
 *   Только цель — активен только при наличии цели (TargetManager)
 *   Burst       — количество доп. кликов за одно нажатие (1–4)
 */
public class BurstClick extends Module {

    private static final String[] MODES = {"Burst", "Stabilize"};

    private final Setting mode      = new Setting("Режим",       MODES, 0);
    private final Setting minCps    = new Setting("Мин. CPS",    8.0,  4.0, 20.0);
    private final Setting maxCps    = new Setting("Макс. CPS",   12.0, 5.0, 20.0);
    private final Setting burstAmt  = new Setting("Burst кол-во", 2.0,  1.0,  4.0);
    private final Setting onlyTarget= new Setting("Только цель", true);

    private int    clickTimer   = 0;
    private int    targetDelay  = 0;
    private boolean wasAttacking = false;

    public BurstClick() {
        super("BurstClick", "Стабилизирует CPS с burst-паттерном для PvP", Category.COMBAT);
        addSetting(mode);
        addSetting(minCps);
        addSetting(maxCps);
        addSetting(burstAmt);
        addSetting(onlyTarget);
    }

    @Override
    public void onEnable() {
        clickTimer  = 0;
        wasAttacking = false;
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.options.attackKey.setPressed(false);
        }
        clickTimer = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;

        // Проверка цели
        if (onlyTarget.getState()) {
            net.enkuron.combat.TargetManager tm =
                net.enkuron.combat.TargetManager.getInstance();
            if (tm == null || tm.getTarget() == null) {
                mc.options.attackKey.setPressed(false);
                return;
            }
        }

        if (clickTimer > 0) {
            clickTimer--;
            return;
        }

        boolean attacking = mc.options.attackKey.isPressed();

        if ("Burst".equals(mode.getCurrentOption())) {
            // Burst: при нажатии ЛКМ — добавляем дополнительные клики
            if (attacking && !wasAttacking) {
                int bursts = (int) burstAmt.getValue();
                for (int i = 0; i < bursts; i++) {
                    mc.options.attackKey.setPressed(true);
                    mc.options.attackKey.setPressed(false);
                }
                clickTimer = calcDelay();
            }
        } else {
            // Stabilize: автоматически кликаем с заданным CPS
            if (mc.targetedEntity != null) {
                mc.options.attackKey.setPressed(true);
                mc.options.attackKey.setPressed(false);
                clickTimer = calcDelay();
            }
        }

        wasAttacking = attacking;
    }

    /** Случайная задержка между кликами в тиках, исходя из min/max CPS. */
    private int calcDelay() {
        double min = minCps.getValue();
        double max = maxCps.getValue();
        if (min > max) min = max;
        double cps = min + Math.random() * (max - min);
        return Math.max(1, (int)(20.0 / cps));
    }
}
