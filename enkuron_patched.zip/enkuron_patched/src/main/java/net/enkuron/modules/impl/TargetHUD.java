package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.enkuron.ui.theme.Theme;
import net.enkuron.ui.theme.ThemeManager;
import net.enkuron.utils.AnimationUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.Identifier;

import java.util.Collection;

/**
 * TargetHUD v4 — фиксы + визуал апгрейд.
 *
 * FIX v4:
 *  - null-check ThemeManager.get() во всех стилях
 *  - HP-ratio clamped [0..1] везде через Math.min
 *  - buildExtra() теперь учитывает showDist И showType
 *  - getPingRaw() не кидает NPE при отключённом NetworkHandler
 *  - Compact: эффекты рисуются слева направо (был баг с обратным порядком)
 *  - Cyber: засечки HP-полоски больше не выходят за края при ratio=1
 *
 * VISUAL v4:
 *  - Classic: верхняя линия теперь accent-цвет из Theme
 *  - Modern: градиентная HP-полоска (зелёный→красный по ratio)
 *  - Card: добавлена акцентная левая полоска из Theme
 *  - Cyber: пульсирующие угловые акценты (sin-анимация)
 *  - Все стили: плавный fade-in через slideAnim при смене цели
 */
public class TargetHUD extends Module {

    private static final String[] STYLES = {
        "Classic", "Modern", "Minimal", "Nametag", "Boss", "Card", "Compact", "Cyber"
    };

    private final Setting style       = new Setting("Стиль",          STYLES, 0);
    private final Setting showDist    = new Setting("Дистанция",      true);
    private final Setting showType    = new Setting("Тип цели",       true);
    private final Setting showArmor   = new Setting("Броня цели",     true);
    private final Setting showEffects = new Setting("Зелья/эффекты",  true);
    private final Setting showPing    = new Setting("Пинг (игроки)",  true);
    private final Setting showWeapon  = new Setting("Оружие в руке",  true);

    // fade-in анимация при появлении цели
    private float fadeAnim  = 0f;
    private float cyberPhase = 0f;
    private LivingEntity lastTarget = null;

    public TargetHUD() {
        super("TargetHUD", "Красивый HUD с расширенной инфо о цели под прицелом", Category.HUD);
        this.x = 10; this.y = 140;
        addSetting(style);  addSetting(showDist);   addSetting(showType);
        addSetting(showArmor); addSetting(showEffects); addSetting(showPing);
        addSetting(showWeapon);
    }

    @Override
    public void onTick() {
        cyberPhase += 0.07f;
        if (cyberPhase > (float)(Math.PI * 2)) cyberPhase -= (float)(Math.PI * 2);

        LivingEntity current = getTarget();
        if (current != lastTarget) {
            // смена цели — сбрасываем fade
            fadeAnim  = 0f;
            lastTarget = current;
        }
        fadeAnim = AnimationUtils.lerp(fadeAnim, current != null ? 1f : 0f, 0.15f);
    }

    @Override
    public void render(DrawContext context) {
        if (!isEnabled() || mc.player == null) return;
        LivingEntity target = getTarget();
        if (target == null && fadeAnim < 0.01f) return;
        if (target == null) target = lastTarget;
        if (target == null) return;

        switch (style.getCurrentOption()) {
            case "Modern"  -> renderModern (context, target);
            case "Minimal" -> renderMinimal(context, target);
            case "Nametag" -> renderNametag(context, target);
            case "Boss"    -> renderBoss   (context, target);
            case "Card"    -> renderCard   (context, target);
            case "Compact" -> renderCompact(context, target);
            case "Cyber"   -> renderCyber  (context, target);
            default        -> renderClassic(context, target);
        }
    }

    // ── CLASSIC v4 ──────────────────────────────────────────────────────────
    private void renderClassic(DrawContext ctx, LivingEntity t) {
        // FIX: null-check Theme
        Theme theme = ThemeManager.get();
        int accentColor = theme != null ? (0xFF000000 | (theme.accent & 0xFFFFFF)) : 0xFFCC4444;

        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f); // FIX: clamp
        String name   = getName(t);
        String hpText = fmt(hp, maxHp);
        String extra  = buildExtra(t);

        boolean isPlayer = (t instanceof PlayerEntity);
        int headSize = isPlayer ? 16 : 0;
        int headPad  = isPlayer ? headSize + 4 : 0;

        int txtW = Math.max(mc.textRenderer.getWidth(name),
                   Math.max(mc.textRenderer.getWidth(hpText), mc.textRenderer.getWidth(extra)));
        int boxW = txtW + 14 + headPad;
        int boxH = extra.isEmpty() ? 28 : 38;
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        int hpColor = hpColor(ratio);
        ctx.fill(x-2, y-2, x+boxW, y+boxH, withAlpha(0x111116, (int)(fadeAnim * 0xBB)));
        // VISUAL: accent-линия из темы
        ctx.fill(x-2, y-2, x+boxW, y-1, withAlpha(accentColor, alpha));

        // Голова игрока слева
        if (isPlayer) {
            drawPlayerHead(ctx, (PlayerEntity) t, x + 2, y + (boxH - headSize) / 2, headSize);
        }

        int tx = x + 2 + headPad;
        ctx.drawText(mc.textRenderer, name,   tx, y+2,  withAlpha(0xFFFFFF, alpha), true);
        ctx.drawText(mc.textRenderer, hpText, tx, y+13, withAlpha(hpColor, alpha),  true);
        if (!extra.isEmpty())
            ctx.drawText(mc.textRenderer, extra, tx, y+24, withAlpha(0xAAAAAA, alpha), false);
        int barW = boxW - 6;
        ctx.fill(x+1, y+boxH-5, x+1+barW,              y+boxH-2, withAlpha(0x222222, alpha));
        ctx.fill(x+1, y+boxH-5, x+1+(int)(barW*ratio), y+boxH-2, withAlpha(hpColor, alpha));
    }

    // ── MODERN v4 ───────────────────────────────────────────────────────────
    private void renderModern(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        String name   = getName(t);
        String hpText = fmt(hp, maxHp);
        String extra  = buildExtra(t);

        boolean isPlayer = (t instanceof PlayerEntity);
        int headSize = isPlayer ? 18 : 0;

        int txtW = Math.max(mc.textRenderer.getWidth(name),
                   Math.max(mc.textRenderer.getWidth(hpText), mc.textRenderer.getWidth(extra)));
        int boxW = Math.max(txtW + 20 + (isPlayer ? headSize + 4 : 0), 110);
        int boxH = extra.isEmpty() ? 32 : 42;
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        ctx.fill(x-1, y-1, x+boxW+1, y+boxH+1, withAlpha(0x000000, (int)(fadeAnim * 0x88)));
        ctx.fill(x,   y,   x+boxW,   y+boxH,   withAlpha(0x0D0D18, (int)(fadeAnim * 0xDD)));

        // VISUAL: градиентная HP-полоска — зелёный→жёлтый→красный
        int hpColor = hpColor(ratio);
        ctx.fill(x, y, x+3, y+boxH, withAlpha(hpColor, alpha));

        // Голова игрока
        if (isPlayer) {
            drawPlayerHead(ctx, (PlayerEntity) t, x + 7, y + (boxH - headSize) / 2, headSize);
        }

        int tx = x + 7 + (isPlayer ? headSize + 4 : 0);
        ctx.drawText(mc.textRenderer, name,   tx, y+4,  withAlpha(0xFFFFFF, alpha), true);
        ctx.drawText(mc.textRenderer, hpText, tx, y+15, withAlpha(hpColor,  alpha), true);
        if (!extra.isEmpty())
            ctx.drawText(mc.textRenderer, extra, tx, y+26, withAlpha(0x888888, alpha), false);

        // Полоска здоровья
        int barY = y + boxH - 5, barW = boxW - 4;
        ctx.fill(x+2, barY, x+2+barW,              barY+3, withAlpha(0x333333, alpha));
        // VISUAL: градиент полоски (два цвета)
        int midX = x + 2 + (int)(barW * ratio);
        ctx.fill(x+2, barY, midX, barY+3, withAlpha(hpColor, alpha));

        if (showArmor.getState() && t instanceof PlayerEntity player)
            renderArmorRow(ctx, player, x + boxW - 4*10, y + 4);
    }

    // ── MINIMAL ──────────────────────────────────────────────────────────────
    private void renderMinimal(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        String name = getName(t);
        int boxW = Math.max(mc.textRenderer.getWidth(name) + 50, 90);
        this.width = boxW; this.height = 14;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        ctx.fill(x-1, y-1, x+boxW+1, y+15, withAlpha(0x000000, (int)(fadeAnim * 0x99)));
        ctx.drawText(mc.textRenderer, name, x+2, y+2, withAlpha(0xFFFFFF, alpha), false);
        String hpStr = String.format("%.0f%%", ratio * 100);
        ctx.drawText(mc.textRenderer, hpStr, x+boxW-mc.textRenderer.getWidth(hpStr)-2, y+2, withAlpha(hpColor(ratio), alpha), false);
        ctx.fill(x, y+12, x+boxW,              y+14, withAlpha(0x333333, alpha));
        ctx.fill(x, y+12, x+(int)(boxW*ratio), y+14, withAlpha(hpColor(ratio), alpha));
    }

    // ── NAMETAG ──────────────────────────────────────────────────────────────
    private void renderNametag(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        String name = getName(t), hpText = fmt(hp, maxHp);
        int nameW = mc.textRenderer.getWidth(name), hpW = mc.textRenderer.getWidth(hpText);
        int boxW = Math.max(nameW, hpW) + 8;
        this.width = boxW; this.height = 22;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        int hpColor = hpColor(ratio);
        ctx.fill(x,   y+1,  x+boxW,   y+21, withAlpha(0x111111, (int)(fadeAnim * 0xCC)));
        ctx.fill(x,   y,    x+boxW,   y+1,  withAlpha(hpColor, alpha));
        ctx.fill(x,   y+20, x+boxW,   y+21, withAlpha(hpColor, alpha));
        int cx = x + (boxW - nameW) / 2;
        ctx.drawText(mc.textRenderer, name,   cx, y+3,  withAlpha(0xFFFFFF, alpha), true);
        cx = x + (boxW - hpW) / 2;
        ctx.drawText(mc.textRenderer, hpText, cx, y+12, withAlpha(hpColor, alpha),  false);
    }

    // ── BOSS ─────────────────────────────────────────────────────────────────
    private void renderBoss(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        String name = getName(t).toUpperCase();
        int sw = mc.getWindow().getScaledWidth();
        int boxW = sw / 2, boxH = 20;
        int bx = sw / 4;
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        int hpColor = hpColor(ratio);
        ctx.fill(bx, y, bx+boxW, y+boxH, withAlpha(0x111118, (int)(fadeAnim * 0xDD)));
        int nameW = mc.textRenderer.getWidth(name);
        ctx.drawText(mc.textRenderer, name, bx + (boxW - nameW) / 2, y + 3, withAlpha(0xFFFFFF, alpha), true);
        int barW = boxW - 4;
        ctx.fill(bx+2, y+boxH-5, bx+2+barW,              y+boxH-2, withAlpha(0x222222, alpha));
        ctx.fill(bx+2, y+boxH-5, bx+2+(int)(barW*ratio), y+boxH-2, withAlpha(hpColor, alpha));
    }

    // ── CARD v4 ──────────────────────────────────────────────────────────────
    private void renderCard(DrawContext ctx, LivingEntity t) {
        // FIX: null-check Theme
        Theme theme = ThemeManager.get();
        int accent = theme != null ? (theme.accent & 0xFFFFFF) : 0x8844FF;

        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int hpColor = hpColor(ratio);

        String name     = getName(t);
        String hpText   = fmt(hp, maxHp);
        String distStr  = showDist.getState() ? String.format("%.1fm", mc.player.distanceTo(t)) : "";
        String pingStr  = (showPing.getState() && t instanceof PlayerEntity p) ? getPingStr(p) : "";
        ItemStack weapon = showWeapon.getState() ? t.getMainHandStack() : ItemStack.EMPTY;
        Collection<StatusEffectInstance> effects = showEffects.getState()
            ? t.getStatusEffects() : java.util.Collections.emptyList();

        int boxW = 140;
        int boxH = 48 + (effects.isEmpty() ? 0 : 12) + (weapon.isEmpty() ? 0 : 0);
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        // Фон с внешней тенью
        ctx.fill(x-1, y-1, x+boxW+1, y+boxH+1, withAlpha(0x000000, (int)(fadeAnim * 0x66)));
        ctx.fill(x,   y,   x+boxW,   y+boxH,   withAlpha(0x0D0D1A, (int)(fadeAnim * 0xEE)));

        // VISUAL: акцентная левая полоска из темы
        ctx.fill(x, y, x+3, y+boxH, withAlpha(accent, alpha));

        int ty = y + 4;
        ctx.drawText(mc.textRenderer, name,   x+7, ty,    withAlpha(0xFFFFFF, alpha), true);
        ty += 11;
        ctx.drawText(mc.textRenderer, hpText, x+7, ty,    withAlpha(hpColor, alpha), false);
        ty += 9;

        // HP полоска
        int barW = boxW - 10;
        ctx.fill(x+5, ty, x+5+barW,              ty+3, withAlpha(0x333333, alpha));
        ctx.fill(x+5, ty, x+5+(int)(barW*ratio), ty+3, withAlpha(hpColor, alpha));
        ty += 7;

        // Оружие
        if (!weapon.isEmpty()) {
            ctx.drawItem(weapon, x+5, ty);
            String wn = weapon.getName().getString();
            if (wn.length() > 14) wn = wn.substring(0, 13) + "…";
            ctx.drawText(mc.textRenderer, "§7" + wn, x+22, ty+3, withAlpha(0x888899, alpha), false);
            ty += 14;
        }

        // Ping + дистанция
        if (!pingStr.isEmpty())
            ctx.drawText(mc.textRenderer, pingStr, x+7, ty, withAlpha(pingColor(t), alpha), false);
        if (!distStr.isEmpty()) {
            int dw = mc.textRenderer.getWidth(distStr);
            ctx.drawText(mc.textRenderer, distStr, x+boxW-dw-5, ty, withAlpha(0x555566, alpha), false);
        }
        ty += 10;

        // Эффекты
        if (!effects.isEmpty()) {
            int ex = x + 7;
            for (StatusEffectInstance eff : effects) {
                if (ex > x + boxW - 10) break;
                ctx.fill(ex, ty+2, ex+5, ty+7, withAlpha(eff.getEffectType().value().getColor(), alpha));
                ex += 7;
            }
        }
    }

    // ── COMPACT v4 ───────────────────────────────────────────────────────────
    private void renderCompact(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int hpColor = hpColor(ratio);

        String name    = getName(t);
        String hpPct   = String.format("%.0f%%", ratio * 100);
        String distStr = showDist.getState() ? String.format("%.0fm", mc.player.distanceTo(t)) : "";
        String pingStr = (showPing.getState() && t instanceof PlayerEntity p) ? getPingStr(p) : "";
        ItemStack weapon = showWeapon.getState() ? t.getMainHandStack() : ItemStack.EMPTY;

        int boxW = 120, boxH = 34;
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        ctx.fill(x, y, x+boxW, y+boxH, withAlpha(0x0B0B17, (int)(fadeAnim * 0xCC)));
        ctx.fill(x, y+boxH-2, x+boxW, y+boxH, withAlpha(hpColor, alpha));

        ctx.drawText(mc.textRenderer, name,  x+3, y+3,  withAlpha(0xEEEEEE, alpha), true);
        ctx.drawText(mc.textRenderer, hpPct, x+3, y+13, withAlpha(hpColor, alpha),  false);
        if (!weapon.isEmpty()) ctx.drawItem(weapon, x+3, y+20);

        int rx = x + boxW - 4;
        if (!pingStr.isEmpty()) {
            int pw = mc.textRenderer.getWidth(pingStr);
            ctx.drawText(mc.textRenderer, pingStr, rx-pw, y+3, withAlpha(pingColor(t), alpha), false);
        }
        if (!distStr.isEmpty()) {
            int dw = mc.textRenderer.getWidth(distStr);
            ctx.drawText(mc.textRenderer, distStr, rx-dw, y+13, withAlpha(0x666666, alpha), false);
        }
        // FIX: эффекты слева направо (был баг — рисовались справа налево)
        if (showEffects.getState()) {
            Collection<StatusEffectInstance> effects = t.getStatusEffects();
            int ex = x + 50, ey = y + 24;
            for (StatusEffectInstance eff : effects) {
                if (ex > x + boxW - 4) break;
                ctx.fill(ex, ey, ex+4, ey+4, withAlpha(eff.getEffectType().value().getColor(), alpha));
                ex += 6;
            }
        }
    }

    // ── CYBER v4 ─────────────────────────────────────────────────────────────
    private void renderCyber(DrawContext ctx, LivingEntity t) {
        float hp = t.getHealth(), maxHp = t.getMaxHealth();
        float ratio = Math.min(hp / maxHp, 1f);
        int hpColor = hpColor(ratio);

        String name     = getName(t).toUpperCase();
        String hpHex    = String.format("HP:%04.1f/%04.0f", hp, maxHp);
        String distStr  = showDist.getState() ? String.format("DST:%.1fM", mc.player.distanceTo(t)) : "";
        String pingStr  = (showPing.getState() && t instanceof PlayerEntity p) ? "PNG:" + getPingRaw(p) + "ms" : "";
        ItemStack weapon = showWeapon.getState() ? t.getMainHandStack() : ItemStack.EMPTY;
        String wLine    = weapon.isEmpty() ? "WPN:--" : "WPN:" + weapon.getName().getString().toUpperCase();
        Collection<StatusEffectInstance> effects = showEffects.getState()
            ? t.getStatusEffects() : java.util.Collections.emptyList();

        int boxW = 160, boxH = 50 + (effects.isEmpty() ? 0 : 10);
        this.width = boxW; this.height = boxH;

        int alpha = (int)(fadeAnim * 0xFF);
        if (alpha <= 0) return;

        ctx.fill(x, y, x+boxW, y+boxH, withAlpha(0x0A0A12, (int)(fadeAnim * 0xF0)));

        // VISUAL: пульсирующие угловые акценты
        float pulse = (float)(0.6 + 0.4 * Math.sin(cyberPhase));
        int cornerAlpha = (int)(pulse * alpha);
        int aw = 8;
        // углы top-left
        ctx.fill(x,       y,       x+aw, y+1,  withAlpha(hpColor, cornerAlpha));
        ctx.fill(x,       y,       x+1,  y+aw, withAlpha(hpColor, cornerAlpha));
        // углы top-right
        ctx.fill(x+boxW-aw, y,     x+boxW, y+1,  withAlpha(hpColor, cornerAlpha));
        ctx.fill(x+boxW-1,  y,     x+boxW, y+aw, withAlpha(hpColor, cornerAlpha));
        // углы bottom-left
        ctx.fill(x,       y+boxH-1, x+aw, y+boxH, withAlpha(hpColor, cornerAlpha));
        ctx.fill(x,       y+boxH-aw, x+1, y+boxH, withAlpha(hpColor, cornerAlpha));
        // углы bottom-right
        ctx.fill(x+boxW-aw, y+boxH-1, x+boxW, y+boxH, withAlpha(hpColor, cornerAlpha));
        ctx.fill(x+boxW-1,  y+boxH-aw, x+boxW, y+boxH, withAlpha(hpColor, cornerAlpha));

        int ty = y + 4;
        ctx.drawText(mc.textRenderer, "§l" + name, x+5, ty, withAlpha(hpColor, alpha), true);
        if (!pingStr.isEmpty()) {
            int pw = mc.textRenderer.getWidth(pingStr);
            ctx.drawText(mc.textRenderer, pingStr, x+boxW-pw-5, ty, withAlpha(0x00FFCC, alpha), false);
        }
        ty += 10;

        ctx.drawText(mc.textRenderer, "§f" + hpHex, x+5, ty, withAlpha(0xCCFFCC, alpha), false);
        ty += 8;

        // HP-полоска с засечками 25%
        // FIX: засечки clamped чтобы не выходили за края
        int barW = boxW - 10;
        ctx.fill(x+5, ty, x+5+barW, ty+4, withAlpha(0x1A1A1A, alpha));
        ctx.fill(x+5, ty, x+5+Math.min((int)(barW*ratio), barW), ty+4, withAlpha(hpColor, alpha));
        for (int i = 1; i < 4; i++) {
            int mx = x + 5 + (int)(barW * 0.25 * i);
            if (mx < x+5+barW) ctx.fill(mx, ty, mx+1, ty+4, withAlpha(0x000000, alpha));
        }
        ty += 7;

        // Оружие
        String ws = wLine.length() > 22 ? wLine.substring(0, 20) + ".." : wLine;
        ctx.drawText(mc.textRenderer, "§7" + ws, x+5, ty, withAlpha(0x777799, alpha), false);
        if (!weapon.isEmpty()) ctx.drawItem(weapon, x+boxW-18, ty-2);
        ty += 10;

        if (!distStr.isEmpty()) {
            ctx.drawText(mc.textRenderer, "§8" + distStr, x+5, ty, withAlpha(0x555577, alpha), false);
            ty += 9;
        }
        if (!effects.isEmpty()) {
            int ex = x + 5;
            for (StatusEffectInstance eff : effects) {
                if (ex > x + boxW - 10) break;
                ctx.fill(ex, ty+1, ex+4, ty+5, withAlpha(eff.getEffectType().value().getColor(), alpha));
                ex += 6;
            }
        }
    }

    // ── Утилиты ──────────────────────────────────────────────────────────────

    private void renderArmorRow(DrawContext ctx, PlayerEntity p, int ax, int ay) {
        int slot = 0;
        for (int i = 3; i >= 0; i--) {
            var stack = p.getInventory().getArmorStack(i);
            if (!stack.isEmpty()) { ctx.drawItem(stack, ax + slot * 9, ay); if (++slot >= 4) break; }
        }
    }

    private String getPingStr(PlayerEntity p) {
        int ping = getPingRaw(p);
        if (ping < 0) return "";
        String col = ping < 80 ? "§a" : ping < 150 ? "§e" : "§c";
        return col + ping + "ms";
    }

    private int getPingRaw(LivingEntity e) {
        if (!(e instanceof PlayerEntity p)) return -1;
        try {
            // FIX: двойной null-check
            var handler = mc.getNetworkHandler();
            if (handler == null) return -1;
            var entry = handler.getPlayerListEntry(p.getUuid());
            return entry == null ? -1 : entry.getLatency();
        } catch (Exception ex) { return -1; }
    }

    private int pingColor(LivingEntity t) {
        int ping = getPingRaw(t);
        if (ping < 0)   return 0xFF888888;
        if (ping < 80)  return 0xFF44EE77;
        if (ping < 150) return 0xFFFFAA22;
        return 0xFFEE3333;
    }

    private String getName(LivingEntity t) {
        String icon = showType.getState() ? ((t instanceof PlayerEntity) ? "♟ " : "♞ ") : "";
        return icon + t.getName().getString();
    }

    private String buildExtra(LivingEntity t) {
        // FIX: учитываем оба флага
        if (!showDist.getState() && !showType.getState()) return "";
        StringBuilder sb = new StringBuilder();
        if (showDist.getState())
            sb.append(String.format("%.1fm", mc.player.distanceTo(t)));
        return sb.toString();
    }

    private String fmt(float hp, float maxHp) { return String.format("%.1f / %.0f ❤", hp, maxHp); }

    private int hpColor(float ratio) {
        if (ratio > 0.6f) return 0xFF44EE77;
        if (ratio > 0.3f) return 0xFFFFAA22;
        return 0xFFEE3333;
    }

    /** Применить alpha к цвету (только R,G,B сохраняются) */
    private static int withAlpha(int rgb, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    private LivingEntity getTarget() {
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            Entity e = hit.getEntity();
            if (e instanceof LivingEntity l && !l.equals(mc.player)) return l;
        }
        return null;
    }

    /**
     * Рисует голову из скина игрока — 16×16 пикселей из текстуры.
     * Первый слой (face) — U: 8..16, V: 8..16 от 64×64 текстуры.
     * Второй слой (hat) — U: 40..48, V: 8..16.
     */
    private void drawPlayerHead(DrawContext ctx, PlayerEntity player, int x, int y, int size) {
        try {
            var handler = mc.getNetworkHandler();
            if (handler == null) return;
            PlayerListEntry entry = handler.getPlayerListEntry(player.getUuid());
            if (entry == null) return;
            Identifier skin = entry.getSkinTextures().texture();
            // Face layer: в текстуре 64×64 лицо это U8..16, V8..16
            ctx.drawTexture(net.minecraft.client.render.RenderLayer::getEntityCutout, skin, x, y, size, size, 8, 8, 8, 8, 64, 64);
            // Hat layer поверх (overlay)
            ctx.drawTexture(net.minecraft.client.render.RenderLayer::getEntityCutout, skin, x, y, size, size, 40, 8, 8, 8, 64, 64);
        } catch (Exception ignored) {
            // если текстура не загружена — просто не рисуем
        }
    }
}
