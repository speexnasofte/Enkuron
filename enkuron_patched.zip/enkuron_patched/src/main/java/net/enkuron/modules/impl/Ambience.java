package net.enkuron.modules.impl;

import net.enkuron.modules.Module;
import net.enkuron.modules.Setting;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Ambience — атмосферные частицы окружения в зависимости от режима.
 *
 * setTimeOfDay недоступен на клиенте в 1.21.4 Fabric, поэтому
 * модуль реализован через клиентские частицы:
 *
 *   Ambient  — нейтральные частицы рассеянного воздуха (ambient entity effect)
 *   Sunset   — тёплые огненные частицы + дым вдали
 *   Night    — мистические soul-flame частицы и портальные искры
 *
 * Частицы спавнятся вокруг игрока в радиусе 6 блоков.
 */
public class Ambience extends Module {

    private static final String[] MODES = {"Ambient", "Sunset", "Night"};

    private final Setting mode    = new Setting("Режим",      MODES, 0);
    private final Setting density = new Setting("Плотность",  3.0, 1.0, 10.0);

    private final Random rng = new Random();
    private int tickCounter = 0;

    public Ambience() {
        super("Ambience", "Атмосферные частицы: Ambient / Sunset / Night", Category.VISUAL);
        addSetting(mode);
        addSetting(density);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        tickCounter++;
        // Спавним частицы каждые N тиков в зависимости от плотности
        int interval = Math.max(1, (int)(11 - density.getValue()));
        if (tickCounter % interval != 0) return;

        Vec3d pos = mc.player.getPos();
        int count = (int) density.getValue();

        for (int i = 0; i < count; i++) {
            double rx = (rng.nextDouble() - 0.5) * 12;
            double ry = (rng.nextDouble() - 0.5) * 4;
            double rz = (rng.nextDouble() - 0.5) * 12;

            double px = pos.x + rx;
            double py = pos.y + ry + 1.0;
            double pz = pos.z + rz;

            double vx = (rng.nextDouble() - 0.5) * 0.02;
            double vy = rng.nextDouble() * 0.01;
            double vz = (rng.nextDouble() - 0.5) * 0.02;

            switch (mode.getCurrentOption()) {
                case "Sunset" -> {
                    // Тёплые частицы: огонь + дым
                    mc.world.addParticle(ParticleTypes.FLAME,       px, py, pz, vx * 0.5, vy, vz * 0.5);
                    if (rng.nextInt(3) == 0)
                        mc.world.addParticle(ParticleTypes.SMOKE,   px, py, pz, vx, vy * 0.5, vz);
                }
                case "Night" -> {
                    // Мистические частицы: soul fire + portal
                    mc.world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, px, py, pz, vx, vy, vz);
                    if (rng.nextInt(4) == 0)
                        mc.world.addParticle(ParticleTypes.PORTAL,  px, py, pz, vx * 2, vy, vz * 2);
                }
                default -> {
                    // Ambient — лёгкие пузырьки воздуха
                    mc.world.addParticle(ParticleTypes.AMBIENT_ENTITY_EFFECT,
                        px, py, pz, 0.4, 0.6, 1.0); // синеватый оттенок через velocity
                    if (rng.nextInt(5) == 0)
                        mc.world.addParticle(ParticleTypes.CLOUD,   px, py, pz, vx * 0.1, vy * 0.1, vz * 0.1);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
    }
}

