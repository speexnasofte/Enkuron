package net.enkuron;

import net.enkuron.event.EventBus;
import net.enkuron.event.RenderHudEvent;
import net.enkuron.event.TickEvent;
import net.enkuron.modules.Module;
import net.enkuron.modules.ModuleManager;
import net.enkuron.ui.HudEditorScreen;
import net.enkuron.ui.clickgui.EnkuronMenu;
import net.enkuron.utils.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Enkuron v2 — точка входа.
 * Полностью совместим с Minecraft 1.21.4 + Fabric.
 *
 * Изменения v2 (глобальное переписывание):
 *  - Упрощённая архитектура: один ModernGUI вместо 5
 *  - Все модули с полным кодом (никаких заглушек)
 *  - Исправлены все баги двойного рендера HUD
 *  - Новые модули: AutoShield, FastPlace, StepUp, AutoSprint, Speedometer, PingHUD и др.
 *  - Правильный EventBus с авто-подпиской при toggle()
 *  - ConfigManager сохраняет настройки, HUD-позиции, GUI-стиль
 */
public class Enkuron implements ClientModInitializer {

    public static final String NAME    = "Enkuron";
    public static final String VERSION = "2.2.0";

    // ── Кейбинды ─────────────────────────────────────────────────────────────
    private static KeyBinding keyOpenMenu;
    private static KeyBinding keyOpenHudEditor; // FIX: HudEditorScreen не имел кейбинда — недостижим
    private static KeyBinding keyToggleSprint;
    private static KeyBinding keyToggleNoFall;
    private static KeyBinding keyToggleBrightness;
    private static KeyBinding keyToggleGlowESP;
    private static KeyBinding keyToggleAutoTotem;
    private static KeyBinding keyToggleZoom;
    private static KeyBinding keyToggleKillCounter;

    @Override
    public void onInitializeClient() {
        registerKeybinds();
        ModuleManager.init();
        net.enkuron.ui.gui.GUIManager.init(); // FIX: один раз при запуске, не при каждом открытии меню
        ConfigManager.load();

        // ── Тик ──────────────────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            ModuleManager.onTick();
            ConfigManager.onTick(); // FIX: автосейв каждые ~1 мин и через 3 сек после изменений
            EventBus.post(new TickEvent(client));
            handleKeybinds(client);
        });

        // ── Рендер HUD ───────────────────────────────────────────────────────
        // ВАЖНО: ModuleManager.onRender() вызывается только из MixinInGameHud.
        // Здесь только рассылаем RenderHudEvent для @EventHandler-подписчиков.
        HudRenderCallback.EVENT.register((context, tickCounter) ->
            EventBus.post(new RenderHudEvent(context))
        );

        // ── Сохранение при выходе ────────────────────────────────────────────
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ConfigManager.save();
            System.out.println("[Enkuron] Config saved.");
        });

        System.out.println("[Enkuron] v" + VERSION + " loaded (MC 1.21.4)");
    }

    // ── Регистрация кейбиндов ─────────────────────────────────────────────────

    private void registerKeybinds() {
        keyOpenMenu         = reg("key.enkuron.menu",        GLFW.GLFW_KEY_RIGHT_SHIFT);
        keyOpenHudEditor    = reg("key.enkuron.hudeditor",   GLFW.GLFW_KEY_F9); // FIX: HUD редактор теперь открывается по F9
        keyToggleSprint     = reg("key.enkuron.sprint",      GLFW.GLFW_KEY_V);
        keyToggleNoFall     = reg("key.enkuron.nofall",      GLFW.GLFW_KEY_B);
        keyToggleBrightness = reg("key.enkuron.brightness",  GLFW.GLFW_KEY_F6);
        keyToggleGlowESP    = reg("key.enkuron.glowesp",     GLFW.GLFW_KEY_F7);
        keyToggleAutoTotem  = reg("key.enkuron.autototem",   GLFW.GLFW_KEY_F8);
        keyToggleZoom       = reg("key.enkuron.zoom",        GLFW.GLFW_KEY_C);
        keyToggleKillCounter= reg("key.enkuron.killcounter", GLFW.GLFW_KEY_F10);
    }

    private static KeyBinding reg(String id, int glfwKey) {
        return KeyBindingHelper.registerKeyBinding(
            new KeyBinding(id, InputUtil.Type.KEYSYM, glfwKey, "Enkuron")
        );
    }

    private void handleKeybinds(net.minecraft.client.MinecraftClient client) {
        if (keyOpenMenu.wasPressed() && !(client.currentScreen instanceof EnkuronMenu)) {
            client.setScreen(new EnkuronMenu());
        }
        if (keyOpenHudEditor.wasPressed() && !(client.currentScreen instanceof HudEditorScreen)) {
            client.setScreen(new HudEditorScreen()); // FIX: открытие HUD редактора по F9
        }
        if (keyToggleSprint.wasPressed())     toggle("Sprint");
        if (keyToggleNoFall.wasPressed())     toggle("NoFall");
        if (keyToggleBrightness.wasPressed()) toggle("Brightness");
        if (keyToggleGlowESP.wasPressed())    toggle("GlowESP");
        if (keyToggleAutoTotem.wasPressed())  toggle("AutoTotem");
        if (keyToggleKillCounter.wasPressed())toggle("KillCounter");
    }

    private void toggle(String name) {
        Module m = ModuleManager.getByName(name);
        if (m != null) m.toggle();
    }
}
