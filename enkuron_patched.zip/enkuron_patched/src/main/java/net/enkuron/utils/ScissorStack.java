package net.enkuron.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * ScissorStack — правильный клиппинг для GUI.
 *
 * Проблема без ScissorStack: контент при скролле вылезает за края панели.
 * Проблема с простым enableScissor: вложенные клиппинги ломают друг друга.
 *
 * Решение: стек прямоугольников клиппинга с пересечением (intersection).
 * Каждый push() пересекает с предыдущим регионом — корректно при любой вложенности.
 *
 * Использование:
 *   ScissorStack.push(ctx, x, y, width, height);
 *   // ... рисуем контент ...
 *   ScissorStack.pop();
 */
public final class ScissorStack {

    private ScissorStack() {}

    private record Rect(int x, int y, int w, int h) {
        /** Пересечение двух прямоугольников. Возвращает пустой rect если нет пересечения. */
        Rect intersect(Rect other) {
            int nx = Math.max(this.x, other.x);
            int ny = Math.max(this.y, other.y);
            int nw = Math.min(this.x + this.w, other.x + other.w) - nx;
            int nh = Math.min(this.y + this.h, other.y + other.h) - ny;
            return new Rect(nx, ny, Math.max(0, nw), Math.max(0, nh));
        }
    }

    private static final Deque<Rect> STACK = new ArrayDeque<>();

    /**
     * Включить scissor-клиппинг для указанного региона.
     * Координаты — в scaled (GUI) пространстве.
     */
    public static void push(int x, int y, int width, int height) {
        Rect region = new Rect(x, y, width, height);

        if (!STACK.isEmpty()) {
            region = STACK.peek().intersect(region);
        }

        STACK.push(region);
        applyScissor(region);
    }

    /**
     * Выключить последний scissor и вернуть предыдущий (если есть).
     * ВСЕГДА вызывай pop() после push() — иначе стек ломается.
     */
    public static void pop() {
        if (STACK.isEmpty()) return;
        STACK.pop();

        if (STACK.isEmpty()) {
            RenderSystem.disableScissor();
        } else {
            applyScissor(STACK.peek());
        }
    }

    /** Принудительно очищает стек (вызывать при закрытии GUI или краше render). */
    public static void clear() {
        STACK.clear();
        RenderSystem.disableScissor();
    }

    /** Проверить, не пуст ли стек (для отладки). */
    public static boolean isActive() {
        return !STACK.isEmpty();
    }

    private static void applyScissor(Rect r) {
        if (r.w <= 0 || r.h <= 0) {
            // Пустой регион — всё скрыто
            RenderSystem.enableScissor(0, 0, 0, 0);
            return;
        }

        // Перевод из GUI-координат в физические пиксели (с учётом scaleFactor)
        double scale = MinecraftClient.getInstance().getWindow().getScaleFactor();
        int winH = MinecraftClient.getInstance().getWindow().getHeight();

        int px = (int)(r.x * scale);
        int py = (int)(winH - (r.y + r.h) * scale);  // OpenGL Y инвертирован
        int pw = (int)(r.w * scale);
        int ph = (int)(r.h * scale);

        RenderSystem.enableScissor(px, py, pw, ph);
    }
}
