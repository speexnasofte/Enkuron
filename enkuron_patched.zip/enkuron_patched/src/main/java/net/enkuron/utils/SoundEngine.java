package net.enkuron.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * SoundEngine — тихие кастомные звуки для GUI.
 *
 * Маленькая деталь, но огромно влияет на «premium feel»:
 *  - Клик по модулю:   тихий UI-click (как в Lunar)
 *  - Включение:        высокий мягкий тик
 *  - Выключение:       низкий приглушённый тик
 *  - Открытие GUI:     мягкий вуш
 *  - Смена категории:  лёгкое касание
 *
 * Все звуки — vanilla Minecraft, адаптированы pitch/volume для UI.
 * Не требует никаких дополнительных ресурсов.
 */
public final class SoundEngine {

    private SoundEngine() {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── Throttle: не играть один звук чаще N мс ──────────────────────────
    private static long lastToggleSound = 0L;
    private static long lastClickSound  = 0L;
    private static long lastCatSound    = 0L;

    private static final long THROTTLE_TOGGLE_MS = 80L;
    private static final long THROTTLE_CLICK_MS  = 50L;
    private static final long THROTTLE_CAT_MS    = 120L;

    /**
     * Звук включения модуля.
     * Тихий высокий «тик» — pitch 1.6, volume 0.12.
     */
    public static void playModuleOn() {
        long now = System.currentTimeMillis();
        if (now - lastToggleSound < THROTTLE_TOGGLE_MS) return;
        lastToggleSound = now;
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.12f, 1.6f);
    }

    /**
     * Звук выключения модуля.
     * Приглушённый низкий «тик» — pitch 0.8, volume 0.10.
     */
    public static void playModuleOff() {
        long now = System.currentTimeMillis();
        if (now - lastToggleSound < THROTTLE_TOGGLE_MS) return;
        lastToggleSound = now;
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.10f, 0.8f);
    }

    /**
     * Звук открытия GUI.
     * Мягкий страница-перелистывание — как открытие меню.
     */
    public static void playGuiOpen() {
        play(SoundEvents.ITEM_BOOK_PAGE_TURN, 0.20f, 1.2f);
    }

    /**
     * Звук закрытия GUI.
     */
    public static void playGuiClose() {
        play(SoundEvents.ITEM_BOOK_PAGE_TURN, 0.15f, 0.85f);
    }

    /**
     * Звук смены категории.
     * Лёгкое мягкое касание.
     */
    public static void playCategoryChange() {
        long now = System.currentTimeMillis();
        if (now - lastCatSound < THROTTLE_CAT_MS) return;
        lastCatSound = now;
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.07f, 1.3f);
    }

    /**
     * Звук открытия настроек модуля.
     */
    public static void playSettingsOpen() {
        play(SoundEvents.ITEM_BOOK_PAGE_TURN, 0.12f, 1.5f);
    }

    /**
     * Звук взаимодействия со слайдером.
     */
    public static void playSliderTick() {
        long now = System.currentTimeMillis();
        if (now - lastClickSound < THROTTLE_CLICK_MS) return;
        lastClickSound = now;
        play(SoundEvents.UI_BUTTON_CLICK.value(), 0.05f, 2.0f);
    }

    // ── Внутренний метод проигрывания ─────────────────────────────────────

    private static void play(SoundEvent event, float volume, float pitch) {
        if (mc == null || mc.getSoundManager() == null) return;
        try {
            mc.getSoundManager().play(
                PositionedSoundInstance.master(event, pitch, volume)
            );
        } catch (Exception ignored) {
            // Не крашим если звук не нашли
        }
    }
}
