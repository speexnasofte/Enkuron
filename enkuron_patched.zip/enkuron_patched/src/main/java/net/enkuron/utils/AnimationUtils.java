package net.enkuron.utils;

/**
 * AnimationUtils v4 — PREMIUM ANIMATIONS
 * Улучшено: delta-independent lerp, elastic easing, magnetic snap,
 * smooth counter, cubic bezier, chromatic shift, multi-spring.
 */
public final class AnimationUtils {

    private AnimationUtils() {}

    // ═══════════════════════════════════════════════════════
    // БАЗОВЫЕ LERP
    // ═══════════════════════════════════════════════════════

    public static float lerp(float current, float target, float speed) {
        return current + (target - current) * speed;
    }

    public static double lerp(double current, double target, double speed) {
        return current + (target - current) * speed;
    }

    /** Frame-rate independent lerp (60fps base). */
    public static float lerpDelta(float current, float target, float speed, float deltaTime) {
        float corrected = 1f - (float) Math.pow(1f - speed, deltaTime * 60f);
        return lerp(current, target, corrected);
    }

    /** Сверхплавный lerp — ещё медленнее у цели (premium feel). */
    public static float smoothLerp(float current, float target, float speed) {
        float diff = target - current;
        if (Math.abs(diff) < 0.0005f) return target;
        return current + diff * speed * (0.6f + 0.4f * Math.abs(diff));
    }

    public static float easeOut(float current, float target, float speed) {
        float diff = target - current;
        if (Math.abs(diff) < 0.001f) return target;
        return current + diff * speed;
    }

    public static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    public static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ═══════════════════════════════════════════════════════
    // EASING ФУНКЦИИ
    // ═══════════════════════════════════════════════════════

    public static float smoothStep(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /** Smoother step — ещё мягче чем smoothStep. */
    public static float smootherStep(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * t * (t * (t * 6f - 15f) + 10f);
    }

    public static float easeInOut(float t) {
        t = clamp(t, 0f, 1f);
        return (float)(-(Math.cos(Math.PI * t) - 1.0) / 2.0);
    }

    public static float easeIn(float t) {
        t = clamp(t, 0f, 1f);
        return t * t;
    }

    public static float easeInCubic(float t) {
        t = clamp(t, 0f, 1f);
        return t * t * t;
    }

    public static float easeOutQuad(float t) {
        t = clamp(t, 0f, 1f);
        return 1f - (1f - t) * (1f - t);
    }

    public static float easeOutCubic(float t) {
        t = clamp(t, 0f, 1f);
        float f = 1f - t;
        return 1f - f * f * f;
    }

    public static float easeInOutCubic(float t) {
        t = clamp(t, 0f, 1f);
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    /** Elastic easeOut — отскок как в iOS/Material Design. */
    public static float easeOutElastic(float t) {
        t = clamp(t, 0f, 1f);
        if (t == 0f || t == 1f) return t;
        float c4 = (float)(2f * Math.PI / 3f);
        return (float)(Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1);
    }

    /** Back easeOut — небольшой overshoot как в Android Material. */
    public static float easeOutBack(float t) {
        t = clamp(t, 0f, 1f);
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        float f = t - 1f;
        return 1f + c3 * f * f * f + c1 * f * f;
    }

    /** Cubic Bezier approximation (p1, p2 — control points 0..1). */
    public static float cubicBezier(float t, float p1x, float p1y, float p2x, float p2y) {
        t = clamp(t, 0f, 1f);
        // Apple-style: fast start, gentle end
        float u = 1f - t;
        return 3f * u * u * t * p1y + 3f * u * t * t * p2y + t * t * t;
    }

    // ═══════════════════════════════════════════════════════
    // SPRING ФИЗИКА
    // ═══════════════════════════════════════════════════════

    /** Spring с overshoot (velocity[0] — скорость, хранить между кадрами). */
    public static float spring(float current, float target, float[] velocity,
                               float stiffness, float damping) {
        float force = (target - current) * stiffness;
        velocity[0] = velocity[0] * damping + force;
        return current + velocity[0];
    }

    /**
     * Premium spring — более реалистичный, как в SwiftUI.
     * stiffness: 0.08-0.2, damping: 0.6-0.85
     */
    public static float premiumSpring(float current, float target, float[] vel,
                                      float stiffness, float damping) {
        float displacement = target - current;
        float springForce  = displacement * stiffness;
        float dampForce    = vel[0] * (1f - damping);
        vel[0] = (vel[0] - dampForce) + springForce;
        float next = current + vel[0];
        // Magnetic snap: если очень близко к цели — защёлкнуть
        if (Math.abs(target - next) < 0.0008f && Math.abs(vel[0]) < 0.0008f) {
            vel[0] = 0f;
            return target;
        }
        return next;
    }

    // ═══════════════════════════════════════════════════════
    // СПЕЦИАЛЬНЫЕ АНИМАЦИИ
    // ═══════════════════════════════════════════════════════

    public static float bounce(float t) {
        t = clamp(t, 0f, 1f);
        float n1 = 7.5625f, d1 = 2.75f;
        if      (t < 1f / d1)   return n1 * t * t;
        else if (t < 2f / d1)   { t -= 1.5f  / d1; return n1 * t * t + 0.75f; }
        else if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
        else                    { t -= 2.625f / d1; return n1 * t * t + 0.984375f; }
    }

    public static float oscillate(double phase, float min, float max) {
        float amp = (max - min) / 2f;
        return min + amp + amp * (float) Math.sin(phase);
    }

    public static float pulseAlpha(double phase, float minAlpha, float maxAlpha) {
        return oscillate(phase, minAlpha, maxAlpha);
    }

    /** Плавный счётчик — значение «наползает» на цель (для HUD цифр). */
    public static float smoothCounter(float current, float target, float speed) {
        return lerp(current, target, speed);
    }

    public static double wrapAngle(double radians) {
        while (radians >  Math.PI) radians -= 2 * Math.PI;
        while (radians < -Math.PI) radians += 2 * Math.PI;
        return radians;
    }

    // ═══════════════════════════════════════════════════════
    // ЦВЕТ И ГРАФИКА
    // ═══════════════════════════════════════════════════════

    public static int breatheAlpha(int baseAlpha, int range, long speedMs) {
        float phase = (float)(System.currentTimeMillis() % speedMs) / speedMs;
        float sin = (float) Math.sin(phase * Math.PI * 2);
        return (int) clamp((double)(baseAlpha + sin * range), 0.0, 255.0);
    }

    public static int colorLerp(int from, int to, float t) {
        t = clamp(t, 0f, 1f);
        int fa = (from >> 24) & 0xFF, fr = (from >> 16) & 0xFF, fg = (from >> 8) & 0xFF, fb = from & 0xFF;
        int ta = (to   >> 24) & 0xFF, tr = (to   >> 16) & 0xFF, tg = (to   >> 8) & 0xFF, tb = to   & 0xFF;
        return ((int)(fa + (ta-fa)*t) << 24) | ((int)(fr + (tr-fr)*t) << 16)
             | ((int)(fg + (tg-fg)*t) << 8)  |  (int)(fb + (tb-fb)*t);
    }

    /** Плавный colorLerp через HSB-пространство (без «серого» в середине). */
    public static int colorLerpHSB(int from, int to, float t) {
        t = clamp(t, 0f, 1f);
        float[] hsbFrom = java.awt.Color.RGBtoHSB((from>>16)&0xFF,(from>>8)&0xFF,from&0xFF,null);
        float[] hsbTo   = java.awt.Color.RGBtoHSB((to  >>16)&0xFF,(to  >>8)&0xFF,to  &0xFF,null);
        // Shortest hue path
        float dh = hsbTo[0] - hsbFrom[0];
        if (dh >  0.5f) dh -= 1f;
        if (dh < -0.5f) dh += 1f;
        float h = hsbFrom[0] + dh * t;
        float s = hsbFrom[1] + (hsbTo[1] - hsbFrom[1]) * t;
        float b = hsbFrom[2] + (hsbTo[2] - hsbFrom[2]) * t;
        int fa = (from >> 24) & 0xFF, ta = (to >> 24) & 0xFF;
        int a  = (int)(fa + (ta - fa) * t);
        int rgb = java.awt.Color.HSBtoRGB(h, s, b);
        return (a << 24) | (rgb & 0x00FFFFFF);
    }

    public static int hsvToArgb(float hue, float saturation, float value, int alpha) {
        hue = hue % 360f; if (hue < 0) hue += 360f;
        float h = hue / 60f;
        float p = value * (1f - saturation);
        float q = value * (1f - saturation * (h % 1f));
        float t = value * (1f - saturation * (1f - h % 1f));
        float r, g, b;
        int i = (int) h;
        switch (i) {
            case 0  -> { r = value; g = t;     b = p;     }
            case 1  -> { r = q;     g = value; b = p;     }
            case 2  -> { r = p;     g = value; b = t;     }
            case 3  -> { r = p;     g = q;     b = value; }
            case 4  -> { r = t;     g = p;     b = value; }
            default -> { r = value; g = p;     b = q;     }
        }
        return (alpha << 24) | ((int)(r*255) << 16) | ((int)(g*255) << 8) | (int)(b*255);
    }

    public static int rainbowArgb(float offset, float speed) {
        float hue = ((System.currentTimeMillis() * speed / 2000f) + offset) % 1f;
        if (hue < 0) hue += 1f;
        return (java.awt.Color.HSBtoRGB(hue, 0.75f, 1.0f) & 0x00FFFFFF) | 0xFF000000;
    }

    /**
     * Chromatic rainbow — медленная красивая радуга (как в Lunar client).
     * speed: скорость 0.0001–0.001, offset: смещение фазы [0..1].
     */
    public static int chromaticRainbow(float offset, float speed) {
        float hue = ((System.currentTimeMillis() * speed) + offset) % 1f;
        if (hue < 0) hue += 1f;
        return (java.awt.Color.HSBtoRGB(hue, 0.65f, 1.0f) & 0x00FFFFFF) | 0xFF000000;
    }

    public static void fillSoftShadow(net.minecraft.client.gui.DrawContext ctx,
                                       int x, int y, int w, int h, int baseAlpha, int layers) {
        for (int i = layers; i >= 1; i--) {
            int a = baseAlpha / (i + 1);
            ctx.fill(x-i, y-i, x+w+i, y+h+i, (a << 24));
        }
    }

    /**
     * Premium drop shadow — многослойная тень с правильным falloff.
     */
    public static void fillPremiumShadow(net.minecraft.client.gui.DrawContext ctx,
                                          int x, int y, int w, int h,
                                          int shadowColor, int layers) {
        int baseA = (shadowColor >> 24) & 0xFF;
        int rgb   = shadowColor & 0x00FFFFFF;
        for (int i = layers; i >= 1; i--) {
            float t   = (float)(layers - i + 1) / layers;
            int   a   = (int)(baseA * easeOutCubic(1f - t));
            int   off = i;
            ctx.fill(x-off, y-off+off, x+w+off, y+h+off+off, (a << 24) | rgb); // bottom
            ctx.fill(x-off, y-off,     x+w+off, y+h+off,     (a/3 << 24) | rgb); // all sides
        }
    }
}
