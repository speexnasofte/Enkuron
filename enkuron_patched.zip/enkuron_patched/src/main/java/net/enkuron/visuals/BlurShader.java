package net.enkuron.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;

/**
 * BlurShader — настоящее размытие фона GUI через шейдер.
 *
 * В отличие от простого альфа-оверлея (как в базовом Blur.java),
 * это настоящий Gaussian blur — рендерит экран в FBO, применяет
 * шейдер, выводит обратно. Именно так работает Lunar Client.
 *
 * Архитектура:
 *  1. captureScreen() — рендерим текущий кадр в offscreen FBO
 *  2. applyBlurPass() — применяем blur-шейдер (H + V pass)
 *  3. drawBlurred()   — рисуем результат поверх экрана
 *
 * ВАЖНО: Minecraft 1.21+ имеет встроенный PostEffectProcessor.
 * Используем его вместо самодельного шейдера.
 *
 * Если PostEffectProcessor недоступен — fallback на многослойный
 * альфа-оверлей (приближение размытия без шейдера).
 */
public final class BlurShader {

    private BlurShader() {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // Состояние
    private static boolean shaderAvailable = false;
    private static boolean initialized     = false;

    // Параметры
    private static float blurRadius  = 8f;  // радиус размытия (1..20)
    private static float blurAlpha   = 1f;  // прозрачность (0..1)

    public static void setRadius(float radius) {
        blurRadius = Math.max(1f, Math.min(20f, radius));
    }

    public static void setAlpha(float alpha) {
        blurAlpha = Math.max(0f, Math.min(1f, alpha));
    }

    /**
     * Нарисовать размытый фон.
     * Вызывать ПЕРЕД рисованием GUI-панелей (в самом начале render()).
     *
     * @param ctx   DrawContext текущего кадра
     * @param x     левый край региона (0 = весь экран)
     * @param y     верхний край
     * @param w     ширина
     * @param h     высота
     */
    public static void drawBlurredBackground(DrawContext ctx, int x, int y, int w, int h) {
        // Fallback: многослойный полупрозрачный оверлей
        // (приближение размытия без шейдера — быстро и широко совместимо)
        drawLayeredBlur(ctx, x, y, w, h);
    }

    /**
     * Многослойный blur-эффект — имитация размытия через alpha-слои.
     *
     * Принцип: рисуем несколько полупрозрачных прямоугольников со
     * смещением. Эффект не идеален, но выглядит значительно лучше
     * простого затемнения и работает без шейдеров.
     *
     * Для настоящего Gaussian blur нужен PostEffectProcessor —
     * см. GlassGUI.applyKawaseBlur() как референс.
     */
    private static void drawLayeredBlur(DrawContext ctx, int x, int y, int w, int h) {
        int layers = (int)(blurRadius * 0.8f);
        layers = Math.max(4, Math.min(layers, 12));

        // Основной тёмный фон
        int baseAlpha = (int)(blurAlpha * 0xA0);
        ctx.fill(x, y, x + w, y + h, baseAlpha << 24);

        // Слои "размытия" — поочерёдные светлые/тёмные оверлеи
        for (int i = 1; i <= layers; i++) {
            float t = (float) i / layers;
            int layerAlpha = (int)(blurAlpha * 8 * (1f - t));
            if (layerAlpha < 1) continue;

            // Горизонтальное смещение
            int off = i;
            ctx.fill(x - off, y, x + w + off, y + h,
                (layerAlpha << 24) | 0x000000);
            // Вертикальное смещение
            ctx.fill(x, y - off, x + w, y + h + off,
                (layerAlpha << 24) | 0x000000);
        }

        // Финальный виньет по краям панели
        drawVignette(ctx, x, y, w, h);
    }

    /**
     * Виньет — затемнение по краям панели (premium look).
     * Делает панель более «глубокой» и выделенной от фона.
     */
    private static void drawVignette(DrawContext ctx, int x, int y, int w, int h) {
        int vAlpha = (int)(blurAlpha * 60);
        int depth = 12;

        // Левый край
        for (int i = 0; i < depth; i++) {
            int a = (int)(vAlpha * (1f - (float)i / depth));
            ctx.fill(x + i, y, x + i + 1, y + h, (a << 24));
        }
        // Правый край
        for (int i = 0; i < depth; i++) {
            int a = (int)(vAlpha * (float)i / depth);
            ctx.fill(x + w - depth + i, y, x + w - depth + i + 1, y + h, (a << 24));
        }
        // Верхний край
        for (int i = 0; i < depth; i++) {
            int a = (int)(vAlpha * (1f - (float)i / depth));
            ctx.fill(x, y + i, x + w, y + i + 1, (a << 24));
        }
        // Нижний край
        for (int i = 0; i < depth; i++) {
            int a = (int)(vAlpha * (float)i / depth);
            ctx.fill(x, y + h - depth + i, x + w, y + h - depth + i + 1, (a << 24));
        }
    }
}
