# Enkuron v2.5 — Premium Smooth Animations Update

## AnimationUtils v4 — Новые методы

- `smootherStep(t)` — 5-степенная функция, ещё мягче smoothStep
- `easeOutElastic(t)` — iOS-стиль с упругим отскоком
- `easeOutBack(t)` — Material Design с небольшим overshoot
- `easeInCubic / easeOutCubic` — кубические функции
- `premiumSpring(pos, target, vel, stiffness, damping)` — реалистичная spring-физика с magnetic snap
- `smoothLerp(...)` — плавный lerp, замедляется у цели
- `colorLerpHSB(...)` — интерполяция цвета через HSB (без серых тонов в середине)
- `chromaticRainbow(offset, speed)` — медленная плавная радуга как в Lunar Client
- `fillPremiumShadow(...)` — многослойная тень с easing falloff
- `smoothCounter(...)` — плавный счётчик для HUD цифр

## GUI Улучшения

### AuroraGUI
- Открытие: `easeOutBack` вместо `easeInOut` → плавный bounce при открытии
- Двойная сглаживание: `smootherStep` + `easeOutBack`
- Liquid Toggle: `premiumSpring` вместо обычного spring → более реалистичный overshoot
- Ripple волны: 5% медленнее распространяются → более плавно
- Hover-анимации: 20% скорости (было 18%) → отзывчивее

### ModernGUI
- Открытие: добавлен `smootherStep` для более мягкого открытия
- Toggle переключатели: `premiumSpring` с magnetic snap
- Toggle glow: подсветка при включении плавно fade in/out
- Тень: premium shadow с easing falloff (было просто alpha layers)
- Scroll: momentum decay 80% (было 85%) → ощущение тяжести

### GlassGUI
- Открытие: `easeOutBack` → стеклянная панель «прыгает» на место
- Toggle: `premiumSpring` с damping 0.72
- Hover: 18% (было 20%) → чуть мягче

### NeonGUI
- Открытие: `easeOutBack` вместо linear
- Toggle: `premiumSpring` вместо простого lerp

### MinimalGUI
- Добавлена анимация открытия с `easeOutBack`
- Панель настроек теперь появляется плавно (slide) с `smoothStep`
- Тень при появлении панели настроек

## NotificationManager v3

- Spring-физика для slide-in (было просто lerp)
- Shake-анимация при WARNING уведомлениях
- Glow за цветной полоской (5 слоёв)
- Chromatic title для TOGGLE уведомлений (как в Lunar)
- Eased прогресс-бар (плавно запаздывает)
- Fade-in через `easeOutCubic` (было linear)
- Pulsing иконка

## HUD Модули
- TargetESP: ускоренные lerp анимации
- ArrayList: ускоренные slide-in
- Watermark: более быстрые pulse эффекты
