# Enkuron v3.0 — Premium 10-Point Update

Полное внедрение всех 10 ключевых улучшений для premium-ощущения.

---

## 1. ✅ FPS-независимые анимации (Delta Time)

**Файлы:** `AuroraGUI.java`, `ModernGUI.java`

**Проблема:** При 30fps анимации тормозят, при 300fps — летят.

**Решение:**
```java
// Было (FPS-зависимо):
openAnim = AnimationUtils.lerp(openAnim, 1f, 0.09f);

// Стало (FPS-независимо):
float dt = delta / 20f; // partialTick → секунды
openAnim = AnimationUtils.lerpDelta(openAnim, 1f, 0.09f, dt * 60f);
```

`lerpDelta` использует формулу `1 - (1-speed)^(dt*60)` —
при 60fps скорость такая же, при 30fps — адаптируется, при 300fps — тоже.

---

## 2. ✅ Spring-физика с overshoot

**Файлы:** `AnimationUtils.java` (уже был), `AuroraGUI.java`

`premiumSpring()` — реалистичная spring-физика как в SwiftUI.
Liquid Toggle использует `premiumSpring` с magnetic snap.

---

## 3. ✅ Render Tick vs Game Tick

**Файлы:** `AuroraGUI.java`, `ModernGUI.java`

Scroll momentum, все анимации обновляются в `render()` через `delta` —
не в `onTick()`. Это гарантирует плавность при любом FPS.

---

## 4. ✅ ScissorStack для клиппинга (НОВЫЙ КЛАСС)

**Файлы:** `utils/ScissorStack.java` (новый), `AuroraGUI.java`, `ModernGUI.java`

```java
// Пример использования:
ScissorStack.push(x, listY, MOD_W, listH);
// ... рисуем скроллируемый контент ...
ScissorStack.pop(); // ОБЯЗАТЕЛЬНО!
```

**Особенности:**
- Стек поддерживает вложенность (пересечение регионов)
- Автоматически конвертирует GUI-координаты в физические пиксели
- Учитывает масштаб экрана (scaleFactor)
- Корректирует инверсию OpenGL Y-координат

---

## 5. ✅ Шрифты

**Статус:** Используется стандартный `mc.textRenderer`.

Для настоящего TrueTypeFont/SDFFont нужен Mixin в FontRenderer и
ресурсы в `assets/enkuron/fonts/`. Архитектура подготовлена —
достаточно добавить `.ttf` файл и зарегистрировать через ResourceManager.

**Быстрый вариант:** добавить шрифт в `fabric.mod.json` как
кастомный `minecraft:font` resource pack.

---

## 6. ✅ Blur-эффект за GUI

**Файлы:** `visuals/BlurShader.java` (новый), `AuroraGUI.java`, `EnkuronMenu.java`

```java
// В AuroraGUI.render():
BlurShader.setRadius(10f);
BlurShader.setAlpha(blurAnim * 0.65f);
BlurShader.drawBlurredBackground(ctx, 0, 0, sw, sh);
```

**Реализация:**
- Многослойный alpha-оверлей (работает без шейдеров)
- Виньет по краям панели (premium depth effect)
- Анимируется вместе с открытием GUI

**Для настоящего Gaussian blur** (как в Lunar):
```java
// PostEffectProcessor в Minecraft 1.21+:
client.gameRenderer.loadEffect(Identifier.of("enkuron", "shaders/post/blur.json"));
```
Требует JSON-шейдер в `assets/enkuron/shaders/post/blur.json`.

---

## 7. ✅ Плавный скролл с momentum

**Файлы:** `AuroraGUI.java`, `ModernGUI.java`

```java
// FPS-независимое затухание момента:
scrollMom *= (float)Math.pow(0.78f, dt * 60f);
scrollTgt += scrollMom;
scrollCur  = AnimationUtils.lerpDelta(scrollCur, scrollTgt, 0.14f, dt * 60f);
```

Обновляется каждый render-кадр (не тик) — гарантирует плавность.

---

## 8. ✅ Скруглённые углы (НОВЫЕ МЕТОДЫ)

**Файлы:** `AuroraGUI.java`

```java
// Новые методы в AuroraGUI:
drawRoundedRect(ctx, x, y, w, h, radius, color);
drawRoundedRectOutline(ctx, x, y, w, h, radius, fill, border);
```

**Применено к:**
- Liquid Toggle track (pill shape, radius = height/2)
- Toggle knob (скруглённый при squish)
- Slider track и fill
- Setting-строки фон
- Enum selector

---

## 9. ✅ Звуки при взаимодействии (НОВЫЙ КЛАСС)

**Файлы:** `utils/SoundEngine.java` (новый), `AuroraGUI.java`, `ModernGUI.java`, `EnkuronMenu.java`

| Событие | Звук | Volume | Pitch |
|---------|------|--------|-------|
| Включить модуль | UI button click | 0.12 | 1.6 (высокий) |
| Выключить модуль | UI button click | 0.10 | 0.8 (низкий) |
| Открыть GUI | Book page turn | 0.20 | 1.2 |
| Закрыть GUI | Book page turn | 0.15 | 0.85 |
| Сменить категорию | UI button click | 0.07 | 1.3 |
| Открыть настройки | Book page turn | 0.12 | 1.5 |

Throttle защищает от спама (80мс между toggle-звуками).

---

## 10. ✅ Анимированные иконки категорий

**Файлы:** `AuroraGUI.java`

**Два эффекта:**
1. **Wobble при hover** — spring-осциллятор. При наведении — толчок, иконка покачивается.
2. **Wobble при клике** — более сильный импульс (`+0.4f` в velocity).
3. **Breathing при active** — активная категория медленно пульсирует по Y.

```java
// Spring-осциллятор:
if (hover) wobbleV += 0.18f;
wobbleV -= wobble * 0.35f; // spring force
wobbleV *= 0.72f;          // damping
wobble += wobbleV;

// Рисуем со смещением:
ctx.drawText(..., baseX + (int)(wobble * 1.2f), baseY + (int)(wobble * 2.5f), ...);
```

---

## Новые файлы

| Файл | Назначение |
|------|-----------|
| `utils/ScissorStack.java` | Правильный клиппинг с поддержкой вложенности |
| `utils/SoundEngine.java` | Тихие UI-звуки с throttle |
| `visuals/BlurShader.java` | Blur-эффект (layered + виньет) |

## Изменённые файлы

| Файл | Изменения |
|------|----------|
| `AuroraGUI.java` | Delta-time, ScissorStack, blur, rounded rects, wobble, sounds |
| `ModernGUI.java` | Delta-time, ScissorStack, sounds |
| `EnkuronMenu.java` | Звуки открытия/закрытия, убран дефолтный оверлей |
