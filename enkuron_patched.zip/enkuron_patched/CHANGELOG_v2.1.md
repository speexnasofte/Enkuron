# Enkuron v2.1.0 — Changelog

## Исправления багов

### Setting — автосохранение при изменении настроек
**Файл:** `modules/Setting.java`

`setValue()`, `setState()`, `setBoolValue()`, `setOptionIndex()` теперь
вызывают `ConfigManager.scheduleAutosave()`. Ранее dirty-сейв никогда не
срабатывал при изменении настроек через GUI — работал только периодический
автосейв раз в минуту.

---

### TargetManager — thread-safe Double-Checked Locking
**Файл:** `combat/TargetManager.java`

Singleton-инстанс теперь объявлен `volatile`, инициализация обёрнута в
`synchronized`-блок (DCL-паттерн). Устраняет потенциальное создание двух
экземпляров при одновременном первом обращении.

---

### AutoPotion — реальная проверка типа зелья
**Файл:** `modules/impl/AutoPotion.java`

`findPotion()` раньше возвращал любое `Items.POTION` без проверки типа
(можно было выпить зелье замедления или прыжка при низком HP).

Теперь метод читает `PotionContentsComponent` (MC 1.21+ API) и ищет зелья
в правильном приоритете:
1. INSTANT_HEALTH (мгновенное исцеление)
2. REGENERATION (регенерация)
3. STRENGTH (сила) — если включена настройка "Пить Силу"
4. SPEED (скорость) — если включена настройка "Пить Скорость"

---

### AutoSword — чтение реального атрибута урона
**Файл:** `modules/impl/AutoSword.java`

`findBestWeapon()` раньше хардкодил урон (4f для меча, 5f для топора),
из-за чего Diamond Sword ≡ Netherite Sword, а зачарование «Резкость 5»
игнорировалось.

Теперь читается `AttributeModifiersComponent` → `EntityAttributes.ATTACK_DAMAGE`
из компонентов предмета. При отсутствии компонента — безопасный fallback.

---

### EchoAura — оптимизация режима ByHP
**Файл:** `modules/impl/EchoAura.java`

В режиме `colorMode = "ByHP"` каждый тик делался полный обход `mc.world.getEntities()`.
При 500+ сущностях на сервере это заметная нагрузка.

Теперь используется `mc.world.getEntitiesByClass()` с bounding box радиуса
`(maxRadius + 2)` блоков — запрос к пространственному индексу, O(k) вместо O(n).

---

### ModuleManager.onRender — уважаем F1 (hudHidden)
**Файл:** `modules/ModuleManager.java`

HUD-элементы Enkuron рендерились даже при нажатом F1 (скрыть интерфейс).
Добавлена проверка `mc.options.hudHidden` в начале `onRender()`.

---

## Новые возможности

### ProfileScreen — экран управления профилями
**Файл:** `ui/ProfileScreen.java`

Новый экран для сохранения/загрузки/удаления именованных профилей конфигурации.
`ConfigManager` умел работать с профилями с v2.0, но GUI для этого отсутствовал.

**Открыть:** нажать `P` в меню Enkuron (Right Shift).

Функции:
- Список всех сохранённых профилей
- Загрузка профиля одним кликом
- Сохранение текущего конфига под новым именем (поле + Enter или кнопка)
- Удаление профиля кнопкой ×
- Статус-сообщения об успехе/ошибке

---

### EnkuronMenu — клавиша P для ProfileScreen
**Файл:** `ui/clickgui/EnkuronMenu.java`

Добавлен обработчик `GLFW_KEY_P` → открыть `ProfileScreen`.
Обновлён doc-комментарий с перечнем всех клавиш.

---

## Версия

`2.0.0` → `2.1.0`
