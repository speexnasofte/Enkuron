package com.pvpbot;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * NPC-бот: PathfinderMob с AI-целями.
 * v7: интеграция BotDifficultyAI — EASY/MEDIUM/HARD/EXPERT поведение.
 */
public class BotEntity extends PathfinderMob {

    // ── Глобальная заморозка (во время отсчёта дуэли) ────────────
    private static boolean globalFrozen = false;
    public static void setGlobalFrozen(boolean frozen) { globalFrozen = frozen; }
    public static boolean isGlobalFrozen() { return globalFrozen; }

    // ── AI Throttling — распределяем тики между ботами ────────────
    // Каждый бот тикает полную логику раз в aiTickInterval тиков.
    // Остальные тики — только физика и анимация (super.tick).
    // При <= 5 ботов: interval=1 (каждый тик), 6-15: interval=2, 16+: interval=3
    private static int  botCount       = 0;
    private static int  globalTickSeed = 0; // счётчик для распределения фаз
    private int         myTickPhase    = 0; // фаза этого бота (0..interval-1)
    private int         aiTickInterval = 1;
    private int         aiSkipCounter  = 0;

    public static void onBotSpawned()  { botCount++; recalcIntervals(); }
    public static void onBotRemoved()  { botCount = Math.max(0, botCount-1); recalcIntervals(); }
    public static int  getBotCount()   { return botCount; }

    private static void recalcIntervals() {
        // Пересчитываем интервал для всех — вызывается при спавне/удалении
        // Реальный пересчёт происходит в начале следующего tick() каждого бота
    }

    private int calcInterval() {
        // OptimizeMode — удваиваем интервал для снижения нагрузки
        boolean opt = PVPBotConfig.INSTANCE.optimizeMode;
        if (botCount <= 5)  return opt ? 2 : 1;   // ≤5  ботов
        if (botCount <= 10) return opt ? 4 : 2;   // ≤10 ботов
        if (botCount <= 18) return opt ? 6 : 3;   // ≤18 ботов
        return opt ? 8 : 4;                        // 19-25 ботов
    }


    private UUID ownerUUID = null;

    // v9: ник игрока чей скин носит бот (null = дефолт)
    private String skinNick = null;

    // FIX: per-bot сложность и режим — раньше использовался глобальный PVPBotConfig.INSTANCE,
    // из-за чего последний загрузившийся бот перетирал сложность/режим всех остальных.
    // null = использовать глобальный конфиг (обратная совместимость)
    private PVPBotConfig.Difficulty perBotDifficulty = null;
    private PVPBotConfig.Mode       perBotMode       = null;

    /** Возвращает сложность этого бота (per-bot если задана, иначе глобальная) */
    public PVPBotConfig.Difficulty getEffectiveDifficulty() {
        return perBotDifficulty != null ? perBotDifficulty : PVPBotConfig.INSTANCE.difficulty;
    }

    /** Возвращает режим этого бота (per-bot если задан, иначе глобальный) */
    public PVPBotConfig.Mode getEffectiveMode() {
        return perBotMode != null ? perBotMode : PVPBotConfig.INSTANCE.mode;
    }

    public void setPerBotDifficulty(PVPBotConfig.Difficulty d) { this.perBotDifficulty = d; }
    public void setPerBotMode(PVPBotConfig.Mode m)             { this.perBotMode = m; }
    public PVPBotConfig.Difficulty getPerBotDifficulty()       { return perBotDifficulty; }
    public PVPBotConfig.Mode       getPerBotMode()             { return perBotMode; }

    public enum BotMode { GUARD, AGGRESSIVE, PASSIVE }
    private BotMode mode = BotMode.GUARD;

    // ── Роль в отряде (назначается SquadManager при squad >= 20) ──
    private BotRole squadRole = BotRole.SOLDIER;

    public BotRole getSquadRole() { return squadRole; }
    public void setSquadRole(BotRole role) { this.squadRole = role; }

    // v7.0 — кулдауны ролей
    public int bowCooldown      = 0;  // SNIPER: тиков до выстрела
    public int sapperCooldown   = 0;  // SAPPER: тиков до закладки
    public int scoutReportTimer = 0;  // SCOUT: тиков до репорта
    public int medicHealCooldown = 0; // MEDIC: тиков до лечения
    public int medicBuffCooldown = MedicLogic.BUFF_INTERVAL; // MEDIC: тиков до глоб. баффа (стартует полным)

    private int  nameUpdateTimer = 0;
    private int  strafeDirTimer  = 0;
    private boolean strafeLeft   = true;

    // ── v7: AI сложности ──────────────────────────────────────────
    private final BotDifficultyAI difficultyAI = new BotDifficultyAI(this);
    public BotDifficultyAI getDifficultyAI() { return difficultyAI; }

    // ── v12: новые системы ────────────────────────────────────────
    private final StrafeAI      strafeAI      = new StrafeAI(this);
    private final PatternAI     patternAI     = new PatternAI(this);   // v14
    private final TargetPriority targetPriority = new TargetPriority(this);
    private final AutoRetreat   autoRetreat   = new AutoRetreat(this);

    /** Текущий кит бота. Сохраняется при ресете/ресрауне. */
    private BotKit currentKit = null;

    public BotKit getCurrentKit() { return currentKit; }
    public void setKit(BotKit kit) {
        this.currentKit = kit;
        if (kit != null) {
            kit.equipment.applyTo(this);
            // v18: синхронизируем конфиг чтобы NethPotLogic и другие логики видели кит
            PVPBotConfig.INSTANCE.currentKit = kit;
            // FIX: режим ставим per-bot, не глобально — иначе бот A перетирал режим бота B
            try {
                PVPBotConfig.Mode m = PVPBotConfig.Mode.valueOf(kit.id.toUpperCase());
                this.perBotMode = m; // только для этого бота
            } catch (IllegalArgumentException ignored) {
                // Нет точного совпадения — оставляем текущий режим
            }
        }
    }

    // ── v14: ComboBreaker + BotNotifier ──────────────────────────
    private final ComboBreaker  comboBreaker  = new ComboBreaker(this);
    private final BotNotifier   notifier      = BotNotifier.create(this);

    // ── v15: BotBunker ────────────────────────────────────────────
    private final BotBunker     bunker        = new BotBunker(this);

    // ── v17: StuckDetector + Squad ────────────────────────────────
    private final StuckDetector    stuckDetector    = new StuckDetector(this);
    public StuckDetector getStuckDetector() { return stuckDetector; }

    // ── FIX B (v1.6.1): TankMode per-bot state ───────────────────
    // Ранее TankMode.INSTANCE держал priorityTargetUUID/wasActive как поля синглтона —
    // первый бот сбрасывал их для всех остальных. Теперь каждый бот хранит своё состояние.
    public final TankMode.BotTankState tankState = new TankMode.BotTankState();

    // ── H: per-bot FightAnalyzer (для /bot top + фикс A) ─────────
    // Раньше использовался глобальный fightAnalyzer — данные смешивались.
    // Каждый бот теперь ведёт свою статистику боёв.
    private final FightAnalyzer fightAnalyzer = new FightAnalyzer();
    public FightAnalyzer getFightAnalyzer() { return fightAnalyzer; }

    // ── v16: AdaptiveCooldown + FakeAttack + BotHunt + BotReplay ─
    private final AdaptiveCooldown adaptiveCooldown = new AdaptiveCooldown(this);
    // ── Kite logic (серверная) ────────────────────────────────────
    private final BotKiteLogic     botKiteLogic     = new BotKiteLogic(this);
    // ── v1.2: PVPBotLogic переписан для NPC ──────────────────────
    private final PVPBotLogic          pvpLogic         = new PVPBotLogic(this);
    // v1.6.0 — AutoInventory для бота (серверный рефилл)
    private final AutoInventory        botAutoInventory  = new AutoInventory();
    private final ModeLogicDispatcher  modeDispatcher   = new ModeLogicDispatcher(this); // v18: fix kit logic
    // PATCH v2.1.0: использует предметы из инвентаря во всех режимах
    private final InventoryUseLogic    inventoryUseLogic = new InventoryUseLogic(this);
    private final FakeAttack           fakeAttack       = new FakeAttack(this);
    private final BotHunt          botHunt          = new BotHunt(this);
    private final BotReplay        replay           = new BotReplay(this);
    private BotPersonality.PersonalityState personalityState = null;           // v18: BotPersonality
    private float lastDamageTakenThisTick = 0f;                                // v18: для Personality berserk
    // Bot inventory (36 slots, like a player hotbar+main) — used by AutoPotionLogic, SmartWeaponSwitch, etc.
    private final SimpleContainer botInventory = new SimpleContainer(36);

    // ── v1.4.2: AutoPotionLogic ───────────────────────────────────
    private final AutoPotionLogic  autoPotionLogic  = new AutoPotionLogic(this);

    public SimpleContainer getInventory()    { return botInventory; }

    // ── Attack strength scale (mirrors Player#getAttackStrengthScale) ──
    // PathfinderMob doesn't have this; we track it via attackAnim (0..1).
    // attackAnim counts down from 1 to 0 after each swing; we invert so
    // 1.0 = fully charged, 0.0 = just attacked.
    public float getAttackStrengthScale(float adjustTicks) {
        // attackAnim (inherited from LivingEntity) goes 1→0 right after a swing.
        // We treat "not swinging" (attackAnim==0) as fully charged (1.0).
        float anim = this.attackAnim;
        return anim > 0f ? (1f - anim) : 1f;
    }
    public StrafeAI      getStrafeAI()      { return strafeAI; }
    public PatternAI     getPatternAI()     { return patternAI; }   // v14
    public TargetPriority getTargetPriority() { return targetPriority; }
    public AutoRetreat   getAutoRetreat()   { return autoRetreat; }
    public ComboBreaker  getComboBreaker()  { return comboBreaker; }  // v14
    public BotNotifier   getNotifier()      { return notifier; }      // v14
    public BotBunker     getBunker()        { return bunker; }        // v15
    public AdaptiveCooldown getAdaptiveCooldown() { return adaptiveCooldown; } // v16
    public BotKiteLogic    getBotKiteLogic()      { return botKiteLogic; }
    public PVPBotLogic     getPvpLogic()        { return pvpLogic; }         // v1.2
    public ModeLogicDispatcher getModeDispatcher() { return modeDispatcher; } // v18
    public FakeAttack    getFakeAttack()    { return fakeAttack; }    // v16
    public BotHunt       getBotHunt()       { return botHunt; }       // v16
    public BotReplay     getReplay()        { return replay; }        // v16
    public BotPersonality.PersonalityState getPersonalityState()  { return personalityState; }  // v18
    public void setPersonality(BotPersonality p) {
        personalityState = new BotPersonality.PersonalityState(p);
        BotPersonality.applyPersonality(this, p);
    }
    public AutoPotionLogic getAutoPotionLogic() { return autoPotionLogic; } // v1.4.2

    // ── v1.8.0: EnvironmentHazardAI ──────────────────────────────
    private final EnvironmentHazardAI hazardAI = new EnvironmentHazardAI(this);
    public EnvironmentHazardAI getHazardAI() { return hazardAI; }

    // ── v2.1.0: Per-bot DpsMeter, ReactionProfile, ArenaMode ────
    private final DpsMeter           dpsMeter       = new DpsMeter();
    private final BotReactionProfile reactionProfile = new BotReactionProfile(this);
    private final BotArenaMode       arenaMode       = new BotArenaMode(this);
    private final AutoRestock        autoRestock     = new AutoRestock(this);

    public DpsMeter           getDpsMeter()       { return dpsMeter; }
    public BotReactionProfile getReactionProfile() { return reactionProfile; }
    public BotArenaMode       getArenaMode()       { return arenaMode; }
    public AutoRestock        getAutoRestock()     { return autoRestock; }

    // ── v2.1.0: KillStreak, HeatMap, SmartWeaponSwitch ──────────
    private final KillStreak         killStreak        = new KillStreak(this);
    private final BotHeatMap         heatMap           = new BotHeatMap(this);
    private final SmartWeaponSwitch  smartWeaponSwitch = new SmartWeaponSwitch(this);

    public KillStreak        getKillStreak()       { return killStreak; }
    public BotHeatMap        getHeatMap()          { return heatMap; }
    public SmartWeaponSwitch getSmartWeaponSwitch() { return smartWeaponSwitch; }

    public BotEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
        this.setCanPickUpLoot(false);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH,          40.0)
            .add(Attributes.MOVEMENT_SPEED,       0.13)
            .add(Attributes.ATTACK_DAMAGE,        8.0)   // FIX v1.4: был 6.0 — поднимаем базовый урон
            .add(Attributes.FOLLOW_RANGE,        100.0)  // FIX: был 24.0 — теперь агрится на 100 блоков
            .add(Attributes.ARMOR,                0.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 0.0)
            .add(Attributes.ATTACK_KNOCKBACK,     0.4);  // FIX v1.4: небольшой отбрасыватель при ударе
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new BotHealGoal(this));
        goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.FloatGoal(this));
        // FIX v1.4: добавляем WaterAvoidingRandomStrollGoal для нормального поведения в воде
        goalSelector.addGoal(2, new BotCritMeleeGoal(this, 1.2, true));
        if (PVPBotConfig.INSTANCE.advPathfind) {
            goalSelector.addGoal(3, new BotPathfindGoal(this, 1.1, 64.0f, 3.0f));
        } else {
            goalSelector.addGoal(3, new BotFollowOwnerGoal(this, 1.1, 10.0f, 3.0f));
        }
        goalSelector.addGoal(4, new net.minecraft.world.entity.ai.goal.RandomStrollGoal(this, 0.8));
        goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(6, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new BotRevengeGoal(this));
        targetSelector.addGoal(2, new BotAttackHostilesGoal(this));
        targetSelector.addGoal(3, new BotAttackPlayersGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        // ── Заморозка во время отсчёта дуэли ─────────────────────
        if (globalFrozen) {
            getNavigation().stop();
            setDeltaMovement(0, getDeltaMovement().y, 0);
            return;
        }
        // ── FIX v1.4: Вода — бот всегда всплывает ────────────────
        // FloatGoal не всегда отрабатывает при AI-throttling, форсируем выплытие
        if (isInWater() && !onGround()) {
            double vy = getDeltaMovement().y;
            if (vy < 0.08) {
                setDeltaMovement(getDeltaMovement().x, Math.min(vy + 0.08, 0.2), getDeltaMovement().z);
            }
            setSprinting(false);
        }
        if (!level().isClientSide) {
            // ── AI Throttling ─────────────────────────────────────
            // Обновляем интервал раз в 40 тиков (при изменении числа ботов)
            if (tickCount % 40 == 0) {
                aiTickInterval = calcInterval();
                if (myTickPhase >= aiTickInterval) myTickPhase = tickCount % aiTickInterval;
            }
            // Пропускаем AI если сейчас не наш тик
            aiSkipCounter++;
            if (aiSkipCounter % aiTickInterval != myTickPhase) {
                // Только базовая физика — навигация продолжает двигать бота
                // по уже вычисленному пути, без пересчёта
                return;
            }

            // ── Обновление имени ──────────────────────────────────
            nameUpdateTimer--;
            if (nameUpdateTimer <= 0) {
                nameUpdateTimer = 20;
                updateNameTag();
                // Синхронизируем скорость и HP с настройками
                applySpeedAttribute();
                applyMaxHealth();
            }

            // ── v14: Тик уведомлений ──────────────────────────────
            notifier.tick();

            // ── v16: AdaptiveCooldown + Replay ────────────────────
            if (PVPBotConfig.INSTANCE.adaptiveCooldownEnabled) adaptiveCooldown.tick();
            // ── v17: StuckDetector + SmartFlank + Squad ───────────
            stuckDetector.tick();
            // ── v8: TeleportStuck ─────────────────────────────────
            if (TeleportStuck.INSTANCE.tick(this)) return; // застрял — телепортирован
            // ── v8: AutoChatTaunts тик кулдауна ──────────────────
            AutoChatTaunts.INSTANCE.tick();
            // ── v2.1.0: ReactionProfile + ArenaMode + AutoRestock ─
            reactionProfile.tick();
            autoRestock.tick();
            if (arenaMode.isEnabled()) {
                arenaMode.tick((ServerLevel) level(), getTarget());
            }
            // v2.1.0: BotTauntReact global tick (раз в N тиков)
            if (tickCount % 10 == 0) BotTauntReact.INSTANCE.tick();
            SmartFlank.INSTANCE.tick(this);
            // OPT v8: GappleOptimizer.globalTick() перенесён в ServerTickEvents (PVPBotMod)
            // ── Роль: тик специализированной логики ───────────────
            SquadManager.Squad roleSquad = SquadManager.INSTANCE.getSquadOf(this);
            switch (squadRole) {
                case MEDIC -> {
                    LivingEntity nearestForMedic = getTarget();
                    MedicLogic.INSTANCE.tick(this, roleSquad, nearestForMedic);
                }
                case SNIPER -> SniperLogic.INSTANCE.tick(this, getTarget());
                case SAPPER -> SapperLogic.INSTANCE.tick(this, getTarget());
                case SCOUT  -> {
                    Player scoutOwner = getOwner();
                    if (scoutOwner != null) ScoutLogic.INSTANCE.tick(this, scoutOwner);
                }
                default -> {} // SOLDIER, TANKER и т.д. — стандартный AI
            }
            // Squad Commander AI
            SquadManager.Squad mySquad = SquadManager.INSTANCE.getSquadOf(this);
            if (mySquad != null && this == mySquad.commander) {
                Player owner = getOwner();
                if (owner != null) SquadManager.INSTANCE.tickCommander(this, mySquad, owner);
            }

            replay.tick();
            // v18: BotPersonality tick
            if (personalityState != null) {
                personalityState.tick(this, getTarget(), lastDamageTakenThisTick);
                lastDamageTakenThisTick = 0f;
            }
            // v18: ReplaySystem tick
            LivingEntity _rsTarget = getTarget();
            String _rsAction = modeDispatcher != null ? modeDispatcher.getStatusLabel() : "IDLE";
            ReplaySystem.INSTANCE.tickBot(this, _rsTarget, _rsAction);

            // ── v16: BotHunt — охота на игроков ───────────────────
            if (PVPBotConfig.INSTANCE.huntEnabled && getTarget() == null) {
                botHunt.tick();
            }

            // ── v15: Pending co-owner add (из WebConfig) ──────────
            if (PVPBotConfig.INSTANCE.pendingCoOwnerAdd != null
                    && PVPBotConfig.INSTANCE.globalOwnerUUID != null
                    && level() instanceof net.minecraft.server.level.ServerLevel sw15) {
                net.minecraft.server.MinecraftServer ms = sw15.getServer();
                boolean added = MultiOwner.INSTANCE.addCoOwner(
                    PVPBotConfig.INSTANCE.globalOwnerUUID,
                    PVPBotConfig.INSTANCE.pendingCoOwnerAdd, ms);
                notifier.send(added
                    ? "§a✔ Совладелец добавлен: §f" + PVPBotConfig.INSTANCE.pendingCoOwnerAdd
                    : "§c✘ Игрок не найден: §f"    + PVPBotConfig.INSTANCE.pendingCoOwnerAdd);
                PVPBotConfig.INSTANCE.pendingCoOwnerAdd = null;
            }

            // ── v15: BotBunker ────────────────────────────────────
            if (PVPBotConfig.INSTANCE.bunkerEnabled && bunker.tick()) return;

            // ── v1.3: Standby режим — стоим в ряд до /bot attack ────
            if (PVPBotConfig.INSTANCE.standbyMode) {
                // В режиме ожидания: сбрасываем цель и стоим в построении
                if (getTarget() != null) setTarget(null);
                // Идём на позицию в построении
                Player owner = getOwner();
                if (owner != null) {
                    // FIX: safe cast — owner может быть не ServerPlayer в edge-cases
                    if (!(owner instanceof net.minecraft.server.level.ServerPlayer sp)) return;
                    var bots = SpawnBotCommand.getBotsFor(sp);
                    int idx = bots.indexOf(this);
                    int total = bots.size();
                    if (idx >= 0) {
                        net.minecraft.world.phys.Vec3 formPos =
                            BotFormations.INSTANCE.getTargetPos(this, idx, total, owner);
                        if (position().distanceTo(formPos) > 1.5) {
                            getNavigation().moveTo(formPos.x, formPos.y, formPos.z, 1.0);
                        }
                    }
                }
                return; // не тикаем AI атаки
            }

            // ── v1.6.0: AutoInventory — рефилл предметов бота ───
            botAutoInventory.tickBot(this);

            // ── v12: TargetPriority — умный выбор цели ───────────
            targetPriority.tick();

            // ── v14: PatternAI — обновление паттернов движения цели ──
            if (getTarget() != null && PVPBotConfig.INSTANCE.patternAIEnabled) {
                patternAI.update(getTarget());
            } else if (getTarget() == null) {
                patternAI.reset();
                fakeAttack.reset();  // FIX #4: сбрасываем fakeCooldown при потере цели
            }

            // ── v12: AutoRetreat ──────────────────────────────────
            boolean retreating = false;
            if (getTarget() != null) {
                retreating = autoRetreat.tick(getTarget());
            }

            // ── v12: Clone mode ───────────────────────────────────
            BotClone.INSTANCE.tick(this);

            // PATCH v2.1.0: использование предметов из инвентаря (паутина, лава, зелья, гэпл)
            inventoryUseLogic.tick(getTarget());

            // ── Страф + BotDifficultyAI во время боя ─────────────
            if (!retreating && getTarget() != null && getTarget().isAlive()) {
                // FIX: ThreatAssessment теперь вызывается внутри BotDifficultyAI.tick()
                // для всех уровней сложности — дублирующий вызов здесь убран.

                // v14: ComboBreaker — если под комбо, прерываем атаку
                if (comboBreaker.tick(getTarget())) return;

                // v16: FakeAttack тик (если активен — блокирует атаку на PAUSE_TICKS)
                if (fakeAttack.tick(getTarget())) return;

                // ── v14: TrainingMode ────────────────────────────────
                if (PVPBotConfig.INSTANCE.trainingMode) {
                    TrainingMode.INSTANCE.tick(this, getTarget());
                }

                // ── v1.6.0: TankMode — прёт напролом, игнорирует kite/retreat ──
                if (PVPBotConfig.INSTANCE.tankModeEnabled) {
                    TankMode.INSTANCE.tick(this, tankState);
                    replay.setAction("TANK"); // FIX #5: записываем фазу TANK в реплей
                } else {
                    // ── MERGED FIX: единственная точка входа в AI.
                    // difficultyAI.tick() уже содержит ModeLogicDispatcher внутри себя.
                    // strafeAI из BotEntity НЕ вызываем — каждая логика (SwordLogic и т.д.)
                    // имеет собственный StrafeAI и вызывает его сама. Иначе — двойной AI.
                    difficultyAI.tick(getTarget());
                }

                // ── v12: синхроатака ──────────────────────────────
                // OPT v8: перенесено в ServerTickEvents в PVPBotMod,
                // чтобы не вызывать N раз при N ботах одного владельца.
            }
        }
    }

    // OPT v8: кэш для имени — пересобираем только если что-то изменилось
    private int lastNameHp = -1;
    private BotMode lastNameMode = null;
    private PVPBotConfig.Difficulty lastNameDiff = null;
    // кеш nametag-флагов для немедленной реакции на изменения в GUI
    private int lastNameTagFlags = -1;

    private static int encodeNameTagFlags(PVPBotConfig cfg) {
        return (cfg.nameTagEnabled          ? 1 : 0)
             | (cfg.nameTagShowLabel        ? 2 : 0)
             | (cfg.nameTagShowMode         ? 4 : 0)
             | (cfg.nameTagShowDifficulty   ? 8 : 0)
             | (cfg.nameTagShowHp           ? 16 : 0);
    }

    private void updateNameTag() {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        int hp    = (int) getHealth();
        int maxHp = (int) getMaxHealth();
        int ntFlags = encodeNameTagFlags(cfg);

        // OPT: пропускаем если ничего не изменилось
        PVPBotConfig.Difficulty effectiveDiff = getEffectiveDifficulty();
        if (hp == lastNameHp
                && mode == lastNameMode
                && effectiveDiff == lastNameDiff
                && ntFlags == lastNameTagFlags) return;
        lastNameHp          = hp;
        lastNameMode        = mode;
        lastNameDiff        = effectiveDiff;
        lastNameTagFlags    = ntFlags;

        // Если nametag полностью выключен — скрываем имя
        if (!cfg.nameTagEnabled) {
            setCustomNameVisible(false);
            return;
        }

        StringBuilder name = new StringBuilder();

        // "PVP-Bot"
        if (cfg.nameTagShowLabel) {
            name.append("§ePVP-Bot ");
        }

        // [GUARD] / [AGRO] / [PASS]
        if (cfg.nameTagShowMode) {
            String modeStr = switch (mode) {
                case GUARD      -> "§a[GUARD]";
                case AGGRESSIVE -> "§c[AGRO]";
                case PASSIVE    -> "§7[PASS]";
                default         -> "§7[?]";
            };
            name.append(modeStr).append(" ");
        }

        // [EASY] / [MED] / [HARD] / [EXPERT]
        if (cfg.nameTagShowDifficulty) {
            String diffStr = switch (getEffectiveDifficulty()) {
                case EASY   -> "§7[EASY]";
                case MEDIUM -> "§e[MED]";
                case HARD   -> "§c[HARD]";
                case EXPERT -> "§4§l[EXPERT]";
                default     -> "§7[?]";
            };
            name.append(diffStr).append(" ");
        }

        // HP-бар + цифры
        if (cfg.nameTagShowHp) {
            String bar = buildHpBar(hp, maxHp);
            name.append(" ").append(bar).append(" §f").append(hp).append("§7/").append(maxHp);
        }

        String label = name.toString().trim();
        if (label.isEmpty()) {
            // Все компоненты выключены — скрываем
            setCustomNameVisible(false);
        } else {
            setCustomName(Component.literal(label));
            setCustomNameVisible(true);
        }
    }

    private String buildHpBar(int hp, int max) {
        if (max == 0) return "";
        int filled = Math.min(8, (int)(8.0 * hp / max));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i == filled) sb.append("§c");
            else if (i == 0) sb.append("§a");
            sb.append(i < filled ? "█" : "░");
        }
        return sb.toString();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag nbt) {
        super.addAdditionalSaveData(nbt);
        if (ownerUUID != null) nbt.putUUID("OwnerUUID", ownerUUID);
        nbt.putString("BotMode", mode.name());
        // FIX: сохраняем per-bot сложность (не глобальную)
        if (perBotDifficulty != null) nbt.putString("BotDifficulty", perBotDifficulty.name());
        if (perBotMode != null)       nbt.putString("BotPerMode", perBotMode.name());
        // v9: сохраняем ник скина
        if (skinNick != null) nbt.putString("SkinNick", skinNick);
        // FIX: сохраняем кит — без этого бот терял снаряжение при рестарте/выгрузке чанка
        if (currentKit != null) nbt.putString("BotKit", currentKit.name());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag nbt) {
        super.readAdditionalSaveData(nbt);
        if (nbt.hasUUID("OwnerUUID")) ownerUUID = nbt.getUUID("OwnerUUID");
        if (nbt.contains("BotMode")) {
            try { mode = BotMode.valueOf(nbt.getString("BotMode")); }
            catch (IllegalArgumentException ignored) { mode = BotMode.GUARD; }
        }
        // v7: восстанавливаем сложность из NBT и применяем
        // v9: восстанавливаем ник скина
        if (nbt.contains("SkinNick")) {
            skinNick = nbt.getString("SkinNick");
            // FIX: запускаем загрузку скина сразу при загрузке из NBT,
            // иначе бот будет Стивом пока рендерер не запросит скин первый раз
            if (!level().isClientSide && skinNick != null && !skinNick.isEmpty()) {
                com.pvpbot.BotSkinManager.INSTANCE.prefetch(skinNick);
            }
        }
        // FIX: восстанавливаем per-bot сложность — не трогаем глобальный конфиг
        if (nbt.contains("BotDifficulty")) {
            try { perBotDifficulty = PVPBotConfig.Difficulty.valueOf(nbt.getString("BotDifficulty")); }
            catch (IllegalArgumentException ignored) {}
        }
        if (nbt.contains("BotPerMode")) {
            try { perBotMode = PVPBotConfig.Mode.valueOf(nbt.getString("BotPerMode")); }
            catch (IllegalArgumentException ignored) {}
        }
        // FIX: восстанавливаем кит из NBT — без этого бот спавнился голым после рестарта
        if (nbt.contains("BotKit")) {
            try {
                BotKit kit = BotKit.valueOf(nbt.getString("BotKit"));
                setKit(kit);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    // ── API ───────────────────────────────────────────────────────
    public void setOwner(Player player) { this.ownerUUID = player.getUUID(); }
    public java.util.UUID getOwnerUUID() { return ownerUUID; }

    @Nullable
    public Player getOwner() {
        if (ownerUUID == null || !(level() instanceof ServerLevel sw)) return null;
        return sw.getPlayerByUUID(ownerUUID);
    }

    public BotMode getBotMode() { return mode; }

    // v9: скин
    public String getSkinNick() { return skinNick; }
    public void setSkinNick(String nick) { this.skinNick = nick; }

    public void setBotMode(BotMode m) {
        mode = m;
        setTarget(null);
        updateNameTag();
    }

    /** Применяет скорость движения из конфига сложности к атрибуту NPC. */
    public void applySpeedAttribute() {
        var speedAttr = this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.setBaseValue(PVPBotConfig.INSTANCE.diffMoveSpeed);
        }
    }

    public void applyMaxHealth() {
        var healthAttr = this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
        if (healthAttr != null) {
            float newMax = Math.max(1f, PVPBotConfig.INSTANCE.botMaxHealth);
            healthAttr.setBaseValue(newMax);
            // Если текущее HP выше нового максимума — подрезаем
            if (this.getHealth() > newMax) this.setHealth(newMax);
        }
    }

    public void cycleMode() {
        mode = switch (mode) {
            case GUARD      -> BotMode.AGGRESSIVE;
            case AGGRESSIVE -> BotMode.PASSIVE;
            case PASSIVE    -> BotMode.GUARD;
            default     -> null;
        };
        setTarget(null);
        updateNameTag();
    }

    public boolean isAlliedToCustom(net.minecraft.world.entity.Entity other) {
        if (other instanceof Player p && ownerUUID != null && p.getUUID().equals(ownerUUID)) return true;
        return super.isAlliedTo(other);
    }

    // isAffectedByDaylight removed in 1.21.4

    // ── v10: AntiKnockback ────────────────────────────────────────
    @Override
    public void knockback(double strength, double x, double z) {
        if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK)) {
            super.knockback(strength, x, z);
        } else {
            AntiKnockback.apply(this, strength, x, z);
        }
    }

    @Override
    public boolean canPickUpLoot() { return false; }

    @Override
    protected void dropEquipment(net.minecraft.server.level.ServerLevel serverLevel) {
        // FIX: дропаем вещи при смерти если включено в конфиге
        if (!PVPBotConfig.INSTANCE.dropLootOnDeath) return;
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            net.minecraft.world.item.ItemStack stack = getItemBySlot(slot);
            if (!stack.isEmpty()) {
                spawnAtLocation(serverLevel, stack);
                setItemSlot(slot, net.minecraft.world.item.ItemStack.EMPTY);
            }
        }
    }

    /** Броня видна с глинтом (зачарования отображаются) — дроп управляется через dropEquipment */
    @Override
    protected float getEquipmentDropChance(net.minecraft.world.entity.EquipmentSlot slot) {
        return PVPBotConfig.INSTANCE.dropLootOnDeath ? 1.0f : 0.0f;
    }

    // ── v1.3.2: Перехватываем нанесение урона — регистрируем подсветку в HUD ──
    @Override
    public boolean doHurtTarget(net.minecraft.server.level.ServerLevel level, net.minecraft.world.entity.Entity target) {
        boolean result = super.doHurtTarget(level, target);
        if (result) {
            // Уведомляем HitHighlightTracker чтобы HUD подсветил этого игрока
            HitHighlightTracker.INSTANCE.onHit(target.getId());
            // v2.1.0: HeatMap — записываем урон по позиции
            if (target instanceof net.minecraft.world.entity.LivingEntity le) {
                float dmg = (float) getAttributeValue(
                    net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
                heatMap.recordDamageDealt(position(), dmg);
                // KillStreak — проверяем смерть цели (HP <= 0 после удара)
                if (le.getHealth() <= 0) {
                    killStreak.onKill(le);
                    arenaMode.onBotKill();  // учитываем раунд
                    heatMap.recordKill(position());
                    // v2.1: ELO + AdaptiveDifficulty — победа бота
                    AdaptiveDifficulty.INSTANCE.updateElo(true, 1000f);
                    // FIX: recordBattle не вызывался нигде — AdaptiveDifficulty не работала!
                    Player own = getOwner();
                    if (own instanceof net.minecraft.server.level.ServerPlayer sp) {
                        AdaptiveDifficulty.INSTANCE.recordBattle(this, true, getHealth(),
                            fightAnalyzer.getFightDurationTicks(), sp);
                    }
                }
            }
        }
        return result;
    }

    // ── v14: damage override для ComboBreaker + BotNotifier ──────
    // Кастомная логика урона вызывается через Fabric Event или hurt-overide
    // В 1.21.4 hurt() - final, используем другой подход
    public void onHurtCustom(DamageSource source, float amount) {
        lastDamageTakenThisTick += amount; // v18: берсерк-триггер (moved from @Override hurt)
        comboBreaker.onDamageReceived(amount);
        // FightAnalyzer — трекинг полученного урона
        if (PVPBotConfig.INSTANCE.statsEnabled) {
            fightAnalyzer.onDamageTaken(amount);
        }
        // v2.1.0: HeatMap — записываем полученный урон
        heatMap.recordDamageTaken(position(), amount);
        // Уведомление при низком HP
        float hp = getHealth();
        if (hp < 10.0f && hp > 0) {
            notifier.onLowHp();
            AutoChatTaunts.INSTANCE.onLowHp(this); // v8: чат-сообщение при низком HP
        }
        // Тотем-попап: HP упало до 1 или ниже и тотем в оффхенде
        if (hp <= 1.0f && PVPBotConfig.INSTANCE.statsEnabled) {
            var offhand = getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND);
            if (offhand.is(net.minecraft.world.item.Items.TOTEM_OF_UNDYING)) {
                fightAnalyzer.onTotemPop();
            }
        }
    }


    @Override
    public void die(DamageSource damageSource) {
        super.die(damageSource);
        ReplaySystem.INSTANCE.onBotRemoved(this); // v18
        // FIX: botCount не уменьшался при естественной смерти — throttle ломался
        BotEntity.onBotRemoved();
        // Уведомление о смерти
        net.minecraft.world.entity.Entity killer = damageSource.getEntity();
        notifier.onDeath(killer instanceof LivingEntity le ? le : null);
        // v8: AutoChatTaunts — бот убил кого-то (это вызывается у ЖЕРТВЫ,
        // поэтому taunt при убийстве обрабатывается в KillDeathTracker)

        // FIX A: закрыть активный бой с проигрышем.
        // Раньше active оставался true и следующий бой накапливал
        // статистику поверх старого — история портилась.
        if (fightAnalyzer.isActive()) {
            fightAnalyzer.onFightEnd(fightAnalyzer.getTarget(), false);
        }
        // v2.1.0: сброс per-bot состояния при смерти
        reactionProfile.reset();
        dpsMeter.reset();
        arenaMode.onBotDeath();  // учитываем раунд в ArenaMode
        autoRestock.reset();
        killStreak.onDeath();    // прерываем серию
        heatMap.recordDeath(position()); // записываем позицию смерти
        AdaptiveDifficulty.INSTANCE.updateElo(false, 1000f); // v2.1: ELO поражение
        // FIX: передаём поражение AdaptiveDifficulty для per-bot авто-адаптации
        Player ownD = getOwner();
        if (ownD instanceof net.minecraft.server.level.ServerPlayer spD) {
            AdaptiveDifficulty.INSTANCE.recordBattle(this, false, 0f,
                fightAnalyzer.getFightDurationTicks(), spD);
        }
        smartWeaponSwitch.reset();
        fakeAttack.reset();      // FIX #4: сбрасываем fakeCooldown при смерти
    }

    /** Публичная обёртка над protected setSharedFlag(7, ...) — управление полётом элитры. */
    public void setElytraFlying(boolean flying) {
        setSharedFlag(7, flying);
    }
}
