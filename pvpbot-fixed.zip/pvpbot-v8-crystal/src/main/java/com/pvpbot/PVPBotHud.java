package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;
import net.minecraft.client.DeltaTracker;

/**
 * PVPBotHud v9 — добавлено:
 *   ✅ Вкл/выкл HUD кнопкой [H]
 *   ✅ Drag-and-drop: зажать ЛКМ по панели → перетащить куда угодно
 *   ✅ Кнопка [⚡OPT] — включает OptimizeMode (отключает ESP/Blur, throttle AI)
 *   ✅ Кэш findNearest() в OptimizeMode (не ищем каждый кадр)
 *   ✅ Tooltip-подсказки при наведении на кнопки
 */
public class PVPBotHud implements HudRenderCallback {

    private final PVPBotConfig  cfg     = PVPBotConfig.INSTANCE;
    private final ModuleManager modules = ModuleManager.INSTANCE;

    // ── Drag state ──────────────────────────────────────────────
    private boolean dragging     = false;
    private int     dragOffsetX  = 0;
    private int     dragOffsetY  = 0;

    // Размеры панели (вычисляются при рендере)
    private int panelX  = 6;
    private int panelY  = 6;
    private static final int PANEL_W = 144;

    // ── Optimize cache ──────────────────────────────────────────
    private LivingEntity cachedTarget    = null;
    private int          cacheAge        = 0;
    private static final int CACHE_TTL   = 10; // тиков

    // ── Кнопки в шапке (координаты — относительные к panelX/Y) ─
    // [H] toggle HUD expand, [⚡] toggle optimize
    private static final int BTN_SIZE = 9;

    // ============================================================

    @Override
    public void onHudRender(GuiGraphics ctx, DeltaTracker ticker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // Разрешаем обрабатывать Mouse click/drag через статический
        // Mouse-листенер, зарегистрированный в PVPBotMod.
        // Здесь только рисуем.

        // Если HUD полностью скрыт — не рисуем ничего
        if (!cfg.showHud) {
            renderMiniToggle(ctx, mc);
            return;
        }

        // Позиция: если не задана пользователем — дефолт (6, 6)
        if (cfg.hudX < 0) cfg.hudX = 6;
        if (cfg.hudY < 0) cfg.hudY = 6;

        panelX = cfg.hudX;
        panelY = cfg.hudY;

        int x  = panelX + 2;
        int y  = panelY;
        int lh = 10;

        boolean isCrystal = cfg.mode == PVPBotConfig.Mode.CRYSTAL;

        // FIX #2: панель расширяется если показана строка Tank/Refill
        boolean showTankRow = cfg.tankModeEnabled || cfg.autoRefill || cfg.botAutoRefill;
        int panelH = lh * 13 + 14 + (showTankRow ? lh : 0);

        // ── Иконка и цвет полоски по китам mctiers.com ───────────
        String kitIconId;
        int topColor;
        switch (cfg.mode) {
            case UHC -> { kitIconId = "kit_uhc";     topColor = 0xFFCC2222; }
            case NETHOP, NETHPOT -> { kitIconId = "kit_nethop"; topColor = 0xFF9933CC; }
            case SMP  -> { kitIconId = "kit_smp";    topColor = 0xFF1A8040; }
            case POT  -> { kitIconId = "kit_pot";    topColor = 0xFFCC44BB; }
            case CRYSTAL -> { kitIconId = "kit_crystal"; topColor = 0xFF00CFFF; }
            case MACE, MACE_ELYTRA -> { kitIconId = "kit_mace"; topColor = 0xFF888888; }
            case AXE  -> { kitIconId = "kit_axe";    topColor = 0xFF4499CC; }
            case TPC  -> { kitIconId = "kit_tpc";    topColor = 0xFF00CFFF; }
            case TOTEM -> { kitIconId = "kit_uhc";   topColor = 0xFFCC2222; }
            case TRIDENT -> { kitIconId = "kit_trident"; topColor = 0xFF3388FF; }
            case CROSSBOW -> { kitIconId = "kit_crossbow"; topColor = 0xFF3388FF; }
            case SNOWBALL -> { kitIconId = "kit_snowball"; topColor = 0xFF88AACC; }
            default -> { kitIconId = "kit_sword";    topColor = 0xFF3388FF; }
        }
        String modeName = cfg.mode.name();

        // FIX v1.3.6: топ-полоска HUD берёт цвет из colorTheme
        topColor = cfg.colorTheme.accent;

        // Фон + цветная полоска сверху
        ctx.fill(panelX - 1, panelY - 1, panelX + PANEL_W, panelY + panelH, 0x88000000);
        ctx.fill(panelX - 1, panelY - 1, panelX + PANEL_W, panelY + 1, topColor);

        // ── Заголовок: иконка PNG + название кита + профиль ──────
        com.pvpbot.gui.render.IconRenderer.draw(ctx, kitIconId, x, y, 9);
        String profile = "§8[" + modules.getActiveProfile() + "]";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§fPVPBot §7" + modeName + " " + profile),
            x + 11, y, 0xFFFFFF, true);

        // Кнопка [⚡] Optimize (справа в заголовке)
        int optBtnX = panelX + PANEL_W - BTN_SIZE - 2;
        int optBtnY = y;
        boolean optOn = cfg.optimizeMode;
        int optBg  = optOn ? 0xFF1A4020 : 0xFF2A2010;
        int optFg  = optOn ? 0xFF22EE66 : 0xFFCCAA00;
        ctx.fill(optBtnX - 1, optBtnY - 1, optBtnX + BTN_SIZE + 1, optBtnY + BTN_SIZE, optBg);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(optOn ? "§a⚡" : "§6⚡"),
            optBtnX, optBtnY, optFg, false);

        // Кнопка [✕] скрыть HUD (правее ⚡)
        int hideBtnX = optBtnX - BTN_SIZE - 3;
        int hideBtnY = y;
        ctx.fill(hideBtnX - 1, hideBtnY - 1, hideBtnX + BTN_SIZE + 1, hideBtnY + BTN_SIZE, 0xFF2A0A0A);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§c✕"),
            hideBtnX, hideBtnY, 0xFFEF4444, false);

        y += lh + 1;

        // ── Статус + число ботов + AI throttle ──────────────────
        String status = cfg.enabled ? "§aВКЛЮЧЁН" : "§cВЫКЛЮЧЕН";
        int bots = BotEntity.getBotCount();
        int throttleTick = cfg.optimizeMode
            ? (bots <= 5 ? 4 : bots <= 10 ? 6 : 8)
            : (bots <= 5 ? 1 : bots <= 10 ? 2 : bots <= 18 ? 3 : 4);
        String throttleInfo = (bots > 5 || cfg.optimizeMode)
            ? " §8[AI/" + throttleTick + "t]" : "";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(
                "§7Статус: " + status + " §8| §7Ботов: §f" + bots + "/" + cfg.maxBots + throttleInfo
            ), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Сложность ────────────────────────────────────────────
        String diff = switch (cfg.difficulty) {
            case EASY   -> "§a★☆☆☆ Лёгкая";
            case MEDIUM -> "§e★★☆☆ Средняя";
            case HARD   -> "§c★★★☆ Сложная";
            case EXPERT -> "§4★★★★ EXPERT";
            default     -> "?";
        };
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§7Сложность: " + diff), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Тема (colorTheme) ─────────────────────────────────────
        String themeStr = "§7Тема: §r" + cfg.colorTheme.name;
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(themeStr), x, y, cfg.colorTheme.light, true);
        y += lh;
        String atk  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ATTACK))  + "§7Атк ";
        String dge  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_DODGE))   + "§7Укл ";
        String heal = icon(modules.isEnabled(ModuleManager.MOD_AUTO_HEAL))    + "§7Леч ";
        String gap  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_GAP))     + "§7Gap";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(atk + dge + heal + gap), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 2: Броня, Тотем, Еда ──────────────────────────
        String armor  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ARMOR))  + "§7Броня ";
        String totem  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_TOTEM))  + "§7Тотем ";
        String eat    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_EAT))    + "§7Еда";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(armor + totem + eat), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 3: W-Tap, Спринт, ESP, Radar ─────────────────
        String wtap   = icon(modules.isEnabled(ModuleManager.MOD_W_TAP))       + "§7W-Tap ";
        String sprint = icon(modules.isEnabled(ModuleManager.MOD_AUTO_SPRINT)) + "§7Спр ";
        // В OptimizeMode ESP всегда выключен
        String espStr = cfg.optimizeMode
            ? "§c✘§7ESP "
            : icon(modules.isEnabled(ModuleManager.MOD_ESP)) + "§7ESP ";
        String radar  = icon(modules.isEnabled(ModuleManager.MOD_RADAR))       + "§7Radar";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(wtap + sprint + espStr + radar), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 4: Bow, Kite, Crystal, WL ────────────────────
        String bow    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_BOW))    + "§7Bow ";
        String kite   = icon(modules.isEnabled(ModuleManager.MOD_KITE))        + "§7Kite ";
        String crys   = isCrystal ? icon(modules.isEnabled(ModuleManager.MOD_CRYSTAL)) + "§7Крист " : "";
        String wl     = cfg.whitelistEnabled ? "§a[WL:" + cfg.whitelist.size() + "]" : "§8[WL]";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(bow + kite + crys + wl), x, y, 0xFFFFFF, true);
        y += lh + 2;

        // ── Строка 5: Tank Mode / AutoRefill статус ─────────────
        if (cfg.tankModeEnabled || cfg.autoRefill || cfg.botAutoRefill) {
            String tank   = cfg.tankModeEnabled ? "§c§l🛡TANK " : "";
            String refill = cfg.autoRefill      ? "§a🎒Refill " : "";
            String botRef = cfg.botAutoRefill   ? "§5🤖BotRef" : "";
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(tank + refill + botRef), x, y, 0xFFFFFF, true);
            y += lh;
        }

        // Разделитель
        ctx.fill(x, y, x + 131, y + 1, 0x55FFFFFF);
        y += 4;

        // ── K/D статистика ───────────────────────────────────────
        if (cfg.statsEnabled) {
            double kd = KillDeathTracker.deaths == 0
                ? KillDeathTracker.kills
                : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(
                    "§aK:§f" + KillDeathTracker.kills +
                    " §cD:§f" + KillDeathTracker.deaths +
                    " §eA:§f" + KillDeathTracker.assists +
                    " §6KD:§f" + String.format("%.1f", kd)
                ), x, y, 0xFFFFFF, true);
            y += lh;
        }

        // ── Список ближайших игроков с подсветкой при ударе ─────
        {
            java.util.List<net.minecraft.world.entity.player.Player> nearbyPlayers =
                mc.level.getEntitiesOfClass(
                    net.minecraft.world.entity.player.Player.class,
                    mc.player.getBoundingBox().inflate(32.0),
                    p -> p != mc.player && p.isAlive()
                );
            // Сортируем: сначала подсвеченные (кого недавно ударили), потом по дистанции
            nearbyPlayers.sort((a, b) -> {
                boolean ha = HitHighlightTracker.INSTANCE.isHighlighted(a.getId());
                boolean hb = HitHighlightTracker.INSTANCE.isHighlighted(b.getId());
                if (ha != hb) return ha ? -1 : 1;
                return Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b));
            });

            int maxShow = Math.min(nearbyPlayers.size(), 5);
            if (maxShow > 0) {
                // Разделитель
                ctx.fill(x, y, x + 131, y + 1, 0x55FFFFFF);
                y += 3;
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal("§8Игроки рядом:"),
                    x, y, 0x888888, false);
                y += lh;

                for (int i = 0; i < maxShow; i++) {
                    net.minecraft.world.entity.player.Player p = nearbyPlayers.get(i);
                    boolean highlighted = HitHighlightTracker.INSTANCE.isHighlighted(p.getId());
                    float alpha = HitHighlightTracker.INSTANCE.getHighlightAlpha(p.getId());

                    // Пульсирующий фон при подсветке (fade-out)
                    if (highlighted) {
                        int bgAlpha = (int)(alpha * 0xAA);
                        int bgColor = (bgAlpha << 24) | 0x8B1A1A; // тёмно-красный с прозрачностью
                        ctx.fill(x - 2, y - 1, x + 131, y + lh - 1, bgColor);
                        // Яркая полоска слева — индикатор удара
                        int barAlpha = (int)(alpha * 0xFF);
                        int barColor = (barAlpha << 24) | 0xFF3333;
                        ctx.fill(x - 2, y - 1, x - 1, y + lh - 1, barColor);
                    }

                    String pName = p.getName().getString();
                    if (pName.length() > 11) pName = pName.substring(0, 11) + "…";
                    int hp    = (int) p.getHealth();
                    int maxHp = (int) p.getMaxHealth();
                    double dist = mc.player.distanceTo(p);

                    String nameColor = highlighted ? "§c" : "§f";
                    String hpColor   = hp > maxHp * 0.5 ? "§a" : hp > maxHp * 0.25 ? "§e" : "§c";
                    String hitTag    = highlighted ? " §c⚔" : "";

                    ctx.drawString(mc.font,
                        net.minecraft.network.chat.Component.literal(
                            nameColor + pName + " " + hpColor + hp + "§7/" + maxHp +
                            " §8(" + String.format("%.0f", dist) + "м)" + hitTag
                        ), x, y, 0xFFFFFF, true);
                    y += lh;
                }
            }
        }

        // ── Цель (с кэшем в OptimizeMode) ───────────────────────
        LivingEntity target = getTarget(mc);
        if (target != null) {
            double dist = mc.player.distanceTo(target);
            String name = target.getName().getString();
            if (name.length() > 13) name = name.substring(0, 13) + "…";
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§cЦель: §f" + name), x, y, 0xFFFFFF, true);
            y += lh;

            int hp    = (int) target.getHealth();
            int maxHp = (int) target.getMaxHealth();

            if (cfg.showDps) {
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal(DpsMeter.INSTANCE.getFormatted()
                        + "  §cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF, true);
            } else {
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal("§cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF, true);
            }
            y += lh;

            // HP-бар
            int barW  = 131;
            float ratio = (float) hp / maxHp;
            ctx.fill(x, y, x + barW, y + 3, 0xFF550000);
            ctx.fill(x, y, x + (int)(barW * ratio), y + 3,
                ratio > 0.5f ? 0xFF00CC44 : ratio > 0.25f ? 0xFFFFAA00 : 0xFFFF2222);
        } else {
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§7Цель: нет"), x, y, 0xFFFFFF, true);
            y += lh;
        }

        // ── v1.6.8: Строка AI-переключателей (terrain / threat / pattern / REC) ─
        renderAiStatusRow(ctx, mc, x, y);
        y += lh + 2;

        // ── v2.1.0: KillStreak строка (если серия > 0) ───────────
        BotEntity nearestBot = findNearestBotForHud(mc);
        if (nearestBot != null) {
            KillStreak ks = nearestBot.getKillStreak();
            if (ks.getCurrent() >= 2) {
                String streakColor = ks.getCurrent() >= 10 ? "§4" : ks.getCurrent() >= 5 ? "§c" : "§e";
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal(
                        "§7Серия: " + streakColor + "×" + ks.getCurrent()
                        + " §7Рекорд: §6" + ks.getBest()),
                    x, y, 0xFFFFFF, true);
                y += lh;
            }
            // Arena mode счёт
            BotArenaMode arena = nearestBot.getArenaMode();
            if (arena.isEnabled()) {
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal(
                        "§7Arena: §a" + arena.getBotWins() + "W §c" + arena.getBotLosses() + "L"),
                    x, y, 0xFFFFFF, true);
                y += lh;
            }
        }

        // ── Подсказка клавиш ─────────────────────────────────────
        String optHint = cfg.optimizeMode ? " §a[⚡OPT]" : "";
        // FIX #9 / v1.6.8: REC индикатор — per-owner, не глобальный
        boolean anyRecording = !BotLearning.recordingOwners().isEmpty();
        String recHint = anyRecording ? "  §c● REC" : "";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§8[R] вкл  [G] настройки  [H] HUD" + optHint + recHint),
            x, y, 0x888888, true);

        // ── OPT индикатор (если включён) ────────────────────────
        if (cfg.optimizeMode) {
            ctx.fill(panelX - 1, panelY + panelH - 2, panelX + PANEL_W, panelY + panelH, 0xFF1A8040);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§a⚡ OPTIMIZE ON"),
                x, panelY + panelH - 10, 0xFF22EE66, false);
        }

        // ── Дуэль оверлей ────────────────────────────────────────
        renderDuelOverlay(ctx, mc);
        renderWaveDefenseHud(ctx, mc);
    }

    /** Найти ближайшего бота (для отображения streak/arena в HUD). */
    private BotEntity findNearestBotForHud(Minecraft mc) {
        if (mc.level == null || mc.player == null) return null;
        return mc.level.getEntitiesOfClass(BotEntity.class,
            mc.player.getBoundingBox().inflate(128))
            .stream()
            .min(java.util.Comparator.comparingDouble(b -> b.distanceTo(mc.player)))
            .orElse(null);
    }

    /**
     * Маленькая кнопка [H] когда HUD скрыт — чтобы можно было вернуть.
     */
    private void renderMiniToggle(GuiGraphics ctx, Minecraft mc) {
        ctx.fill(2, 2, 26, 13, 0xAA000000);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§8[H]"),
            4, 4, 0x666666, false);
    }

    // ── Drag поддержка (вызывается из PVPBotMod) ────────────────

    /** Вызывается при нажатии ЛКМ. Возвращает true если попали по панели. */
    public boolean onMousePressed(double mx, double my) {
        if (!cfg.showHud) return false;
        if (insidePanel(mx, my)) {
            dragging    = true;
            dragOffsetX = (int) mx - panelX;
            dragOffsetY = (int) my - panelY;
            return true;
        }
        return false;
    }

    /** Вызывается при отпускании ЛКМ. */
    public void onMouseReleased(double mx, double my) {
        if (dragging) {
            dragging = false;
            BotConfig.save();
        }
        // Проверяем клик по кнопкам если не драг
        checkButtonClick(mx, my);
    }

    /** Вызывается при движении мыши с зажатой ЛКМ. */
    public void onMouseDragged(double mx, double my) {
        if (!dragging) return;
        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        int newX = (int) mx - dragOffsetX;
        int newY = (int) my - dragOffsetY;

        // Не даём улететь за границы экрана
        newX = Math.max(0, Math.min(newX, sw - PANEL_W));
        newY = Math.max(0, Math.min(newY, sh - 30));

        cfg.hudX = newX;
        cfg.hudY = newY;
    }

    /**
     * Клик по кнопкам [⚡] и [✕].
     */
    private void checkButtonClick(double mx, double my) {
        if (!cfg.showHud) {
            // Клик по мини-[H]
            if (mx >= 2 && mx <= 26 && my >= 2 && my <= 13) {
                cfg.showHud = true;
                BotConfig.save();
            }
            return;
        }

        int y0 = panelY;

        // Кнопка [⚡] Optimize
        int optBtnX = panelX + PANEL_W - BTN_SIZE - 2;
        if (mx >= optBtnX - 1 && mx <= optBtnX + BTN_SIZE + 1
                && my >= y0 - 1 && my <= y0 + BTN_SIZE) {
            cfg.optimizeMode = !cfg.optimizeMode;
            // Применяем оптимизации сразу
            if (cfg.optimizeMode) {
                cfg.espEnabled  = false;
            }
            BotConfig.save();
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.gui.getChat().addMessage(net.minecraft.network.chat.Component.literal(
                    cfg.optimizeMode
                        ? "§a[PVPBot] §fOptimize ON — ESP выключен, AI throttle x" + (cfg.maxBots <= 5 ? 4 : 6)
                        : "§e[PVPBot] §fOptimize OFF — настройки восстановлены"
                ));
            }
            return;
        }

        // Кнопка [✕] скрыть HUD
        int hideBtnX = optBtnX - BTN_SIZE - 3;
        if (mx >= hideBtnX - 1 && mx <= hideBtnX + BTN_SIZE + 1
                && my >= y0 - 1 && my <= y0 + BTN_SIZE) {
            cfg.showHud = false;
            BotConfig.save();
        }
    }

    private boolean insidePanel(double mx, double my) {
        return mx >= panelX - 1 && mx <= panelX + PANEL_W
            && my >= panelY - 1 && my <= panelY + 30; // только по шапке для drag
    }

    // ── Target cache (OptimizeMode) ──────────────────────────────

    private LivingEntity getTarget(Minecraft mc) {
        if (cfg.optimizeMode) {
            cacheAge++;
            if (cachedTarget == null || !cachedTarget.isAlive() || cacheAge >= CACHE_TTL) {
                cachedTarget = findNearest(mc);
                cacheAge     = 0;
            }
            return cachedTarget;
        }
        return findNearest(mc);
    }

    private LivingEntity findNearest(Minecraft mc) {
        if (mc.player == null || mc.level == null) return null;
        double range = cfg.optimizeMode ? 12.0 : 16.0;
        AABB box = mc.player.getBoundingBox().inflate(range);
        List<LivingEntity> list = mc.level.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != mc.player && e.isAlive() && !e.isInvisible()
        );
        return list.stream()
            .min(Comparator.comparingDouble(mc.player::distanceTo))
            .orElse(null);
    }

    private String icon(boolean on) { return on ? "§a✔" : "§c✘"; }

    // ══════════════════════════════════════════════════════════════
    //  WaveDefense — HUD волн (v1.6.0)
    // ══════════════════════════════════════════════════════════════
    private void renderWaveDefenseHud(GuiGraphics ctx, Minecraft mc) {
        WaveDefense wd = WaveDefense.INSTANCE;
        if (!wd.isActive()) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int cx = sw / 2;

        int wave      = wd.getCurrentWave();
        int total     = wd.getTotalWaves();
        int kills     = wd.getTotalKills();
        int enemies   = wd.getEnemiesAlive();
        int timerSecs = Math.max(0, (wd.getWaveInterval() - wd.getWaveTimer()) / 20);

        // ── Верхняя плашка: "Волна 3/10" ──
        String waveStr  = "§c⚔ §fВолна §c" + wave + " §f/ " + total;
        String killStr  = "§aУбийств: §f" + kills;
        String enemyStr = "§cВрагов: §f" + enemies;
        String nextStr  = enemies == 0 ? "§e⏱ Следующая: §f" + timerSecs + "с" : "";

        int boxW = 140, boxH = enemies == 0 ? 52 : 42;
        int bx   = cx - boxW / 2;
        int by   = 8;

        // Фон
        ctx.fill(bx - 2, by - 2, bx + boxW + 2, by + boxH + 2, 0xCC000000);
        ctx.fill(bx - 2, by - 2, bx + boxW + 2, by, 0xFF_EF4444); // красная полоска сверху

        // Текст
        int ty = by + 4;
        ctx.drawString(mc.font, net.minecraft.network.chat.Component.literal(waveStr),
            bx + boxW / 2 - mc.font.width(waveStr.replaceAll("§.", "")) / 2, ty, 0xFFFFFF, true);
        ty += 11;
        ctx.drawString(mc.font, net.minecraft.network.chat.Component.literal(killStr + "  " + enemyStr),
            bx + 4, ty, 0xFFFFFF, true);
        ty += 11;

        // Прогресс-бар волны
        int barW = boxW - 8;
        float progress = (float) wd.getWaveTimer() / wd.getWaveInterval();
        ctx.fill(bx + 4, ty, bx + 4 + barW, ty + 4, 0xFF_334155);
        ctx.fill(bx + 4, ty, bx + 4 + (int)(barW * progress), ty + 4, 0xFF_22C55E);
        ty += 8;

        if (enemies == 0 && !nextStr.isEmpty()) {
            ctx.drawString(mc.font, net.minecraft.network.chat.Component.literal(nextStr),
                bx + 4, ty, 0xFFFFFF, true);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Дуэль — оверлей в MCTiers стиле
    // ══════════════════════════════════════════════════════════════
    private void renderDuelOverlay(GuiGraphics ctx, Minecraft mc) {
        DuelTimer duel = DuelTimer.INSTANCE;
        if (!duel.isActive() && duel.getPhase() == DuelTimer.Phase.IDLE) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int cx = sw / 2;

        int botScore    = duel.getBotScore();
        int playerScore = duel.getPlayerScore();
        String scoreStr = botScore + " - " + playerScore;

        ctx.pose().pushPose();
        ctx.pose().scale(2.5f, 2.5f, 1f);
        int scoreW = mc.font.width(scoreStr);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§c" + botScore + " §f- §a" + playerScore),
            (int)((cx - scoreW * 2.5f / 2f) / 2.5f),
            (int)((sh * 0.12f) / 2.5f),
            0xFFFFFF, true);
        ctx.pose().popPose();

        String roundStr = "Round " + duel.getCurrentRound() + " / " + duel.getTotalRounds();
        int roundW = mc.font.width(roundStr);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§7" + roundStr),
            cx - roundW / 2,
            (int)(sh * 0.12f) + 22,
            0x888888, true);

        if (duel.isCountdown()) {
            int secs = duel.getCountdownSecs();
            String cd      = String.valueOf(secs);
            String cdColor = secs <= 1 ? "§c" : secs <= 2 ? "§e" : "§a";

            // Полное затемнение экрана
            ctx.fill(0, 0, sw, sh, 0xAA000000);

            // Цифра обратного отсчёта — рисуем НЕПРОЗРАЧНЫЙ фон под ней
            // чтобы предыдущие цифры не просвечивали
            float scale = 5f;
            int cdW = mc.font.width(cd);
            int cdH = mc.font.lineHeight;
            int cdPixW = (int)(cdW  * scale);
            int cdPixH = (int)(cdH  * scale);
            int cdX    = cx - cdPixW / 2;
            int cdY    = sh / 2 - cdPixH / 2 - 20;
            // Чёрный фон с запасом — полностью перекрывает прошлую цифру
            ctx.fill(cdX - 16, cdY - 10, cdX + cdPixW + 16, cdY + cdPixH + 10, 0xFF000000);

            ctx.pose().pushPose();
            ctx.pose().scale(scale, scale, 1f);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(cdColor + "§l" + cd),
                (int)((cx - cdW * scale / 2f) / scale),
                (int)((sh / 2f - 20f) / scale),
                0xFFFFFF, false); // false = без тени (тень тоже накапливается)
            ctx.pose().popPose();

            String rdLabel = "Round " + duel.getCurrentRound() + " / " + duel.getTotalRounds();
            int rdW = mc.font.width(rdLabel);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§f" + rdLabel),
                cx - rdW / 2, sh / 2 + 35, 0xFFFFFF, true);

            String scLabel = "§c" + botScore + " §7- §a" + playerScore;
            int scW = mc.font.width(scLabel);
            ctx.pose().pushPose();
            ctx.pose().scale(1.8f, 1.8f, 1f);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(scLabel),
                (int)((cx - scW * 1.8f / 2f) / 1.8f),
                (int)((sh / 2f + 50f) / 1.8f),
                0xFFFFFF, true);
            ctx.pose().popPose();
        }

        if (duel.getPhase() == DuelTimer.Phase.FINISHED) {
            ctx.fill(0, 0, sw, sh, 0x88000000);

            boolean botWon = duel.getBotScore() > duel.getPlayerScore();
            boolean draw   = duel.getBotScore() == duel.getPlayerScore();

            String result     = draw ? "§e§lDRAW" : botWon ? "§c§lYOU LOSE" : "§a§lYOU WIN";
            String finalScore = "§c" + duel.getBotScore() + " §f- §a" + duel.getPlayerScore();

            ctx.pose().pushPose();
            ctx.pose().scale(3f, 3f, 1f);
            int rW = mc.font.width(result.replaceAll("§.", ""));
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(result),
                (int)((cx - rW * 3f / 2f) / 3f),
                (int)((sh / 2f - 25f) / 3f),
                0xFFFFFF, true);
            ctx.pose().popPose();

            ctx.pose().pushPose();
            ctx.pose().scale(2f, 2f, 1f);
            int fsW = mc.font.width(finalScore.replaceAll("§.", ""));
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(finalScore),
                (int)((cx - fsW * 2f / 2f) / 2f),
                (int)((sh / 2f + 15f) / 2f),
                0xFFFFFF, true);
            ctx.pose().popPose();
        }
    }
    // ── v1.6.8: Строка AI-статусов ───────────────────────────────

    /**
     * Рендерит компактную строку с индикаторами активных AI-модулей:
     *   [⛰T] TerrainTactics  — зелёный если есть активная тактика
     *   [☠H] ThreatAssessment — красный если угроза высокая
     *   [◈P] PatternAI CounterStrategy — цвет по типу контр-паттерна
     *
     * Вызывается из основного render-цикла прямо перед строкой клавиш.
     */
    private void renderAiStatusRow(GuiGraphics ctx, Minecraft mc, int x, int y) {
        if (mc.player == null) return;

        java.util.List<BotEntity> playerBots = SpawnBotCommand.getAllBots();
        BotEntity firstBot = playerBots.isEmpty() ? null : playerBots.get(0);

        StringBuilder sb = new StringBuilder();

        // ── TerrainTactics ────────────────────────────────────────
        String terrainLabel = "§8[⛰-]";
        try {
            String tactic = TerrainTactics.INSTANCE.getActiveTacticLabel();
            if (tactic != null && !tactic.isEmpty()) {
                terrainLabel = "§a[⛰" + tactic + "]";
            }
        } catch (Exception ignored) {}
        sb.append(terrainLabel).append(" ");

        // ── ThreatAssessment ──────────────────────────────────────
        String threatLabel = "§8[☠-]";
        if (firstBot != null) {
            try {
                net.minecraft.world.entity.LivingEntity tgt = firstBot.getTarget();
                float dist = tgt != null ? firstBot.distanceTo(tgt) : Float.MAX_VALUE;
                if (tgt != null && dist < 8f)       threatLabel = "§c[☠!!]";
                else if (tgt != null && dist < 16f) threatLabel = "§e[☠!]";
                else if (tgt != null)               threatLabel = "§a[☠ok]";
            } catch (Exception ignored) {}
        }
        sb.append(threatLabel).append(" ");

        // ── PatternAI CounterStrategy ────────────────────────────
        String patternLabel = "§8[◈-]";
        if (firstBot != null) {
            try {
                PatternAI.CounterStrategy cs = firstBot.getPatternAI().getActiveCounter();
                patternLabel = switch (cs) {
                    case STRAFE_MIRROR  -> "§b[◈MIR]";
                    case STRAFE_COUNTER -> "§d[◈CTR]";
                    case TIMING_SHIFT   -> "§6[◈TMG]";
                    case BAIT_STOP      -> "§e[◈BAIT]";
                    default             -> "§8[◈-]";
                };
            } catch (Exception ignored) {}
        }
        sb.append(patternLabel);

        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(sb.toString()),
            x, y, 0xFFFFFF, true);
    }

}

// NOTE: File was closed above — this block is unreachable.
// The renderAiStatusRow method is injected via patch below.
