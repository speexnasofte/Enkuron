package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * TpcLogic v6.0 — FULL REWRITE
 *
 * ════════════════════════════════════════════════════════════════
 *  TPC = Totem + Crystal + Axe. Стиль игры:
 *  кристалл сбивает HP цели → топор добивает пока цель в KB.
 * ════════════════════════════════════════════════════════════════
 *
 *  Фазы:
 *
 *  APPROACH    → Сближение. Лук при dist > BOW_RANGE.
 *                Спринт + жемчуг gap close.
 *
 *  PRESSURE    → Основная фаза. Орбита вокруг цели на ORBIT_DIST.
 *                Кристальный урон каждые CRYSTAL_CD тиков.
 *                Топор между кристаллами (не прерывает цикл).
 *                Shield-check: если цель блокирует — axe для слома.
 *
 *  AXE_BURST   → Combo-окно после взрыва кристалла или слома щита.
 *                BURST_COUNT ударов топором с BURST_CD тиков интервал.
 *                Во время burst — принудительное сближение к цели.
 *
 *  CRIT_FINISH → Цель на низком HP (< FINISH_HP): прыжок-крит топором
 *                каждые CRIT_EVERY удара. Переход при targetHp < FINISH_HP.
 *
 *  RETREAT     → HP < RETREAT_HP: зигзаг, хил, ждём восстановления.
 *
 * ════════════════════════════════════════════════════════════════
 *  Ключевые улучшения v6:
 * ════════════════════════════════════════════════════════════════
 *
 *  ✦ AXE_BURST реально работает (в v5 фаза была в enum но не в switch)
 *  ✦ CRIT_FINISH: отдельная фаза для добивания — прыжок-крит + W-tap
 *  ✦ PatternAI: кристальный урон на предсказанную позицию цели
 *  ✦ SolidBonus: +25% урон у стен/потолка (блокирует KB-escape)
 *  ✦ AntiTotem: детект pop → немедленный burst 4 удара
 *  ✦ SmartShield: тотем ↔ щит переключение без конфликтов
 *  ✦ Orbit с фазовым сдвигом (не стоим неподвижно)
 *  ✦ AntiKB: цель в воздухе после crystal KB → жмём к ней
 *  ✦ Лук с leading shot на dist > BOW_RANGE
 *  ✦ Strength II + Speed II всегда активны
 *  ✦ HeatMap + HitHighlightTracker интеграция
 *  ✦ getStateLabel() с деталями для HUD
 */
public class TpcLogic {

    // ════════════════════════════════════════════════════════════════
    //  Дистанции
    // ════════════════════════════════════════════════════════════════
    private static final double BOW_RANGE      = 15.0;
    private static final double CRYSTAL_RANGE  = 9.0;
    private static final double AXE_RANGE      = 3.8;
    private static final double ORBIT_DIST     = 3.0;  // орбитальный радиус в PRESSURE
    private static final double BURST_CHASE    = 2.5;  // сближаемся во время burst
    private static final double FINISH_RANGE   = 3.0;  // дистанция для CRIT_FINISH атак

    // ════════════════════════════════════════════════════════════════
    //  Кулдауны (тики)
    // ════════════════════════════════════════════════════════════════
    private static final int CRYSTAL_CD        = 10;  // v5=12 → быстрее
    private static final int AXE_CD            = 14;
    private static final int BOW_CD            = 16;
    private static final int BURST_CD          = 5;   // между ударами в burst
    private static final int BURST_COUNT       = 5;   // ударов в одном burst
    private static final int RETREAT_CD        = 100;
    private static final int STR_CD            = 400;
    private static final int SPD_CD            = 400;
    private static final int ORBIT_CD          = 6;   // обновление орбиты
    private static final int SHIELD_DISABLE_CD = 100; // тиков после слома щита (щит не поднимается)
    private static final int ANTI_TOTEM_HITS   = 4;   // ударов при pop тотема у цели
    private static final int ANTI_TOTEM_HIT_CD = 6;

    // ════════════════════════════════════════════════════════════════
    //  Пороги HP
    // ════════════════════════════════════════════════════════════════
    private static final float RETREAT_HP      = 6.0f;  // ниже — RETREAT
    private static final float RECOVER_HP      = 13.0f; // выше — выход из RETREAT
    private static final float FINISH_HP       = 8.0f;  // HP цели для CRIT_FINISH

    // ════════════════════════════════════════════════════════════════
    //  Прочее
    // ════════════════════════════════════════════════════════════════
    private static final int   CRIT_EVERY      = 3;    // каждый N-й удар — крит

    // ════════════════════════════════════════════════════════════════
    //  Фазы
    // ════════════════════════════════════════════════════════════════
    private enum Phase { APPROACH, PRESSURE, AXE_BURST, CRIT_FINISH, RETREAT }
    private Phase phase = Phase.APPROACH;

    // ════════════════════════════════════════════════════════════════
    //  Зависимости
    // ════════════════════════════════════════════════════════════════
    private final BotEntity    bot;
    private final PVPBotConfig cfg    = PVPBotConfig.INSTANCE;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;

    // ════════════════════════════════════════════════════════════════
    //  Состояние
    // ════════════════════════════════════════════════════════════════
    private int crystalCd      = 0;
    private int axeCd          = 0;
    private int bowCd          = 0;
    private int burstCd        = 0;
    private int burstHitsLeft  = 0;
    private int retreatCd      = 0;
    private int strCd          = 0;
    private int spdCd          = 0;
    private int shieldDisable  = 0;   // кулдаун щита цели (после слома)
    private int orbitTimer     = 0;
    private int antiTotemHits  = 0;
    private int antiTotemHitCd = 0;
    private int hitCount       = 0;
    private boolean critPending = false;
    private float   orbitAngle  = 0f;
    private boolean zigzagLeft  = true;
    private int     zigzagTimer = 0;

    // AntiTotem
    private float targetLastHp = -1f;

    // ════════════════════════════════════════════════════════════════
    //  Конструктор
    // ════════════════════════════════════════════════════════════════
    public TpcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    // ════════════════════════════════════════════════════════════════
    //  Главный тик
    // ════════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        tickTimers();

        // ── Всегда: тотем + баффы + вода ─────────────────────────
        ensureTotem();
        applyBuffs();
        if (bot.isInWater() && !bot.onGround())
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.15, bot.getDeltaMovement().z);

        if (target == null || !target.isAlive()) {
            phase = Phase.APPROACH;
            return;
        }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Глобальный RETREAT-check ──────────────────────────────
        if (myHp < RETREAT_HP && phase != Phase.RETREAT) {
            phase = Phase.RETREAT;
            retreatCd = RETREAT_CD;
        }

        // ── AntiTotem (приоритет над фазами) ─────────────────────
        tickAntiTotem(sw, target, dist);

        // ── Смотрим на цель ───────────────────────────────────────
        if (dist < BOW_RANGE) bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Фазовый автомат ───────────────────────────────────────
        switch (phase) {
            case APPROACH    -> tickApproach(sw, target, dist);
            case PRESSURE    -> tickPressure(sw, target, dist);
            case AXE_BURST   -> tickAxeBurst(sw, target, dist);
            case CRIT_FINISH -> tickCritFinish(sw, target, dist);
            case RETREAT     -> tickRetreat(sw, target, dist, myHp);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  APPROACH: сближение к цели
    // ════════════════════════════════════════════════════════════════
    private void tickApproach(ServerLevel sw, LivingEntity target, double dist) {
        // Лук пока далеко
        if (dist > BOW_RANGE) {
            doBowShot(sw, target, dist);
        }

        bot.setSprinting(true);
        bot.getNavigation().moveTo(target, 1.4);

        // Вошли в зону — переходим в PRESSURE
        if (dist <= CRYSTAL_RANGE) {
            phase = Phase.PRESSURE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  PRESSURE: орбита + кристалл + топор между кристаллами
    // ════════════════════════════════════════════════════════════════
    private void tickPressure(ServerLevel sw, LivingEntity target, double dist) {
        // Улетели — возврат
        if (dist > CRYSTAL_RANGE + 2.0) {
            phase = Phase.APPROACH;
            return;
        }

        // Страф + орбита
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive && cfg.strafeEnabled) strafe.tick(target);
        updateOrbit(target, dist);

        // ── Кристалл ─────────────────────────────────────────────
        if (dist <= CRYSTAL_RANGE && crystalCd <= 0) {
            doCrystalHit(sw, target, dist);
            // После кристалла — burst окно
            if (dist <= AXE_RANGE + 1.0) {
                enterBurst();
                return; // уходим сразу в AXE_BURST
            }
        }

        // ── Топор между кристаллами (если вблизи, без burst) ─────
        if (dist <= AXE_RANGE && axeCd <= 0 && crystalCd > CRYSTAL_CD / 2) {
            boolean blocking = isBlocking(target);
            if (blocking) {
                // Слом щита
                doAxeHit(sw, target, false);
                shieldDisable = SHIELD_DISABLE_CD;
                enterBurst();
                return;
            }
            // Обычный удар топором
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit) {
                doCritAxe(sw, target);
            } else {
                doAxeHit(sw, target, false);
            }
        }

        // ── Переход в CRIT_FINISH ────────────────────────────────
        if (target.getHealth() < FINISH_HP) {
            phase = Phase.CRIT_FINISH;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  AXE_BURST: серия ударов топором после кристалла/слома щита
    // ════════════════════════════════════════════════════════════════
    private void tickAxeBurst(ServerLevel sw, LivingEntity target, double dist) {
        if (burstHitsLeft <= 0) {
            // Burst завершён
            phase = target.getHealth() < FINISH_HP ? Phase.CRIT_FINISH : Phase.PRESSURE;
            return;
        }

        // Принудительное сближение во время burst
        if (dist > BURST_CHASE) {
            bot.getNavigation().moveTo(target, 1.5);
            bot.setSprinting(true);
        }

        // Бьём с интервалом BURST_CD
        if (burstCd <= 0 && dist <= AXE_RANGE + 0.5) {
            boolean isFinalHit = (burstHitsLeft == 1);
            // Финальный удар burst — крит
            if (isFinalHit) {
                doCritAxe(sw, target);
            } else {
                doAxeHit(sw, target, false);
            }
            burstHitsLeft--;
            burstCd = BURST_CD;
        }

        // Цель сдохла посреди burst
        if (!target.isAlive()) {
            burstHitsLeft = 0;
            phase = Phase.APPROACH;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  CRIT_FINISH: добивание прыжками-критами
    // ════════════════════════════════════════════════════════════════
    private void tickCritFinish(ServerLevel sw, LivingEntity target, double dist) {
        // Цель восстановилась — назад в PRESSURE
        if (target.getHealth() >= FINISH_HP + 2.0f) {
            phase = Phase.PRESSURE;
            critPending = false;
            return;
        }

        // Сближаемся
        if (dist > FINISH_RANGE) {
            bot.getNavigation().moveTo(target, 1.3);
            bot.setSprinting(true);
            return;
        }

        boolean wTapActive = wTap.tick(target);
        if (!wTapActive && cfg.strafeEnabled) strafe.tick(target);

        // Кристалл если цель чуть дальше axe range
        if (dist > AXE_RANGE && crystalCd <= 0) {
            doCrystalHit(sw, target, dist);
            return;
        }

        if (axeCd <= 0) {
            // Каждый 3-й удар — прыжок-крит
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit) {
                doCritAxe(sw, target);
            } else {
                doAxeHit(sw, target, false);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  RETREAT: зигзаг + хил
    // ════════════════════════════════════════════════════════════════
    private void tickRetreat(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        retreatCd--;

        // Мгновенный хил
        if (retreatCd == RETREAT_CD - 1) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 0));
        }

        // Зигзаг отступ
        if (zigzagTimer <= 0) {
            zigzagLeft = !zigzagLeft;
            zigzagTimer = 5 + bot.level().getRandom().nextInt(6);
        }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side  = zigzagLeft
            ? new Vec3(-away.z, 0,  away.x).scale(0.5)
            : new Vec3( away.z, 0, -away.x).scale(0.5);
        Vec3 dest = bot.position().add(away.scale(8.0)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.4);
        bot.setSprinting(true);

        // Лук пока отступаем
        if (dist > 6.0) doBowShot(sw, target, dist);

        // Восстановились
        if (myHp >= RECOVER_HP || retreatCd <= 0) {
            phase = Phase.APPROACH;
            critPending = false;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  AntiTotem: burst при pop тотема у цели
    // ════════════════════════════════════════════════════════════════
    private void tickAntiTotem(ServerLevel sw, LivingEntity target, double dist) {
        float hp = target.getHealth();

        // Детект pop
        if (targetLastHp > 0 && targetLastHp <= 1.2f && hp > 1.5f) {
            antiTotemHits = ANTI_TOTEM_HITS;
            notifyOwner(sw, "§d[TPC] AntiTotem! " + ANTI_TOTEM_HITS + " ударов!");
        }

        if (antiTotemHits > 0 && antiTotemHitCd <= 0) {
            if (dist <= AXE_RANGE) {
                doAxeHit(sw, target, false);
                antiTotemHits--;
                antiTotemHitCd = ANTI_TOTEM_HIT_CD;
            } else {
                bot.getNavigation().moveTo(target, 1.6);
                bot.setSprinting(true);
            }
        }

        targetLastHp = hp;
    }

    // ════════════════════════════════════════════════════════════════
    //  Орбита
    // ════════════════════════════════════════════════════════════════
    private void updateOrbit(LivingEntity target, double dist) {
        if (orbitTimer > 0) return;
        orbitTimer = ORBIT_CD;
        orbitAngle += (float)(Math.PI * 0.3);

        if (dist > ORBIT_DIST + 1.2) {
            bot.getNavigation().moveTo(target, 1.15);
        } else if (dist < ORBIT_DIST - 0.8) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 3, bot.getY(), bot.getZ() + away.z * 3, 1.1);
        } else {
            double tx = target.getX() + Math.cos(orbitAngle) * ORBIT_DIST;
            double tz = target.getZ() + Math.sin(orbitAngle) * ORBIT_DIST;
            bot.getNavigation().moveTo(tx, target.getY(), tz, 1.05);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Атаки
    // ════════════════════════════════════════════════════════════════

    private void doCrystalHit(ServerLevel sw, LivingEntity target, double dist) {
        // PatternAI: бьём по предсказанной позиции
        Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);

        // SolidBonus: +25% у стен/потолка (цель не может откатиться)
        BlockPos tPos = BlockPos.containing(predicted);
        boolean nearSolid = false;
        for (BlockPos adj : new BlockPos[]{
            tPos.north(), tPos.south(), tPos.east(), tPos.west(), tPos.above(2), tPos.below()
        }) {
            if (sw.getBlockState(adj).isSolid()) { nearSolid = true; break; }
        }
        float solidBonus = nearSolid ? 1.25f : 1.0f;

        // Урон: больше вблизи, меньше на дистанции
        float baseDmg = (float)(Math.max(5.0, 18.0 - dist * 1.0) * solidBonus);
        if (target.isAlive())
            target.hurt(sw.damageSources().explosion(bot, bot), baseDmg);

        // AoE на других в радиусе 2.5
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(2.5),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().explosion(bot, bot), baseDmg * 0.4f));

        // AntiKB: если цель в воздухе — горизонтальный KB сильнее
        boolean inAir = !target.onGround();
        Vec3 kb = predicted.subtract(bot.position()).normalize();
        float kbY = inAir ? 0.5f : 1.0f;  // в воздухе меньше вертикали (не даём дальше улететь)
        if (target.isAlive())
            target.setDeltaMovement(target.getDeltaMovement().add(kb.x * 1.3, kbY, kb.z * 1.3));

        // Визуал + звук
        sw.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
            predicted.x, predicted.y, predicted.z, 1, 0, 0, 0, 0);
        bot.playSound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE.value(), 0.9f, 1.0f);

        HitHighlightTracker.INSTANCE.onHit(target.getId());
        crystalCd = CRYSTAL_CD;
        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), baseDmg);
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        equipAxe();
        if (!target.isAlive()) return;
        bot.doHurtTarget(sw, target);

        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY() + 1, target.getZ(), 4, 0.4, 0.2, 0.4, 0.05);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        }

        hitCount++;
        axeCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : AXE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), crit ? 22f : 14f);
    }

    /**
     * Прыжок-крит: прыгаем, ждём падения, бьём в воздухе.
     * Вызываем каждый тик — внутри управляет состоянием critPending.
     */
    private void doCritAxe(ServerLevel sw, LivingEntity target) {
        if (!critPending && bot.onGround()) {
            bot.getJumpControl().jump();
            critPending = true;
            axeCd = 2; // небольшая задержка пока поднимаемся
        } else if (critPending && !bot.onGround() && bot.fallDistance > 0.02f) {
            doAxeHit(sw, target, true);
            critPending = false;
        }
    }

    private void doBowShot(ServerLevel sw, LivingEntity target, double dist) {
        if (bowCd > 0) return;
        equipBow();

        // Leading shot: компенсируем движение цели
        float lead = (float)(dist / 22.0 * 20);
        Vec3  vel  = target.getDeltaMovement();
        Vec3  aim  = target.position().add(vel.scale(lead));
        bot.getLookControl().setLookAt(aim.x, aim.y + 1.0, aim.z, 60f, 60f);

        float dmg = (float) Math.max(4.0, Math.min(9.0, 11.0 - dist * 0.3));
        if (target.isAlive())
            target.hurt(sw.damageSources().arrow(null, bot), dmg);

        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(), 4, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
        bowCd = BOW_CD;
        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), dmg);
    }

    // ════════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ════════════════════════════════════════════════════════════════

    /** Запуск AXE_BURST: устанавливаем счётчик и переключаем фазу */
    private void enterBurst() {
        burstHitsLeft = BURST_COUNT;
        burstCd = 0;
        phase = Phase.AXE_BURST;
    }

    private void tickTimers() {
        if (crystalCd      > 0) crystalCd--;
        if (axeCd          > 0) axeCd--;
        if (bowCd          > 0) bowCd--;
        if (burstCd        > 0) burstCd--;
        if (retreatCd      > 0) retreatCd--;
        if (strCd          > 0) strCd--;
        if (spdCd          > 0) spdCd--;
        if (shieldDisable  > 0) shieldDisable--;
        if (orbitTimer     > 0) orbitTimer--;
        if (antiTotemHitCd > 0) antiTotemHitCd--;
        if (zigzagTimer    > 0) zigzagTimer--;
    }

    private void applyBuffs() {
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1)); // Strength II
            strCd = STR_CD;
        }
        if (spdCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); // Speed II
            spdCd = SPD_CD;
        }
    }

    private void ensureTotem() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        // Снимаем шифт если не блокируем
        bot.setShiftKeyDown(false);
    }

    private boolean isBlocking(LivingEntity t) {
        if (shieldDisable > 0) return false; // щит уже сломан — не считаем
        return (t.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD) ||
                t.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD))
            && t.isBlocking();
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                    .enchant("sharpness", 5)
                    .enchant("efficiency", 5)
                    .enchant("unbreaking", 3)
                    .build());
    }

    private void equipBow() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                    .enchant("power", 5)
                    .enchant("infinity", 1)
                    .build());
    }

    private void notifyOwner(ServerLevel sw, String msg) {
        if (bot.getOwner() instanceof ServerPlayer sp)
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    // ════════════════════════════════════════════════════════════════
    //  HUD
    // ════════════════════════════════════════════════════════════════
    public String getStateLabel() {
        return switch (phase) {
            case APPROACH    -> "TPC:MOVE";
            case PRESSURE    -> "TPC:PRESSURE";
            case AXE_BURST   -> "TPC:BURST " + burstHitsLeft + "x";
            case CRIT_FINISH -> "TPC:FINISH";
            case RETREAT     -> "TPC:FLEE " + retreatCd + "t";
        };
    }
}
