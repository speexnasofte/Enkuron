package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * TotemLogic v17 — EXPANDED
 *
 * ════════════════════════════════════════════════════════════════
 *  Режим TOTEM: бот-танк, принимает урон вместо владельца.
 * ════════════════════════════════════════════════════════════════
 *
 *  Фазы:
 *
 *  REPOSITION  — бот вычисляет идеальную танк-позицию между
 *                владельцем и целью и бежит туда.
 *
 *  AGGRO       — на позиции: атакует цель мечом (W-tap), агрит
 *                на себя. Следит за позицией владельца и смещается
 *                при его движении.
 *
 *  INTERCEPT   — цель переключилась на владельца → бот прыгает
 *                прямо между ними, принимает удары первым.
 *
 *  POP_WAIT    — тотем сработал (HP ≤ 1): отскок, регенерация,
 *                баффы, частицы. Возврат в бой при HP ≥ 10.
 *
 *  FLANK       — при HP владельца < 30% бот перестаёт танковать
 *                и переходит в режим агрессивного флангового
 *                давления: атаки с боку + W-tap серии.
 *
 * ════════════════════════════════════════════════════════════════
 *  Новое в v17:
 * ════════════════════════════════════════════════════════════════
 *
 *  ✦ FLANK-фаза: если владелец критически ранен — бот давит
 *    с фланга чтобы цель отвлеклась от добивания владельца
 *  ✦ CritWindow: детект замаха цели (isUsingItem с мечом/топором)
 *    → бот уходит в сторону, принимает удар вместо владельца
 *  ✦ OwnerShield: если владелец близко к цели И бот рядом →
 *    бот физически вклинивается между ними (moveTo midpoint)
 *  ✦ AntiTotem v2: комбо после pop расширено до 5 ударов,
 *    добавлен Speed II burst на 3 секунды
 *  ✦ SmartRetreat: отступ зигзагом (не прямолинейно)
 *  ✦ HealBurst: при pop сразу Regen II + Absorption II + Heal I
 *  ✦ Strength I всегда (не только в FLANK)
 *  ✦ TauntShout: лог-сообщение владельцу при смене фаз
 *  ✦ ensureTotemInOffhand: заменяет ЛЮБОЙ предмет (не только пустой)
 *  ✦ equipBestSword: netherite > diamond > iron, авто-выбор
 *  ✦ isTargetingOwner: расширена логика для игроков (dot + dist)
 */
public class TotemLogic {

    // ════════════════════════════════════════════════════════════════
    //  Константы
    // ════════════════════════════════════════════════════════════════

    /** Блоков перед владельцем в направлении цели — танк-позиция */
    private static final double TANK_OFFSET        = 2.5;
    /** Дальность атаки мечом */
    private static final double MELEE_RANGE        = 3.5;
    /** Дальность флангового давления */
    private static final double FLANK_RANGE        = 4.5;
    /** Кулдаун обычной атаки */
    private static final int    ATTACK_CD          = 11;
    /** Кулдаун атаки в FLANK-режиме (быстрее) */
    private static final int    FLANK_ATTACK_CD    = 7;
    /** Тиков ожидания после pop тотема */
    private static final int    POP_WAIT_TICKS     = 50;
    /** HP бота при котором тотем «поп-нется» */
    private static final float  POP_HP_THRESHOLD   = 1.5f;
    /** HP бота для возврата в бой после pop */
    private static final float  RECOVER_HP         = 10.0f;
    /** % HP владельца ниже которого включается FLANK */
    private static final float  FLANK_OWNER_HP_PCT = 0.30f;
    /** Дистанция отскока после pop */
    private static final double POP_RETREAT_DIST   = 4.5;
    /** Кулдауны баффов */
    private static final int    STR_CD             = 400;
    private static final int    SPEED_CD           = 400;
    private static final int    REGEN_CD           = 300;
    /** Ударов в AntiTotem комбо */
    private static final int    ANTI_TOTEM_HITS    = 5;
    /** Тиков между ударами AntiTotem */
    private static final int    ANTI_TOTEM_HIT_CD  = 8;
    /** Позиция OK если ближе этого от танк-точки */
    private static final double ON_POSITION_DIST   = 1.8;
    /** Позиция требует коррекции если дальше */
    private static final double REPOSITION_DIST    = 3.0;
    /** Угол фланкового смещения (радианы) */
    private static final double FLANK_ANGLE        = Math.PI / 2.5;

    // ════════════════════════════════════════════════════════════════
    //  Фазы
    // ════════════════════════════════════════════════════════════════
    private enum State { REPOSITION, AGGRO, INTERCEPT, POP_WAIT, FLANK }

    // ════════════════════════════════════════════════════════════════
    //  Состояние
    // ════════════════════════════════════════════════════════════════
    private State state      = State.REPOSITION;
    private int   attackCd   = 0;
    private int   popTimer   = 0;
    private int   strCd      = 0;
    private int   speedCd    = 0;
    private int   regenCd    = 0;

    // AntiTotem
    private float targetLastHp     = -1f;
    private int   antiTotemHits    = 0;
    private int   antiTotemHitCd   = 0;
    private int   antiTotemSpeedBurst = 0; // тиков Speed II после pop

    // Flank
    private double flankAngleOffset = FLANK_ANGLE; // чередуем стороны
    private int    flankSideTimer   = 0;           // меняем сторону каждые N тиков

    private final BotEntity    bot;
    private final WTapLogic    wTap;

    public TotemLogic(BotEntity bot) {
        this.bot  = bot;
        this.wTap = new WTapLogic(bot);
    }

    // ════════════════════════════════════════════════════════════════
    //  Главный тик
    // ════════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        // Тотем всегда в оффхенде
        ensureTotemInOffhand();

        // Таймеры
        tickTimers();

        // Баффы всегда активны
        applyBuffs(sw);

        // AntiTotem комбо (приоритет над фазами)
        tickAntiTotem(sw, target);

        // Pop-check (глобальный, из любой фазы)
        if (bot.getHealth() <= POP_HP_THRESHOLD && state != State.POP_WAIT) {
            enterPop(sw, target);
            return;
        }

        // Определяем нужен ли FLANK
        LivingEntity owner = getOwner(sw);
        if (owner != null && state != State.POP_WAIT) {
            float ownerMaxHp = owner.getMaxHealth();
            float ownerHpPct = owner.getHealth() / ownerMaxHp;
            if (ownerHpPct < FLANK_OWNER_HP_PCT && state != State.FLANK) {
                state = State.FLANK;
                taunt(sw, "§c[Totem] FLANK — владелец критически ранен!");
            }
            // Если владелец восстановился — выходим из FLANK
            if (ownerHpPct >= 0.55f && state == State.FLANK) {
                state = State.REPOSITION;
            }
        }

        // Фазовый автомат
        switch (state) {
            case REPOSITION -> tickReposition(sw, target, owner);
            case AGGRO      -> tickAggro(sw, target, owner);
            case INTERCEPT  -> tickIntercept(sw, target, owner);
            case POP_WAIT   -> tickPopWait(sw, target);
            case FLANK      -> tickFlank(sw, target, owner);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  REPOSITION: бежим на танк-позицию
    // ════════════════════════════════════════════════════════════════
    private void tickReposition(ServerLevel sw, LivingEntity target, LivingEntity owner) {
        if (owner == null) {
            // Нет владельца — просто агрим цель
            state = State.AGGRO;
            return;
        }

        Vec3 tankPos = calcTankPos(owner, target);
        double distToTank = bot.position().distanceTo(tankPos);

        if (distToTank > ON_POSITION_DIST) {
            bot.getNavigation().moveTo(tankPos.x, tankPos.y, tankPos.z, 1.3);
        } else {
            // На месте
            state = State.AGGRO;
        }

        // Если цель уже атакует владельца — переходим к INTERCEPT сразу
        if (isTargetingOwner(target, owner)) {
            state = State.INTERCEPT;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  AGGRO: атакуем, агрим на себя, держим позицию
    // ════════════════════════════════════════════════════════════════
    private void tickAggro(ServerLevel sw, LivingEntity target, LivingEntity owner) {
        double distToTarget = bot.distanceTo(target);

        // Проверяем позицию
        if (owner != null) {
            Vec3 tankPos = calcTankPos(owner, target);
            double distToTank = bot.position().distanceTo(tankPos);
            if (distToTank > REPOSITION_DIST) {
                state = State.REPOSITION;
                return;
            }
        }

        // Атака мечом
        if (distToTarget <= MELEE_RANGE && attackCd <= 0) {
            equipBestSword();
            wTap.onAttack();
            bot.doHurtTarget(sw, target);
            attackCd = ATTACK_CD;
        } else if (distToTarget > MELEE_RANGE + 0.5) {
            bot.getNavigation().moveTo(target, 1.2);
        }

        // Смотрим на цель для агра
        if (distToTarget <= MELEE_RANGE + 2.0) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
        }

        // Цель переключилась на владельца
        if (owner != null && isTargetingOwner(target, owner)) {
            state = State.INTERCEPT;
            taunt(sw, "§e[Totem] INTERCEPT — заслоняю владельца!");
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  INTERCEPT: вклиниваемся между целью и владельцем
    // ════════════════════════════════════════════════════════════════
    private void tickIntercept(ServerLevel sw, LivingEntity target, LivingEntity owner) {
        if (owner == null) { state = State.AGGRO; return; }

        // Точка между целью и владельцем (ближе к цели — 40/60)
        Vec3 interceptPos = target.position().scale(0.4)
            .add(owner.position().scale(0.6));
        bot.getNavigation().moveTo(interceptPos.x, interceptPos.y, interceptPos.z, 1.45);

        // Атакуем цель
        double dist = bot.distanceTo(target);
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            equipBestSword();
            wTap.onAttack();
            bot.doHurtTarget(sw, target);
            attackCd = ATTACK_CD;
        }

        // OwnerShield: если цель вплотную к владельцу — физически вклинились
        double targetToOwner = target.distanceTo(owner);
        if (targetToOwner < 2.5 && bot.distanceTo(owner) < 3.0) {
            // Тычок цели в сторону от владельца
            Vec3 push = target.position().subtract(owner.position()).normalize();
            target.setDeltaMovement(target.getDeltaMovement().add(push.x * 0.5, 0.15, push.z * 0.5));
        }

        // Цель переключилась — назад в AGGRO
        if (!isTargetingOwner(target, owner)) {
            state = State.AGGRO;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  FLANK: агрессивное фланговое давление
    // ════════════════════════════════════════════════════════════════
    private void tickFlank(ServerLevel sw, LivingEntity target, LivingEntity owner) {
        flankSideTimer--;
        if (flankSideTimer <= 0) {
            // Меняем сторону фланка каждые ~40 тиков
            flankAngleOffset = -flankAngleOffset;
            flankSideTimer = 40 + (int)(Math.random() * 20);
        }

        // Вычисляем фланговую позицию: сбоку от цели
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        // Поворачиваем вектор на flankAngleOffset
        double sin = Math.sin(flankAngleOffset);
        double cos = Math.cos(flankAngleOffset);
        Vec3 flankDir = new Vec3(
            toTarget.x * cos - toTarget.z * sin,
            0,
            toTarget.x * sin + toTarget.z * cos
        );
        Vec3 flankPos = target.position().add(flankDir.scale(2.2));

        double distToTarget = bot.distanceTo(target);

        // Движение на фланговую позицию или атака
        if (distToTarget > FLANK_RANGE) {
            bot.getNavigation().moveTo(flankPos.x, flankPos.y, flankPos.z, 1.4);
            bot.setSprinting(true);
        } else {
            // Стреляем с фланга
            if (attackCd <= 0) {
                equipBestSword();
                wTap.onAttack();
                bot.doHurtTarget(sw, target);
                attackCd = FLANK_ATTACK_CD;
            }
            // Скользим на фланговую позицию даже в атаке
            bot.getNavigation().moveTo(flankPos.x, flankPos.y, flankPos.z, 1.15);
        }

        // Защищаем владельца даже в FLANK-режиме
        if (owner != null && isTargetingOwner(target, owner)
                && target.distanceTo(owner) < 4.0) {
            state = State.INTERCEPT;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  POP_WAIT: тотем сработал, восстановление
    // ════════════════════════════════════════════════════════════════
    private void tickPopWait(ServerLevel sw, LivingEntity target) {
        popTimer--;

        // Частицы тотема
        if (popTimer % 4 == 0) {
            sw.sendParticles(ParticleTypes.TOTEM_OF_UNDYING,
                bot.getX(), bot.getY() + 1.0, bot.getZ(),
                8, 0.35, 0.55, 0.35, 0.12);
        }

        // Продолжаем отступать
        if (popTimer % 10 == 0 && target != null) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            // Зигзаг
            double zigzag = (popTimer % 20 < 10) ? 1.5 : -1.5;
            Vec3 perp = new Vec3(-away.z, 0, away.x).scale(zigzag);
            Vec3 dest = bot.position().add(away.scale(5.0)).add(perp);
            bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.4);
        }

        // Выход из POP_WAIT
        if (bot.getHealth() >= RECOVER_HP || popTimer <= 0) {
            state = State.REPOSITION;
            taunt(sw, "§a[Totem] Восстановился → REPOSITION");
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  AntiTotem v2: комбо после pop тотема у цели
    // ════════════════════════════════════════════════════════════════
    private void tickAntiTotem(ServerLevel sw, LivingEntity target) {
        float currentHp = target.getHealth();

        // Детект pop: HP было ≤ 1.2, теперь > 1.5
        if (targetLastHp > 0 && targetLastHp <= 1.2f && currentHp > 1.5f) {
            antiTotemHits = ANTI_TOTEM_HITS;
            antiTotemSpeedBurst = 60; // 3 секунды Speed II
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
            taunt(sw, "§d[Totem] AntiTotem! " + ANTI_TOTEM_HITS + " combo ударов!");
        }

        if (antiTotemSpeedBurst > 0) antiTotemSpeedBurst--;

        // Выполняем комбо
        if (antiTotemHits > 0 && antiTotemHitCd <= 0) {
            double dist = bot.distanceTo(target);
            if (dist <= MELEE_RANGE) {
                equipBestSword();
                bot.doHurtTarget(sw, target);
                antiTotemHits--;
                antiTotemHitCd = ANTI_TOTEM_HIT_CD;
            } else {
                // Бросок к цели
                bot.getNavigation().moveTo(target, 1.65);
                bot.setSprinting(true);
            }
        }

        targetLastHp = currentHp;
    }

    // ════════════════════════════════════════════════════════════════
    //  Pop: вход в фазу POP_WAIT
    // ════════════════════════════════════════════════════════════════
    private void enterPop(ServerLevel sw, LivingEntity target) {
        state = State.POP_WAIT;
        popTimer = POP_WAIT_TICKS;

        // HealBurst: мгновенный хил
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1)); // Regen II
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 1)); // Absorption II
        bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 0));           // Instant Health I

        // Звук + отскок
        bot.playSound(SoundEvents.TOTEM_USE, 1.0f, 1.0f);

        if (target != null) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            Vec3 dest = bot.position().add(away.scale(POP_RETREAT_DIST));
            bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.5);
        }

        taunt(sw, "§c[Totem] POP! Отступаю на " + POP_WAIT_TICKS + " тиков");
    }

    // ════════════════════════════════════════════════════════════════
    //  Вспомогательные методы
    // ════════════════════════════════════════════════════════════════

    /** Вычисляем позицию танка: TANK_OFFSET блоков от владельца к цели */
    private Vec3 calcTankPos(LivingEntity owner, LivingEntity target) {
        Vec3 dir = target.position().subtract(owner.position()).normalize();
        return owner.position().add(dir.scale(TANK_OFFSET));
    }

    /** Тотем всегда в оффхенде — заменяем что угодно */
    public void ensureTotemInOffhand() {
        ItemStack offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (!offhand.is(Items.TOTEM_OF_UNDYING)) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }
    }

    /** Netherite > Diamond > Iron > любой меч */
    private void equipBestSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (cur.is(Items.NETHERITE_SWORD)) return;
        if (cur.is(Items.DIAMOND_SWORD))   return;
        // Ставим лучший доступный
        for (var item : new net.minecraft.world.item.Item[]{
                Items.NETHERITE_SWORD, Items.DIAMOND_SWORD, Items.IRON_SWORD }) {
            // Предполагаем что у бота всегда есть алмазный меч (стандартный кит)
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(item));
            return;
        }
    }

    /** Баффы всегда активны */
    private void applyBuffs(ServerLevel sw) {
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 0)); // Strength I
            strCd = STR_CD;
        }
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 0)); // Speed I
            speedCd = SPEED_CD;
        }
    }

    private void tickTimers() {
        if (attackCd      > 0) attackCd--;
        if (strCd         > 0) strCd--;
        if (speedCd       > 0) speedCd--;
        if (regenCd       > 0) regenCd--;
        if (antiTotemHitCd > 0) antiTotemHitCd--;
    }

    private LivingEntity getOwner(ServerLevel sw) {
        Player owner = bot.getOwner();
        return owner instanceof LivingEntity le ? le : null;
    }

    /**
     * Цель атакует владельца?
     * Для мобов — getTarget(). Для игроков — направление взгляда + дистанция.
     */
    private boolean isTargetingOwner(LivingEntity target, LivingEntity owner) {
        if (target instanceof Mob mob) {
            return mob.getTarget() != null
                && mob.getTarget().getUUID().equals(owner.getUUID());
        }
        // Игрок: смотрит на владельца + достаточно близко
        Vec3 look    = target.getViewVector(1.0f).normalize();
        Vec3 toOwner = owner.position().subtract(target.position()).normalize();
        return look.dot(toOwner) > 0.80 && target.distanceTo(owner) < 7.0;
    }

    /** Сообщение владельцу о смене фаз */
    private void taunt(ServerLevel sw, String msg) {
        Player owner = bot.getOwner();
        if (owner instanceof ServerPlayer sp) {
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  HUD
    // ════════════════════════════════════════════════════════════════
    public String getStateLabel() {
        return switch (state) {
            case REPOSITION -> "TOTEM:MOVE";
            case AGGRO      -> "TOTEM:TANK";
            case INTERCEPT  -> "TOTEM:SHIELD";
            case POP_WAIT   -> "TOTEM:POP " + popTimer + "t";
            case FLANK      -> "TOTEM:FLANK";
        };
    }
}
