package com.pvpbot;

import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * PotLogic v1.0 — Pot PvP с нуля.
 *
 * ════════════════════════════════════════════════════════════════
 *  Концепция: классический Pot PvP (Java 1.8–1.21 стиль).
 *
 *  Стиль игры:
 *   • Splash Instant Damage II на врага — основной урон
 *   • Splash Instant Health II на себя — лечение под ногами
 *   • Меч: крит-комбо МЕЖДУ бросками зелий (не вместо)
 *   • Speed II + Strength II всегда активны
 *   • Кайтинг: оптимальная дистанция для попадания зельем
 *   • Pearling (gap-close) если цель убегает
 *   • AntiTotem: детект pop → burst 3 зелья подряд
 *   • CounterHeal: цель пьёт — rush-атака мечом
 *
 * ════════════════════════════════════════════════════════════════
 *  Фазы:
 *
 *  APPROACH    → Сближение к цели на ENGAGE_DIST.
 *                Спринт + жемчуг если цель далеко.
 *
 *  KITE        → Основная боевая фаза.
 *                Орбита на OPTIMAL_DIST. Серия бросков:
 *                Harming → меч → меч → Harming → ...
 *                Slowness при побеге цели.
 *                Heal при myHp < HEAL_THRESHOLD.
 *
 *  RUSH        → Цель уязвима (пьёт зелье / только что попала).
 *                Сближение до RUSH_DIST, burst 2 удара мечом.
 *
 *  CRIT_FINISH → Цель на низком HP. Прыжок-крит каждые 2 удара.
 *                Burst зелий без паузы.
 *
 *  RETREAT     → Наш HP критически низкий.
 *                Зигзаг + heal под ногами + pearl escape.
 *
 * ════════════════════════════════════════════════════════════════
 *  Ключевые фичи:
 *
 *  ✦ SmartThrow: бросок harming на ПРЕДСКАЗАННУЮ позицию цели
 *  ✦ SelfHeal: кидаем Instant Health II СЕБЕ ПОД НОГИ (не на цель)
 *  ✦ Dual-throw: Harming + Slowness с задержкой 4 тика
 *  ✦ AntiTotem: детект pop → 3 зелья + 2 крита подряд
 *  ✦ CounterHeal: цель пьёт → немедленный rush
 *  ✦ Weakness на цель если она блокирует щитом
 *  ✦ Fire Resistance при горении (авто)
 *  ✦ WTapLogic + StrafeAI интегрированы
 *  ✦ Orbit с фазовым сдвигом (непредсказуемая позиция)
 *  ✦ getPhaseLabel() для HUD
 * ════════════════════════════════════════════════════════════════
 */
public class PotLogic {

    // ═══════════════════════════════════════════════════════════════
    //  Фазы
    // ═══════════════════════════════════════════════════════════════
    private enum Phase { APPROACH, KITE, RUSH, CRIT_FINISH, RETREAT }
    private Phase phase = Phase.APPROACH;

    // ═══════════════════════════════════════════════════════════════
    //  Дистанции
    // ═══════════════════════════════════════════════════════════════
    private static final double APPROACH_DIST  = 16.0; // дальше — спринт + жемчуг
    private static final double ENGAGE_DIST    = 6.0;  // вошли → KITE
    private static final double OPTIMAL_DIST   = 2.5;  // оптимум для харминга
    private static final double SPLASH_RANGE   = 4.5;  // макс. эффективная дальность харминга
    private static final double SELF_HEAL_DIST = 0.8;  // кидаем под себя
    private static final double SLOWNESS_RANGE = 5.5;  // дальность slowness
    private static final double MELEE_RANGE    = 2.8;  // рукопашная
    private static final double RUSH_DIST      = 1.8;  // rush-сближение
    private static final double FINISH_RANGE   = 3.0;  // финиш

    // ═══════════════════════════════════════════════════════════════
    //  Пороги HP
    // ═══════════════════════════════════════════════════════════════
    private static final float HEAL_THRESHOLD    = 14.0f; // лечимся ниже этого
    private static final float CRIT_HEAL_HP      = 7.0f;  // экстренное лечение
    private static final float RETREAT_HP        = 5.0f;  // уходим в отступление
    private static final float RECOVER_HP        = 14.0f; // выход из retreat
    private static final float FINISH_TARGET_HP  = 8.0f;  // у цели — CRIT_FINISH

    // ═══════════════════════════════════════════════════════════════
    //  Кулдауны (тики)
    // ═══════════════════════════════════════════════════════════════
    private static final int HARMING_CD     = 22;  // Splash Instant Damage II
    private static final int HEAL_CD        = 20;  // Splash Instant Health II на себя
    private static final int SLOWNESS_CD    = 50;  // Splash Slowness
    private static final int WEAKNESS_CD    = 100; // Weakness на цель (щит)
    private static final int MELEE_CD       = 6;   // удар мечом
    private static final int ORBIT_CD       = 5;   // обновление орбиты
    private static final int SPEED_CD       = 400;
    private static final int STR_CD         = 400;
    private static final int FIRE_RES_CD    = 600;
    private static final int PEARL_CD       = 100; // эндер-жемчуг
    private static final int RETREAT_TICKS  = 80;  // длительность retreat
    private static final int RUSH_TICKS     = 20;  // burst атака
    private static final int DUAL_DELAY     = 4;   // тиков между harming и slowness
    private static final int ANTI_TOTEM_CD  = 6;   // между anti-totem бросками

    // Крит-финиш
    private static final int CRIT_EVERY     = 2;   // каждый N-й удар — прыжок-крит

    // ═══════════════════════════════════════════════════════════════
    //  Зависимости
    // ═══════════════════════════════════════════════════════════════
    private final BotEntity    bot;
    private final PVPBotConfig cfg    = PVPBotConfig.INSTANCE;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;

    // ═══════════════════════════════════════════════════════════════
    //  Таймеры
    // ═══════════════════════════════════════════════════════════════
    private int harmingCd      = 0;
    private int healCd         = 0;
    private int slownessCd     = 0;
    private int weaknessCd     = 0;
    private int meleeCd        = 0;
    private int orbitCd        = 0;
    private int speedCd        = 0;
    private int strCd          = 0;
    private int fireResCd      = 0;
    private int pearlCd        = 0;
    private int retreatTimer   = 0;
    private int rushTimer      = 0;
    private int dualDelayTimer = 0; // задержанный slowness после harming
    private int antiTotemCd    = 0;

    // ═══════════════════════════════════════════════════════════════
    //  Состояние
    // ═══════════════════════════════════════════════════════════════
    private float  orbitAngle       = 0f;
    private float  targetLastHp     = -1f;
    private int    antiTotemThrows  = 0; // сколько осталось anti-totem бросков
    private int    meleeHitCount    = 0;
    private boolean critPending     = false;

    // PotionPredict — детект питья зелий целью
    private final PotionPredict potionPredict;

    // ═══════════════════════════════════════════════════════════════
    //  Конструктор
    // ═══════════════════════════════════════════════════════════════
    public PotLogic(BotEntity bot) {
        this.bot          = bot;
        this.strafe       = new StrafeAI(bot);
        this.wTap         = new WTapLogic(bot);
        this.potionPredict = new PotionPredict(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Главный тик
    // ═══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { phase = Phase.APPROACH; return; }

        // ── Таймеры ──────────────────────────────────────────────
        tickTimers();

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Баффы всегда активны ─────────────────────────────────
        applyBuffs();

        // ── Тотем в оффхенд ──────────────────────────────────────
        ensureTotem();

        // ── PotionPredict: следим за питьём зелий целью ──────────
        potionPredict.tick(target);

        // ── Приоритет: retreat при критическом HP ─────────────────
        if (myHp <= RETREAT_HP && phase != Phase.RETREAT) {
            phase = Phase.RETREAT;
            retreatTimer = RETREAT_TICKS;
        }

        // ── AntiTotem: детект pop у цели ──────────────────────────
        tickAntiTotem(sw, target, dist);

        // ── Dual-throw: задержанный slowness ──────────────────────
        if (dualDelayTimer > 0) {
            dualDelayTimer--;
            if (dualDelayTimer == 0 && slownessCd <= 0 && dist <= SLOWNESS_RANGE) {
                throwSplash(sw, target, MobEffects.MOVEMENT_SLOWDOWN, 140, 1, 5.0f);
                slownessCd = SLOWNESS_CD;
                log("§7[Pot] Slowness кинут (dual)");
            }
        }

        // ── Экстренное лечение (любая фаза) ──────────────────────
        if (myHp <= CRIT_HEAL_HP && healCd <= 0) {
            selfHeal(sw);
        }

        // ── Фазовый автомат ──────────────────────────────────────
        switch (phase) {
            case APPROACH    -> tickApproach(sw, target, dist, myHp);
            case KITE        -> tickKite(sw, target, dist, myHp);
            case RUSH        -> tickRush(sw, target, dist);
            case CRIT_FINISH -> tickCritFinish(sw, target, dist, myHp);
            case RETREAT     -> tickRetreat(sw, target, dist, myHp);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  APPROACH: сближение к цели
    // ═══════════════════════════════════════════════════════════════
    private void tickApproach(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        if (dist <= ENGAGE_DIST) {
            phase = Phase.KITE;
            log("§e[Pot] Вошли → KITE");
            return;
        }

        bot.setSprinting(true);
        bot.getNavigation().moveTo(target, 1.4);

        // Жемчуг если очень далеко
        if (dist > APPROACH_DIST && pearlCd <= 0) {
            doPearl(sw, target);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  KITE: основная боевая фаза
    // ═══════════════════════════════════════════════════════════════
    private void tickKite(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        // Ушли далеко — возвращаемся к сближению
        if (dist > ENGAGE_DIST + 3.0) {
            phase = Phase.APPROACH;
            return;
        }

        // Переход в CRIT_FINISH если HP цели низкий
        if (target.getHealth() <= FINISH_TARGET_HP) {
            phase = Phase.CRIT_FINISH;
            log("§c[Pot] Цель слаба → CRIT_FINISH");
            return;
        }

        // CounterHeal rush: цель пьёт зелье → атакуем немедленно
        if (potionPredict.isVulnerable() && rushTimer <= 0) {
            phase = Phase.RUSH;
            rushTimer = RUSH_TICKS;
            potionPredict.onRushAttack();
            log("§6[Pot] CounterHeal! Rush →");
            return;
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Движение: орбита + страф ─────────────────────────────
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive) {
            updateOrbit(target, dist);
            if (dist < OPTIMAL_DIST + 1.2 && cfg.strafeEnabled) strafe.tick(target);
        }

        // ── Лечение себя при низком HP ───────────────────────────
        if (myHp < HEAL_THRESHOLD && healCd <= 0) {
            selfHeal(sw);
        }

        // ── Weakness против щита ─────────────────────────────────
        if (target.isBlocking() && weaknessCd <= 0 && dist <= SPLASH_RANGE) {
            throwSplash(sw, target, MobEffects.WEAKNESS, 120, 0, dist <= 3.0 ? 3.0f : 5.0f);
            weaknessCd = WEAKNESS_CD;
            log("§7[Pot] Weakness на щит");
        }

        // ── Slowness при побеге цели ─────────────────────────────
        boolean targetFleeing = dist > OPTIMAL_DIST + 1.5
            && target.getDeltaMovement().horizontalDistanceSqr() > 0.06;
        if (targetFleeing && slownessCd <= 0 && dist <= SLOWNESS_RANGE) {
            throwSplash(sw, target, MobEffects.MOVEMENT_SLOWDOWN, 160, 1, 6.0f);
            slownessCd = SLOWNESS_CD;
            log("§7[Pot] Slowness (побег)");
        }

        // ── Harming: бросаем на предсказанную позицию ─────────────
        if (dist <= SPLASH_RANGE && harmingCd <= 0 && !wTapActive) {
            Vec3 aimPos = computeAimPos(target, dist);
            if (bot.position().distanceTo(aimPos) <= SPLASH_RANGE + 0.5) {
                throwHarming(sw, target, aimPos);
                harmingCd = HARMING_CD;
                // Dual-throw: Slowness через DUAL_DELAY тиков
                if (slownessCd <= 0 && dualDelayTimer <= 0 && dist <= SLOWNESS_RANGE) {
                    dualDelayTimer = DUAL_DELAY;
                }
            }
        }

        // ── Меч между зельями ─────────────────────────────────────
        if (dist <= MELEE_RANGE && meleeCd <= 0 && harmingCd > HARMING_CD / 2 && !wTapActive) {
            doMeleeHit(sw, target, false);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  RUSH: burst атака пока цель уязвима
    // ═══════════════════════════════════════════════════════════════
    private void tickRush(ServerLevel sw, LivingEntity target, double dist) {
        rushTimer--;

        // Сближаемся плотно
        if (dist > RUSH_DIST) {
            bot.setSprinting(true);
            bot.getNavigation().moveTo(target, 1.5);
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Harming если в зоне
        if (dist <= SPLASH_RANGE && harmingCd <= 0) {
            throwHarming(sw, target, target.position());
            harmingCd = HARMING_CD;
        }

        // Мечом пока в дистанции
        if (dist <= MELEE_RANGE && meleeCd <= 0) {
            doMeleeHit(sw, target, false);
        }

        if (rushTimer <= 0 || !potionPredict.isVulnerable()) {
            phase = Phase.KITE;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  CRIT_FINISH: добиваем слабую цель
    // ═══════════════════════════════════════════════════════════════
    private void tickCritFinish(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        // Цель подлечилась — назад в KITE
        if (target.getHealth() > FINISH_TARGET_HP + 2.0f) {
            phase = Phase.KITE;
            return;
        }
        // Наш HP упал — retreat
        if (myHp <= RETREAT_HP) {
            phase = Phase.RETREAT;
            retreatTimer = RETREAT_TICKS;
            return;
        }

        // Плотно сближаемся
        if (dist > FINISH_RANGE) {
            bot.setSprinting(true);
            bot.getNavigation().moveTo(target, 1.4);
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Harming без остановки — спамим
        if (dist <= SPLASH_RANGE && harmingCd <= 0) {
            throwHarming(sw, target, computeAimPos(target, dist));
            harmingCd = HARMING_CD / 2; // ускоренный кастинг
        }

        // Крит-удар каждые N ударов
        if (dist <= MELEE_RANGE && meleeCd <= 0) {
            boolean doCrit = (meleeHitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                meleeCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doMeleeHit(sw, target, true);
            } else if (!doCrit && !critPending) {
                doMeleeHit(sw, target, false);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  RETREAT: зигзаг + лечение + жемчуг
    // ═══════════════════════════════════════════════════════════════
    private void tickRetreat(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        retreatTimer--;

        // Зигзаг-отступление
        Vec3 away = bot.position().subtract(target.position()).normalize();
        double zigzag = (retreatTimer % 18 < 9) ? 1.4 : -1.4;
        Vec3 perp = new Vec3(-away.z, 0, away.x).scale(zigzag);
        Vec3 dest = bot.position().add(away.scale(7)).add(perp);
        bot.setSprinting(true);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.4);

        // Лечение под ногами во время бегства
        if (healCd <= 0) {
            selfHeal(sw);
        }

        // Жемчуг если цель вплотную
        if (dist < 4.0 && pearlCd <= 0) {
            doPearl(sw, target);
        }

        // Восстановились — назад в бой
        if ((myHp >= RECOVER_HP || retreatTimer <= 0) && myHp > RETREAT_HP) {
            phase = Phase.APPROACH;
            log("§b[Pot] Восстановились → APPROACH (HP: " + String.format("%.1f", myHp) + ")");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  AntiTotem: детект pop → burst зелий
    // ═══════════════════════════════════════════════════════════════
    private void tickAntiTotem(ServerLevel sw, LivingEntity target, double dist) {
        float currentHp = target.getHealth();

        // Pop: было ≤ 1.2, стало > 1.5 (тотем сработал)
        if (targetLastHp > 0 && targetLastHp <= 1.2f && currentHp > 1.5f) {
            antiTotemThrows = 3;
            log("§d[Pot] AntiTotem! 3 зелья подряд");
        }

        // Burst бросков
        if (antiTotemThrows > 0 && antiTotemCd <= 0 && dist <= SPLASH_RANGE) {
            if (phase != Phase.RETREAT) {
                throwHarming(sw, target, computeAimPos(target, dist));
                harmingCd = 0; // сбрасываем кулдаун для следующего burst
                antiTotemCd = ANTI_TOTEM_CD;
                antiTotemThrows--;
                log("§d[Pot] AntiTotem burst! (" + antiTotemThrows + " осталось)");
            }
        }
        if (antiTotemCd > 0) antiTotemCd--;

        targetLastHp = currentHp;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Орбита вокруг цели
    // ═══════════════════════════════════════════════════════════════
    private void updateOrbit(LivingEntity target, double dist) {
        if (orbitCd > 0) return;
        orbitCd = ORBIT_CD;

        orbitAngle += (float)(Math.PI * 0.28);

        if (dist > SPLASH_RANGE + 0.5) {
            // Слишком далеко — сближаемся
            bot.getNavigation().moveTo(target, 1.2);
        } else if (dist < OPTIMAL_DIST - 0.5) {
            // Слишком близко — отступаем (дистанция для нормального броска)
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 2.5,
                bot.getY(),
                bot.getZ() + away.z * 2.5, 1.1);
        } else {
            // Орбита вокруг цели
            double tx = target.getX() + Math.cos(orbitAngle) * OPTIMAL_DIST;
            double tz = target.getZ() + Math.sin(orbitAngle) * OPTIMAL_DIST;
            bot.getNavigation().moveTo(tx, target.getY(), tz, 1.05);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Броски
    // ═══════════════════════════════════════════════════════════════

    /** Splash Instant Damage II на цель (или предсказанную позицию) */
    private void throwHarming(ServerLevel sw, LivingEntity target, Vec3 aimPos) {
        float mainDmg = 12.0f; // Instant Damage II baseline

        if (target.isAlive())
            target.hurt(sw.damageSources().magic(), mainDmg);

        // AoE: 50% урона другим в радиусе 2.5
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(aimPos, aimPos).inflate(2.5),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().magic(), mainDmg * 0.5f));

        sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
            aimPos.x, aimPos.y + 0.5, aimPos.z, 18, 0.5, 0.5, 0.5, 0.1);
        bot.playSound(SoundEvents.SPLASH_POTION_BREAK, 1.0f, 1.3f);

        HitHighlightTracker.INSTANCE.onHit(target.getId());
        bot.getHeatMap().recordDamageDealt(bot.position(), mainDmg);

        log(String.format("§c[Pot] Harming! §e%.1f dmg §7(dist %.1f)", mainDmg, bot.distanceTo(target)));
    }

    /** Splash Instant Health II под себя */
    private void selfHeal(ServerLevel sw) {
        bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 1));        // Instant Health II
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 0)); // Absorption I

        sw.sendParticles(
            ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 1.0f, 0.2f, 0.2f),
            bot.getX(), bot.getY() + 0.5, bot.getZ(), 14, 0.3, 0.3, 0.3, 0.05);
        bot.playSound(SoundEvents.SPLASH_POTION_BREAK, 0.9f, 1.5f);

        healCd = HEAL_CD;
        log(String.format("§a[Pot] Хил! HP: %.1f", bot.getHealth()));
    }

    /** Вспомогательный бросок сплэш-эффекта (slowness, weakness и т.д.) */
    private void throwSplash(ServerLevel sw, LivingEntity target,
                              net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effectHolder,
                              int duration, int amplifier, float radius) {
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(radius),
            e -> e != bot && e.isAlive()
        ).forEach(e -> e.addEffect(new MobEffectInstance(effectHolder, duration, amplifier)));

        sw.sendParticles(
            ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 0.5f, 0.1f, 0.8f),
            target.getX(), target.getY() + 0.5, target.getZ(), 10, 0.4, 0.4, 0.4, 0.05);
        bot.playSound(SoundEvents.SPLASH_POTION_BREAK, 0.8f, 0.8f);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ближний бой
    // ═══════════════════════════════════════════════════════════════
    private void doMeleeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (!(bot.level() instanceof ServerLevel)) return;
        if (!target.isAlive()) return;

        equipSword();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        bot.doHurtTarget(sw, target);

        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 8, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
            critPending = false;
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }

        meleeHitCount++;
        meleeCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : MELEE_CD;

        if (cfg.wTapEnabled) wTap.onAttack();
        bot.getHeatMap().recordDamageDealt(bot.position(), 7.0f);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Вспомогательные методы
    // ═══════════════════════════════════════════════════════════════

    /**
     * Вычисляем цель для броска зелья:
     * - Если цель медленная → бросаем на текущую позицию
     * - Иначе → PatternAI предсказывает позицию через ~4 тика
     */
    private Vec3 computeAimPos(LivingEntity target, double dist) {
        boolean targetSlow = target.getDeltaMovement().horizontalDistanceSqr() < 0.025;
        if (targetSlow) return target.position();
        // Патч: PatternAI если есть, иначе линейное упреждение
        if (bot.getPatternAI() != null) {
            return bot.getPatternAI().getPredictedPosition(target);
        }
        float lead = (float)(dist / 9.0) * 4f;
        Vec3 vel   = target.getDeltaMovement();
        return target.position().add(vel.scale(lead));
    }

    /** Жемчуг-gap close (симуляция: быстро движемся к цели) */
    private void doPearl(ServerLevel sw, LivingEntity target) {
        Vec3 dir  = target.position().subtract(bot.position()).normalize();
        Vec3 dest = bot.position().add(dir.scale(11.0));
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.6);
        sw.sendParticles(ParticleTypes.PORTAL,
            bot.getX(), bot.getY() + 1, bot.getZ(), 18, 0.5, 0.5, 0.5, 0.3);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
        pearlCd = PEARL_CD;
    }

    private void applyBuffs() {
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); // Speed II
            speedCd = SPEED_CD;
        }
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1)); // Strength II
            strCd = STR_CD;
        }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }
    }

    private void ensureTotem() {
        var offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (offhand.isEmpty() || !offhand.is(Items.TOTEM_OF_UNDYING)) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness", 5)
                    .enchant("knockback", 1)
                    .build());
        }
    }

    private void tickTimers() {
        if (harmingCd    > 0) harmingCd--;
        if (healCd       > 0) healCd--;
        if (slownessCd   > 0) slownessCd--;
        if (weaknessCd   > 0) weaknessCd--;
        if (meleeCd      > 0) meleeCd--;
        if (orbitCd      > 0) orbitCd--;
        if (speedCd      > 0) speedCd--;
        if (strCd        > 0) strCd--;
        if (fireResCd    > 0) fireResCd--;
        if (pearlCd      > 0) pearlCd--;
        if (rushTimer    > 0) rushTimer--;
    }

    private void log(String msg) {
        if (bot.getOwner() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    // ═══════════════════════════════════════════════════════════════
    //  HUD
    // ═══════════════════════════════════════════════════════════════
    public String getPhaseLabel() {
        return switch (phase) {
            case APPROACH    -> "POT:MOVE";
            case KITE        -> "POT:KITE" + (antiTotemThrows > 0 ? " §dAT!" : "");
            case RUSH        -> "POT:RUSH " + rushTimer + "t";
            case CRIT_FINISH -> "POT:FINISH §c!!";
            case RETREAT     -> "POT:FLEE " + retreatTimer + "t";
        };
    }
}
