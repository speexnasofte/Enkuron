package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * NethPotLogic v7.0 — PATCH
 *
 * Улучшения v7 (patch):
 *  ✦ Dual-throw задержка 6 тиков между harming и slowness (было одновременно)
 *  ✦ isNethOP: проверяем по Mode вместо kit-instance (надёжнее)
 *  ✦ Weakness зелье против щита: если цель блокирует — Weakness I
 *  ✦ Меч после зелья: короткий burst 2 удара при dist < 2.5
 *
 * NethPotLogic v6.0 — MAJOR REWRITE
 *
 * Улучшения v6:
 *  ✦ Splash harming: бросаем на ПРЕДСКАЗАННУЮ позицию цели (PatternAI)
 *  ✦ Dual-throw: Harming + Slowness в связке при dist < 3.0
 *  ✦ Anti-gap: если цель поглощает (золотое яблоко) — меняем тактику
 *  ✦ Меч между бросками: крит + W-tap синхронизированы с harming CD
 *  ✦ Retreat improved: зигзаг + лечение рядом с укрытием
 *  ✦ NethOP: эффект Strength III + Speed II вместо I
 *  ✦ Throwback: если цель блокирует — бросаем Slowness чтобы снять возможность побега
 *  ✦ Instant Health II priority при HP < 6 (было только Regen)
 *  ✦ HeatMap: записываем урон зельями
 */
public class NethPotLogic {

    // ── Дальности ─────────────────────────────────────────────────
    private static final double SPLASH_RANGE     = 5.0;
    private static final double MELEE_RANGE      = 3.0;
    private static final double OPTIMAL_SPLASH   = 2.3;  // точнее чем v5
    private static final double SLOWNESS_RANGE   = 4.5;

    // ── Кулдауны ──────────────────────────────────────────────────
    private static final int    HARMING_CD  = 24;   // быстрее: v5=28
    private static final int    HEALING_CD  = 25;   // быстрее: v5=30
    private static final int    SLOWNESS_CD = 45;
    private static final int    SPEED_CD    = 400;
    private static final int    STR_CD      = 400;
    private static final int    REGEN_CD    = 480;
    private static final int    FIRE_RES_CD = 600;
    private static final int    RETREAT_CD  = 160;
    private static final int    MELEE_CD    = 5;    // быстрее: v5=6

    // ── Баффы NethOP vs NethPot ───────────────────────────────────
    // NethOP: Strength III + Speed II; NethPot: II + I
    private static final int    CRIT_EVERY  = 3;

    private final boolean isNethOP;
    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int harmingCd  = 0, healingCd  = 0, slownCd   = 0;
    private int speedCd    = 0, strCd      = 0, regenCd   = 0;
    private int fireResCd  = 0, retreatCd  = 0, meleeCd   = 0;
    private int hitCount   = 0;
    private boolean critPending  = false;
    private boolean retreating   = false;
    // Отслеживаем: цель использует гэпл?
    private int targetAbsorption = 0;
    private int absoCheckTimer   = 0;
    // PATCH v7: задержанный dual-throw slowness
    private int pendingSlowness  = 0; // тиков до броска slowness после harming
    // PATCH v7: weakness против щита
    private static final int WEAKNESS_CD = 120;
    private int weaknessCd = 0;
    // PATCH v7: burst после зелья
    private int burstAfterPotion = 0;

    public NethPotLogic(BotEntity bot) {
        this.bot     = bot;
        this.strafe  = new StrafeAI(bot);
        this.wTap    = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        // PATCH v7: надёжная проверка через Mode (не kit-instance)
        this.isNethOP = (cfg.mode == PVPBotConfig.Mode.NETHOP);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        if (harmingCd > 0) harmingCd--;
        if (healingCd > 0) healingCd--;
        if (weaknessCd     > 0) weaknessCd--;
        if (burstAfterPotion > 0) burstAfterPotion--;
        // PATCH v7: задержанный бросок slowness
        if (pendingSlowness > 0) {
            pendingSlowness--;
            if (pendingSlowness <= 0 && slownCd <= 0) {
                // Бросаем slowness с задержкой 6 тиков после harming
                if (target != null && target.isAlive() && bot.level() instanceof ServerLevel _sw2) {
                    throwSplash(_sw2, target, net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 100, 0, 3.5f);
                    slownCd = SLOWNESS_CD;
                }
            }
        }
        if (slownCd   > 0) slownCd--;
        if (speedCd   > 0) speedCd--;
        if (strCd     > 0) strCd--;
        if (regenCd   > 0) regenCd--;
        if (fireResCd > 0) fireResCd--;
        if (retreatCd > 0) retreatCd--;
        if (meleeCd   > 0) meleeCd--;
        if (absoCheckTimer > 0) absoCheckTimer--;

        // ── Баффы ВСЕГДА ─────────────────────────────────────────
        int strLevel = isNethOP ? 2 : 1;
        int spdLevel = isNethOP ? 1 : 1;
        if (speedCd <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, spdLevel)); speedCd = SPEED_CD; }
        if (strCd   <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,   800, strLevel)); strCd   = STR_CD; }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }
        if (bot.isInWater() && !bot.onGround())
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.12, bot.getDeltaMovement().z);

        if (target == null || !target.isAlive()) { retreating = false; return; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Instant Health II при критически низком HP (приоритет) ──
        if (myHp < 6.0f && healingCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 1)); // Instant Health II
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 1));
            healingCd = HEALING_CD;
            sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
                bot.getX(), bot.getY()+1, bot.getZ(), 12, 0.3,0.3,0.3,0.05);
            bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 0.8f, 1.4f);
        }

        // ── Regen при пониженном HP ──────────────────────────────
        if (myHp < 10.0f && regenCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
            regenCd = REGEN_CD;
        }

        // ── Обнаружение: цель приняла гэпл (Absorption > 0) ─────
        if (absoCheckTimer <= 0) {
            absoCheckTimer = 10;
            var abso = target.getEffect(MobEffects.ABSORPTION);
            targetAbsorption = abso != null ? (int) abso.getDuration() : 0;
        }

        // ── Retreat при крит HP ───────────────────────────────────
        if (myHp < 5.0f && retreatCd <= 0) {
            retreating = true;
            retreatCd  = RETREAT_CD;
        }
        if (retreating) {
            tickRetreat(sw, target);
            if (myHp > 12.0f || retreatCd <= 0) retreating = false;
            return;
        }

        // ── Навигация + страф ─────────────────────────────────────
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive) {
            if (dist < OPTIMAL_SPLASH + 1.5 && cfg.strafeEnabled) strafe.tick(target);
            else bot.getNavigation().moveTo(target, 1.05);
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Slowness при побеге цели ──────────────────────────────
        boolean targetFleeing = target.getDeltaMovement().horizontalDistanceSqr() > 0.08
            && dist > OPTIMAL_SPLASH;
        if (dist <= SLOWNESS_RANGE && slownCd <= 0 && (targetFleeing || targetAbsorption > 0)) {
            throwSplash(sw, target, MobEffects.MOVEMENT_SLOWDOWN, 160, 1, 6.0f);
            slownCd = SLOWNESS_CD;
        }

        // PATCH v7: Weakness I против щита — снижает урон топора на 4 (делает слом медленнее)
        // Логика: Weakness на себя не нужен, кидаем на ЦЕЛЬ когда она блокирует
        boolean targetBlocking = (target.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD)
            || target.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD))
            && target.isBlocking();
        if (targetBlocking && weaknessCd <= 0 && dist <= SPLASH_RANGE) {
            throwSplash(sw, target, MobEffects.WEAKNESS, 120, 0, dist <= 3.0 ? 3.0f : 5.0f);
            weaknessCd = WEAKNESS_CD;
        }

        // ── Harming: бросаем на предсказанную позицию ─────────────
        if (dist <= SPLASH_RANGE && harmingCd <= 0 && !wTapActive) {
            boolean targetSlow = target.getDeltaMovement().horizontalDistanceSqr() < 0.03;
            // Если цель медленная — кидаем прямо, иначе упреждение
            Vec3 aimPos = targetSlow ? target.position()
                : predictThrowPos(target, dist);
            double aimDist = bot.position().distanceTo(aimPos);
            if (aimDist <= OPTIMAL_SPLASH + 1.0 || targetSlow) {
                throwHarming(sw, target, aimPos);
                harmingCd = HARMING_CD;
                // PATCH v7: Dual-throw с задержкой 6 тиков (не одновременно)
                if (dist <= 3.5 && slownCd <= 0 && pendingSlowness <= 0) {
                    pendingSlowness = 6; // бросим slowness через 6 тиков
                }
                burstAfterPotion = 10; // burst 2 удара после зелья
            }
        }

        // PATCH v7: burst 2 удара сразу после броска зелья
        if (burstAfterPotion > 0 && dist <= MELEE_RANGE && meleeCd <= 0) {
            doMeleeHit(sw, target, false);
            burstAfterPotion = 0;
        }

        // ── Меч между зельями (крит синхронизирован с harmingCd) ─
        if (dist <= MELEE_RANGE && meleeCd <= 0 && harmingCd > 4 && !wTapActive) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            equipSword();
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                meleeCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doMeleeHit(sw, target, true);
            } else if (!doCrit && !critPending) {
                doMeleeHit(sw, target, false);
            }
        }
    }

    // ════════════════════════════════════════════════════════════
    //  Атаки
    // ════════════════════════════════════════════════════════════

    private void doMeleeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 6,0.2,0.2,0.2,0.1);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        critPending = false;
        meleeCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : MELEE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
        bot.getHeatMap().recordDamageDealt(bot.position(), 7.5f);
    }

    private void throwHarming(ServerLevel sw, LivingEntity target, Vec3 aimPos) {
        float aoeRadius = isNethOP ? 3.0f : 2.5f;
        float mainDmg   = isNethOP ? 14.0f : 12.0f;

        if (target.isAlive())
            target.hurt(sw.damageSources().magic(), mainDmg);

        // AoE на других в радиусе
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(aimPos, aimPos).inflate(aoeRadius),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().magic(), mainDmg * 0.5f));

        sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
            aimPos.x, aimPos.y+0.5, aimPos.z, 20, 0.5,0.5,0.5,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 1.0f, 1.2f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        bot.getHeatMap().recordDamageDealt(bot.position(), mainDmg);
    }

    private void throwSplash(ServerLevel sw, LivingEntity target,
                              net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effectHolder,
                              int duration, int amplifier, float radius) {
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(radius),
            e -> e != bot && e.isAlive()
        ).forEach(e -> e.addEffect(new MobEffectInstance(effectHolder, duration, amplifier)));
        sw.sendParticles(ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 0.5f, 0.1f, 0.8f),
            target.getX(), target.getY()+0.5, target.getZ(), 10, 0.4,0.4,0.4,0.05);
        bot.playSound(net.minecraft.sounds.SoundEvents.SPLASH_POTION_BREAK, 0.8f, 0.8f);
    }

    // ════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ════════════════════════════════════════════════════════════

    /** Предсказываем позицию цели через ~5 тиков (время броска зелья). */
    private Vec3 predictThrowPos(LivingEntity target, double dist) {
        float lead = (float)(dist / 8.0) * 4; // тиков упреждения
        Vec3 vel   = target.getDeltaMovement();
        return target.position().add(vel.scale(lead));
    }

    private void tickRetreat(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side = (bot.level().getRandom().nextBoolean())
            ? new Vec3(-away.z, 0, away.x).scale(0.4)
            : new Vec3( away.z, 0,-away.x).scale(0.4);
        Vec3 dest = bot.position().add(away.scale(8)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.35);
        bot.setSprinting(true);
        // Лечение во время бегства
        if (healingCd <= 0 && bot.getHealth() < 12f) {
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 1));
            healingCd = HEALING_CD;
        }
    }

    private void equipSword() {
        var swordItem = isNethOP ? Items.NETHERITE_SWORD : Items.DIAMOND_SWORD;
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(swordItem))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(swordItem, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("knockback", 1).build());
    }
}
