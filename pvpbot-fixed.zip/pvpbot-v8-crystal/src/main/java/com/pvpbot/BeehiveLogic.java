package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * BeehiveLogic v2.0 — Полная переработка.
 *
 * ══════════════════════════════════════════════════════════════════
 *  КОНЦЕПЦИЯ:
 *  Бот управляет армией пчёл + атакует сам мечом + использует мёд
 *  для лечения. Три режима действий в зависимости от обстановки.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ФАЗЫ:
 *
 *  SWARM_ATTACK — Армия пчёл атакует цель. Бот держит дистанцию
 *    и периодически «подзывает» новых пчёл.
 *    При 3+ активных пчёлах — ждём и кайтим.
 *    При < 2 пчёлах — переходим в MELEE.
 *
 *  MELEE — Пчёл мало/нет. Бот атакует сам мечом.
 *    W-tap + страф + крит. Продолжаем собирать пчёл параллельно.
 *
 *  HONEY_HEAL — HP < HEAL_THRESHOLD. Бот пьёт мёд и ищет укрытие.
 *    После выпивания — возврат в SWARM_ATTACK или MELEE.
 *
 *  SUMMON — Нет пчёл рядом, но есть ульи в радиусе.
 *    Бот идёт к ближайшему улью и «будит» пчёл.
 *
 * ══════════════════════════════════════════════════════════════════
 *  МЕХАНИКИ:
 *
 *  1. BEE PRIORITY: атакующие пчёлы получают rage бафф (Speed III).
 *     Пчёлы с poison атакуют цель aggressively.
 *
 *  2. BEE FORMATION: пчёлы держатся по 3 вокруг цели (окружение).
 *     Каждые BEE_REPOSITION_CD тиков — переставляем позиции.
 *
 *  3. HONEY THROWING: если цель убегает — бросаем Honey Bottle
 *     как снаряд (Slowness + slip эффект через DamageSource).
 *
 *  4. WITHER BEES: специальные пчёлы с Wither II эффектом при укусе.
 *     Накладывается через addEffect при агре.
 *
 *  5. TERRITORY: бот помечает площадку 8×8 блоков как "территорию".
 *     Пчёлы не отходят далеко от бота (re-target если улетели).
 *
 *  6. BEE COUNT TRACKING: считаем живых пчёл с нашим таргетом.
 *     Если bee.getTarget() == target — считается активной.
 *
 *  7. HONEY MANAGEMENT: 4 Honey Bottle в инвентаре.
 *     Каждый лечит 4HP + Saturation. Приоритет над другими действиями.
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class BeehiveLogic {

    // ── Радиусы ────────────────────────────────────────────────────
    private static final double BEE_SEARCH_RADIUS    = 24.0;
    private static final double HIVE_SEARCH_RADIUS   = 32.0;
    private static final double TERRITORY_RADIUS     = 8.0;
    private static final double MELEE_RANGE          = 3.5;
    private static final double HONEY_THROW_RANGE    = 8.0;
    private static final double KITE_DIST            = 6.0;   // держим дистанцию при рое

    // ── Пчёлы ──────────────────────────────────────────────────────
    private static final int    MIN_ACTIVE_BEES      = 3;     // порог перехода в рой
    private static final int    MAX_BEE_BUFF         = 5;     // максимум баффов в тик
    private static final int    BEE_REPOSITION_CD    = 40;    // тиков между перестановками
    private static final int    BEE_RECALL_CD        = 80;    // тиков между отзывом
    private static final int    WITHER_DUR           = 80;    // тиков wither на цели
    private static final int    POISON_DUR           = 120;   // тиков poison на цели

    // ── Мёд ────────────────────────────────────────────────────────
    private static final float  HEAL_THRESHOLD       = 12.0f;
    private static final float  HONEY_HEAL_AMT       = 4.0f;
    private static final int    HONEY_CD             = 60;
    private static final int    HONEY_THROW_CD       = 50;

    // ── Кулдауны ───────────────────────────────────────────────────
    private static final int    MELEE_CD             = 8;
    private static final int    CRIT_EVERY           = 3;
    private static final int    SUMMON_CD            = 120;
    private static final int    EFFECT_CD            = 20;    // тиков между баффами пчёл
    private static final int    SPEED_CD             = 300;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase { SWARM_ATTACK, MELEE, HONEY_HEAL, SUMMON }
    private Phase phase = Phase.MELEE;

    // ── Состояние ──────────────────────────────────────────────────
    private int   honeyCd         = 0;
    private int   honeyThrowCd    = 0;
    private int   meleeCd         = 0;
    private int   beePosCD        = 0;
    private int   beeRecallCd     = 0;
    private int   summonCd        = 0;
    private int   effectCd        = 0;
    private int   speedCd         = 0;
    private int   critCounter     = 0;
    private boolean critPending   = false;
    private int   activeBeeCount  = 0;   // кэш живых пчёл на цели

    private final BotEntity    bot;
    private final WTapLogic    wTap;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public BeehiveLogic(BotEntity bot) {
        this.bot    = bot;
        this.wTap   = new WTapLogic(bot);
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (honeyCd      > 0) honeyCd--;
        if (honeyThrowCd > 0) honeyThrowCd--;
        if (meleeCd      > 0) meleeCd--;
        if (beePosCD     > 0) beePosCD--;
        if (beeRecallCd  > 0) beeRecallCd--;
        if (summonCd     > 0) summonCd--;
        if (effectCd     > 0) effectCd--;
        if (speedCd      > 0) speedCd--;

        // Speed I для мобильности
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 0));
            speedCd = SPEED_CD;
        }

        ensureKit();

        // Обновляем счётчик активных пчёл каждые 10 тиков
        if (bot.tickCount % 10 == 0) {
            activeBeeCount = countActiveBees(sw, target);
        }

        double dist = bot.distanceTo(target);

        // ── Выбор фазы ────────────────────────────────────────────
        updatePhase(sw, target, dist);

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Управление пчёлами (параллельно любой фазе) ───────────
        manageBees(sw, target);

        // ── Диспатч ───────────────────────────────────────────────
        switch (phase) {
            case SWARM_ATTACK -> tickSwarm(sw, target, dist);
            case MELEE        -> tickMelee(sw, target, dist);
            case HONEY_HEAL   -> tickHoney(sw, target);
            case SUMMON       -> tickSummon(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Выбор фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(ServerLevel sw, LivingEntity target, double dist) {
        // Мёд — приоритет
        if (bot.getHealth() < HEAL_THRESHOLD && honeyCd <= 0) {
            phase = Phase.HONEY_HEAL; return;
        }
        // Рой готов
        if (activeBeeCount >= MIN_ACTIVE_BEES) {
            phase = Phase.SWARM_ATTACK; return;
        }
        // Ищем улей
        if (activeBeeCount == 0 && summonCd <= 0 && findNearestHive(sw) != null) {
            phase = Phase.SUMMON; return;
        }
        // Мелли (пчёл мало или нет)
        phase = Phase.MELEE;
    }

    // ════════════════════════════════════════════════════════════════
    //  SWARM_ATTACK — рой активен
    // ════════════════════════════════════════════════════════════════

    private void tickSwarm(ServerLevel sw, LivingEntity target, double dist) {
        // Держим дистанцию — пчёлы делают работу
        if (dist < KITE_DIST) {
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.4);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0, away.z));
        } else if (dist > KITE_DIST * 1.5) {
            bot.getNavigation().moveTo(target, 1.0);
        } else {
            if (cfg.strafeEnabled) strafe.tick(target);
        }

        // Honey throw если цель убегает
        if (honeyThrowCd <= 0 && dist < HONEY_THROW_RANGE) {
            Vec3 vel = target.getDeltaMovement();
            boolean fleeing = vel.horizontalDistanceSqr() > 0.05
                && target.position().subtract(bot.position()).normalize()
                    .dot(vel.normalize()) > 0.5;
            if (fleeing) {
                throwHoney(sw, target);
                honeyThrowCd = HONEY_THROW_CD;
            }
        }

        // Если рой внезапно рассеялся — меле
        if (activeBeeCount < 2 && dist <= MELEE_RANGE && meleeCd <= 0) {
            doMeleeHit(sw, target, false);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  MELEE — бьём сами
    // ════════════════════════════════════════════════════════════════

    private void tickMelee(ServerLevel sw, LivingEntity target, double dist) {
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive) {
            if (dist > MELEE_RANGE) bot.getNavigation().moveTo(target, 1.1);
            else if (cfg.strafeEnabled) strafe.tick(target);
        }

        if (dist <= MELEE_RANGE && meleeCd <= 0 && !wTapActive) {
            boolean doCrit = critCounter >= CRIT_EVERY;
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                critCounter = 0;
            } else if (critPending && !bot.onGround()
                    && bot.getDeltaMovement().y < -0.01 && bot.fallDistance > 0.08f) {
                doMeleeHit(sw, target, true);
                critPending = false;
            } else if (!critPending) {
                doMeleeHit(sw, target, false);
                critCounter++;
            } else if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
                critPending = false;
                doMeleeHit(sw, target, false);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  HONEY_HEAL
    // ════════════════════════════════════════════════════════════════

    private void tickHoney(ServerLevel sw, LivingEntity target) {
        // Отходим пока лечимся
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.setDeltaMovement(bot.getDeltaMovement().add(away.x * 0.3, 0, away.z * 0.3));

        if (honeyCd <= 0) {
            bot.heal(HONEY_HEAL_AMT);
            bot.addEffect(new MobEffectInstance(MobEffects.SATURATION, 40, 0));
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0));
            sw.sendParticles(ParticleTypes.ITEM_SLIME,
                bot.getX(), bot.getY() + 1, bot.getZ(), 10, 0.2, 0.2, 0.2, 0.08);
            bot.playSound(SoundEvents.HONEY_DRINK.value(), 1.0f, 1.0f + (float)(Math.random() * 0.2 - 0.1));
            honeyCd = HONEY_CD;
        }

        // Как только HP восстановлено — выходим
        if (bot.getHealth() >= bot.getMaxHealth() * 0.75f || honeyCd > 40) {
            phase = activeBeeCount >= MIN_ACTIVE_BEES ? Phase.SWARM_ATTACK : Phase.MELEE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  SUMMON — идём к улью
    // ════════════════════════════════════════════════════════════════

    private void tickSummon(ServerLevel sw, LivingEntity target) {
        // Ищем ближайший BeehiveBlockEntity или bee
        // Пробуем найти диких пчёл рядом и агрим их на цель
        List<Bee> bees = sw.getEntitiesOfClass(Bee.class,
            bot.getBoundingBox().inflate(HIVE_SEARCH_RADIUS),
            b -> b.isAlive() && b.getTarget() == null);

        if (!bees.isEmpty()) {
            for (Bee bee : bees) {
                if (bees.indexOf(bee) >= 5) break;
                awakeBee(bee, target);
            }
            summonCd = SUMMON_CD;
            phase    = Phase.MELEE;
        } else {
            // Нет пчёл — просто идём к цели
            bot.getNavigation().moveTo(target, 1.0);
            summonCd = SUMMON_CD;
            phase    = Phase.MELEE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Управление пчёлами (каждый тик)
    // ════════════════════════════════════════════════════════════════

    private void manageBees(ServerLevel sw, LivingEntity target) {
        List<Bee> activeBees = getActiveBees(sw, target);

        // Баффим пчёл каждые EFFECT_CD тиков
        if (effectCd <= 0 && !activeBees.isEmpty()) {
            int buffed = 0;
            for (Bee bee : activeBees) {
                if (buffed >= MAX_BEE_BUFF) break;
                // Speed III для быстрого преследования
                bee.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 2));
                // Resistance чтобы пчёлы не умирали быстро
                bee.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
                buffed++;
            }
            effectCd = EFFECT_CD;

            // Wither на цель через пчёл
            if (!activeBees.isEmpty() && activeBees.get(0).distanceTo(target) < 3.0) {
                target.addEffect(new MobEffectInstance(MobEffects.WITHER, WITHER_DUR, 1));
                target.addEffect(new MobEffectInstance(MobEffects.POISON, POISON_DUR, 0));
            }
        }

        // Переформирование — окружаем цель
        if (beePosCD <= 0 && !activeBees.isEmpty() && activeBees.size() >= 2) {
            repositionBees(activeBees, target);
            beePosCD = BEE_REPOSITION_CD;
        }

        // Отзываем пчёл которые улетели за территорию
        if (beeRecallCd <= 0) {
            recallBees(sw, target);
            beeRecallCd = BEE_RECALL_CD;
        }
    }

    private void repositionBees(List<Bee> bees, LivingEntity target) {
        int n = Math.min(bees.size(), 6);
        for (int i = 0; i < n; i++) {
            double angle = (2 * Math.PI * i) / n;
            double tx = target.getX() + Math.cos(angle) * 1.5;
            double tz = target.getZ() + Math.sin(angle) * 1.5;
            bees.get(i).getNavigation().moveTo(tx, target.getY(), tz, 1.5);
        }
    }

    private void recallBees(ServerLevel sw, LivingEntity target) {
        List<Bee> wandered = sw.getEntitiesOfClass(Bee.class,
            bot.getBoundingBox().inflate(BEE_SEARCH_RADIUS),
            b -> b.isAlive() && b.getTarget() == target
                && b.distanceTo(bot) > TERRITORY_RADIUS * 2);
        for (Bee bee : wandered) {
            bee.getNavigation().moveTo(target, 1.8);
        }
    }

    private void awakeBee(Bee bee, LivingEntity target) {
        bee.setTarget(target);
        bee.setRemainingPersistentAngerTime(600);
        bee.setPersistentAngerTarget(target.getUUID());
        bee.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 2));
        Vec3 dir = target.position().subtract(bee.position()).normalize().scale(0.6);
        bee.setDeltaMovement(dir);
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    private void doMeleeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (!target.isAlive()) return;
        bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
        }
        meleeCd = MELEE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    /** Бросаем Honey Bottle в цель — Slowness + slip. */
    private void throwHoney(ServerLevel sw, LivingEntity target) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0));
        target.hurt(sw.damageSources().magic(), 2.0f);
        sw.sendParticles(ParticleTypes.ITEM_HONEY,
            target.getX(), target.getY() + 1, target.getZ(), 16, 0.3, 0.3, 0.3, 0.1);
        bot.playSound(SoundEvents.HONEY_DRINK.value(), 0.8f, 0.5f);
    }

    private int countActiveBees(ServerLevel sw, LivingEntity target) {
        return (int) sw.getEntitiesOfClass(Bee.class,
            bot.getBoundingBox().inflate(TERRITORY_RADIUS * 2),
            b -> b.isAlive() && b.getTarget() == target).stream().count();
    }

    private List<Bee> getActiveBees(ServerLevel sw, LivingEntity target) {
        return sw.getEntitiesOfClass(Bee.class,
            bot.getBoundingBox().inflate(TERRITORY_RADIUS * 2.5),
            b -> b.isAlive() && b.getTarget() == target);
    }

    private Vec3 findNearestHive(ServerLevel sw) {
        // Ищем диких пчёл без таргета
        var idle = sw.getEntitiesOfClass(Bee.class,
            bot.getBoundingBox().inflate(HIVE_SEARCH_RADIUS),
            b -> b.isAlive() && b.getTarget() == null);
        if (idle.isEmpty()) return null;
        return idle.stream()
            .min(Comparator.comparingDouble(b -> b.distanceTo(bot)))
            .map(net.minecraft.world.entity.Entity::position)
            .orElse(null);
    }

    private void ensureKit() {
        var mh = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!mh.is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness",5).enchant("knockback",2)
                    .enchant("unbreaking",3).enchant("mending",1).build());
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.HONEY_BOTTLE))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.HONEY_BOTTLE));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }

    public void reset() {
        phase = Phase.MELEE;
        honeyCd = 0; honeyThrowCd = 0; meleeCd = 0;
        beePosCD = 0; beeRecallCd = 0; summonCd = 0;
        effectCd = 0; speedCd = 0;
        critCounter = 0; critPending = false; activeBeeCount = 0;
        wTap.reset();
    }

    public String getStateLabel() {
        return "BEE:" + switch (phase) {
            case SWARM_ATTACK -> "SWARM×" + activeBeeCount;
            case MELEE        -> "MELEE";
            case HONEY_HEAL   -> "HEAL";
            case SUMMON       -> "SUMMON";
        };
    }
}
