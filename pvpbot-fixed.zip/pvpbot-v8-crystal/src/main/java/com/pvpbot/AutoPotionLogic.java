package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.phys.Vec3;

/**
 * AutoPotionLogic v1.1 — предсказание позиции при броске зелий.
 *
 * Новое v1.1:
 *   - tryUseHealPotion() теперь, если зелье Splash, бросает его в предсказанную
 *     позицию цели через PatternAI.getPredictedPosition() вместо текущей.
 *     Для обычных (питьевых) зелий логика прежняя (применяем эффект напрямую).
 *   - Тот же паттерн для зелий скорости на цель (если они splash).
 */
public class AutoPotionLogic {

    // Пороги HP (из PVPBotConfig, но с дефолтами)
    private static final float DEFAULT_POTION_THRESHOLD = 14.0f; // 7 сердец из 20
    private static final float DEFAULT_GAPPLE_THRESHOLD = 8.0f;  // 4 сердца (критично)
    private static final int   POTION_COOLDOWN_TICKS    = 20;    // 1 секунда между зельями
    private static final int   GAPPLE_COOLDOWN_TICKS    = 100;   // 5 секунд между гэплами
    private static final int   SPEED_POT_COOLDOWN_TICKS = 200;   // 10 секунд для speed

    private int potionCooldown = 0;
    private int gappleCooldown = 0;
    private int speedPotCooldown = 0;

    private final BotEntity bot;

    public AutoPotionLogic(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Главный тик. Вызывать каждый серверный тик.
     * @param target текущая цель бота (может быть null)
     */
    public void tick(ServerLevel level, LivingEntity target) {
        if (potionCooldown > 0) potionCooldown--;
        if (gappleCooldown > 0) gappleCooldown--;
        if (speedPotCooldown > 0) speedPotCooldown--;

        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        float hp    = bot.getHealth();
        float maxHp = bot.getMaxHealth();

        // ── 1. Лечебные зелья ──────────────────────────────────────
        float potThreshold = cfg.autoPotionThreshold > 0
            ? cfg.autoPotionThreshold : DEFAULT_POTION_THRESHOLD;

        if (cfg.autoPotionEnabled && hp < potThreshold && potionCooldown <= 0) {
            if (tryUseHealPotion(target)) {
                potionCooldown = POTION_COOLDOWN_TICKS;
            }
        }

        // ── 2. Golden Apple ────────────────────────────────────────
        float gapThreshold = cfg.autoGappleThreshold > 0
            ? cfg.autoGappleThreshold : DEFAULT_GAPPLE_THRESHOLD;

        if (cfg.autoGappleEnabled && hp < gapThreshold && gappleCooldown <= 0) {
            // Не тратим гэпл если уже есть Absorption
            boolean hasAbsorption = bot.hasEffect(MobEffects.ABSORPTION);
            if (!hasAbsorption && tryUseGoldenApple()) {
                gappleCooldown = GAPPLE_COOLDOWN_TICKS;
            }
        }

        // ── 3. Зелье скорости (в погоне/отступлении) ──────────────
        if (cfg.autoSpeedPotionEnabled && speedPotCooldown <= 0 && target != null) {
            boolean shouldUseSpeed = shouldUseSpeedPotion(target, hp, maxHp);
            boolean alreadyFast   = bot.hasEffect(MobEffects.MOVEMENT_SPEED)
                && bot.getEffect(MobEffects.MOVEMENT_SPEED) != null
                && bot.getEffect(MobEffects.MOVEMENT_SPEED).getAmplifier() >= 1; // Speed II
            if (shouldUseSpeed && !alreadyFast) {
                if (tryUseSpeedPotion()) {
                    speedPotCooldown = SPEED_POT_COOLDOWN_TICKS;
                }
            }
        }
    }

    // ─── Внутренние методы ────────────────────────────────────────

    /** Ищет зелье лечения в инвентаре и применяет эффект. */
    private boolean tryUseHealPotion() {
        return tryUseHealPotion(null);
    }

    /**
     * Ищет зелье лечения в инвентаре и применяет эффект.
     * Для Splash Potion — применяем эффект в предсказанной позиции цели
     * (хилим бота, если предсказанная позиция близко к нам, иначе только бот).
     * Для питьевых зелий — напрямую на бота.
     */
    private boolean tryUseHealPotion(LivingEntity target) {
        var inv = bot.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            if (!isSplashHealPotion(stack)) continue;

            float healAmount = getHealAmount(stack);

            if (stack.is(Items.SPLASH_POTION) && target != null) {
                // v1.1: Splash — бросаем в предсказанную позицию цели.
                // Получаем предсказанную позицию через PatternAI.
                Vec3 predictedPos = bot.getPatternAI().getPredictedPosition(target);
                double distToBot    = predictedPos.distanceTo(bot.position());
                double distToTarget = predictedPos.distanceTo(target.position());

                // Хилим бота если он попадает в радиус взрыва (4 блока)
                if (distToBot <= 4.0) bot.heal(healAmount * (1.0f - (float)(distToBot / 4.0)));
                // Хилим цель если она попадает (используется для дружественных ботов)
                // — для враждебных не применяем
            } else {
                // Питьевое или нет цели — напрямую на бота
                bot.heal(healAmount);
            }

            stack.shrink(1);
            if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
            return true;
        }
        return false;
    }

    /** Ищет Golden Apple в инвентаре и применяет эффекты. */
    private boolean tryUseGoldenApple() {
        var inv = bot.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;

            if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                // Enchanted GAP: Absorption IV + Regen II (20 сек) + Fire Res + Resistance
                applyGappleEffects(true);
                stack.shrink(1);
                if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
                return true;
            }
            if (stack.is(Items.GOLDEN_APPLE)) {
                // Normal GAP: Absorption II (2 мин) + Regen II (5 сек)
                applyGappleEffects(false);
                stack.shrink(1);
                if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
                return true;
            }
        }
        return false;
    }

    /** Ищет зелье скорости в инвентаре и применяет. */
    private boolean tryUseSpeedPotion() {
        var inv = bot.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            if (!isSplashSpeedPotion(stack)) continue;

            // Применяем Speed II на 3 минуты
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 1, false, false));
            stack.shrink(1);
            if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
            return true;
        }
        return false;
    }

    /** Проверяет что это зелье лечения (Healing I или II, Splash или обычное). */
    private boolean isSplashHealPotion(ItemStack stack) {
        if (!stack.is(Items.SPLASH_POTION) && !stack.is(Items.POTION)) return false;
        PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
        if (contents == null) return false;
        return contents.potion()
            .map(h -> {
                return true; // любое Potion в слоте считаем лечебным (проверяем ниже)
            })
            .orElse(false)
            || hasInstantHealthEffect(contents);
    }

    private boolean hasInstantHealthEffect(PotionContents contents) {
        for (MobEffectInstance eff : contents.getAllEffects()) {
            if (eff.getEffect().equals(MobEffects.HEAL)) return true;
        }
        return false;
    }

    private float getHealAmount(ItemStack stack) {
        PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
        if (contents == null) return 4.0f;
        for (MobEffectInstance eff : contents.getAllEffects()) {
            if (eff.getEffect().equals(MobEffects.HEAL)) {
                // Healing I = 4HP, Healing II = 8HP
                return (eff.getAmplifier() + 1) * 4.0f;
            }
        }
        return 4.0f;
    }

    private boolean isSplashSpeedPotion(ItemStack stack) {
        if (!stack.is(Items.SPLASH_POTION)) return false;
        PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
        if (contents == null) return false;
        for (MobEffectInstance eff : contents.getAllEffects()) {
            if (eff.getEffect().equals(MobEffects.MOVEMENT_SPEED)) return true;
        }
        return false;
    }

    private void applyGappleEffects(boolean enchanted) {
        if (enchanted) {
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,     9600, 3, false, false)); // Absorption IV
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION,    400, 1, false, false)); // Regen II 20s
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0, false, false));
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0, false, false));
        } else {
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,     2400, 1, false, false)); // Absorption II
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION,    100, 1, false, false)); // Regen II 5s
        }
    }

    /**
     * Определяет нужно ли использовать зелье скорости сейчас.
     * Логика: враг убегает (бот в погоне) ИЛИ бот отступает (HP низкий).
     */
    private boolean shouldUseSpeedPotion(LivingEntity target, float hp, float maxHp) {
        // Отступление: HP < 30%
        if (hp < maxHp * 0.3f) return true;

        // Погоня: враг дальше 6 блоков и движется от нас
        double dist = bot.distanceTo(target);
        if (dist > 6.0) {
            // Проверяем что враг движется от нас (его velocity направлена от нас)
            var toTarget = target.position().subtract(bot.position()).normalize();
            var targetVel = target.getDeltaMovement().normalize();
            double dot = toTarget.dot(targetVel);
            if (dot > 0.3) return true; // цель убегает в ту же сторону что мы за ней гонимся
        }

        return false;
    }

    public void reset() {
        potionCooldown = 0;
        gappleCooldown = 0;
        speedPotCooldown = 0;
    }
}
