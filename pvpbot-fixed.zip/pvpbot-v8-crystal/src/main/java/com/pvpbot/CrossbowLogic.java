package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * CrossbowLogic v2.0 — Полная переработка.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ФАЗОВАЯ МАШИНА:
 *
 *  KITE      — держим оптимальную дистанцию, стреляем burst'ами
 *  FIREWORK  — залп фейерверков (каждые FIREWORK_EVERY burst'ов)
 *  CLOSE     — враг подошёл вплотную: откат + sword combo
 *  RELOAD    — пауза перезарядки, продолжаем кайтить
 *  ESCAPE    — HP < escape threshold: dash назад + pearl
 *
 * ══════════════════════════════════════════════════════════════════
 *  МЕХАНИКИ:
 *
 *  1. Burst-режим: 3-5 стрел с интервалом BURST_INTERVAL тиков.
 *     Тип снаряда чередуется: обычные стрелы → firework → стрелы.
 *
 *  2. Piercing-выстрел: если 2+ врагов в линии — стреляем стрелой
 *     с эффектом прострела (урон всем в линии).
 *
 *  3. Firework burst: 4 фейерверка за 12 тиков — взрывной AoE урон.
 *     Используется как особая фаза раз в FIREWORK_EVERY burst'ов.
 *
 *  4. Kite movement: стрейф + отступление при сближении врага.
 *     При dist < MIN_KITE — резкий откат + смена направления страфа.
 *
 *  5. Close combat: если враг вплотную — 2 удара мечом + откат.
 *     Не стреляем в упор (сложно попасть и не дать урон).
 *
 *  6. Predict aim: упреждение на скорость цели * LEAD_TICKS.
 *     Точность выстрела: 95% EXPERT, 85% HARD, 70% MEDIUM.
 *
 *  7. Speed buff: постоянный Speed II для кайтинга.
 *
 *  8. Shield-break mode: если цель держит щит — Firework burst
 *     (AoE взрыв игнорирует щит).
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class CrossbowLogic {

    // ── Дистанции ──────────────────────────────────────────────────
    private static final double OPTIMAL_RANGE   = 11.0;
    private static final double MAX_RANGE       = 20.0;
    private static final double MIN_KITE_RANGE  = 4.5;
    private static final double CLOSE_RANGE     = 3.0;
    private static final double PIERCE_RANGE    = 14.0;

    // ── Burst ──────────────────────────────────────────────────────
    private static final int    BURST_SIZE      = 4;
    private static final int    BURST_INTERVAL  = 3;    // тиков между выстрелами
    private static final int    RELOAD_TICKS    = 28;   // перезарядка
    private static final int    FIREWORK_EVERY  = 3;    // burst'ов до fw-фазы
    private static final int    FW_BURST_SIZE   = 4;    // фейерверков за раз
    private static final int    FW_INTERVAL     = 4;    // тиков между fw

    // ── Кулдауны ───────────────────────────────────────────────────
    private static final int    CLOSE_SWORD_CD  = 6;
    private static final int    CLOSE_SWORD_CNT = 2;    // ударов в упор
    private static final int    SPEED_CD        = 350;
    private static final int    KITE_CD         = 8;    // тиков между kite-шагами
    private static final int    PEARL_CD        = 80;
    private static final int    ESCAPE_HP_MULT  = 3;    // escape при HP < max/N

    // ── Урон ───────────────────────────────────────────────────────
    private static final float  ARROW_DMG       = 8.5f;
    private static final float  FW_DMG          = 6.0f;
    private static final float  PIERCE_DMG      = 7.0f;
    private static final float  SWORD_DMG_CLOSE = 5.0f;

    // ── Точность по сложности ──────────────────────────────────────
    private static final float  AIM_EXPERT      = 0.04f;
    private static final float  AIM_HARD        = 0.12f;
    private static final float  AIM_MEDIUM      = 0.22f;
    private static final float  AIM_EASY        = 0.50f;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase { KITE, FIREWORK_BURST, CLOSE, RELOAD, ESCAPE }
    private Phase phase = Phase.KITE;

    // ── Состояние ──────────────────────────────────────────────────
    private int   burstLeft     = 0;
    private int   burstTick     = 0;
    private int   reloadTimer   = 0;
    private int   fwLeft        = 0;
    private int   fwTick        = 0;
    private int   burstCount    = 0;   // сколько burst'ов сделали
    private int   closeSwordCd  = 0;
    private int   closeSwordHits= 0;
    private int   speedCd       = 0;
    private int   kiteCd        = 0;
    private int   pearlCd       = 0;
    private int   patternSyncCd = 0;
    private boolean strafeLeft  = true;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public CrossbowLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (reloadTimer   > 0) reloadTimer--;
        if (fwTick        > 0) fwTick--;
        if (burstTick     > 0) burstTick--;
        if (closeSwordCd  > 0) closeSwordCd--;
        if (speedCd       > 0) speedCd--;
        if (kiteCd        > 0) kiteCd--;
        if (pearlCd       > 0) pearlCd--;
        if (patternSyncCd > 0) patternSyncCd--;

        // Speed II всегда
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 1));
            speedCd = SPEED_CD;
        }

        ensureKit();
        double dist = bot.distanceTo(target);
        boolean blocking = isTargetBlocking(target);

        // ── Выбор фазы ────────────────────────────────────────────
        updatePhase(dist, blocking);

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Диспатч ───────────────────────────────────────────────
        switch (phase) {
            case KITE           -> tickKite(sw, target, dist);
            case FIREWORK_BURST -> tickFireworkBurst(sw, target);
            case CLOSE          -> tickClose(sw, target);
            case RELOAD         -> tickReload(target, dist);
            case ESCAPE         -> tickEscape(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Выбор фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(double dist, boolean blocking) {
        float hp = bot.getHealth();

        // Escape при низком HP
        if (hp < bot.getMaxHealth() / ESCAPE_HP_MULT && pearlCd <= 0) {
            phase = Phase.ESCAPE; return;
        }
        // Вплотную — меч
        if (dist < CLOSE_RANGE) { phase = Phase.CLOSE; return; }
        // Перезарядка
        if (reloadTimer > 0) { phase = Phase.RELOAD; return; }
        // Firework burst — раз в FIREWORK_EVERY или против щита
        if (fwLeft > 0 || (burstCount > 0 && burstCount % FIREWORK_EVERY == 0)
                || blocking) {
            phase = Phase.FIREWORK_BURST; return;
        }
        phase = Phase.KITE;
    }

    // ════════════════════════════════════════════════════════════════
    //  KITE — стреляем + держим дистанцию
    // ════════════════════════════════════════════════════════════════

    private void tickKite(ServerLevel sw, LivingEntity target, double dist) {
        // Kite движение
        tickKiteMovement(target, dist);

        // Страф
        if (cfg.strafeEnabled) {
            syncPatternAI();
            strafe.tick(target);
        }

        if (dist > MAX_RANGE) return;

        // Burst выстрелы
        if (burstLeft > 0) {
            if (burstTick <= 0) {
                // Piercing если 2+ врагов в линии
                if (canPierce(sw, target) && dist <= PIERCE_RANGE) {
                    shootPiercing(sw, target);
                } else {
                    shootArrow(sw, target);
                }
                burstLeft--;
                burstTick = BURST_INTERVAL;
                if (burstLeft == 0) {
                    reloadTimer = RELOAD_TICKS;
                    burstCount++;
                }
            }
        } else if (dist <= OPTIMAL_RANGE * 1.6) {
            // Начать новый burst
            burstLeft = BURST_SIZE;
            burstTick = 1;
        }
    }

    private void tickKiteMovement(LivingEntity target, double dist) {
        if (kiteCd > 0) return;

        if (dist < MIN_KITE_RANGE) {
            // Отходим назад с уклонением
            Vec3 away = bot.position().subtract(target.position()).normalize();
            double sideX = strafeLeft ? -away.z : away.z;
            double sideZ = strafeLeft ?  away.x : -away.x;
            Vec3 retreat = away.add(sideX * 0.5, 0, sideZ * 0.5).normalize().scale(0.55);
            bot.setDeltaMovement(bot.getDeltaMovement().add(retreat.x, 0, retreat.z));
            bot.setSprinting(true);
            kiteCd = KITE_CD;
        } else if (dist > OPTIMAL_RANGE * 1.4) {
            // Приближаемся
            bot.getNavigation().moveTo(target, 1.1);
        } else if (dist > OPTIMAL_RANGE) {
            // Лёгкое сближение
            bot.getNavigation().moveTo(target, 0.95);
        } else {
            bot.getNavigation().stop();
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  FIREWORK BURST
    // ════════════════════════════════════════════════════════════════

    private void tickFireworkBurst(ServerLevel sw, LivingEntity target) {
        // Инициализация фазы
        if (fwLeft == 0) { fwLeft = FW_BURST_SIZE; fwTick = 0; }

        if (fwTick <= 0 && fwLeft > 0) {
            launchFirework(sw, target);
            fwLeft--;
            fwTick = FW_INTERVAL;
        }

        if (fwLeft == 0) {
            phase       = Phase.RELOAD;
            reloadTimer = RELOAD_TICKS + 10;
        }

        // Продолжаем кайтить во время fw-фазы
        tickKiteMovement(target, bot.distanceTo(target));
    }

    // ════════════════════════════════════════════════════════════════
    //  CLOSE COMBAT — вплотную: 2 удара мечом + откат
    // ════════════════════════════════════════════════════════════════

    private void tickClose(ServerLevel sw, LivingEntity target) {
        // Откат назад
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.5);
        bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0.15, away.z));

        // 2 удара мечом
        if (closeSwordCd <= 0 && closeSwordHits < CLOSE_SWORD_CNT) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("unbreaking", 3).build());
            if (target.isAlive()) {
                bot.doHurtTarget(sw, target);
                sw.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY() + 1, target.getZ(), 4, 0.2, 0.2, 0.2, 0.1);
            }
            closeSwordCd = CLOSE_SWORD_CD;
            closeSwordHits++;
        }

        if (closeSwordHits >= CLOSE_SWORD_CNT) {
            closeSwordHits = 0;
            ensureKit(); // обратно арбалет
            phase = Phase.KITE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  RELOAD — перезарядка
    // ════════════════════════════════════════════════════════════════

    private void tickReload(LivingEntity target, double dist) {
        // Держим дистанцию во время перезарядки
        tickKiteMovement(target, dist);
        if (reloadTimer <= 0) phase = Phase.KITE;
    }

    // ════════════════════════════════════════════════════════════════
    //  ESCAPE — pearl-рывок назад
    // ════════════════════════════════════════════════════════════════

    private void tickEscape(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 dest = bot.getEyePosition().add(away.scale(12.0));

        var pearl = new net.minecraft.world.entity.projectile.ThrownEnderpearl(
            net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        Vec3 dir = dest.subtract(bot.getEyePosition()).normalize();
        pearl.moveTo(bot.getEyePosition().x, bot.getEyePosition().y, bot.getEyePosition().z);
        pearl.setDeltaMovement(dir.scale(2.5));
        sw.addFreshEntity(pearl);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 0.6f);

        pearlCd = PEARL_CD;
        phase   = Phase.KITE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Выстрелы
    // ════════════════════════════════════════════════════════════════

    private void shootArrow(ServerLevel sw, LivingEntity target) {
        Vec3 from = bot.getEyePosition();
        Vec3 aim  = getAimPos(target, from);
        Vec3 dir  = aim.subtract(from).normalize();

        Arrow arrow = new Arrow(sw, from.x, from.y, from.z,
            new ItemStack(Items.ARROW), ItemStack.EMPTY);
        arrow.setOwner(bot);
        arrow.shoot(dir.x, dir.y, dir.z, 3.0f, aimSpread());
        arrow.pickup = net.minecraft.world.entity.projectile.AbstractArrow.Pickup.DISALLOWED;
        arrow.setBaseDamage(ARROW_DMG);
        sw.addFreshEntity(arrow);

        bot.playSound(SoundEvents.CROSSBOW_SHOOT, 1.0f, 1.0f + (float)(Math.random() * 0.1 - 0.05));
        sw.sendParticles(ParticleTypes.CRIT, from.x, from.y, from.z, 2, 0.05, 0.05, 0.05, 0.02);
    }

    /** Piercing: стрела летит по линии, ранит всех на пути. */
    private void shootPiercing(ServerLevel sw, LivingEntity primary) {
        Vec3 from = bot.getEyePosition();
        Vec3 dir  = primary.getEyePosition().subtract(from).normalize();

        // Наносим урон всем в линии
        for (var e : sw.getEntitiesOfClass(LivingEntity.class,
                bot.getBoundingBox().inflate(PIERCE_RANGE),
                e -> e != bot && e.isAlive())) {
            Vec3 toE = e.getEyePosition().subtract(from);
            double dot = dir.dot(toE.normalize());
            double distE = toE.length();
            if (dot > 0.95 && distE <= PIERCE_RANGE) {
                e.hurt(sw.damageSources().mobAttack(bot), PIERCE_DMG);
            }
        }

        Arrow arrow = new Arrow(sw, from.x, from.y, from.z,
            new ItemStack(Items.ARROW), ItemStack.EMPTY);
        arrow.setOwner(bot);
        arrow.shoot(dir.x, dir.y, dir.z, 3.0f, 0.5f);
        arrow.pickup = net.minecraft.world.entity.projectile.AbstractArrow.Pickup.DISALLOWED;
        sw.addFreshEntity(arrow);

        bot.playSound(SoundEvents.CROSSBOW_SHOOT, 1.1f, 0.85f);
        sw.sendParticles(ParticleTypes.ENCHANTED_HIT,
            from.x, from.y, from.z, 5, 0.1, 0.1, 0.1, 0.05);
    }

    private void launchFirework(ServerLevel sw, LivingEntity target) {
        Vec3 from = bot.getEyePosition();
        Vec3 aim  = getAimPos(target, from);
        Vec3 dir  = aim.subtract(from).normalize();

        FireworkRocketEntity fw = new FireworkRocketEntity(
            sw, bot, from.x, from.y, from.z, new ItemStack(Items.FIREWORK_ROCKET));
        fw.setDeltaMovement(dir.x * 1.8, dir.y * 1.8, dir.z * 1.8);
        sw.addFreshEntity(fw);

        // AoE урон при взрыве
        if (target.isAlive()) target.hurt(sw.damageSources().explosion(bot, bot), FW_DMG);
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(2.5),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().explosion(bot, bot), FW_DMG * 0.6f));

        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.9f, 1.1f);
        sw.sendParticles(ParticleTypes.FIREWORK,
            target.getX(), target.getY() + 1, target.getZ(), 12, 0.4, 0.4, 0.4, 0.15);
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    /** Предсказываем позицию цели на LEAD_TICKS тиков вперёд. */
    private Vec3 getAimPos(LivingEntity target, Vec3 from) {
        double dist = from.distanceTo(target.getEyePosition());
        float lead  = (float)(dist / 50.0) * 3.0f; // тиков упреждения
        Vec3 vel    = target.getDeltaMovement();
        return target.getEyePosition().add(vel.scale(lead));
    }

    private float aimSpread() {
        return switch (bot.getEffectiveDifficulty()) {
            case EXPERT -> AIM_EXPERT;
            case HARD   -> AIM_HARD;
            case MEDIUM -> AIM_MEDIUM;
            default     -> AIM_EASY;
        };
    }

    private boolean canPierce(ServerLevel sw, LivingEntity primary) {
        Vec3 dir = primary.position().subtract(bot.position()).normalize();
        long count = sw.getEntitiesOfClass(LivingEntity.class,
            bot.getBoundingBox().inflate(PIERCE_RANGE),
            e -> e != bot && e.isAlive()
        ).stream().filter(e -> {
            Vec3 toE = e.position().subtract(bot.position());
            return dir.dot(toE.normalize()) > 0.92 && toE.length() <= PIERCE_RANGE;
        }).count();
        return count >= 2;
    }

    private boolean isTargetBlocking(LivingEntity t) {
        return (t.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD)
             || t.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD))
            && t.isBlocking();
    }

    private void syncPatternAI() {
        if (!cfg.patternAIEnabled || patternSyncCd > 0) { patternSyncCd--; return; }
        PatternAI pai = bot.getPatternAI();
        double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
        double neutral = strafe.isStrafeLeft() ? -90.0 : 90.0;
        strafe.setAdaptedYaw((float)(absYaw - neutral));
        patternSyncCd = 3;
    }

    private void ensureKit() {
        var mh = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!mh.is(Items.CROSSBOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.CROSSBOW, bot.level().registryAccess())
                    .enchant("quick_charge", 3).enchant("multishot", 1)
                    .enchant("unbreaking", 3).enchant("mending", 1).build());
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(Items.NETHERITE_HELMET, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (bot.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(Items.NETHERITE_CHESTPLATE, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(Items.NETHERITE_LEGGINGS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(Items.NETHERITE_BOOTS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    public void reset() {
        phase = Phase.KITE; burstLeft = 0; burstTick = 0; reloadTimer = 0;
        fwLeft = 0; fwTick = 0; burstCount = 0;
        closeSwordCd = 0; closeSwordHits = 0; speedCd = 0;
        kiteCd = 0; pearlCd = 0; patternSyncCd = 0;
    }

    public String getStateLabel() {
        return "XBOW:" + switch (phase) {
            case KITE           -> burstLeft > 0 ? "BURST" + burstLeft : "KITE";
            case FIREWORK_BURST -> "FW!" + fwLeft;
            case CLOSE          -> "CLOSE";
            case RELOAD         -> "RELOAD";
            case ESCAPE         -> "ESC";
        };
    }
}
