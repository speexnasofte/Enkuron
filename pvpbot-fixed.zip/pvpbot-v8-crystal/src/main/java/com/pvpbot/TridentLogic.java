package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * TridentLogic v2.0 — Полная переработка.
 *
 * ══════════════════════════════════════════════════════════════════
 *  КОНЦЕПЦИЯ:
 *  Бот сочетает метание трезубца (дальний бой) с мощным ближним
 *  боем при подхвате. Использует Riptide для телепорт-атак в
 *  дождь и Channeling для молнии.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ФАЗЫ:
 *
 *  MELEE        — ближний бой трезубцем (3-5 блоков).
 *                 Крит-прыжок, W-tap, страф.
 *
 *  THROW        — метаем трезубец (5-20 блоков).
 *                 Предсказание позиции цели на 4 тика.
 *                 Если Loyalty — ждём возврата.
 *                 Если не Loyalty — идём подбирать.
 *
 *  RETRIEVE     — идём к упавшему трезубцу. Пока идём —
 *                 атакуем вторым оружием (меч).
 *
 *  RIPTIDE_DASH — Riptide телепорт-атака. Только при:
 *                 дождь (isRaining) ИЛИ вода под ногами.
 *                 Прыгаем и активируем Riptide.
 *
 *  CHANNELING   — вызов молнии (Channeling+гроза).
 *                 Метаем трезубец в цель, ждём громового удара.
 *
 *  ESCAPE       — отход при HP < ESCAPE_HP.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ЗАЧАРОВАНИЯ:
 *
 *  Loyalty III  — трезубец возвращается через LOYALTY_RETURN_CD тиков.
 *  Channeling I — молния при ударе в грозу.
 *  Impaling V   — +2.5 урона по мокрым/водным мобам.
 *  Riptide III  — телепорт-атака при воде/дожде.
 *  Unbreaking III + Mending.
 *
 *  Примечание: Riptide и Loyalty/Channeling — взаимоисключающие.
 *  У бота два комплекта: основной (Loyalty+Channeling) и
 *  второй (Riptide) — переключается по погоде/обстановке.
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class TridentLogic {

    // ── Дистанции ──────────────────────────────────────────────────
    private static final double MELEE_RANGE        = 3.8;
    private static final double THROW_MIN_DIST     = 5.0;
    private static final double THROW_OPT_DIST     = 10.0;
    private static final double THROW_MAX_DIST     = 20.0;
    private static final double RIPTIDE_MIN_DIST   = 6.0;
    private static final double RIPTIDE_MAX_DIST   = 18.0;

    // ── Кулдауны ───────────────────────────────────────────────────
    private static final int    MELEE_CD           = 10;
    private static final int    THROW_CD           = 45;
    private static final int    RIPTIDE_CD         = 55;
    private static final int    CHANNELING_CD      = 180;
    private static final int    LOYALTY_RETURN_CD  = 35;   // тиков пока летит обратно
    private static final int    RETRIEVE_TIMEOUT   = 200;  // макс. тиков на подбор
    private static final int    DODGE_CD           = 20;
    private static final int    PEARL_CD           = 80;
    private static final int    SPEED_CD           = 350;
    private static final int    CRIT_EVERY         = 3;

    // ── HP ─────────────────────────────────────────────────────────
    private static final float  ESCAPE_HP          = 7.0f;
    private static final float  RIPTIDE_MIN_HP     = 10.0f; // не рипайдим при низком HP

    // ── Урон ───────────────────────────────────────────────────────
    private static final float  THROW_DMG          = 14.0f;
    private static final float  MELEE_DMG_BONUS    = 3.0f;  // бонус за impaling
    private static final float  LIGHTNING_DMG      = 8.0f;
    private static final float  RIPTIDE_HIT_DMG    = 12.0f;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase { MELEE, THROW, RETRIEVE, RIPTIDE_DASH, CHANNELING, ESCAPE }
    private Phase phase = Phase.MELEE;

    // ── Состояние ──────────────────────────────────────────────────
    private int   meleeCd          = 0;
    private int   throwCd          = 0;
    private int   riptideCd        = 0;
    private int   channelingCd     = 0;
    private int   loyaltyTimer     = 0;   // ждём возврата
    private int   retrieveTimer    = 0;   // таймаут подбора
    private int   dodgeCd          = 0;
    private int   pearlCd          = 0;
    private int   speedCd          = 0;
    private int   critCounter      = 0;
    private boolean critPending    = false;
    private boolean tridentThrown  = false; // летит снаряд
    private boolean hasLoyalty     = true;  // зачарование Loyalty
    private boolean isRaining      = false;

    private final BotEntity    bot;
    private final WTapLogic    wTap;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public TridentLogic(BotEntity bot) {
        this.bot    = bot;
        this.wTap   = new WTapLogic(bot);
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (meleeCd      > 0) meleeCd--;
        if (throwCd      > 0) throwCd--;
        if (riptideCd    > 0) riptideCd--;
        if (channelingCd > 0) channelingCd--;
        if (loyaltyTimer > 0) loyaltyTimer--;
        if (retrieveTimer> 0) retrieveTimer--;
        if (dodgeCd      > 0) dodgeCd--;
        if (pearlCd      > 0) pearlCd--;
        if (speedCd      > 0) speedCd--;

        // Speed I
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 0));
            speedCd = SPEED_CD;
        }

        // Проверяем дождь/грозу каждые 20 тиков
        if (bot.tickCount % 20 == 0) {
            isRaining = sw.isRaining();
        }

        ensureKit(sw);

        double dist = bot.distanceTo(target);
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Возврат Loyalty — сбрасываем флаг
        if (tridentThrown && loyaltyTimer <= 0) {
            tridentThrown = false;
        }

        // Выбор фазы
        updatePhase(sw, target, dist);

        switch (phase) {
            case MELEE        -> tickMelee(sw, target, dist);
            case THROW        -> tickThrow(sw, target, dist);
            case RETRIEVE     -> tickRetrieve(sw, target);
            case RIPTIDE_DASH -> tickRiptide(sw, target, dist);
            case CHANNELING   -> tickChanneling(sw, target, dist);
            case ESCAPE       -> tickEscape(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Обновление фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(ServerLevel sw, LivingEntity target, double dist) {
        // Escape приоритет
        if (bot.getHealth() < ESCAPE_HP && pearlCd <= 0) {
            phase = Phase.ESCAPE; return;
        }

        // Ruptide в дождь
        boolean canRiptide = (isRaining || isInWater()) && riptideCd <= 0
            && dist >= RIPTIDE_MIN_DIST && dist <= RIPTIDE_MAX_DIST
            && bot.getHealth() > RIPTIDE_MIN_HP;

        // Channeling в грозу
        boolean canChannel = sw.isThundering() && channelingCd <= 0
            && dist <= THROW_MAX_DIST;

        if (canChannel) { phase = Phase.CHANNELING; return; }
        if (canRiptide) { phase = Phase.RIPTIDE_DASH; return; }

        // Трезубец в полёте — ждём или идём подбирать
        if (tridentThrown) {
            if (hasLoyalty || loyaltyTimer > 0) {
                // Ждём возврата — меле мечом если близко
                if (dist <= MELEE_RANGE) { phase = Phase.MELEE; return; }
                phase = Phase.THROW; return; // держим позицию
            } else {
                phase = Phase.RETRIEVE; return;
            }
        }

        // Оптимальная дистанция для броска
        if (dist >= THROW_MIN_DIST && dist <= THROW_MAX_DIST && throwCd <= 0) {
            phase = Phase.THROW; return;
        }

        phase = Phase.MELEE;
    }

    // ════════════════════════════════════════════════════════════════
    //  MELEE
    // ════════════════════════════════════════════════════════════════

    private void tickMelee(ServerLevel sw, LivingEntity target, double dist) {
        boolean wTapActive = wTap.tick(target);

        if (!wTapActive) {
            if (dist > MELEE_RANGE) bot.getNavigation().moveTo(target, 1.12);
            else if (cfg.strafeEnabled) strafe.tick(target);
        }

        if (dist > MELEE_RANGE || meleeCd > 0 || wTapActive) return;

        // Крит-прыжок
        if (critCounter >= CRIT_EVERY && bot.onGround() && !critPending) {
            bot.getJumpControl().jump();
            critPending = true; critCounter = 0; return;
        }
        if (critPending && !bot.onGround()
                && bot.getDeltaMovement().y < -0.01 && bot.fallDistance > 0.08f) {
            doMeleeHit(sw, target, true);
            critPending = false; return;
        }
        if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
            critPending = false;
        }
        doMeleeHit(sw, target, false);
        critCounter++;
    }

    // ════════════════════════════════════════════════════════════════
    //  THROW — метаем трезубец
    // ════════════════════════════════════════════════════════════════

    private void tickThrow(ServerLevel sw, LivingEntity target, double dist) {
        // Держим оптимальную дистанцию
        if (dist < THROW_MIN_DIST) {
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.4);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0, away.z));
        } else if (dist > THROW_OPT_DIST * 1.5) {
            bot.getNavigation().moveTo(target, 1.05);
        }

        if (tridentThrown || throwCd > 0) return;
        if (dist > THROW_MAX_DIST) { phase = Phase.MELEE; return; }

        throwTrident(sw, target);
    }

    private void throwTrident(ServerLevel sw, LivingEntity target) {
        Vec3 eye = bot.getEyePosition();
        // Упреждение на 4 тика
        Vec3 predicted = MotionPredictor.predict(target, 4);
        Vec3 dir = predicted.subtract(eye).normalize();

        ThrownTrident trident = new ThrownTrident(sw, bot,
            bot.getItemBySlot(EquipmentSlot.MAINHAND));
        trident.moveTo(eye.x, eye.y, eye.z);
        trident.shoot(dir.x, dir.y, dir.z, 2.5f, aimSpread());

        sw.addFreshEntity(trident);
        bot.playSound(SoundEvents.TRIDENT_THROW.value(), 1.0f, 1.0f);
        sw.sendParticles(ParticleTypes.ENCHANTED_HIT,
            eye.x, eye.y, eye.z, 5, 0.1, 0.1, 0.1, 0.05);

        // Урон (симулируем попадание — физика Minecraft вычитает сама, но добавляем бонус)
        double dist = bot.distanceTo(target);
        if (dist <= THROW_OPT_DIST * 1.2 && target.isAlive()) {
            target.hurt(sw.damageSources().trident(trident, bot), THROW_DMG);
            target.setDeltaMovement(dir.x * 1.5, dir.y * 1.5 + 0.3, dir.z * 1.5);
        }

        tridentThrown = true;
        throwCd       = THROW_CD;
        loyaltyTimer  = LOYALTY_RETURN_CD;
        retrieveTimer = RETRIEVE_TIMEOUT;

        if (cfg.wTapEnabled) wTap.onAttack();
        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), THROW_DMG);
    }

    // ════════════════════════════════════════════════════════════════
    //  RETRIEVE — идём подбирать трезубец
    // ════════════════════════════════════════════════════════════════

    private void tickRetrieve(ServerLevel sw, LivingEntity target) {
        if (!tridentThrown || retrieveTimer <= 0) {
            tridentThrown = false;
            phase = Phase.MELEE; return;
        }

        // Пока идём — атакуем мечом если близко
        double dist = bot.distanceTo(target);
        if (dist <= 3.5 && meleeCd <= 0) {
            equipSword();
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            meleeCd = MELEE_CD;
        } else {
            // Ищем упавший трезубец в радиусе 24 блоков
            var tridentEntity = sw.getEntitiesOfClass(
                net.minecraft.world.entity.projectile.ThrownTrident.class,
                bot.getBoundingBox().inflate(24.0),
                t -> t.getOwner() == bot
            ).stream().findFirst().orElse(null);

            if (tridentEntity != null) {
                bot.getNavigation().moveTo(tridentEntity, 1.3);
            } else {
                // Трезубца нет — видимо подобрали или потеряли
                tridentThrown = false;
                phase = Phase.MELEE;
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  RIPTIDE_DASH — телепорт-атака
    // ════════════════════════════════════════════════════════════════

    private void tickRiptide(ServerLevel sw, LivingEntity target, double dist) {
        if (!isRaining && !isInWater()) { phase = Phase.MELEE; return; }

        // Смотрим на цель и прыгаем
        bot.getLookControl().setLookAt(target, 60f, 60f);

        if (bot.onGround()) {
            bot.getJumpControl().jump();
            return;
        }

        // В воздухе — Riptide даёт импульс в направлении взгляда
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        bot.setDeltaMovement(dir.x * 2.8, dir.y * 2.8 + 0.3, dir.z * 2.8);

        // Урон при пролёте сквозь цель
        if (dist <= 2.5) {
            target.hurt(sw.damageSources().mobAttack(bot), RIPTIDE_HIT_DMG);
            target.setDeltaMovement(dir.x * 2.0, 1.2, dir.z * 2.0);
            sw.sendParticles(ParticleTypes.BUBBLE_COLUMN_UP,
                bot.getX(), bot.getY() + 1, bot.getZ(), 20, 0.4, 0.4, 0.4, 0.25);
            bot.playSound(SoundEvents.TRIDENT_HIT_GROUND, 1.2f, 0.7f);
            riptideCd = RIPTIDE_CD;
            phase     = Phase.MELEE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  CHANNELING — молния
    // ════════════════════════════════════════════════════════════════

    private void tickChanneling(ServerLevel sw, LivingEntity target, double dist) {
        if (!sw.isThundering()) { phase = Phase.MELEE; return; }
        if (tridentThrown)      { phase = Phase.THROW;  return; }

        bot.getLookControl().setLookAt(target, 60f, 60f);
        if (dist > THROW_MAX_DIST) { bot.getNavigation().moveTo(target, 1.1); return; }

        throwTrident(sw, target);

        // Дополнительно вызываем молнию напрямую
        if (sw.canSeeSky(target.blockPosition())) {
            var lightning = net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(sw, net.minecraft.world.entity.EntitySpawnReason.TRIGGERED);
            if (lightning != null) {
                lightning.moveTo(target.position());
                sw.addFreshEntity(lightning);
                target.hurt(sw.damageSources().lightningBolt(), LIGHTNING_DMG);
                sw.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    target.getX(), target.getY() + 1, target.getZ(),
                    30, 0.5, 1.0, 0.5, 0.3);
                bot.playSound(SoundEvents.TRIDENT_THUNDER.value(), 1.5f, 1.0f);
            }
        }

        channelingCd = CHANNELING_CD;
        phase        = Phase.MELEE;
    }

    // ════════════════════════════════════════════════════════════════
    //  ESCAPE
    // ════════════════════════════════════════════════════════════════

    private void tickEscape(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 dest = bot.getEyePosition().add(away.scale(12.0));

        var pearl = new net.minecraft.world.entity.projectile.ThrownEnderpearl(
            net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        pearl.moveTo(bot.getEyePosition().x, bot.getEyePosition().y, bot.getEyePosition().z);
        pearl.setDeltaMovement(away.scale(2.5));
        sw.addFreshEntity(pearl);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 0.6f);
        pearlCd = PEARL_CD;
        phase   = Phase.MELEE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Вызвать при получении урона
    // ════════════════════════════════════════════════════════════════

    public void onDamageReceived(float amount, LivingEntity attacker) {
        if (dodgeCd > 0 || attacker == null || amount < 4.0f) return;
        Vec3 away = bot.position().subtract(attacker.position()).normalize();
        bot.setDeltaMovement(away.x * 0.6, 0.25, away.z * 0.6);
        strafe.flipDirection();
        dodgeCd = DODGE_CD;
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    private void doMeleeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (!target.isAlive()) return;
        bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 8, 0.3, 0.3, 0.3, 0.1);
            bot.playSound(SoundEvents.TRIDENT_HIT, 1.0f, 0.7f);
        } else {
            bot.playSound(SoundEvents.TRIDENT_HIT, 1.0f, 1.0f);
        }
        meleeCd = MELEE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    private boolean isInWater() {
        return bot.isInWater() || bot.isInLava();
    }

    private float aimSpread() {
        return switch (bot.getEffectiveDifficulty()) {
            case EXPERT -> 0.3f;
            case HARD   -> 0.8f;
            case MEDIUM -> 1.4f;
            default     -> 2.5f;
        };
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("unbreaking", 3).build());
    }

    private void ensureKit(ServerLevel sw) {
        var mh = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!mh.is(Items.TRIDENT))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.TRIDENT, bot.level().registryAccess())
                    .enchant("loyalty",     3)
                    .enchant("channeling",  1)
                    .enchant("impaling",    5)
                    .enchant("unbreaking",  3)
                    .enchant("mending",     1)
                    .build());
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(Items.NETHERITE_HELMET, bot.level().registryAccess())
                    .enchant("aqua_affinity", 1).enchant("respiration", 3)
                    .enchant("protection", 4).enchant("unbreaking", 3).build());
        if (bot.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(Items.NETHERITE_CHESTPLATE, bot.level().registryAccess())
                    .enchant("protection", 4).enchant("unbreaking", 3).build());
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(Items.NETHERITE_LEGGINGS, bot.level().registryAccess())
                    .enchant("protection", 4).enchant("unbreaking", 3).build());
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(Items.NETHERITE_BOOTS, bot.level().registryAccess())
                    .enchant("depth_strider", 3).enchant("protection", 4)
                    .enchant("unbreaking", 3).build());
    }

    public void reset() {
        phase = Phase.MELEE;
        meleeCd = 0; throwCd = 0; riptideCd = 0; channelingCd = 0;
        loyaltyTimer = 0; retrieveTimer = 0; dodgeCd = 0; pearlCd = 0; speedCd = 0;
        critCounter = 0; critPending = false; tridentThrown = false;
        wTap.reset();
    }

    public String getStateLabel() {
        return "TRIDENT:" + switch (phase) {
            case MELEE        -> critPending ? "CRIT!" : "MELEE";
            case THROW        -> tridentThrown ? "FLY~" + loyaltyTimer : "AIM";
            case RETRIEVE     -> "FETCH";
            case RIPTIDE_DASH -> "RIPTIDE!";
            case CHANNELING   -> "⚡BOLT";
            case ESCAPE       -> "ESC";
        };
    }
}
