package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * SnowballLogic v2.0 — Полная переработка.
 *
 * ══════════════════════════════════════════════════════════════════
 *  КОНЦЕПЦИЯ:
 *  Снежки сами по себе не наносят урон (кроме Blaze). Но логика
 *  этого кита — DISRUPTION: прерывание действий, контроль позиции,
 *  combo с мечом.
 *
 * ══════════════════════════════════════════════════════════════════
 *  МЕХАНИКИ:
 *
 *  1. AIM DISRUPTION (приоритет)
 *     Снежок попадает в цель → knockback 0.5 блока → прерывает атаку.
 *     Бот рассчитывает тайминг: кидает снежок ровно когда цель
 *     начинает анимацию удара (isSwinging).
 *
 *  2. COMBO WINDOW
 *     После 3 снежков подряд → 1 удар мечом (враг отвлечён).
 *     SNOWBALL×3 → SWORD×1 → SNOWBALL×3 → ...
 *
 *  3. SLOW ZONE (Snow Carpet)
 *     Раз в CARPET_CD тиков кидаем 5 снежков в ноги цели —
 *     создаём "зону льда": Slowness II на 40 тиков.
 *
 *  4. INTERRUPT ABILITY
 *     Если цель готовится использовать предмет (isUsingItem) —
 *     мгновенный бросок снежка для прерывания.
 *
 *  5. GROUP DISRUPTION
 *     Если 3+ врагов рядом — ковровая бомбардировка (AoE knockback).
 *
 *  6. KITE (держим оптимальную дистанцию)
 *     Снежки эффективны с 6-12 блоков. Ближе — меч.
 *
 *  7. SNOWBALL BURST
 *     При получении урона — burst 5 снежков подряд (smoke screen).
 *
 * ══════════════════════════════════════════════════════════════════
 *  ФАЗЫ:
 *
 *  KITE         — оптимальная дистанция, снежки + кайтинг
 *  COMBO_SWORD  — быстрый удар мечом после серии снежков
 *  CARPET_BOMB  — ковровая бомбардировка по группе
 *  CLOSE        — слишком близко: меч + откат
 *  BURST        — smoke screen после получения урона
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class SnowballLogic {

    // ── Дистанции ──────────────────────────────────────────────────
    private static final double OPT_RANGE        = 9.0;
    private static final double MAX_RANGE        = 16.0;
    private static final double CLOSE_RANGE      = 3.5;
    private static final double CARPET_RANGE     = 5.0;

    // ── Кулдауны ───────────────────────────────────────────────────
    private static final int    THROW_CD         = 4;    // тиков между снежками
    private static final int    COMBO_EVERY      = 3;    // снежков до комбо-удара
    private static final int    SWORD_CD         = 10;
    private static final int    CARPET_CD        = 90;
    private static final int    CARPET_COUNT     = 6;
    private static final int    CARPET_INTERVAL  = 2;
    private static final int    BURST_SIZE       = 5;
    private static final int    BURST_INTERVAL   = 3;
    private static final int    KITE_CD          = 6;
    private static final int    SPEED_CD         = 350;
    private static final int    SLOWNESS_DUR     = 40;
    private static final int    DODGE_CD         = 18;

    // ── Урон/эффекты ───────────────────────────────────────────────
    private static final float  SWORD_DMG        = 7.0f;
    private static final float  SNOWBALL_KB      = 0.45f;
    private static final float  CLOSE_DMG        = 5.0f;
    private static final float  CARPET_SLOW_DUR  = 40;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase { KITE, COMBO_SWORD, CARPET_BOMB, CLOSE, BURST }
    private Phase phase = Phase.KITE;

    // ── Состояние ──────────────────────────────────────────────────
    private int   throwCd         = 0;
    private int   swordCd         = 0;
    private int   carpetCd        = 0;
    private int   carpetLeft      = 0;
    private int   carpetTick      = 0;
    private int   burstLeft       = 0;
    private int   burstTick       = 0;
    private int   snowballCount   = 0;   // до combo
    private int   kiteCd          = 0;
    private int   speedCd         = 0;
    private int   dodgeCd         = 0;
    private int   comboSwordHits  = 0;
    private boolean strafeLeft    = true;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public SnowballLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (throwCd    > 0) throwCd--;
        if (swordCd    > 0) swordCd--;
        if (carpetCd   > 0) carpetCd--;
        if (carpetTick > 0) carpetTick--;
        if (burstTick  > 0) burstTick--;
        if (kiteCd     > 0) kiteCd--;
        if (speedCd    > 0) speedCd--;
        if (dodgeCd    > 0) dodgeCd--;

        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1));
            speedCd = SPEED_CD;
        }

        ensureKit();
        double dist = bot.distanceTo(target);
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // INTERRUPT PRIORITY: цель использует предмет — немедленно кидаем
        if (target.isUsingItem() && throwCd <= 0) {
            throwSnowball(sw, target, 0f);
            throwCd = THROW_CD * 2;
        }

        // Выбор фазы
        updatePhase(sw, target, dist);

        switch (phase) {
            case KITE        -> tickKite(sw, target, dist);
            case COMBO_SWORD -> tickComboSword(sw, target, dist);
            case CARPET_BOMB -> tickCarpetBomb(sw, target);
            case CLOSE       -> tickClose(sw, target, dist);
            case BURST       -> tickBurst(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Обновление фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(ServerLevel sw, LivingEntity target, double dist) {
        if (phase == Phase.BURST && burstLeft > 0) return;
        if (phase == Phase.CARPET_BOMB && carpetLeft > 0) return;
        if (phase == Phase.COMBO_SWORD && comboSwordHits < 2) return;

        if (dist < CLOSE_RANGE) { phase = Phase.CLOSE; return; }

        // Ковровая бомбардировка по группе
        if (carpetCd <= 0 && countNearby(sw, target) >= 3) {
            phase = Phase.CARPET_BOMB;
            carpetLeft = CARPET_COUNT; carpetTick = 0;
            carpetCd   = CARPET_CD;
            return;
        }

        // Combo после COMBO_EVERY снежков
        if (snowballCount >= COMBO_EVERY) {
            phase = Phase.COMBO_SWORD;
            snowballCount = 0; comboSwordHits = 0;
            return;
        }

        phase = Phase.KITE;
    }

    // ════════════════════════════════════════════════════════════════
    //  KITE — снежки + кайтинг
    // ════════════════════════════════════════════════════════════════

    private void tickKite(ServerLevel sw, LivingEntity target, double dist) {
        tickKiteMovement(target, dist);
        if (cfg.strafeEnabled) strafe.tick(target);
        if (throwCd > 0 || dist > MAX_RANGE) return;

        // Aim disruption: бросаем когда цель замахивается
        boolean swinging = target.swingTime > 0;
        float spread = swinging ? 0.05f : aimSpread(); // точнее при замахе

        if (swinging || throwCd <= 0) {
            throwSnowball(sw, target, spread);
            snowballCount++;
        }
    }

    private void tickKiteMovement(LivingEntity target, double dist) {
        if (kiteCd > 0) return;
        if (dist < OPT_RANGE * 0.7) {
            // Отходим
            Vec3 away = bot.position().subtract(target.position()).normalize();
            Vec3 side  = strafeLeft
                ? new Vec3(-away.z, 0, away.x) : new Vec3(away.z, 0, -away.x);
            Vec3 move  = away.add(side.scale(0.4)).normalize().scale(0.45);
            bot.setDeltaMovement(bot.getDeltaMovement().add(move.x, 0, move.z));
            bot.setSprinting(true);
            kiteCd = KITE_CD;
        } else if (dist > MAX_RANGE) {
            bot.getNavigation().moveTo(target, 1.1);
        } else if (dist > OPT_RANGE * 1.2) {
            bot.getNavigation().moveTo(target, 0.95);
        } else {
            bot.getNavigation().stop();
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  COMBO_SWORD — 1-2 удара мечом
    // ════════════════════════════════════════════════════════════════

    private void tickComboSword(ServerLevel sw, LivingEntity target, double dist) {
        // Подбегаем для удара
        if (dist > CLOSE_RANGE + 0.5) {
            bot.getNavigation().moveTo(target, 1.2);
            bot.setSprinting(true);
            return;
        }
        if (swordCd > 0) return;

        equipSword();
        if (target.isAlive()) {
            bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 5, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        }
        swordCd = SWORD_CD;
        comboSwordHits++;

        if (comboSwordHits >= 2) {
            phase = Phase.KITE;
            ensureKit(); // обратно снежки
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  CARPET_BOMB — по группе
    // ════════════════════════════════════════════════════════════════

    private void tickCarpetBomb(ServerLevel sw, LivingEntity target) {
        if (carpetTick > 0 || carpetLeft <= 0) {
            if (carpetLeft <= 0) {
                // AoE slowness
                sw.getEntitiesOfClass(LivingEntity.class,
                    target.getBoundingBox().inflate(5.0),
                    e -> e != bot && e.isAlive()
                ).forEach(e -> {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, SLOWNESS_DUR, 1));
                    e.setDeltaMovement(e.getDeltaMovement().scale(0.4));
                });
                phase = Phase.KITE;
            }
            return;
        }

        // Кидаем снежки в ноги цели — разброс по зоне
        Vec3 feet = new Vec3(
            target.getX() + (Math.random() - 0.5) * 2.0,
            target.getY(),
            target.getZ() + (Math.random() - 0.5) * 2.0
        );
        throwSnowballTo(sw, feet, 0.1f);
        carpetLeft--;
        carpetTick = CARPET_INTERVAL;

        // Эффекты
        sw.sendParticles(ParticleTypes.ITEM_SNOWBALL,
            target.getX(), target.getY() + 0.5, target.getZ(), 8, 0.5, 0.2, 0.5, 0.15);
    }

    // ════════════════════════════════════════════════════════════════
    //  CLOSE — вплотную
    // ════════════════════════════════════════════════════════════════

    private void tickClose(ServerLevel sw, LivingEntity target, double dist) {
        // Откат
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.4);
        bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0.1, away.z));

        if (swordCd <= 0 && dist <= CLOSE_RANGE + 0.5) {
            equipSword();
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            swordCd = SWORD_CD;
        }

        if (dist > CLOSE_RANGE + 1.5) {
            phase = Phase.KITE;
            ensureKit();
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  BURST — smoke screen после удара
    // ════════════════════════════════════════════════════════════════

    private void tickBurst(ServerLevel sw, LivingEntity target) {
        if (burstLeft <= 0 || burstTick > 0) {
            if (burstLeft <= 0) phase = Phase.KITE;
            return;
        }

        throwSnowball(sw, target, 0.3f); // быстрые снежки с расширенным спредом
        burstLeft--;
        burstTick = BURST_INTERVAL;
        snowballCount++;
    }

    // ════════════════════════════════════════════════════════════════
    //  Вызвать при получении урона
    // ════════════════════════════════════════════════════════════════

    public void onDamageReceived(float amount, LivingEntity attacker) {
        if (amount < 3.0f || dodgeCd > 0) return;
        burstLeft = BURST_SIZE;
        burstTick = 0;
        phase     = Phase.BURST;

        // Откат
        if (attacker != null) {
            Vec3 away = bot.position().subtract(attacker.position()).normalize().scale(0.55);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0.2, away.z));
        }
        strafe.flipDirection();
        dodgeCd = DODGE_CD;
    }

    // ════════════════════════════════════════════════════════════════
    //  Бросок снежка
    // ════════════════════════════════════════════════════════════════

    private void throwSnowball(ServerLevel sw, LivingEntity target, float spread) {
        Vec3 eye = bot.getEyePosition();
        Vec3 aim = MotionPredictor.predict(target, 2).add(0, target.getBbHeight() * 0.5, 0);
        throwSnowballTo(sw, aim, spread);
        applyHitEffect(sw, target);
        throwCd = THROW_CD;
    }

    private void throwSnowballTo(ServerLevel sw, Vec3 target, float spread) {
        Vec3 eye = bot.getEyePosition();
        Vec3 dir = target.subtract(eye).normalize();

        Snowball sb = new Snowball(net.minecraft.world.entity.EntityType.SNOWBALL, sw);
        sb.setOwner(bot);
        sb.moveTo(eye.x, eye.y, eye.z);
        sb.shoot(dir.x, dir.y, dir.z, 1.5f, spread);
        sw.addFreshEntity(sb);
        bot.playSound(SoundEvents.SNOWBALL_THROW, 0.5f, 0.9f + (float)(Math.random() * 0.2));
    }

    /** Knockback + визуальный эффект попадания. */
    private void applyHitEffect(ServerLevel sw, LivingEntity target) {
        if (!target.isAlive()) return;
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(
            target.getDeltaMovement().add(dir.x * SNOWBALL_KB, 0.1, dir.z * SNOWBALL_KB));
        sw.sendParticles(ParticleTypes.ITEM_SNOWBALL,
            target.getX(), target.getY() + 1, target.getZ(), 4, 0.2, 0.2, 0.2, 0.05);
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    private int countNearby(ServerLevel sw, LivingEntity primary) {
        return sw.getEntitiesOfClass(LivingEntity.class,
            primary.getBoundingBox().inflate(5.0),
            e -> e != bot && e.isAlive()).size();
    }

    private float aimSpread() {
        return switch (bot.getEffectiveDifficulty()) {
            case EXPERT -> 0.8f;
            case HARD   -> 1.4f;
            case MEDIUM -> 2.2f;
            default     -> 3.5f;
        };
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness",5).enchant("unbreaking",3).build());
    }

    private void ensureKit() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SNOWBALL))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.SNOWBALL, 64));
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(Items.NETHERITE_HELMET, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (bot.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(Items.NETHERITE_CHESTPLATE, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(Items.NETHERITE_LEGGINGS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(Items.NETHERITE_BOOTS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
    }

    public void reset() {
        phase = Phase.KITE;
        throwCd = 0; swordCd = 0; carpetCd = 0;
        carpetLeft = 0; carpetTick = 0;
        burstLeft = 0; burstTick = 0;
        snowballCount = 0; kiteCd = 0; speedCd = 0;
        dodgeCd = 0; comboSwordHits = 0;
    }

    public String getStateLabel() {
        return "SNOW:" + switch (phase) {
            case KITE        -> "×" + snowballCount + "/" + COMBO_EVERY;
            case COMBO_SWORD -> "SWORD!";
            case CARPET_BOMB -> "CARPET×" + carpetLeft;
            case CLOSE       -> "CLOSE";
            case BURST       -> "BURST×" + burstLeft;
        };
    }
}
