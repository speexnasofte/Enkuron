package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.windcharge.WindCharge;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * MaceElytraLogic v7.0 — Pro Mace+Elytra combo.
 *
 * ══════════════════════════════════════════════════════
 *  ПРО-КОМБО (как играют топ МС-Тирс игроки):
 *
 *  1. PEARL_CLOSE  — если цель далеко (> 18 блоков):
 *       бросает эндер-перл к цели → телепорт → сразу WIND_UP
 *
 *  2. WIND_UP — бросает wind charge под ноги СЕБЕ:
 *       взрыв даёт импульс вверх → надевает элитры →
 *       wind charge = быстрый старт вверх (не фейерверки!)
 *
 *  3. ASCEND — летит вверх на элитрах + повторные wind charge
 *       в себя (Wind Burst на мейсе даёт wind charge при ударе,
 *       но здесь используем прямые снаряды):
 *       набирает ASCEND_HEIGHT = 24 блока над целью
 *
 *  4. GLIDE_AIM — снимает элитры, пикирует на цель,
 *       корректирует курс каждый тик (predict движения цели)
 *
 *  5. DIVE_SMASH — снимает элитры перед ударом → надевает
 *       нагрудник → удар булавой с Wind Burst.
 *       Wind Burst при ударе автоматически отбрасывает цель + даёт
 *       ещё импульс вверх — если хочет повторить комбо, сразу
 *       прыгает и letит заново.
 *
 *  6. RELAUNCH (опционально) — если цель ещё жива и HP бота > 8:
 *       немедленно повторяет WIND_UP → ASCEND → SMASH.
 *       Топ-игроки делают 2-3 пике подряд.
 *
 *  7. COOLDOWN — короткая пауза, добивает в ближнем бою.
 *
 * ══════════════════════════════════════════════════════
 *  ЭКИП:
 *   - CHEST: Elytra (во время полёта) / Netherite Chestplate (во время удара)
 *   - MAIN: Mace с Wind Burst III + Density V + Breach IV + Unbreaking III + Mending
 *   - OFF:  Totem of Undying
 *   - REST: Netherite helmet/legs/boots
 *
 *  Wind Burst III на мейсе — при смэше автоматически даёт
 *  wind charge эффект → можно сразу снова лететь вверх!
 * ══════════════════════════════════════════════════════
 */
public class MaceElytraLogic {

    // ── Дистанции ─────────────────────────────────────────────────
    /** Дистанция для броска перла к цели (закрыть gap) */
    private static final double PEARL_CLOSE_DIST  = 18.0;
    /** Дистанция после перла — цель достаточно близко для WIND_UP */
    private static final double WIND_UP_DIST      = 14.0;
    /** Радиус ветрового заряда (бросаем под себя) */
    private static final double WIND_DIST         = 9.0;
    /** Смэш попадает если dist <= этого */
    private static final double SMASH_DIST        = 4.5;
    /** Минимальная дистанция для подъёма — не прыгаем прямо на цели */
    private static final double MIN_ASCEND_DIST   = 4.0;

    // ── Подъём ────────────────────────────────────────────────────
    /** На сколько блоков выше цели поднимаемся */
    private static final double ASCEND_HEIGHT     = 24.0;
    /** Интервал в тиках между wind charge при подъёме */
    private static final int    WC_INTERVAL       = 7;
    /** Максимум wind charge за один подъём */
    private static final int    MAX_WC            = 6;

    // ── Кулдауны ─────────────────────────────────────────────────
    /** Полный кулдаун после смэша */
    private static final int    FULL_CD           = 35;
    /** Кулдаун wind charge (чтобы не спамить) */
    private static final int    WIND_CD           = 30;
    /** Кулдаун перла */
    private static final int    PEARL_CD          = 60;
    /** Кулдаун наземного удара */
    private static final int    GROUND_CD         = 12;
    /** Кулдаун strength */
    private static final int    STR_CD            = 300;
    /** Таймаут пике (тиков) — если не попали, fallback */
    private static final int    DIVE_TIMEOUT      = 160;
    /** Кулдаун relaunch — сколько тиков после смэша до повторного подъёма */
    private static final int    RELAUNCH_DELAY    = 8;

    // ── Урон ─────────────────────────────────────────────────────
    private static final float  BASE_DAMAGE       = 12.0f;
    private static final float  VEL_MULT          = 8.0f;
    private static final float  HEIGHT_MULT       = 2.0f;
    private static final float  MAX_DAMAGE        = 60.0f;

    // ── Состояние ────────────────────────────────────────────────
    /**
     * Фазы комбо:
     *  IDLE       — ждём, оцениваем, наземный бой
     *  PEARL_CLOSE— бросаем перл к цели (gap close)
     *  WIND_UP    — первый wind charge под себя + прыжок
     *  ASCEND     — летим вверх на элитрах + wind charge
     *  GLIDE_AIM  — пикируем на цель (корректируем курс)
     *  DIVE_SMASH — наносим удар
     *  RELAUNCH   — короткая пауза → снова WIND_UP
     *  COOLDOWN   — отдыхаем
     */
    private enum Phase {
        IDLE, PEARL_CLOSE, WIND_UP, ASCEND, GLIDE_AIM, DIVE_SMASH, RELAUNCH, COOLDOWN
    }

    private Phase phase           = Phase.IDLE;
    private int   cdTimer         = 0;
    private int   wcTimer         = 0;    // таймер между wind charge при подъёме
    private int   wcUsed          = 0;    // сколько WC использовано за подъём
    private int   windCd          = 0;    // кулдаун wind charge вообще
    private int   pearlCd         = 0;    // кулдаун перла
    private int   groundCd        = 0;    // кулдаун наземного удара
    private int   strCd           = 0;    // кулдаун strength
    private int   diveTimeout     = 0;    // таймер пике
    private int   relaunchTimer   = 0;    // таймер до повторного подъёма
    private int   smashCount      = 0;    // сколько смэшей сделали (для relaunch)

    private double ascendTargetY  = 0;    // целевая высота подъёма
    private double ascendStartY   = 0;    // начальная высота
    private double speedAtHit     = 0;    // скорость при ударе (для урона)

    // Pearl close: ждём телепортации
    private int    pearlWaitTimer = 0;

    private final BotEntity bot;

    public MaceElytraLogic(BotEntity bot) { this.bot = bot; }

    // ════════════════════════════════════════════════════════════
    //  MAIN TICK
    // ════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        // Декрементируем все таймеры
        if (cdTimer       > 0) cdTimer--;
        if (wcTimer       > 0) wcTimer--;
        if (windCd        > 0) windCd--;
        if (pearlCd       > 0) pearlCd--;
        if (groundCd      > 0) groundCd--;
        if (strCd         > 0) strCd--;
        if (diveTimeout   > 0) diveTimeout--;
        if (relaunchTimer > 0) relaunchTimer--;
        if (pearlWaitTimer > 0) pearlWaitTimer--;

        // Strength всегда активен
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 1));
            strCd = STR_CD;
        }

        ensureKit();

        if (target == null || !target.isAlive()) {
            phase = Phase.IDLE;
            forceUnequipElytra();
            return;
        }

        double dist = bot.distanceTo(target);
        bot.getLookControl().setLookAt(target, 30f, 30f);

        switch (phase) {
            case IDLE        -> tickIdle(sw, target, dist);
            case PEARL_CLOSE -> tickPearlClose(sw, target, dist);
            case WIND_UP     -> tickWindUp(sw, target);
            case ASCEND      -> tickAscend(sw, target);
            case GLIDE_AIM   -> tickGlide(sw, target);
            case DIVE_SMASH  -> tickSmash(sw, target);
            case RELAUNCH    -> tickRelaunch(sw, target, dist);
            case COOLDOWN    -> tickCooldown(sw, target, dist);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  IDLE — стоим, оцениваем обстановку
    // ════════════════════════════════════════════════════════════

    private void tickIdle(ServerLevel sw, LivingEntity target, double dist) {
        // Наземный удар пока кулдаун
        if (cdTimer > 0) {
            if (dist <= 3.8 && groundCd <= 0) doGroundHit(sw, target);
            return;
        }

        equipMace();

        // ── 1. Цель ДАЛЕКО — бросаем перл чтобы закрыть дистанцию ──
        // Профи: Pearl → сразу после телепорта Wind Charge вверх → Ascend → Smash
        if (dist > PEARL_CLOSE_DIST && pearlCd <= 0) {
            if (throwPearl(sw, target)) {
                phase         = Phase.PEARL_CLOSE;
                pearlWaitTimer = 25; // ждём ~1.25 сек пока перл долетит
                pearlCd       = PEARL_CD;
                notifyOwner("§b[MaceElytra] §f🪬 Pearl → closing gap §7(dist=" + (int)dist + ")");
                return;
            }
        }

        // ── 2. Цель в зоне — начинаем подъём (Wind Charge вверх) ──
        if (dist > MIN_ASCEND_DIST && dist < WIND_UP_DIST) {
            startAscend(target);
            return;
        }

        // ── 3. Цель очень близко — наземный удар / wind charge ──
        if (dist <= WIND_DIST && windCd <= 0) {
            // Толкаем цель вверх для создания окна пике
            pushTargetUp(sw, target);
        }
        if (dist <= 3.8 && groundCd <= 0) {
            doGroundHit(sw, target);
        } else {
            bot.getNavigation().moveTo(target, 1.15);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  PEARL_CLOSE — ждём пока перл долетит и телепортирует
    // ════════════════════════════════════════════════════════════

    private void tickPearlClose(ServerLevel sw, LivingEntity target, double dist) {
        if (pearlWaitTimer <= 0 || dist <= WIND_UP_DIST) {
            // Телепортировались (или цель сама подошла) → сразу в WIND_UP
            startAscend(target);
        }
        // Ждём — смотрим на цель
        bot.getLookControl().setLookAt(target, 60f, 30f);
    }

    // ════════════════════════════════════════════════════════════
    //  Вспомогательный: начать подъём
    // ════════════════════════════════════════════════════════════

    private void startAscend(LivingEntity target) {
        ascendStartY  = bot.getY();
        // Цель высоты: максимум из текущей и высоты цели + ASCEND_HEIGHT
        ascendTargetY = Math.max(bot.getY(), target.getY()) + ASCEND_HEIGHT;
        wcUsed  = 0;
        wcTimer = 0;
        equipElytra();
        phase = Phase.WIND_UP;
        bot.getNavigation().stop();
        notifyOwner("§6[MaceElytra] §e⬆ WIND UP → Ascend (target Y=" + (int)ascendTargetY + ")");
    }

    // ════════════════════════════════════════════════════════════
    //  WIND_UP — первый wind charge под себя + прыжок активирует элитры
    // ════════════════════════════════════════════════════════════

    private void tickWindUp(ServerLevel sw, LivingEntity target) {
        equipElytra();

        // Шаг 1: если на земле — прыжок
        if (bot.onGround()) {
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.55, bot.getDeltaMovement().z);
            // Ждём 2 тика перед первым WC
            wcTimer = 2;
            return;
        }

        // Шаг 2: активируем elytra
        if (!bot.isFallFlying() && !bot.onGround()) {
            bot.setElytraFlying(true);
        }

        // Шаг 3: первый wind charge (в себя вниз) когда оторвались от земли
        if (wcTimer <= 0 && bot.isFallFlying()) {
            launchWindChargeSelf(sw);
            wcTimer = WC_INTERVAL;
            wcUsed  = 1;
            phase   = Phase.ASCEND;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  ASCEND — летим вверх, стреляем wind charge под себя
    // ════════════════════════════════════════════════════════════

    private void tickAscend(ServerLevel sw, LivingEntity target) {
        ensureElytraActive();

        double y    = bot.getY();
        double left = ascendTargetY - y;

        // Повторные wind charge пока не набрали высоту
        if (wcTimer <= 0 && wcUsed < MAX_WC && left > 2.0 && bot.isFallFlying()) {
            launchWindChargeSelf(sw);
            wcTimer = WC_INTERVAL;
            wcUsed++;
        }

        // Дрейф к цели горизонтально (чтобы начать пике прямо над ней)
        if (y < ascendTargetY - 1.0) {
            Vec3 vel = bot.getDeltaMovement();
            Vec3 toTarget = new Vec3(
                target.getX() - bot.getX(), 0, target.getZ() - bot.getZ()
            ).normalize().scale(0.12);
            bot.setDeltaMovement(
                clamp(vel.x + toTarget.x, -1.8, 1.8),
                vel.y,
                clamp(vel.z + toTarget.z, -1.8, 1.8)
            );
        } else {
            // Достигли высоты → отключаем элитры, начинаем пике
            bot.setElytraFlying(false);
            phase       = Phase.GLIDE_AIM;
            diveTimeout = DIVE_TIMEOUT;
            notifyOwner("§6[MaceElytra] §c↓ DIVE! H=" + (int)(y - ascendStartY) + "blk");
        }

        // Частицы
        if (bot.tickCount % 3 == 0)
            sw.sendParticles(ParticleTypes.GUST_EMITTER_SMALL,
                bot.getX(), bot.getY() - 0.5, bot.getZ(), 1, 0.1, 0.1, 0.1, 0.0);
    }

    // ════════════════════════════════════════════════════════════
    //  GLIDE_AIM — пике к цели (без элитр = свободное падение + steering)
    // ════════════════════════════════════════════════════════════

    private void tickGlide(ServerLevel sw, LivingEntity target) {
        if (diveTimeout <= 0) {
            // Промахнулись — fallback
            forceUnequipElytra();
            phase   = Phase.COOLDOWN;
            cdTimer = FULL_CD;
            return;
        }

        double dist = bot.distanceTo(target);
        Vec3   vel  = bot.getDeltaMovement();

        // Предсказываем позицию цели на 3 тика вперёд
        Vec3 predicted = MotionPredictor.predict(target, 3);
        Vec3 toTarget  = predicted.subtract(bot.position()).normalize();
        double speed   = vel.length();

        // Steering: если медленно — сильная коррекция; если быстро — лёгкая
        double steerF = speed < 2.0 ? 0.7 : 0.22;
        bot.setDeltaMovement(
            clamp(vel.x + toTarget.x * steerF, -4.2, 4.2),
            vel.y + toTarget.y * steerF - 0.04,
            clamp(vel.z + toTarget.z * steerF, -4.2, 4.2)
        );
        bot.getLookControl().setLookAt(target, 180, 90);

        // Близко к цели — переключаемся на смэш
        if (dist <= SMASH_DIST) {
            // Снимаем элитры, надеваем нагрудник перед ударом
            bot.setElytraFlying(false);
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
            phase = Phase.DIVE_SMASH;
            tickSmash(sw, target);
            return;
        }

        // Промахнулись и уже на земле
        if (bot.onGround() && diveTimeout < 100) {
            forceUnequipElytra();
            doGroundHit(sw, target);
            phase   = Phase.COOLDOWN;
            cdTimer = FULL_CD;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  DIVE_SMASH — удар при пике
    // ════════════════════════════════════════════════════════════

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        if (target == null || !target.isAlive()) {
            forceUnequipElytra();
            phase   = Phase.COOLDOWN;
            cdTimer = FULL_CD;
            return;
        }

        Vec3  vel    = bot.getDeltaMovement();
        speedAtHit   = vel.length();
        double dropH = Math.max(0, bot.getY() - ascendStartY); // высота падения

        float dmg = Math.min(MAX_DAMAGE,
            BASE_DAMAGE + (float)(speedAtHit * VEL_MULT) + (float)(dropH * HEIGHT_MULT));

        // Убедимся что грудной слот — нагрудник (не элитры!)
        bot.setElytraFlying(false);
        if (bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));

        // Экипируем мейс и бьём
        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Knockback
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive())
            target.setDeltaMovement(kb.x * 2.2, 2.0, kb.z * 2.2);

        // Спецэффекты
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(), 32, 0.8, 0.8, 0.8, 0.5);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.3f, 0.65f);

        // Тормозим бота после удара
        bot.setDeltaMovement(vel.x * 0.1, Math.max(vel.y * 0.08, 0), vel.z * 0.1);

        // Agro-buff: Strength II + Absorption II + Speed I
        bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0));

        smashCount++;
        notifyOwner(String.format(
            "§6[MaceElytra] §c💥 SMASH #%d! §e%.0fdmg §7(v=%.1f h=%.0f)",
            smashCount, dmg, speedAtHit, dropH));

        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), dmg);

        // ── RELAUNCH: если цель жива и HP бота > 8 → повторный подъём ──
        // Это и есть "мейс элитра комбо" — несколько пике подряд!
        // Wind Burst на мейсе при ударе даёт импульс вверх — используем его.
        if (target.isAlive() && bot.getHealth() > 8f && smashCount < 3) {
            relaunchTimer = RELAUNCH_DELAY;
            phase = Phase.RELAUNCH;
        } else {
            // Финальный удар — восстанавливаем кит, кулдаун
            smashCount = 0;
            equipElytra(); // снова надеваем элитры на грудь
            phase   = Phase.COOLDOWN;
            cdTimer = FULL_CD;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  RELAUNCH — короткая пауза после смэша → снова вверх
    //  Wind Burst (зачарование на мейсе) уже дал импульс вверх —
    //  мы лишь подхватываем этот импульс элитрами!
    // ════════════════════════════════════════════════════════════

    private void tickRelaunch(ServerLevel sw, LivingEntity target, double dist) {
        if (relaunchTimer <= 0) {
            // Сразу надеваем элитры и летим снова
            equipElytra();
            // Пересчитываем высоту — цель могла переместиться
            ascendStartY  = bot.getY();
            ascendTargetY = Math.max(bot.getY(), target.getY()) + ASCEND_HEIGHT;
            wcUsed  = 0;
            wcTimer = 0;
            phase   = Phase.WIND_UP;
            bot.getNavigation().stop();
            notifyOwner("§6[MaceElytra] §e⬆ RE-LAUNCH #" + smashCount + "!");
        }
        // Пока ждём — смотрим на цель
        bot.getLookControl().setLookAt(target, 60f, 30f);
    }

    // ════════════════════════════════════════════════════════════
    //  COOLDOWN — восстановление, наземные удары
    // ════════════════════════════════════════════════════════════

    private void tickCooldown(ServerLevel sw, LivingEntity target, double dist) {
        if (cdTimer <= 0) {
            smashCount = 0;
            phase = Phase.IDLE;
            return;
        }
        // В кулдауне — бьём наземно если близко
        if (dist <= 3.5 && groundCd <= 0) doGroundHit(sw, target);
        else if (dist > 3.5) bot.getNavigation().moveTo(target, 1.1);
    }

    // ════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════

    /**
     * Wind Charge под себя вниз → взрыв даёт импульс вверх.
     * Именно так делают топ Mace+Elytra игроки для быстрого старта.
     */
    private void launchWindChargeSelf(ServerLevel sw) {
        WindCharge wc = new WindCharge(sw,
            bot.getX(), bot.getY() + 0.4, bot.getZ(),
            new net.minecraft.world.phys.Vec3(0, -1, 0));
        wc.shoot(0, -1, 0, 1.6f, 0.08f);
        sw.addFreshEntity(wc);
        bot.playSound(SoundEvents.WIND_CHARGE_THROW, 0.85f, 1.35f);
        sw.sendParticles(ParticleTypes.GUST,
            bot.getX(), bot.getY(), bot.getZ(), 5, 0.25, 0.2, 0.25, 0.08);
    }

    /**
     * Толчок цели вверх wind charge — создаём окно для пике.
     * Профи применяют это когда враг стоит близко перед подъёмом.
     */
    private void pushTargetUp(ServerLevel sw, LivingEntity target) {
        Vec3 push = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(push.x * 0.9, 2.6, push.z * 0.9);
        target.hurt(sw.damageSources().explosion(null, bot), 3.5f);
        target.igniteForSeconds(2);
        sw.sendParticles(ParticleTypes.GUST,
            target.getX(), target.getY(), target.getZ(), 16, 0.5, 0.5, 0.5, 0.25);
        bot.playSound(SoundEvents.WIND_CHARGE_THROW, 1.1f, 0.85f);
        windCd = WIND_CD;
    }

    /** Эндер-перл к цели для закрытия дистанции. */
    private boolean throwPearl(ServerLevel sw, LivingEntity target) {
        // Проверяем офф-хэнд/мейнхэнд на наличие перла
        // (перл обычно есть у профи в инвентаре)
        Vec3 eye = bot.getEyePosition();
        Vec3 dir = target.getEyePosition().subtract(eye).normalize();
        double hD = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(dir.y, hD));

        ThrownEnderpearl pearl = new ThrownEnderpearl(
            net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        pearl.moveTo(eye.x, eye.y, eye.z, yaw, pitch);
        pearl.shootFromRotation(bot, pitch, yaw, 0.0f, 2.5f, 0.0f);
        sw.addFreshEntity(pearl);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 0.4f + (float)Math.random() * 0.4f);
        return true;
    }

    /** Наземный удар булавой. */
    private void doGroundHit(ServerLevel sw, LivingEntity target) {
        if (!target.isAlive()) return;
        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        bot.doHurtTarget(sw, target);
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 0.8, target.getZ(), 6, 0.2, 0.2, 0.2, 0.06);
        bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
        groundCd = GROUND_CD;
        if (bot.getHeatMap() != null)
            bot.getHeatMap().recordDamageDealt(bot.position(), 10f);
    }

    // ── Экипировка ───────────────────────────────────────────────

    private void ensureKit() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }

    private void equipElytra() {
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
    }

    private void forceUnequipElytra() {
        bot.setElytraFlying(false);
        if (bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
    }

    /** Гарантирует что элитры активны (isFallFlying) если уже в воздухе */
    private void ensureElytraActive() {
        if (!bot.onGround() && !bot.isFallFlying()) {
            bot.setElytraFlying(true);
        }
    }

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.MACE, bot.level().registryAccess())
                    // Wind Burst III: при смэше даёт wind charge эффект → сразу снова вверх!
                    .enchant("wind_burst",  3)
                    // Density V: +3.5 урона за блок падения
                    .enchant("density",     5)
                    // Breach IV: пробивает броню
                    .enchant("breach",      4)
                    .enchant("unbreaking",  3)
                    .enchant("mending",     1)
                    .build());
    }

    // ── Прочее ───────────────────────────────────────────────────

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : Math.min(v, hi);
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    // ── Публичные методы ──────────────────────────────────────────

    public boolean isSmashing() {
        return phase == Phase.GLIDE_AIM || phase == Phase.DIVE_SMASH;
    }

    public boolean isFlying() {
        return phase == Phase.ASCEND || phase == Phase.WIND_UP || phase == Phase.GLIDE_AIM;
    }

    public String getStateLabel() {
        return switch (phase) {
            case IDLE        -> "ME:IDLE";
            case PEARL_CLOSE -> "ME:PEARL→";
            case WIND_UP     -> "ME:WC↑";
            case ASCEND      -> "ME:↑" + wcUsed + "/" + MAX_WC;
            case GLIDE_AIM   -> "ME:DIVE↓";
            case DIVE_SMASH  -> "ME:SMASH!";
            case RELAUNCH    -> "ME:RELAUNCH";
            case COOLDOWN    -> "ME:CD";
        };
    }
}
