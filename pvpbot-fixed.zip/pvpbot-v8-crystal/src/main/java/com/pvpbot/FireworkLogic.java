package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * FireworkLogic v2.0 — Полная переработка.
 *
 * ══════════════════════════════════════════════════════════════════
 *  КОНЦЕПЦИЯ:
 *  Воздушный боец на элитрах. Постоянно держится в воздухе,
 *  атакует фейерверками сверху и с флангов, уклоняется дешами,
 *  наносит меч-удары при пике.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ФАЗЫ:
 *
 *  LAUNCH   — взлёт с земли с помощью фейерверка-ускорителя.
 *             Прыгаем, активируем элитры, стреляем FW вниз.
 *
 *  AERIAL   — воздушный бой. Держимся на высоте AERIAL_HEIGHT
 *             над целью. Стреляем фейерверками вниз. Страфим.
 *
 *  DIVE     — пике на цель. Отключаем элитры, падаем вертикально,
 *             наносим удар мечом при пике (как MaceElytra).
 *
 *  DASH     — боковой уклонение с ускорением фейерверком.
 *             Используется при получении урона или близком
 *             подлёте снаряда.
 *
 *  GROUND   — на земле. Быстрый взлёт обратно.
 *             Короткий sword burst пока летим обратно вверх.
 *
 *  RELOAD   — перезарядка после залпа. Продолжаем лететь.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ТИПЫ ФЕЙЕРВЕРКОВ:
 *
 *  STANDARD — прямой выстрел, 6 урона
 *  BURST    — 3 снаряда в конусе, 4 урона каждый
 *  CARPET   — 5 снарядов широким веером, 3 урона каждый (зона)
 *  DIVE_FW  — под себя при пике (ускорение вниз + урон при взрыве)
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class FireworkLogic {

    // ── Высоты и дистанции ─────────────────────────────────────────
    private static final double AERIAL_HEIGHT    = 12.0;  // высота над целью
    private static final double MIN_HEIGHT       = 6.0;   // минимум — иначе LAUNCH
    private static final double DIVE_START_DIST  = 10.0;  // начинаем пике с этой высоты
    private static final double DIVE_HIT_DIST    = 3.5;   // удар в пике
    private static final double LAUNCH_RANGE     = 18.0;  // стреляем если ближе
    private static final double BURST_RANGE      = 12.0;  // burst если ближе
    private static final double CARPET_RANGE     = 8.0;   // ковровая если ближе

    // ── Кулдауны ───────────────────────────────────────────────────
    private static final int    FW_CD            = 18;    // между залпами
    private static final int    BURST_CD         = 10;    // между burst снарядами
    private static final int    DIVE_CD          = 80;    // между пиками
    private static final int    DASH_CD          = 35;    // между дашами
    private static final int    LAUNCH_CD        = 5;     // тиков до следующего FW при взлёте
    private static final int    SWORD_CD         = 8;
    private static final int    SPEED_CD         = 350;
    private static final int    RELOAD_TICKS     = 22;

    // ── Burst параметры ────────────────────────────────────────────
    private static final int    BURST_COUNT      = 3;
    private static final int    CARPET_COUNT     = 5;
    private static final double BURST_SPREAD     = 0.25; // конус spread
    private static final double CARPET_SPREAD    = 0.55; // широкий веер

    // ── Урон ───────────────────────────────────────────────────────
    private static final float  STD_DMG          = 6.0f;
    private static final float  BURST_DMG        = 4.0f;
    private static final float  CARPET_DMG       = 3.0f;
    private static final float  DIVE_SWORD_DMG   = 10.0f;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase { LAUNCH, AERIAL, DIVE, DASH, GROUND, RELOAD }
    private Phase phase = Phase.GROUND;

    // ── Burst sub-state ────────────────────────────────────────────
    private int   burstLeft      = 0;
    private int   burstTick      = 0;
    private float burstYawOffset = 0;

    // ── Таймеры ────────────────────────────────────────────────────
    private int   fwCd           = 0;
    private int   diveCd         = 0;
    private int   dashCd         = 0;
    private int   launchFwCd     = 0;
    private int   swordCd        = 0;
    private int   speedCd        = 0;
    private int   reloadTimer    = 0;
    private int   diveTimeout    = 0;
    private int   groundTimer    = 0;

    // ── Флаги ──────────────────────────────────────────────────────
    private boolean elytraActive = false;

    private final BotEntity    bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public FireworkLogic(BotEntity bot) { this.bot = bot; }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        if (fwCd        > 0) fwCd--;
        if (diveCd      > 0) diveCd--;
        if (dashCd      > 0) dashCd--;
        if (launchFwCd  > 0) launchFwCd--;
        if (swordCd     > 0) swordCd--;
        if (speedCd     > 0) speedCd--;
        if (reloadTimer > 0) reloadTimer--;
        if (diveTimeout > 0) diveTimeout--;
        if (groundTimer > 0) groundTimer--;
        if (burstTick   > 0) burstTick--;

        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1));
            speedCd = SPEED_CD;
        }

        ensureKit();

        double dist    = bot.distanceTo(target);
        double heightAboveTarget = bot.getY() - target.getY();

        bot.getLookControl().setLookAt(target, 60f, 60f);

        // ── Выбор фазы ────────────────────────────────────────────
        updatePhase(dist, heightAboveTarget);

        // ── Диспатч ───────────────────────────────────────────────
        switch (phase) {
            case LAUNCH  -> tickLaunch(sw, target);
            case AERIAL  -> tickAerial(sw, target, dist, heightAboveTarget);
            case DIVE    -> tickDive(sw, target, dist);
            case DASH    -> tickDash(sw, target);
            case GROUND  -> tickGround(sw, target);
            case RELOAD  -> tickReloadPhase(target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Обновление фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(double dist, double heightAbove) {
        if (phase == Phase.DASH && dashCd > 0) return;
        if (phase == Phase.DIVE && diveTimeout > 0) return;

        if (bot.onGround()) {
            elytraActive = false;
            if (phase != Phase.LAUNCH) {
                phase = groundTimer > 0 ? Phase.GROUND : Phase.LAUNCH;
            }
            return;
        }

        if (reloadTimer > 0 && phase != Phase.DIVE && phase != Phase.DASH) {
            phase = Phase.RELOAD; return;
        }

        // Достаточно высоко — воздушный бой
        if (heightAbove >= MIN_HEIGHT) {
            // Пике каждые DIVE_CD тиков если хорошая высота
            if (diveCd <= 0 && heightAbove >= DIVE_START_DIST && dist <= BURST_RANGE + 2) {
                phase = Phase.DIVE; diveTimeout = 60; return;
            }
            phase = Phase.AERIAL;
            return;
        }

        // Слишком низко — взлёт
        phase = Phase.LAUNCH;
    }

    // ════════════════════════════════════════════════════════════════
    //  LAUNCH — взлёт
    // ════════════════════════════════════════════════════════════════

    private void tickLaunch(ServerLevel sw, LivingEntity target) {
        // Прыгаем и активируем элитры
        if (bot.onGround()) {
            bot.getJumpControl().jump();
            groundTimer = 0;
            return;
        }

        // Активируем элитры как только оторвались
        if (!elytraActive && !bot.onGround()) {
            bot.startFallFlying();
            elytraActive = true;
        }

        // Стреляем FW вниз для ускорения
        if (launchFwCd <= 0 && bot.isFallFlying()) {
            launchFireworkBoost(sw);
            launchFwCd = LAUNCH_CD;
        }

        // Направляем вверх
        Vec3 vel = bot.getDeltaMovement();
        bot.setDeltaMovement(vel.x * 0.92, Math.max(vel.y, 0.5), vel.z * 0.92);
    }

    // ════════════════════════════════════════════════════════════════
    //  AERIAL — воздушный бой
    // ════════════════════════════════════════════════════════════════

    private void tickAerial(ServerLevel sw, LivingEntity target, double dist, double heightAbove) {
        ensureFlying();

        // Держим высоту AERIAL_HEIGHT над целью
        double targetY = target.getY() + AERIAL_HEIGHT;
        Vec3 vel = bot.getDeltaMovement();

        // Горизонтальный дрейф к позиции над целью
        Vec3 toAbove = new Vec3(
            target.getX() - bot.getX(), 0, target.getZ() - bot.getZ()
        );
        double hDist = toAbove.length();
        if (hDist > 3.0) {
            Vec3 hDir = toAbove.normalize().scale(0.1);
            bot.setDeltaMovement(
                clamp(vel.x + hDir.x, -1.5, 1.5),
                vel.y,
                clamp(vel.z + hDir.z, -1.5, 1.5)
            );
        }

        // Вертикальный контроль
        if (bot.getY() < targetY - 1.0) {
            if (launchFwCd <= 0) { launchFireworkBoost(sw); launchFwCd = LAUNCH_CD + 2; }
        } else if (bot.getY() > targetY + 3.0) {
            bot.setDeltaMovement(vel.x, Math.min(vel.y, -0.15), vel.z);
        }

        if (fwCd > 0 || dist > LAUNCH_RANGE) return;

        // Выбор типа залпа по дистанции
        if (burstLeft > 0) {
            if (burstTick <= 0) {
                shootBurstRound(sw, target);
                burstLeft--;
                burstTick = BURST_CD;
                if (burstLeft == 0) { reloadTimer = RELOAD_TICKS; fwCd = FW_CD; }
            }
            return;
        }

        if (dist <= CARPET_RANGE) {
            shootCarpet(sw, target);
            fwCd = FW_CD; reloadTimer = RELOAD_TICKS;
        } else if (dist <= BURST_RANGE) {
            burstLeft = BURST_COUNT;
            burstTick = 1;
            burstYawOffset = 0;
        } else {
            shootStandard(sw, target);
            fwCd = FW_CD; reloadTimer = RELOAD_TICKS;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  DIVE — пике
    // ════════════════════════════════════════════════════════════════

    private void tickDive(ServerLevel sw, LivingEntity target, double dist) {
        // Отключаем элитры для свободного падения
        bot.stopFallFlying();
        elytraActive = false;

        // Steering к цели
        Vec3 vel = bot.getDeltaMovement();
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        bot.setDeltaMovement(
            clamp(vel.x + toTarget.x * 0.3, -3.5, 3.5),
            vel.y - 0.05,
            clamp(vel.z + toTarget.z * 0.3, -3.5, 3.5)
        );

        // Удар мечом при пике
        if (dist <= DIVE_HIT_DIST) {
            equipSword();
            if (target.isAlive()) {
                target.hurt(sw.damageSources().mobAttack(bot), DIVE_SWORD_DMG);
                Vec3 kb = target.position().subtract(bot.position()).normalize();
                target.setDeltaMovement(kb.x * 1.5, 0.8, kb.z * 1.5);
                sw.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY() + 1, target.getZ(), 12, 0.4, 0.4, 0.4, 0.15);
                bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
            }
            diveCd  = DIVE_CD;
            phase   = Phase.LAUNCH;
            diveTimeout = 0;
            bot.setDeltaMovement(vel.x * 0.15, 0.6, vel.z * 0.15);
            return;
        }

        // Таймаут пике
        if (diveTimeout <= 0 || bot.onGround()) {
            phase = Phase.GROUND;
            groundTimer = 8;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  DASH — боковой уклон
    // ════════════════════════════════════════════════════════════════

    private void tickDash(ServerLevel sw, LivingEntity target) {
        ensureFlying();
        if (dashCd <= 0) {
            phase = Phase.AERIAL;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  GROUND — на земле
    // ════════════════════════════════════════════════════════════════

    private void tickGround(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);
        // Быстрый sword burst пока на земле
        if (dist <= 3.5 && swordCd <= 0) {
            equipSword();
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            swordCd = SWORD_CD;
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
        } else {
            bot.getNavigation().moveTo(target, 1.1);
        }
        // Взлёт
        if (groundTimer <= 0) phase = Phase.LAUNCH;
    }

    // ════════════════════════════════════════════════════════════════
    //  RELOAD
    // ════════════════════════════════════════════════════════════════

    private void tickReloadPhase(LivingEntity target) {
        ensureFlying();
        if (reloadTimer <= 0) phase = Phase.AERIAL;
    }

    // ════════════════════════════════════════════════════════════════
    //  Выстрелы
    // ════════════════════════════════════════════════════════════════

    /** Стандартный прямой выстрел. */
    private void shootStandard(ServerLevel sw, LivingEntity target) {
        Vec3 dir = target.getEyePosition().subtract(bot.getEyePosition()).normalize();
        spawnFW(sw, dir, 1.6f);
        if (target.isAlive()) target.hurt(sw.damageSources().explosion(bot, bot), STD_DMG);
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
        sw.sendParticles(ParticleTypes.FIREWORK, bot.getX(), bot.getEyeY(), bot.getZ(),
            3, 0.1, 0.1, 0.1, 0.05);
    }

    /** Один снаряд burst с угловым смещением. */
    private void shootBurstRound(ServerLevel sw, LivingEntity target) {
        float angle = burstYawOffset;
        Vec3 base = target.getEyePosition().subtract(bot.getEyePosition()).normalize();
        Vec3 dir = rotateY(base, Math.toRadians(angle));
        dir = dir.add(0, -0.05 * (BURST_COUNT - burstLeft), 0).normalize();
        spawnFW(sw, dir, 1.5f);
        if (target.isAlive()) target.hurt(sw.damageSources().explosion(bot, bot), BURST_DMG);
        burstYawOffset += BURST_SPREAD * 50;
        sw.sendParticles(ParticleTypes.FIREWORK, bot.getX(), bot.getEyeY(), bot.getZ(),
            2, 0.05, 0.05, 0.05, 0.03);
    }

    /** Ковровый залп: 5 снарядов веером вниз. */
    private void shootCarpet(ServerLevel sw, LivingEntity target) {
        Vec3 base = target.getEyePosition().subtract(bot.getEyePosition()).normalize();
        for (int i = 0; i < CARPET_COUNT; i++) {
            double angle = (i - CARPET_COUNT / 2.0) * CARPET_SPREAD;
            Vec3 dir = rotateY(base, angle).add(0, -0.12, 0).normalize();
            spawnFW(sw, dir, 1.3f);
        }
        // AoE урон
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(3.5),
            e -> e != bot && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().explosion(bot, bot), CARPET_DMG));
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.1f, 0.7f);
        sw.sendParticles(ParticleTypes.FIREWORK,
            target.getX(), target.getY() + 1, target.getZ(), 20, 1.0, 0.3, 1.0, 0.1);
    }

    /** FW вниз под себя для ускорения при взлёте. */
    private void launchFireworkBoost(ServerLevel sw) {
        spawnFW(sw, new Vec3(0, -1, 0), 2.0f);
        sw.sendParticles(ParticleTypes.FIREWORK,
            bot.getX(), bot.getY(), bot.getZ(), 5, 0.2, 0.1, 0.2, 0.05);
    }

    private void spawnFW(ServerLevel sw, Vec3 dir, float speed) {
        FireworkRocketEntity fw = new FireworkRocketEntity(
            sw, bot, bot.getX(), bot.getEyeY(), bot.getZ(), new ItemStack(Items.FIREWORK_ROCKET));
        fw.setDeltaMovement(dir.x * speed, dir.y * speed, dir.z * speed);
        sw.addFreshEntity(fw);
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    public void onDamageReceived(float amount, LivingEntity attacker) {
        if (amount < 4.0f || dashCd > 0 || attacker == null) return;
        // Боковой уклон при получении урона
        Vec3 away = bot.position().subtract(attacker.position()).normalize();
        Vec3 side  = new Vec3(-away.z, 0.3, away.x).scale(1.2);
        bot.setDeltaMovement(bot.getDeltaMovement().add(side));
        if (bot.level() instanceof ServerLevel sw) {
            launchFireworkBoost(sw);
        }
        dashCd = DASH_CD;
        phase  = Phase.DASH;
    }

    private void ensureFlying() {
        if (!bot.onGround() && !bot.isFallFlying()) {
            bot.startFallFlying();
            elytraActive = true;
        }
    }

    private void equipSword() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness",5).enchant("unbreaking",3).build());
    }

    private void ensureKit() {
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(Items.ELYTRA, bot.level().registryAccess())
                    .enchant("unbreaking",3).enchant("mending",1).build());
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(Items.NETHERITE_HELMET, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(Items.NETHERITE_LEGGINGS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(Items.NETHERITE_BOOTS, bot.level().registryAccess())
                    .enchant("protection",4).enchant("unbreaking",3).build());
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_SWORD)
                && !bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.FIREWORK_ROCKET))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.FIREWORK_ROCKET, 64));
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private static Vec3 rotateY(Vec3 v, double angle) {
        double cos = Math.cos(angle), sin = Math.sin(angle);
        return new Vec3(v.x * cos + v.z * sin, v.y, -v.x * sin + v.z * cos);
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : Math.min(v, hi);
    }

    public void reset() {
        phase = Phase.GROUND; burstLeft = 0; burstTick = 0; burstYawOffset = 0;
        fwCd = 0; diveCd = 0; dashCd = 0; launchFwCd = 0;
        swordCd = 0; speedCd = 0; reloadTimer = 0; diveTimeout = 0;
        groundTimer = 0; elytraActive = false;
    }

    public String getStateLabel() {
        return "FW:" + switch (phase) {
            case LAUNCH  -> "LAUNCH";
            case AERIAL  -> burstLeft > 0 ? "BURST" + burstLeft : "AERIAL";
            case DIVE    -> "DIVE!";
            case DASH    -> "DASH";
            case GROUND  -> "GROUND";
            case RELOAD  -> "RELOAD";
        };
    }
}
