package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * CrystalBotLogic v8.0 — FULL REWRITE
 *
 * ════════════════════════════════════════════════════════════════
 *  Архитектура: 5 фаз с чёткими переходами
 * ════════════════════════════════════════════════════════════════
 *
 *  APPROACH    → Сближение, спринт к цели, эндер-жемчуг gap close
 *  SETUP       → Укладка обсидиана по умным позициям (макс. урон)
 *  PLACE       → Спавн кристаллов на лучших базах (2 штуки)
 *  EXPLODE     → Взрыв + KB-меч + предсказание позиции цели (PatternAI)
 *  RETREAT     → Отступ, хил, ждём восстановления
 *
 * ════════════════════════════════════════════════════════════════
 *  Ключевые улучшения v8:
 * ════════════════════════════════════════════════════════════════
 *
 *  ✦ APPROACH-фаза: чёткое сближение вместо loop в PLACE_OBS
 *  ✦ SmartBase scoring: выбираем базы с максимальным уроном по цели
 *  ✦ Dual crystal: 2 кристалла одновременно → двойной взрыв
 *  ✦ PatternAI: бросок кристалла на ПРЕДСКАЗАННУЮ позицию цели
 *  ✦ AntiTotem window: детект pop → мгновенный второй взрыв
 *  ✦ SelfDmg guard: не взрываем если сами в радиусе поражения
 *  ✦ Orbit с фазовым сдвигом (не стоим на одном месте)
 *  ✦ Weakness зелье против щита (цель не может блокировать)
 *  ✦ Strength III + Speed II баффы всегда активны
 *  ✦ Zigzag retreat с авто-хилом
 *  ✦ SelfExplosionDmg: берём dmg из cfg.diffCrystalDamage
 *  ✦ getPhaseLabel() — расширенный статус для HUD
 */
public class CrystalBotLogic {

    // ═══════════════════════════════════════════════════════════════
    //  Фазы
    // ═══════════════════════════════════════════════════════════════
    private enum Phase { APPROACH, SETUP, PLACE, EXPLODE, RETREAT }

    // ═══════════════════════════════════════════════════════════════
    //  Дистанции
    // ═══════════════════════════════════════════════════════════════
    private static final double APPROACH_DIST   = 14.0; // дальше — спринт + жемчуг
    private static final double ENGAGE_DIST     = 7.0;  // вошли в зону — начинаем SETUP
    private static final double PLACE_RANGE     = 5.5;  // радиус спавна кристалла
    private static final double EXPLODE_RANGE   = 7.5;  // взрываем если кристалл ≤ 7.5 от цели
    private static final double MELEE_RANGE     = 3.2;  // мечом тянемся
    private static final double ORBIT_RADIUS    = 3.8;  // орбитальный радиус
    private static final double SAFE_SELF_DIST  = 5.0;  // не взрываем если сам ближе этого к кристаллу

    // ═══════════════════════════════════════════════════════════════
    //  Кулдауны (в тиках)
    // ═══════════════════════════════════════════════════════════════
    private static final int OBS_CD         = 2;   // укладка обсидиана
    private static final int PLACE_CD       = 3;   // спавн кристалла
    private static final int EXPLODE_CD     = 2;   // взрыв
    private static final int SWORD_CD       = 7;   // KB-меч
    private static final int PEARL_CD       = 80;  // эндер-жемчуг
    private static final int GAP_CD         = 220; // gap apple
    private static final int SPEED_CD       = 400;
    private static final int STR_CD         = 400;
    private static final int WEAKNESS_CD    = 140; // слабость на щит
    private static final int ORBIT_CD       = 5;   // обновление орбиты
    private static final int RETREAT_TICKS  = 60;  // ждём после отступа
    private static final int ANTI_TOTEM_CD  = 4;   // промежуток между anti-totem ударами

    // ═══════════════════════════════════════════════════════════════
    //  Обсидиан: сколько блоков нужно перед PLACE
    // ═══════════════════════════════════════════════════════════════
    private static final int OBS_NEEDED = 2;

    // ═══════════════════════════════════════════════════════════════
    //  Ссылки
    // ═══════════════════════════════════════════════════════════════
    private final BotEntity       bot;
    private final PVPBotConfig    cfg         = PVPBotConfig.INSTANCE;
    private final ObsidianPlacer  obsidianPlacer = new ObsidianPlacer();

    // ═══════════════════════════════════════════════════════════════
    //  Состояние
    // ═══════════════════════════════════════════════════════════════
    private Phase   phase       = Phase.APPROACH;
    private float   orbitAngle  = 0f;

    // Таймеры
    private int obsTimer        = 0;
    private int placeTimer      = 0;
    private int explodeTimer    = 0;
    private int swordTimer      = 0;
    private int pearlCd         = 0;
    private int gapCd           = 0;
    private int speedCd         = 0;
    private int strCd           = 0;
    private int weaknessCd      = 0;
    private int orbitTimer      = 0;
    private int retreatTimer    = 0;
    private int antiTotemCd     = 0;

    // Размещённые кристаллы
    private EndCrystal crystal1 = null;
    private EndCrystal crystal2 = null;

    // AntiTotem
    private float  targetLastHp      = -1f;
    private int    antiTotemHitsLeft = 0;

    // ═══════════════════════════════════════════════════════════════
    //  Конструктор
    // ═══════════════════════════════════════════════════════════════
    public CrystalBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Главный тик
    // ═══════════════════════════════════════════════════════════════
    public void tick(ServerLevel sw, LivingEntity target) {
        if (sw == null || target == null || !target.isAlive()) return;

        // ── Таймеры ──────────────────────────────────────────────
        tickTimers();

        double dist  = bot.distanceTo(target);
        float  myHp  = bot.getHealth();

        // ── Тотем всегда в оффхенде ──────────────────────────────
        bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // ── Баффы всегда активны ─────────────────────────────────
        applyBuffs();

        // ── Приоритет: критически низкое HP → RETREAT ─────────────
        if (myHp < 5.0f && phase != Phase.RETREAT) {
            phase = Phase.RETREAT;
            retreatTimer = RETREAT_TICKS;
        }

        // ── AntiTotem: детект pop тотема у цели ──────────────────
        tickAntiTotem(sw, target, dist);

        // ── Фазовый автомат ──────────────────────────────────────
        switch (phase) {
            case APPROACH -> tickApproach(sw, target, dist);
            case SETUP    -> tickSetup(sw, target, dist);
            case PLACE    -> tickPlace(sw, target, dist);
            case EXPLODE  -> tickExplode(sw, target, dist);
            case RETREAT  -> tickRetreat(sw, target, dist, myHp);
        }

        // ── Орбита (все фазы кроме RETREAT и APPROACH) ───────────
        if (phase == Phase.SETUP || phase == Phase.PLACE || phase == Phase.EXPLODE) {
            updateOrbit(target, dist);
        }

        // ── Weakness против щита ─────────────────────────────────
        tickWeakness(sw, target, dist);

        // ── KB-меч в фазе EXPLODE ─────────────────────────────────
        if (phase == Phase.EXPLODE) {
            tickSwordKB(sw, target, dist);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  APPROACH: сближение к цели
    // ═══════════════════════════════════════════════════════════════
    private void tickApproach(ServerLevel sw, LivingEntity target, double dist) {
        if (dist <= ENGAGE_DIST) {
            phase = Phase.SETUP;
            return;
        }

        bot.setSprinting(true);
        bot.getNavigation().moveTo(target, 1.5);

        // Жемчуг если далеко
        if (dist > APPROACH_DIST && pearlCd <= 0) {
            doPearl(sw, target);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  SETUP: укладка обсидиана + подсчёт
    // ═══════════════════════════════════════════════════════════════
    private void tickSetup(ServerLevel sw, LivingEntity target, double dist) {
        // Отдалились — возврат к сближению
        if (dist > ENGAGE_DIST + 2.0) {
            phase = Phase.APPROACH;
            return;
        }

        if (obsTimer <= 0) {
            obsidianPlacer.tick(sw, bot, target);
            obsTimer = OBS_CD;
        }

        int obsCount = countObsidianNear(sw, target);
        if (obsCount >= OBS_NEEDED) {
            phase = Phase.PLACE;
            log("§e[Crystal] База готова (" + obsCount + " блоков) → PLACE");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  PLACE: спавн кристаллов на лучших позициях
    // ═══════════════════════════════════════════════════════════════
    private void tickPlace(ServerLevel sw, LivingEntity target, double dist) {
        if (placeTimer > 0) return;

        // База обсидиана пропала (цель убежала)
        if (!ObsidianPlacer.hasBase(sw, target)) {
            phase = Phase.SETUP;
            return;
        }

        List<BlockPos> bases = findAllCrystalBases(sw, target);
        if (bases.isEmpty()) {
            phase = Phase.SETUP;
            return;
        }

        // Скоринг: выбираем базу ближайшую к цели для макс. урона
        bases.sort(Comparator.comparingDouble(b ->
            b.above().getCenter().distanceTo(target.position())));

        // Первый кристалл — ближайший к цели
        if (crystal1 == null || crystal1.isRemoved()) {
            crystal1 = spawnCrystal(sw, bases.get(0).above());
            if (crystal1 != null) log("§a[Crystal] Кристалл #1 поставлен");
        }

        // Второй кристалл — на другой базе (если есть)
        if (bases.size() >= 2 && (crystal2 == null || crystal2.isRemoved())) {
            crystal2 = spawnCrystal(sw, bases.get(1).above());
            if (crystal2 != null) log("§a[Crystal] Кристалл #2 поставлен");
        }

        placeTimer = PLACE_CD;

        // Хоть один кристалл поставили → взрываем
        if (crystal1 != null || crystal2 != null) {
            phase = Phase.EXPLODE;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  EXPLODE: взрыв кристаллов
    // ═══════════════════════════════════════════════════════════════
    private void tickExplode(ServerLevel sw, LivingEntity target, double dist) {
        if (explodeTimer > 0) return;

        // Ищем все кристаллы в зоне
        AABB searchBox = target.getBoundingBox().inflate(EXPLODE_RANGE + 2.0);
        List<EndCrystal> nearby = sw.getEntitiesOfClass(EndCrystal.class, searchBox, e -> true);

        if (nearby.isEmpty()) {
            crystal1 = null;
            crystal2 = null;
            phase = Phase.SETUP;
            return;
        }

        // PatternAI: предсказываем позицию цели через 2 тика
        Vec3 predictedTargetPos = bot.getPatternAI().getPredictedPosition(target);

        // Выбираем кристалл с максимальным уроном по предсказанной позиции
        EndCrystal best = nearby.stream()
            .filter(c -> c.position().distanceTo(predictedTargetPos) <= EXPLODE_RANGE)
            .filter(c -> bot.distanceTo(c) >= SAFE_SELF_DIST) // SelfDmg guard
            .min(Comparator.comparingDouble(c -> c.position().distanceTo(predictedTargetPos)))
            .orElse(null);

        if (best == null) {
            // Кристалл есть, но цель не в зоне или мы сами слишком близко
            // Перемещаемся чтобы выйти за безопасную дистанцию
            repositionFromCrystal(nearby.get(0));
            return;
        }

        double crystalDistToTarget = best.position().distanceTo(predictedTargetPos);
        boolean targetInAir = !target.onGround();

        // Базовый урон + воздушный бонус
        float baseDmg = (float) cfg.diffCrystalDamage;
        float airMul  = targetInAir ? 1.5f : 1.0f;
        // Масштаб по дистанции: ближе = больнее (7.5 → 0, 0 → полный урон)
        float distScale = (float) Math.max(0.1, (EXPLODE_RANGE - crystalDistToTarget) / EXPLODE_RANGE);
        float damage = baseDmg * airMul * distScale;

        if (damage > 0.5f && target.isAlive()) {
            target.hurt(sw.damageSources().explosion(bot, bot), damage);
        }

        // Knockback от взрыва
        Vec3 kb = predictedTargetPos.subtract(best.position()).normalize();
        target.setDeltaMovement(target.getDeltaMovement().add(kb.x * 1.3, 0.75, kb.z * 1.3));

        // Визуал + звук
        sw.sendParticles(ParticleTypes.EXPLOSION,
            best.getX(), best.getY(), best.getZ(), 8, 0.9, 0.9, 0.9, 0.1);
        bot.playSound(SoundEvents.GENERIC_EXPLODE.value(), 1.5f, 1.0f);

        log(String.format("§c[Crystal] BOOM! §e%.1f dmg §7(%.1f от цели%s)",
            damage, crystalDistToTarget, targetInAir ? " +воздух" : ""));

        best.discard();
        cleanupCrystalRef(best);

        // Второй кристалл — взрываем сразу
        detonateSecond(sw, target, nearby, best, baseDmg);

        explodeTimer = EXPLODE_CD;
        phase = Phase.SETUP;
    }

    /** Взрываем второй кристалл немедленно после первого */
    private void detonateSecond(ServerLevel sw, LivingEntity target,
                                 List<EndCrystal> nearby, EndCrystal justBurst, float baseDmg) {
        nearby.stream()
            .filter(c -> c != justBurst && !c.isRemoved())
            .filter(c -> c.distanceTo(target) <= EXPLODE_RANGE)
            .filter(c -> bot.distanceTo(c) >= SAFE_SELF_DIST)
            .min(Comparator.comparingDouble(c -> c.distanceTo(target)))
            .ifPresent(c -> {
                float d2Scale = (float) Math.max(0.1,
                    (EXPLODE_RANGE - c.distanceTo(target)) / EXPLODE_RANGE);
                float dmg2 = baseDmg * 0.85f * d2Scale;
                if (dmg2 > 0.5f && target.isAlive())
                    target.hurt(sw.damageSources().explosion(bot, bot), dmg2);
                Vec3 kb2 = target.position().subtract(c.position()).normalize();
                target.setDeltaMovement(target.getDeltaMovement().add(kb2.x, 0.5, kb2.z));
                sw.sendParticles(ParticleTypes.EXPLOSION,
                    c.getX(), c.getY(), c.getZ(), 4, 0.5, 0.5, 0.5, 0.05);
                c.discard();
                cleanupCrystalRef(c);
                log(String.format("§6[Crystal] Double BOOM! +%.1f dmg", dmg2));
            });
    }

    // ═══════════════════════════════════════════════════════════════
    //  RETREAT: отступ и лечение
    // ═══════════════════════════════════════════════════════════════
    private void tickRetreat(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        retreatTimer--;

        // Gap apple хил
        if (gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 0));
            gapCd = GAP_CD;
        }

        // Zigzag отступ
        Vec3 away = bot.position().subtract(target.position()).normalize();
        double zigzag = (retreatTimer % 20 < 10) ? 1.5 : -1.5;
        Vec3 perpendicular = new Vec3(-away.z, 0, away.x).scale(zigzag);
        Vec3 dest = bot.position().add(away.scale(6)).add(perpendicular);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.35);

        // Жемчуг если цель вплотную
        if (dist < 4.0 && pearlCd <= 0) {
            doPearl(sw, target);
        }

        // Восстановились — назад в бой
        if (myHp >= 12.0f || retreatTimer <= 0) {
            phase = Phase.APPROACH;
            log("§b[Crystal] Восстановились → APPROACH");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Орбита вокруг цели
    // ═══════════════════════════════════════════════════════════════
    private void updateOrbit(LivingEntity target, double dist) {
        if (orbitTimer > 0) return;
        orbitTimer = ORBIT_CD;

        // Фазовый сдвиг = не стоим на одном месте
        orbitAngle += (float)(Math.PI * 0.35);

        if (dist > PLACE_RANGE + 1.0) {
            // Слишком далеко — сближаемся
            bot.getNavigation().moveTo(target, 1.2);
        } else if (dist < ORBIT_RADIUS - 0.8) {
            // Слишком близко — отходим
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 3.0,
                bot.getY(),
                bot.getZ() + away.z * 3.0, 1.1);
        } else {
            // Орбита
            double tx = target.getX() + Math.cos(orbitAngle) * ORBIT_RADIUS;
            double tz = target.getZ() + Math.sin(orbitAngle) * ORBIT_RADIUS;
            bot.getNavigation().moveTo(tx, target.getY(), tz, 1.05);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  KB-меч: толкаем цель К ближайшему кристаллу
    // ═══════════════════════════════════════════════════════════════
    private void tickSwordKB(ServerLevel sw, LivingEntity target, double dist) {
        if (dist > MELEE_RANGE || swordTimer > 0) return;

        // Ищем ближайший кристалл к цели
        AABB box = target.getBoundingBox().inflate(9.0);
        List<EndCrystal> crystals = sw.getEntitiesOfClass(EndCrystal.class, box, e -> true);

        Vec3 pushDir;
        if (!crystals.isEmpty()) {
            EndCrystal nearest = crystals.stream()
                .min(Comparator.comparingDouble(c -> c.distanceToSqr(target)))
                .orElse(null);
            if (nearest != null) {
                // Толкаем К кристаллу (не от бота)
                pushDir = nearest.position().subtract(target.position()).normalize();
            } else {
                pushDir = target.position().subtract(bot.position()).normalize();
            }
        } else {
            pushDir = target.position().subtract(bot.position()).normalize();
        }

        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Применяем KB к цели
        target.setDeltaMovement(
            target.getDeltaMovement().add(pushDir.x * 0.85, 0.22, pushDir.z * 0.85));

        swordTimer = SWORD_CD;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Weakness против щита
    // ═══════════════════════════════════════════════════════════════
    private void tickWeakness(ServerLevel sw, LivingEntity target, double dist) {
        if (weaknessCd > 0 || dist > 5.0) return;
        // Цель блокирует щитом?
        if (target.isBlocking()) {
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
            sw.sendParticles(ParticleTypes.SPLASH,
                target.getX(), target.getY() + 1, target.getZ(), 6, 0.3, 0.3, 0.3, 0.05);
            weaknessCd = WEAKNESS_CD;
            log("§7[Crystal] Weakness → щит снят");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  AntiTotem: комбо когда у цели сработал тотем
    // ═══════════════════════════════════════════════════════════════
    private void tickAntiTotem(ServerLevel sw, LivingEntity target, double dist) {
        float currentHp = target.getHealth();

        // Pop: HP было ≤ 1.2, теперь > 1.5
        if (targetLastHp > 0 && targetLastHp <= 1.2f && currentHp > 1.5f) {
            antiTotemHitsLeft = 3;
            log("§d[Crystal] AntiTotem! Комбо из 3 взрывов");
        }

        // Комбо: немедленно ещё один взрыв
        if (antiTotemHitsLeft > 0 && antiTotemCd <= 0) {
            antiTotemCd = ANTI_TOTEM_CD;
            // Форсируем фазу PLACE для быстрого следующего взрыва
            if (phase != Phase.RETREAT) {
                phase = Phase.SETUP;
                obsTimer = 0;
                placeTimer = 0;
                explodeTimer = 0;
            }
            antiTotemHitsLeft--;
        }
        if (antiTotemCd > 0) antiTotemCd--;

        targetLastHp = currentHp;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Вспомогательные методы
    // ═══════════════════════════════════════════════════════════════

    private void tickTimers() {
        if (obsTimer     > 0) obsTimer--;
        if (placeTimer   > 0) placeTimer--;
        if (explodeTimer > 0) explodeTimer--;
        if (swordTimer   > 0) swordTimer--;
        if (pearlCd      > 0) pearlCd--;
        if (gapCd        > 0) gapCd--;
        if (speedCd      > 0) speedCd--;
        if (strCd        > 0) strCd--;
        if (weaknessCd   > 0) weaknessCd--;
        if (orbitTimer   > 0) orbitTimer--;
    }

    private void applyBuffs() {
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); // Speed II
            speedCd = SPEED_CD;
        }
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 2)); // Strength III
            strCd = STR_CD;
        }
    }

    private void doPearl(ServerLevel sw, LivingEntity target) {
        // Симулируем жемчуг — телепортируемся ближе к цели
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        Vec3 dest = bot.position().add(dir.scale(12.0));
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.6);
        sw.sendParticles(ParticleTypes.PORTAL,
            bot.getX(), bot.getY() + 1, bot.getZ(), 20, 0.5, 0.5, 0.5, 0.3);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
        pearlCd = PEARL_CD;
    }

    private EndCrystal spawnCrystal(ServerLevel sw, BlockPos pos) {
        if (!sw.getBlockState(pos).isAir()) return null;
        if (!sw.getBlockState(pos.above()).isAir()) return null;

        // Проверяем что база — обсидиан или бедрок
        var baseBlock = sw.getBlockState(pos.below()).getBlock();
        if (baseBlock != Blocks.OBSIDIAN && baseBlock != Blocks.BEDROCK) return null;

        EndCrystal c = EntityType.END_CRYSTAL.create(sw, EntitySpawnReason.TRIGGERED);
        if (c == null) return null;

        c.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        c.setBeamTarget(null);
        sw.addFreshEntity(c);
        return c;
    }

    /** Находим все валидные базы для кристаллов вокруг цели */
    private List<BlockPos> findAllCrystalBases(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition();
        int[] dx = { 1, -1,  0,  0,  1, -1,  1, -1,  0 };
        int[] dz = { 0,  0,  1, -1,  1, -1, -1,  1,  0 };

        List<BlockPos> result = new ArrayList<>();
        for (int i = 0; i < dx.length; i++) {
            BlockPos obsPos   = base.offset(dx[i], -1, dz[i]);
            BlockPos placePos = obsPos.above();

            var b = level.getBlockState(obsPos).getBlock();
            if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) continue;
            if (!level.getBlockState(placePos).isAir()) continue;
            if (!level.getBlockState(placePos.above()).isAir()) continue;

            result.add(obsPos);
        }
        return result;
    }

    private int countObsidianNear(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition();
        int[] dx = { 1, -1,  0,  0,  1, -1,  1, -1,  0 };
        int[] dz = { 0,  0,  1, -1,  1, -1, -1,  1,  0 };
        int count = 0;
        for (int i = 0; i < dx.length; i++) {
            var b = level.getBlockState(base.offset(dx[i], -1, dz[i])).getBlock();
            if (b == Blocks.OBSIDIAN || b == Blocks.BEDROCK) count++;
        }
        return count;
    }

    /** Если сами слишком близко к кристаллу — отходим */
    private void repositionFromCrystal(EndCrystal c) {
        Vec3 away = bot.position().subtract(c.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * (SAFE_SELF_DIST + 1),
            bot.getY(),
            bot.getZ() + away.z * (SAFE_SELF_DIST + 1), 1.2);
    }

    private void cleanupCrystalRef(EndCrystal c) {
        if (c == crystal1) crystal1 = null;
        if (c == crystal2) crystal2 = null;
    }

    private void log(String msg) {
        if (bot.getOwner() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    // ═══════════════════════════════════════════════════════════════
    //  HUD
    // ═══════════════════════════════════════════════════════════════
    public String getPhaseLabel() {
        String crysts = ((crystal1 != null && !crystal1.isRemoved()) ? "①" : "")
                      + ((crystal2 != null && !crystal2.isRemoved()) ? "②" : "");
        return switch (phase) {
            case APPROACH -> "CRYS:MOVE";
            case SETUP    -> "CRYS:OBS";
            case PLACE    -> "CRYS:PLACE" + (crysts.isEmpty() ? "" : " " + crysts);
            case EXPLODE  -> "CRYS:BOOM!" + (crysts.isEmpty() ? "" : " " + crysts);
            case RETREAT  -> "CRYS:FLEE " + retreatTimer + "t";
        };
    }
}
