package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import java.awt.Color;

/**
 * Рендерер вкладки PROFILES — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class ProfilesTabRenderer {

    private ProfilesTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;
        g.drawString(font, "LOAD PRESET PROFILE", sx, sy, TEXT_WHITE); sy += 18;

        Object[][] built = {
            {"pvp",             "PvP Standard",    "SWORD · HARD",    "kit_sword",   0xFFC0A050},
            {"pve",             "PvE Mode",         "BOW · MEDIUM",    "kit_axe",     0xFF22C55E},
            {"crystal",         "Crystal PvP",      "CRYSTAL · EXPERT","kit_crystal", 0xFF60A5FA},
            {"passive",         "Passive",          "No Attack",       "kit_vanilla", 0xFF94A3B8},
            {"smp",             "SMP Survival",     "SWORD · MEDIUM",  "kit_smp",     0xFF4ADE80},
            {"uhc",             "UHC Mode",         "BOW · HARD",      "kit_uhc",     0xFFEF4444},
            {"nethpot",         "NethPot",          "POTION · HARD",   "kit_nethpot", 0xFF8B5CF6},
            {"axe",             "Axe PvP",          "AXE · HARD",      "kit_axe",     0xFFFB923C},
            {"tpc",             "TPC",              "CRYSTAL · EXPERT","kit_tpc",     0xFF8B5CF6},
            {"obsidian_crystal","Obsidian Crystal", "CRYSTAL · EXPERT","kit_crystal", 0xFF6366F1},
            {"snowball",        "Snowball",         "SNOWBALL · MED",  "kit_snowball",0xFF94A3B8},
            {"shield_sword",    "Shield Sword",     "SWORD · HARD",    "kit_sword",   0xFF3B82F6},
        };

        int pW = 118, pH = 60, pCols = 4, pGap = 5;
        for (int i = 0; i < built.length; i++) {
            Object[] bp = built[i];
            int col = i % pCols, row = i / pCols;
            int bx = sx + col * (pW + pGap), by = sy + row * (pH + pGap);
            boolean hov = mx >= bx && mx < bx + pW && my >= by && my < by + pH;
            int acc = (int)(long)(Integer) bp[4];
            float a = AnimationUtil.tick("prof_preset_" + i, hov ? 1f : 0f, 0.18f);

            int pbg = AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x14000000, a);
            RenderUtil.rounded(g, bx, by, pW, pH, 6, new Color(pbg));
            g.fillGradient(bx + 4, by, bx + pW - 4, by + 3, acc, (acc & 0x00FFFFFF));
            bd(g, bx, by, pW, pH, AnimationUtil.lerpColor(BORDER_CARD, acc, a * 0.7f));

            // Иконка кита через IconRenderer (PNG или Unicode-fallback)
            IconRenderer.draw(g, (String) bp[3], bx + 4, by + 5, 10);
            g.drawString(font, (String) bp[1], bx + 18, by + 8, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, a));
            g.drawString(font, (String) bp[2], bx + 5,  by + 20, TEXT_GRAY);

            if (hov) {
                fr(g, bx, by + pH - 16, pW, 16, 0xFF0A1018);
                g.drawString(font, "Load: " + bp[0], bx + 5, by + pH - 12, ACCENT_BLUE);
            }
        }

        int saveY = sy + (built.length / pCols + 1) * (pH + pGap) + 8;
        secTitle(g, "SAVE CURRENT CONFIG", sx, saveY); saveY += 14;
        int[] sc = {0xFF22C55E, 0xFF60A5FA, 0xFF8B5CF6};
        String[] sn = {"pvp", "crystal", "passive"};
        for (int i = 0; i < 3; i++) {
            boolean hov = mx >= sx + i * 142 && mx < sx + i * 142 + 132 && my >= saveY && my < saveY + 16;
            float a = AnimationUtil.tick("save_btn_" + i, hov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, sx + i * 142, saveY, 132, 16, 3, new Color(AnimationUtil.lerpColor(BG_CARD, (sc[i] & 0x00FFFFFF) | 0x20000000, a)));
            bd(g, sx + i * 142, saveY, 132, 16, AnimationUtil.lerpColor(BORDER_CARD, sc[i], a));
            g.drawString(font, "💾 Save as '" + sn[i] + "'", sx + i * 142 + 5, saveY + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, sc[i], a));
        }

        // ── Экспорт / Импорт профилей ─────────────────────────────
        int expY = saveY + 26;
        secTitle(g, "EXPORT / IMPORT PROFILES", sx, expY); expY += 14;

        // Кнопка Export
        boolean hovExp = mx >= sx && mx < sx + 130 && my >= expY && my < expY + 18;
        float aExp = AnimationUtil.tick("exp_btn", hovExp ? 1f : 0f, 0.2f);
        RenderUtil.rounded(g, sx, expY, 130, 18, 3,
            new Color(AnimationUtil.lerpColor(BG_CARD, 0x20E8A020, aExp)));
        bd(g, sx, expY, 130, 18, AnimationUtil.lerpColor(BORDER_CARD, 0xFFE8A020, aExp));
        g.drawString(font, "📤 Export current profile", sx + 5, expY + 5,
            AnimationUtil.lerpColor(TEXT_GRAY, 0xFFE8A020, aExp));

        // Список сохранённых профилей для импорта
        java.util.List<String> savedProfiles = BotConfig.listProfiles();
        int impX = sx + 140;
        g.drawString(font, "📂 Saved profiles:", impX, expY, TEXT_GRAY);
        expY += 12;
        if (savedProfiles.isEmpty()) {
            g.drawString(font, "Нет сохранённых профилей", impX, expY, TEXT_DARK);
        } else {
            for (int i = 0; i < Math.min(savedProfiles.size(), 5); i++) {
                String pname = savedProfiles.get(i);
                int py2 = expY + i * 16;
                boolean hovImp = mx >= impX && mx < impX + 200 && my >= py2 && my < py2 + 14;
                float aImp = AnimationUtil.tick("imp_" + i, hovImp ? 1f : 0f, 0.2f);
                if (hovImp) fr(g, impX - 2, py2 - 1, 204, 14, 0x15FFFFFF);
                g.drawString(font, "📥 " + pname, impX, py2 + 2,
                    AnimationUtil.lerpColor(TEXT_GRAY, 0xFF60A5FA, aImp));
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  STATS TAB
    // ═══════════════════════════════════════════════════════════════

}
