package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import java.awt.Color;

/**
 * Рендерер вкладки SOUND — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class SoundTabRenderer {

    private SoundTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        int sx = cx + 14, sy = cy + 10;

        // Заголовок
        secTitle(g, "CLIENT SOUNDS", sx, sy); sy += 18;
        g.drawString(font, "§7Звуки при включении / выключении модулей", sx, sy, TEXT_GRAY); sy += 16;

        // Сетка кнопок звука
        ClientSounds.SoundMode[] soundModes = ClientSounds.modes();
        ClientSounds.SoundMode cur = ClientSounds.INSTANCE.getMode();
        int btnW = 80, btnH = 20, btnGap = 6, perRow = 5;
        for (int i = 0; i < soundModes.length; i++) {
            ClientSounds.SoundMode m = soundModes[i];
            int col = i % perRow, row = i / perRow;
            int bx = sx + col * (btnW + btnGap);
            int by = sy + row * (btnH + btnGap);
            boolean sel = m == cur;
            boolean hov = mx >= bx && mx < bx + btnW && my >= by && my < by + btnH;
            float a = AnimationUtil.tick("snd_tab_mode_" + i, sel ? 1f : (hov ? 0.5f : 0f), 0.2f);
            int bg = AnimationUtil.lerpColor(BG_CARD, 0x33AAAAFF, a);
            int bd = AnimationUtil.lerpColor(BORDER_CARD, sel ? ACCENT_CYAN : ACCENT_BLUE, a);
            RenderUtil.rounded(g, bx, by, btnW, btnH, 4, new Color(bg));
            bd(g, bx, by, btnW, btnH, bd);
            if (sel) g.fill(bx, by, bx + btnW, by + 2, ACCENT_CYAN);
            g.drawString(font, (sel ? "§b✔ " : "§7") + m.label, bx + 6, by + 6,
                sel ? ACCENT_CYAN : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
        }
        int rows = (int) Math.ceil(soundModes.length / (float) perRow);
        sy += rows * (btnH + btnGap) + 14;

        // Ползунок громкости
        secTitle(g, "VOLUME", sx, sy); sy += 14;
        g.drawString(font, "Громкость:", sx, sy + 3, TEXT_GRAY);
        int slW = 200;
        int slX = sx + 80;
        fr(g, slX, sy + 6, slW, 5, BG_CARD);
        int fillW = (int)(slW * ClientSounds.INSTANCE.getVolume());
        fr(g, slX, sy + 6, fillW, 5, ACCENT_CYAN);
        int knobX = slX + fillW - 4;
        fr(g, knobX, sy + 3, 8, 11, 0xFFCCEEFF);
        g.drawString(font, (int)(ClientSounds.INSTANCE.getVolume() * 100) + "%",
            slX + slW + 8, sy + 3, TEXT_BRIGHT);
        sy += 22;

        // Кнопка Test Sound
        int testW = 90, testH = 18;
        boolean hovTest = mx >= sx && mx < sx + testW && my >= sy && my < sy + testH;
        float at = AnimationUtil.tick("snd_tab_test", hovTest ? 1f : 0f, 0.2f);
        int tbg = AnimationUtil.lerpColor(BG_CARD, 0x33FFAA44, at);
        RenderUtil.rounded(g, sx, sy, testW, testH, 4, new Color(tbg));
        bd(g, sx, sy, testW, testH, AnimationUtil.lerpColor(BORDER_CARD, 0xFFFFAA44, at));
        g.drawString(font, "▶  Test Sound", sx + 6, sy + 5, AnimationUtil.lerpColor(TEXT_GRAY, 0xFFFFBB66, at));
        sy += 26;

        // Подсказка
        g.drawString(font, "§7Звуки воспроизводятся при тогле любого модуля.", sx, sy, TEXT_GRAY); sy += 12;
        g.drawString(font, "§7WAV-файлы: assets/pvpbot/sounds/", sx, sy, TEXT_GRAY);

        g.disableScissor();
    }

    /** Обработка кликов во вкладке SOUND. */
    private void handleSoundTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int sx = cx + 14, sy = cy + 10;
        sy += 18 + 16; // заголовок + описание

        ClientSounds.SoundMode[] soundModes = ClientSounds.modes();
        int btnW = 80, btnH = 20, btnGap = 6, perRow = 5;
        for (int i = 0; i < soundModes.length; i++) {
            int col = i % perRow, row = i / perRow;
            int bx = sx + col * (btnW + btnGap);
            int by = sy + row * (btnH + btnGap);
            if (mx >= bx && mx < bx + btnW && my >= by && my < by + btnH) {
                ClientSounds.INSTANCE.setMode(soundModes[i]);
                ClientSounds.INSTANCE.playEnable(); // превью
                BotConfig.save();
                return;
            }
        }
        int rows = (int) Math.ceil(soundModes.length / (float) perRow);
        sy += rows * (btnH + btnGap) + 14;
        sy += 14; // "VOLUME" заголовок

        // Ползунок громкости
        int slX = sx + 80, slW = 200;
        if (mx >= slX && mx < slX + slW && my >= sy && my < sy + 18) {
            float vol = (float)(mx - slX) / slW;
            ClientSounds.INSTANCE.setVolume(Math.max(0f, Math.min(1f, vol)));
            BotConfig.save();
            return;
        }
        sy += 22;

        // Test кнопка
        int testW = 90, testH = 18;
        if (mx >= sx && mx < sx + testW && my >= sy && my < sy + testH) {
            ClientSounds.INSTANCE.playEnable();
        }
    }


}
