package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Рендерер вкладки THEME — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class ThemeTabRenderer {

    private ThemeTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 14, sy = cy + 12;

        // ── Заголовок ─────────────────────────────────────────────
        g.drawString(font, "COLOR THEME", sx, sy, cfg.colorTheme.accent);
        sy += 12;
        g.drawString(font, "Выберите тему. Изменения применяются мгновенно.", sx, sy, TEXT_GRAY);
        sy += 18;
        g.fill(cx + 6, sy, cx + cw - 6, sy + 1, BORDER_SEP);
        sy += 10;

        // ── Карточки тем ─────────────────────────────────────────
        int cardW = 120, cardH = 90, gap = 10;
        int cols  = (cw - 28) / (cardW + gap);
        if (cols < 1) cols = 1;

        PVPBotConfig.ColorTheme[] themes = PVPBotConfig.ColorTheme.values();
        int col = 0;
        for (PVPBotConfig.ColorTheme theme : themes) {
            int tx = sx + col * (cardW + gap);
            boolean active = cfg.colorTheme == theme;
            boolean hov    = mx >= tx && mx < tx + cardW && my >= sy && my < sy + cardH;
            float   anim   = AnimationUtil.tick("theme_" + theme.name(), (hov || active) ? 1f : 0f, 0.15f);

            // Фон карточки
            int cardBg = active ? theme.bg : AnimationUtil.lerpColor(BG_CARD, BG_CARD_HOV, anim);
            RenderUtil.rounded(g, tx, sy, cardW, cardH, 6, new java.awt.Color(cardBg));

            // Рамка: акцент если активна
            int border = active ? theme.accent : AnimationUtil.lerpColor(BORDER_CARD, theme.accent, anim * 0.5f);
            bd(g, tx, sy, cardW, cardH, border);

            // Градиентный превью-полос (Lunar-стиль)
            g.fillGradient(tx + 6, sy + 8, tx + cardW - 6, sy + 30, theme.accent, theme.light);
            // Вторая полоска — тёмный bg
            g.fillGradient(tx + 6, sy + 32, tx + cardW - 6, sy + 40, theme.bg, theme.accent);

            // Название темы
            int nameColor = active ? theme.light : AnimationUtil.lerpColor(TEXT_GRAY, theme.light, anim);
            g.drawString(font, theme.name, tx + 6, sy + 46, nameColor);

            // Активная метка
            if (active) {
                RenderUtil.rounded(g, tx + 6, sy + cardH - 22, cardW - 12, 14, 4, new java.awt.Color(theme.accent & 0x44FFFFFF));
                g.drawString(font, "✓ ACTIVE", tx + 10, sy + cardH - 18, theme.accent);
            } else if (hov) {
                RenderUtil.rounded(g, tx + 6, sy + cardH - 22, cardW - 12, 14, 4, new java.awt.Color(0x22FFFFFF));
                g.drawString(font, "Select", tx + 10, sy + cardH - 18, TEXT_GRAY);
            }

            col++;
            if (col >= cols) { col = 0; sy += cardH + gap; }
        }
    }

    /** Обработка кликов во вкладке THEME. */
    private void handleThemeTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 1;
        int cw = WIN_W - LEFT_W - 1;
        int sx = cx + 14;
        int sy = winY + HEADER_H + 12 + 12 + 18 + 1 + 10; // совпадает с renderThemeTab

        int cardW = 120, cardH = 90, gap = 10;
        int cols  = (cw - 28) / (cardW + gap);
        if (cols < 1) cols = 1;

        PVPBotConfig.ColorTheme[] themes = PVPBotConfig.ColorTheme.values();
        int col = 0;
        for (PVPBotConfig.ColorTheme theme : themes) {
            int tx = sx + col * (cardW + gap);
            if (mx >= tx && mx < tx + cardW && my >= sy && my < sy + cardH) {
                cfg.colorTheme = theme;
                BotConfig.save();
                return;
            }
            col++;
            if (col >= cols) { col = 0; sy += cardH + gap; }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  SOUND TAB — выбор звука тогла и громкости
    // ═══════════════════════════════════════════════════════════════


}
