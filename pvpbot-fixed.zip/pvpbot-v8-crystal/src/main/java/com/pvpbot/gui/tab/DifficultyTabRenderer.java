package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import java.awt.Color;

/**
 * Рендерер вкладки DIFFICULTY — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class DifficultyTabRenderer {

    private DifficultyTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;
        g.drawString(font, "DIFFICULTY SETTINGS", sx, sy, TEXT_WHITE);
        g.drawString(font, "Current: " + cfg.difficulty.name(), sx + 186, sy, diffCol(cfg.difficulty));
        sy += 18;

        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int[] cols = {0xFF22C55E, 0xFFEAB308, 0xFFEF4444, 0xFF991B1B};
        String[][] params = {
            {"Кд: 24 тика","Дальн: 2.8","Перлы: НЕТ","Кристаллы: НЕТ","Скорость -35%","Промахи: 30%","AI: Отключён"},
            {"Кд: 13±4 тика","Дальн: 3.5","Лук >12 блоков","Перлы: НЕТ","Скорость: норма","Стрейф: редко","AI: Базовый"},
            {"Кд: 7 тиков","Дальн: 4.0","Перлы: ДА","Кристаллы: ДА","Бьёт в воздухе","Скорость +3%","AI: Продвинутый"},
            {"Кд: 4 тика","Дальн: 4.5","Перлы+Кристаллы","Обсидиан авто","Воздух ×1.4","Combo BURST","AI: Эксперт"},
        };

        int dcW = (cw - 16) / 4 - 4;
        for (int i = 0; i < 4; i++) {
            boolean act = cfg.difficulty == diffs[i];
            int dx = sx + i * (dcW + 5);
            boolean hov = mx >= dx && mx < dx + dcW && my >= sy && my < sy + 140;
            float a = AnimationUtil.tick("diff_card_" + i, (act || hov) ? 1f : 0f, 0.14f);

            int dBg = AnimationUtil.lerpColor(BG_CARD, (cols[i] & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, dx, sy, dcW, 140, 6, new Color(dBg));
            // top stripe
            g.fillGradient(dx + 6, sy, dx + dcW - 6, sy + 3, cols[i], (cols[i] & 0x00FFFFFF) | 0x00000000);
            // border
            bd(g, dx, sy, dcW, 140, act ? cols[i] : AnimationUtil.lerpColor(BORDER_CARD, cols[i], a * 0.6f));

            g.drawString(font, diffs[i].name(), dx + 5, sy + 8, act ? cols[i] : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
            if (act) g.drawString(font, "✓", dx + dcW - 12, sy + 8, cols[i]);

            for (int pi = 0; pi < params[i].length; pi++) {
                g.drawString(font, "• " + params[i][pi], dx + 5, sy + 22 + pi * 10,
                    AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, Math.max(0.5f, a)));
            }

            // bottom action bar
            fr(g, dx, sy + 124, dcW, 16, act ? 0xFF0A1A0D : 0xFF0A0D14);
            g.drawString(font, act ? "● ACTIVE" : (hov ? "Click to select" : ""),
                dx + 5, sy + 128, act ? cols[i] : ACCENT_BLUE);
        }

        sy += 150;
        secTitle(g, "FINE TUNING", sx, sy); sy += 14;
        drawSlider(g, mx, my, "Attack CD",  sx,       sy,     220, 2, 30, cfg.attackCooldown, 10);
        drawSlider(g, mx, my, "Atk Range",  sx + 240, sy,     180, 1, 6,  cfg.attackRange, 11);
        sy += 26;
        drawSlider(g, mx, my, "Crystal DMG",sx,       sy,     220, 5, 30, cfg.diffCrystalDamage, 12);
        drawSlider(g, mx, my, "Pearl HP",   sx + 240, sy,     180, 1, 20, cfg.diffPearlEscapeHpThreshold, 13);
        sy += 26;
        drawSlider(g, mx, my, "Crystal CD", sx,       sy,     220, 1, 20, cfg.diffCrystalCooldown, 14);
        drawSlider(g, mx, my, "Bow Range",  sx + 240, sy,     180, 3, 30, cfg.diffBowSwitchRange, 15);
    }

    // ═══════════════════════════════════════════════════════════════
    //  PROFILES TAB
    // ═══════════════════════════════════════════════════════════════

}
