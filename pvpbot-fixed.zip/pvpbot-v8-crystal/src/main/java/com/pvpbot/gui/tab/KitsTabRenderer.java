package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import java.awt.Color;

/**
 * Рендерер вкладки KITS — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class KitsTabRenderer {

    private KitsTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // Заголовок
        g.drawString(font, "ВЫБЕРИ КИТ", sx, sy, TEXT_WHITE);
        g.drawString(font, "§7источник: mctiers.com/kits", sx + font.width("ВЫБЕРИ КИТ") + 8, sy + 1, TEXT_GRAY);
        sy += 14;

        // Сетка карточек: 3 колонки
        int kW = 154, kH = 72, kGap = 5, kCols = 3;
        for (int i = 0; i < KIT_CARDS.length; i++) {
            Object[] kd = KIT_CARDS[i];
            String  kid  = (String) kd[0];
            String  name = (String) kd[1];
            String  icon = (String) kd[2];
            int     acc  = (int)(long)(Integer) kd[3];
            String  sub1 = (String) kd[4];
            String  sub2 = (String) kd[5];

            int col = i % kCols, row = i / kCols;
            int kx = sx + col * (kW + kGap);
            int ky = sy + row * (kH + kGap) - (int)scrollYf;

            // Пропускаем если за пределами видимости
            if (ky + kH < cy || ky > cy + ch) continue;

            boolean hov = mx >= kx && mx < kx + kW && my >= ky && my < ky + kH;
            boolean sel = kid.equals(selectedKitId);
            boolean active = kid.equals(cfg.mode != null ? cfg.mode.name().toLowerCase() : "");

            float aHov = AnimationUtil.tick("kit_hov_" + i, hov ? 1f : 0f, 0.18f);
            float aSel = AnimationUtil.tick("kit_sel_" + i, sel ? 1f : 0f, 0.22f);

            // Фон карточки
            int bgBase = sel ? AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x22000000, 1f)
                             : AnimationUtil.lerpColor(BG_CARD, BG_CARD_HOV, aHov);
            RenderUtil.rounded(g, kx, ky, kW, kH, 5, new Color(bgBase));

            // Акцент-полоска сверху
            int topAlpha = (int)((0.4f + 0.6f * aSel) * 255) << 24;
            g.fill(kx + 4, ky, kx + kW - 4, ky + 2, topAlpha | (acc & 0x00FFFFFF));

            // Рамка
            int borderCol = sel ? acc : AnimationUtil.lerpColor(BORDER_CARD, acc, aHov * 0.6f);
            bd(g, kx, ky, kW, kH, borderCol);

            // Иконка
            IconRenderer.draw(g, icon, kx + 5, ky + 5, 12);

            // Название
            int nameCol = AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, Math.max(aHov, aSel));
            g.drawString(font, name, kx + 21, ky + 7, nameCol);

            // Галочка «активный режим»
            if (active) {
                g.drawString(font, "§a●", kx + kW - 14, ky + 6, 0xFF22C55E);
            }

            // Подробности снаряжения
            g.drawString(font, sub1, kx + 5, ky + 22, TEXT_GRAY);
            g.drawString(font, sub2, kx + 5, ky + 32, 0xFF4A6080);

            // Кнопки «На бота» и «Мне тоже» — показываются при hover/select
            if (sel || hov) {
                int btnY  = ky + kH - 18;
                int btnW1 = (kW - 14) / 2 - 2;
                int btnW2 = (kW - 14) / 2 - 2;
                int btnX1 = kx + 5;
                int btnX2 = kx + 5 + btnW1 + 4;

                // Кнопка 1: «На бота»
                boolean h1 = mx >= btnX1 && mx < btnX1 + btnW1 && my >= btnY && my < btnY + 14;
                float a1 = AnimationUtil.tick("kit_b1_" + i, h1 ? 1f : 0f, 0.2f);
                RenderUtil.rounded(g, btnX1, btnY, btnW1, 14, 3, new Color(AnimationUtil.lerpColor(0xFF0A1018, (acc & 0x00FFFFFF) | 0x33000000, a1)));
                bd(g, btnX1, btnY, btnW1, 14, AnimationUtil.lerpColor(BORDER_CARD, acc, a1));
                String l1 = active ? "✔ Бот" : "⚔ Бот";
                g.drawString(font, l1, btnX1 + (btnW1 - font.width(l1)) / 2, btnY + 3, AnimationUtil.lerpColor(TEXT_GRAY, acc, a1));

                // Кнопка 2: «Мне»
                boolean h2 = mx >= btnX2 && mx < btnX2 + btnW2 && my >= btnY && my < btnY + 14;
                float a2 = AnimationUtil.tick("kit_b2_" + i, h2 ? 1f : 0f, 0.2f);
                RenderUtil.rounded(g, btnX2, btnY, btnW2, 14, 3, new Color(AnimationUtil.lerpColor(0xFF0A1018, 0x33FFFFFF, a2)));
                bd(g, btnX2, btnY, btnW2, 14, AnimationUtil.lerpColor(BORDER_CARD, 0xFFFFFFFF, a2 * 0.4f));
                String l2 = "🎁 Мне";
                g.drawString(font, l2, btnX2 + (btnW2 - font.width(l2)) / 2, btnY + 3, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, a2));
            }
        }

        // Итого строк
        int rows = (KIT_CARDS.length + kCols - 1) / kCols;
        maxScrollY = Math.max(0, rows * (kH + kGap) - (ch - 30));
    }

    private void handleKitsTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        int sx = cx + 10, sy = cy + 8 + 14;
        int areaTop = cy, areaBottom = cy + ch;

        int kW = 154, kH = 72, kGap = 5, kCols = 3;
        for (int i = 0; i < KIT_CARDS.length; i++) {
            Object[] kd = KIT_CARDS[i];
            String  kid = (String) kd[0];
            int col = i % kCols, row = i / kCols;
            int kx = sx + col * (kW + kGap);
            int ky = sy + row * (kH + kGap) - scrollY;

            // FIX: пропускаем карточки вне видимой области
            if (ky + kH < areaTop || ky > areaBottom) continue;

            if (mx >= kx && mx < kx + kW && my >= ky && my < ky + kH) {
                selectedKitId = kid;

                int btnY  = ky + kH - 18;
                int btnW1 = (kW - 14) / 2 - 2;
                int btnW2 = (kW - 14) / 2 - 2;
                int btnX1 = kx + 5;
                int btnX2 = kx + 5 + btnW1 + 4;

                if (my >= btnY && my < ky + kH) {
                    if (mx >= btnX1 && mx < btnX1 + btnW1) {
                        // Кнопка «На бота» — только бот
                        sendCmd("bot kit " + kid);
                        try { cfg.mode = PVPBotConfig.Mode.valueOf(kid.toUpperCase()); BotConfig.save(); }
                        catch (IllegalArgumentException ignored) {}
                    } else if (mx >= btnX2 && mx < btnX2 + btnW2) {
                        // Кнопка «Мне» — бот И игрок
                        sendCmd("bot kit " + kid);
                        try { cfg.mode = PVPBotConfig.Mode.valueOf(kid.toUpperCase()); BotConfig.save(); }
                        catch (IllegalArgumentException ignored) {}
                    }
                    rebuild();
                }
                return;
            }
        }
    }


}
