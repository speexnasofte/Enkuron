package com.pvpbot.gui.tab;

import com.pvpbot.PVPBotConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Font;

import java.awt.Color;

/**
 * Shared context for all tab renderers.
 * PVPBotScreen sets these fields before calling any tab renderer's render() method.
 * Tab renderers access them as if they were local fields via static import or direct class access.
 */
public final class TabRenderContext {

    private TabRenderContext() {}

    // ── Window layout (set by PVPBotScreen.init/render) ──────────
    public static int winX, winY;

    // ── Layout constants ──────────────────────────────────────────
    public static final int WIN_W    = 680;
    public static final int WIN_H    = 430;
    public static final int HEADER_H = 30;
    public static final int LEFT_W   = 136;
    public static final int FOOT_H   = 20;

    // ── Colours ───────────────────────────────────────────────────
    public static final int BG_MAIN      = 0xFF0A0D12;
    public static final int BG_CARD      = 0xFF161B28;
    public static final int BG_CARD_HOV  = 0xFF1C2235;
    public static final int BG_CARD_EN   = 0xFF0D1A10;
    public static final int BORDER_CARD  = 0xFF1A2035;
    public static final int ACCENT_BLUE  = 0xFF3B82F6;
    public static final int ACCENT_GREEN = 0xFF22C55E;
    public static final int ACCENT_RED   = 0xFFEF4444;
    public static final int ACCENT_CYAN  = 0xFF06B6D4;
    public static final int TEXT_WHITE   = 0xFFFFFFFF;
    public static final int TEXT_BRIGHT  = 0xFFE2E8F0;
    public static final int TEXT_GRAY    = 0xFF7A8BB0;
    public static final int TEXT_DARK    = 0xFF303A55;
    public static final int NEW_BG       = 0xFF1E3A8A;
    public static final int NEW_FG       = 0xFF93C5FD;

    // ── Font (set by PVPBotScreen) ────────────────────────────────
    public static Font font;

    // ── Config (set by PVPBotScreen) ──────────────────────────────
    public static PVPBotConfig cfg;

    // ── Squad state (set by PVPBotScreen, written back by SquadTabRenderer) ──
    public static int    squadSelectedPreset = -1;
    public static int    squadCount          = 10;
    public static int    squadPresetW, squadPresetH, squadPresetX0;
    public static int[]  squadPresetY        = new int[16];
    public static int    squadSliderX, squadSliderY, squadSliderW;
    public static boolean draggingSquadSlider = false;

    /** Squad preset table: each row = { id, icon, name, desc1, desc2, accentColor, kitId, minCount, maxCount } */
    public static final Object[][] SQUAD_PRESETS = {
        {"sword",       "⚔",  "Мечники",      "Ближний бой",    "Стандартный отряд",   0xFF3B82F6, "sword",      1, 20},
        {"crystal",     "💎", "Кристальщики", "End Crystal PvP","Опытный отряд",        0xFF8B5CF6, "crystal",    1, 10},
        {"archer",      "🏹", "Лучники",      "Дальний бой",    "Поддержка с тыла",     0xFF22C55E, "bow",        2, 15},
        {"tank",        "🛡",  "Танки",         "Передовой бой",  "Принимают удары",     0xFFEF4444, "sword",      1, 8 },
        {"medic",       "❤",  "Медики",        "Поддержка",      "Лечат союзников",     0xFFEC4899, "nethpot",    1, 6 },
        {"mixed",       "⚡", "Смешанный",    "Разные роли",    "Универсальный состав", 0xFFF59E0B, "sword",      3, 30},
        {"axe",         "🪓", "Топорщики",    "Осколки щитов",  "Ломают щиты",          0xFFFF6B35, "axe",        1, 15},
        {"elite",       "👑", "Элита",         "Лучшие бойцы",   "Макс. сложность",     0xFFFFD700, "crystal",    1, 5 },
    };

    // ── Helpers (mirrors PVPBotScreen.fr / bd) ────────────────────

    /** Shorthand: filled rectangle. */
    public static void fr(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    /** Shorthand: 1-pixel border rectangle. */
    public static void bd(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x,         y,         x + w,     y + 1,     color);
        g.fill(x,         y + h - 1, x + w,     y + h,     color);
        g.fill(x,         y,         x + 1,     y + h,     color);
        g.fill(x + w - 1, y,         x + w,     y + h,     color);
    }
}
