package com.pvpbot.gui.tab;

import static com.pvpbot.gui.tab.TabRenderContext.*;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import java.awt.Color;

/**
 * Рендерер вкладки SQUAD — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class SquadTabRenderer {

    private SquadTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;

        // ── Заголовок ─────────────────────────────────────────────
        g.drawString(font, "⚔  ОТРЯДЫ — ВЫБОР ТИПА И РАЗМЕРА", sx, sy, ACCENT_BLUE);
        sy += 14;
        g.drawString(font, "Выберите тип · настройте количество · нажмите Создать", sx, sy, TEXT_GRAY);
        sy += 16;

        // ── Сетка пресетов 4×2 ────────────────────────────────────
        int cols = 4;
        int cardW = 118, cardH = 72, cardGap = 5;
        squadPresetW = cardW; squadPresetH = cardH; squadPresetX0 = sx;

        for (int i = 0; i < SQUAD_PRESETS.length; i++) {
            Object[] p = SQUAD_PRESETS[i];
            int acc    = (int)(long)(Integer) p[5];
            int minS   = (int) p[7];
            int maxS   = (int) p[8];

            int col = i % cols, row = i / cols;
            int bx = sx + col * (cardW + cardGap);
            int by = sy + row * (cardH + cardGap);
            squadPresetY[i] = by;

            boolean sel  = (squadSelectedPreset == i);
            boolean hov  = mx >= bx && mx < bx + cardW && my >= by && my < by + cardH;
            float anim   = AnimationUtil.tick("sq_preset_" + i, (hov || sel) ? 1f : 0f, 0.18f);

            // Фон карточки
            int bgCard = sel
                ? AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x30000000, 1f)
                : AnimationUtil.lerpColor(BG_CARD, (acc & 0x00FFFFFF) | 0x18000000, anim);
            RenderUtil.rounded(g, bx, by, cardW, cardH, 6, new java.awt.Color(bgCard));

            // Акцент-полоска сверху
            float stripA = sel ? 1f : anim;
            int stripAlpha = (int)(255 * stripA);
            g.fillGradient(bx + 6, by, bx + cardW - 6, by + 3,
                (stripAlpha << 24) | (acc & 0x00FFFFFF), 0);

            // Рамка
            bd(g, bx, by, cardW, cardH,
                sel ? acc : AnimationUtil.lerpColor(BORDER_CARD, acc, anim * 0.6f));

            // Выбранный — дополнительный glow
            if (sel) {
                for (int gi = 2; gi > 0; gi--) {
                    int ga = 0x15;
                    g.fill(bx - gi, by - gi, bx + cardW + gi, by + cardH + gi,
                        (ga << 24) | (acc & 0x00FFFFFF));
                }
            }

            // Иконка + название
            IconRenderer.draw(g, (String) p[1], bx + 4, by + 6, 10);
            g.drawString(font, (String) p[2], bx + 18, by + 7,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, anim));

            // Описание
            g.drawString(font, (String) p[3], bx + 5, by + 22, TEXT_GRAY);
            g.drawString(font, (String) p[4], bx + 5, by + 32, TEXT_GRAY);

            // Мин/макс
            String sizeStr = "👥 " + minS + "–" + maxS + " бойцов";
            g.drawString(font, sizeStr, bx + 5, by + 44, sel ? acc : TEXT_DARK);

            // Кит
            g.drawString(font, "⚙ " + ((String) p[6]).toUpperCase(), bx + 5, by + 54,
                sel ? AnimationUtil.lerpColor(TEXT_GRAY, acc, 0.8f) : TEXT_DARK);

            // Галочка выбора
            if (sel) {
                fr(g, bx + cardW - 14, by + cardH - 14, 13, 13,
                    (acc & 0x00FFFFFF) | 0xFF000000);
                g.drawString(font, "✓", bx + cardW - 11, by + cardH - 12, 0xFFFFFFFF);
            }
        }

        int gridBottom = sy + 2 * (cardH + cardGap) + 4;

        // ── Слайдер количества ────────────────────────────────────
        int slY = gridBottom + 6;
        g.drawString(font, "КОЛИЧЕСТВО БОЙЦОВ:", sx, slY, TEXT_WHITE); slY += 12;

        // Ограничение по выбранному пресету
        int minAllowed = 1, maxAllowed = 30;
        if (squadSelectedPreset >= 0) {
            minAllowed = (int) SQUAD_PRESETS[squadSelectedPreset][7];
            maxAllowed = (int) SQUAD_PRESETS[squadSelectedPreset][8];
        }
        squadCount = Math.max(minAllowed, Math.min(maxAllowed, squadCount));

        int slW = cw - 30, slH = 8;
        int slX = sx;
        squadSliderX = slX; squadSliderY = slY; squadSliderW = slW;

        // Трек
        fr(g, slX, slY + 2, slW, slH, 0xFF1A2035);
        // Заполнение
        float frac = (float)(squadCount - minAllowed) / Math.max(1, maxAllowed - minAllowed);
        int fillW  = (int)(slW * frac);
        int slAcc  = squadSelectedPreset >= 0
            ? (int)(long)(Integer) SQUAD_PRESETS[squadSelectedPreset][5]
            : ACCENT_BLUE;
        g.fillGradient(slX, slY + 2, slX + fillW, slY + 2 + slH, slAcc,
            (slAcc & 0x00FFFFFF) | 0xAA000000);
        // Ручка
        int kx = slX + fillW - 4;
        fr(g, kx, slY, 8, slH + 4, slAcc);
        bd(g, kx, slY, 8, slH + 4, TEXT_WHITE);

        slY += slH + 8;

        // Цифры
        String countLabel = "× " + squadCount + (squadCount >= 20 ? "  §aАвторолиСрабатывают!" : "");
        g.drawString(font, "× " + squadCount, sx, slY, slAcc);

        // Подсказка авто-ролей
        if (squadCount >= 20) {
            g.drawString(font, "✦ Авто-роли: Элита · Медик · Танкер · Солдаты",
                sx + 30, slY, ACCENT_GREEN);
        }
        slY += 14;

        // Быстрые кнопки количества
        int[] quickNums = {1, 3, 5, 10, 15, 20, 25, 30};
        int qx = sx;
        for (int n : quickNums) {
            if (n < minAllowed || n > maxAllowed) { qx += 28; continue; }
            boolean qsel = (squadCount == n);
            boolean qhov = mx >= qx && mx < qx + 24 && my >= slY && my < slY + 14;
            float qa = AnimationUtil.tick("sq_quick_" + n, (qhov || qsel) ? 1f : 0f, 0.2f);
            int qbg = AnimationUtil.lerpColor(BG_CARD, slAcc & 0x00FFFFFF | 0x40000000, qa);
            fr(g, qx, slY, 24, 14, qbg);
            bd(g, qx, slY, 24, 14, qsel ? slAcc : BORDER_CARD);
            g.drawString(font, String.valueOf(n), qx + (n >= 10 ? 2 : 6), slY + 3,
                qsel ? TEXT_WHITE : TEXT_GRAY);
            qx += 28;
        }

        // ── Выбранный пресет — итоговая панель ────────────────────
        if (squadSelectedPreset >= 0) {
            Object[] sel = SQUAD_PRESETS[squadSelectedPreset];
            int pacc = (int)(long)(Integer) sel[5];
            int panY = slY + 20;
            int panW = cw - 20, panH = 32;
            RenderUtil.rounded(g, sx, panY, panW, panH, 5,
                new java.awt.Color((pacc & 0x00FFFFFF) | 0x20000000, true));
            bd(g, sx, panY, panW, panH, pacc);
            g.drawString(font, (String) sel[1] + " " + (String) sel[2],
                sx + 8, panY + 6, pacc);
            String kitInfo = "Кит: " + ((String) sel[6]).toUpperCase()
                + "  ·  Бойцов: " + squadCount
                + "  ·  /bot spawn " + squadCount + " → /bot squad create";
            g.drawString(font, kitInfo, sx + 8, panY + 18, TEXT_GRAY);
        }

        // ── Кнопки управления отрядом (кастомный рендер) ─────────
        int bbY = winY + WIN_H - FOOT_H - 32;
        String[][] btns = {{"⚔  СОЗДАТЬ ОТРЯД", "160"}, {"✕  Расформировать", "130"}, {"📋  Статус", "90"}};
        int[] bAccents = {ACCENT_GREEN, ACCENT_RED, ACCENT_BLUE};
        int bbX = sx;
        for (int i = 0; i < btns.length; i++) {
            int bW = Integer.parseInt(btns[i][1]);
            boolean hov = mx >= bbX && mx < bbX + bW && my >= bbY && my < bbY + 20;
            float ba = AnimationUtil.tick("squad_btn_" + i, hov ? 1f : 0f, 0.2f);
            int bbg = AnimationUtil.lerpColor(BG_CARD, (bAccents[i] & 0x00FFFFFF) | 0x25000000, ba);
            RenderUtil.rounded(g, bbX, bbY, bW, 20, 4, new Color(bbg));
            bd(g, bbX, bbY, bW, 20, AnimationUtil.lerpColor(BORDER_CARD, bAccents[i], ba));
            g.drawString(font, btns[i][0], bbX + 6, bbY + 6,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, ba));
            bbX += bW + 8;
        }
    }

    /** Кнопка Создать: спавним нужное количество ботов с нужным китом и создаём отряд. */
    static void spawnSquad() {
        if (squadSelectedPreset < 0) return;
        Object[] p = SQUAD_PRESETS[squadSelectedPreset];
        String kit = (String) p[6];
        // /bot spawn <count>  →  /bot kit <kit>  →  /bot squad create
        sendCmd("bot spawn " + squadCount);
        sendCmd("bot kit " + kit);
        sendCmd("bot squad create");
    }

    static void sendCmd(String cmd) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance(); if (mc != null && mc.player != null)
            mc.player.connection.sendCommand(cmd);
    }

    /**
     * Применяет кит соответствующий текущему cfg.mode ко всем активным ботам.
     * Вызывается при смене режима/профиля из GUI.
     */
    static void applyKitToBots() {
        BotKit kit = modeToKit(cfg.mode);
        if (kit != null) sendCmd("kit " + kit.id);
    }

    /** Маппинг Mode → BotKit. */
    private static BotKit modeToKit(PVPBotConfig.Mode mode) {
        return switch (mode) {
            case SWORD          -> BotKit.SWORD;
            case CRYSTAL        -> BotKit.CRYSTAL;
            case SMP            -> BotKit.SMP;
            case UHC            -> BotKit.UHC;
            case NETHPOT        -> BotKit.NETHPOT;
            case AXE            -> BotKit.AXE;
            case TPC            -> BotKit.TPC;
            case MACE           -> BotKit.MACE;
            case MACE_ELYTRA    -> BotKit.MACE_ELYTRA;
            case BEEHIVE        -> BotKit.BEEHIVE;
            case FIREWORK       -> BotKit.FIREWORK;
            case CROSSBOW       -> BotKit.CROSSBOW;
            case TRIDENT        -> BotKit.TRIDENT;
            case TOTEM          -> BotKit.TOTEM;
            case SNOWBALL       -> BotKit.SNOWBALL;
            case NETHOP         -> BotKit.NETHOP;
            case POT            -> BotKit.POT;
        };
    }

    // Обработка кликов вкладки SQUAD
    static void handleSquadTabClick(int mx, int my) {
        int cx = winX + LEFT_W + 10;
        int cy = winY + HEADER_H + 38;
        int cols = 4, cardW = 118, cardH = 72, cardGap = 5;

        // Клики по карточкам пресетов
        for (int i = 0; i < SQUAD_PRESETS.length; i++) {
            int col = i % cols, row = i / cols;
            int bx = cx + col * (cardW + cardGap);
            int by = cy + row * (cardH + cardGap);
            if (mx >= bx && mx < bx + cardW && my >= by && my < by + cardH) {
                squadSelectedPreset = (squadSelectedPreset == i) ? -1 : i;
                // Скорректировать количество под лимиты пресета
                if (squadSelectedPreset >= 0) {
                    int mn = (int) SQUAD_PRESETS[squadSelectedPreset][7];
                    int mx2 = (int) SQUAD_PRESETS[squadSelectedPreset][8];
                    squadCount = Math.max(mn, Math.min(mx2, squadCount));
                }

                return;
            }
        }

        // Клики по быстрым кнопкам количества
        int gridBottom = cy + 2 * (cardH + cardGap) + 4;
        int slY = gridBottom + 6 + 12 + 8 + 8 + 8 + 14; // approximate
        int[] quickNums = {1, 3, 5, 10, 15, 20, 25, 30};
        int qx = cx;
        for (int n : quickNums) {
            if (mx >= qx && mx < qx + 24 && my >= slY && my < slY + 14) {
                int mn = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][7] : 1;
                int mxN = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][8] : 30;
                if (n >= mn && n <= mxN) { squadCount = n; }
                return;
            }
            qx += 28;
        }

        // Слайдер
        if (squadSliderW > 0 && my >= squadSliderY && my < squadSliderY + 12
                && mx >= squadSliderX && mx < squadSliderX + squadSliderW) {
            draggingSquadSlider = true;
            updateSquadSlider(mx);
        }

        // Кнопки управления отрядом внизу
        int bbY = winY + WIN_H - FOOT_H - 32;
        int bbX = winX + LEFT_W + 10;
        if (my >= bbY && my < bbY + 20) {
            if (mx >= bbX && mx < bbX + 160)            { spawnSquad(); return; }
            if (mx >= bbX + 168 && mx < bbX + 298)      { sendCmd("bot squad disband"); return; }
            if (mx >= bbX + 306 && mx < bbX + 396)      { sendCmd("bot squad info"); return; }
        }
    }

    static void updateSquadSlider(int mx) {
        if (squadSliderW <= 0) return;
        int minS = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][7] : 1;
        int maxS = squadSelectedPreset >= 0 ? (int) SQUAD_PRESETS[squadSelectedPreset][8] : 30;
        float frac = (float)(mx - squadSliderX) / squadSliderW;
        frac = Math.max(0f, Math.min(1f, frac));
        squadCount = minS + Math.round(frac * (maxS - minS));
    }
    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — ROLES TAB — настройка ролей отряда
    // ═══════════════════════════════════════════════════════════════

    /** Список строк слайдеров ролей {role, sliderX, sliderY, sliderW} */
    private static final int[]   roleSliderPos  = new int[BotRole.values().length * 3];
    private static int           draggingRoleIdx = -1;

    static void buildRolesWidgets() {
        // Кнопки рендерятся кастомно в renderRolesTab, клики в handleRolesTabClick
    }


}
