package com.pvpbot;

import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import com.pvpbot.StrafeAI;
import com.pvpbot.BotKit;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.awt.Color;
import java.util.*;
import com.pvpbot.gui.tab.*;

/**
 * PVPBotScreen v5.0 — МАКСИМАЛЬНАЯ ВЕРСИЯ
 *
 * Улучшения над v4.0:
 *  - RenderUtil (скруглённые прямоугольники, glow, тени)
 *  - AnimationUtil (плавные hover/enable анимации на каждой карточке)
 *  - Pulse-анимация на активных кнопках
 *  - Gradient шапка и sidebar
 *  - Улучшенные карточки: accent-полоска, glow при enabled
 *  - Иконки модов через Unicode/Emoji
 *  - Drag окна мышкой (перемещение)
 *  - Поиск с живой анимацией и иконкой лупы
 *  - Scrollbar с плавной анимацией
 *  - Notification badge на вкладке STATS
 *  - Полный settings: слайдеры кликабельны
 *  - Difficulty: анимированный выбор
 *  - Stats: K/D граф + сессионный таймер
 *  - Tooltip с задержкой
 *  - Нижний статусбар с цветом по статусу
 *  - Все параметры конфига привязаны
 */
public class PVPBotScreen extends Screen {

    // ═══════════════════════════════════════════════════════════════
    //  ПАЛИТРА
    // ═══════════════════════════════════════════════════════════════
    private static final int BG_MAIN      = 0xFF0A0D12;
    private static final int BG_WIN       = 0xFF111520;
    private static final int BG_LEFT      = 0xFF0B0E16;
    private static final int BG_CARD      = 0xFF161B28;
    private static final int BG_CARD_HOV  = 0xFF1C2235;
    private static final int BG_CARD_EN   = 0xFF0D1A10;
    private static final int BG_HEADER    = 0xFF080C14;
    private static final int BG_ENABLED   = 0xFF0C2012;
    private static final int BG_DISABLED  = 0xFF200C0C;
    private static final int BG_OPT       = 0xFF141824;
    private static final int BG_GEAR      = 0xFF10141F;
    private static final int BG_SEARCH    = 0xFF0C1018;
    private static final int BG_PROF      = 0xFF0F1320;
    private static final int BG_PROF_ACT  = 0xFF172030;
    private static final int BG_SUB_ACT   = 0xFF182440;
    private static final int BG_TOOLTIP   = 0xEE08090F;

    private static final int BORDER_CARD  = 0xFF1A2035;
    private static final int BORDER_SEP   = 0xFF171D2E;
    private static final int BORDER_SRCH  = 0xFF1E2840;

    private static final int ACCENT_BLUE  = 0xFF3B82F6;
    private static final int ACCENT_GREEN = 0xFF22C55E;
    private static final int ACCENT_RED   = 0xFFEF4444;
    private static final int ACCENT_PURP  = 0xFFA855F7;
    private static final int ACCENT_YEL   = 0xFFFACC15;
    private static final int ACCENT_CYAN  = 0xFF06B6D4;
    private static final int ACCENT_ORG   = 0xFFFB923C;
    private static final int ACCENT_GRAY = 0xFF64748B;

    private static final int TEXT_WHITE   = 0xFFFFFFFF;
    private static final int TEXT_BRIGHT  = 0xFFE2E8F0;
    private static final int TEXT_GRAY    = 0xFF7A8BB0;
    private static final int TEXT_DARK    = 0xFF303A55;
    private static final int TEXT_GREEN   = 0xFF22C55E;
    private static final int TEXT_RED     = 0xFFEF4444;
    private static final int TEXT_BLUE    = 0xFF60A5FA;

    private static final int NEW_BG       = 0xFF1E3A8A;
    private static final int NEW_FG       = 0xFF93C5FD;

    // ═══════════════════════════════════════════════════════════════
    //  РАЗМЕРЫ
    // ═══════════════════════════════════════════════════════════════
    private static final int WIN_W    = 680;
    private static final int WIN_H    = 430;
    private static final int HEADER_H = 30;
    private static final int LEFT_W   = 136;
    private static final int SUB_H    = 28;
    private static final int FOOT_H   = 20;
    private static final int CARD_W   = 150;
    private static final int CARD_H   = 84;
    private static final int CARD_GAP = 6;
    private static final int COLS     = 3;
    private static final int PROF_H   = 46;
    private static final int PROF_GAP = 3;

    // ═══════════════════════════════════════════════════════════════
    //  ENUMS
    // ═══════════════════════════════════════════════════════════════
    private enum ModCat {
        ALL("ALL",""), NEW("NEW","★"), HUD("HUD","📊"),
        SERVER("SERVER","🌐"), MECHANIC("MECHANIC","⚙"),
        COMBAT("COMBAT","⚔"), VISUAL("VISUAL","👁"),
        UTILITY("UTILITY","🔧");
        final String label, icon;
        ModCat(String l, String i){ label=l; icon=i; }
    }

    private enum Tab {
        MODS("MODS"), KITS("KITS"), SETTINGS("SETTINGS"), DIFFICULTY("DIFFICULTY"),
        PROFILES("PROFILES"), STATS("STATS"), SQUAD("SQUAD"),
        ROLES("РОЛИ"), HISTORY("ИСТОРИЯ"), THEME("THEME"), SOUND("SOUND");
        final String label;
        Tab(String l){ label=l; }
    }

    // ═══════════════════════════════════════════════════════════════
    //  ДАННЫЕ МОДУЛЕЙ  { name, configKey, cat, isNew, desc, icon, accentColor }
    // ═══════════════════════════════════════════════════════════════
    private static final Object[][] MODS = {
        {"Auto Attack",    "autoAttack",               ModCat.COMBAT,   false, "Атакует ближайшего врага автоматически",   "⚔",  ACCENT_RED},
        {"W-Tap",          "wTapEnabled",              ModCat.COMBAT,   false, "Зажимает W для сброса кулдауна атаки",     "⚡", ACCENT_YEL},
        {"S-Tap",          "sTapEnabled",              ModCat.COMBAT,   false, "Зажимает S после удара для -KB",           "↩",  ACCENT_YEL},
        {"Auto Crystal",   "autoCrystal",              ModCat.COMBAT,   true,  "Расставляет и взрывает End Crystal",       "💎", ACCENT_CYAN},
        {"Auto Bow",       "autoBowEnabled",           ModCat.COMBAT,   false, "Стреляет из лука на дальней дистанции",    "🏹", ACCENT_GREEN},
        {"Kite",           "kiteEnabled",              ModCat.COMBAT,   false, "Держит дистанцию и стреляет из лука",      "🎈", ACCENT_BLUE},
        {"Auto Dodge",     "autoDodge",                ModCat.COMBAT,   false, "Уклоняется от атак в ближнем бою",         "🛡", ACCENT_BLUE},
        {"Fake Attack",    "fakeAttackEnabled",        ModCat.COMBAT,   true,  "Ложные замахи для дезориентации врага",    "🎭", ACCENT_PURP},
        {"Pattern AI",     "patternAIEnabled",         ModCat.SERVER,   true,  "ИИ меняет паттерны атаки динамически",    "🧠", ACCENT_PURP},
        {"Anti Pattern",   "antiPatternEnabled",       ModCat.SERVER,   true,  "Контрит паттерны атаки противника",        "🔄", ACCENT_CYAN},
        {"Adaptive CD",    "adaptiveCooldownEnabled",  ModCat.SERVER,   true,  "Адаптивный кулдаун под пинг сервера",      "⏱", ACCENT_BLUE},
        {"Ping Display",   "statsEnabled",             ModCat.SERVER,   false, "Показывает пинг в HUD",                    "📡", ACCENT_GREEN},
        {"Show HUD",       "showHud",                  ModCat.HUD,      false, "Отображает HUD с информацией о боте",      "📊", ACCENT_BLUE},
        {"Show DPS",       "showDps",                  ModCat.HUD,      false, "Показывает DPS урона на экране",           "💥", ACCENT_RED},
        {"Bot Stats",      "statsEnabled",             ModCat.HUD,      false, "Статистика K/D и урона в бою",             "📈", ACCENT_GREEN},
        {"Radar",          "radarEnabled",             ModCat.HUD,      false, "Мини-карта с ближайшими игроками",         "📡", ACCENT_CYAN},
        {"Auto Sprint",    "autoSprint",               ModCat.MECHANIC, false, "Постоянный спринт без остановки",          "🏃", ACCENT_GREEN},
        {"Toggle Sneak",   "toggleSneak",              ModCat.MECHANIC, false, "Шифт для уклонения от крит-прыжков",       "🕵", ACCENT_GRAY},
        {"Auto Heal",      "autoHeal",                 ModCat.MECHANIC, false, "Пьёт зелья лечения при низком HP",         "❤",  ACCENT_RED},
        {"Auto Gap",       "autoGapEnabled",           ModCat.MECHANIC, false, "Ест золотые яблоки при критическом HP",    "🍎", ACCENT_YEL},
        {"Auto Armor",     "autoArmor",                ModCat.MECHANIC, false, "Надевает лучшую броню автоматически",      "🦺", ACCENT_BLUE},
        {"Auto Totem",     "autoTotem",                ModCat.MECHANIC, false, "Перекладывает тотем в оффхенд авто",       "🗿", ACCENT_YEL},
        {"Auto Log",       "autoLogEnabled",           ModCat.UTILITY,  false, "Выходит из игры при критическом HP",       "🚪", ACCENT_RED},
        {"Auto Pearl",     "autoPearlEnabled",         ModCat.MECHANIC, true,  "Бросает Эндер-жемчуг для отступления",    "🔮", ACCENT_PURP},
        {"Auto Respawn",   "autoRespawn",              ModCat.MECHANIC, false, "Авто-ответ при смерти/выходе",             "⏺",  ACCENT_GREEN},
        {"ESP",            "espEnabled",               ModCat.VISUAL,   false, "Подсвечивает игроков сквозь стены",        "👁",  ACCENT_CYAN},
        {"Nametag",        "nameTagEnabled",           ModCat.VISUAL,   false, "Надпись над ботом (имя/HP/сложность)",     "🏷",  ACCENT_YEL},
        {"Tag: Label",     "nameTagShowLabel",         ModCat.VISUAL,   false, "Показывать 'PVP-Bot' в надписи",           "🔤", ACCENT_YEL},
        {"Tag: Mode",      "nameTagShowMode",          ModCat.VISUAL,   false, "Показывать режим [GUARD/AGRO/PASS]",       "⚔",  ACCENT_YEL},
        {"Tag: Diff",      "nameTagShowDifficulty",    ModCat.VISUAL,   false, "Показывать сложность [EASY/MED/HARD]",     "🎯", ACCENT_YEL},
        {"Tag: HP",        "nameTagShowHp",            ModCat.VISUAL,   false, "Показывать HP и бар здоровья",             "❤",  ACCENT_RED},
        {"Tracers",        "tracersEnabled",           ModCat.VISUAL,   false, "Рисует линии к ближайшим игрокам",         "📐", ACCENT_BLUE},
        {"Anti KB",        "antiKnockbackEnabled",     ModCat.MECHANIC, false, "Снижает отброс от ударов",                 "🧲", ACCENT_YEL},
        {"Notifications",  "notificationsEnabled",     ModCat.UTILITY,  false, "Уведомления о событиях в чат",             "🔔", ACCENT_YEL},
        {"Training Mode",  "trainingMode",             ModCat.UTILITY,  false, "Щадящий режим для обучения новичков",      "🎓", ACCENT_GREEN},
        {"Hunt",           "huntEnabled",              ModCat.UTILITY,  true,  "Ищет и преследует врагов вдали",           "🎯", ACCENT_RED},
        {"Bunker",         "bunkerEnabled",            ModCat.MECHANIC, false, "Прячется в укрытие при низком HP",         "🏰", ACCENT_BLUE},
        {"Standby",        "standbyMode",              ModCat.UTILITY,  true,  "Боты ждут команды /bot attack",            "⏸",  ACCENT_GRAY},
        {"Auto Eat",       "autoEat",                  ModCat.MECHANIC, false, "Ест еду при низком голоде авто",           "🍖", ACCENT_ORG},
        {"Obsidian Place", "autoCrystal",              ModCat.COMBAT,   true,  "Кладёт обсидиан под кристаллы",            "🪨", ACCENT_GRAY},
        {"Whitelist",      "whitelistEnabled",         ModCat.UTILITY,  false, "Атакует только игроков из списка",         "📋", ACCENT_BLUE},
        {"Auto Kit",       "autoKitSelect",            ModCat.MECHANIC, true,  "Авто-выбор кита под броню врага",          "🎒", ACCENT_PURP},
        {"Retreat",        "retreatEnabled",           ModCat.COMBAT,   true,  "Отступает при низком HP (глобально)",      "🏃", ACCENT_GRAY},
        {"Tank Mode",      "tankModeEnabled",          ModCat.COMBAT,   true,  "Прёт напролом к врагу, игнорирует kite",   "🛡", ACCENT_RED},
        {"Auto Refill",    "autoRefill",               ModCat.MECHANIC, true,  "Пополняет инвентарь игрока авто",          "🎒", ACCENT_GREEN},
        {"Bot AutoRefill", "botAutoRefill",            ModCat.MECHANIC, true,  "Пополняет инвентарь бота авто (сервер)",   "🤖", ACCENT_PURP},
        {"Drop Loot",      "dropLootOnDeath",          ModCat.MECHANIC, true,  "Дропает снаряжение бота при его смерти",   "📦", ACCENT_ORG},
        {"Give Player Kit","givePlayerKit",            ModCat.UTILITY,  true,  "Выдаёт активный кит игроку в инвентарь",  "🎁", ACCENT_GREEN},
        {"Smoke Bomb",     "smokeBombEnabled",         ModCat.COMBAT,   true,  "Кидает снежок в ноги убегающему врагу",   "💨", ACCENT_GRAY},
    };


    // ═══════════════════════════════════════════════════════════════
    //  ПРОФИЛИ
    // ═══════════════════════════════════════════════════════════════
    private static class Prof {
        String name, sub; int color; boolean active;
        Prof(String n, String s, int c, boolean a){ name=n; sub=s; color=c; active=a; }
    }
    private final List<Prof> profiles = new ArrayList<>();

    // ═══════════════════════════════════════════════════════════════
    //  СОСТОЯНИЕ
    // ═══════════════════════════════════════════════════════════════
    private int winX, winY;
    private Tab tab       = Tab.MODS;
    private ModCat cat    = ModCat.ALL;
    private float scrollYf  = 0;   // FIX: float для плавной анимации рендера
    private int   scrollY   = 0;   // FIX: int для точного hit-теста кликов
    private int maxScrollY = 0; // для вкладки KITS
    private int targetScrollY = 0;
    private String search = "";
    private boolean searchFocus = false;
    private String optMod = null;
    private int optPanX, optPanY;
    private String tooltip     = null;
    private int ttX, ttY, ttTimer = 0;
    private int dragSlider = -1; // index слайдера, который тянем
    private final Map<String,Boolean> mstate = new LinkedHashMap<>();
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private long sessionStart = System.currentTimeMillis();

    // ── SQUAD TAB состояние ───────────────────────────────────────
    /** Выбранный тип отряда (индекс в SQUAD_PRESETS). */
    private int squadSelectedPreset = -1;
    /** Количество бойцов в отряде (слайдер 1–30). */
    private int squadCount = 10;
    /** true если тянем слайдер количества. */
    private boolean draggingSquadSlider = false;

    // Drag окна
    private boolean dragging = false;
    private int dragOffX, dragOffY;

    // ═══════════════════════════════════════════════════════════════
    //  КОНСТРУКТОР
    // ═══════════════════════════════════════════════════════════════
    public PVPBotScreen(Screen parent) {
        super(Component.literal("PVPBot v5.0"));
        if (profiles.isEmpty()) {
            profiles.add(new Prof("Testing",          "Latest PvP",       0xFF3B82F6, true));
            profiles.add(new Prof("Main",             "Latest PvP",       0xFF22C55E, false));
            profiles.add(new Prof("Crystal Fighter",  "Crystal EXPERT",   0xFFA855F7, false));
            profiles.add(new Prof("UHC Preset",       "UHC HARD",         0xFFEF4444, false));
            profiles.add(new Prof("Training",         "Beginner EASY",    0xFF06B6D4, false));
        }
        reloadModState();
    }

    private void reloadModState() {
        for (Object[] m : MODS) {
            String k = (String) m[1];
            mstate.put(k, getB(k));
        }
        // fix: antiKnockbackEnabled не в конфиге напрямую
        mstate.put("antiKnockbackEnabled", false);
    }

    // ═══════════════════════════════════════════════════════════════
    //  INIT
    // ═══════════════════════════════════════════════════════════════
    @Override
    protected void init() {
        winX = (width  - WIN_W) / 2;
        winY = (height - WIN_H) / 2;
        rebuild();
    }

    private void rebuild() {
        clearWidgets();
        if (tab == Tab.MODS)        buildModsWidgets();
        else if (tab == Tab.SETTINGS)    buildSettingsWidgets();
        else if (tab == Tab.DIFFICULTY)  buildDiffWidgets();
        else if (tab == Tab.PROFILES)    buildProfilesWidgets();
        else if (tab == Tab.STATS)       buildStatsWidgets();
        else if (tab == Tab.SQUAD)       buildSquadWidgets();
        else if (tab == Tab.ROLES)       buildRolesWidgets();
        else if (tab == Tab.HISTORY)     {} // no widgets needed
        else if (tab == Tab.THEME)       {} // no widgets needed — rendered inline
        buildProfileWidgets();
    }

    // ─────────────────────────────────────────────────────────────
    //  Sidebar widget buttons (profiles)
    // ─────────────────────────────────────────────────────────────
    private void buildProfileWidgets() {
        // Клики по профилям и кнопкам sidebar обрабатываются в mouseClicked().
        // Рендер делается в renderLeft() — не добавляем Button-виджеты,
        // чтобы избежать двойного рендера текста поверх кастомных карточек.
    }

    // ─────────────────────────────────────────────────────────────
    //  MODS widgets
    // ─────────────────────────────────────────────────────────────
    private void buildModsWidgets() {
        // close opt panel — невидимая кнопка только для закрытия панели опций
        if (optMod != null) {
            addRenderableWidget(Button.builder(Component.literal(""), b -> { optMod = null; rebuild(); })
                .pos(optPanX + 150, optPanY + 4).size(12, 12).build());
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  SETTINGS widgets
    // ─────────────────────────────────────────────────────────────
    private void buildSettingsWidgets() {
        // Все клики обрабатываются в handleSettingsClick() и mouseClicked().
        // Рендер полностью кастомный (renderSettings), виджеты не нужны.
    }

    private void addTogBtn(int x, int y, String label, boolean on, Runnable action) {
        // no-op: тоглы рендерятся вручную, клики через handleSettingsClick
    }
    private void addPM(int x, int y, String label, Runnable dec, Runnable inc) {
        // no-op: кнопки +/- рендерятся вручную в renderNumRow
    }

    // ─────────────────────────────────────────────────────────────
    //  DIFFICULTY widgets
    // ─────────────────────────────────────────────────────────────
    private void buildDiffWidgets() {
        // Клики обрабатываются в handleDiffTabClick(). Рендер кастомный.
    }

    // ─────────────────────────────────────────────────────────────
    //  PROFILES widgets
    // ─────────────────────────────────────────────────────────────
    private void buildProfilesWidgets() {
        // Клики обрабатываются в handleProfPresetsClick(). Рендер кастомный.
    }

    private void buildStatsWidgets() {
        // Кнопки Reset/Kit Stats обрабатываются в mouseClicked через координаты.
    }

    // ═══════════════════════════════════════════════════════════════
    //  RENDER  (главный)
    // ═══════════════════════════════════════════════════════════════
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        tooltip = null;
        // FIX: плавный скролл через float, но scrollY (int) всегда = round для hit-тестов
        scrollYf += (targetScrollY - scrollYf) * 0.18f;
        scrollY   = Math.round(scrollYf);
        // затемнённый фон
        g.fillGradient(0, 0, width, height, 0xCC000000, 0xDD000510);

        // тень окна
        for (int i = 8; i > 0; i--) {
            int a = (int)(40 * (1f - (float)i / 8));
            g.fill(winX - i, winY - i, winX + WIN_W + i, winY + WIN_H + i, (a << 24) | 0x000000);
        }

        // Основное окно
        RenderUtil.rounded(g, winX, winY, WIN_W, WIN_H, 8, new Color(0x111520));
        // RGB animated border
        int borderRgb = AnimationUtil.rgbCycleFull(0.2f, 0.6f, 0.5f);
        RenderUtil.outline(g, winX, winY, WIN_W, WIN_H, 8, new Color(borderRgb));

        renderHeader(g, mx, my);
        renderLeft(g, mx, my);
        g.fill(winX + LEFT_W, winY + HEADER_H, winX + LEFT_W + 1, winY + WIN_H, 0xFF0A0D18);

        switch (tab) {
            case MODS       -> renderMods(g, mx, my);
            case KITS       -> KitsTabRenderer.render(g, mx, my);
            case SETTINGS   -> renderSettings(g, mx, my);
            case DIFFICULTY -> DifficultyTabRenderer.render(g, mx, my);
            case PROFILES   -> ProfilesTabRenderer.render(g, mx, my);
            case STATS      -> StatsTabRenderer.render(g, mx, my);
            case SQUAD      -> SquadTabRenderer.render(g, mx, my);
            case ROLES      -> RolesTabRenderer.render(g, mx, my);
            case HISTORY    -> HistoryTabRenderer.render(g, mx, my);
            case THEME      -> ThemeTabRenderer.render(g, mx, my);
            case SOUND      -> SoundTabRenderer.render(g, mx, my);
            default -> {}
        }

        renderFooter(g, mx, my);
        super.render(g, mx, my, pt);
        if (tooltip != null) renderTooltip2(g, tooltip, ttX, ttY);
    }

    // ═══════════════════════════════════════════════════════════════
    //  HEADER
    // ═══════════════════════════════════════════════════════════════
    private void renderHeader(GuiGraphics g, int mx, int my) {
        // gradient header
        g.fillGradient(winX, winY, winX + WIN_W, winY + HEADER_H, 0xFF0C1220, 0xFF080C16);
        // RGB animated top accent line
        // FIX: top accent line использует colorTheme вместо random RGB если не LUNAR
        int rgb1, rgb2, rgb3;
        if (cfg.colorTheme == PVPBotConfig.ColorTheme.LUNAR) {
            rgb1 = AnimationUtil.rgbCycle(0.3f);
            rgb2 = AnimationUtil.rgbCycleOffset(0.3f, 0.33f);
            rgb3 = AnimationUtil.rgbCycleOffset(0.3f, 0.66f);
        } else {
            rgb1 = cfg.colorTheme.accent;
            rgb2 = cfg.colorTheme.light;
            rgb3 = cfg.colorTheme.accent;
        }
        g.fillGradient(winX + 4, winY, winX + LEFT_W + (WIN_W - LEFT_W) / 2, winY + 1, rgb1, rgb2);
        g.fillGradient(winX + LEFT_W + (WIN_W - LEFT_W) / 2, winY, winX + WIN_W - 4, winY + 1, rgb2, rgb3);
        g.fill(winX, winY + HEADER_H - 1, winX + WIN_W, winY + HEADER_H, 0xFF0A0F1E);

        // Logo + name (иконка из текстуры)
        try {
            net.minecraft.resources.ResourceLocation logoRL =
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("pvpbot", "textures/gui/logo.png");
            // В 1.21.4 blit сам привязывает текстуру, RenderSystem.setShaderTexture не нужен
            g.blit(net.minecraft.client.renderer.RenderType::guiTextured, logoRL, winX + 5, winY + 5, 0, 0, 20, 20, 20, 20);
        } catch (Exception ex) {
            // fallback если текстура не загружена
            fr(g, winX + 6, winY + 7, 16, 16, 0xFF1A2540);
            bd(g, winX + 6, winY + 7, 16, 16, 0xFF2A3F6F);
            g.drawString(font, "E", winX + 10, winY + 10, ACCENT_CYAN);
        }
        g.drawString(font, "PVPBot", winX + 28, winY + 10, TEXT_BRIGHT);
        // version badge
        fr(g, winX + 108, winY + 8, 28, 12, NEW_BG);
        g.drawString(font, "v5.0", winX + 110, winY + 10, NEW_FG);

        // Nav tabs
        int tx = winX + LEFT_W + 8;
        for (Tab t : Tab.values()) {
            boolean act = t == tab;
            String lbl = t.label;
            int tw = font.width(lbl) + 14;
            boolean hov = mx >= tx && mx < tx + tw && my >= winY + 2 && my < winY + HEADER_H;
            float anim = AnimationUtil.tick("tab_" + t.name(), (hov || act) ? 1f : 0f, 0.18f);

            if (act) {
                // RGB animated underline on active tab
                int tabRgb = AnimationUtil.rgbCycleOffset(0.25f, (float)t.ordinal() / Tab.values().length);
                int ua = (int)(255 * anim);
                g.fill(tx, winY + HEADER_H - 2, tx + tw, winY + HEADER_H, (ua << 24) | (tabRgb & 0x00FFFFFF));
                // subtle bg
                fr(g, tx, winY + 2, tw, HEADER_H - 3, 0x0A3B82F6);
                g.drawString(font, lbl, tx + 7, winY + 10, TEXT_WHITE);
            } else {
                int col = AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim);
                if (hov) fr(g, tx, winY + 4, tw, HEADER_H - 6, 0x12FFFFFF);
                g.drawString(font, lbl, tx + 7, winY + 10, col);
            }
            // STATS: красный badge если убийства > 0
            if (t == Tab.STATS && KillDeathTracker.kills > 0) {
                fr(g, tx + tw - 6, winY + 6, 6, 6, ACCENT_RED);
            }
            tx += tw + 2;
        }

        // Close button
        int cx = winX + WIN_W - 18, cy = winY + 8;
        boolean hX = mx >= cx && mx < cx + 14 && my >= cy && my < cy + 14;
        float xA = AnimationUtil.tick("close_btn", hX ? 1f : 0f, 0.2f);
        int xBg = AnimationUtil.lerpColor(0xFF0D1420, 0xFF7F1D1D, xA);
        fr(g, cx, cy, 14, 14, xBg);
        bd(g, cx, cy, 14, 14, hX ? ACCENT_RED : 0xFF1E2A40);
        g.drawString(font, "✕", cx + 3, cy + 3, hX ? TEXT_WHITE : TEXT_GRAY);
    }

    // ═══════════════════════════════════════════════════════════════
    //  LEFT SIDEBAR
    // ═══════════════════════════════════════════════════════════════
    private void renderLeft(GuiGraphics g, int mx, int my) {
        // gradient sidebar
        g.fillGradient(winX, winY + HEADER_H, winX + LEFT_W, winY + WIN_H, 0xFF0B0E16, 0xFF0D1220);
        int px = winX + 4, py = winY + HEADER_H + 4;

        g.drawString(font, "PROFILES", px + 4, py, TEXT_DARK);
        py += 12;

        for (int i = 0; i < profiles.size(); i++) {
            Prof p = profiles.get(i);
            int gy = py + i * (PROF_H + PROF_GAP);
            boolean hov = mx >= px && mx < px + LEFT_W - 8 && my >= gy && my < gy + PROF_H;
            boolean act = p.active;
            float anim = AnimationUtil.tick("prof_" + i, (hov || act) ? 1f : 0f, 0.15f);

            // bg card
            int bg = AnimationUtil.lerpColor(BG_PROF, act ? BG_PROF_ACT : 0xFF111826, anim);
            RenderUtil.rounded(g, px, gy, LEFT_W - 8, PROF_H, 4, new Color(bg));
            // color stripe left
            int sa = act ? 255 : (int)(120 * anim);
            g.fill(px, gy, px + 3, gy + PROF_H, (sa << 24) | (p.color & 0x00FFFFFF));
            // active border
            if (act) RenderUtil.outline(g, px, gy, LEFT_W - 8, PROF_H, 4, new Color((p.color & 0x00FFFFFF) | 0x30000000));

            // icon circle
            fr(g, px + 6, gy + 8, 22, 22, (p.color & 0x00FFFFFF) | 0x20000000);
            g.drawString(font, "◈", px + 10, gy + 12, act ? p.color : AnimationUtil.lerpColor(TEXT_DARK, p.color, anim));

            g.drawString(font, p.name, px + 31, gy + 6, act ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim));
            g.drawString(font, p.sub,  px + 31, gy + 17, AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, anim));

            if (act) {
                // RGB pulsing active dot
                float pulse = AnimationUtil.pulse(4.0f);
                int pa = (int)(200 + 55 * pulse);
                int dotRgb = AnimationUtil.rgbCycleOffset(0.3f, (float)i / profiles.size());
                g.fill(px + LEFT_W - 18, gy + 18, px + LEFT_W - 12, gy + 24, (pa << 24) | (dotRgb & 0x00FFFFFF));
            }
            if (hov && !act) { tooltip = p.name + " — " + p.sub; ttX = mx; ttY = gy - 4; }
        }

        int bY = winY + WIN_H - FOOT_H - 48;
        // New profile & HUD layout buttons
        for (int i = 0; i < 2; i++) {
            String lbl = i == 0 ? "+ NEW PROFILE" : "❖ HUD LAYOUT";
            int ly = bY + i * 23;
            boolean hov = mx >= px && mx < px + LEFT_W - 8 && my >= ly && my < ly + 18;
            float anim = AnimationUtil.tick("sidebtn_" + i, hov ? 1f : 0f, 0.2f);
            int bg = AnimationUtil.lerpColor(BG_PROF, 0xFF1A2535, anim);
            RenderUtil.rounded(g, px, ly, LEFT_W - 8, 18, 4, new Color(bg));
            g.drawString(font, lbl, px + 6, ly + 5, AnimationUtil.lerpColor(TEXT_GRAY, ACCENT_BLUE, anim));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  MODS TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderMods(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        renderSubBar(g, mx, my, cx, cy, cw);
        renderGrid(g, mx, my, cx, cy + SUB_H, cw, ch - SUB_H);
        if (optMod != null) renderOptPanel(g, mx, my, optMod);
    }

    // ─────────────────────────────────────────────────────────────
    //  Sub-category bar
    // ─────────────────────────────────────────────────────────────
    private void renderSubBar(GuiGraphics g, int mx, int my, int cx, int cy, int cw) {
        g.fillGradient(cx, cy, cx + cw, cy + SUB_H, 0xFF0C1018, 0xFF080C14);
        g.fill(cx, cy + SUB_H - 1, cx + cw, cy + SUB_H, 0xFF0A0D18);

        int tx = cx + 6;
        for (ModCat c : ModCat.values()) {
            boolean act = c == cat;
            String lbl = c.icon.isEmpty() ? c.label : c.icon + " " + c.label;
            int tw = font.width(lbl) + 12;
            boolean hov = mx >= tx && mx < tx + tw && my >= cy && my < cy + SUB_H;
            float anim = AnimationUtil.tick("cat_" + c.name(), (hov || act) ? 1f : 0f, 0.18f);

            if (act) {
                RenderUtil.rounded(g, tx, cy + 5, tw, SUB_H - 8, 4, new Color(BG_SUB_ACT));
                // FIX: динамический цвет из colorTheme
                int themeAccent = cfg.colorTheme.accent;
                g.fill(tx + 2, cy + SUB_H - 3, tx + tw - 2, cy + SUB_H - 1, themeAccent);
                g.drawString(font, lbl, tx + 6, cy + 9, themeAccent);
            } else {
                if (hov) RenderUtil.rounded(g, tx, cy + 5, tw, SUB_H - 8, 4, new Color(0xFF131A28));
                g.drawString(font, lbl, tx + 6, cy + 9, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, anim));
            }

            // NEW badge
            if (c == ModCat.NEW) { fr(g, tx + tw - 5, cy + 5, 5, 5, ACCENT_BLUE); }
            tx += tw + 3;
        }

        // Search box
        int sX = cx + cw - 94, sY = cy + 6, sW = 88, sH = 16;
        boolean sfH = mx >= sX && mx < sX + sW && my >= sY && my < sY + sH;
        float sAnim = AnimationUtil.tick("search", searchFocus ? 1f : (sfH ? 0.5f : 0f), 0.2f);
        RenderUtil.rounded(g, sX, sY, sW, sH, 4, new Color(BG_SEARCH));
        int sBorder = AnimationUtil.lerpColor(BORDER_SRCH, ACCENT_BLUE, sAnim);
        bd(g, sX, sY, sW, sH, sBorder);
        g.drawString(font, "🔍", sX + 3, sY + 4, AnimationUtil.lerpColor(TEXT_DARK, TEXT_GRAY, sAnim));
        String ds = search.isEmpty() ? (searchFocus ? "" : "Search...") : search;
        g.drawString(font, ds, sX + 14, sY + 4, search.isEmpty() ? TEXT_DARK : TEXT_BRIGHT);
        if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0)
            fr(g, sX + 14 + font.width(search), sY + 3, 1, 10, TEXT_BRIGHT);
    }

    // ─────────────────────────────────────────────────────────────
    //  MOD CARD GRID
    // ─────────────────────────────────────────────────────────────
    private void renderGrid(GuiGraphics g, int mx, int my, int cx, int cy, int cw, int ch) {
        // clip region
        int sX = cx + 6, sY = cy + 6;
        int maxSc = maxScroll();

        // scrollbar
        if (maxSc > 0) {
            int sbX = cx + cw - 5;
            fr(g, sbX, cy, 4, ch, 0xFF080C14);
            float fr2 = (float) scrollYf / maxSc;
            int tH = Math.max(20, (int)((float) ch / (maxSc + ch) * ch));
            RenderUtil.rounded(g, sbX, cy + (int)((ch - tH) * fr2), 4, tH, 2, new Color(0xFF2D4A80));
        }

        int col = 0, row = 0, total = 0;
        for (Object[] mod : MODS) {
            String name = (String) mod[0], key = (String) mod[1];
            ModCat mc = (ModCat) mod[2]; boolean isN = (boolean) mod[3];
            String desc = (String) mod[4], icon = (String) mod[5];
            int accent = (int)(long)(Integer) mod[6];
            if (!filter(name, mc, isN)) continue;
            total++;

            int cardX = sX + col * (CARD_W + CARD_GAP);
            int cardY = sY + row * (CARD_H + CARD_GAP) - (int)scrollYf;

            if (cardY + CARD_H >= cy && cardY <= cy + ch) {
                boolean en   = mstate.getOrDefault(key, false);
                boolean hov  = mx >= cardX && mx < cardX + CARD_W && my >= Math.max(cardY, cy) && my < cardY + CARD_H && cardY >= cy - 4;
                renderCard(g, cardX, cardY, name, key, icon, desc, en, hov, isN, mc, accent);
                if (hov && cardY >= cy) { tooltip = desc; ttX = mx; ttY = Math.max(cardY - 4, cy); }
            }

            col++; if (col >= COLS) { col = 0; row++; }
        }

        if (total == 0) {
            String msg = "Модов не найдено: «" + search + "»";
            g.drawString(font, msg, cx + (cw - font.width(msg)) / 2, cy + ch / 2, TEXT_GRAY);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  ОДНА КАРТОЧКА МОДА
    // ─────────────────────────────────────────────────────────────
    private void renderCard(GuiGraphics g, int cx, int cy, String name, String key,
                            String icon, String desc, boolean en, boolean hov,
                            boolean isNew, ModCat mc, int accent) {
        String animKey = "card_" + key + "_" + name;
        float ha = AnimationUtil.tick(animKey + "_h", hov ? 1f : 0f, 0.16f);
        float ea = AnimationUtil.tick(animKey + "_e", en  ? 1f : 0f, 0.14f);

        // card bg
        int bg = AnimationUtil.lerpColor(BG_CARD, en ? BG_CARD_EN : BG_CARD_HOV, Math.max(ha, ea * 0.5f));
        RenderUtil.rounded(g, cx, cy, CARD_W, CARD_H, 6, new Color(bg));

        // top accent line (RGB when enabled, static when not)
        int lineColor = en
            ? AnimationUtil.rgbCycleOffset(0.5f, (float)(cx + cy) / 600f)
            : accent;
        int lineAlpha = (int)(255 * Math.max(0.4f, ea));
        g.fillGradient(cx + 6, cy, cx + CARD_W - 6, cy + 2,
            (lineAlpha << 24) | (lineColor & 0x00FFFFFF), 0x00000000);

        // border
        int borderCol = en
            ? AnimationUtil.lerpColor(BORDER_CARD, (accent & 0x00FFFFFF) | 0x60000000, ea)
            : AnimationUtil.lerpColor(BORDER_CARD, 0xFF1E2A45, ha);
        bd(g, cx, cy, CARD_W, CARD_H, borderCol);

        // glow при enabled — RGB пульсирующий
        if (ea > 0.1f) {
            int glowRgb = AnimationUtil.rgbCycleOffset(0.4f, (float)(cx + cy) / 500f);
            for (int i = 4; i > 0; i--) {
                int ga = (int)(35 * ea * (1f - (float)i / 4));
                if (ga > 3) g.fill(cx - i, cy - i, cx + CARD_W + i, cy + CARD_H + i,
                    (ga << 24) | (glowRgb & 0x00FFFFFF));
            }
        }

        // icon circle background
        int iconBgAlpha = (int)(60 + 40 * ha);
        fr(g, cx + 6, cy + 8, 20, 20, (iconBgAlpha << 24) | (accent & 0x00FFFFFF));
        g.drawString(font, icon, cx + 9, cy + 12, AnimationUtil.lerpColor(accent, TEXT_WHITE, ha * 0.4f));

        // mod name
        g.drawString(font, trunc(name, CARD_W - 50), cx + 30, cy + 9, en ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, ha));

        // NEW badge
        if (isNew) {
            fr(g, cx + CARD_W - 30, cy + 7, 26, 10, NEW_BG);
            bd(g, cx + CARD_W - 30, cy + 7, 26, 10, ACCENT_BLUE);
            g.drawString(font, "NEW", cx + CARD_W - 27, cy + 8, NEW_FG);
        }

        // desc
        g.drawString(font, trunc(desc, CARD_W - 10), cx + 5, cy + 24, TEXT_GRAY);

        // separator
        g.fill(cx + 4, cy + CARD_H - 36, cx + CARD_W - 4, cy + CARD_H - 35, BORDER_SEP);

        // ENABLED / DISABLED button
        int eY = cy + CARD_H - 34;
        int enBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, ea);
        fr(g, cx + 4, eY, CARD_W - 36, 14, enBg);
        bd(g, cx + 4, eY, CARD_W - 36, 14,
            AnimationUtil.lerpColor(0xFF3A1A1A, (0x80000000 | (ACCENT_GREEN & 0x00FFFFFF)), ea));
        String eStr = en ? "● ENABLED" : "● DISABLED";
        int eFg = AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, ea);
        g.drawString(font, eStr, cx + 7, eY + 3, eFg);

        // OPTIONS / gear
        int oX = cx + 4, oY = cy + CARD_H - 18;
        boolean gSel = name.equals(optMod);
        fr(g, oX, oY, CARD_W - 36, 14, BG_OPT);
        bd(g, oX, oY, CARD_W - 36, 14, 0xFF141824);
        g.drawString(font, "OPTIONS", oX + 4, oY + 3, hov ? TEXT_GRAY : TEXT_DARK);

        // gear icon button
        int gX = cx + CARD_W - 30;
        float gA = AnimationUtil.tick("gear_" + name, gSel ? 1f : 0f, 0.2f);
        int gBg = AnimationUtil.lerpColor(BG_GEAR, 0xFF1B3060, gA);
        fr(g, gX, oY, 26, 14, gBg);
        bd(g, gX, oY, 26, 14, AnimationUtil.lerpColor(0xFF141824, ACCENT_BLUE, gA));
        g.drawString(font, "⚙", gX + 8, oY + 3, AnimationUtil.lerpColor(TEXT_GRAY, ACCENT_BLUE, gA));
    }

    private int optPanelHeight(String n) {
        return switch (n) {
            case "Kite", "Auto Crystal", "Obsidian Place", "Auto Pearl" -> 130; // 4 слайдера
            case "Auto Bow", "Auto Attack", "Adaptive CD", "ESP", "Radar" -> 86; // 2 слайдера
            case "Auto Dodge", "Auto Heal", "Auto Gap", "Auto Log",
                 "Bunker", "Hunt", "Auto Eat", "W-Tap", "Tracers" -> 60; // 1 слайдер
            case "Smoke Bomb" -> 86; // FIX #6: 2 слайдера — MinDist + Cooldown
            default -> 52; // текст
        };
    }

    // ─────────────────────────────────────────────────────────────
    //  OPTIONS PANEL
    // ─────────────────────────────────────────────────────────────
    private void renderOptPanel(GuiGraphics g, int mx, int my, String mName) {
        int pX = Math.min(optPanX, winX + WIN_W - 170);
        int pY = Math.min(optPanY, winY + WIN_H - FOOT_H - 138);
        int pW = 164, pH = optPanelHeight(mName);
        // shadow
        for (int i = 6; i > 0; i--) {
            int a = (int)(35 * (1f - (float)i / 6));
            g.fill(pX - i, pY - i, pX + pW + i, pY + pH + i, (a << 24));
        }
        RenderUtil.rounded(g, pX, pY, pW, pH, 6, new Color(0xFF0C1018));
        bd(g, pX, pY, pW, pH, ACCENT_BLUE);
        // header
        g.fillGradient(pX, pY, pX + pW, pY + 18, 0xFF0F1825, 0xFF0C1018);
        g.fill(pX, pY + 17, pX + pW, pY + 18, ACCENT_BLUE);
        g.drawString(font, mName, pX + 6, pY + 5, TEXT_WHITE);
        // close x
        g.drawString(font, "✕", pX + pW - 12, pY + 5, TEXT_GRAY);

        renderOptParams(g, mx, my, mName, pX + 5, pY + 22, pW - 10);
    }

    private void renderOptParams(GuiGraphics g, int mx, int my, String n, int px, int py, int pw) {
        switch (n) {
            // ── COMBAT ─────────────────────────────────────────────
            case "Auto Attack" -> {
                drawSlider(g, mx, my, "Atk CD",    px, py,      pw, 2,  30,  cfg.attackCooldown, 0);
                drawSlider(g, mx, my, "Atk Range", px, py + 26, pw, 1,  6,   cfg.attackRange,    1);
            }
            case "W-Tap" -> {
                drawSlider(g, mx, my, "Release T", px, py,      pw, 1,  8,   cfg.wTapReleaseTicks, 0);
            }
            case "Auto Crystal", "Obsidian Place" -> {
                drawSlider(g, mx, my, "Place R",   px, py,      pw, 2,  10,  cfg.crystalPlaceRange,   0);
                drawSlider(g, mx, my, "Cr CD",     px, py + 26, pw, 1,  20,  cfg.crystalCooldown,     1);
                drawSlider(g, mx, my, "Cr DMG",    px, py + 52, pw, 5,  30,  cfg.diffCrystalDamage,   2);
                drawSlider(g, mx, my, "Diff CD",   px, py + 78, pw, 1,  60,  cfg.diffCrystalCooldown, 3);
            }
            case "Auto Bow" -> {
                drawSlider(g, mx, my, "Bow Range", px, py,      pw, 5,  50,  cfg.bowRange,    0);
                drawSlider(g, mx, my, "Bow CD",    px, py + 26, pw, 5,  60,  cfg.bowCooldown, 1);
            }
            case "Kite" -> {
                drawSlider(g, mx, my, "Bow Range", px, py,      pw, 5,  50,  cfg.bowRange,    0);
                drawSlider(g, mx, my, "Bow CD",    px, py + 26, pw, 5,  60,  cfg.bowCooldown, 1);
                drawSlider(g, mx, my, "Min Dist",  px, py + 52, pw, 2,  20,  cfg.kiteMinDist, 2);
                drawSlider(g, mx, my, "Max Dist",  px, py + 78, pw, 5,  40,  cfg.kiteMaxDist, 3);
            }
            case "Auto Dodge" -> {
                drawSlider(g, mx, my, "Dodge R",   px, py,      pw, 1,  8,   cfg.dodgeRange,  0);
            }
            // ── MECHANIC ───────────────────────────────────────────
            case "Auto Heal" -> {
                drawSlider(g, mx, my, "Heal HP",   px, py,      pw, 1,  20,  cfg.healThreshold,        0);
            }
            case "Auto Gap" -> {
                drawSlider(g, mx, my, "Gap HP",    px, py,      pw, 1,  20,  cfg.autoGapHpThreshold,   0);
            }
            case "Auto Log" -> {
                drawSlider(g, mx, my, "Log HP",    px, py,      pw, 1,  15,  cfg.autoLogHpThreshold,   0);
            }
            case "Auto Pearl" -> {
                drawSlider(g, mx, my, "Pearl Dist",px, py,      pw, 5,  32,  cfg.diffPearlThrowDist,   0);
                drawSlider(g, mx, my, "Escape HP", px, py + 26, pw, 1,  20,  cfg.diffPearlEscapeHpThreshold, 1);
                drawSlider(g, mx, my, "Pearl CD",  px, py + 52, pw, 20, 300, cfg.diffPearlCooldown,    2);
            }
            case "Bunker" -> {
                drawSlider(g, mx, my, "Bunker HP", px, py,      pw, 1,  20,  cfg.bunkerHpThreshold,    0);
            }
            case "Hunt" -> {
                drawSlider(g, mx, my, "Hunt Range",px, py,      pw, 16, 256, cfg.huntRange,             0);
            }
            case "Anti KB" -> {
                g.drawString(font, "Снижает отброс", px, py,      TEXT_GRAY);
                g.drawString(font, "от ударов врага", px, py + 12, TEXT_DARK);
            }
            case "Auto Eat" -> {
                drawSlider(g, mx, my, "Food Thr",  px, py,      pw, 1,  20,  cfg.eatThreshold,          0);
            }
            // ── VISUAL / HUD ───────────────────────────────────────
            case "ESP" -> {
                drawSlider(g, mx, my, "ESP Range", px, py,      pw, 10, 128, cfg.espRange,              0);
                drawSlider(g, mx, my, "Line W",    px, py + 26, pw, 1,  5,   cfg.espLineWidth,          1);
            }
            case "Radar" -> {
                drawSlider(g, mx, my, "Radar R",   px, py,      pw, 10, 128, cfg.radarRange,            0);
                drawSlider(g, mx, my, "Radar Rad", px, py + 26, pw, 10, 100, cfg.radarRadius,           1);
            }
            case "Tracers" -> {
                drawSlider(g, mx, my, "ESP Range", px, py,      pw, 10, 128, cfg.espRange,              0);
            }
            // ── SERVER / AI ────────────────────────────────────────
            case "Adaptive CD" -> {
                drawSlider(g, mx, my, "Atk CD",    px, py,      pw, 2,  30,  cfg.attackCooldown,        0);
                drawSlider(g, mx, my, "Atk Range", px, py + 26, pw, 1,  6,   cfg.attackRange,           1);
            }
            // ── FIX #6: SmokeBomb ─────────────────────────────────
            case "Smoke Bomb" -> {
                drawSlider(g, mx, my, "Min Dist",  px, py,      pw, 2,  30,  cfg.smokeBombMinDist,       0);
                drawSlider(g, mx, my, "CD (ticks)",px, py + 26, pw, 20, 300, cfg.smokeBombCooldown,      1);
            }
            // ── TOGGLES-ONLY (нет числовых параметров) ─────────────
            case "S-Tap", "Auto Sprint", "Toggle Sneak",
                 "Auto Armor", "Auto Totem", "Auto Respawn",
                 "Fake Attack", "Pattern AI", "Anti Pattern",
                 "Ping Display", "Show HUD", "Show DPS", "Bot Stats",
                 "Notifications", "Training Mode", "Standby",
                 "Whitelist", "Auto Kit" -> {
                g.drawString(font, "Только вкл/выкл", px, py,      TEXT_GRAY);
                g.drawString(font, "— кнопка на карточке", px, py + 12, TEXT_DARK);
            }
            default -> {
                g.drawString(font, "Нет параметров", px, py,      TEXT_GRAY);
                g.drawString(font, "вкл/выкл на карточке", px, py + 12, TEXT_DARK);
            }
        }
    }

    private void drawSlider(GuiGraphics g, int mx, int my, String label,
                            int sx, int sy, int sw, double min, double max, double val, int idx) {
        // label left, value right
        g.drawString(font, label + ":", sx, sy, TEXT_GRAY);
        String vs = (val == (int) val) ? String.valueOf((int) val) : String.format("%.1f", val);
        g.drawString(font, vs, sx + sw - font.width(vs), sy, TEXT_BRIGHT);

        int ty = sy + 11;
        // track
        RenderUtil.rounded(g, sx, ty, sw, 5, 2, new Color(0xFF101826));
        double frac = Math.max(0, Math.min(1, (val - min) / (max - min)));
        // fill
        int fillW = (int)(sw * frac);
        if (fillW > 4) RenderUtil.rounded(g, sx, ty, fillW, 5, 2, new Color(ACCENT_BLUE));
        // knob
        int kx = sx + fillW - 4;
        boolean kHov = mx >= kx - 2 && mx < kx + 10 && my >= ty - 3 && my < ty + 8;
        float kA = AnimationUtil.tick("slider_" + idx, kHov ? 1f : 0f, 0.2f);
        int kColor = AnimationUtil.lerpColor(ACCENT_BLUE, TEXT_WHITE, kA);
        RenderUtil.rounded(g, kx, ty - 2, 8, 9, 3, new Color(kColor));
    }

    // ═══════════════════════════════════════════════════════════════
    //  SETTINGS TAB
    // ═══════════════════════════════════════════════════════════════
    private void renderSettings(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        g.fill(cx, cy, cx + cw, cy + ch, 0xFF0A0D12);
        fr(g, cx, cy, cw, ch, BG_MAIN);
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        int sx = cx + 12, sy = cy + 8;

        // DIFFICULTY
        secTitle(g, "DIFFICULTY", sx, sy); sy += 14;
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int[] dc = {0xFF22C55E, 0xFFEAB308, 0xFFEF4444, 0xFF991B1B};
        int dcW = 58;
        for (int i = 0; i < 4; i++) {
            int dx = sx + i * (dcW + 4);
            boolean act = cfg.difficulty == diffs[i];
            boolean hov = mx >= dx && mx < dx + dcW && my >= sy && my < sy + 22;
            float a = AnimationUtil.tick("sets_diff_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int dBg = AnimationUtil.lerpColor(BG_CARD, (dc[i] & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, dx, sy, dcW, 22, 4, new Color(dBg));
            g.fill(dx, sy, dx + dcW, sy + 2, dc[i]);
            g.drawString(font, diffs[i].name(), dx + 4, sy + 7, act ? dc[i] : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
            if (act) g.drawString(font, "✓", dx + dcW - 10, sy + 7, dc[i]);
        }
        sy += 32;

        // COMBAT MODE
        secTitle(g, "COMBAT MODE", sx, sy); sy += 14;
        PVPBotConfig.Mode[] modes = PVPBotConfig.Mode.values();
        String[] mIcons = {
            "🗡",   // SWORD      — голубой меч (mctiers)
            "🪓",   // AXE        — голубой топор (mctiers)
            "🔨",   // MACE       — серая булава (mctiers)
            "🔨",   // MACE_ELYTRA— булава + элитры
            "❤",   // UHC        — красное сердце (mctiers)
            "💀",   // NETHOP     — фиолетовый череп (mctiers)
            "⚗",   // POT        — колба/зелье (mctiers)
            "🟢",   // SMP        — зелёный жемчуг (mctiers)
            "💠",   // CRYSTAL    — голубой кристалл (mctiers Vanilla)
            "💀",   // NETHPOT    — фиолетовый череп
            "💠",   // TPC        — кристалл
            "❄",   // SNOWBALL
            "❤",   // TOTEM      — сердце
            "🔱",   // TRIDENT
            "🐝",   // BEEHIVE
            "🎆",   // FIREWORK
            "🏹",   // CROSSBOW
        };
        int availW = WIN_W - LEFT_W - 20;
        int modesPerRow = 7;
        int mcW = (availW - (modesPerRow - 1) * 3) / modesPerRow; // авто-ширина
        int mcH = 20;
        for (int i = 0; i < modes.length; i++) {
            int mc = i % modesPerRow, mr = i / modesPerRow;
            int mx2 = sx + mc * (mcW + 3), my2 = sy + mr * (mcH + 3);
            boolean act = cfg.mode == modes[i];
            boolean hov = mx >= mx2 && mx < mx2 + mcW && my >= my2 && my < my2 + mcH;
            float a = AnimationUtil.tick("sets_mode_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int strp = modeColor(modes[i]);
            int mBg = AnimationUtil.lerpColor(BG_CARD, (strp & 0x00FFFFFF) | 0x18000000, a);
            RenderUtil.rounded(g, mx2, my2, mcW, mcH, 3, new Color(mBg));
            g.fill(mx2, my2, mx2 + mcW, my2 + 2, act ? strp : AnimationUtil.lerpColor(0xFF101826, strp, a * 0.7f));
            String ico = i < mIcons.length ? mIcons[i] : "?";
            String label = trunc(modes[i].name(), mcW - 16);
            g.drawString(font, ico + " " + label, mx2 + 3, my2 + 6, act ? TEXT_WHITE : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
        }
        sy += (modes.length / modesPerRow + 2) * (mcH + 3) + 6;

        // QUICK TOGGLES
        secTitle(g, "QUICK TOGGLES", sx, sy); sy += 14;
        renderTogRow(g, mx, my, sx, sy,
            new String[]{"W-Tap","Pearls","Crystals","Standby","PatternAI"},
            new boolean[]{cfg.wTapEnabled, cfg.diffUsePearls, cfg.diffUseCrystals, cfg.standbyMode, cfg.patternAIEnabled});
        sy += 22;
        renderTogRow(g, mx, my, sx, sy,
            new String[]{"AdaptCD","Whitelist","Bunker","Hunt","Training"},
            new boolean[]{cfg.adaptiveCooldownEnabled, cfg.whitelistEnabled, cfg.bunkerEnabled, cfg.huntEnabled, cfg.trainingMode});
        sy += 22;

        // Strafe row
        boolean strafeOn = cfg.strafeEnabled;
        boolean strafeHov = mx >= sx && mx < sx + 88 && my >= sy && my < sy + 16;
        float strafeA = AnimationUtil.tick("togrow_Strafe", strafeOn ? 1f : (strafeHov ? 0.4f : 0f), 0.16f);
        int strafeBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, strafeA);
        RenderUtil.rounded(g, sx, sy, 88, 16, 3, new Color(strafeBg));
        bd(g, sx, sy, 88, 16, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, strafeA));
        g.drawString(font, "Strafe:" + (strafeOn ? "ON" : "OFF"), sx + 4, sy + 4,
            AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, strafeA));

        // Strafe style buttons
        StrafeAI.StrafeStyle[] styles = StrafeAI.StrafeStyle.values();
        int styleX = sx + 96;
        for (int i = 0; i < styles.length; i++) {
            boolean act = cfg.strafeStyle == styles[i];
            boolean hov = mx >= styleX && mx < styleX + 58 && my >= sy && my < sy + 16;
            float sa = AnimationUtil.tick("strafe_style_" + i, (act || hov) ? 1f : 0f, 0.16f);
            int sbg = AnimationUtil.lerpColor(BG_CARD, (ACCENT_CYAN & 0x00FFFFFF) | 0x25000000, sa);
            RenderUtil.rounded(g, styleX, sy, 58, 16, 3, new Color(sbg));
            bd(g, styleX, sy, 58, 16, act ? ACCENT_CYAN : AnimationUtil.lerpColor(BORDER_CARD, ACCENT_CYAN, sa));
            g.drawString(font, styles[i].name(), styleX + 4, sy + 4,
                act ? ACCENT_CYAN : AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, sa));
            styleX += 62;
        }
        sy += 30;

        // PARAMETERS
        secTitle(g, "PARAMETERS", sx, sy); sy += 14;
        renderNumRow(g, mx, my, sx,       sy,    "Attack CD",  String.valueOf(cfg.attackCooldown));
        renderNumRow(g, mx, my, sx + 210, sy,    "Atk Range",  String.format("%.1f", cfg.attackRange));
        renderNumRow(g, mx, my, sx,       sy+20, "Max Bots",   String.valueOf(cfg.maxBots));
        renderNumRow(g, mx, my, sx + 210, sy+20, "Cr.Damage",  String.format("%.0f", cfg.diffCrystalDamage));
        renderNumRow(g, mx, my, sx,       sy+40, "Heal HP",    String.format("%.0f", cfg.healThreshold));
        renderNumRow(g, mx, my, sx + 210, sy+40, "Crystal CD", String.valueOf(cfg.crystalCooldown));
        renderNumRow(g, mx, my, sx,       sy+60, "Bot Max HP", String.format("%.0f", cfg.botMaxHealth));
        renderNumRow(g, mx, my, sx + 210, sy+60, "Heal Thr",   String.format("%.0f", cfg.botHealThreshold));
        sy += 80;

        // ── SOUND (переехал в отдельную вкладку SOUND) ───────────
        secTitle(g, "CLIENT SOUNDS", sx, sy); sy += 14;
        g.drawString(font, "§7Настройки звука перенесены во вкладку  §b[ SOUND ]", sx, sy, TEXT_GRAY);
        sy += 24;

        // ── WEB CONFIG ────────────────────────────────────────────
        secTitle(g, "WEB CONFIG (порт " + cfg.webConfigPort + ")", sx, sy); sy += 14;
        boolean wcOn = cfg.webConfigEnabled;
        boolean wcHov = mx >= sx && mx < sx + 120 && my >= sy && my < sy + 18;
        float wcA = AnimationUtil.tick("wc_toggle", wcOn ? 1f : (wcHov ? 0.4f : 0f), 0.18f);
        int wcBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, wcA);
        RenderUtil.rounded(g, sx, sy, 120, 18, 4, new Color(wcBg));
        bd(g, sx, sy, 120, 18, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, wcA));
        g.drawString(font, wcOn ? "🌐 HTTP: ON  (localhost:" + cfg.webConfigPort + ")" : "🌐 HTTP: OFF",
            sx + 5, sy + 5, AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, wcA));
        if (wcOn) {
            g.drawString(font, "→ http://localhost:" + cfg.webConfigPort, sx + 130, sy + 5, TEXT_GRAY);
        }
        sy += 26;

        // ── AUTO CHAT TAUNTS ──────────────────────────────────────
        secTitle(g, "AUTO CHAT TAUNTS", sx, sy); sy += 14;
        boolean acOn = cfg.autoChatEnabled;
        boolean acHov = mx >= sx && mx < sx + 100 && my >= sy && my < sy + 16;
        float acA = AnimationUtil.tick("ac_toggle", acOn ? 1f : (acHov ? 0.4f : 0f), 0.18f);
        RenderUtil.rounded(g, sx, sy, 100, 16, 3, new Color(AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, acA)));
        bd(g, sx, sy, 100, 16, AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, acA));
        g.drawString(font, "AutoChat: " + (acOn ? "ON" : "OFF"), sx + 4, sy + 4,
            AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, acA));
        sy += 20;
        // Kill message field
        g.drawString(font, "Kill msg:", sx, sy + 2, TEXT_GRAY);
        int kmX = sx + 58; int kmW = 180;
        fr(g, kmX, sy, kmW, 13, BG_CARD); bd(g, kmX, sy, kmW, 13, BORDER_CARD);
        g.drawString(font, trunc(cfg.chatKillMessage, kmW - 6), kmX + 3, sy + 2, TEXT_BRIGHT);
        sy += 18;
        // Low HP message field
        g.drawString(font, "Low HP:", sx, sy + 2, TEXT_GRAY);
        fr(g, kmX, sy, kmW, 13, BG_CARD); bd(g, kmX, sy, kmW, 13, BORDER_CARD);
        g.drawString(font, trunc(cfg.chatLowHpMessage, kmW - 6), kmX + 3, sy + 2, TEXT_BRIGHT);
        g.drawString(font, "(click to edit)", kmX + kmW + 4, sy + 2, TEXT_GRAY);
        sy += 24;

        // ── BOT LEARNING ──────────────────────────────────────────
        secTitle(g, "BOT LEARNING", sx, sy); sy += 14;
        boolean blRec = BotLearning.INSTANCE.isRecording();
        g.drawString(font, "Status: " + (blRec ? "§aRECORDING" : "§7IDLE"), sx, sy, TEXT_GRAY); sy += 12;
        int topN = BotLearning.INSTANCE.getPatternCount();
        g.drawString(font, "Learned patterns: §e" + topN, sx, sy, TEXT_GRAY); sy += 12;
        // Start/Stop buttons
        int blBtnW = 72;
        for (int i = 0; i < 3; i++) {
            String[] btnLabels = {"▶ Start", "■ Stop", "⟳ Reset"};
            int[] btnColors = {ACCENT_GREEN, ACCENT_RED, ACCENT_YEL};
            int bx = sx + i * (blBtnW + 4);
            boolean bHov = mx >= bx && mx < bx + blBtnW && my >= sy && my < sy + 16;
            float bA = AnimationUtil.tick("bl_btn_" + i, bHov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, bx, sy, blBtnW, 16, 3,
                new Color(AnimationUtil.lerpColor(BG_CARD, (btnColors[i] & 0x00FFFFFF) | 0x22000000, bA)));
            bd(g, bx, sy, blBtnW, 16, AnimationUtil.lerpColor(BORDER_CARD, btnColors[i], bA));
            g.drawCenteredString(font, btnLabels[i], bx + blBtnW / 2, sy + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, btnColors[i], bA));
        }
        // Top pattern display
        sy += 22;
        var topPat = BotLearning.INSTANCE.getTopPattern();
        if (topPat != null && !topPat.isEmpty()) {
            // Format: first 6 actions abbreviated
            StringBuilder sb = new StringBuilder("Top: ");
            int show = Math.min(6, topPat.size());
            for (int i = 0; i < show; i++) {
                if (i > 0) sb.append("→");
                sb.append(topPat.get(i).name().substring(0, Math.min(3, topPat.get(i).name().length())));
            }
            if (topPat.size() > 6) sb.append("…");
            sb.append(" (").append(BotLearning.INSTANCE.getPatternCount()).append(" total)");
            g.drawString(font, trunc(sb.toString(), WIN_W - LEFT_W - 30), sx, sy, ACCENT_CYAN);
        } else {
            g.drawString(font, "No patterns yet — stand near a player and /bot learn start", sx, sy, TEXT_GRAY);
        }
        g.disableScissor();
    }

    private void renderTogRow(GuiGraphics g, int mx, int my, int sx, int sy, String[] labels, boolean[] vals) {
        for (int i = 0; i < labels.length; i++) {
            int tx = sx + i * 96, ty = sy;
            boolean on = vals[i];
            boolean hov = mx >= tx && mx < tx + 88 && my >= ty && my < ty + 16;
            float a = AnimationUtil.tick("togrow_" + labels[i], on ? 1f : (hov ? 0.4f : 0f), 0.16f);
            int tBg = AnimationUtil.lerpColor(BG_DISABLED, BG_ENABLED, a);
            RenderUtil.rounded(g, tx, ty, 88, 16, 3, new Color(tBg));
            int tBorder = AnimationUtil.lerpColor(0xFF2A1010, 0xFF1A3A1A, a);
            bd(g, tx, ty, 88, 16, tBorder);
            g.drawString(font, labels[i] + ":" + (on ? "ON" : "OFF"), tx + 4, ty + 4,
                AnimationUtil.lerpColor(TEXT_RED, TEXT_GREEN, a));
        }
    }

    private void renderNumRow(GuiGraphics g, int mx, int my, int sx, int sy, String label, String val) {
        g.drawString(font, label + ":", sx, sy + 2, TEXT_GRAY);
        fr(g, sx + 118, sy, 50, 12, BG_CARD); bd(g, sx + 118, sy, 50, 12, BORDER_CARD);
        g.drawString(font, val, sx + 122, sy + 2, TEXT_BRIGHT);
        // minus/plus
        for (int i = 0; i < 2; i++) {
            int bx = sx + 170 + i * 16;
            boolean hov = mx >= bx && mx < bx + 14 && my >= sy && my < sy + 12;
            float a = AnimationUtil.tick("pm_" + label + i, hov ? 1f : 0f, 0.2f);
            fr(g, bx, sy, 14, 12, AnimationUtil.lerpColor(BG_GEAR, 0xFF1A2A40, a));
            bd(g, bx, sy, 14, 12, AnimationUtil.lerpColor(BORDER_CARD, ACCENT_BLUE, a));
            g.drawString(font, i == 0 ? "−" : "+", bx + 3, sy + 2, AnimationUtil.lerpColor(TEXT_GRAY, TEXT_BRIGHT, a));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  DIFFICULTY TAB
    // ═══════════════════════════════════════════════════════════════
    // ── Делегировано в DifficultyTabRenderer ──
    // private void renderDifficulty(...) — тело перенесено в gui/tab/DifficultyTabRenderer.java

    // ── Делегировано в ProfilesTabRenderer ──
    // private void renderProfilesTab(...) — тело перенесено в gui/tab/ProfilesTabRenderer.java

    // ─────────────────────────────────────────────────────────────
    //  MISSING STUBS (called by existing code, bodies trimmed in refactor)
    // ─────────────────────────────────────────────────────────────

    /** Reads a boolean config field by its string key via reflection. */
    private boolean getB(String key) {
        try {
            java.lang.reflect.Field f = PVPBotConfig.class.getField(key);
            return (boolean) f.get(cfg);
        } catch (Exception e) {
            return false;
        }
    }

    /** Squad tab — no interactive widgets needed; render is handled by SquadTabRenderer. */
    private void buildSquadWidgets() {
        // Clicks handled in mouseClicked via coordinate checks. Render is custom.
    }

    /** Roles tab — no interactive widgets needed; render is handled by RolesTabRenderer. */
    private void buildRolesWidgets() {
        // Clicks handled in mouseClicked via coordinate checks. Render is custom.
    }

    /** Draws the bottom status bar (version, mode label). */
    private void renderFooter(GuiGraphics g, int mx, int my) {
        int fx = winX;
        int fy = winY + WIN_H - 16;
        g.fill(fx, fy, fx + WIN_W, fy + 16, 0xAA080C14);
        String ver = "PVPBot v5.0  |  " + (cfg.enabled ? "§aACTIVE" : "§cINACTIVE");
        g.drawString(font, ver, fx + 6, fy + 4, TEXT_GRAY);
    }

    /** Renders a small tooltip near the cursor. */
    private void renderTooltip2(GuiGraphics g, String text, int x, int y) {
        int tw = font.width(text) + 8;
        int th = 14;
        int tx = Math.min(x + 6, winX + WIN_W - tw - 4);
        int ty = Math.max(y - th - 2, winY + 2);
        g.fill(tx, ty, tx + tw, ty + th, 0xEE0C1018);
        g.fill(tx, ty, tx + 1, ty + th, ACCENT_BLUE);
        g.drawString(font, text, tx + 4, ty + 3, TEXT_BRIGHT);
    }

    /** Shorthand: filled rectangle. */
    private void fr(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    /** Shorthand: 1-pixel border rectangle. */
    private void bd(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x,         y,         x + w,     y + 1,     color); // top
        g.fill(x,         y + h - 1, x + w,     y + h,     color); // bottom
        g.fill(x,         y,         x + 1,     y + h,     color); // left
        g.fill(x + w - 1, y,         x + w,     y + h,     color); // right
    }
}