package com.pvpbot;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * EnchantUtil — утилита для выдачи зачарованных предметов в 1.21.4.
 *
 * В 1.21.x зачарования хранятся как компонент DataComponents.ENCHANTMENTS
 * типа ItemEnchantments. Класс предоставляет удобный fluent-билдер.
 *
 * Использование:
 *   ItemStack sword = EnchantUtil.of(Items.DIAMOND_SWORD)
 *       .enchant("sharpness", 5)
 *       .enchant("unbreaking", 3)
 *       .build();
 */
public class EnchantUtil {

    private final ItemStack stack;
    private final ItemEnchantments.Mutable enchants = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);

    private EnchantUtil(ItemStack stack) {
        this.stack = stack;
    }

    /** Создать билдер для предмета. */
    public static EnchantUtil of(net.minecraft.world.item.Item item) {
        return new EnchantUtil(new ItemStack(item));
    }

    /** Добавить зачарование по пути (например "protection", "sharpness"). */
    public EnchantUtil enchant(String path, int level) {
        ResourceLocation rl = ResourceLocation.withDefaultNamespace(path);
        var enchOpt = BuiltInRegistries.ENCHANTMENT.getHolder(
            net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.ENCHANTMENT, rl
            )
        );
        enchOpt.ifPresent(holder -> enchants.set(holder, level));
        return this;
    }

    /** Собрать готовый ItemStack с зачарованиями. */
    public ItemStack build() {
        stack.set(DataComponents.ENCHANTMENTS, enchants.toImmutable());
        return stack;
    }

    /**
     * Быстрый метод: создать стак с одним зачарованием.
     * EnchantUtil.single(Items.DIAMOND_HELMET, "protection", 4)
     */
    public static ItemStack single(net.minecraft.world.item.Item item, String enchant, int level) {
        return of(item).enchant(enchant, level).build();
    }
}
