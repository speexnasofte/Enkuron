package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * CrystalBotLogic v5.0 — MCTiers Crystal PvP.
 *
 * Чёткий цикл:
 *   1. PLACE_OBS  — кладём обсидиан под/рядом с целью
 *   2. PLACE_CRYS — ставим кристалл на обсидиан
 *   3. EXPLODE    — взрываем кристалл когда цель рядом
 *   → повторяем
 *
 * Дополнительно:
 *   - Меч KB1 отбрасывает цель на кристалл
 *   - Эндер жемчуг при dist > 10
 *   - Golden Apple при низком HP
 *   - Тотем в оффхенд всегда
 *   - +40% урона от взрыва если цель в воздухе
 */
public class CrystalBotLogic {

    private enum Phase { PLACE_OBS, PLACE_CRYS, EXPLODE }

    private final BotEntity    bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final ObsidianPlacer obsidianPlacer = new ObsidianPlacer();

    private Phase phase = Phase.PLACE_OBS;

    // Кулдауны
    private int obsTimer    = 0;
    private int placeTimer  = 0;
    private int explodeTimer= 0;
    private int swordTimer  = 0;
    private int pearlCd     = 0;
    private int gapCd       = 0;
    private int speedCd     = 0;

    // Последний поставленный кристалл
    private EndCrystal placedCrystal = null;

    private static final double PLACE_RANGE  = 5.5;
    private static final double MELEE_RANGE  = 3.0;
    private static final double PEARL_RANGE  = 10.0;
    private static final int    OBS_CD       = 3;   // тиков между обсидианом
    private static final int    PLACE_CD     = 5;   // тиков между кристаллами
    private static final int    EXPLODE_CD   = 4;   // тиков между взрывами
    private static final int    SWORD_CD     = 8;
    private static final int    PEARL_CD     = 80;
    private static final int    GAP_CD       = 220;
    private static final int    SPEED_CD     = 400;
    private static final int    OBS_NEEDED   = 2;   // минимум обсидиана перед кристаллом

    public CrystalBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(ServerLevel sw, LivingEntity target) {
        if (sw == null || target == null || !target.isAlive()) return;

        if (obsTimer     > 0) obsTimer--;
        if (placeTimer   > 0) placeTimer--;
        if (explodeTimer > 0) explodeTimer--;
        if (swordTimer   > 0) swordTimer--;
        if (pearlCd      > 0) pearlCd--;
        if (gapCd        > 0) gapCd--;
        if (speedCd      > 0) speedCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Всегда: тотем в оффхенд ───────────────────────────────
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // ── Всегда: Speed II ──────────────────────────────────────
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }

        // ── Всегда: Golden Apple при низком HP ───────────────────
        if (myHp < 10.0f && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
        }

        // ── Эндер жемчуг для сближения ───────────────────────────
        if (dist > PEARL_RANGE && pearlCd <= 0) {
            bot.moveTo(target.getX(), target.getY(), target.getZ());
            sw.sendParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
            return;
        }

        // ── Позиционирование ──────────────────────────────────────
        if (dist > PLACE_RANGE - 0.5)
            bot.getNavigation().moveTo(target, 1.0);
        else if (dist < 2.5)
            bot.getNavigation().stop();

        // ── Меч KB1 — отбрасываем цель на кристалл ───────────────
        if (dist <= MELEE_RANGE && swordTimer <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
            // KB1 — толкаем цель от бота (в сторону кристаллов)
            Vec3 kb = target.position().subtract(bot.position()).normalize();
            target.setDeltaMovement(
                target.getDeltaMovement().add(kb.x * 0.9, 0.25, kb.z * 0.9)
            );
            swordTimer = SWORD_CD;
        }

        // ── Главный цикл: обсидиан → кристалл → взрыв ────────────
        switch (phase) {
            case PLACE_OBS  -> tickPlaceObs(sw, target);
            case PLACE_CRYS -> tickPlaceCrys(sw, target);
            case EXPLODE    -> tickExplode(sw, target);
        }
    }

    // ── Фаза 1: кладём обсидиан ───────────────────────────────────
    private void tickPlaceObs(ServerLevel sw, LivingEntity target) {
        if (obsTimer > 0) return;

        obsidianPlacer.tick(sw, bot, target);
        obsTimer = OBS_CD;

        // Считаем сколько обсидиана уже есть рядом
        int obsCount = countObsidianNear(sw, target);
        if (obsCount >= OBS_NEEDED) {
            phase = Phase.PLACE_CRYS;
            log("§e[Crystal] Обсидиан готов (" + obsCount + " блоков) → ставим кристалл");
        }
    }

    // ── Фаза 2: ставим кристалл на обсидиан ──────────────────────
    private void tickPlaceCrys(ServerLevel sw, LivingEntity target) {
        if (placeTimer > 0) return;

        // Нет обсидиана — назад
        BlockPos obsPos = ObsidianPlacer.findCrystalBase(sw, target);
        if (obsPos == null) {
            phase = Phase.PLACE_OBS;
            return;
        }

        BlockPos crystalPos = obsPos.above();

        // Проверяем что место свободно
        if (!sw.getBlockState(crystalPos).isAir() || !sw.getBlockState(crystalPos.above()).isAir()) {
            // Место занято — ищем другое через ObsidianPlacer уже при следующем тике
            placeTimer = PLACE_CD;
            return;
        }

        // Спавним кристалл
        EndCrystal crystal = EntityType.END_CRYSTAL.create(sw, EntitySpawnReason.TRIGGERED);
        if (crystal == null) return;
        crystal.moveTo(crystalPos.getX() + 0.5, crystalPos.getY(), crystalPos.getZ() + 0.5);
        crystal.setBeamTarget(null);
        sw.addFreshEntity(crystal);

        placedCrystal = crystal;
        placeTimer    = PLACE_CD;
        phase         = Phase.EXPLODE;

        log("§a[Crystal] Кристалл поставлен → взрываем");
    }

    // ── Фаза 3: взрываем кристалл ────────────────────────────────
    private void tickExplode(ServerLevel sw, LivingEntity target) {
        if (explodeTimer > 0) return;

        double dist = bot.distanceTo(target);

        // Ищем ближайший кристалл к цели
        AABB searchBox = target.getBoundingBox().inflate(cfg.crystalPlaceRange);
        List<EndCrystal> crystals = sw.getEntitiesOfClass(EndCrystal.class, searchBox, e -> true);

        if (crystals.isEmpty()) {
            // Кристаллов нет — назад к постановке
            phase = Phase.PLACE_OBS;
            return;
        }

        // Цель должна быть в зоне взрыва
        EndCrystal best = crystals.stream()
            .min(Comparator.comparingDouble(c -> c.distanceToSqr(target)))
            .orElse(null);
        if (best == null) { phase = Phase.PLACE_OBS; return; }

        double crystalDist = best.distanceTo(target);

        // Ждём пока цель подойдёт к кристаллу (или бьём мечом чтобы затолкать)
        if (crystalDist > 4.5) {
            explodeTimer = EXPLODE_CD;
            return;
        }

        // Взрываем!
        boolean inAir = !target.onGround();
        float   damage = inAir
            ? cfg.diffCrystalDamage * 1.4f   // +40% если в воздухе
            : cfg.diffCrystalDamage;

        if (target != null && target.isAlive()) target.hurt(sw.damageSources().explosion(bot, bot), damage);

        Vec3 kb = target.position().subtract(best.position()).normalize().scale(1.5);
        target.setDeltaMovement(target.getDeltaMovement().add(kb.x, 0.6, kb.z));

        best.discard();
        placedCrystal = null;

        sw.sendParticles(ParticleTypes.EXPLOSION,
            best.getX(), best.getY(), best.getZ(), 5, 0.6,0.6,0.6,0.1);
        bot.playSound(SoundEvents.GENERIC_EXPLODE.value(), 1.2f, 1.0f);

        explodeTimer = EXPLODE_CD;

        log(String.format("§c[Crystal] Взрыв! §e%.1f урона §7(%s)",
            damage, inAir ? "в воздухе +40%" : "земля"));

        // Если кристаллов больше нет — снова ставим
        if (crystals.size() <= 1) phase = Phase.PLACE_OBS;
        // Иначе продолжаем взрывать оставшиеся
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private int countObsidianNear(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition().below();
        int count = 0;
        int[] dx = { 0,  1, -1,  0,  0,  1, -1,  1, -1 };
        int[] dz = { 0,  0,  0,  1, -1,  1, -1, -1,  1 };
        for (int i = 0; i < dx.length; i++) {
            BlockPos p = base.offset(dx[i], 0, dz[i]);
            var b = level.getBlockState(p).getBlock();
            if (b == net.minecraft.world.level.block.Blocks.OBSIDIAN
             || b == net.minecraft.world.level.block.Blocks.BEDROCK) count++;
        }
        return count;
    }

    private void log(String msg) {
        if (bot.getOwner() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    public String getPhaseLabel() {
        return switch (phase) {
            case PLACE_OBS  -> "CRYS:OBS";
            case PLACE_CRYS -> "CRYS:PLACE";
            case EXPLODE    -> "CRYS:BOOM!";
        };
    }
}
