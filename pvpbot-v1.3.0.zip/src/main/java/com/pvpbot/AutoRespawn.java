package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.network.chat.Component;

/**
 * Авто-респавн: обнаруживает экран смерти и автоматически нажимает «Respawn».
 *
 * FIX v2: исправлен краш/чёрный экран при смерти игрока.
 *  - respawn() и setScreen(null) вызываются через mc.execute() (безопасно для render-треда)
 *  - Двойная проверка mc.player != null
 *  - Delay увеличен с 20 до 30 тиков — серверы медленнее регистрируют смерть
 *  - setScreen(null) вызывается отдельным execute() после respawn()
 */
public class AutoRespawn {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int  deathTimer = 0;
    private int  resetTimer = 0;
    private boolean wasDead = false;

    public void tick(Minecraft mc) {
        if (!cfg.autoRespawn) {
            deathTimer = 0;
            resetTimer = 0;
            wasDead    = false;
            return;
        }

        if (mc.screen instanceof DeathScreen) {
            resetTimer = 0;
            deathTimer++;

            // 30 тиков = 1.5 сек — ждём чтобы сервер подтвердил смерть
            if (deathTimer >= 30 && !wasDead) {
                wasDead = true;
                doRespawn(mc);
            }
        } else {
            if (wasDead) {
                resetTimer++;
                if (resetTimer >= 10) {
                    wasDead    = false;
                    deathTimer = 0;
                    resetTimer = 0;
                }
            } else {
                deathTimer = 0;
                resetTimer = 0;
            }
        }
    }

    /**
     * FIX: respawn() и setScreen() через mc.execute() — не блокируем render-тред.
     * setScreen(null) вызывается вторым execute() ПОСЛЕ respawn(), давая серверу
     * время ответить — это устраняет чёрный экран и краш.
     */
    private void doRespawn(Minecraft mc) {
        mc.execute(() -> {
            if (mc.player == null) return;
            try {
                mc.player.respawn();
            } catch (Exception ignored) {
                // Пакет уже был отправлен — игнорируем
            }
            // Закрываем экран смерти следующим execute (после обработки respawn-пакета)
            mc.execute(() -> {
                if (mc.screen instanceof DeathScreen) {
                    mc.setScreen(null);
                }
                if (mc.player != null && mc.gui != null) {
                    mc.gui.getChat().addMessage(
                        Component.literal("§a[PVPBot] §fАвто-респавн!")
                    );
                }
            });
        });
    }
}
