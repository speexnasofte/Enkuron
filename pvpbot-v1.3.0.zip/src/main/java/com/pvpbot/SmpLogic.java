package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;

/**
 * SmpLogic v4.0 — MCTiers SMP.
 *
 * Kit: Netherite полная броня (Sharp5+KB1+FA2 меч, топор Sharp5+Eff5)
 *   Эндер жемчуг 16, Golden Apple 64
 *   Зелья: Strength II, Speed II, FireResistance(long)
 *   Тотем offhand, щит Mend+Unb3
 *
 * Тактика:
 *  - Strength II + Speed II в начале боя
 *  - Огнестойкость при горении
 *  - Эндер жемчуг для телепорта при dist > 10
 *  - Golden Apple при низком HP + отступление
 *  - Щит при высоком входящем уроне
 *  - Топор для слома щита, меч для DPS
 *  - Fire Aspect поджигает цель
 *  - Крит-прыжки каждые N ударов
 */
public class SmpLogic {

    private static final double MELEE_RANGE  = 3.0;
    private static final double AXE_RANGE    = 3.5;
    private static final double PEARL_RANGE  = 10.0;
    private static final float  GAP_HP       = 12.0f;
    private static final float  SHIELD_HP    = 14.0f;
    private static final float  RETREAT_HP   = 5.0f;
    private static final int    ATTACK_CD    = 10;
    private static final int    AXE_CD       = 22;
    private static final int    SHIELD_DUR   = 25;
    private static final int    GAP_CD       = 220;
    private static final int    PEARL_CD     = 80;
    private static final int    SPEED_CD     = 400;
    private static final int    STR_CD       = 400;
    private static final int    FIRE_RES_CD  = 600;
    private static final int    RETREAT_CD   = 120;
    private static final int    CRIT_EVERY   = 4;

    private enum State { FIGHTING, BLOCKING, RETREATING }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd    = 0;
    private int axeCd       = 0;
    private int shieldTimer = 0;
    private int gapCd       = 0;
    private int pearlCd     = 0;
    private int speedCd     = 0;
    private int strCd       = 0;
    private int fireResCd   = 0;
    private int retreatCd   = 0;
    private int hitCount    = 0;
    private boolean critPending    = false;
    private boolean shieldDisabled = false;
    private int shieldDisTimer = 0;

    public SmpLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        if (attackCd    > 0) attackCd--;
        if (axeCd       > 0) axeCd--;
        if (shieldTimer > 0) shieldTimer--;
        if (gapCd       > 0) gapCd--;
        if (pearlCd     > 0) pearlCd--;
        if (speedCd     > 0) speedCd--;
        if (strCd       > 0) strCd--;
        if (fireResCd   > 0) fireResCd--;
        if (retreatCd   > 0) retreatCd--;
        if (shieldDisTimer > 0) { shieldDisTimer--; if (shieldDisTimer <= 0) shieldDisabled = false; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Баффы ─────────────────────────────────────────────────
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1));
            strCd = STR_CD;
        }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }

        // ── Тотем в оффхенд всегда ────────────────────────────────
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // ── Эндер жемчуг для сближения ───────────────────────────
        if (dist > PEARL_RANGE && pearlCd <= 0) {
            Vec3 tPos = target.position();
            bot.moveTo(tPos.x, tPos.y, tPos.z);
            sw.sendParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
            return;
        }

        // ── Золотое яблоко при низком HP ──────────────────────────
        if (myHp < GAP_HP && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
        }

        // ── Переходы состояний ────────────────────────────────────
        if (myHp < RETREAT_HP && retreatCd <= 0) {
            state = State.RETREATING; retreatCd = RETREAT_CD;
        }
        if (myHp < SHIELD_HP && shieldTimer <= 0 && state == State.FIGHTING) {
            state = State.BLOCKING; shieldTimer = SHIELD_DUR;
        }
        if (state == State.BLOCKING && shieldTimer <= 0) state = State.FIGHTING;
        if (state == State.RETREATING && dist > 9.0) state = State.FIGHTING;

        switch (state) {
            case FIGHTING   -> tickFighting(sw, target, dist);
            case BLOCKING   -> tickBlocking(target);
            case RETREATING -> tickRetreating(target);
            default -> {}
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        // Навигация
        if (dist > 2.6) bot.getNavigation().moveTo(target, 1.0);
        else bot.getNavigation().stop();
        strafe.tick(target);

        bot.getLookControl().setLookAt(target, 30f, 30f);

        boolean blocking = isTargetBlocking(target);

        // ── Топор ломает щит ──────────────────────────────────────
        if (blocking && dist <= AXE_RANGE && axeCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_AXE));
            if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
            shieldDisabled = true; shieldDisTimer = 100;
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
            axeCd = AXE_CD;
            return;
        }

        // ── Меч DPS ───────────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doSwordHit(sw, target, true); critPending = false;
            } else if (!doCrit) {
                doSwordHit(sw, target, false); critPending = false;
            }
        }
    }

    private void tickBlocking(LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
        if (bot.distanceTo(target) < 2.5) {
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.1);
            Vec3 cur  = bot.getDeltaMovement();
            bot.setDeltaMovement(cur.x + away.x, cur.y, cur.z + away.z);
        }
        if (shieldTimer <= 0)
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private void tickRetreating(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 9, bot.getY(), bot.getZ() + away.z * 9, 1.2
        );
        bot.setSprinting(true);
    }

    private void doSwordHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 6, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }
}
