package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;

/**
 * BotKit — система китов для PVP-бота.
 * Киты соответствуют стандартным раскладкам MCTiers (mctiers.com).
 *
 * FIX v2: все предметы теперь выдаются с правильными зачарованиями
 * (Protection IV, Sharpness V, Unbreaking III и т.д.) через EnchantUtil.
 *
 * Доступные киты:
 *   SWORD    — Diamond Prot4, Diamond меч (Unbreaking3), без оффхенда — Sword PvP
 *   AXE      — Diamond без зачар, Diamond топор mainhand + щит offhand — Axe PvP
 *   MACE     — Netherite Prot4, Mace mainhand, тотем offhand, элитры нагрудник — Mace PvP
 *   UHC      — Diamond Prot3/Prot2, меч Sharp3, лук offhand — UHC
 *   NETHOP   — Netherite Prot4+Mending, меч Sharp5, тотем offhand — NethOP
 *   POT      — Diamond Prot4, Diamond меч Sharp5, сплэш-зелье offhand — Diamond Pot
 *   SMP      — Netherite полный, меч Sharp5+KB1+FA2, тотем offhand — SMP
 *   CRYSTAL  — Netherite BlastProt4 на ногах/ботах, меч KB1+Sharp5, тотем — Crystal PvP
 *
 * Использование: /bot kit <название>
 */
public enum BotKit {

    // ── Sword PvP (MCTiers) ───────────────────────────────────────
    SWORD("sword", "Sword PvP — алмазная броня Prot4, меч Unb3 (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,    null,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "pvp"
    ),

    // ── Axe PvP (MCTiers) ────────────────────────────────────────
    // Броня без зачарований — MCTiers Axe кит стандарт
    AXE("axe", "Axe PvP — алмазная броня без зачар, топор + щит (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_AXE,      Items.SHIELD,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.AXE_PLAIN   // без зачарований на броне (MCTiers стандарт)
        ),
        "axe"
    ),

    // ── Mace PvP (MCTiers 1.21+) ─────────────────────────────────
    MACE("mace", "Mace PvP — нетерит Prot4, булава Breach4/Density5, тотем (MCTiers)",
        new KitEquipment(
            Items.MACE,                Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4
        ),
        "pvp"
    ),

    // ── UHC (MCTiers) ─────────────────────────────────────────────
    UHC("uhc", "UHC — алмаз Prot3/Prot2, меч Sharp3, голд яблоки, арбалет (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,    Items.BOW,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.UHC_ARMOR
        ),
        "uhc"
    ),

    // ── Netherite OP / NethOP (MCTiers) ───────────────────────────
    NETHOP("nethop", "NethOP — нетерит Prot4+Mending, меч Sharp5, зелья, тотем (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,     Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4_MENDING
        ),
        "nethpot"
    ),

    // ── Diamond Pot / Pot (MCTiers) ────────────────────────────────
    POT("pot", "Diamond Pot — алмаз Prot4, меч Sharp5+Sweep3, зелья хила (MCTiers)",
        new KitEquipment(
            Items.DIAMOND_SWORD,    Items.SPLASH_POTION,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "nethpot"
    ),

    // ── SMP (MCTiers) ─────────────────────────────────────────────
    SMP("smp", "SMP — нетерит полный, меч Sharp5+KB1+FA2, жемчуг, тотем (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,     Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.SMP_FULL
        ),
        "smp"
    ),

    // ── Mace + Elytra ─────────────────────────────────────────────
    MACE_ELYTRA("mace_elytra", "Mace+Elytra — пике с элитр, Wind Charge, булава-смэш",
        new KitEquipment(
            Items.MACE,               Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,   Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4
        ),
        "pvp"
    ),

    // ── Crystal PvP (MCTiers) ─────────────────────────────────────
    CRYSTAL("crystal", "Crystal PvP — нетерит BlastProt4 ноги/боты, кристаллы, тотемы (MCTiers)",
        new KitEquipment(
            Items.NETHERITE_SWORD,     Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.CRYSTAL_ARMOR
        ),
        "crystal"
    ),

    // ── Алиасы ───────────────────────────────────────────────────
    NETHPOT("nethpot", "NethPot — нетерит, зелья хила (алиас NETHOP)",
        new KitEquipment(
            Items.NETHERITE_SWORD,     Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4_MENDING
        ),
        "nethpot"
    ),

    TPC("tpc", "TPC — топор + кристалл + тотем",
        new KitEquipment(
            Items.NETHERITE_AXE,       Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,    Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,  Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4
        ),
        "tpc"
    ),

    SNOWBALL("snowball", "Snowball — снежки",
        new KitEquipment(
            Items.SNOWBALL, Items.SHIELD,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "snowball"
    ),

    BEEHIVE("beehive", "Beehive — улей/пчёлы",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.SHIELD,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "pvp"
    ),

    FIREWORK("firework", "Firework — фейерверки + элитры",
        new KitEquipment(
            Items.FIREWORK_ROCKET,  Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4
        ),
        "pvp"
    ),

    CROSSBOW("crossbow", "Crossbow — арбалет PvP",
        new KitEquipment(
            Items.CROSSBOW, Items.SHIELD,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "pvp"
    ),

    TRIDENT("trident", "Trident — трезубец PvP",
        new KitEquipment(
            Items.TRIDENT, Items.SHIELD,
            Items.DIAMOND_HELMET,   Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            KitEnchant.SWORD_PROT4
        ),
        "pvp"
    ),

    TOTEM("totem", "Totem — тотем + меч",
        new KitEquipment(
            Items.NETHERITE_SWORD,    Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,   Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            KitEnchant.NETHERITE_PROT4
        ),
        "pvp"
    );


    // ─────────────────────────────────────────────────────────────
    public final String id;
    public final String displayName;
    public final KitEquipment equipment;
    public final String profileName;

    BotKit(String id, String displayName, KitEquipment equipment, String profileName) {
        this.id          = id;
        this.displayName = displayName;
        this.equipment   = equipment;
        this.profileName = profileName;
    }

    public static BotKit byId(String id) {
        for (BotKit kit : values()) {
            if (kit.id.equalsIgnoreCase(id)) return kit;
        }
        return null;
    }

    public static String listIds() {
        StringBuilder sb = new StringBuilder();
        for (BotKit kit : values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(kit.id);
        }
        return sb.toString();
    }

    // ── Профили зачарований для китов ─────────────────────────────
    /**
     * KitEnchant — интерфейс для применения зачарований к снаряжению кита.
     * Каждый профиль знает какие зачарования класть на что.
     */
    public interface KitEnchant {

        void apply(BotEntity bot, Item mainhand, Item offhand,
                   Item helmet, Item chestplate, Item leggings, Item boots);

        // ── Diamond Prot4 (Sword/Pot/Crossbow/Snowball кит) ──────
        KitEnchant SWORD_PROT4 = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 5).enchant("unbreaking", 3).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 4).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(chest).enchant("protection", 4).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("protection", 4).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("protection", 4).enchant("unbreaking", 3).enchant("feather_falling", 4).build());
        };

        // ── Axe PvP — броня без зачарований (MCTiers стандарт) ───
        KitEnchant AXE_PLAIN = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 5).enchant("unbreaking", 3).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            // Броня без зачарований — MCTiers Axe кит
            bot.setItemSlot(EquipmentSlot.HEAD,    new ItemStack(hel));
            bot.setItemSlot(EquipmentSlot.CHEST,   new ItemStack(chest));
            bot.setItemSlot(EquipmentSlot.LEGS,    new ItemStack(legs));
            bot.setItemSlot(EquipmentSlot.FEET,    new ItemStack(bts));
        };

        // ── UHC — Prot3 шлем/боты, Prot2 нагрудник/поножи ───────
        KitEnchant UHC_ARMOR = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 3).enchant("unbreaking", 3).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 3).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(chest).enchant("protection", 2).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("protection", 2).enchant("unbreaking", 3).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("protection", 3).enchant("unbreaking", 3).build());
        };

        // ── Netherite Prot4 (Mace/TPC/MACE_ELYTRA) ──────────────
        KitEnchant NETHERITE_PROT4 = (bot, main, off, hel, chest, legs, bts) -> {
            // Мэйнхенд зависит от предмета
            if (main == Items.MACE) {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main).enchant("density", 5).enchant("breach", 4).build());
            } else if (main == Items.NETHERITE_AXE) {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main).enchant("sharpness", 5).enchant("efficiency", 5).enchant("unbreaking", 3).build());
            } else {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main).enchant("sharpness", 5).enchant("unbreaking", 3).build());
            }
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            // Нагрудник: если элитры — без зачарований кроме unbreaking
            if (chest == Items.ELYTRA) {
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest).enchant("unbreaking", 3).enchant("mending", 1).build());
            } else {
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            }
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("feather_falling", 4).enchant("mending", 1).build());
        };

        // ── Netherite Prot4 + Mending (NethOP/NETHPOT) ───────────
        KitEnchant NETHERITE_PROT4_MENDING = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 5).enchant("sweeping_edge", 3)
                    .enchant("unbreaking", 3).enchant("mending", 1).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("mending", 1).enchant("aqua_affinity", 1).build());
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(chest).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("feather_falling", 4).enchant("mending", 1).build());
        };

        // ── SMP — полный нетерит со всеми зачарованиями ──────────
        KitEnchant SMP_FULL = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 5).enchant("knockback", 1)
                    .enchant("sweeping_edge", 3).enchant("fire_aspect", 2)
                    .enchant("unbreaking", 3).enchant("mending", 1).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("mending", 1).enchant("respiration", 3).enchant("aqua_affinity", 1).build());
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(chest).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("mending", 1).enchant("swift_sneak", 3).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("protection", 4).enchant("unbreaking", 3)
                    .enchant("feather_falling", 4).enchant("mending", 1)
                    .enchant("depth_strider", 3).enchant("soul_speed", 3).build());
        };

        // ── Crystal PvP — BlastProt4 на ногах и ботах ────────────
        KitEnchant CRYSTAL_ARMOR = (bot, main, off, hel, chest, legs, bts) -> {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(main).enchant("sharpness", 5).enchant("knockback", 1)
                    .enchant("sweeping_edge", 3).enchant("unbreaking", 3).enchant("mending", 1).build());
            if (off != null)
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
            bot.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(hel).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.CHEST,
                EnchantUtil.of(chest).enchant("protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            // Ноги и боты — blast protection вместо protection (Crystal PvP стандарт)
            bot.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(legs).enchant("blast_protection", 4).enchant("unbreaking", 3).enchant("mending", 1).build());
            bot.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(bts).enchant("blast_protection", 4).enchant("unbreaking", 3)
                    .enchant("feather_falling", 4).enchant("mending", 1).build());
        };
    }

    // ── Снаряжение кита ──────────────────────────────────────────
    public static class KitEquipment {
        public final Item mainhand;
        public final Item offhand;
        public final Item helmet;
        public final Item chestplate;
        public final Item leggings;
        public final Item boots;
        private final KitEnchant enchantProfile;

        public KitEquipment(Item mainhand, Item offhand,
                            Item helmet, Item chestplate,
                            Item leggings, Item boots,
                            KitEnchant enchantProfile) {
            this.mainhand       = mainhand;
            this.offhand        = offhand;
            this.helmet         = helmet;
            this.chestplate     = chestplate;
            this.leggings       = leggings;
            this.boots          = boots;
            this.enchantProfile = enchantProfile;
        }

        /** Применить снаряжение с зачарованиями к боту. */
        public void applyTo(BotEntity bot) {
            enchantProfile.apply(bot, mainhand, offhand, helmet, chestplate, leggings, boots);
        }
    }
}
