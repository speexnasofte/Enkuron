package com.pvpbot;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * NPC-бот: PathfinderMob с AI-целями.
 * v7: интеграция BotDifficultyAI — EASY/MEDIUM/HARD/EXPERT поведение.
 */
public class BotEntity extends PathfinderMob {

    // ── Глобальная заморозка (во время отсчёта дуэли) ────────────
    private static boolean globalFrozen = false;
    public static void setGlobalFrozen(boolean frozen) { globalFrozen = frozen; }
    public static boolean isGlobalFrozen() { return globalFrozen; }

    // ── AI Throttling — распределяем тики между ботами ────────────
    // Каждый бот тикает полную логику раз в aiTickInterval тиков.
    // Остальные тики — только физика и анимация (super.tick).
    // При <= 5 ботов: interval=1 (каждый тик), 6-15: interval=2, 16+: interval=3
    private static int  botCount       = 0;
    private static int  globalTickSeed = 0; // счётчик для распределения фаз
    private int         myTickPhase    = 0; // фаза этого бота (0..interval-1)
    private int         aiTickInterval = 1;
    private int         aiSkipCounter  = 0;

    // Слабые ссылки на живые ботов — для глобального пересчёта интервала
    private static final java.util.Set<java.lang.ref.WeakReference<BotEntity>> allBotRefs =
        java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    public static void onBotSpawned()  { botCount++; recalcIntervals(); }
    public static void onBotRemoved()  { botCount = Math.max(0, botCount-1); recalcIntervals(); }
    public static int  getBotCount()   { return botCount; }

    private static void recalcIntervals() {
        // Вычисляем новый интервал по текущему числу ботов
        boolean opt = PVPBotConfig.INSTANCE.optimizeMode;
        int newInterval;
        if      (botCount <= 5)  newInterval = opt ? 2 : 1;
        else if (botCount <= 10) newInterval = opt ? 4 : 2;
        else if (botCount <= 18) newInterval = opt ? 6 : 3;
        else                     newInterval = opt ? 8 : 4;

        // Применяем ко всем живым ботам немедленно, убираем мёртвые ссылки
        allBotRefs.removeIf(ref -> {
            BotEntity b = ref.get();
            if (b == null || b.isRemoved()) return true;
            b.aiTickInterval = newInterval;
            return false;
        });
    }

    /** Регистрирует бота в глобальном реестре при создании. */
    private void registerSelf() {
        allBotRefs.add(new java.lang.ref.WeakReference<>(this));
    }

    private int calcInterval() {
        // OptimizeMode — удваиваем интервал для снижения нагрузки
        boolean opt = PVPBotConfig.INSTANCE.optimizeMode;
        if (botCount <= 5)  return opt ? 2 : 1;   // ≤5  ботов
        if (botCount <= 10) return opt ? 4 : 2;   // ≤10 ботов
        if (botCount <= 18) return opt ? 6 : 3;   // ≤18 ботов
        return opt ? 8 : 4;                        // 19-25 ботов
    }


    private UUID ownerUUID = null;

    // v9: ник игрока чей скин носит бот (null = дефолт)
    private String skinNick = null;

    public enum BotMode { GUARD, AGGRESSIVE, PASSIVE }
    private BotMode mode = BotMode.GUARD;

    // ── Роль в отряде (назначается SquadManager при squad >= 20) ──
    private BotRole squadRole = BotRole.SOLDIER;

    public BotRole getSquadRole() { return squadRole; }
    public void setSquadRole(BotRole role) { this.squadRole = role; }

    // v7.0 — кулдауны ролей
    public int bowCooldown      = 0;  // SNIPER: тиков до выстрела
    public int sapperCooldown   = 0;  // SAPPER: тиков до закладки
    public int scoutReportTimer = 0;  // SCOUT: тиков до репорта
    public int medicHealCooldown = 0; // MEDIC: тиков до лечения
    public int medicBuffCooldown = MedicLogic.BUFF_INTERVAL; // MEDIC: тиков до глоб. баффа (стартует полным)

    private int  nameUpdateTimer = 0;
    private int  strafeDirTimer  = 0;
    private boolean strafeLeft   = true;

    // ── v7: AI сложности ──────────────────────────────────────────
    private final BotDifficultyAI difficultyAI = new BotDifficultyAI(this);

    // ── v12: новые системы ────────────────────────────────────────
    private final StrafeAI      strafeAI      = new StrafeAI(this);
    private final PatternAI     patternAI     = new PatternAI(this);   // v14
    private final TargetPriority targetPriority = new TargetPriority(this);
    private final AutoRetreat   autoRetreat   = new AutoRetreat(this);

    /** Текущий кит бота. Сохраняется при ресете/ресрауне. */
    private BotKit currentKit = null;

    public BotKit getCurrentKit() { return currentKit; }
    public void setKit(BotKit kit) {
        this.currentKit = kit;
        if (kit != null) {
            kit.equipment.applyTo(this);
            // v1.3: синхронизируем конфиг чтобы NethPotLogic и другие логики видели кит
            PVPBotConfig.INSTANCE.currentKit = kit;
            // v1.3: автоматически выставляем режим под кит
            try {
                PVPBotConfig.Mode m = PVPBotConfig.Mode.valueOf(kit.id.toUpperCase());
                PVPBotConfig.INSTANCE.mode = m;
            } catch (IllegalArgumentException ignored) {
                // Нет точного совпадения — оставляем текущий режим
            }
        }
    }

    // ── v14: ComboBreaker + BotNotifier ──────────────────────────
    private final ComboBreaker  comboBreaker  = new ComboBreaker(this);
    private final BotNotifier   notifier      = BotNotifier.create(this);

    // ── v15: BotBunker ────────────────────────────────────────────
    private final BotBunker     bunker        = new BotBunker(this);

    // ── v17: StuckDetector + Squad ────────────────────────────────
    private final StuckDetector    stuckDetector    = new StuckDetector(this);
    public StuckDetector getStuckDetector() { return stuckDetector; }

    // ── v16: AdaptiveCooldown + FakeAttack + BotHunt + BotReplay ─
    private final AdaptiveCooldown adaptiveCooldown = new AdaptiveCooldown(this);
    // ── Kite logic (серверная) ────────────────────────────────────
    private final BotKiteLogic     botKiteLogic     = new BotKiteLogic(this);
    // ── v1.2: PVPBotLogic переписан для NPC ──────────────────────
    private final PVPBotLogic          pvpLogic         = new PVPBotLogic(this);
    private final ModeLogicDispatcher  modeDispatcher   = new ModeLogicDispatcher(this); // v1.3: fix kit logic
    private final FakeAttack           fakeAttack       = new FakeAttack(this);
    private final BotHunt          botHunt          = new BotHunt(this);
    private final BotReplay        replay           = new BotReplay(this);

    public StrafeAI      getStrafeAI()      { return strafeAI; }
    public PatternAI     getPatternAI()     { return patternAI; }   // v14
    public TargetPriority getTargetPriority() { return targetPriority; }
    public AutoRetreat   getAutoRetreat()   { return autoRetreat; }
    public ComboBreaker  getComboBreaker()  { return comboBreaker; }  // v14
    public BotNotifier   getNotifier()      { return notifier; }      // v14
    public BotBunker     getBunker()        { return bunker; }        // v15
    public AdaptiveCooldown getAdaptiveCooldown() { return adaptiveCooldown; } // v16
    public BotKiteLogic    getBotKiteLogic()      { return botKiteLogic; }
    public PVPBotLogic     getPvpLogic()        { return pvpLogic; }         // v1.2
    public ModeLogicDispatcher getModeDispatcher() { return modeDispatcher; } // v1.3
    public FakeAttack    getFakeAttack()    { return fakeAttack; }    // v16
    public BotHunt       getBotHunt()       { return botHunt; }       // v16
    public BotReplay     getReplay()        { return replay; }        // v16

    public BotEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
        this.setCanPickUpLoot(false);
        this.setPersistenceRequired();
        registerSelf(); // регистрируем в глобальном реестре для recalcIntervals()
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH,          40.0)
            .add(Attributes.MOVEMENT_SPEED,       0.13)
            .add(Attributes.ATTACK_DAMAGE,        1.0)
            .add(Attributes.FOLLOW_RANGE,        24.0)
            .add(Attributes.ARMOR,                0.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 0.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new BotHealGoal(this));
        goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.FloatGoal(this));
        goalSelector.addGoal(2, new BotCritMeleeGoal(this, 1.2, true));
        if (PVPBotConfig.INSTANCE.advPathfind) {
            goalSelector.addGoal(3, new BotPathfindGoal(this, 1.1, 64.0f, 3.0f));
        } else {
            goalSelector.addGoal(3, new BotFollowOwnerGoal(this, 1.1, 10.0f, 3.0f));
        }
        goalSelector.addGoal(4, new net.minecraft.world.entity.ai.goal.RandomStrollGoal(this, 0.8));
        goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(6, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new BotRevengeGoal(this));
        targetSelector.addGoal(2, new BotAttackHostilesGoal(this));
        targetSelector.addGoal(3, new BotAttackPlayersGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        // ── Заморозка во время отсчёта дуэли ─────────────────────
        if (globalFrozen) {
            getNavigation().stop();
            setDeltaMovement(0, getDeltaMovement().y, 0);
            return;
        }
        if (!level().isClientSide) {
            // ── AI Throttling ─────────────────────────────────────
            // Обновляем интервал раз в 40 тиков (при изменении числа ботов)
            if (tickCount % 40 == 0) {
                aiTickInterval = calcInterval();
                if (myTickPhase >= aiTickInterval) myTickPhase = tickCount % aiTickInterval;
            }
            // Пропускаем AI если сейчас не наш тик
            aiSkipCounter++;
            if (aiSkipCounter % aiTickInterval != myTickPhase) {
                // Только базовая физика — навигация продолжает двигать бота
                // по уже вычисленному пути, без пересчёта
                return;
            }

            // ── Обновление имени ──────────────────────────────────
            nameUpdateTimer--;
            if (nameUpdateTimer <= 0) {
                nameUpdateTimer = 20;
                updateNameTag();
                // Синхронизируем скорость и HP с настройками
                applySpeedAttribute();
                applyMaxHealth();
            }

            // ── v14: Тик уведомлений ──────────────────────────────
            notifier.tick();

            // ── v16: AdaptiveCooldown + Replay ────────────────────
            if (PVPBotConfig.INSTANCE.adaptiveCooldownEnabled) adaptiveCooldown.tick();
            // ── v17: StuckDetector + SmartFlank + Squad ───────────
            stuckDetector.tick();
            // ── v8: TeleportStuck ─────────────────────────────────
            if (TeleportStuck.INSTANCE.tick(this)) return; // застрял — телепортирован
            // ── v8: AutoChatTaunts тик кулдауна ──────────────────
            AutoChatTaunts.INSTANCE.tick();
            SmartFlank.INSTANCE.tick(this);
            // OPT v8: GappleOptimizer.globalTick() перенесён в ServerTickEvents (PVPBotMod)
            // ── Роль: тик специализированной логики ───────────────
            SquadManager.Squad roleSquad = SquadManager.INSTANCE.getSquadOf(this);
            switch (squadRole) {
                case MEDIC -> {
                    LivingEntity nearestForMedic = getTarget();
                    MedicLogic.INSTANCE.tick(this, roleSquad, nearestForMedic);
                }
                case SNIPER -> SniperLogic.INSTANCE.tick(this, getTarget());
                case SAPPER -> SapperLogic.INSTANCE.tick(this, getTarget());
                case SCOUT  -> {
                    Player scoutOwner = getOwner();
                    if (scoutOwner != null) ScoutLogic.INSTANCE.tick(this, scoutOwner);
                }
                default -> {} // SOLDIER, TANKER и т.д. — стандартный AI
            }
            // Squad Commander AI
            SquadManager.Squad mySquad = SquadManager.INSTANCE.getSquadOf(this);
            if (mySquad != null && this == mySquad.commander) {
                Player owner = getOwner();
                if (owner != null) SquadManager.INSTANCE.tickCommander(this, mySquad, owner);
            }

            replay.tick();

            // ── v16: BotHunt — охота на игроков ───────────────────
            if (PVPBotConfig.INSTANCE.huntEnabled && getTarget() == null) {
                botHunt.tick();
            }

            // ── v15: Pending co-owner add (из WebConfig) ──────────
            if (PVPBotConfig.INSTANCE.pendingCoOwnerAdd != null
                    && PVPBotConfig.INSTANCE.globalOwnerUUID != null
                    && level() instanceof net.minecraft.server.level.ServerLevel sw15) {
                net.minecraft.server.MinecraftServer ms = sw15.getServer();
                boolean added = MultiOwner.INSTANCE.addCoOwner(
                    PVPBotConfig.INSTANCE.globalOwnerUUID,
                    PVPBotConfig.INSTANCE.pendingCoOwnerAdd, ms);
                notifier.send(added
                    ? "§a✔ Совладелец добавлен: §f" + PVPBotConfig.INSTANCE.pendingCoOwnerAdd
                    : "§c✘ Игрок не найден: §f"    + PVPBotConfig.INSTANCE.pendingCoOwnerAdd);
                PVPBotConfig.INSTANCE.pendingCoOwnerAdd = null;
            }

            // ── v15: BotBunker ────────────────────────────────────
            if (PVPBotConfig.INSTANCE.bunkerEnabled && bunker.tick()) return;

            // ── v1.3: Standby режим — стоим в ряд до /bot attack ────
            if (PVPBotConfig.INSTANCE.standbyMode) {
                // В режиме ожидания: сбрасываем цель и стоим в построении
                if (getTarget() != null) setTarget(null);
                // Идём на позицию в построении
                Player owner = getOwner();
                if (owner != null) {
                    var bots = SpawnBotCommand.getBotsFor((net.minecraft.server.level.ServerPlayer) owner);
                    int idx = bots.indexOf(this);
                    int total = bots.size();
                    if (idx >= 0) {
                        net.minecraft.world.phys.Vec3 formPos =
                            BotFormations.INSTANCE.getTargetPos(this, idx, total, owner);
                        if (position().distanceTo(formPos) > 1.5) {
                            getNavigation().moveTo(formPos.x, formPos.y, formPos.z, 1.0);
                        }
                    }
                }
                return; // не тикаем AI атаки
            }

            // ── v12: TargetPriority — умный выбор цели ───────────
            targetPriority.tick();

            // ── v14: PatternAI — обновление паттернов движения цели ──
            if (getTarget() != null && PVPBotConfig.INSTANCE.patternAIEnabled) {
                patternAI.update(getTarget());
            } else if (getTarget() == null) {
                patternAI.reset();
            }

            // ── v12: AutoRetreat ──────────────────────────────────
            boolean retreating = false;
            if (getTarget() != null) {
                retreating = autoRetreat.tick(getTarget());
            }

            // ── v12: Clone mode ───────────────────────────────────
            BotClone.INSTANCE.tick(this);

            // ── Страф + BotDifficultyAI во время боя ─────────────
            if (!retreating && getTarget() != null && getTarget().isAlive()) {
                // ThreatAssessment — обновить цель для всех режимов (не только HARD/EXPERT)
                if (PVPBotConfig.INSTANCE.threatAssessEnabled) {
                    LivingEntity bestThreat = difficultyAI.getThreatAssessment().tick();
                    if (bestThreat != null && bestThreat != getTarget()) {
                        setTarget(bestThreat);
                    }
                }

                // v14: ComboBreaker — если под комбо, прерываем атаку
                if (comboBreaker.tick(getTarget())) return;

                // v16: FakeAttack тик (если активен — блокирует атаку на PAUSE_TICKS)
                if (fakeAttack.tick(getTarget())) return;

                // v12: продвинутый StrafeAI вместо простого стрейфа
                if (PVPBotConfig.INSTANCE.strafeEnabled) {
                    strafeAI.setStyle(PVPBotConfig.INSTANCE.strafeStyle);
                    strafeAI.tick(getTarget());
                }

                // ── v14: TrainingMode ────────────────────────────────
                if (PVPBotConfig.INSTANCE.trainingMode) {
                    TrainingMode.INSTANCE.tick(this, getTarget());
                }

                // ── v7: тик BotDifficultyAI ───────────────────────
                difficultyAI.tick(getTarget());

                // ── v1.3: ModeLogicDispatcher — тикаем логику активного кита ──
                // Если у бота задан кит И включён правильный режим — используем
                // специализированную логику (SwordLogic, AxeLogic, MaceLogic и т.д.)
                // Иначе fallback на общий PVPBotLogic
                boolean kitHandled = false;
                if (currentKit != null && PVPBotConfig.INSTANCE.mode != null) {
                    kitHandled = modeDispatcher.tick(getTarget());
                }
                if (!kitHandled) {
                    // Нет кита или режим не совпадает — общий PVP AI
                    pvpLogic.tick();
                }

                // ── v12: синхроатака ──────────────────────────────
                // OPT v8: перенесено в ServerTickEvents в PVPBotMod,
                // чтобы не вызывать N раз при N ботах одного владельца.
            }
        }
    }

    // OPT v8: кэш последнего HP для имени — не пересобираем строку если HP не изменилось
    private int lastNameHp = -1;

    private void updateNameTag() {
        int hp    = (int) getHealth();
        int maxHp = (int) getMaxHealth();

        // OPT: пропускаем если HP не изменилось (экономим Component.literal + строковую конкатенацию)
        if (hp == lastNameHp) return;
        lastNameHp = hp;

        String modeStr = switch (mode) {
            case GUARD      -> "§a[GUARD]";
            case AGGRESSIVE -> "§c[AGRO]";
            case PASSIVE    -> "§7[PASS]";
            default     -> "?";
        };
        // v7: показываем уровень сложности в имени
        String diffStr = switch (PVPBotConfig.INSTANCE.difficulty) {
            case EASY   -> "§7[EASY]";
            case MEDIUM -> "§e[MED]";
            case HARD   -> "§c[HARD]";
            case EXPERT -> "§4§l[EXPERT]";
            default     -> "§7[?]";
        };
        String bar = buildHpBar(hp, maxHp);
        setCustomName(Component.literal("§ePVP-Bot " + modeStr + " " + diffStr + "  " + bar + " §f" + hp + "§7/" + maxHp));
        setCustomNameVisible(true);
    }

    private String buildHpBar(int hp, int max) {
        if (max == 0) return "";
        int filled = Math.min(8, (int)(8.0 * hp / max));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i == filled) sb.append("§c");
            else if (i == 0) sb.append("§a");
            sb.append(i < filled ? "█" : "░");
        }
        return sb.toString();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag nbt) {
        super.addAdditionalSaveData(nbt);
        if (ownerUUID != null) nbt.putUUID("OwnerUUID", ownerUUID);
        nbt.putString("BotMode", mode.name());
        // v7: сохраняем сложность в NBT
        nbt.putString("BotDifficulty", PVPBotConfig.INSTANCE.difficulty.name());
        // v9: сохраняем ник скина
        if (skinNick != null) nbt.putString("SkinNick", skinNick);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag nbt) {
        super.readAdditionalSaveData(nbt);
        if (nbt.hasUUID("OwnerUUID")) ownerUUID = nbt.getUUID("OwnerUUID");
        if (nbt.contains("BotMode")) {
            try { mode = BotMode.valueOf(nbt.getString("BotMode")); }
            catch (IllegalArgumentException ignored) { mode = BotMode.GUARD; }
        }
        // v7: восстанавливаем сложность из NBT и применяем
        // v9: восстанавливаем ник скина
        if (nbt.contains("SkinNick")) skinNick = nbt.getString("SkinNick");
        if (nbt.contains("BotDifficulty")) {
            try {
                PVPBotConfig.INSTANCE.difficulty =
                    PVPBotConfig.Difficulty.valueOf(nbt.getString("BotDifficulty"));
                PVPBotConfig.INSTANCE.applyDifficulty();
            } catch (IllegalArgumentException ignored) {}
        }
    }

    // ── API ───────────────────────────────────────────────────────
    public void setOwner(Player player) { this.ownerUUID = player.getUUID(); }
    public java.util.UUID getOwnerUUID() { return ownerUUID; }

    @Nullable
    public Player getOwner() {
        if (ownerUUID == null || !(level() instanceof ServerLevel sw)) return null;
        return sw.getPlayerByUUID(ownerUUID);
    }

    public BotMode getBotMode() { return mode; }

    // v9: скин
    public String getSkinNick() { return skinNick; }
    public void setSkinNick(String nick) { this.skinNick = nick; }

    public void setBotMode(BotMode m) {
        mode = m;
        setTarget(null);
        updateNameTag();
    }

    /** Применяет скорость движения из конфига сложности к атрибуту NPC. */
    public void applySpeedAttribute() {
        var speedAttr = this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.setBaseValue(PVPBotConfig.INSTANCE.diffMoveSpeed);
        }
    }

    public void applyMaxHealth() {
        var healthAttr = this.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
        if (healthAttr != null) {
            float newMax = Math.max(1f, PVPBotConfig.INSTANCE.botMaxHealth);
            healthAttr.setBaseValue(newMax);
            // Если текущее HP выше нового максимума — подрезаем
            if (this.getHealth() > newMax) this.setHealth(newMax);
        }
    }

    public void cycleMode() {
        mode = switch (mode) {
            case GUARD      -> BotMode.AGGRESSIVE;
            case AGGRESSIVE -> BotMode.PASSIVE;
            case PASSIVE    -> BotMode.GUARD;
            default     -> null;
        };
        setTarget(null);
        updateNameTag();
    }

    public boolean isAlliedToCustom(net.minecraft.world.entity.Entity other) {
        if (other instanceof Player p && ownerUUID != null && p.getUUID().equals(ownerUUID)) return true;
        return super.isAlliedTo(other);
    }

    // isAffectedByDaylight removed in 1.21.4

    // ── v10: AntiKnockback ────────────────────────────────────────
    @Override
    public void knockback(double strength, double x, double z) {
        if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK)) {
            super.knockback(strength, x, z);
        } else {
            AntiKnockback.apply(this, strength, x, z);
        }
    }

    @Override
    public boolean canPickUpLoot() { return false; }

    @Override
    protected void dropEquipment(net.minecraft.server.level.ServerLevel serverLevel) {}

    // ── v14: damage override для ComboBreaker + BotNotifier ──────
    // Кастомная логика урона вызывается через Fabric Event или hurt-overide
    // В 1.21.4 hurt() - final, используем другой подход
    public void onHurtCustom(DamageSource source, float amount) {
        comboBreaker.onDamageReceived(amount);
        // FightAnalyzer — трекинг полученного урона
        if (PVPBotConfig.INSTANCE.statsEnabled) {
            FightAnalyzer.INSTANCE.onDamageTaken(amount);
        }
        // Уведомление при низком HP
        float hp = getHealth();
        if (hp < 10.0f && hp > 0) {
            notifier.onLowHp();
            AutoChatTaunts.INSTANCE.onLowHp(this); // v8: чат-сообщение при низком HP
        }
        // Тотем-попап: HP упало до 1 или ниже и тотем в оффхенде
        if (hp <= 1.0f && PVPBotConfig.INSTANCE.statsEnabled) {
            var offhand = getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND);
            if (offhand.is(net.minecraft.world.item.Items.TOTEM_OF_UNDYING)) {
                FightAnalyzer.INSTANCE.onTotemPop();
            }
        }
    }

    @Override
    public void die(DamageSource damageSource) {
        super.die(damageSource);
        // Уведомление о смерти
        net.minecraft.world.entity.Entity killer = damageSource.getEntity();
        notifier.onDeath(killer instanceof LivingEntity le ? le : null);
        // v8: AutoChatTaunts — бот убил кого-то (это вызывается у ЖЕРТВЫ,
        // поэтому taunt при убийстве обрабатывается в KillDeathTracker)
    }
}
