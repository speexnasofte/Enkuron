package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;
import net.minecraft.client.DeltaTracker;

/**
 * PVPBotHud v9 — добавлено:
 *   ✅ Вкл/выкл HUD кнопкой [H]
 *   ✅ Drag-and-drop: зажать ЛКМ по панели → перетащить куда угодно
 *   ✅ Кнопка [⚡OPT] — включает OptimizeMode (отключает ESP/Blur, throttle AI)
 *   ✅ Кэш findNearest() в OptimizeMode (не ищем каждый кадр)
 *   ✅ Tooltip-подсказки при наведении на кнопки
 */
public class PVPBotHud implements HudRenderCallback {

    private final PVPBotConfig  cfg     = PVPBotConfig.INSTANCE;
    private final ModuleManager modules = ModuleManager.INSTANCE;

    // ── Drag state ──────────────────────────────────────────────
    private boolean dragging     = false;
    private int     dragOffsetX  = 0;
    private int     dragOffsetY  = 0;

    // Размеры панели (вычисляются при рендере)
    private int panelX  = 6;
    private int panelY  = 6;
    private static final int PANEL_W = 144;

    // ── Optimize cache ──────────────────────────────────────────
    private LivingEntity cachedTarget    = null;
    private int          cacheAge        = 0;
    private static final int CACHE_TTL   = 10; // тиков

    // ── Кнопки в шапке (координаты — относительные к panelX/Y) ─
    // [H] toggle HUD expand, [⚡] toggle optimize
    private static final int BTN_SIZE = 9;

    // ============================================================

    @Override
    public void onHudRender(GuiGraphics ctx, DeltaTracker ticker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // Разрешаем обрабатывать Mouse click/drag через статический
        // Mouse-листенер, зарегистрированный в PVPBotMod.
        // Здесь только рисуем.

        // Если HUD полностью скрыт — не рисуем ничего
        if (!cfg.showHud) {
            renderMiniToggle(ctx, mc);
            return;
        }

        // Позиция: если не задана пользователем — дефолт (6, 6)
        if (cfg.hudX < 0) cfg.hudX = 6;
        if (cfg.hudY < 0) cfg.hudY = 6;

        panelX = cfg.hudX;
        panelY = cfg.hudY;

        int x  = panelX + 2;
        int y  = panelY;
        int lh = 10;

        boolean isCrystal = cfg.mode == PVPBotConfig.Mode.CRYSTAL;

        // Высота панели
        int panelH = lh * 13 + 14;

        // ── Иконка и цвет полоски по китам mctiers.com ───────────
        String kitIconId;
        int topColor;
        switch (cfg.mode) {
            case UHC -> { kitIconId = "kit_uhc";     topColor = 0xFFCC2222; }
            case NETHOP, NETHPOT -> { kitIconId = "kit_nethop"; topColor = 0xFF9933CC; }
            case SMP  -> { kitIconId = "kit_smp";    topColor = 0xFF1A8040; }
            case POT  -> { kitIconId = "kit_pot";    topColor = 0xFFCC44BB; }
            case CRYSTAL -> { kitIconId = "kit_crystal"; topColor = 0xFF00CFFF; }
            case MACE, MACE_ELYTRA -> { kitIconId = "kit_mace"; topColor = 0xFF888888; }
            case AXE  -> { kitIconId = "kit_axe";    topColor = 0xFF4499CC; }
            case TPC  -> { kitIconId = "kit_tpc";    topColor = 0xFF00CFFF; }
            case TOTEM -> { kitIconId = "kit_uhc";   topColor = 0xFFCC2222; }
            case TRIDENT -> { kitIconId = "kit_trident"; topColor = 0xFF3388FF; }
            case CROSSBOW -> { kitIconId = "kit_crossbow"; topColor = 0xFF3388FF; }
            case SNOWBALL -> { kitIconId = "kit_snowball"; topColor = 0xFF88AACC; }
            default -> { kitIconId = "kit_sword";    topColor = 0xFF3388FF; }
        }
        String modeName = cfg.mode.name();

        // Фон + цветная полоска сверху
        ctx.fill(panelX - 1, panelY - 1, panelX + PANEL_W, panelY + panelH, 0x88000000);
        ctx.fill(panelX - 1, panelY - 1, panelX + PANEL_W, panelY + 1, topColor);

        // ── Заголовок: иконка PNG + название кита + профиль ──────
        com.pvpbot.gui.render.IconRenderer.draw(ctx, kitIconId, x, y, 9);
        String profile = "§8[" + modules.getActiveProfile() + "]";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§fPVPBot §7" + modeName + " " + profile),
            x + 11, y, 0xFFFFFF, true);

        // Кнопка [⚡] Optimize (справа в заголовке)
        int optBtnX = panelX + PANEL_W - BTN_SIZE - 2;
        int optBtnY = y;
        boolean optOn = cfg.optimizeMode;
        int optBg  = optOn ? 0xFF1A4020 : 0xFF2A2010;
        int optFg  = optOn ? 0xFF22EE66 : 0xFFCCAA00;
        ctx.fill(optBtnX - 1, optBtnY - 1, optBtnX + BTN_SIZE + 1, optBtnY + BTN_SIZE, optBg);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(optOn ? "§a⚡" : "§6⚡"),
            optBtnX, optBtnY, optFg, false);

        // Кнопка [✕] скрыть HUD (правее ⚡)
        int hideBtnX = optBtnX - BTN_SIZE - 3;
        int hideBtnY = y;
        ctx.fill(hideBtnX - 1, hideBtnY - 1, hideBtnX + BTN_SIZE + 1, hideBtnY + BTN_SIZE, 0xFF2A0A0A);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§c✕"),
            hideBtnX, hideBtnY, 0xFFEF4444, false);

        y += lh + 1;

        // ── Статус + число ботов + AI throttle ──────────────────
        String status = cfg.enabled ? "§aВКЛЮЧЁН" : "§cВЫКЛЮЧЕН";
        int bots = BotEntity.getBotCount();
        int throttleTick = cfg.optimizeMode
            ? (bots <= 5 ? 4 : bots <= 10 ? 6 : 8)
            : (bots <= 5 ? 1 : bots <= 10 ? 2 : bots <= 18 ? 3 : 4);
        String throttleInfo = (bots > 5 || cfg.optimizeMode)
            ? " §8[AI/" + throttleTick + "t]" : "";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(
                "§7Статус: " + status + " §8| §7Ботов: §f" + bots + "/" + cfg.maxBots + throttleInfo
            ), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Сложность ────────────────────────────────────────────
        String diff = switch (cfg.difficulty) {
            case EASY   -> "§a★☆☆☆ Лёгкая";
            case MEDIUM -> "§e★★☆☆ Средняя";
            case HARD   -> "§c★★★☆ Сложная";
            case EXPERT -> "§4★★★★ EXPERT";
            default     -> "?";
        };
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§7Сложность: " + diff), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Модули строка 1: Атк, Укл, Леч, Gap ─────────────────
        String atk  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ATTACK))  + "§7Атк ";
        String dge  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_DODGE))   + "§7Укл ";
        String heal = icon(modules.isEnabled(ModuleManager.MOD_AUTO_HEAL))    + "§7Леч ";
        String gap  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_GAP))     + "§7Gap";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(atk + dge + heal + gap), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 2: Броня, Тотем, Еда ──────────────────────────
        String armor  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ARMOR))  + "§7Броня ";
        String totem  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_TOTEM))  + "§7Тотем ";
        String eat    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_EAT))    + "§7Еда";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(armor + totem + eat), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 3: W-Tap, Спринт, ESP, Radar ─────────────────
        String wtap   = icon(modules.isEnabled(ModuleManager.MOD_W_TAP))       + "§7W-Tap ";
        String sprint = icon(modules.isEnabled(ModuleManager.MOD_AUTO_SPRINT)) + "§7Спр ";
        // В OptimizeMode ESP всегда выключен
        String espStr = cfg.optimizeMode
            ? "§c✘§7ESP "
            : icon(modules.isEnabled(ModuleManager.MOD_ESP)) + "§7ESP ";
        String radar  = icon(modules.isEnabled(ModuleManager.MOD_RADAR))       + "§7Radar";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(wtap + sprint + espStr + radar), x, y, 0xFFFFFF, true);
        y += lh;

        // ── Строка 4: Bow, Kite, Crystal, WL ────────────────────
        String bow    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_BOW))    + "§7Bow ";
        String kite   = icon(modules.isEnabled(ModuleManager.MOD_KITE))        + "§7Kite ";
        String crys   = isCrystal ? icon(modules.isEnabled(ModuleManager.MOD_CRYSTAL)) + "§7Крист " : "";
        String wl     = cfg.whitelistEnabled ? "§a[WL:" + cfg.whitelist.size() + "]" : "§8[WL]";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal(bow + kite + crys + wl), x, y, 0xFFFFFF, true);
        y += lh + 2;

        // Разделитель
        ctx.fill(x, y, x + 131, y + 1, 0x55FFFFFF);
        y += 4;

        // ── K/D статистика ───────────────────────────────────────
        if (cfg.statsEnabled) {
            double kd = KillDeathTracker.deaths == 0
                ? KillDeathTracker.kills
                : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(
                    "§aK:§f" + KillDeathTracker.kills +
                    " §cD:§f" + KillDeathTracker.deaths +
                    " §eA:§f" + KillDeathTracker.assists +
                    " §6KD:§f" + String.format("%.1f", kd)
                ), x, y, 0xFFFFFF, true);
            y += lh;
        }

        // ── Цель (с кэшем в OptimizeMode) ───────────────────────
        LivingEntity target = getTarget(mc);
        if (target != null) {
            double dist = mc.player.distanceTo(target);
            String name = target.getName().getString();
            if (name.length() > 13) name = name.substring(0, 13) + "…";
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§cЦель: §f" + name), x, y, 0xFFFFFF, true);
            y += lh;

            int hp    = (int) target.getHealth();
            int maxHp = (int) target.getMaxHealth();

            if (cfg.showDps) {
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal(DpsMeter.INSTANCE.getFormatted()
                        + "  §cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF, true);
            } else {
                ctx.drawString(mc.font,
                    net.minecraft.network.chat.Component.literal("§cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF, true);
            }
            y += lh;

            // HP-бар
            int barW  = 131;
            float ratio = (float) hp / maxHp;
            ctx.fill(x, y, x + barW, y + 3, 0xFF550000);
            ctx.fill(x, y, x + (int)(barW * ratio), y + 3,
                ratio > 0.5f ? 0xFF00CC44 : ratio > 0.25f ? 0xFFFFAA00 : 0xFFFF2222);
        } else {
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§7Цель: нет"), x, y, 0xFFFFFF, true);
            y += lh;
        }

        y += lh + 2;

        // ── Подсказка клавиш ─────────────────────────────────────
        String optHint = cfg.optimizeMode ? " §a[⚡OPT]" : "";
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§8[R] вкл  [G] настройки  [H] HUD" + optHint),
            x, y, 0x888888, true);

        // ── OPT индикатор (если включён) ────────────────────────
        if (cfg.optimizeMode) {
            ctx.fill(panelX - 1, panelY + panelH - 2, panelX + PANEL_W, panelY + panelH, 0xFF1A8040);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§a⚡ OPTIMIZE ON"),
                x, panelY + panelH - 10, 0xFF22EE66, false);
        }

        // ── Дуэль оверлей ────────────────────────────────────────
        renderDuelOverlay(ctx, mc);
    }

    /**
     * Маленькая кнопка [H] когда HUD скрыт — чтобы можно было вернуть.
     */
    private void renderMiniToggle(GuiGraphics ctx, Minecraft mc) {
        ctx.fill(2, 2, 26, 13, 0xAA000000);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§8[H]"),
            4, 4, 0x666666, false);
    }

    // ── Drag поддержка (вызывается из PVPBotMod) ────────────────

    /** Вызывается при нажатии ЛКМ. Возвращает true если попали по панели. */
    public boolean onMousePressed(double mx, double my) {
        if (!cfg.showHud) return false;
        if (insidePanel(mx, my)) {
            dragging    = true;
            dragOffsetX = (int) mx - panelX;
            dragOffsetY = (int) my - panelY;
            return true;
        }
        return false;
    }

    /** Вызывается при отпускании ЛКМ. */
    public void onMouseReleased(double mx, double my) {
        if (dragging) {
            dragging = false;
            BotConfig.save();
        }
        // Проверяем клик по кнопкам если не драг
        checkButtonClick(mx, my);
    }

    /** Вызывается при движении мыши с зажатой ЛКМ. */
    public void onMouseDragged(double mx, double my) {
        if (!dragging) return;
        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        int newX = (int) mx - dragOffsetX;
        int newY = (int) my - dragOffsetY;

        // Не даём улететь за границы экрана
        newX = Math.max(0, Math.min(newX, sw - PANEL_W));
        newY = Math.max(0, Math.min(newY, sh - 30));

        cfg.hudX = newX;
        cfg.hudY = newY;
    }

    /**
     * Клик по кнопкам [⚡] и [✕].
     */
    private void checkButtonClick(double mx, double my) {
        if (!cfg.showHud) {
            // Клик по мини-[H]
            if (mx >= 2 && mx <= 26 && my >= 2 && my <= 13) {
                cfg.showHud = true;
                BotConfig.save();
            }
            return;
        }

        int y0 = panelY;

        // Кнопка [⚡] Optimize
        int optBtnX = panelX + PANEL_W - BTN_SIZE - 2;
        if (mx >= optBtnX - 1 && mx <= optBtnX + BTN_SIZE + 1
                && my >= y0 - 1 && my <= y0 + BTN_SIZE) {
            cfg.optimizeMode = !cfg.optimizeMode;
            // Применяем оптимизации сразу
            if (cfg.optimizeMode) {
                cfg.espEnabled  = false;
            }
            BotConfig.save();
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.gui.getChat().addMessage(net.minecraft.network.chat.Component.literal(
                    cfg.optimizeMode
                        ? "§a[PVPBot] §fOptimize ON — ESP выключен, AI throttle x" + (cfg.maxBots <= 5 ? 4 : 6)
                        : "§e[PVPBot] §fOptimize OFF — настройки восстановлены"
                ));
            }
            return;
        }

        // Кнопка [✕] скрыть HUD
        int hideBtnX = optBtnX - BTN_SIZE - 3;
        if (mx >= hideBtnX - 1 && mx <= hideBtnX + BTN_SIZE + 1
                && my >= y0 - 1 && my <= y0 + BTN_SIZE) {
            cfg.showHud = false;
            BotConfig.save();
        }
    }

    private boolean insidePanel(double mx, double my) {
        return mx >= panelX - 1 && mx <= panelX + PANEL_W
            && my >= panelY - 1 && my <= panelY + 30; // только по шапке для drag
    }

    // ── Target cache (OptimizeMode) ──────────────────────────────

    private LivingEntity getTarget(Minecraft mc) {
        if (cfg.optimizeMode) {
            cacheAge++;
            if (cachedTarget == null || !cachedTarget.isAlive() || cacheAge >= CACHE_TTL) {
                cachedTarget = findNearest(mc);
                cacheAge     = 0;
            }
            return cachedTarget;
        }
        return findNearest(mc);
    }

    private LivingEntity findNearest(Minecraft mc) {
        if (mc.player == null || mc.level == null) return null;
        double range = cfg.optimizeMode ? 12.0 : 16.0;
        AABB box = mc.player.getBoundingBox().inflate(range);
        List<LivingEntity> list = mc.level.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != mc.player && e.isAlive() && !e.isInvisible()
        );
        return list.stream()
            .min(Comparator.comparingDouble(mc.player::distanceTo))
            .orElse(null);
    }

    private String icon(boolean on) { return on ? "§a✔" : "§c✘"; }

    // ══════════════════════════════════════════════════════════════
    //  Дуэль — оверлей в MCTiers стиле
    // ══════════════════════════════════════════════════════════════
    private void renderDuelOverlay(GuiGraphics ctx, Minecraft mc) {
        DuelTimer duel = DuelTimer.INSTANCE;
        if (!duel.isActive() && duel.getPhase() == DuelTimer.Phase.IDLE) return;

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        int cx = sw / 2;

        int botScore    = duel.getBotScore();
        int playerScore = duel.getPlayerScore();
        String scoreStr = botScore + " - " + playerScore;

        ctx.pose().pushPose();
        ctx.pose().scale(2.5f, 2.5f, 1f);
        int scoreW = mc.font.width(scoreStr);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§c" + botScore + " §f- §a" + playerScore),
            (int)((cx - scoreW * 2.5f / 2f) / 2.5f),
            (int)((sh * 0.12f) / 2.5f),
            0xFFFFFF, true);
        ctx.pose().popPose();

        String roundStr = "Round " + duel.getCurrentRound() + " / " + duel.getTotalRounds();
        int roundW = mc.font.width(roundStr);
        ctx.drawString(mc.font,
            net.minecraft.network.chat.Component.literal("§7" + roundStr),
            cx - roundW / 2,
            (int)(sh * 0.12f) + 22,
            0x888888, true);

        if (duel.isCountdown()) {
            int secs = duel.getCountdownSecs();
            String cd      = String.valueOf(secs);
            String cdColor = secs <= 1 ? "§c" : secs <= 2 ? "§e" : "§a";

            ctx.fill(0, 0, sw, sh, 0x55000000);

            ctx.pose().pushPose();
            ctx.pose().scale(5f, 5f, 1f);
            int cdW = mc.font.width(cd);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(cdColor + "§l" + cd),
                (int)((cx - cdW * 5f / 2f) / 5f),
                (int)((sh / 2f - 20f) / 5f),
                0xFFFFFF, true);
            ctx.pose().popPose();

            String rdLabel = "Round " + duel.getCurrentRound() + " / " + duel.getTotalRounds();
            int rdW = mc.font.width(rdLabel);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal("§f" + rdLabel),
                cx - rdW / 2, sh / 2 + 35, 0xFFFFFF, true);

            String scLabel = "§c" + botScore + " §7- §a" + playerScore;
            int scW = mc.font.width(scLabel);
            ctx.pose().pushPose();
            ctx.pose().scale(1.8f, 1.8f, 1f);
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(scLabel),
                (int)((cx - scW * 1.8f / 2f) / 1.8f),
                (int)((sh / 2f + 50f) / 1.8f),
                0xFFFFFF, true);
            ctx.pose().popPose();
        }

        if (duel.getPhase() == DuelTimer.Phase.FINISHED) {
            ctx.fill(0, 0, sw, sh, 0x88000000);

            boolean botWon = duel.getBotScore() > duel.getPlayerScore();
            boolean draw   = duel.getBotScore() == duel.getPlayerScore();

            String result     = draw ? "§e§lDRAW" : botWon ? "§c§lYOU LOSE" : "§a§lYOU WIN";
            String finalScore = "§c" + duel.getBotScore() + " §f- §a" + duel.getPlayerScore();

            ctx.pose().pushPose();
            ctx.pose().scale(3f, 3f, 1f);
            int rW = mc.font.width(result.replaceAll("§.", ""));
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(result),
                (int)((cx - rW * 3f / 2f) / 3f),
                (int)((sh / 2f - 25f) / 3f),
                0xFFFFFF, true);
            ctx.pose().popPose();

            ctx.pose().pushPose();
            ctx.pose().scale(2f, 2f, 1f);
            int fsW = mc.font.width(finalScore.replaceAll("§.", ""));
            ctx.drawString(mc.font,
                net.minecraft.network.chat.Component.literal(finalScore),
                (int)((cx - fsW * 2f / 2f) / 2f),
                (int)((sh / 2f + 15f) / 2f),
                0xFFFFFF, true);
            ctx.pose().popPose();
        }
    }
}
