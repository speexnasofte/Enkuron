package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.biome.Biome;

/**
 * TridentLogic — v14: режим TRIDENT.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ДВА СТИЛЯ В ОДНОМ РЕЖИМЕ:
 * ══════════════════════════════════════════════════════════════════
 *
 *  CHANNELING-стиль (цель мокрая / идёт дождь):
 *    - Кидает трезубец в цель
 *    - Автоматически вызывает молнию на мокрую цель (Channeling)
 *    - Урон: 8 (трезубец) + 5 (молния) = 13+, цель горит и слепнет
 *    - Cooldown: 40 тиков
 *
 *  RIPTIDE-стиль (бот сам мокрый / дождь):
 *    - Бот использует рывок Riptide — телепортируется к цели
 *    - Наносит мощный urон при столкновении (удар с разгона)
 *    - После рывка — добивает мечом
 *    - Cooldown: 35 тиков
 *
 *  COMBO:
 *    - Riptide-рывок → удар трезубцем в ближнем бою → отход
 *    - Или: держать дистанцию → Channeling-бросок → Riptide добить
 *
 * ══════════════════════════════════════════════════════════════════
 *  ОПРЕДЕЛЕНИЕ СТИЛЯ:
 * ══════════════════════════════════════════════════════════════════
 *  Приоритет: если цель мокрая (под водой/дождём) → CHANNELING.
 *  Иначе если бот мокрый (дождь/вода) → RIPTIDE.
 *  Иначе → обычный бросок трезубцем.
 * ══════════════════════════════════════════════════════════════════
 */
public class TridentLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double THROW_RANGE        = 14.0;  // дальность броска
    private static final double MELEE_RANGE        = 3.5;   // ближний бой трезубцем
    private static final double RIPTIDE_RANGE      = 12.0;  // дальность Riptide-рывка
    private static final int    CHANNELING_COOLDOWN= 40;
    private static final int    RIPTIDE_COOLDOWN   = 35;
    private static final int    MELEE_COOLDOWN     = 15;
    private static final float  TRIDENT_DAMAGE     = 8.0f;
    private static final float  LIGHTNING_DAMAGE   = 5.0f;
    private static final float  RIPTIDE_DAMAGE     = 11.0f; // удар с разгона

    // ── Состояние ─────────────────────────────────────────────────
    private enum TridentStyle { IDLE, CHANNELING, RIPTIDE_DASH, MELEE }
    private TridentStyle style   = TridentStyle.IDLE;

    private int channelingCd = 0;
    private int riptideCd   = 0;
    private int meleeCd     = 0;
    private int riptideTick = 0; // тиков после рывка (для добивания)

    private final BotEntity bot;

    public TridentLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (channelingCd > 0) channelingCd--;
        if (riptideCd   > 0) riptideCd--;
        if (meleeCd     > 0) meleeCd--;
        if (riptideTick > 0) riptideTick--;

        equipTrident();

        double dist      = bot.distanceTo(target);
        boolean targetWet = isEntityWet(sw, target);
        boolean botWet    = isEntityWet(sw, bot);
        boolean raining   = sw.isRaining() && sw.isSkyVisible(bot.getBlockPos());

        // ── После Riptide-рывка: добиваем в ближнем бою ──────────
        if (riptideTick > 0 && dist <= MELEE_RANGE + 1.5 && meleeCd <= 0) {
            doMeleeStrike(sw, target);
            return;
        }

        // ── CHANNELING: цель мокрая → бросок + молния ─────────────
        if ((targetWet || raining) && dist <= THROW_RANGE && channelingCd <= 0) {
            doChannelingThrow(sw, target);
            return;
        }

        // ── RIPTIDE: бот мокрый → рывок к цели ───────────────────
        if ((botWet || raining) && dist > MELEE_RANGE && dist <= RIPTIDE_RANGE && riptideCd <= 0) {
            doRiptideDash(sw, target);
            return;
        }

        // ── Обычный ближний бой трезубцем ─────────────────────────
        if (dist <= MELEE_RANGE && meleeCd <= 0) {
            doMeleeStrike(sw, target);
            return;
        }

        // ── Подход если далеко ────────────────────────────────────
        if (dist > MELEE_RANGE) {
            bot.getNavigation().moveTo(target, 1.2);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  CHANNELING: бросок трезубца + молния
    // ══════════════════════════════════════════════════════════════
    private void doChannelingThrow(ServerLevel sw, LivingEntity target) {
        // Направление к цели
        Vec3 dir = target.getEyePos().subtract(bot.getEyePos()).normalize();

        // Спавним снаряд трезубца
        ThrownTrident trident = new ThrownTrident(sw, bot, new ItemStack(Items.TRIDENT));
        trident.setVelocity(dir.x * 2.2, dir.y * 2.2, dir.z * 2.2);
        trident.setPos(bot.getX(), bot.getEyeY() - 0.1, bot.getZ());
        sw.spawnEntity(trident);

        // Урон трезубца сразу (симуляция попадания для NPC)
        target.hurt(sw, sw.getDamageSources().playerAttack(null), TRIDENT_DAMAGE);

        // ── Channeling-молния (только на мокрую цель) ──────────────
        if (isEntityWet(sw, target)) {
            // Спавним молнию прямо на цели
            net.minecraft.world.entity.LightningBolt lightning = new net.minecraft.world.entity.LightningBolt(
                net.minecraft.world.entity.EntityType.LIGHTNING_BOLT, sw
            );
            lightning.setPos(target.getX(), target.getY(), target.getZ());
            sw.spawnEntity(lightning);

            // Доп. урон молнии + эффект
            target.hurt(sw, sw.getDamageSources().lightningBolt(), LIGHTNING_DAMAGE);
            target.setOnFireFor(8); // 8 секунд огня

            // Notify
            bot.getNotifier().send("§b⚡ Channeling! Молния на §f" + target.getName().getString());
        }

        // Эффекты броска
        sw.spawnParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(),
            10, 0.3, 0.3, 0.3, 0.15);
        bot.playSound(SoundEvents.ITEM_TRIDENT_THROW, 1.0f, 1.0f);

        channelingCd = CHANNELING_COOLDOWN;

        // После броска — сближаемся для добивания
        bot.getNavigation().moveTo(target, 1.3);
    }

    // ══════════════════════════════════════════════════════════════
    //  RIPTIDE: рывок к цели с уроном при столкновении
    // ══════════════════════════════════════════════════════════════
    private void doRiptideDash(ServerLevel sw, LivingEntity target) {
        Vec3 dir = target.position().subtract(bot.position()).normalize();

        // Мощный импульс к цели (симуляция Riptide)
        bot.setVelocity(dir.x * 2.8, dir.y * 0.6 + 0.3, dir.z * 2.8);
        bot.velocityModified = true;

        // Урон при "столкновении" если уже близко (или симулируем попадание)
        double dist = bot.distanceTo(target);
        if (dist <= MELEE_RANGE + 3.0) {
            target.hurt(sw, sw.getDamageSources().playerAttack(null), RIPTIDE_DAMAGE);

            // Knockback — цель отлетает по направлению рывка
            target.setVelocity(dir.x * 1.5, 0.6, dir.z * 1.5);
            target.velocityModified = true;

            sw.spawnParticles(ParticleTypes.SPLASH,
                target.getX(), target.getY(), target.getZ(),
                20, 0.5, 0.3, 0.5, 0.2);
            bot.playSound(SoundEvents.ITEM_TRIDENT_RIPTIDE_3, 1.0f, 1.0f);

            bot.getNotifier().send("§3🌊 Riptide! §c" + String.format("%.0f", RIPTIDE_DAMAGE) + " урона");
        }

        // Тиков для добивания
        riptideTick = 20;
        riptideCd   = RIPTIDE_COOLDOWN;
    }

    // ══════════════════════════════════════════════════════════════
    //  Ближний бой трезубцем
    // ══════════════════════════════════════════════════════════════
    private void doMeleeStrike(ServerLevel sw, LivingEntity target) {
        target.hurt(sw, sw.getDamageSources().playerAttack(null), TRIDENT_DAMAGE);

        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setVelocity(kb.x * 0.8, 0.35, kb.z * 0.8);
        target.velocityModified = true;

        sw.spawnParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(),
            6, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 0.9f, 1.0f);

        meleeCd = MELEE_COOLDOWN;
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ══════════════════════════════════════════════════════════════

    /** Экипировать трезубец */
    private void equipTrident() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.TRIDENT)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.TRIDENT));
        }
        // Тотем в оффхенд
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty()) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }
        // Броня
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }

    /**
     * Проверяем — сущность "мокрая":
     *   - Стоит в воде/под водой
     *   - Находится под дождём (небо видно + идёт дождь)
     */
    private boolean isEntityWet(ServerLevel sw, LivingEntity entity) {
        if (entity.isTouchingWater() || entity.isWet()) return true;
        // Дождь: биом не засушливый, небо видно, идёт дождь
        if (!sw.isRaining()) return false;
        if (!sw.isSkyVisible(entity.getBlockPos())) return false;
        // Проверяем биом (в пустынях/саваннах дождя нет)
        var biome = sw.getBiome(entity.getBlockPos());
        return biome.value().getPrecipitation(entity.getBlockPos()) ==
               net.minecraft.world.biome.Biome.Precipitation.RAIN;
    }

    /** Метка для HUD */
    public String getStateLabel() {
        if (riptideTick > 0) return "TRI:RIPTIDE";
        if (channelingCd > 0 && riptideCd > 0) return "TRI:CD";
        return "TRI:READY";
    }
}
