package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EquipmentSlot;

/**
 * BotKiteLogic — серверный кайтинг для NPC-бота.
 *
 * В отличие от клиентского KiteLogic (работает на игроке через KeyPress),
 * этот класс управляет velocity бота напрямую на сервере.
 *
 * ┌────────────┬──────────────────────────────────────────────────────┐
 * │ FLEE       │ dist < kiteMinDist → отбегаем, стреляем из лука      │
 * │ IDEAL      │ kiteMin..kiteMax   → стрейф + стрельба               │
 * │ CHASE      │ dist > kiteMax     → приближаемся к дистанции стрельбы│
 * └────────────┴──────────────────────────────────────────────────────┘
 *
 * v13: Улучшения:
 *   - Wall-avoidance: бот проверяет блоки и меняет направление
 *   - Predictive strafing: стрейф с учётом движения цели
 *   - HP-адаптация: при низком HP агрессивнее убегает
 *   - Симуляция выстрела из лука с предсказанием позиции
 */
public class BotKiteLogic {

    // ── Конфиг дистанций ─────────────────────────────────────────
    private static final double KITE_MIN_DIST  = 5.0;   // ближе → убегаем
    private static final double KITE_MAX_DIST  = 14.0;  // дальше → приближаемся
    private static final double IDEAL_DIST     = 9.0;   // идеал — центр зоны стрельбы

    // ── Скорости ─────────────────────────────────────────────────
    private static final double FLEE_SPEED     = 0.28;
    private static final double STRAFE_SPEED   = 0.18;
    private static final double CHASE_SPEED    = 0.22;

    // ── Кулдауны ─────────────────────────────────────────────────
    private static final int BOW_COOLDOWN_TICKS   = 25;  // тиков между выстрелами
    private static final int STRAFE_FLIP_MIN      = 12;  // мин тиков до смены стрейфа
    private static final int STRAFE_FLIP_MAX      = 25;

    // ── Состояние ────────────────────────────────────────────────
    private enum KiteState { FLEE, IDEAL, CHASE }
    private KiteState state       = KiteState.IDEAL;

    private int bowCooldown       = 0;
    private int strafeTimer       = 0;
    private int strafeDir         = 1;    // +1 = влево, -1 = вправо
    private int wallAvoidDir      = 0;    // временное направление обхода стены
    private int wallAvoidTicks    = 0;

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public BotKiteLogic(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Главный тик — вызывать каждый тик пока бот в KITE-режиме.
     */
    public void tick(LivingEntity target) {
        if (bot.getWorld().isClient) return;
        if (target == null || !target.isAlive()) return;

        if (bowCooldown  > 0) bowCooldown--;
        if (strafeTimer  > 0) strafeTimer--;
        if (wallAvoidTicks > 0) wallAvoidTicks--;

        double dist = bot.distanceTo(target);
        updateState(dist);

        // Экипируем лук
        equipBow();

        switch (state) {
            case FLEE  -> doFlee(target);
            case IDEAL -> doIdeal(target);
            case CHASE -> doChase(target);
        }

        // Стрельба в любом состоянии (если есть кулдаун)
        if (bowCooldown <= 0) {
            shootBow(target);
        }
    }

    // ── Обновление состояния ─────────────────────────────────────
    private void updateState(double dist) {
        // При низком HP — расширяем зону flee (убегаем дальше)
        double fleeBonus = (bot.getHealth() < 8.0f) ? 2.0 : 0.0;
        double minDist   = KITE_MIN_DIST + fleeBonus;

        if      (dist < minDist)         state = KiteState.FLEE;
        else if (dist > KITE_MAX_DIST)   state = KiteState.CHASE;
        else                             state = KiteState.IDEAL;
    }

    // ── FLEE: убегаем от цели ────────────────────────────────────
    private void doFlee(LivingEntity target) {
        Vec3d away = bot.getPos().subtract(target.getPos()).normalize();

        // Wall-avoidance: если впереди блок — отклоняемся
        if (wallAvoidTicks <= 0) {
            Vec3d checkPos = bot.getPos().add(away.multiply(1.2));
            if (isBlocked(checkPos)) {
                // Пробуем +90° или -90°
                wallAvoidDir   = (bot.getWorld().getRandom().nextBoolean()) ? 1 : -1;
                wallAvoidTicks = 15;
            }
        }

        Vec3d moveDir = away;
        if (wallAvoidTicks > 0) {
            // Поворот на 45° для обхода стены
            double angle = wallAvoidDir * Math.PI / 4.0;
            moveDir = rotateY(away, angle);
        }

        applyVelocityXZ(moveDir, FLEE_SPEED);
    }

    // ── IDEAL: стрейф на хорошей дистанции ───────────────────────
    private void doIdeal(LivingEntity target) {
        // Меняем направление стрейфа через случайный интервал
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = STRAFE_FLIP_MIN + bot.getWorld().getRandom()
                .nextInt(STRAFE_FLIP_MAX - STRAFE_FLIP_MIN);
        }

        // Вектор "к цели"
        Vec3d toTarget = target.getPos().subtract(bot.getPos()).normalize();
        // Перпендикуляр — направление стрейфа
        Vec3d strafe = new Vec3d(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);

        // v13: предсказываем движение цели и стрейфуем в противоположную сторону
        Vec3d targetVel = target.getVelocity();
        if (targetVel.horizontalLengthSquared() > 0.01) {
            // Цель движется — контрстрейф
            Vec3d counterStrafe = new Vec3d(-targetVel.z, 0, targetVel.x).normalize();
            strafe = strafe.add(counterStrafe.multiply(0.4)).normalize();
        }

        applyVelocityXZ(strafe, STRAFE_SPEED);
    }

    // ── CHASE: приближаемся к идеальной дистанции ────────────────
    private void doChase(LivingEntity target) {
        Vec3d dir = target.getPos().subtract(bot.getPos()).normalize();
        applyVelocityXZ(dir, CHASE_SPEED);
    }

    // ── Выстрел из лука ──────────────────────────────────────────
    private void shootBow(LivingEntity target) {
        if (!(bot.getWorld() instanceof ServerWorld sw)) return;

        double dist = bot.distanceTo(target);

        // v13: предсказываем позицию цели для точного выстрела
        Vec3d aimPos = MotionPredictor.predict(target, (int)(dist / 3));

        // Урон: 3–9 в зависимости от дистанции (как ванильный лук)
        float damage = (float) Math.max(3.0, Math.min(9.0, 10.0 - dist * 0.35));

        // Наносим урон ближайшей сущности к прицельной точке
        sw.getEntitiesByClass(LivingEntity.class,
            new net.minecraft.util.math.Box(aimPos, aimPos).expand(1.2),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.damage(sw, sw.getDamageSources().arrow(null, bot), damage)
        );

        // Эффект стрелы
        sw.spawnParticles(
            ParticleTypes.CRIT,
            aimPos.x, aimPos.y + 1, aimPos.z,
            4, 0.2, 0.2, 0.2, 0.1
        );

        bowCooldown = BOW_COOLDOWN_TICKS;
    }

    // ── Вспомогательные ──────────────────────────────────────────

    private void applyVelocityXZ(Vec3d dir, double speed) {
        Vec3d cur = bot.getVelocity();
        bot.setVelocity(
            cur.x * 0.6 + dir.x * speed,
            cur.y,
            cur.z * 0.6 + dir.z * speed
        );
        bot.velocityModified = true;
    }

    private void equipBow() {
        ItemStack cur = bot.getEquippedStack(EquipmentSlot.MAINHAND);
        if (!cur.isOf(Items.BOW)) {
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        }
    }

    /** Проверяет, есть ли твёрдый блок в позиции (для wall-avoidance). */
    private boolean isBlocked(Vec3d pos) {
        return !bot.getWorld().getBlockState(
            new net.minecraft.util.math.BlockPos(
                (int) Math.floor(pos.x),
                (int) Math.floor(pos.y),
                (int) Math.floor(pos.z)
            )
        ).isAir();
    }

    /** Поворот вектора вокруг оси Y на угол angle (радианы). */
    private Vec3d rotateY(Vec3d v, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        return new Vec3d(
            v.x * cos - v.z * sin,
            v.y,
            v.x * sin + v.z * cos
        );
    }

    public KiteState getState() { return state; }
}
