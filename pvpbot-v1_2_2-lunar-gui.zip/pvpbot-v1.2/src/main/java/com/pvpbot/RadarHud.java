package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Radar HUD — круговой мини-радар в углу экрана.
 *
 * • Круг с линией "север" (направление взгляда игрока)
 * • Точки: красные = игроки, оранжевые = мобы, золотые = NPC-боты
 * • Масштаб: radarRange блоков → радиус radarRadius пикселей
 * • Позиция: правый верхний угол (настраивается)
 */
public class RadarHud {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public void render(GuiGraphics ctx, Minecraft mc) {
        if (!cfg.radarEnabled || mc.player == null || mc.world == null) return;

        int screenW = mc.getWindow().getScaledWidth();
        int r       = cfg.radarRadius;      // радиус круга в px
        int cx      = screenW - r - 8;      // центр X (правый верхний угол)
        int cy      = r + 8;                // центр Y

        // ── Фон ──────────────────────────────────────────────────
        drawFilledCircle(ctx, cx, cy, r, 0xAA000000);
        drawCircleOutline(ctx, cx, cy, r, 0xFFFFFFFF);

        // Крест-нить прицела (деление радара на секторы)
        ctx.fill(cx - r, cy, cx + r + 1, cy + 1, 0x33FFFFFF);
        ctx.fill(cx,     cy - r, cx + 1, cy + r + 1, 0x33FFFFFF);

        // Внутреннее кольцо (половина радара)
        drawCircleOutline(ctx, cx, cy, r / 2, 0x22FFFFFF);

        // ── Направление взгляда (стрелка "вперёд") ────────────────
        float yaw = mc.player.getYaw(); // 0 = юг, 90 = запад, -90 = восток, 180 = север
        double fwdRad = Math.toRadians(yaw);
        int arrowX = cx + (int)(Math.sin(fwdRad) * (r - 4));
        int arrowY = cy - (int)(Math.cos(fwdRad) * (r - 4));
        drawLine(ctx, cx, cy, arrowX, arrowY, 0xFFFFFFFF);
        ctx.fill(arrowX - 1, arrowY - 1, arrowX + 2, arrowY + 2, 0xFFFFFFFF);

        // ── Сущности ──────────────────────────────────────────────
        Vec3 playerPos = mc.player.getPos();
        double range    = cfg.radarRange;

        Box box = mc.player.getBoundingBox().expand(range);
        List<LivingEntity> entities = mc.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != mc.player && e.isAlive()
        );

        for (LivingEntity e : entities) {
            double dx = e.getX() - playerPos.x;
            double dz = e.getZ() - playerPos.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > range) continue;

            // Поворот относительно взгляда игрока
            double angle = Math.atan2(dx, -dz) - Math.toRadians(yaw);
            double scaledDist = (dist / range) * (r - 3);

            int dotX = cx + (int)(Math.sin(angle) * scaledDist);
            int dotY = cy - (int)(Math.cos(angle) * scaledDist);

            int color = getRadarColor(e);
            int dotSize = (e instanceof Player) ? 2 : 1;
            ctx.fill(dotX - dotSize, dotY - dotSize,
                     dotX + dotSize + 1, dotY + dotSize + 1, color);
        }

        // ── Заголовок ─────────────────────────────────────────────
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal("§7RADAR"),
            cx - mc.textRenderer.getWidth("RADAR") / 2 + 1,
            cy + r + 2, 0x888888);
    }

    // ── Геометрия ─────────────────────────────────────────────────

    private void drawFilledCircle(GuiGraphics ctx, int cx, int cy, int r, int color) {
        for (int y = -r; y <= r; y++) {
            int halfW = (int) Math.sqrt(r * r - y * y);
            ctx.fill(cx - halfW, cy + y, cx + halfW + 1, cy + y + 1, color);
        }
    }

    private void drawCircleOutline(GuiGraphics ctx, int cx, int cy, int r, int color) {
        int x = r, y = 0, err = 0;
        while (x >= y) {
            plot8(ctx, cx, cy, x, y, color);
            y++;
            if (err <= 0) { err += 2 * y + 1; }
            else          { x--; err += 2 * (y - x) + 1; }
        }
    }

    private void plot8(GuiGraphics ctx, int cx, int cy, int x, int y, int color) {
        ctx.fill(cx + x, cy + y, cx + x + 1, cy + y + 1, color);
        ctx.fill(cx - x, cy + y, cx - x + 1, cy + y + 1, color);
        ctx.fill(cx + x, cy - y, cx + x + 1, cy - y + 1, color);
        ctx.fill(cx - x, cy - y, cx - x + 1, cy - y + 1, color);
        ctx.fill(cx + y, cy + x, cx + y + 1, cy + x + 1, color);
        ctx.fill(cx - y, cy + x, cx - y + 1, cy + x + 1, color);
        ctx.fill(cx + y, cy - x, cx + y + 1, cy - x + 1, color);
        ctx.fill(cx - y, cy - x, cx - y + 1, cy - x + 1, color);
    }

    private void drawLine(GuiGraphics ctx, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1), sx = x1 < x2 ? 1 : -1;
        int dy = -Math.abs(y2 - y1), sy = y1 < y2 ? 1 : -1;
        int err = dx + dy;
        while (true) {
            ctx.fill(x1, y1, x1 + 1, y1 + 1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 >= dy) { if (x1 == x2) break; err += dy; x1 += sx; }
            if (e2 <= dx) { if (y1 == y2) break; err += dx; y1 += sy; }
        }
    }

    private int getRadarColor(LivingEntity e) {
        if (e instanceof Player)  return 0xFFFF2222;
        if (e instanceof BotEntity)     return 0xFFFFD700;
        if (e instanceof net.minecraft.world.entity.monster.Monster) return 0xFFFF7700;
        return 0xFF44FF44;
    }
}
