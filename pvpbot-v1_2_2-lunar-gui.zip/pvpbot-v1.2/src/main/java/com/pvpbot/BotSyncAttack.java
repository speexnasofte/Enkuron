package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * BotSyncAttack — система синхроатаки нескольких ботов (v12).
 *
 * Режимы:
 *   FOCUS   — все боты атакуют одну цель одновременно
 *   SURROUND — боты окружают цель с разных сторон перед атакой
 *
 * Запуск:
 *   1. /bot sync attack [ник]  — ручной
 *   2. Авто: когда любой бот находит цель, остальные синхронизируются
 *
 * Логика окружения:
 *   Боты расходятся по кругу вокруг цели на расстояние SURROUND_RADIUS,
 *   ждут SURROUND_WAIT_TICKS и только потом одновременно атакуют.
 */
public class BotSyncAttack {

    public static final BotSyncAttack INSTANCE = new BotSyncAttack();

    // ── Настройки ─────────────────────────────────────────────────
    private static final double SURROUND_RADIUS    = 3.5;  // блоков от цели
    private static final int    SURROUND_WAIT_TICKS = 40;  // 2 секунды сбора
    private static final int    AUTO_SYNC_COOLDOWN  = 60;  // тиков между авто-синхро

    public enum SyncMode { FOCUS, SURROUND }

    // ── Состояние ─────────────────────────────────────────────────
    private SyncMode  mode           = SyncMode.SURROUND;
    private boolean   active         = false;
    private LivingEntity syncTarget  = null;

    // авто-синхро
    private boolean   autoSync       = true;
    private int       autoSyncCooldown = 0;

    // окружение: бот → его позиция сбора
    private final Map<BotEntity, Vec3> surroundPositions = new LinkedHashMap<>();
    private int surroundTimer = 0;
    private boolean surroundReady = false;

    private BotSyncAttack() {}

    // ─────────────────────────────────────────────────────────────
    //  Публичный API
    // ─────────────────────────────────────────────────────────────

    public SyncMode getMode()       { return mode; }
    public void setMode(SyncMode m) { mode = m; }
    public boolean isAutoSync()     { return autoSync; }
    public void setAutoSync(boolean v) { autoSync = v; }
    public boolean isActive()       { return active; }
    public LivingEntity getTarget() { return syncTarget; }

    /**
     * Запустить синхроатаку вручную.
     * @param bots   список ботов игрока
     * @param target цель (null = первая цель любого бота)
     * @param source игрок-инициатор (для фидбека)
     */
    public void start(List<BotEntity> bots, LivingEntity target, ServerPlayer source) {
        if (bots == null || bots.isEmpty()) {
            if (source != null) msg(source, "§cНет активных ботов для синхроатаки!");
            return;
        }

        // Найти цель если не задана
        LivingEntity resolvedTarget = target;
        if (resolvedTarget == null) {
            for (BotEntity bot : bots) {
                if (bot.getTarget() != null && bot.getTarget().isAlive()) {
                    resolvedTarget = bot.getTarget();
                    break;
                }
            }
        }
        if (resolvedTarget == null) {
            if (source != null) msg(source, "§cЦель не найдена! Укажи /bot sync attack <ник>");
            return;
        }

        activate(bots, resolvedTarget);

        if (source != null) {
            String modeName = mode == SyncMode.SURROUND ? "§6Окружение" : "§cФокус";
            msg(source, "§a⚡ Синхроатака [" + modeName + "§a] → §f"
                + resolvedTarget.getName().getString()
                + " §7[" + bots.size() + " ботов]");
        }
    }

    /**
     * Вызывается каждый тик из BotEntity.tick() на сервере.
     * Проверяет авто-синхро.
     */
    public void serverTick(List<BotEntity> bots) {
        if (autoSyncCooldown > 0) autoSyncCooldown--;

        // Авто: если не активна — смотрим есть ли общая цель
        if (!active && autoSync && autoSyncCooldown == 0 && bots.size() >= 2) {
            LivingEntity found = null;
            int count = 0;
            for (BotEntity bot : bots) {
                if (bot.getTarget() != null && bot.getTarget().isAlive()) {
                    if (found == null) found = bot.getTarget();
                    count++;
                }
            }
            // Авто-синхро если 2+ ботов видят цель
            if (found != null && count >= 2) {
                activate(bots, found);
                autoSyncCooldown = AUTO_SYNC_COOLDOWN;
            }
        }

        // Тик активной синхроатаки
        if (active) {
            tickActive(bots);
        }
    }

    /**
     * Остановить синхроатаку.
     */
    public void stop() {
        active = false;
        syncTarget = null;
        surroundPositions.clear();
        surroundTimer = 0;
        surroundReady = false;
    }

    // ─────────────────────────────────────────────────────────────
    //  Внутренняя логика
    // ─────────────────────────────────────────────────────────────

    private void activate(List<BotEntity> bots, LivingEntity target) {
        active = true;
        syncTarget = target;
        surroundReady = false;
        surroundTimer = 0;
        surroundPositions.clear();

        if (mode == SyncMode.SURROUND) {
            // Рассчитать позиции окружения равномерно по кругу
            int n = bots.size();
            for (int i = 0; i < n; i++) {
                double angle = 2 * Math.PI * i / n;
                double x = target.getX() + SURROUND_RADIUS * Math.cos(angle);
                double z = target.getZ() + SURROUND_RADIUS * Math.sin(angle);
                surroundPositions.put(bots.get(i), new Vec3(x, target.getY(), z));
            }
        } else {
            // FOCUS: сразу назначаем цель
            for (BotEntity bot : bots) {
                bot.setTarget(target);
            }
        }
    }

    private void tickActive(List<BotEntity> bots) {
        // Проверка: цель ещё жива?
        if (syncTarget == null || !syncTarget.isAlive()) {
            stop();
            return;
        }

        if (mode == SyncMode.FOCUS) {
            // Просто держим всех на одной цели
            for (BotEntity bot : bots) {
                if (!bot.isRemoved()) bot.setTarget(syncTarget);
            }
            // Стоп если цель мертва
            if (!syncTarget.isAlive()) stop();

        } else {
            // SURROUND: фаза 1 — сбор позиций
            if (!surroundReady) {
                surroundTimer++;
                for (Map.Entry<BotEntity, Vec3> entry : surroundPositions.entrySet()) {
                    BotEntity bot = entry.getKey();
                    Vec3 pos = entry.getValue();
                    if (!bot.isRemoved()) {
                        // Двигаем бота к его позиции окружения (через pathfinder)
                        bot.getNavigation().moveTo(pos.x, pos.y, pos.z, 1.3);
                        bot.setTarget(null); // не атакует пока не окружил
                    }
                }
                // Обновляем позиции вокруг движущейся цели
                updateSurroundPositions(bots);

                if (surroundTimer >= SURROUND_WAIT_TICKS) {
                    surroundReady = true;
                }
            } else {
                // Фаза 2 — одновременная атака
                for (BotEntity bot : bots) {
                    if (!bot.isRemoved()) bot.setTarget(syncTarget);
                }
            }
        }
    }

    /** Пересчитать позиции окружения под текущее положение движущейся цели. */
    private void updateSurroundPositions(List<BotEntity> bots) {
        if (syncTarget == null) return;
        int n = surroundPositions.size();
        int i = 0;
        for (BotEntity bot : surroundPositions.keySet()) {
            double angle = 2 * Math.PI * i / n;
            double x = syncTarget.getX() + SURROUND_RADIUS * Math.cos(angle);
            double z = syncTarget.getZ() + SURROUND_RADIUS * Math.sin(angle);
            surroundPositions.put(bot, new Vec3(x, syncTarget.getY(), z));
            i++;
        }
    }

    private static void msg(ServerPlayer p, String text) {
        p.sendMessage(Component.literal(text), false);
    }
}
