package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

public class CrystalLogic {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int placeTimer = 0;
    private int explodeTimer = 0;

    public void tick(Minecraft mc) {
        if (mc.player == null || mc.world == null) return;

        placeTimer--;
        explodeTimer--;

        Player player = mc.player;

        // Ищем ближайшего врага
        LivingEntity target = findTarget(mc, player);
        if (target == null) return;

        // 1. Взрываем ближайший кристалл к врагу
        if (explodeTimer <= 0) {
            explodeCrystalNear(mc, target);
            explodeTimer = cfg.crystalCooldown;
        }

        // 2. Ставим новый кристалл рядом с врагом
        if (placeTimer <= 0 && hasCrystals(player)) {
            placeCrystalNear(mc, player, target);
            placeTimer = cfg.crystalCooldown + 1;
        }
    }

    // Взрываем кристалл ближайший к врагу
    private void explodeCrystalNear(Minecraft mc, LivingEntity target) {
        if (mc.world == null || mc.player == null) return;

        Box searchBox = target.getBoundingBox().expand(cfg.crystalPlaceRange);
        List<EndCrystal> crystals = mc.world.getEntitiesByClass(
            EndCrystal.class, searchBox, e -> true
        );

        crystals.stream()
            .min(Comparator.comparingDouble(c -> c.squaredDistanceTo(target)))
            .ifPresent(crystal -> {
                mc.interactionManager.attackEntity(mc.player, crystal);
                mc.player.swingHand(Hand.MAIN_HAND);
            });
    }

    // Ставим кристалл на обсидиан/бедрок рядом с врагом
    private void placeCrystalNear(Minecraft mc, Player player, LivingEntity target) {
        if (mc.world == null) return;

        // Переключаем на кристаллы в хотбаре
        int slot = findCrystalSlot(player);
        if (slot == -1) return;
        player.getInventory().selectedSlot = slot;

        BlockPos targetPos = target.getBlockPos();

        // Ищем подходящий блок вокруг врага для установки кристалла
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos basePos = targetPos.add(dx, -1, dz);
                BlockPos placePos = basePos.up();

                var baseBlock = mc.world.getBlockState(basePos).getBlock();
                boolean isValidBase =
                    baseBlock == net.minecraft.world.level.block.Blocks.OBSIDIAN ||
                    baseBlock == net.minecraft.world.level.block.Blocks.BEDROCK;

                boolean isAir = mc.world.getBlockState(placePos).isAir();
                boolean isAirAbove = mc.world.getBlockState(placePos.up()).isAir();

                double dist = player.getPos().distanceTo(Vec3.ofCenter(placePos));

                if (isValidBase && isAir && isAirAbove && dist <= cfg.crystalPlaceRange) {
                    BlockHitResult hit = new BlockHitResult(
                        Vec3.ofCenter(basePos),
                        Direction.UP,
                        basePos,
                        false
                    );
                    mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
                    return;
                }
            }
        }
    }

    private LivingEntity findTarget(Minecraft mc, Player player) {
        if (mc.world == null) return null;
        Box box = player.getBoundingBox().expand(16.0);
        List<LivingEntity> list = mc.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive() && !e.isInvisible()
        );
        return list.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }

    private boolean hasCrystals(Player player) {
        return findCrystalSlot(player) != -1;
    }

    private int findCrystalSlot(Player player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }
}
