package com.pvpbot.client;

import com.pvpbot.BotEntity;
import com.pvpbot.BotSkinManager;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * BotEntityRenderer v9 — рендерит бота с моделью игрока и его скином.
 *
 * Если скин ещё грузится → показываем дефолтный Стив.
 * Как только BotSkinManager загрузил текстуру → автоматически
 * подхватывается при следующем кадре (getTexture() вызывается каждый кадр).
 *
 * Модель: PlayerModel (slim=false) — стандартная широкоруканая.
 * Для slim (Alex-образной) нужен отдельный ModelLayers.PLAYER_SLIM.
 */
public class BotEntityRenderer extends MobRenderer<BotEntity, PlayerModel<BotEntity>> {

    // Стив — фоллбэк пока скин грузится
    private static final ResourceLocation STEVE_TEXTURE =
        ResourceLocation.of("minecraft", "textures/entity/steve.png");

    public BotEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            new PlayerModel<>(ctx.getPart(ModelLayers.PLAYER), false),
            0.5f);
    }

    @Override
    public ResourceLocation getTexture(BotEntity entity) {
        String skinNick = entity.getSkinNick();

        if (skinNick == null || skinNick.isEmpty()) {
            return STEVE_TEXTURE;
        }

        // Получаем из кеша (может быть null если ещё грузится)
        ResourceLocation tex = BotSkinManager.INSTANCE.getSkinTexture(skinNick);
        return tex != null ? tex : STEVE_TEXTURE;
    }
}
