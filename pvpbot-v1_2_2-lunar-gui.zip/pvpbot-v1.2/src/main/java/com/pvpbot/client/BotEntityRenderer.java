package com.pvpbot.client;

import com.pvpbot.BotEntity;
import com.pvpbot.BotSkinManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.ResourceLocation;

/**
 * BotEntityRenderer v9 — рендерит бота с моделью игрока и его скином.
 */
public class BotEntityRenderer extends HumanoidMobRenderer<BotEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {

    private static final ResourceLocation STEVE_TEXTURE =
        ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/player/wide/steve.png");

    public BotEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)),
            0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(HumanoidRenderState state) {
        return STEVE_TEXTURE;
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }
}
