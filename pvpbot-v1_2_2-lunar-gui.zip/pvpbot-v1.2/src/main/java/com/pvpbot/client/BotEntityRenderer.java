package com.pvpbot.client;

import com.pvpbot.BotEntity;
import com.pvpbot.BotSkinManager;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.util.Identifier;

/**
 * BotEntityRenderer v9 — рендерит бота с моделью игрока и его скином.
 *
 * Если скин ещё грузится → показываем дефолтный Стив.
 * Как только BotSkinManager загрузил текстуру → автоматически
 * подхватывается при следующем кадре (getTexture() вызывается каждый кадр).
 *
 * Модель: PlayerEntityModel (slim=false) — стандартная широкоруканая.
 * Для slim (Alex-образной) нужен отдельный EntityModelLayers.PLAYER_SLIM.
 */
public class BotEntityRenderer extends MobEntityRenderer<BotEntity, PlayerEntityModel<BotEntity>> {

    // Стив — фоллбэк пока скин грузится
    private static final Identifier STEVE_TEXTURE =
        Identifier.of("minecraft", "textures/entity/steve.png");

    public BotEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx,
            new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false),
            0.5f);
    }

    @Override
    public Identifier getTexture(BotEntity entity) {
        String skinNick = entity.getSkinNick();

        if (skinNick == null || skinNick.isEmpty()) {
            return STEVE_TEXTURE;
        }

        // Получаем из кеша (может быть null если ещё грузится)
        Identifier tex = BotSkinManager.INSTANCE.getSkinTexture(skinNick);
        return tex != null ? tex : STEVE_TEXTURE;
    }
}
