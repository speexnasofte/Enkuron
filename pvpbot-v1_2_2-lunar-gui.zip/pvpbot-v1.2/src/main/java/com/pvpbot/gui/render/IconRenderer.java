package com.pvpbot.gui.render;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/**
 * IconRenderer — рисует иконки модулей через текстуры.
 * Текстуры лежат в: assets/pvpbot/textures/gui/icons/<name>.png
 *
 * Если текстура не найдена — рисуется Unicode-символ (fallback).
 */
public class IconRenderer {

    // Все иконки мода
    private static final String[] ICON_NAMES = {
        "auto_attack", "auto_dodge", "auto_heal", "auto_eat",
        "auto_gap", "auto_sprint", "auto_totem", "auto_armor",
        "auto_bow", "kite", "w_tap", "s_tap", "esp",
        "radar", "auto_crystal", "stats", "hud", "auto_block",
        "anti_knockback", "auto_log", "auto_pearl", "tracers"
    };

    /**
     * Рисует иконку модуля по её id.
     * Сначала пробует текстуру, при ошибке — символ.
     */
    public static void draw(GuiGraphics ctx, String moduleId, int x, int y, int size) {
        try {
            ResourceLocation tex = ResourceLocation.fromNamespaceAndPath("pvpbot", "textures/gui/icons/" + moduleId + ".png");
            ctx.drawTexture(tex, x, y, 0, 0, size, size, size, size);
        } catch (Exception e) {
            // fallback: Unicode символ посередине
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc != null && mc.textRenderer != null) {
                String sym = getFallbackSymbol(moduleId);
                int sw = mc.textRenderer.getWidth(sym);
                ctx.drawText(mc.textRenderer, sym, x + (size - sw) / 2, y + (size / 2) - 4, 0xCCCCCC, true);
            }
        }
    }

    /** Unicode fallback когда нет PNG. */
    public static String getFallbackSymbol(String id) {
        return switch (id) {
            case "auto_attack"    -> "\u2694"; // ⚔
            case "auto_dodge"     -> "\u26A1"; // ⚡
            case "auto_heal"      -> "\u2764"; // ❤
            case "auto_eat"       -> "\u2615"; // ☕
            case "auto_gap"       -> "\u2B50"; // ⭐
            case "auto_sprint"    -> "\u25B6"; // ▶
            case "auto_totem"     -> "\u26E8"; // ⛨
            case "auto_armor"     -> "\u1F6E1"; // 🛡
            case "auto_bow"       -> "\u27B9"; // ➹
            case "kite"           -> "\u2605"; // ★
            case "w_tap"          -> "\u26A1"; // ⚡
            case "s_tap"          -> "\u21C4"; // ⇄
            case "esp"            -> "\u25CE"; // ◎
            case "radar"          -> "\u25CC"; // ◌
            case "auto_crystal"   -> "\u25C6"; // ◆
            case "stats"          -> "\u25A0"; // ■
            case "hud"            -> "\u2630"; // ☰
            case "auto_block"     -> "\u25A3"; // ▣
            case "anti_knockback" -> "\u21D5"; // ⇕
            case "auto_log"       -> "\u23CF"; // ⏏
            case "auto_pearl"     -> "\u25CB"; // ○
            case "tracers"        -> "\u25B3"; // △
            default               -> "\u2022"; // •
        };
    }
}
