package com.pvpbot.gui.render;

import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;

/**
 * BlurUtil — имитация blur-эффекта через многослойное затемнение.
 *
 * Настоящий GLSL blur требует шейдеров (отдельный ресурс-пак).
 * Здесь мы делаем "frosted glass" через полупрозрачные слои —
 * выглядит похоже на Lunar без лишних зависимостей.
 */
public class BlurUtil {

    /**
     * Рисует frosted-glass подложку поверх мира.
     * Вызывать ДО рисования панели.
     */
    public static void drawFrost(GuiGraphics ctx, int screenW, int screenH) {
        // слой 1: тёмный overlay
        ctx.fill(0, 0, screenW, screenH, new Color(0, 0, 0, 130).getRGB());
        // слой 2: слегка синеватый для "холодного" Lunar look
        ctx.fill(0, 0, screenW, screenH, new Color(5, 8, 20, 40).getRGB());
    }

    /**
     * Frosted стекло для конкретного прямоугольника (панель).
     */
    public static void drawPanelFrost(GuiGraphics ctx, int x, int y, int w, int h) {
        // многослойное затемнение — имитирует depth blur
        ctx.fill(x - 4, y - 4, x + w + 4, y + h + 4, new Color(0, 0, 0, 60).getRGB());
        ctx.fill(x - 2, y - 2, x + w + 2, y + h + 2, new Color(0, 0, 0, 80).getRGB());
        ctx.fill(x,     y,     x + w,     y + h,     new Color(0, 0, 0, 40).getRGB());
    }
}
