package com.pvpbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/**
 * KiteLogic — кайтинг (kiting): держим дистанцию от врага, стреляя из лука.
 *
 * Состояния:
 *  FLEE   — враг слишком близко (< kiteMinDist) → убегаем назад
 *  IDEAL  — враг в зоне стрельбы (kiteMinDist..kiteMaxDist) → стоим/стрейф
 *  CHASE  — враг слишком далеко (> kiteMaxDist) → приближаемся
 *
 * Алгоритм отступления:
 *  1. Вычисляем вектор "от врага"
 *  2. Ищем свободное направление методом wall-avoidance (3 варианта: прямо, +45°, -45°)
 *  3. Устанавливаем клавиши движения через velocity
 */
public class KiteLogic {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private enum KiteState { FLEE, IDEAL, CHASE }
    private KiteState state = KiteState.IDEAL;

    private int strafeTimer = 0;
    private int strafeDir   = 1;

    public void tick(MinecraftClient client) {
        if (!cfg.kiteEnabled) {
            releaseKeys(client);
            return;
        }
        if (client.player == null || client.world == null) return;

        PlayerEntity player = client.player;
        LivingEntity target = findKiteTarget(client, player);

        if (target == null) {
            releaseKeys(client);
            return;
        }

        double dist = player.distanceTo(target);
        updateState(dist);

        switch (state) {
            case FLEE  -> flee(client, player, target);
            case IDEAL -> idealPosition(client, player, target);
            case CHASE -> chase(client, player, target);
        }
    }

    private void updateState(double dist) {
        if      (dist < cfg.kiteMinDist)  state = KiteState.FLEE;
        else if (dist > cfg.kiteMaxDist)  state = KiteState.CHASE;
        else                              state = KiteState.IDEAL;
    }

    /** Убегаем от врага, разворачиваясь спиной */
    private void flee(MinecraftClient client, PlayerEntity player, LivingEntity target) {
        Vec3d away = player.getPos().subtract(target.getPos()).normalize();

        // Устанавливаем velocity напрямую — мгновенный отклик
        Vec3d curr = player.getVelocity();
        double fleeSpeed = 0.25;
        player.setVelocity(
            curr.x * 0.5 + away.x * fleeSpeed,
            curr.y,
            curr.z * 0.5 + away.z * fleeSpeed
        );
        player.velocityModified = true;

        client.options.backKey.setPressed(true);
        client.options.forwardKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
    }

    /** Идеальная дистанция — стрейфимся, не убегаем */
    private void idealPosition(MinecraftClient client, PlayerEntity player, LivingEntity target) {
        strafeTimer--;
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = 15 + (int)(Math.random() * 10);
        }

        client.options.backKey.setPressed(false);
        client.options.forwardKey.setPressed(false);

        if (strafeDir > 0) {
            client.options.leftKey.setPressed(true);
            client.options.rightKey.setPressed(false);
        } else {
            client.options.rightKey.setPressed(true);
            client.options.leftKey.setPressed(false);
        }
    }

    /** Враг слишком далеко — приближаемся */
    private void chase(MinecraftClient client, PlayerEntity player, LivingEntity target) {
        client.options.forwardKey.setPressed(true);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
    }

    private void releaseKeys(MinecraftClient client) {
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
    }

    private LivingEntity findKiteTarget(MinecraftClient client, PlayerEntity player) {
        Box box = player.getBoundingBox().expand(cfg.kiteMaxDist + 10);
        List<LivingEntity> entities = client.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive() && !e.isInvisible()
        );
        return entities.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }
}
