package com.pvpbot;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

/**
 * DpsMeter — урон в секунду по текущей цели.
 *
 * Использует скользящее окно за последние 20 тиков (1 секунда).
 * Записи: (tick, damage) — добавляются из PVPBotLogic при атаке.
 *
 * Отображается в PVPBotHud.
 */
public class DpsMeter {

    public static final DpsMeter INSTANCE = new DpsMeter();

    private static final int WINDOW_TICKS = 20; // 1 секунда

    // Очередь: (tick, damage)
    private final Deque<long[]> hits = new ArrayDeque<>();
    private int currentTick = 0;

    // Текущая цель
    private UUID currentTargetUUID = null;

    // Кэш DPS (обновляется каждый тик)
    private float cachedDps = 0f;

    private DpsMeter() {}

    public void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            currentTick++;
            // Удаляем старые записи за пределами окна
            while (!hits.isEmpty() && currentTick - hits.peekFirst()[0] > WINDOW_TICKS) {
                hits.pollFirst();
            }
            // Пересчитываем DPS
            float total = 0f;
            for (long[] entry : hits) {
                total += entry[1] / 10f; // damage хранится *10 для точности
            }
            // DPS = урон за окно / (окно в секундах)
            cachedDps = total / (WINDOW_TICKS / 20f);
        });
    }

    /**
     * Записать удар по цели.
     * @param target цель
     * @param damage нанесённый урон
     */
    public void recordDamage(LivingEntity target, float damage) {
        currentTargetUUID = target.getUUID();
        hits.addLast(new long[]{ currentTick, (long)(damage * 10) });
    }

    /**
     * Сбрасывает DPS при смене цели.
     */
    public void onTargetChanged(UUID newTargetUUID) {
        if (!java.util.Objects.equals(newTargetUUID, currentTargetUUID)) {
            hits.clear();
            cachedDps = 0f;
            currentTargetUUID = newTargetUUID;
        }
    }

    /** Возвращает текущий DPS (урон/сек). */
    public float getDps() { return cachedDps; }

    /** Форматирует для HUD: "DPS: 12.4" */
    public String getFormatted() {
        return String.format("DPS: §e%.1f", cachedDps);
    }

    public void reset() {
        hits.clear();
        cachedDps = 0f;
    }
}
