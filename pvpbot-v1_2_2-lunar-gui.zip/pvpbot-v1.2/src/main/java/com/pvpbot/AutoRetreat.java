package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/**
 * AutoRetreat — система авто-отступления бота (v12).
 *
 * Фазы:
 *   FIGHTING  → обычный бой
 *   RETREATING → HP упал ниже порога → бот убегает от цели
 *   HEALING   → бот остановился, использует зелья/еду/тотем
 *   RETURNING → HP восстановлен → бот возвращается к цели
 *
 * Триггер: HP < retreatHpThreshold (по умолчанию 6 = 3 сердца)
 * Возврат:  HP > returnHpThreshold  (по умолчанию 16 = 8 сердец)
 */
public class AutoRetreat {

    public enum RetreatPhase { FIGHTING, RETREATING, HEALING, RETURNING }

    // ── Настройки ─────────────────────────────────────────────────
    private static final float  RETREAT_HP_THRESHOLD = 6.0f;
    private static final float  RETURN_HP_THRESHOLD  = 16.0f;
    private static final double RETREAT_DISTANCE     = 12.0; // блоков от цели
    private static final double RETREAT_SPEED        = 1.5;  // множитель скорости
    private static final int    HEAL_DURATION        = 60;   // тиков лечения
    private static final int    RETREAT_COOLDOWN     = 200;  // тиков между отступлениями

    // ── Состояние ─────────────────────────────────────────────────
    private RetreatPhase phase      = RetreatPhase.FIGHTING;
    private int          healTimer  = 0;
    private int          cooldown   = 0;
    private Vec3d        retreatPos = null;

    private final BotEntity bot;

    public AutoRetreat(BotEntity bot) {
        this.bot = bot;
    }

    public RetreatPhase getPhase() { return phase; }
    public boolean isRetreating()  { return phase != RetreatPhase.FIGHTING; }

    /**
     * Главный тик. Вызывается из BotDifficultyAI каждый тик.
     * Возвращает true если бот сейчас НЕ должен атаковать (отступает/лечится).
     */
    public boolean tick(LivingEntity target) {
        if (cooldown > 0) cooldown--;

        return switch (phase) {
            case FIGHTING   -> tickFighting(target);
            case RETREATING -> tickRetreating(target);
            case HEALING    -> tickHealing(target);
            case RETURNING  -> tickReturning(target);
        };
    }

    // ─────────────────────────────────────────────────────────────

    private boolean tickFighting(LivingEntity target) {
        // Проверяем нужно ли отступать
        if (cooldown <= 0 && bot.getHealth() <= RETREAT_HP_THRESHOLD) {
            startRetreat(target);
            return true;
        }
        return false;
    }

    private boolean tickRetreating(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }

        double dist = bot.distanceTo(target);

        if (dist >= RETREAT_DISTANCE) {
            // Достаточно далеко — начинаем лечиться
            phase = RetreatPhase.HEALING;
            healTimer = HEAL_DURATION;
            bot.getNavigation().stop();
        } else {
            // Бежим от цели
            Vec3d away = bot.getPos().subtract(target.getPos()).normalize().multiply(RETREAT_SPEED);
            bot.getNavigation().startMovingTo(
                bot.getX() + away.x * 5,
                bot.getY(),
                bot.getZ() + away.z * 5,
                1.6
            );
            // Снять цель — не атаковать во время бегства
            bot.setTarget(null);
        }
        return true;
    }

    private boolean tickHealing(LivingEntity target) {
        healTimer--;

        // Симулируем использование лечебного предмета
        useHealItem();

        if (healTimer <= 0 || bot.getHealth() >= RETURN_HP_THRESHOLD) {
            phase = RetreatPhase.RETURNING;
        }
        return true;
    }

    private boolean tickReturning(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }

        double dist = bot.distanceTo(target);

        if (dist <= PVPBotConfig.INSTANCE.attackRange + 1.0) {
            // Вернулись к цели
            phase = RetreatPhase.FIGHTING;
            cooldown = RETREAT_COOLDOWN;
            bot.setTarget(target);
            return false;
        }

        // Идём к цели
        bot.getNavigation().startMovingTo(target, 1.4);
        return true;
    }

    private void startRetreat(LivingEntity target) {
        phase = RetreatPhase.RETREATING;
        Vec3d away = bot.getPos().subtract(target.getPos()).normalize();
        retreatPos = bot.getPos().add(away.multiply(RETREAT_DISTANCE));
    }

    /** Использовать лечебный предмет из инвентаря. */
    private void useHealItem() {
        // Проверяем зелья/еду/золотые яблоки в инвентаре
        for (int i = 0; i < bot.getInventory().size(); i++) {
            ItemStack stack = bot.getInventory().getStack(i);
            if (stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE)) {
                // Используем — просто добавляем HP напрямую (симуляция)
                bot.heal(4.0f);
                stack.decrement(1);
                return;
            }
        }
        // Fallback — пассивная регенерация
        bot.heal(0.5f);
    }
}
