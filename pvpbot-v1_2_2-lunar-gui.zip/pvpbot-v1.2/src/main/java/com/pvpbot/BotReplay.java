package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.ArrayList;

/**
 * BotReplay — v16: запись последних 5 секунд боя.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Что записывается каждый тик:
 * ══════════════════════════════════════════════════════════════════
 *
 *  - Позиция бота (X, Y, Z)
 *  - HP бота
 *  - Позиция цели (если есть)
 *  - HP цели
 *  - Действие: IDLE / ATTACK / DODGE / RETREAT / FAKE / BUNKER
 *
 * ══════════════════════════════════════════════════════════════════
 *  /bot replay — выводит сжатый текстовый лог в чат:
 * ══════════════════════════════════════════════════════════════════
 *
 *  [0.0s] BOT(X=12.3,Y=64,Z=-8.1 HP=36) → TARGET(HP=28) ACTION=ATTACK
 *  [0.2s] BOT(X=12.1,Y=64,Z=-8.3 HP=36) → TARGET(HP=24) ACTION=DODGE
 *  ...
 *
 *  Выводится только каждые 4 тика (≈ 5 строк в секунду) для читаемости.
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class BotReplay {

    // ── Константы ─────────────────────────────────────────────────
    /** Тиков хранить (~5 сек = 100 тиков) */
    private static final int BUFFER_TICKS  = 100;
    /** Каждые N тиков пишем запись */
    private static final int RECORD_EVERY  = 2;
    /** Показываем каждые N тиков в replay (для сжатости) */
    private static final int DISPLAY_EVERY = 4;

    // ── Запись ────────────────────────────────────────────────────
    public static class Frame {
        public final float  tick;         // тик относительно начала буфера
        public final Vec3  botPos;
        public final float  botHp;
        public final Vec3  targetPos;    // null если нет цели
        public final float  targetHp;
        public final String action;

        Frame(float tick, Vec3 botPos, float botHp,
              Vec3 targetPos, float targetHp, String action) {
            this.tick      = tick;
            this.botPos    = botPos;
            this.botHp     = botHp;
            this.targetPos = targetPos;
            this.targetHp  = targetHp;
            this.action    = action;
        }
    }

    // ── Состояние ─────────────────────────────────────────────────
    private final Deque<Frame> buffer = new ArrayDeque<>();
    private int recordTimer = 0;
    private int globalTick  = 0;

    /** Текущее действие, которое ставят другие системы */
    private String currentAction = "IDLE";

    private final BotEntity bot;

    public BotReplay(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Вызывать каждый тик BotEntity
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        globalTick++;
        recordTimer++;

        if (recordTimer < RECORD_EVERY) return;
        recordTimer = 0;

        LivingEntity target = bot.getTarget();
        Vec3 targetPos = target != null ? target.getPos() : null;
        float targetHp  = target != null ? target.getHealth() : 0;

        Frame frame = new Frame(
            globalTick * 0.05f,        // tick * 0.05 = секунды
            bot.getPos(),
            bot.getHealth(),
            targetPos,
            targetHp,
            currentAction
        );

        buffer.addLast(frame);

        // Ограничиваем размер буфера
        while (buffer.size() > BUFFER_TICKS / RECORD_EVERY) {
            buffer.pollFirst();
        }

        // Сброс action в IDLE до следующего тика
        currentAction = "IDLE";
    }

    // ══════════════════════════════════════════════════════════════
    //  Установить текущее действие (вызывают другие системы)
    // ══════════════════════════════════════════════════════════════
    public void setAction(String action) {
        this.currentAction = action;
    }

    // ══════════════════════════════════════════════════════════════
    //  /bot replay — вывод в чат игроку
    // ══════════════════════════════════════════════════════════════
    public void printReplayToPlayer(ServerPlayer player) {
        if (buffer.isEmpty()) {
            player.sendMessage(Component.literal("§7[Replay] Нет данных."), false);
            return;
        }

        List<Frame> frames = new ArrayList<>(buffer);
        float startTime = frames.get(0).tick;

        player.sendMessage(Component.literal(
            "§6══════ BOT REPLAY (последние " + String.format("%.1f", frames.size() * RECORD_EVERY * 0.05f)
            + "с) ══════"), false);

        int shown = 0;
        for (int i = 0; i < frames.size(); i++) {
            // Показываем каждые DISPLAY_EVERY записей
            if (i % DISPLAY_EVERY != 0) continue;
            Frame f = frames.get(i);
            float t = f.tick - startTime;

            String botInfo = String.format("§fBOT §7[%.0f,%.0f,%.0f §cHP%.0f§7]",
                f.botPos.x, f.botPos.y, f.botPos.z, f.botHp);

            String targetInfo = "§7(нет цели)";
            if (f.targetPos != null) {
                double dist = f.botPos.distanceTo(f.targetPos);
                targetInfo = String.format("§7→ §fTGT §7[dist=%.1f §cHP%.0f§7]",
                    dist, f.targetHp);
            }

            String actionColor = switch (f.action) {
                case "ATTACK"  -> "§c";
                case "DODGE"   -> "§b";
                case "RETREAT" -> "§e";
                case "FAKE"    -> "§d";
                case "BUNKER"  -> "§6";
                default        -> "§7";
            };

            String line = String.format("§8[%.1fs] %s %s %s%s",
                t, botInfo, targetInfo, actionColor, f.action);

            player.sendMessage(Component.literal(line), false);
            shown++;

            if (shown >= 20) { // не спамим больше 20 строк
                player.sendMessage(Component.literal("§8... (ещё " + (frames.size()/DISPLAY_EVERY - shown) + " кадров)"), false);
                break;
            }
        }

        player.sendMessage(Component.literal("§6══════════════════════════════════"), false);
    }

    // ── Геттеры ───────────────────────────────────────────────────
    public int   getBufferSize() { return buffer.size(); }
    public boolean hasData()     { return !buffer.isEmpty(); }
}
