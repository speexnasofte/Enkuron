package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * PVPBotLogic — серверная PvP-логика для NPC-бота (BotEntity).
 *
 * Переписано в v1.2: убран весь Minecraft / client.options.
 * Теперь работает только на серверной стороне через BotEntity API.
 *
 * Вызывается из BotEntity.tick() когда есть цель.
 *
 * Что делает:
 *   - Находит ближайшего врага (не владельца, не своих ботов)
 *   - Крит-прыжок перед атакой (BotCritMeleeGoal уже делает это,
 *     PVPBotLogic дополняет логикой кулдауна и DPS-записи)
 *   - AutoHeal — NPC ест золотое яблоко когда HP низкое
 *   - AutoSprint — NPC всегда спринтует к цели
 *   - Dodge — уклонение velocity-импульсом в сторону
 *   - Strafe — навигация по дуге вокруг цели
 *   - FightAnalyzer / KillDeathTracker интеграция
 */
public class PVPBotLogic {

    private final PVPBotConfig cfg     = PVPBotConfig.INSTANCE;
    private final BotEntity    bot;

    private int     attackTimer   = 0;
    private int     dodgeTimer    = 0;
    private int     strafeTimer   = 0;
    private int     strafeDir     = 1;
    private boolean jumpedForCrit = false;

    // Отслеживаем смену цели для DPS
    private UUID lastTargetUUID = null;

    public PVPBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик — вызывать из BotEntity.tick()
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        if (!(bot.getWorld() instanceof ServerLevel sw)) return;

        if (attackTimer > 0) attackTimer--;
        if (dodgeTimer  > 0) dodgeTimer--;
        if (strafeTimer > 0) strafeTimer--;

        // ── AutoHeal: NPC ест гэпл при низком HP ─────────────────
        if (cfg.autoHeal) {
            tickAutoHeal(sw);
        }

        // ── AutoSprint ─────────────────────────────────────────────
        if (cfg.autoSprint && !bot.isSprinting() && !bot.isSneaking()) {
            bot.setSprinting(true);
        }

        // ── Цель ──────────────────────────────────────────────────
        LivingEntity target = findNearestEnemy(sw);

        if (target != null) {
            // DPS: отслеживаем смену цели
            UUID targetUUID = target.getUuid();
            if (!targetUUID.equals(lastTargetUUID)) {
                DpsMeter.INSTANCE.onTargetChanged(targetUUID);
                lastTargetUUID = targetUUID;
            }

            lookAtTarget(target);
            double dist = bot.distanceTo(target);

            // Dodge: уклонение когда враг слишком близко
            if (cfg.autoDodge && dist < cfg.dodgeRange && dodgeTimer <= 0) {
                dodge(target);
                dodgeTimer = 15;
            }

            // Атака
            if (cfg.autoAttack && dist <= cfg.attackRange && attackTimer <= 0) {
                tickAttack(sw, target);
            } else if (dist > cfg.attackRange) {
                // Идём к цели со страфом
                tickMoveWithStrafe(target);
            }

            // FightAnalyzer: отслеживаем бой
            if (cfg.statsEnabled) {
                FightAnalyzer.INSTANCE.onFightStart(target.getName().getString());
            }

        } else {
            lastTargetUUID = null;
            jumpedForCrit  = false;
            // Нет цели — останавливаем навигацию если BotHunt не активен
            if (!cfg.huntEnabled) {
                bot.getNavigation().stop();
            }
        }
    }

    // ── Крит-атака ────────────────────────────────────────────────
    private void tickAttack(ServerLevel sw, LivingEntity target) {
        if (bot.isOnGround() && !jumpedForCrit) {
            // Прыгаем для крита
            bot.getJumpControl().setActive();
            jumpedForCrit = true;
        } else if (jumpedForCrit && !bot.isOnGround()) {
            // В воздухе — бьём (крит = fallDistance > 0 && !onGround)
            bot.tryAttack(target);
            jumpedForCrit = false;

            float estimatedDamage = 7.0f; // Netherite sword base
            if (cfg.statsEnabled) {
                KillDeathTracker.recordHit(target.getUuid());
                DpsMeter.INSTANCE.recordDamage(target, estimatedDamage);
                FightAnalyzer.INSTANCE.onHit(estimatedDamage);
            }

            // Кулдаун с учётом AdaptiveCooldown
            attackTimer = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown()
                : cfg.attackCooldown;

        } else if (jumpedForCrit && bot.isOnGround()) {
            // Прыжок не получился (застряли) — сбрасываем
            jumpedForCrit = false;
        }
    }

    // ── Движение к цели со страфом ────────────────────────────────
    private void tickMoveWithStrafe(LivingEntity target) {
        // Меняем сторону страфа каждые strafeTimer тиков
        if (strafeTimer <= 0) {
            strafeDir  = -strafeDir;
            strafeTimer = 20 + bot.getWorld().getRandom().nextInt(15);
        }

        Vec3 toTarget = target.getPos().subtract(bot.getPos()).normalize();
        // Перпендикуляр — страф влево или вправо
        Vec3 strafe = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir)
            .multiply(0.15);

        Vec3 move = toTarget.multiply(0.25).add(strafe);
        bot.setVelocity(bot.getVelocity().add(move.x, 0, move.z));
        bot.velocityModified = true;

        // Навигация через pathfind
        bot.getNavigation().startMovingTo(target, 1.3);
    }

    // ── Поиск ближайшего врага ────────────────────────────────────
    private LivingEntity findNearestEnemy(ServerLevel sw) {
        Box searchBox = bot.getBoundingBox().expand(cfg.attackRange + 4.0);
        List<LivingEntity> entities = sw.getEntitiesByClass(
            LivingEntity.class, searchBox,
            e -> e != bot
                && e.isAlive()
                && !e.isInvisible()
                // Не атакуем владельца
                && !(e instanceof Player p
                     && bot.getOwner() != null
                     && p.getUuid().equals(bot.getOwner().getUuid()))
                // Не атакуем других ботов того же владельца
                && !(e instanceof BotEntity other
                     && bot.getOwner() != null
                     && bot.getOwner().getUuid().equals(
                         other.getOwner() != null ? other.getOwner().getUuid() : null))
                // Whitelist проверка
                && !isWhitelisted(e)
        );
        return entities.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);
    }

    // ── AutoHeal: NPC ест Golden Apple из инвентаря ───────────────
    private void tickAutoHeal(ServerLevel sw) {
        if (bot.getHealth() > cfg.botHealThreshold) return;

        // Ищем Golden Apple в снаряжении (equipStack)
        ItemStack gap = new ItemStack(Items.GOLDEN_APPLE);
        ItemStack main = bot.getEquippedStack(EquipmentSlot.MAINHAND);

        // Если уже держим гэпл — «едим» (восстанавливаем HP напрямую,
        // т.к. NPC не может использовать предметы как игрок)
        if (main.isOf(Items.GOLDEN_APPLE) || main.isOf(Items.ENCHANTED_GOLDEN_APPLE)) {
            // Применяем эффект вручную: +4 HP мгновенно (Instant Health I)
            bot.heal(4.0f);
            // Снимаем один гэпл из стека
            main.decrement(1);
            if (main.isEmpty()) {
                bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            }
            if (cfg.statsEnabled) {
                FightAnalyzer.INSTANCE.onGappleUsed();
            }
            return;
        }

        // Ищем гэпл и экипируем в руку
        // (полноценный инвентарь у NPC не реализован — берём из BotKit)
        bot.equipStack(EquipmentSlot.MAINHAND, gap);
    }

    // ── Dodge: velocity-импульс в сторону ─────────────────────────
    private void dodge(LivingEntity target) {
        Vec3 toEnemy  = target.getPos().subtract(bot.getPos()).normalize();
        Vec3 dodgeDir = new Vec3(-toEnemy.z, 0, toEnemy.x);
        bot.setVelocity(bot.getVelocity().add(
            dodgeDir.x * 0.5, 0.3, dodgeDir.z * 0.5
        ));
        bot.velocityModified = true;
    }

    // ── Поворот к цели ────────────────────────────────────────────
    private void lookAtTarget(LivingEntity target) {
        Vec3 diff  = target.getEyePos().subtract(bot.getEyePos());
        double hDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(diff.y, hDist));
        bot.setYaw(lerpAngle(bot.getYaw(), yaw, 0.35f));
        bot.setPitch(lerp(bot.getPitch(), pitch, 0.35f));
        bot.setHeadYaw(bot.getYaw());
        bot.setBodyYaw(bot.getYaw());
    }

    // ── Whitelist ─────────────────────────────────────────────────
    private boolean isWhitelisted(LivingEntity e) {
        if (!cfg.whitelistEnabled) return false;
        if (!(e instanceof Player p)) return false;
        return cfg.whitelist.contains(p.getName().getString());
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private float lerpAngle(float a, float b, float t) {
        float diff = ((b - a) % 360 + 540) % 360 - 180;
        return a + diff * t;
    }
}
