package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.effect.MobEffect;

/**
 * NethPotLogic — логика NethPot (Potion PvP) режима.
 *
 * NethPot особенности:
 *   - Железная броня (без шлема) + зелья вместо регена
 *   - Сплэш зелья: Harming II на врага, Healing II на себя
 *   - Speed II зелье для стрейфа
 *   - Fire Resistance при поджигании
 *   - Invisibility зелье при критическом HP (отрыв)
 *   - Ближний бой мечом между разливами
 *
 * Логика разлива:
 *   dist <= SPLASH_RANGE  → разливаем Harming на врага
 *   self HP < 10          → разливаем Healing на себя
 *   self HP < 6           → Invis + отрыв
 *   враг в огне           → Fire Resist на себя
 *
 * Автотайминг: зелья разливаются в оптимальный момент —
 *   когда враг стоит (низкая скорость) для максимального попадания.
 */
public class NethPotLogic {

    // ── Дистанции ─────────────────────────────────────────────────
    private static final double SPLASH_RANGE   = 4.5;  // дальность разлива
    private static final double MELEE_RANGE    = 3.0;
    private static final double OPTIMAL_SPLASH = 2.5;  // оптимум — почти вплотную

    // ── Кулдауны (тики) ──────────────────────────────────────────
    private static final int HARMING_CD  = 35;   // Harming II
    private static final int HEALING_CD  = 40;   // Healing II
    private static final int SPEED_CD    = 400;  // Speed II (долгий)
    private static final int FIRE_RES_CD = 600;  // Fire Resistance
    private static final int INVIS_CD    = 300;  // Invisibility
    private static final int MELEE_CD    = 8;    // удар мечом

    private final BotEntity bot;

    private int harmingCd  = 0;
    private int healingCd  = 0;
    private int speedCd    = 0;
    private int fireResCd  = 0;
    private int invisCd    = 0;
    private int meleeCd    = 0;

    private boolean hasSpeed   = false;
    private boolean hasFireRes = false;

    public NethPotLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.getWorld().isClient) return;
        if (!(bot.getWorld() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        // Кулдауны
        if (harmingCd > 0) harmingCd--;
        if (healingCd > 0) healingCd--;
        if (speedCd   > 0) speedCd--;
        if (fireResCd > 0) fireResCd--;
        if (invisCd   > 0) invisCd--;
        if (meleeCd   > 0) meleeCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── 1. Speed II в начале боя ───────────────────────────────
        if (speedCd <= 0 && !hasSpeed) {
            applySplashOnSelf(sw, MobEffects.SPEED, 800, 1); // Speed II 40сек
            hasSpeed = true;
            speedCd  = SPEED_CD;
        }

        // ── 2. Fire Resistance если горим ─────────────────────────
        if (bot.isOnFire() && fireResCd <= 0 && !hasFireRes) {
            applySplashOnSelf(sw, MobEffects.FIRE_RESISTANCE, 1200, 0);
            hasFireRes = true;
            fireResCd  = FIRE_RES_CD;
        }

        // ── 3. Invisibility + отрыв при критически низком HP ──────
        if (myHp < 6.0f && invisCd <= 0) {
            applySplashOnSelf(sw, MobEffects.INVISIBILITY, 600, 0);
            // Рывок прочь
            Vec3 away = bot.getPos().subtract(target.getPos()).normalize().multiply(0.5);
            bot.setVelocity(bot.getVelocity().add(away.x, 0.3, away.z));
            bot.velocityModified = true;
            invisCd = INVIS_CD;
            return;
        }

        // ── 4. Healing II на себя при низком HP ───────────────────
        if (myHp < 10.0f && healingCd <= 0) {
            applySplashOnSelf(sw, MobEffects.INSTANT_HEALTH, 1, 1); // Healing II
            healingCd = HEALING_CD;
        }

        // ── 5. Harming II на врага ─────────────────────────────────
        if (dist <= SPLASH_RANGE && harmingCd <= 0) {
            // Оптимальный момент: враг медленный или стоит
            boolean targetSlow = target.getVelocity().horizontalLengthSquared() < 0.04;
            boolean inRange    = dist <= OPTIMAL_SPLASH;

            if (inRange || targetSlow) {
                throwHarmingPotion(sw, target);
                harmingCd = HARMING_CD;
            }
        }

        // ── 6. Подходим для разлива ───────────────────────────────
        if (dist > OPTIMAL_SPLASH && dist <= SPLASH_RANGE * 1.5 && harmingCd > HARMING_CD / 2) {
            Vec3 dir = target.getPos().subtract(bot.getPos()).normalize().multiply(0.2);
            bot.setVelocity(bot.getVelocity().add(dir));
            bot.velocityModified = true;
        }

        // ── 7. Меч между разливами ────────────────────────────────
        if (dist <= MELEE_RANGE && meleeCd <= 0 && harmingCd > 5) {
            equipSword();
            bot.tryAttack(sw, target);
            meleeCd = MELEE_CD;
        }
    }

    // ── Разлив зелья вредности на цель ───────────────────────────
    private void throwHarmingPotion(ServerLevel sw, LivingEntity target) {
        // Harming II: ~12 урона сразу (как ванилла) + небольшой AoE
        float directDmg = 12.0f;
        float aoeDmg    = 6.0f;
        Vec3 targetPos = target.getPos();

        // Прямое попадание
        target.damage(sw, sw.getDamageSources().magic(), directDmg);

        // AoE — попадает в радиусе 2 блоков
        sw.getEntitiesByClass(LivingEntity.class,
            new Box(targetPos, targetPos).expand(2.0),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.damage(sw, sw.getDamageSources().magic(), aoeDmg));

        // Эффекты
        sw.spawnParticles(ParticleTypes.INSTANT_EFFECT,
            targetPos.x, targetPos.y + 1, targetPos.z,
            20, 0.5, 0.5, 0.5, 0.1);
        bot.playSound(SoundEvents.ENTITY_SPLASH_POTION_BREAK, 1.0f, 1.2f);
    }

    // ── Разлив зелья на себя ─────────────────────────────────────
    private void applySplashOnSelf(ServerLevel sw,
                                    net.minecraft.world.effect.MobEffect effect,
                                    int duration, int amplifier) {
        bot.addStatusEffect(new MobEffectInstance(
            net.minecraft.registry.entry.RegistryEntry.of(effect),
            duration, amplifier));

        sw.spawnParticles(ParticleTypes.EFFECT,
            bot.getX(), bot.getY() + 1, bot.getZ(),
            10, 0.3, 0.3, 0.3, 0.05);
        bot.playSound(SoundEvents.ENTITY_SPLASH_POTION_BREAK, 0.8f, 0.9f);
    }

    private void equipSword() {
        ItemStack cur = bot.getEquippedStack(EquipmentSlot.MAINHAND);
        if (!cur.isOf(Items.DIAMOND_SWORD))
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }
}
