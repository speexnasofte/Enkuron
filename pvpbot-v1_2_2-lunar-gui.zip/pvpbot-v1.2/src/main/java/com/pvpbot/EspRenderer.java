package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * ESP-рендерер: рисует хитбоксы сущностей сквозь стены.
 *
 * Цветовая схема:
 *   Игроки          — красный  (0xFF2222)
 *   NPC-боты        — золотой  (0xFFD700)
 *   Враждебные мобы — оранжевый (0xFF7700)
 *   Пассивные мобы  — зелёный  (0x44FF44)
 *
 * Рисуем только рёбра AABB (12 рёбер), без заливки.
 * Над каждой сущностью — нейминг (имя + HP).
 */
public class EspRenderer {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public void onWorldRender(WorldRenderContext context) {
        if (!cfg.espEnabled) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        PoseStack matrices = context.matrixStack();
        if (matrices == null) return;

        Camera camera = context.camera();
        Vec3 camPos  = camera.position();

        // Получаем все живые сущности в радиусе espRange
        double range = cfg.espRange;
        AABB searchBox = mc.player.getBoundingBox().expand(range);
        List<LivingEntity> entities = mc.level.getEntitiesByClass(
            LivingEntity.class, searchBox,
            e -> e != mc.player && e.isAlive()
        );

        if (entities.isEmpty()) return;

        com.mojang.blaze3d.vertex.Tesselator tess    = com.mojang.blaze3d.vertex.Tesselator.getInstance();
        com.mojang.blaze3d.vertex.BufferBuilder buf   = tess.begin(com.mojang.blaze3d.vertex.VertexFormat.Mode.DEBUG_LINES,
                                          com.mojang.blaze3d.vertex.DefaultVertexFormat.POSITION_COLOR);

        matrices.push();
        // Смещаемся в координаты камеры
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        Matrix4f mat = matrices.peek().getPositionMatrix();

        RenderSystem.disableDepthTest();        // сквозь стены
        RenderSystem.lineWidth(cfg.espLineWidth);

        for (LivingEntity e : entities) {
            if (e == mc.player) continue;
            int color = getEspColor(e);
            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8)  & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;
            float a = 0.9f;

            // Интерполируем позицию для плавности
            float delta = context.tickCounter().getTickDelta(true);
            double ex = e.prevX + (e.getX() - e.prevX) * delta;
            double ey = e.prevY + (e.getY() - e.prevY) * delta;
            double ez = e.prevZ + (e.getZ() - e.prevZ) * delta;

            AABB bb = e.getBoundingBox();
            double w = (bb.maxX - bb.minX) / 2.0;
            double h = bb.maxY - bb.minY;

            drawBox(buf, mat,
                ex - w, ey, ez - w,
                ex + w, ey + h, ez + w,
                r, g, b, a);
        }

        // Рисуем
        BufferRenderer.drawWithGlobalProgram(buf.end());

        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(1.0f);
        matrices.pop();
    }

    /** Рисует 12 рёбер AABB */
    private void drawBox(com.mojang.blaze3d.vertex.BufferBuilder buf, Matrix4f mat,
                         double x1, double y1, double z1,
                         double x2, double y2, double z2,
                         float r, float g, float b, float a) {
        float fx1 = (float)x1, fy1 = (float)y1, fz1 = (float)z1;
        float fx2 = (float)x2, fy2 = (float)y2, fz2 = (float)z2;

        // Нижний прямоугольник
        line(buf, mat, fx1,fy1,fz1, fx2,fy1,fz1, r,g,b,a);
        line(buf, mat, fx2,fy1,fz1, fx2,fy1,fz2, r,g,b,a);
        line(buf, mat, fx2,fy1,fz2, fx1,fy1,fz2, r,g,b,a);
        line(buf, mat, fx1,fy1,fz2, fx1,fy1,fz1, r,g,b,a);
        // Верхний прямоугольник
        line(buf, mat, fx1,fy2,fz1, fx2,fy2,fz1, r,g,b,a);
        line(buf, mat, fx2,fy2,fz1, fx2,fy2,fz2, r,g,b,a);
        line(buf, mat, fx2,fy2,fz2, fx1,fy2,fz2, r,g,b,a);
        line(buf, mat, fx1,fy2,fz2, fx1,fy2,fz1, r,g,b,a);
        // Вертикальные рёбра
        line(buf, mat, fx1,fy1,fz1, fx1,fy2,fz1, r,g,b,a);
        line(buf, mat, fx2,fy1,fz1, fx2,fy2,fz1, r,g,b,a);
        line(buf, mat, fx2,fy1,fz2, fx2,fy2,fz2, r,g,b,a);
        line(buf, mat, fx1,fy1,fz2, fx1,fy2,fz2, r,g,b,a);
    }

    private void line(com.mojang.blaze3d.vertex.BufferBuilder buf, Matrix4f mat,
                      float x1, float y1, float z1,
                      float x2, float y2, float z2,
                      float r, float g, float b, float a) {
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a);
    }

    private int getEspColor(LivingEntity e) {
        if (e instanceof Player)  return 0xFF2222; // красный
        if (e instanceof BotEntity)     return 0xFFD700; // золотой
        if (e instanceof net.minecraft.world.entity.monster.Monster) return 0xFF7700; // оранжевый
        return 0x44FF44; // зелёный — пассивные
    }
}
