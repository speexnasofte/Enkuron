package com.pvpbot;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Главный класс мода v6 — добавлено:
 *   ESP хитбоксы       (EspRenderer)
 *   Radar HUD          (RadarHud)
 *   K/D статистика     (KillDeathTracker)
 *   AutoBow            (AutoBow, в PVPBotLogic)
 *   Кайтинг            (KiteLogic, в PVPBotLogic)
 *   Улучшенный pathfind (BotPathfindGoal, в BotEntity)
 */
public class PVPBotMod implements ModInitializer, ClientModInitializer {

    public static KeyBinding toggleKey;
    public static KeyBinding settingsKey;

    // v1.2: PVPBotLogic теперь живёт в BotEntity, не здесь
    private final PVPBotConfig cfg        = PVPBotConfig.INSTANCE;
    private final AutoRespawn autoRespawn = new AutoRespawn();
    private final RadarHud radarHud       = new RadarHud();  // NEW

    // ── Серверная инициализация ──────────────────────────────────
    @Override
    public void onInitialize() {
        BotConfig.load(); // загружает конфиг и синхронизирует ModuleManager
        BotEntityType.register();
        FabricDefaultAttributeRegistry.register(
            BotEntityType.BOT_ENTITY,
            BotEntity.createAttributes()
        );
        SpawnBotCommand.register();

        // v16: DuelTimer — тикаем на сервере
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            DuelTimer.INSTANCE.tick(server);
        });
    }

    // ── Клиентская инициализация ─────────────────────────────────
    @Override
    public void onInitializeClient() {
        // Клавиши
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.pvpbot"
        ));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpbot.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.pvpbot"
        ));

        // HUD (основная панель + радар)
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            new PVPBotHud().onHudRender(ctx, ticker); // основной HUD
        });
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            var mc = net.minecraft.client.MinecraftClient.getInstance();
            radarHud.render(ctx, mc);                 // радар
        });

        // ESP — рендер в мире (сквозь стены)
        WorldRenderEvents.END.register(new EspRenderer());

        // K/D трекер
        KillDeathTracker.register();
        DpsMeter.INSTANCE.register(); // v9
        BotSkinManager.INSTANCE.register(); // v9

        // Тик-цикл
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            autoRespawn.tick(client);

            while (toggleKey.wasPressed()) {
                cfg.enabled = !cfg.enabled;
                BotConfig.save();
                if (client.player != null) {
                    client.player.sendMessage(
                        Text.literal(cfg.enabled
                            ? "§a[PVPBot] §fВключён!"
                            : "§c[PVPBot] §fВыключен!"), true);
                }
            }

            while (settingsKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new PVPBotScreen(null));
                }
            }

            // v1.2: логика бота тикается в BotEntity.tick() на сервере
        });
    }
}
