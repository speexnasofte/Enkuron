package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;

/**
 * SwordLogic — логика классического Sword PvP режима.
 *
 * Sword PvP особенности:
 *   - W-Tap: отпускаем движение вперёд на 1-2 тика после удара
 *     для сброса атакового кулдауна (momentum reset)
 *   - Критические удары: прыгаем перед ударом для крит-урона (x1.5)
 *   - Стрейф: постоянное движение боком для уклонения
 *   - Расстояние: держим ~2-2.5 блока (sword range)
 *   - Перлы при дистанции > 8 (приближение)
 *
 * W-Tap алгоритм:
 *   1. Атакуем (полный кулдаун)
 *   2. Отпускаем вперёд на wTapTicks (1-2 тика)
 *   3. Снова вперёд — velocity reset сбрасывает knockback
 *
 * Крит алгоритм:
 *   1. Прыгаем (setVelocity Y+)
 *   2. На пике прыжка — атакуем (урон x1.5 + крит-частицы)
 */
public class SwordLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double MELEE_RANGE     = 3.0;
    private static final double IDEAL_DIST      = 2.2;
    // Фикс v1.2.1: кулдаун берём из AdaptiveCooldown через BotDifficultyAI
    // ATTACK_CD оставлен как fallback для случаев без бота
    private static final int    ATTACK_CD       = 10;
    private static final int    WTAP_TICKS      = 2;    // тиков W-Tap паузы
    private static final int    CRIT_INTERVAL   = 3;    // каждый N-й удар — крит
    private static final int    STRAFE_FLIP     = 18;
    private static final int    PEARL_CD        = 60;

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd    = 0;
    private int wTapPause   = 0;    // тики паузы W-Tap
    private int strafeTimer = 0;
    private int strafeDir   = 1;
    private int hitCount    = 0;    // счётчик ударов (для крита)
    private int pearlCd     = 0;
    private boolean inCrit  = false;// сейчас в прыжке для крита

    public SwordLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClient) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        // Кулдауны
        if (attackCd  > 0) attackCd--;
        if (wTapPause > 0) wTapPause--;
        if (strafeTimer > 0) strafeTimer--;
        if (pearlCd   > 0) pearlCd--;

        double dist = bot.distanceTo(target);

        // Экипируем нетеритовый меч
        equipSword();

        // ── Перл для сближения ────────────────────────────────────
        if (dist > 8.0 && pearlCd <= 0) {
            Vec3 aim = MotionPredictor.predict(target, 5);
            bot.teleport(aim.x, aim.y, aim.z);
            pearlCd = PEARL_CD;
            return;
        }

        // ── Стрейф ────────────────────────────────────────────────
        doStrafe(target);

        // ── Позиционирование ──────────────────────────────────────
        doPositioning(target, dist);

        // ── W-Tap пауза (не двигаемся вперёд) ────────────────────
        if (wTapPause > 0) return; // не атакуем и не двигаемся вперёд

        // ── Атака ─────────────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            boolean doCrit = (hitCount % CRIT_INTERVAL == 0);

            if (doCrit && !inCrit) {
                doCritJump(sw, target);
            } else if (!doCrit || inCrit) {
                doAttack(sw, target, doCrit && inCrit);
            }
        }
    }

    // ── Стрейф влево-вправо ───────────────────────────────────────
    private void doStrafe(LivingEntity target) {
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = STRAFE_FLIP + bot.level().getRandom().nextInt(8);
        }

        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 strafe   = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);
        bot.setVelocity(bot.getVelocity().add(strafe.scale(0.14)));
        bot.velocityModified = true;
    }

    // ── Позиционирование на идеальной дистанции ───────────────────
    private void doPositioning(LivingEntity target, double dist) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        if (dist > IDEAL_DIST + 0.5) {
            // Приближаемся
            bot.setVelocity(bot.getVelocity().add(toTarget.scale(0.16)));
        } else if (dist < IDEAL_DIST - 0.3) {
            // Отступаем
            bot.setVelocity(bot.getVelocity().add(toTarget.scale(-0.12)));
        }
        bot.velocityModified = true;
    }

    // ── Крит прыжок ───────────────────────────────────────────────
    private void doCritJump(ServerLevel sw, LivingEntity target) {
        // Прыжок вверх
        Vec3 vel = bot.getVelocity();
        bot.setVelocity(vel.x, 0.42, vel.z);
        bot.velocityModified = true;
        inCrit = true;

        // Атакуем на следующем тике (следующий tick() когда inCrit=true)
        // Откладываем: attackCd = 1 чтобы атаковать в следующий тик при падении
        attackCd = 1;
    }

    // ── Обычный удар / крит удар ──────────────────────────────────
    private void doAttack(ServerLevel sw, LivingEntity target, boolean isCrit) {
        if (!(sw instanceof ServerLevel)) return;

        float dmg = isCrit ? 10.5f : 7.0f; // крит = x1.5 базового

        target.hurt(sw, sw.getDamageSources().playerAttack(null), dmg);

        if (isCrit) {
            // Крит-частицы
            sw.spawnParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(),
                8, 0.3, 0.3, 0.3, 0.15);
            bot.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_ATTACK_CRIT,
                1.0f, 1.0f);
            inCrit = false;
        } else {
            bot.playSound(net.minecraft.sound.SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                0.8f, 1.0f);
        }

        hitCount++;
        // Фикс v1.2.1: используем AdaptiveCooldown если доступен
        attackCd  = PVPBotConfig.INSTANCE.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : ATTACK_CD;
        wTapPause = WTAP_TICKS; // W-Tap пауза после удара
    }

    private void equipSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.NETHERITE_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
    }
}
