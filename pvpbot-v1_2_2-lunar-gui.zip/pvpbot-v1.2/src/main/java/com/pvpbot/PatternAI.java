package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * PatternAI — v14: Обучение паттернам движения противника.
 *
 * Бот запоминает историю позиций цели (скользящее окно)
 * и вычисляет среднее направление/скорость движения.
 * На основе этого адаптирует свой страф — бежит «навстречу»
 * куда движется враг, или обходит с другой стороны.
 *
 * Также реализует АнтиПаттерн — рандомизацию собственного
 * поведения чтобы противник не мог «прочитать» бота.
 */
public class PatternAI {

    // ── Настройки ─────────────────────────────────────────────────
    private static final int   HISTORY_SIZE       = 20;  // тиков истории
    private static final int   PREDICT_AHEAD      = 5;   // тиков вперёд
    private static final double MIN_SPEED_THRESHOLD = 0.05; // мин. скорость для паттерна

    // АнтиПаттерн — рандомизация поведения бота
    private static final int   ANTI_PATTERN_INTERVAL_MIN = 30;
    private static final int   ANTI_PATTERN_INTERVAL_MAX = 80;

    // ── Состояние ─────────────────────────────────────────────────
    private final Deque<Vec3> posHistory = new ArrayDeque<>();
    private Vec3 predictedPos = null;    // предсказанная позиция цели
    private Vec3 avgVelocity  = Vec3.ZERO;

    // АнтиПаттерн
    private int   antiPatternTimer   = 40;
    private float antiPatternYawBias = 0f;  // случайное смещение страфа бота
    private boolean antiActive       = false;

    private final BotEntity bot;

    public PatternAI(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Обновить историю позиций цели.
     * Вызывать каждый тик из BotEntity.tick() когда есть цель.
     */
    public void update(LivingEntity target) {
        Vec3 pos = target.getPos();
        posHistory.addLast(pos);
        if (posHistory.size() > HISTORY_SIZE) {
            posHistory.pollFirst();
        }

        // Вычислить среднюю скорость за последние тики
        avgVelocity = computeAvgVelocity();

        // Предсказать позицию через PREDICT_AHEAD тиков
        predictedPos = pos.add(avgVelocity.multiply(PREDICT_AHEAD));

        // АнтиПаттерн тик
        tickAntiPattern();
    }

    /**
     * Получить предсказанную позицию цели (для броска перлов/зелий).
     * Возвращает текущую позицию цели если данных недостаточно.
     */
    public Vec3 getPredictedPosition(LivingEntity target) {
        if (predictedPos == null || posHistory.size() < 5) {
            return target.getPos();
        }
        return predictedPos;
    }

    /**
     * Получить адаптированное направление страфа.
     * Возвращает угол страфа с учётом движения противника.
     * @param baseYaw  базовый yaw бота
     * @param strafeLeft текущая сторона страфа
     * @return адаптированный yaw-offset для страфа
     */
    public double getAdaptedStrafeYaw(float baseYaw, boolean strafeLeft) {
        double base = strafeLeft ? -90.0 : 90.0;

        // Если движение противника достаточно быстрое — адаптируем
        double speed = avgVelocity.horizontalLength();
        if (speed > MIN_SPEED_THRESHOLD && posHistory.size() >= 10) {
            // Вычислить угол движения противника
            double enemyAngle = Math.toDegrees(Math.atan2(-avgVelocity.x, avgVelocity.z));
            // Смещаем страф в сторону движения противника (перехват)
            double diff = angleDiff(enemyAngle, baseYaw);
            base += diff * 0.3; // 30% адаптации
        }

        // АнтиПаттерн: добавляем случайное смещение
        base += antiPatternYawBias;

        return base;
    }

    /**
     * Оценить насколько предсказуемо текущее движение врага (0..1).
     * 1.0 = очень предсказуем (прямолинейно), 0.0 = хаотично.
     */
    public float getEnemyPredictability() {
        if (posHistory.size() < 8) return 0.5f;

        // Вычислить дисперсию угла движения
        List<Double> angles = new ArrayList<>();
        Vec3[] arr = posHistory.toArray(new Vec3[0]);
        for (int i = 1; i < arr.length; i++) {
            Vec3 delta = arr[i].subtract(arr[i - 1]);
            if (delta.horizontalLength() > 0.01) {
                angles.add(Math.toDegrees(Math.atan2(-delta.x, delta.z)));
            }
        }
        if (angles.size() < 3) return 0.5f;

        double mean = angles.stream().mapToDouble(d -> d).average().orElse(0);
        double variance = angles.stream()
            .mapToDouble(a -> (a - mean) * (a - mean))
            .average().orElse(0);
        // Нормализуем: 0 дисперсия = 1.0 предсказуемость
        return (float) Math.max(0, 1.0 - Math.min(variance / 900.0, 1.0));
    }

    /** Сброс истории при смене цели. */
    public void reset() {
        posHistory.clear();
        predictedPos = null;
        avgVelocity = Vec3.ZERO;
    }

    /** Активна ли АнтиПаттерн рандомизация. */
    public boolean isAntiPatternActive() { return antiActive; }

    // ── Внутренняя логика ─────────────────────────────────────────

    private Vec3 computeAvgVelocity() {
        if (posHistory.size() < 2) return Vec3.ZERO;

        Vec3[] arr = posHistory.toArray(new Vec3[0]);
        Vec3 sum = Vec3.ZERO;
        int count = 0;
        for (int i = arr.length - 1; i > 0 && i > arr.length - 8; i--) {
            sum = sum.add(arr[i].subtract(arr[i - 1]));
            count++;
        }
        return count > 0 ? sum.multiply(1.0 / count) : Vec3.ZERO;
    }

    private void tickAntiPattern() {
        antiPatternTimer--;
        if (antiPatternTimer <= 0) {
            // Сменить случайное смещение страфа бота
            Random rnd = new Random();
            antiPatternYawBias = (rnd.nextFloat() - 0.5f) * 40f; // ±20 градусов
            antiActive = rnd.nextBoolean(); // иногда вообще не страфаем предсказуемо

            antiPatternTimer = ANTI_PATTERN_INTERVAL_MIN
                + rnd.nextInt(ANTI_PATTERN_INTERVAL_MAX - ANTI_PATTERN_INTERVAL_MIN);
        }
    }

    private double angleDiff(double a, double b) {
        double diff = ((a - b) % 360 + 540) % 360 - 180;
        return diff;
    }
}
