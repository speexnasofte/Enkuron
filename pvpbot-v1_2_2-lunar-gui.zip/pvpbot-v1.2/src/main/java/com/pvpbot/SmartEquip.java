package com.pvpbot;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;

import java.util.*;

/**
 * SmartEquip v10 — умная экипировка бота из инвентаря.
 *
 * Расширяет /bot equip: вместо жёсткой выдачи неритовского сета
 * анализирует инвентарь бота и надевает лучшее из доступного.
 *
 * Логика:
 *   1. Для каждого слота брони (HEAD/CHEST/LEGS/FEET) выбираем предмет
 *      с максимальным показателем защиты (ArmorItem.getProtection()).
 *   2. Для MAINHAND выбираем оружие с максимальным attack_damage.
 *   3. Учитываем зачарования: добавляем Protection/Sharpness к базовым значениям.
 *   4. Если в инвентаре ничего нет — выдаём неритовский дефолт (старое поведение).
 *
 * Интеграция:
 *   - SmartEquip.equip(bot, world) вызывается в SpawnBotCommand.equipBot()
 *     вместо giveDefaultEquipment(bot).
 *   - Команда /bot equip [smart] — если параметр указан, использует SmartEquip,
 *     иначе — старый дефолт (обратная совместимость).
 */
public class SmartEquip {

    private SmartEquip() {}

    // ── Слот → подходящие типы предметов ────────────────────────

    private static final Map<EquipmentSlot, Class<?>> SLOT_TYPES = new LinkedHashMap<>();
    static {
        SLOT_TYPES.put(EquipmentSlot.HEAD,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.CHEST,     ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.LEGS,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.FEET,      ArmorItem.class);
        SLOT_TYPES.put(EquipmentSlot.MAINHAND,  null); // weapons — отдельная логика
    }

    /**
     * Основной метод. Берёт предметы из инвентаря бота или создаёт дефолтные.
     *
     * @param bot   целевой бот
     * @param world серверный мир (нужен для EnchantmentHelper)
     */
    public static void equip(BotEntity bot, ServerLevel world) {
        net.minecraft.entity.mob.MobEntity mob = bot;
        var inv = bot.getInventory();

        // Собираем все стеки из инвентаря
        List<ItemStack> available = new ArrayList<>();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) available.add(s.copy());
        }

        // Броня
        for (EquipmentSlot slot : new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack best = bestArmorFor(slot, available, world);
            if (best != null) {
                bot.equipStack(slot, best);
            } else {
                bot.equipStack(slot, defaultArmor(slot));
            }
        }

        // Оружие
        ItemStack bestWeapon = bestWeapon(available, world);
        if (bestWeapon != null) {
            bot.equipStack(EquipmentSlot.MAINHAND, bestWeapon);
        } else {
            bot.equipStack(EquipmentSlot.MAINHAND,
                new ItemStack(Items.NETHERITE_SWORD));
        }
    }

    // ── Выбор лучшей брони ───────────────────────────────────────

    private static ItemStack bestArmorFor(EquipmentSlot slot,
                                          List<ItemStack> pool,
                                          ServerLevel world) {
        ItemStack best = null;
        double bestScore = -1;

        for (ItemStack s : pool) {
            if (!(s.getItem() instanceof ArmorItem ai)) continue;
            if (ai.getSlotType() != slot) continue;

            double score = ai.getProtection();
            // Добавляем бонус Protection
            score += enchantBonus(s, world, "protection") * 0.5;

            if (score > bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    // ── Выбор лучшего оружия ─────────────────────────────────────

    private static ItemStack bestWeapon(List<ItemStack> pool, ServerLevel world) {
        ItemStack best = null;
        double bestScore = -1;

        for (ItemStack s : pool) {
            Item item = s.getItem();
            // Принимаем мечи, топоры и трезубцы
            if (!(item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem)) continue;

            // Базовый урон через атрибуты
            double base = getBaseDamage(s);
            double score = base + enchantBonus(s, world, "sharpness") * 0.8;

            if (score > bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    // ── Базовый урон ─────────────────────────────────────────────

    private static double getBaseDamage(ItemStack stack) {
        // Используем стандартный атрибут attack_damage
        var attrs = stack.getItem().getAttributeModifiers();
        double base = 1.0;
        for (var entry : attrs.modifiers()) {
            if (entry.attribute().value() == net.minecraft.entity.attribute.Attributes.ATTACK_DAMAGE) {
                base += entry.modifier().value();
            }
        }
        return base;
    }

    // ── Бонус зачарования ────────────────────────────────────────

    private static int enchantBonus(ItemStack stack, ServerLevel world, String enchantId) {
        try {
            var reg = world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
            for (var entry : reg.getIndexedEntries()) {
                if (entry.registryKey().getValue().getPath().equals(enchantId)) {
                    return EnchantmentHelper.getLevel(entry, stack);
                }
            }
        } catch (Exception ignored) {}
        return 0;
    }

    // ── Дефолтное снаряжение (fallback) ─────────────────────────

    private static ItemStack defaultArmor(EquipmentSlot slot) {
        return new ItemStack(switch (slot) {
            case HEAD  -> Items.NETHERITE_HELMET;
            case CHEST -> Items.NETHERITE_CHESTPLATE;
            case LEGS  -> Items.NETHERITE_LEGGINGS;
            case FEET  -> Items.NETHERITE_BOOTS;
            default    -> Items.AIR;
        });
    }
}
