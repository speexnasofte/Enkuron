package com.pvpbot;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.navigation.PathNavigation;
import net.minecraft.world.entity.navigation.Path;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;

import java.util.*;

/**
 * BotPathfindGoal — улучшенный pathfinding с прыжками через блоки.
 *
 * Проблема стандартного MC pathfinding:
 *   NavigationMob использует базовый PathNodeMaker, который не всегда
 *   прыгает через 1-блочные препятствия и застревает.
 *
 * Наш подход:
 *   1. Используем встроенный Navigation (он уже умеет в стены и прыжки)
 *   2. Добавляем систему "unstuck": если бот не движется 2 сек — телепортируем
 *   3. При достижении владельца (< 4 блока) — останавливаем
 *   4. Jump-assist: если впереди блок высотой 1 — принудительно прыгаем
 */
public class BotPathfindGoal extends Goal {

    private final BotEntity bot;
    private final double speed;
    private final float maxDist;
    private final float minDist;

    private Player owner;

    // Unstuck система
    private Vec3 lastPos         = null;
    private int   stuckTimer      = 0;
    private static final int STUCK_THRESHOLD = 40; // 2 сек без движения

    // Прыжки через препятствия
    private int jumpCooldown = 0;

    public BotPathfindGoal(BotEntity bot, double speed, float maxDist, float minDist) {
        this.bot     = bot;
        this.speed   = speed;
        this.maxDist = maxDist;
        this.minDist = minDist;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (bot.getTarget() != null) return false;
        owner = bot.getOwner();
        if (owner == null) return false;
        return owner.distanceToSqr(bot) > (minDist * minDist);
    }

    @Override
    public boolean shouldContinue() {
        if (bot.getTarget() != null) return false;
        if (owner == null) return false;
        double d = owner.distanceToSqr(bot);
        return d > (minDist * minDist) && d < (maxDist * maxDist * 16);
    }

    @Override
    public void start() {
        stuckTimer = 0;
        lastPos    = bot.position();
        navigate();
    }

    @Override
    public void stop() {
        bot.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (owner == null) return;

        bot.getLookControl().lookAt(owner, 10f, bot.getMaxLookPitchChange());

        jumpCooldown--;

        // Обновляем путь каждые 10 тиков
        if (bot.age % 10 == 0) {
            navigate();
        }

        // Jump-assist: проверяем блок впереди
        if (jumpCooldown <= 0 && bot.onGround()) {
            checkAndJump();
        }

        // Unstuck: если не двигаемся — принудительно телепортируем или прыгаем
        Vec3 curr = bot.position();
        if (lastPos != null) {
            double moved = curr.distanceToSqr(lastPos);
            if (moved < 0.01) {
                stuckTimer++;
                if (stuckTimer > STUCK_THRESHOLD) {
                    unstuck();
                    stuckTimer = 0;
                }
            } else {
                stuckTimer = 0;
            }
        }
        lastPos = curr;
    }

    private void navigate() {
        if (owner == null) return;
        double dist = bot.distanceTo(owner);

        // Formations v10/v11: используем смещённую целевую позицию
        Vec3 target = BotFormations.INSTANCE.getTargetPos(bot, 0, 1, owner);

        if (dist > 48.0) {
            // Телепорт если очень далеко
            bot.teleportTo(target.x, target.y, target.z);
        } else {
            bot.getNavigation().moveTo(target.x, target.y, target.z, speed);
        }
    }

    /**
     * Проверяем есть ли блок высотой 1 впереди — если да, прыгаем.
     * "Впереди" = 1.5 блока по направлению движения.
     */
    private void checkAndJump() {
        Vec3 vel = bot.getDeltaMovement();
        if (vel.horizontalLengthSquared() < 0.01) return; // не движемся

        Vec3 dir = new Vec3(vel.x, 0, vel.z).normalize();
        World world = bot.level();

        // Позиция на 1 блок вперёд у ног
        BlockPos ahead = BlockPos.ofFloored(
            bot.getX() + dir.x * 1.0,
            bot.getY(),
            bot.getZ() + dir.z * 1.0
        );

        // Если блок впереди на уровне ног — прыгаем
        BlockState stateAhead = world.getBlockState(ahead);
        BlockState stateAbove = world.getBlockState(ahead.up());

        if (!stateAhead.isAir() && stateAbove.isAir()) {
            // Блок высотой ≤ 1, над ним свободно — прыгаем
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.42, bot.getDeltaMovement().z);
            bot.velocityModified = true;
            jumpCooldown = 10;
        }
    }

    /**
     * Unstuck: пробуем выпрыгнуть или телепортируемся к владельцу.
     */
    private void unstuck() {
        if (owner == null) return;
        double dist = bot.distanceTo(owner);

        if (dist < 20.0) {
            // Попытка прыжка
            bot.setDeltaMovement(
                (owner.getX() - bot.getX()) * 0.2,
                0.5,
                (owner.getZ() - bot.getZ()) * 0.2
            );
            bot.velocityModified = true;
        } else {
            // Телепорт к владельцу
            bot.teleportTo(owner.getX(), owner.getY(), owner.getZ());
        }

        navigate();
    }
}
