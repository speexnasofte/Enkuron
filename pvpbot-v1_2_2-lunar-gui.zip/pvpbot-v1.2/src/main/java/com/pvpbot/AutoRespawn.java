package com.pvpbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.text.Text;

/**
 * Авто-респавн: обнаруживает экран смерти и автоматически нажимает «Respawn».
 * Работает через tickDelay чтобы избежать гонки на открытии экрана.
 */
public class AutoRespawn {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int deathTimer = 0;
    private boolean wasDead = false;

    public void tick(MinecraftClient mc) {
        if (!cfg.autoRespawn) {
            deathTimer = 0;
            wasDead = false;
            return;
        }

        // Если открыт экран смерти — считаем тики
        if (mc.currentScreen instanceof DeathScreen) {
            deathTimer++;

            // Ждём 20 тиков (1 сек) чтобы сервер успел зарегистрировать смерть
            if (deathTimer >= 20 && !wasDead) {
                wasDead = true;
                // Отправляем пакет респавна
                if (mc.player != null) {
                    mc.player.requestRespawn();
                    mc.setScreen(null);

                    // Уведомление в чат после возрождения
                    if (mc.player != null) {
                        mc.player.sendMessage(
                            Text.literal("§a[PVPBot] §fАвто-респавн активирован!"),
                            true
                        );
                    }
                }
            }
        } else {
            // Экран смерти закрыт — сбрасываем
            if (wasDead) {
                wasDead = false;
                deathTimer = 0;
            } else {
                deathTimer = 0;
            }
        }
    }
}
