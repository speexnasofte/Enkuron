package com.pvpbot;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Трекер kills / deaths / assists для клиентского игрока.
 *
 * Kill:   враг умер пока мы его атаковали (lastAttackedTick < 40 тиков назад)
 * Death:  наш игрок умер
 * Assist: враг умер < 100 тиков после нашего удара, но не мы финальный
 *
 * Сохраняется в сессии (сбрасывается при ресетТе через /bot stats reset).
 */
public class KillDeathTracker {

    public static int kills   = 0;
    public static int deaths  = 0;
    public static int assists = 0;

    // Тик последней атаки нами по каждому игроку (UUID → gameTick)
    private static final java.util.Map<java.util.UUID, Integer> lastHitTick =
        new java.util.HashMap<>();

    private static int gameTick = 0;
    private static boolean wasDead = false;

    // Регистрируем ивенты — вызывается из PVPBotMod
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            gameTick++;

            PlayerEntity player = client.player;

            // Детектим смерть игрока
            if (player.isDead() && !wasDead) {
                deaths++;
                wasDead = true;
                showMessage(client, "§c☠ Вы погибли! §7[" + deaths + "смертей]");
            }
            if (!player.isDead()) wasDead = false;

            // Детектим убийство / ассист: проверяем мёртвых врагов
            client.world.getEntitiesByClass(
                net.minecraft.entity.LivingEntity.class,
                player.getBoundingBox().expand(64.0),
                e -> e != player && e.isDead()
            ).forEach(e -> {
                java.util.UUID uid = e.getUuid();
                if (!lastHitTick.containsKey(uid)) return;

                int hitTick = lastHitTick.remove(uid);
                int delta   = gameTick - hitTick;

                if (delta < 40) {
                    // Финальный удар — kill
                    kills++;
                    String name = e.getName().getString();
                    showMessage(client, "§a⚔ Kill! §f" + name
                        + "  §7[K:" + kills + " D:" + deaths + "]");
                    // v1.2: FightAnalyzer — выводим разбор боя
                    FightAnalyzer.INSTANCE.onFightEnd(name, client);
                } else if (delta < 100) {
                    // Ударили недавно, но не финальный — assist
                    assists++;
                    showMessage(client, "§e✦ Assist §7[" + assists + "]");
                }
            });

            // Записываем наши удары (обновляется в PVPBotLogic через recordHit)
        });
    }

    /** Вызывается из PVPBotLogic при каждой атаке */
    public static void recordHit(java.util.UUID targetUUID) {
        lastHitTick.put(targetUUID, gameTick);
    }

    public static void reset() {
        kills = deaths = assists = 0;
        lastHitTick.clear();
    }

    public static double getKD() {
        return deaths == 0 ? kills : (double) kills / deaths;
    }

    private static void showMessage(MinecraftClient mc, String msg) {
        if (mc.player != null) {
            mc.player.sendMessage(net.minecraft.text.Text.literal("§e[PVPBot] §f" + msg), true);
        }
    }
}
