package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

import java.util.EnumSet;

/**
 * Цель ИИ: бот «ест» лечебный предмет (golden_apple или из инвентаря),
 * когда его HP падает ниже botHealThreshold.
 *
 * v4.1 — улучшения:
 *   • Проигрывает анимацию поедания (OFFHAND на несколько тиков)
 *   • Ищет лечебный предмет в инвентаре бота перед heal()
 *   • Убирает предмет после использования (симуляция поедания)
 *   • Cooldown 3 сек, анимация 1.5 сек
 */
public class BotHealGoal extends Goal {

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int healCooldown  = 0;
    private int eatAnimation  = 0;   // тики показа предмета в руке

    private static final int HEAL_INTERVAL    = 60;  // тиков между исцелениями (3 сек)
    private static final int EAT_ANIM_TICKS   = 30;  // тики анимации "поедания"
    private static final int HEAL_AMOUNT      = 6;   // HP за раз

    public BotHealGoal(BotEntity bot) {
        this.bot = bot;
        this.setControls(EnumSet.of(Control.LOOK)); // не прерываем патруль/атаку
    }

    @Override
    public boolean canStart() {
        if (healCooldown > 0) { healCooldown--; return false; }
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        return bot.getHealth() < cfg.botHealThreshold;
    }

    @Override
    public boolean shouldContinue() {
        // Продолжаем пока идёт анимация поедания
        return eatAnimation > 0;
    }

    @Override
    public void start() {
        ItemStack healItem = findHealItem();

        // Держим предмет в offhand для анимации
        bot.setItemSlot(EquipmentSlot.OFFHAND, healItem.copy());
        eatAnimation = EAT_ANIM_TICKS;

        // Восстанавливаем HP
        float missing = bot.getMaxHealth() - bot.getHealth();
        float amount  = Math.min(HEAL_AMOUNT, missing);
        if (amount > 0) {
            bot.heal(amount);
        }

        healCooldown = HEAL_INTERVAL;
    }

    @Override
    public void tick() {
        eatAnimation--;
        if (eatAnimation <= 0) {
            // Убираем предмет из руки после "поедания"
            bot.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        }
    }

    @Override
    public void stop() {
        bot.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        eatAnimation = 0;
    }

    /**
     * Ищет лечебный предмет:
     * 1. Проверяем configured item из конфига
     * 2. Fallback: golden_apple
     */
    private ItemStack findHealItem() {
        // Пробуем предмет из конфига
        try {
            ResourceLocation id = ResourceLocation.of(cfg.botHealItem);
            var item = Registries.ITEM.get(id);
            if (item != Items.AIR) {
                return new ItemStack(item);
            }
        } catch (Exception ignored) {}

        // Fallback — enchanted golden apple (лучше)
        return new ItemStack(Items.GOLDEN_APPLE);
    }
}
