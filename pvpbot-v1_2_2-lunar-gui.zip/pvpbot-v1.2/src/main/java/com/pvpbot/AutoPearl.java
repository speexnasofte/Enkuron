package com.pvpbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/**
 * AutoPearl v11 — автоматический бросок Эндер-жемчуга.
 *
 * Два режима (определяется через параметр mode в ModuleManager):
 *
 *   GAP_CLOSE  — игрок бросает перл к цели когда она > gapThreshold блоков
 *                и у игрока достаточно HP (не ниже hp_min).
 *
 *   ESCAPE     — бросает перл «за спину» когда HP < escape_hp.
 *
 * По умолчанию: GAP_CLOSE, порог 8 блоков.
 *
 * Параметры (ModuleManager MOD_AUTO_PEARL):
 *   mode          — "gap_close" | "escape"       (по умолчанию: "gap_close")
 *   gap_threshold — дистанция для GAP_CLOSE      (по умолчанию: 8.0)
 *   hp_min        — минимальный HP для гэпклоза  (по умолчанию: 12.0)
 *   escape_hp     — HP для побега                (по умолчанию: 8.0)
 *   cooldown      — тики между бросками           (по умолчанию: 60)
 *
 * Интеграция:
 *   AutoPearl.INSTANCE.tick(client) вызывается в PVPBotLogic.tick() после
 *   блока обработки цели.
 */
public class AutoPearl {

    public static final AutoPearl INSTANCE = new AutoPearl();

    private static final String MOD = ModuleManager.MOD_AUTO_PEARL;

    private int cooldownTimer = 0;

    private AutoPearl() {}

    /**
     * Вызывается каждый клиентский тик из PVPBotLogic.tick().
     * Возвращает true если бросил перл в этом тике.
     */
    public boolean tick(MinecraftClient client) {
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) return false;
        if (client.player == null || client.world == null) return false;

        cooldownTimer--;
        if (cooldownTimer > 0) return false;

        ModuleManager.ModuleState state = ModuleManager.INSTANCE.getModule(MOD);
        String mode       = (state != null) ? state.params.getOrDefault("mode", "gap_close").toString() : "gap_close";
        double gapThresh  = (state != null) ? state.getDouble("gap_threshold", 8.0) : 8.0;
        double hpMin      = (state != null) ? state.getDouble("hp_min",        12.0) : 12.0;
        double escapeHp   = (state != null) ? state.getDouble("escape_hp",      8.0) : 8.0;
        int    cooldown   = (state != null) ? state.getInt("cooldown",          60)  : 60;

        PlayerEntity player = client.player;

        // Ищем перл в hotbar
        int pearlSlot = findPearlSlot(player);
        if (pearlSlot < 0) return false; // нет перла

        float hp = player.getHealth();

        if (mode.equals("escape") && hp < (float) escapeHp) {
            throwPearl(client, player, pearlSlot, escapeDirection(player));
            cooldownTimer = cooldown;
            return true;
        }

        if (mode.equals("gap_close") && hp >= (float) hpMin) {
            LivingEntity target = findNearestEnemy(client, player);
            if (target != null && player.distanceTo(target) > gapThresh) {
                throwPearl(client, player, pearlSlot, target.getEyePos());
                cooldownTimer = cooldown;
                return true;
            }
        }

        return false;
    }

    /** Ищет Эндер-жемчуг в hotbar (слоты 0–8). */
    private int findPearlSlot(PlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(Items.ENDER_PEARL)) {
                return i;
            }
        }
        return -1;
    }

    /** Находит ближайшего противника в радиусе 24 блоков. */
    private LivingEntity findNearestEnemy(MinecraftClient client, PlayerEntity player) {
        Box box = player.getBoundingBox().expand(24.0);
        List<LivingEntity> entities = client.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive()
                && !(e instanceof net.minecraft.entity.passive.TameableEntity te
                     && te.getOwner() == player)
        );
        return entities.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }

    /**
     * Бросает перл к целевой точке:
     * выставляем нужный слот, поворачиваем взгляд, ПКМ.
     */
    private void throwPearl(MinecraftClient client, PlayerEntity player, int slot, Vec3d target) {
        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;

        // Целимся на точку
        Vec3d diff = target.subtract(player.getEyePos());
        double hDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(diff.y, hDist));
        player.setYaw(yaw);
        player.setPitch(pitch);

        // Нажимаем и отпускаем ПКМ (бросок)
        client.options.useKey.setPressed(true);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        client.options.useKey.setPressed(false);

        // Возвращаем слот
        player.getInventory().selectedSlot = prevSlot;
    }

    /**
     * Направление «за спину» от взгляда (для побега).
     * Бросаем перл на 10 блоков позади.
     */
    private Vec3d escapeDirection(PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f);
        return player.getEyePos().add(look.negate().multiply(10.0));
    }
}
