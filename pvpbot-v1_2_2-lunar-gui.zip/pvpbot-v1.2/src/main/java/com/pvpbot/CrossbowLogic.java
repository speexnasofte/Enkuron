package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * CrossbowLogic — v14: режим CROSSBOW.
 *
 * Механика:
 *   1. Burst-огонь: 3 стрелы/фейерверка подряд с коротким интервалом.
 *   2. На близкой дистанции — откат назад (кайтинг) + burst.
 *   3. На дальней дистанции — стоит и стреляет.
 *   4. Чередует стрелы и фейерверки (по кулдауну).
 *
 * Совместимость: 1.21.11
 */
public class CrossbowLogic {

    private static final int BURST_SIZE        = 3;
    private static final int BURST_INTERVAL    = 3;   // тиков между выстрелами
    private static final int RELOAD_TICKS      = 30;  // перезарядка после burst
    private static final double OPTIMAL_RANGE  = 10.0;
    private static final double MIN_KITE_RANGE = 4.0;
    private static final int FIREWORK_EVERY    = 3;   // каждый N burst — фейерверк

    private int burstLeft    = 0;
    private int burstTick    = 0;
    private int reloadTimer  = 0;
    private int burstCount   = 0; // счётчик burst'ов для чередования

    private final BotEntity bot;

    public CrossbowLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (!(bot.getWorld() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (reloadTimer > 0) { reloadTimer--; return; }

        equipCrossbowKit();
        double dist = bot.distanceTo(target);

        // Смотрим на цель
        bot.getLookControl().lookAt(target, 30f, 30f);

        // Кайтинг — держим оптимальную дистанцию
        if (dist < MIN_KITE_RANGE) {
            Vec3 away = bot.getPos().subtract(target.getPos()).normalize().multiply(0.5);
            bot.setVelocity(bot.getVelocity().add(away.x, 0, away.z));
            bot.velocityModified = true;
        } else if (dist > OPTIMAL_RANGE * 1.5) {
            bot.getNavigation().startMovingTo(target, 1.1);
        } else {
            bot.getNavigation().stop();
        }

        // ── Burst ─────────────────────────────────────────────────
        if (burstLeft > 0) {
            burstTick--;
            if (burstTick <= 0) {
                shootAt(sw, target);
                burstLeft--;
                burstTick = BURST_INTERVAL;
                if (burstLeft == 0) {
                    reloadTimer = RELOAD_TICKS;
                    burstCount++;
                }
            }
        } else if (dist <= OPTIMAL_RANGE * 1.8) {
            // Начать новый burst
            burstLeft = BURST_SIZE;
            burstTick = 1;
        }
    }

    private void shootAt(ServerLevel sw, LivingEntity target) {
        boolean useFirework = (burstCount % FIREWORK_EVERY == 0);

        Vec3 from = bot.getEyePos();
        Vec3 to   = target.getEyePos();
        Vec3 dir  = to.subtract(from).normalize();

        if (useFirework) {
            // Фейерверк как ракета
            FireworkRocketEntity fw = new FireworkRocketEntity(
                sw, bot, from.x, from.y, from.z, new ItemStack(Items.FIREWORK_ROCKET)
            );
            fw.setVelocity(dir.x * 2.0, dir.y * 2.0, dir.z * 2.0);
            sw.spawnEntity(fw);
            bot.playSound(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 1.2f);
        } else {
            // Стрела
            Arrow arrow = new Arrow(sw, from.x, from.y, from.z, new ItemStack(Items.ARROW), null);
            arrow.setOwner(bot);
            arrow.setVelocity(dir.x, dir.y, dir.z, 2.5f, 1.0f);
            arrow.pickupType = Arrow.PickupPermission.DISALLOWED;
            sw.spawnEntity(arrow);
            bot.playSound(SoundEvents.ITEM_CROSSBOW_SHOOT, 1.0f, 1.0f);
        }

        // Частицы
        sw.spawnParticles(ParticleTypes.CRIT,
            from.x, from.y, from.z, 3, 0.1, 0.1, 0.1, 0.05);
    }

    private void equipCrossbowKit() {
        if (bot.getEquippedStack(EquipmentSlot.MAINHAND).isEmpty())
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
        if (bot.getEquippedStack(EquipmentSlot.HEAD).isEmpty())
            bot.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getEquippedStack(EquipmentSlot.CHEST).isEmpty())
            bot.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        if (bot.getEquippedStack(EquipmentSlot.LEGS).isEmpty())
            bot.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getEquippedStack(EquipmentSlot.FEET).isEmpty())
            bot.equipStack(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }
}
