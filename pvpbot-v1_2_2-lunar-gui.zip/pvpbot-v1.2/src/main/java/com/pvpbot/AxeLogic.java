package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * AxeLogic — логика Axe PvP режима.
 *
 * Axe PvP особенности:
 *   - Нетеритовый топор: снимает щиты на 5 секунд (shield disable)
 *   - Медленнее меча, но больше урон (~9 базовый)
 *   - Щит в оффхенде: поднимаем при входящем уроне
 *   - Тактика: ждём удар → снимаем щит → combo
 *
 * Алгоритм Shield-Break:
 *   1. Детектируем что цель блокирует щитом (isBlocking)
 *   2. Атакуем топором — это снимает щит на 5 секунд
 *   3. В эти 5 секунд делаем максимальный DPS
 *
 * Combo после снятия щита:
 *   Удар → небольшая пауза → удар → W-Tap → удар
 *   (3 удара в быстром темпе пока щит снят)
 *
 * Шкала кулдауна топора: 1.0 атак/сек (20 тиков)
 */
public class AxeLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double MELEE_RANGE       = 3.2;
    private static final double IDEAL_DIST        = 2.5;
    private static final int    AXE_ATTACK_CD     = 20;   // 1 атака/сек
    private static final int    SHIELD_DISABLE_DUR= 100;  // 5 секунд в тиках
    private static final int    BURST_CD          = 8;    // быстрый удар в burst
    private static final int    BURST_COUNT       = 3;    // ударов в burst
    private static final int    STRAFE_FLIP       = 22;
    private static final int    PEARL_CD          = 70;

    private final BotEntity bot;

    private int attackCd      = 0;
    private int strafeTimer   = 0;
    private int strafeDir     = 1;
    private int pearlCd       = 0;
    private int shieldDisabledTicks = 0; // тиков пока щит цели снят
    private int burstHits     = 0;       // ударов сделано в текущем burst
    private int burstCd       = 0;
    private boolean inBurst   = false;   // сейчас в режиме быстрых ударов

    public AxeLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { inBurst = false; return; }

        // Кулдауны
        if (attackCd           > 0) attackCd--;
        if (shieldDisabledTicks > 0) shieldDisabledTicks--;
        if (burstCd            > 0) burstCd--;
        if (strafeTimer        > 0) strafeTimer--;
        if (pearlCd            > 0) pearlCd--;

        double dist = bot.distanceTo(target);
        equipAxe();

        // ── Перл для сближения ────────────────────────────────────
        if (dist > 9.0 && pearlCd <= 0) {
            Vec3 aim = MotionPredictor.predict(target, 4);
            bot.teleportTo(aim.x, aim.y, aim.z);
            pearlCd = PEARL_CD;
            return;
        }

        // ── Позиционирование ──────────────────────────────────────
        doPositioning(target, dist);

        // ── Стрейф ────────────────────────────────────────────────
        doStrafe(target);

        if (dist > MELEE_RANGE) return;

        // ── Главная логика: shield break + burst ──────────────────
        boolean targetBlocking = isTargetBlocking(target);

        if (targetBlocking && attackCd <= 0) {
            // Бьём топором — снимаем щит
            doAxeAttack(sw, target, false);
            shieldDisabledTicks = SHIELD_DISABLE_DUR;
            inBurst = true;
            burstHits = 0;
        } else if (shieldDisabledTicks > 0 && inBurst) {
            // Щит снят — burst combo
            doBurstAttack(sw, target);
        } else if (!targetBlocking && attackCd <= 0) {
            // Цель не блокирует — обычный удар
            doAxeAttack(sw, target, false);
            // Поднять свой щит если атакуют
            checkRaiseOwnShield();
        }
    }

    // ── Обычный удар топором ──────────────────────────────────────
    private void doAxeAttack(ServerLevel sw, LivingEntity target, boolean isBurst) {
        float dmg = isBurst ? 8.0f : 9.0f; // burst чуть слабее (быстро)
        target.hurt(sw, sw.damageSources().playerAttack(null), dmg);

        sw.spawnParticles(ParticleTypes.SWEEP_ATTACK,
            target.getX(), target.getY() + 1, target.getZ(),
            5, 0.4, 0.2, 0.4, 0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.85f);

        attackCd = isBurst ? BURST_CD : AXE_ATTACK_CD;
    }

    // ── Burst combo пока щит снят ─────────────────────────────────
    private void doBurstAttack(ServerLevel sw, LivingEntity target) {
        if (burstCd > 0) return;

        if (burstHits < BURST_COUNT) {
            doAxeAttack(sw, target, true);
            burstCd  = BURST_CD;
            burstHits++;
        } else {
            // Burst завершён
            inBurst  = false;
            burstHits = 0;
            attackCd = AXE_ATTACK_CD; // нормальный кулдаун
        }
    }

    // ── Проверка щита цели ────────────────────────────────────────
    private boolean isTargetBlocking(LivingEntity target) {
        if (shieldDisabledTicks > 0) return false; // щит уже снят
        ItemStack offhand = target.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack mainhand = target.getItemBySlot(EquipmentSlot.MAINHAND);
        boolean hasShield = offhand.is(Items.SHIELD) || mainhand.is(Items.SHIELD);
        return hasShield && target.isBlocking();
    }

    // ── Поднять свой щит если враг атакует ───────────────────────
    private void checkRaiseOwnShield() {
        ItemStack off = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (!off.is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    // ── Позиционирование ─────────────────────────────────────────
    private void doPositioning(LivingEntity target, double dist) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        if (dist > IDEAL_DIST + 0.5) {
            bot.setDeltaMovement(bot.getDeltaMovement().add(toTarget.scale(0.17)));
        } else if (dist < IDEAL_DIST - 0.4) {
            bot.setDeltaMovement(bot.getDeltaMovement().add(toTarget.scale(-0.1)));
        }
        bot.velocityModified = true;
    }

    // ── Стрейф ───────────────────────────────────────────────────
    private void doStrafe(LivingEntity target) {
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = STRAFE_FLIP + bot.level().getRandom().nextInt(10);
        }
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 strafe   = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);
        bot.setDeltaMovement(bot.getDeltaMovement().add(strafe.scale(0.11)));
        bot.velocityModified = true;
    }

    private void equipAxe() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_AXE));
    }
}
