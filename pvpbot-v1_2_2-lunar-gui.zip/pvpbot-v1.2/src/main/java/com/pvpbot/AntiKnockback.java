package com.pvpbot;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.Vec3;

/**
 * AntiKnockback v10 — подавляет кнокбэк у NPC-бота.
 *
 * Принцип: переопределяем takeKnockback() в BotEntity и
 * умножаем применённый импульс на (1 - resistance), где
 * resistance = 0.0 .. 1.0 (0 = без защиты, 1 = полный иммунитет).
 *
 * Значение resistance читается из ModuleManager:
 *   ModuleManager.INSTANCE.getModule(MOD_ANTI_KNOCKBACK)
 *                          .getDouble("resistance", 0.8)
 *
 * Модуль: MOD_ANTI_KNOCKBACK в ModuleManager.
 *
 * Интеграция в BotEntity:
 *   @Override
 *   public void takeKnockback(double strength, double x, double z) {
 *       AntiKnockback.apply(this, strength, x, z);
 *   }
 *
 *   @Override
 *   protected void knockback(LivingEntity attacker) {
 *       // подавляем стандартный knockback-при-удар
 *       if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK))
 *           super.knockback(attacker);
 *   }
 */
public class AntiKnockback {

    private AntiKnockback() {}

    /**
     * Вызывать из BotEntity.takeKnockback() вместо super.takeKnockback().
     *
     * @param bot      экземпляр BotEntity
     * @param strength сила кнокбэка
     * @param x        направление X
     * @param z        направление Z
     */
    public static void apply(BotEntity bot, double strength, double x, double z) {
        if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK)) {
            // Модуль выключен — стандартное поведение
            defaultKnockback(bot, strength, x, z);
            return;
        }

        double resistance = ModuleManager.INSTANCE
                .getModule(ModuleManager.MOD_ANTI_KNOCKBACK)
                .getDouble("resistance", 0.8);

        // Уменьшаем силу кнокбэка
        double reducedStrength = strength * (1.0 - resistance);

        if (reducedStrength < 0.001) {
            // Практически полный иммунитет — не применяем вообще
            return;
        }

        defaultKnockback(bot, reducedStrength, x, z);
    }

    private static void defaultKnockback(BotEntity bot, double strength, double x, double z) {
        // Повторяем логику LivingEntity.takeKnockback()
        if (strength <= 0) return;

        Vec3 vel = bot.getDeltaMovement();
        double len = Math.sqrt(x * x + z * z);
        if (len < 1e-9) return;

        double nx = x / len;
        double nz = z / len;

        Vec3 knockVec = new Vec3(
            vel.x / 2.0 - nx * strength,
            bot.onGround() ? Math.min(0.4, vel.y / 2.0 + strength) : vel.y,
            vel.z / 2.0 - nz * strength
        );
        bot.setDeltaMovement(knockVec);
    }
}
