package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.phys.Vec3;

/**
 * BotDifficultyAI — управляет поведением NPC-бота в зависимости от сложности.
 *
 * Вызывается из BotEntity.tick() на серверной стороне.
 *
 * ┌──────────┬──────────────────────────────────────────────────────────────────┐
 * │ EASY     │ Базовая атака, нет перлов/кристаллов, лук не использует          │
 * │ MEDIUM   │ Лук на дальних дистанциях, базовый стрейф                        │
 * │ HARD     │ Перлы для преследования/отрыва, авто-стрейф, крит-прыжки        │
 * │ EXPERT   │ Всё выше + end crystals, предсказание позиции, combo-атаки       │
 * └──────────┴──────────────────────────────────────────────────────────────────┘
 */
public class BotDifficultyAI {

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    // ── Таймеры ───────────────────────────────────────────────────
    private int pearlCooldown   = 0;   // тиков до следующего броска перла
    private int bowCooldown     = 0;   // тиков до следующего выстрела
    private int crystalCooldown = 0;   // тиков до следующей кристальной атаки
    private int comboCooldown   = 0;   // тиков комбо-паузы (EXPERT)
    private int comboHits       = 0;   // текущее кол-во ударов в комбо
    private int predictTick     = 0;   // тик обновления предсказанной позиции

    private Vec3 predictedTargetPos = null; // предсказанная позиция цели (EXPERT)

    // ── v12: новые системы ────────────────────────────────────────
    private final ComboSystem    comboSystem;
    private final WeaponSwitcher weaponSwitcher;

    // ── v1.2: PotionPredict ───────────────────────────────────────
    private final PotionPredict  potionPredict;

    // ── v13: Mace + улучшенный AI ────────────────────────────────
    private final MaceLogic           maceLogic;
    private final ModeLogicDispatcher modeDispatcher;
    /** Счётчик тиков для адаптивного поведения */
    private int    adaptTick     = 0;
    /** Последнее HP цели (для детекции ухода от боя) */
    private float  lastTargetHp  = -1;
    /** Сколько тиков цель не получает урон (для агрессивного давления) */
    private int    targetNoDmgTicks = 0;

    public BotDifficultyAI(BotEntity bot) {
        this.bot = bot;
        this.comboSystem    = new ComboSystem(bot);
        this.weaponSwitcher = new WeaponSwitcher(bot);
        this.maceLogic      = new MaceLogic(bot);
        this.modeDispatcher = new ModeLogicDispatcher(bot);
        this.potionPredict  = new PotionPredict(bot);   // v1.2
    }

    /**
     * Фикс v1.2.1: возвращает effectiveCooldown из AdaptiveCooldown если включён,
     * иначе базовый из конфига. Все *Logic классы должны использовать этот метод.
     */
    public int getAttackCooldown() {
        if (PVPBotConfig.INSTANCE.adaptiveCooldownEnabled) {
            return bot.getAdaptiveCooldown().getEffectiveCooldown();
        }
        return PVPBotConfig.INSTANCE.attackCooldown;
    }

    /**
     * Главный тик — вызывать из BotEntity.tick() при наличии цели.
     * @param target текущая цель бота
     */
    public void tick(LivingEntity target) {
        if (bot.level().isClient) return;

        // Убываем все таймеры
        if (pearlCooldown   > 0) pearlCooldown--;
        if (bowCooldown     > 0) bowCooldown--;
        if (crystalCooldown > 0) crystalCooldown--;
        if (comboCooldown   > 0) comboCooldown--;
        if (predictTick     > 0) predictTick--;

        // v1.2: PotionPredict tick
        if (target != null && target.isAlive()) {
            potionPredict.tick(target);

            // Если враг пьёт зелье — rush-атака без ожидания кулдауна крита
            if (potionPredict.isVulnerable() && bot.distanceTo(target) <= 3.8) {
                bot.getNavigation().moveTo(target, 1.4);
                bot.tryAttack(target);
                potionPredict.onRushAttack();
            }
        }

        // v14: уведомление об убийстве
        if (target == null || !target.isAlive()) {
            if (lastTargetHp > 0) {
                // цель только что умерла
                bot.getNotifier().onKill(target != null ? target : null);
                lastTargetHp = -1;
            }
            return;
        }

        // ── v13: адаптивный трекинг цели ─────────────────────────
        adaptTick++;
        if (adaptTick % 10 == 0) {
            float currentHp = target.getHealth();
            if (lastTargetHp >= 0 && currentHp >= lastTargetHp) {
                targetNoDmgTicks += 10; // цель не получает урон
            } else {
                targetNoDmgTicks = 0;   // урон наносится — сбрасываем
            }
            lastTargetHp = currentHp;
        }

        // ── v13: MACE режим — отдельная ветка ────────────────────
        PVPBotConfig.Mode mode = cfg.mode;
        if (mode == PVPBotConfig.Mode.MACE) {
            maceLogic.tick(target);
            // Если не в Smash-фазе — используем ComboSystem для добивания
            if (!maceLogic.isSmashing()) {
                comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM);
                comboSystem.tick(target);
            }
            return;
        }

        // ── v13: Диспетчер режимов (SWORD, AXE, UHC, NETHPOT, SMP, TPC) ──
        if (modeDispatcher.tick(target)) return;

        PVPBotConfig.Difficulty diff = cfg.difficulty;

        switch (diff) {
            case EASY   -> tickEasy(target);
            case MEDIUM -> tickMedium(target);
            case HARD   -> tickHard(target);
            case EXPERT -> tickExpert(target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EASY — только базовая атака, ничего умного
    // ════════════════════════════════════════════════════════════════
    private void tickEasy(LivingEntity target) {
        // На EASY ИИ целиком управляется стандартными Goal'ами.
        // BotDifficultyAI только сбрасывает таймеры.
        pearlCooldown   = cfg.diffPearlCooldown;
        bowCooldown     = cfg.diffBowCooldown;
        crystalCooldown = cfg.diffCrystalCooldown;
    }

    // ════════════════════════════════════════════════════════════════
    // MEDIUM — лук при дистанции > bowSwitchRange, базовый стрейф
    // ════════════════════════════════════════════════════════════════
    private void tickMedium(LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Лук на дальних дистанциях
        if (dist > cfg.diffBowSwitchRange && bowCooldown <= 0) {
            equipBow();
            simulateBowShot(target);
            bowCooldown = cfg.diffBowCooldown;
        } else if (dist <= cfg.diffBowSwitchRange) {
            equipSword();
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HARD — перлы, WeaponSwitcher, AutoRetreat, ComboSystem
    // ════════════════════════════════════════════════════════════════
    private void tickHard(LivingEntity target) {
        double dist = bot.distanceTo(target);

        // v12: авто-смена оружия по дистанции
        weaponSwitcher.tick(target);

        // v12: combo-система (RHYTHM по умолчанию на HARD)
        comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM);
        comboSystem.tick(target);

        // Перл-рывок
        if (cfg.diffUsePearls && dist > cfg.diffPearlThrowDist && pearlCooldown <= 0) {
            // v12: предсказываем куда кинуть перл
            Vec3 aim = MotionPredictor.predict(target, 5);
            throwEnderPearl(aim);
            pearlCooldown = cfg.diffPearlCooldown;
        }

        // Перл-отрыв
        if (cfg.diffUsePearls && bot.getHealth() < cfg.diffPearlEscapeHpThreshold
                && pearlCooldown <= 0) {
            throwEnderPearl(computeEscapePos(target));
            pearlCooldown = cfg.diffPearlCooldown;
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EXPERT — всё выше + end crystals + предсказание + combo
    // ════════════════════════════════════════════════════════════════
    private void tickExpert(LivingEntity target) {
        double dist = bot.distanceTo(target);

        // ── Предсказание позиции ──────────────────────────────────
        if (predictTick <= 0) {
            // v12: используем MotionPredictor вместо старого предсказания
            predictedTargetPos = MotionPredictor.predictForProjectile(bot, target, 1.6);
            predictTick = 3; // обновляем каждые 3 тика (≈150 мс)
        }

        // ── Переключение оружия ───────────────────────────────────
        if (dist > cfg.diffBowSwitchRange && bowCooldown <= 0) {
            equipBow();
            Vec3 aimPos = predictedTargetPos != null ? predictedTargetPos : target.position();
            simulateBowShotAt(aimPos);
            bowCooldown = cfg.diffBowCooldown;
        } else {
            equipSword();
        }

        // ── End Crystals ──────────────────────────────────────────
        if (cfg.diffUseCrystals && crystalCooldown <= 0 && dist < cfg.diffCrystalPlaceRange) {
            // Симулируем подрыв кристалла: наносим урон в зоне взрыва
            simulateCrystalExplosion(target);
            crystalCooldown = cfg.diffCrystalCooldown;
        }

        // ── Перлы (рывок + отрыв) ────────────────────────────────
        if (cfg.diffUsePearls) {
            if (dist > cfg.diffPearlThrowDist && pearlCooldown <= 0) {
                Vec3 aim = predictedTargetPos != null ? predictedTargetPos : target.position();
                throwEnderPearl(aim);
                pearlCooldown = cfg.diffPearlCooldown;
            }
            if (bot.getHealth() < cfg.diffPearlEscapeHpThreshold && pearlCooldown <= 0) {
                throwEnderPearl(computeEscapePos(target));
                pearlCooldown = cfg.diffPearlCooldown;
            }
        }

        // ── v13: Адаптивное давление ──────────────────────────────
        // Если цель > 20 тиков не получает урон — бот агрессивнее рвётся вперёд
        if (targetNoDmgTicks > 20 && dist > 2.5 && pearlCooldown <= 0) {
            Vec3 rushPos = predictedTargetPos != null ? predictedTargetPos : target.position();
            throwEnderPearl(rushPos);
            pearlCooldown = cfg.diffPearlCooldown;
            targetNoDmgTicks = 0;
        }

        // ── v12: Комбо-атаки (ComboSystem) ──────────────────────
        comboSystem.setPattern(ComboSystem.ComboPattern.BURST); // EXPERT = BURST
        comboSystem.tick(target);

        // ── v12: WeaponSwitcher ───────────────────────────────────
        weaponSwitcher.tick(target);
    }

    // ════════════════════════════════════════════════════════════════
    // Вспомогательные методы
    // ════════════════════════════════════════════════════════════════

    /** Экипируем меч из инвентаря бота (первый найденный меч или netherite_sword). */
    private void equipSword() {
        // Bot mob has no player inventory; equip sword directly
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
    }

    /** Экипируем лук. */
    private void equipBow() {
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }

    private boolean isSword(ItemStack stack) {
        return stack.is(Items.NETHERITE_SWORD) || stack.is(Items.DIAMOND_SWORD)
            || stack.is(Items.IRON_SWORD)      || stack.is(Items.STONE_SWORD)
            || stack.is(Items.GOLDEN_SWORD)    || stack.is(Items.WOODEN_SWORD);
    }

    /**
     * Симулирует выстрел из лука: мгновенно наносим урон цели
     * (урон зависит от дистанции, как у настоящего лука).
     */
    private void simulateBowShot(LivingEntity target) {
        simulateBowShotAt(target.position());
    }

    private void simulateBowShotAt(Vec3 aimPos) {
        // Находим ближайшую живую сущность к прицельной точке
        double dist = bot.distanceTo(aimPos.x, aimPos.y, aimPos.z);
        // Урон: от 2 (дальн.) до 9 (близк.) — как ванильный заряженный лук
        float damage = (float) Math.max(2.0, 9.0 - dist * 0.3);

        // Наносим урон ближайшей сущности в радиусе 2 блоков от aimPos
        if (bot.level() instanceof net.minecraft.server.level.ServerLevel sw) {
            sw.getEntitiesByClass(LivingEntity.class,
                new net.minecraft.world.phys.AABB(aimPos, aimPos).expand(1.5),
                e -> e != bot && e.isAlive()
            ).stream().findFirst().ifPresent(e ->
                e.hurt(sw, sw.getDamageSources().arrow(null, bot), damage)
            );
        }
    }

    /**
     * Симулирует взрыв end crystal рядом с целью.
     * Радиус: cfg.diffCrystalPlaceRange / 2
     */
    private void simulateCrystalExplosion(LivingEntity target) {
        if (!(bot.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
        float explosionDamage = cfg.diffCrystalDamage;
        // Урон цели
        target.hurt(sw, sw.getDamageSources().explosion(bot, bot), explosionDamage);
        // Knockback к цели
        Vec3 kb = target.position().subtract(bot.position()).normalize().scale(1.2);
        target.setVelocity(target.getVelocity().add(kb.x, 0.4, kb.z));
        target.velocityModified = true;
    }

    /**
     * Бросок эндер-жемчуга: телепортирует бота к целевой позиции.
     * Реальный предмет не расходуем (серверный NPC).
     */
    private void throwEnderPearl(Vec3 destination) {
        if (!(bot.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
        // Безопасная телепортация: проверяем что позиция не в блоке
        double x = destination.x;
        double y = destination.y;
        double z = destination.z;
        // Небольшой оффсет чтобы не застрять
        bot.teleport(x, y, z);
        // Эффект частиц при телепорте
        sw.spawnParticles(
            net.minecraft.particle.ParticleTypes.PORTAL,
            bot.getX(), bot.getY() + 1, bot.getZ(),
            16, 0.3, 0.5, 0.3, 0.1
        );
        bot.playSound(net.minecraft.sound.SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
    }

    /**
     * Вычисляет позицию для отрыва: противоположно от цели, на расстоянии pearlEscapeDist.
     */
    private Vec3 computeEscapePos(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        return bot.position().add(away.scale(cfg.diffPearlEscapeDist));
    }

    /**
     * Предсказывает позицию цели через N тиков на основе текущей скорости.
     */
    private Vec3 predictTargetPosition(LivingEntity target, int ticks) {
        Vec3 vel = target.getVelocity();
        return target.position().add(vel.scale(ticks));
    }

    /**
     * Уклонение в конце комбо: боковой импульс прочь от цели.
     */
    private void applyComboEvade(LivingEntity target) {
        Vec3 toEnemy = target.position().subtract(bot.position()).normalize();
        // Перпендикулярно к врагу (боковой стрейф)
        Vec3 side = new Vec3(-toEnemy.z, 0, toEnemy.x)
            .scale(bot.level().getRandom().nextBoolean() ? 1 : -1);
        bot.setVelocity(bot.getVelocity().add(side.scale(0.6)).add(0, 0.3, 0));
        bot.velocityModified = true;
    }
}
