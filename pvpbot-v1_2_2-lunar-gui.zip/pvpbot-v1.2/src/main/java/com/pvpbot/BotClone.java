package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * BotClone — режим "клонирования" игрока (v12).
 *
 * Когда включён:
 *   - Бот следует за игроком
 *   - Когда игрок атакует — бот атакует ту же цель
 *   - Когда игрок использует предмет — бот повторяет
 *   - Полезно для тренировки PvP: бот дублирует твои атаки
 *
 * Активация: /bot clone on | off
 */
public class BotClone {

    public static final BotClone INSTANCE = new BotClone();

    private static final double ATTACK_COPY_RANGE = 20.0; // блоков — радиус слежения за атакой

    private boolean active = false;

    // Последняя цель владельца
    private LivingEntity ownerLastTarget = null;
    private int          copyDelay       = 0; // тиков задержки копирования (реализм)

    private BotClone() {}

    public boolean isActive()       { return active; }
    public void setActive(boolean v) { this.active = v; }
    public void toggle()             { this.active = !this.active; }

    /**
     * Тик — вызывается из BotEntity.tick() на сервере.
     */
    public void tick(BotEntity bot) {
        if (!active) return;
        if (copyDelay > 0) { copyDelay--; return; }

        Player owner = bot.getOwner();
        if (owner == null || !owner.isAlive()) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;

        // Бот следует за владельцем вплотную
        double distToOwner = bot.distanceTo(owner);
        if (distToOwner > 3.0) {
            bot.getNavigation().moveTo(owner, 1.2);
        }

        // Найти цель владельца — кого он смотрит / последнего атакованного
        LivingEntity ownerTarget = findOwnerTarget(owner, sw);

        if (ownerTarget != null && ownerTarget.isAlive()) {
            if (ownerTarget != ownerLastTarget) {
                // Владелец сменил цель — бот тоже переключается
                ownerLastTarget = ownerTarget;
                copyDelay = 2; // небольшая задержка для реализма
            }
            // Бот атакует ту же цель
            bot.setTarget(ownerTarget);
        }
    }

    /**
     * Найти цель игрока — смотрим на кого направлен взгляд игрока в радиусе ATTACK_COPY_RANGE.
     */
    private LivingEntity findOwnerTarget(Player owner, ServerLevel sw) {
        // Сначала — кого игрок последний раз ударил (через AttackTarget)
        // В vanilla API нет прямого "lastAttacked", используем raycast
        var ray = owner.raycast(ATTACK_COPY_RANGE, 0, false);
        if (ray instanceof net.minecraft.util.hit.EntityHitResult ehr
                && ehr.getEntity() instanceof LivingEntity living) {
            return living;
        }

        // Fallback — ближайший враг к игроку
        List<LivingEntity> nearby = sw.getEntitiesByClass(
            LivingEntity.class,
            new Box(owner.blockPosition()).expand(ATTACK_COPY_RANGE),
            e -> e != owner && e != null && e.isAlive()
                && !(e instanceof BotEntity) // не атаковать других ботов
        );

        return nearby.stream()
            .filter(e -> e instanceof net.minecraft.world.entity.player.Player
                    || e instanceof net.minecraft.world.entity.monster.Monster)
            .min(java.util.Comparator.comparingDouble(e -> owner.distanceToSqr(e)))
            .orElse(null);
    }
}
