package com.pvpbot;

import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

/**
 * Атакует других игроков — только в режиме AGGRESSIVE.
 * Владелец никогда не является целью.
 */
public class BotAttackPlayersGoal extends NearestAttackableTargetGoal<Player> {

    private final BotEntity bot;

    public BotAttackPlayersGoal(BotEntity bot) {
        super(bot, Player.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canStart() {
        if (bot.getBotMode() != BotEntity.BotMode.AGGRESSIVE) return false;
        var owner = bot.getOwner();
        // Ищем ближайшего игрока, исключая владельца
        return super.canStart();
    }

    @Override
    protected boolean isTargetValid(Player target) {
        var owner = bot.getOwner();
        if (owner != null && target.getUUID().equals(owner.getUUID())) return false;
        return super.isTargetValid(target);
    }
}
