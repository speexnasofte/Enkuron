package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * MaceLogic — умная логика для MACE (булава) PvP режима.
 *
 * Булава в Minecraft 1.21 наносит бонусный урон в зависимости от
 * высоты падения перед ударом (Smash Attack). Чем выше прыгнул —
 * тем больше урон.
 *
 * Алгоритм Smash Attack:
 *   1. Бот прыгает вверх над целью (JUMP_UP фаза)
 *   2. Достигает пика прыжка — начинает падать (FALLING фаза)
 *   3. При падении атакует цель (SMASH фаза)
 *   4. После удара — откат/кулдаун (COOLDOWN фаза)
 *
 * Дополнительно:
 *   - Автоматически использует тотем из оффхенда если HP < 6
 *   - Dash к цели если она убегает (dist > DASH_RANGE)
 *   - Windcharge-like knockback после удара (через velocity)
 */
public class MaceLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double SMASH_TRIGGER_DIST = 3.0;   // дистанция для начала Smash
    private static final double DASH_RANGE          = 6.0;   // дистанция для рывка
    private static final double JUMP_HEIGHT         = 3.5;   // блоки подъёма для Smash
    private static final float  SMASH_BASE_DAMAGE   = 8.0f;  // базовый урон булавы
    private static final float  FALL_BONUS_PER_BLOCK= 1.5f;  // доп. урон за каждый блок падения
    private static final int    SMASH_COOLDOWN_TICKS= 30;    // тиков кулдауна между Smash
    private static final int    DASH_COOLDOWN_TICKS = 25;    // тиков кулдауна dash

    // ── Состояние автомата ────────────────────────────────────────
    private enum SmashState { IDLE, JUMP_UP, FALLING, SMASH, COOLDOWN }
    private SmashState smashState = SmashState.IDLE;

    private final BotEntity bot;
    private int    smashCooldown = 0;
    private int    dashCooldown  = 0;
    private double jumpStartY    = 0;  // Y при старте прыжка
    private double peakY         = 0;  // пиковая высота

    public MaceLogic(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Главный тик — вызывается из BotDifficultyAI каждый тик в MACE режиме.
     */
    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (target == null || !target.isAlive()) {
            smashState = SmashState.IDLE;
            return;
        }

        // Кулдауны
        if (smashCooldown > 0) smashCooldown--;
        if (dashCooldown  > 0) dashCooldown--;

        double dist = bot.distanceTo(target);

        // Убеждаемся что в руке булава
        equipMace();

        // ── Основной автомат Smash ────────────────────────────────
        switch (smashState) {
            case IDLE     -> tickIdle(target, dist);
            case JUMP_UP  -> tickJumpUp(target);
            case FALLING  -> tickFalling(target);
            case SMASH    -> tickSmash(target);
            case COOLDOWN -> tickCooldown();
        }

        // ── Dash если цель убегает ────────────────────────────────
        if (smashState == SmashState.IDLE && dist > DASH_RANGE && dashCooldown <= 0) {
            dashToTarget(target);
        }
    }

    // ── IDLE: ждём момента для Smash ─────────────────────────────
    private void tickIdle(LivingEntity target, double dist) {
        if (smashCooldown > 0) return;

        if (dist <= SMASH_TRIGGER_DIST) {
            // Начинаем Smash — прыгаем вверх
            jumpStartY = bot.getY();
            peakY      = jumpStartY;
            smashState = SmashState.JUMP_UP;
            doJumpUp();
        }
    }

    // ── JUMP_UP: поднимаемся вверх ────────────────────────────────
    private void tickJumpUp(LivingEntity target) {
        double currentY = bot.getY();

        if (currentY > peakY) {
            peakY = currentY; // обновляем пик
        }

        // Если начали падать (Y уменьшился) — переходим в FALLING
        if (currentY < peakY - 0.1) {
            smashState = SmashState.FALLING;
            return;
        }

        // Если поднялись достаточно высоко — начинаем падать
        if (currentY >= jumpStartY + JUMP_HEIGHT) {
            smashState = SmashState.FALLING;
        }
    }

    // ── FALLING: падаем вниз к цели ──────────────────────────────
    private void tickFalling(LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Если достаточно близко к цели по вертикали — бьём
        double vertDiff = bot.getY() - target.getY();
        if (vertDiff <= 1.5 && dist <= SMASH_TRIGGER_DIST + 1.0) {
            smashState = SmashState.SMASH;
            tickSmash(target);
            return;
        }

        // Если приземлились без удара — сброс
        if (bot.onGround()) {
            smashState = SmashState.COOLDOWN;
            smashCooldown = SMASH_COOLDOWN_TICKS / 2;
        }
    }

    // ── SMASH: наносим удар булавой ──────────────────────────────
    private void tickSmash(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) {
            smashState = SmashState.COOLDOWN;
            return;
        }

        // Высота падения = пик - текущий Y (минимум 0)
        double fallBlocks = Math.max(0, peakY - bot.getY());

        // Итоговый урон: базовый + бонус за падение
        float damage = SMASH_BASE_DAMAGE + (float)(fallBlocks * FALL_BONUS_PER_BLOCK);
        damage = Math.min(damage, 30.0f); // кап урона

        // Наносим урон
        target.hurt(sw, sw.damageSources().playerAttack(null), damage);

        // Knockback вверх + в сторону от бота (как у ванильной булавы)
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(
            kb.x * 1.5,
            1.2,          // сильный отброс вверх
            kb.z * 1.5
        );
        target.velocityModified = true;

        // Эффекты
        sw.spawnParticles(
            ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(),
            12, 0.4, 0.4, 0.4, 0.2
        );
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);

        // Сбрасываем velocity бота (чтобы не улететь дальше)
        bot.setDeltaMovement(bot.getDeltaMovement().scale(0.2, 0.1, 0.2));
        bot.velocityModified = true;

        smashCooldown = SMASH_COOLDOWN_TICKS;
        smashState    = SmashState.COOLDOWN;
    }

    // ── COOLDOWN: ждём ───────────────────────────────────────────
    private void tickCooldown() {
        if (smashCooldown <= 0) {
            smashState = SmashState.IDLE;
        }
    }

    // ── Прыжок вверх ─────────────────────────────────────────────
    private void doJumpUp() {
        if (!(bot.level() instanceof ServerLevel)) return;
        // Импульс вверх для прыжка (как ванильный прыжок + усиленный)
        Vec3 vel = bot.getDeltaMovement();
        bot.setDeltaMovement(vel.x, 0.55, vel.z); // чуть выше обычного прыжка
        bot.velocityModified = true;
    }

    // ── Рывок к цели (Dash) ───────────────────────────────────────
    private void dashToTarget(LivingEntity target) {
        Vec3 dir = target.position().subtract(bot.position()).normalize();
        bot.setDeltaMovement(
            dir.x * 0.7,
            bot.getDeltaMovement().y,
            dir.z * 0.7
        );
        bot.velocityModified = true;
        dashCooldown = DASH_COOLDOWN_TICKS;
    }

    // ── Экипировать булаву ────────────────────────────────────────
    private void equipMace() {
        ItemStack current = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!current.is(Items.MACE)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
        }
    }

    /**
     * Проверяет — бот сейчас в фазе Smash Attack (прыжок/падение/удар).
     * Используется в BotDifficultyAI чтобы не переключать оружие.
     */
    public boolean isSmashing() {
        return smashState != SmashState.IDLE && smashState != SmashState.COOLDOWN;
    }

    /**
     * Возвращает текущее состояние для отладки/HUD.
     */
    public String getStateLabel() {
        return switch (smashState) {
            case IDLE     -> "MACE:IDLE";
            case JUMP_UP  -> "MACE:JUMP";
            case FALLING  -> "MACE:FALL";
            case SMASH    -> "MACE:SMASH";
            case COOLDOWN -> "MACE:CD";
        };
    }
}
