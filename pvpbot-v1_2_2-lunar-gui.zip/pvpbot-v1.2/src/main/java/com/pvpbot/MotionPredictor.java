package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * MotionPredictor — предсказание позиции цели через N тиков.
 *
 * Алгоритм:
 *   1. Берём текущую скорость цели (velocity)
 *   2. Применяем трение (0.91 в воздухе, 0.6 на земле)
 *   3. Итерируем N тиков вперёд
 *
 * Используется в BotDifficultyAI (HARD/EXPERT) и ComboSystem.
 */
public class MotionPredictor {

    private static final double FRICTION_GROUND = 0.546; // 0.6 * 0.91
    private static final double FRICTION_AIR    = 0.91;

    /**
     * Предсказать позицию цели через ticks тиков.
     */
    public static Vec3 predict(LivingEntity target, int ticks) {
        Vec3 pos = target.position();
        Vec3 vel = target.getVelocity();
        boolean onGround = target.isOnGround();

        for (int i = 0; i < ticks; i++) {
            pos = pos.add(vel);
            double friction = onGround ? FRICTION_GROUND : FRICTION_AIR;
            vel = new Vec3(vel.x * friction, vel.y - 0.08, vel.z * friction);
            // Земля
            if (pos.y <= target.level().getBottomY()) {
                vel = new Vec3(vel.x, 0, vel.z);
                onGround = true;
            }
        }
        return pos;
    }

    /**
     * Предсказать позицию с учётом времени полёта стрелы/перла.
     * projectileSpeed — скорость снаряда (блоков/тик).
     * Итеративно ищем время, при котором снаряд долетает до предсказанной позиции.
     */
    public static Vec3 predictForProjectile(LivingEntity shooter, LivingEntity target,
                                              double projectileSpeed) {
        Vec3 shooterPos = shooter.getEyePos();
        for (int ticks = 1; ticks <= 40; ticks++) {
            Vec3 predicted = predict(target, ticks);
            double dist = shooterPos.distanceTo(predicted);
            double travelTime = dist / projectileSpeed;
            if (travelTime <= ticks + 1.5) {
                return predicted;
            }
        }
        // Fallback: просто текущая позиция
        return target.position();
    }
}
