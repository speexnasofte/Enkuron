package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Camera;
import net.minecraft.client.renderer.RenderType;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Tracers v11 — линии от центра экрана к сущностям (через HudRenderCallback).
 *
 * Реализован отдельно от EspRenderer: EspRenderer рисует хитбоксы через
 * WorldRenderCallback (3D), Tracers использует WorldRenderContext для рисования
 * линий в 3D-пространстве поверх мира.
 *
 * Цветовая схема (совпадает с EspRenderer):
 *   Игроки          — красный  (255, 34, 34)
 *   NPC-боты        — золотой  (255, 215, 0)
 *   Враждебные мобы — оранжевый (255, 119, 0)
 *   Пассивные мобы  — зелёный  (68, 255, 68)
 *
 * Параметры (ModuleManager MOD_TRACERS):
 *   range          — радиус поиска сущностей (по умолчанию: 64.0)
 *   players_only   — рисовать только для игроков (по умолчанию: false)
 *   line_width     — толщина линии; в MC 1.21 всегда 1.0 (GL ограничение)
 *
 * Интеграция:
 *   Tracers.INSTANCE.register() вызывается в PVPBotMod.onInitializeClient()
 *   (или BotClientInit) после регистрации EspRenderer.
 */
public class Tracers implements WorldRenderCallback {

    public static final Tracers INSTANCE = new Tracers();

    private static final String MOD = ModuleManager.MOD_TRACERS;

    private Tracers() {}

    public void register() {
        net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.LAST.register(this::onWorldRender);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.world == null) return;

        ModuleManager.ModuleState state = ModuleManager.INSTANCE.getModule(MOD);
        double range       = (state != null) ? state.getDouble("range",        64.0) : 64.0;
        boolean playersOnly = (state != null) && state.getBool("players_only", false);

        Camera camera   = context.camera();
        Vec3  camPos   = camera.getPos();
        PoseStack matrices = context.matrixStack();
        if (matrices == null) return;

        MultiBufferSource.Immediate immediate =
            mc.getBufferBuilders().getEntityVertexConsumers();

        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        // Начало линии — позиция камеры (центр экрана в 3D)
        float startX = (float) camPos.x;
        float startY = (float) camPos.y;
        float startZ = (float) camPos.z;

        Player player = mc.player;
        Box searchBox = player.getBoundingBox().expand(range);

        List<LivingEntity> entities = mc.world.getEntitiesByClass(
            LivingEntity.class, searchBox,
            e -> e != player && e.isAlive()
        );

        VertexConsumer lines = immediate.getBuffer(RenderLayer.getLines());

        for (LivingEntity entity : entities) {
            if (playersOnly && !(entity instanceof Player)) continue;

            // Центр сущности (середина AABB по Y)
            Vec3 pos = entity.getPos().add(0, entity.getHeight() / 2.0, 0);
            float ex = (float) pos.x;
            float ey = (float) pos.y;
            float ez = (float) pos.z;

            int[] color = entityColor(entity);
            int r = color[0], g = color[1], b = color[2];

            // Линия от камеры до центра сущности
            drawLine(lines, matrix,
                startX, startY, startZ,
                ex, ey, ez,
                r, g, b, 200); // alpha 200/255
        }

        immediate.draw(RenderLayer.getLines());
        matrices.pop();
    }

    /** Рисует одну линию (два вершины с нормалью). */
    private void drawLine(VertexConsumer consumer, Matrix4f matrix,
                           float x1, float y1, float z1,
                           float x2, float y2, float z2,
                           int r, int g, int b, int a) {
        // Нормаль направлена по вектору линии
        float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;

        consumer.vertex(matrix, x1, y1, z1)
                .color(r, g, b, a)
                .normal(nx, ny, nz);
        consumer.vertex(matrix, x2, y2, z2)
                .color(r, g, b, a)
                .normal(nx, ny, nz);
    }

    private int[] entityColor(LivingEntity entity) {
        if (entity instanceof BotEntity)    return new int[]{255, 215,   0}; // золотой
        if (entity instanceof Player) return new int[]{255,  34,  34}; // красный
        if (entity instanceof net.minecraft.world.entity.Mob mob
                && mob.isUndead())          return new int[]{255, 119,   0}; // оранжевый
        // Пассивные / нейтральные
        return new int[]{68, 255, 68};
    }
}
