package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * TargetPriority — умный выбор цели для бота (v12).
 *
 * Режимы приоритета:
 *   NEAREST    — ближайший враг (дефолт)
 *   LOWEST_HP  — у кого меньше всего HP (добить)
 *   MOST_ITEMS — у кого больше всего предметов (лут)
 *   FOCUS      — принудительная цель (задана вручную через /bot target)
 *
 * Бот пересматривает цель каждые RETARGET_INTERVAL тиков,
 * если текущая цель вышла за пределы ABANDON_RANGE блоков.
 */
public class TargetPriority {

    public enum PriorityMode { NEAREST, LOWEST_HP, MOST_ITEMS, FOCUS }

    private static final int    RETARGET_INTERVAL = 40;  // тиков между пересмотром цели
    private static final double ABANDON_RANGE     = 32.0; // блоков — бросить цель
    private static final double SCAN_RANGE        = 24.0; // блоков — радиус поиска

    private PriorityMode mode          = PriorityMode.NEAREST;
    private UUID         forcedTarget  = null;  // для режима FOCUS
    private int          retargetTimer = 0;

    private final BotEntity bot;

    public TargetPriority(BotEntity bot) {
        this.bot = bot;
    }

    public void setMode(PriorityMode m)        { this.mode = m; }
    public PriorityMode getMode()               { return mode; }
    public void setForcedTarget(UUID uuid)      { this.forcedTarget = uuid; this.mode = PriorityMode.FOCUS; }
    public void clearForcedTarget()             { this.forcedTarget = null; this.mode = PriorityMode.NEAREST; }

    /**
     * Главный тик. Возвращает лучшую цель (или null).
     * Вызывать из BotDifficultyAI / BotEntity.tick().
     */
    public LivingEntity tick() {
        retargetTimer--;

        LivingEntity current = bot.getTarget();

        // Проверяем нужно ли пересматривать
        boolean needRetarget = current == null
            || !current.isAlive()
            || bot.distanceTo(current) > ABANDON_RANGE
            || retargetTimer <= 0;

        if (!needRetarget) return current;

        retargetTimer = RETARGET_INTERVAL;
        LivingEntity best = findBest();
        if (best != null && best != current) {
            bot.setTarget(best);
            // v14: уведомление о найденной цели
            bot.getNotifier().onTargetFound(best);
        }
        return best != null ? best : current;
    }

    // ─────────────────────────────────────────────────────────────

    private LivingEntity findBest() {
        if (!(bot.getWorld() instanceof ServerWorld sw)) return null;

        // Режим FOCUS — ищем принудительную цель
        if (mode == PriorityMode.FOCUS && forcedTarget != null) {
            PlayerEntity p = sw.getPlayerByUuid(forcedTarget);
            if (p != null && p.isAlive() && bot.distanceTo(p) <= SCAN_RANGE) return p;
        }

        // Получаем список кандидатов
        List<PlayerEntity> candidates = sw.getPlayers(p ->
            !p.isSpectator()
            && p.isAlive()
            && bot.distanceTo(p) <= SCAN_RANGE
            && !isOwner(p)
            && isEnemy(p)
        );

        if (candidates.isEmpty()) return null;

        return switch (mode) {
            case NEAREST   -> candidates.stream()
                .min(Comparator.comparingDouble(p -> bot.squaredDistanceTo(p)))
                .orElse(null);
            case LOWEST_HP -> candidates.stream()
                .min(Comparator.comparingDouble(LivingEntity::getHealth))
                .orElse(null);
            case MOST_ITEMS -> candidates.stream()
                .max(Comparator.comparingInt(p -> countItems(p)))
                .orElse(null);
            default        -> candidates.stream()
                .min(Comparator.comparingDouble(p -> bot.squaredDistanceTo(p)))
                .orElse(null);
        };
    }

    private boolean isOwner(PlayerEntity p) {
        PlayerEntity owner = bot.getOwner();
        return owner != null && owner.getUuid().equals(p.getUuid());
    }

    private boolean isEnemy(PlayerEntity p) {
        // Проверяем whitelist — если включён, игроки в нём не цели
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (cfg.whitelistEnabled && cfg.whitelist.contains(p.getName().getString())) return false;
        return true;
    }

    private int countItems(PlayerEntity p) {
        int count = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (!p.getInventory().getStack(i).isEmpty()) count++;
        }
        return count;
    }
}
