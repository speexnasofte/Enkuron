package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;

/**
 * ComboBreaker — определяет когда бот попал под комбо врага и разрывает бой.
 *
 * ══════════════════════════════════════════════════════════════════
 *  АЛГОРИТМ ДЕТЕКЦИИ:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Бот попал под комбо если выполнено 2 из 3 условий:
 *    1. Получил 2+ удара за последние WINDOW_TICKS тиков
 *    2. HP упало на COMBO_HP_DROP_THRESHOLD за WINDOW_TICKS тиков
 *    3. Дистанция до врага <= COMBO_DIST_THRESHOLD (враг вплотную)
 *
 *  При детекции:
 *    A. Немедленный dash назад (импульс от цели)
 *    B. Если HARD/EXPERT — pearl-телепорт на 8 блоков назад
 *    C. Временный иммунитет к повторному срабатыванию (REARM_TICKS)
 *    D. Уведомление через BotNotifier
 *
 * ══════════════════════════════════════════════════════════════════
 *  ИНТЕГРАЦИЯ:
 * ══════════════════════════════════════════════════════════════════
 *  Вызывать из BotEntity.tick() ДО difficultyAI.tick():
 *
 *    if (comboBreaker.tick(getTarget())) return; // бот разрывает — пропускаем атаку
 *
 *  Также вызывать onDamageReceived(amount) из метода damage():
 *
 *    @Override
 *    public boolean damage(ServerWorld world, DamageSource source, float amount) {
 *        comboBreaker.onDamageReceived(amount);
 *        return super.damage(world, source, amount);
 *    }
 * ══════════════════════════════════════════════════════════════════
 */
public class ComboBreaker {

    // ── Константы ─────────────────────────────────────────────────
    /** Окно наблюдения за уронами (тики, ≈1 сек) */
    private static final int   WINDOW_TICKS          = 20;
    /** Сколько ударов подряд считается комбо врага */
    private static final int   HIT_COUNT_THRESHOLD   = 2;
    /** Падение HP за окно, считающееся комбо-уроном */
    private static final float COMBO_HP_DROP          = 5.0f;
    /** Максимальная дистанция для детекции (враг рядом) */
    private static final double COMBO_DIST            = 4.5;
    /** Тиков до следующего срабатывания */
    private static final int   REARM_TICKS            = 60;
    /** Сила импульса dash-назад */
    private static final double DASH_FORCE            = 0.85;
    /** Дистанция pearl-отрыва */
    private static final double PEARL_ESCAPE_DIST     = 9.0;
    /** Тиков dash-движения (бот двигается назад N тиков) */
    private static final int   DASH_DURATION          = 8;

    // ── Состояние ─────────────────────────────────────────────────
    private final BotEntity bot;

    /** Кольцевой буфер времён ударов (ringbuffer последних ударов) */
    private final long[] hitTimestamps = new long[8];
    private int  hitWriteIdx  = 0;
    private int  hitCount     = 0;   // ударов за последние WINDOW_TICKS

    /** HP в начале окна наблюдения */
    private float hpAtWindowStart = -1;
    private int   windowTimer     = 0;

    /** Кулдаун повторного срабатывания */
    private int   rearmTimer      = 0;
    /** Тики активного dash-назад */
    private int   dashTimer       = 0;

    /** Счётчик текущего тика (для временных меток) */
    private long  tickCounter     = 0;

    public ComboBreaker(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Вызов при получении урона (из BotEntity.damage())
    // ══════════════════════════════════════════════════════════════
    public void onDamageReceived(float amount) {
        // Записываем timestamp удара
        hitTimestamps[hitWriteIdx % hitTimestamps.length] = tickCounter;
        hitWriteIdx++;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    //  @return true если бот сейчас разрывает дистанцию (прерывать атаку)
    // ══════════════════════════════════════════════════════════════
    public boolean tick(LivingEntity target) {
        if (!(bot.getWorld() instanceof ServerWorld sw)) return false;

        tickCounter++;

        if (rearmTimer > 0) rearmTimer--;

        // ── Активный dash ─────────────────────────────────────────
        if (dashTimer > 0) {
            dashTimer--;
            applyDashImpulse(target);
            return true; // прерываем атаку пока дашим
        }

        if (target == null || !target.isAlive()) return false;
        if (rearmTimer > 0) return false;

        // ── Обновляем окно наблюдения ─────────────────────────────
        windowTimer++;
        if (windowTimer >= WINDOW_TICKS) {
            windowTimer    = 0;
            hpAtWindowStart = bot.getHealth();
        }
        if (hpAtWindowStart < 0) hpAtWindowStart = bot.getHealth();

        // ── Считаем удары за окно ─────────────────────────────────
        hitCount = 0;
        for (long ts : hitTimestamps) {
            if (ts > 0 && (tickCounter - ts) <= WINDOW_TICKS) {
                hitCount++;
            }
        }

        // ── Детекция комбо ────────────────────────────────────────
        float  hpDrop = hpAtWindowStart - bot.getHealth();
        double dist   = bot.distanceTo(target);

        int conditionsMet = 0;
        if (hitCount   >= HIT_COUNT_THRESHOLD) conditionsMet++;
        if (hpDrop     >= COMBO_HP_DROP)        conditionsMet++;
        if (dist       <= COMBO_DIST)           conditionsMet++;

        if (conditionsMet >= 2) {
            triggerBreak(sw, target);
            return true;
        }

        return false;
    }

    // ══════════════════════════════════════════════════════════════
    //  Срабатывание — разрыв дистанции
    // ══════════════════════════════════════════════════════════════
    private void triggerBreak(ServerWorld sw, LivingEntity target) {
        rearmTimer = REARM_TICKS;
        dashTimer  = DASH_DURATION;

        // Сбрасываем счётчик ударов
        java.util.Arrays.fill(hitTimestamps, 0);
        hitCount = 0;
        hpAtWindowStart = bot.getHealth();

        // ── Dash назад ────────────────────────────────────────────
        applyDashImpulse(target);

        // ── Pearl-отрыв на HARD/EXPERT ────────────────────────────
        PVPBotConfig.Difficulty diff = PVPBotConfig.INSTANCE.difficulty;
        if ((diff == PVPBotConfig.Difficulty.HARD || diff == PVPBotConfig.Difficulty.EXPERT)
                && PVPBotConfig.INSTANCE.diffUsePearls) {
            Vec3d escapePos = computeEscapePos(target);
            bot.teleport(escapePos.x, escapePos.y, escapePos.z);
            sw.spawnParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY() + 1, bot.getZ(),
                16, 0.3, 0.5, 0.3, 0.1);
            bot.playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }

        // ── Эффекты ───────────────────────────────────────────────
        sw.spawnParticles(ParticleTypes.SWEEP_ATTACK,
            bot.getX(), bot.getY() + 0.8, bot.getZ(),
            6, 0.4, 0.2, 0.4, 0.1);
        bot.playSound(SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 1.2f);

        // ── Уведомление ───────────────────────────────────────────
        bot.getNotifier().onComboBreak();
    }

    // ── Dash-импульс прочь от цели ────────────────────────────────
    private void applyDashImpulse(LivingEntity target) {
        if (target == null) return;
        Vec3d away = bot.getPos().subtract(target.getPos());
        if (away.lengthSquared() < 0.001) {
            // Если стоим на одном месте — боковой уход
            away = new Vec3d(1, 0, 0);
        }
        away = away.normalize().multiply(DASH_FORCE);
        Vec3d vel = bot.getVelocity();
        bot.setVelocity(
            vel.x * 0.3 + away.x,
            vel.y + 0.15,
            vel.z * 0.3 + away.z
        );
        bot.velocityModified = true;
    }

    // ── Позиция для pearl-отрыва ──────────────────────────────────
    private Vec3d computeEscapePos(LivingEntity target) {
        Vec3d away = bot.getPos().subtract(target.getPos()).normalize();
        return bot.getPos().add(away.multiply(PEARL_ESCAPE_DIST));
    }

    // ── Геттеры для HUD ──────────────────────────────────────────
    public int getHitCountInWindow() { return hitCount; }
    public boolean isBreaking()      { return dashTimer > 0; }
}
