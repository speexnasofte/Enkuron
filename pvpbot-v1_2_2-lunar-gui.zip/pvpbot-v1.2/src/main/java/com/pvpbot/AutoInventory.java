package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

public class AutoInventory {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int checkTimer = 0;

    // Минимальное количество предметов
    private static final int CRYSTALS_MIN = 16;
    private static final int TOTEMS_MIN   = 2;
    private static final int FOOD_MIN     = 8;

    public void tick(Minecraft mc) {
        if (mc.player == null || !cfg.autoRefill) return;
        checkTimer--;
        if (checkTimer > 0) return;
        checkTimer = 60; // проверка раз в 3 секунды

        Player player = mc.player;

        if (cfg.refillCrystals && cfg.mode == PVPBotConfig.Mode.CRYSTAL) {
            refill(mc, Items.END_CRYSTAL, CRYSTALS_MIN);
        }
        if (cfg.refillTotems) {
            refill(mc, Items.TOTEM_OF_UNDYING, TOTEMS_MIN);
        }
        if (cfg.refillFood) {
            refill(mc, Items.GOLDEN_APPLE, FOOD_MIN);
        }
    }

    private void refill(Minecraft mc, Item item, int min) {
        if (mc.player == null) return;
        int current = countItem(mc.player, item);
        if (current >= min) return;

        int need = min - current;
        String id = Registries.ITEM.getId(item).toString();
        // Использует /give — работает только с OP или в одиночной игре с читами
        mc.player.networkHandler.sendChatCommand("give @s " + id + " " + need);
    }

    private int countItem(Player player, Item item) {
        int count = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            var stack = player.getInventory().getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }
}
