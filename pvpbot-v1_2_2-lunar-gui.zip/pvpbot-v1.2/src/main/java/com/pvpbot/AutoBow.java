package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * AutoBow — автоматическая стрельба из лука/арбалета.
 *
 * Логика:
 *  1. Если в руке лук (BowItem) или арбалет (CrossbowItem) — активируемся
 *  2. Находим ближайшую цель в радиусе bowRange
 *  3. Прицеливаемся с учётом ГРАВИТАЦИИ стрелы (arc prediction)
 *  4. Натягиваем лук (удерживаем useKey) 20 тиков (полная сила)
 *  5. Отпускаем — стреляем
 *  6. Cooldown bowCooldown тиков
 *
 * Предсказание траектории:
 *   Скорость стрелы при полной зарядке ≈ 3.0 блока/тик
 *   Гравитация стрелы ≈ 0.05 блока/тик²
 *   Решаем квадратное уравнение для pitch компенсации
 */
public class AutoBow {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int chargeTimer   = 0;  // тики натяжения
    private int cooldownTimer = 0;  // тики после выстрела
    private boolean isCharging = false;

    private static final int FULL_CHARGE_TICKS = 20;
    private static final float ARROW_SPEED     = 3.0f; // блоков/тик при полном заряде
    private static final float ARROW_GRAVITY   = 0.05f; // блоков/тик²

    public void tick(Minecraft client) {
        if (!cfg.autoBowEnabled) return;
        if (client.player == null || client.world == null) return;

        Player player = client.player;

        // Проверяем: в руке лук или арбалет?
        boolean hasBow      = player.getMainHandStack().getItem() instanceof BowItem;
        boolean hasCrossbow = player.getMainHandStack().getItem() instanceof CrossbowItem;

        if (!hasBow && !hasCrossbow) {
            // Ищем лук в хотбаре
            for (int i = 0; i < 9; i++) {
                var stack = player.getInventory().getStack(i);
                if (stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem) {
                    player.getInventory().selectedSlot = i;
                    break;
                }
            }
            stopCharging(client);
            return;
        }

        cooldownTimer--;
        if (cooldownTimer > 0) return;

        // Ищем цель
        LivingEntity target = findBowTarget(client, player);

        if (target == null) {
            stopCharging(client);
            return;
        }

        // Прицеливаемся с предсказанием траектории
        aimWithPrediction(client, player, target);

        if (hasBow) {
            tickBow(client, player, target);
        } else {
            tickCrossbow(client, player, target);
        }
    }

    private void tickBow(Minecraft client, Player player, LivingEntity target) {
        if (!isCharging) {
            // Начинаем натягивать
            client.options.useKey.setPressed(true);
            isCharging = true;
            chargeTimer = 0;
        } else {
            chargeTimer++;
            if (chargeTimer >= FULL_CHARGE_TICKS) {
                // Полный заряд — отпускаем (выстрел)
                client.options.useKey.setPressed(false);
                isCharging = false;
                chargeTimer = 0;
                cooldownTimer = cfg.bowCooldown;
            }
        }
    }

    private void tickCrossbow(Minecraft client, Player player, LivingEntity target) {
        var stack = player.getMainHandStack();
        boolean loaded = CrossbowItem.isCharged(stack);

        if (!loaded) {
            // Заряжаем арбалет
            if (!isCharging) {
                client.options.useKey.setPressed(true);
                isCharging = true;
            }
        } else {
            // Заряжен — стреляем
            if (isCharging) {
                client.options.useKey.setPressed(false);
                isCharging = false;
            }
            // Атакуем (правая кнопка с заряженным арбалетом)
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);
            cooldownTimer = cfg.bowCooldown;
        }
    }

    /**
     * Прицеливание с предсказанием дуги полёта стрелы.
     * Компенсируем: гравитацию + движение цели (линейная экстраполяция).
     */
    private void aimWithPrediction(Minecraft client, Player player, LivingEntity target) {
        Vec3 playerEye = player.getEyePos();
        Vec3 targetPos = target.getPos().add(0, target.getHeight() * 0.6, 0); // центр тела

        double dx = targetPos.x - playerEye.x;
        double dy = targetPos.y - playerEye.y;
        double dz = targetPos.z - playerEye.z;
        double horizDist = Math.sqrt(dx * dx + dz * dz);

        // Время полёта (приближение): dist / arrow_speed
        double flightTime = horizDist / ARROW_SPEED;

        // Компенсация гравитации: нужно целиться выше на g*t²/2
        double gravComp = 0.5 * ARROW_GRAVITY * flightTime * flightTime;

        // Компенсация движения цели
        Vec3 vel = target.getVelocity();
        double predX = targetPos.x + vel.x * flightTime;
        double predY = targetPos.y + vel.y * flightTime + gravComp;
        double predZ = targetPos.z + vel.z * flightTime;

        double aimDx = predX - playerEye.x;
        double aimDy = predY - playerEye.y;
        double aimDz = predZ - playerEye.z;
        double aimH  = Math.sqrt(aimDx * aimDx + aimDz * aimDz);

        float yaw   = (float) Math.toDegrees(Math.atan2(-aimDx, aimDz));
        float pitch = (float) Math.toDegrees(-Math.atan2(aimDy, aimH));

        // Плавное прицеливание
        player.setYaw(lerpAngle(player.getYaw(), yaw, 0.4f));
        player.setPitch(lerp(player.getPitch(), pitch, 0.4f));
    }

    private LivingEntity findBowTarget(Minecraft client, Player player) {
        double range = cfg.bowRange;
        Box box = player.getBoundingBox().expand(range);
        List<LivingEntity> entities = client.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive() && !e.isInvisible()
        );
        return entities.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }

    private void stopCharging(Minecraft client) {
        if (isCharging) {
            client.options.useKey.setPressed(false);
            isCharging = false;
            chargeTimer = 0;
        }
    }

    private float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private float lerpAngle(float a, float b, float t) {
        float diff = ((b - a) % 360 + 540) % 360 - 180;
        return a + diff * t;
    }
}
