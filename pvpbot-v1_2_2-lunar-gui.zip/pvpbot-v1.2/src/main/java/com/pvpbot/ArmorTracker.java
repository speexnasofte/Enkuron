package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * ArmorTracker — v1.2: следит за прочностью брони врага.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Логика:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Каждые SAMPLE_INTERVAL тиков считает суммарную оставшуюся
 *  прочность брони цели (все 4 слота). Если прочность падает
 *  ниже LOW_DURABILITY_THRESHOLD — сигнализирует WeaponSwitcher
 *  переключиться на NETHERITE_AXE (топор снимает больше прочности
 *  за удар и быстрее доламывает броню).
 *
 *  В 1.21.11 прочность доступна через ItemStack.getDamage() /
 *  getMaxDamage(). Интеграция через BotDifficultyAI.tick().
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class ArmorTracker {

    // ── Константы ─────────────────────────────────────────────────
    /** Суммарная оставшаяся прочность ниже этого → переключаемся на AXE */
    private static final int   LOW_DURABILITY_THRESHOLD = 60;
    /** Тиков между замерами прочности */
    private static final int   SAMPLE_INTERVAL          = 20;
    /** Тиков сигнала «переключись на топор» (не дёргать каждый тик) */
    private static final int   SIGNAL_DURATION          = 40;

    // ── Состояние ─────────────────────────────────────────────────
    private int   sampleTimer    = 0;
    private int   signalTimer    = 0;   // > 0 → рекомендуем AXE
    private int   lastTotalDur   = -1;  // кэш прочности (для HUD)

    private final BotEntity bot;

    public ArmorTracker(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик. Вызывать из BotDifficultyAI.tick().
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (signalTimer > 0) signalTimer--;

        sampleTimer++;
        if (sampleTimer < SAMPLE_INTERVAL) return;
        sampleTimer = 0;

        int totalDur = calcRemainingDurability(target);
        lastTotalDur = totalDur;

        if (totalDur >= 0 && totalDur < LOW_DURABILITY_THRESHOLD) {
            signalTimer = SIGNAL_DURATION;
        }
    }

    /**
     * @return true если прочность брони врага критически низкая —
     *         WeaponSwitcher должен выбрать топор.
     */
    public boolean shouldUseAxe() {
        return signalTimer > 0;
    }

    /** Суммарная оставшаяся прочность всей брони (для HUD). -1 если нет брони. */
    public int getLastTotalDurability() {
        return lastTotalDur;
    }

    // ── Внутренние ───────────────────────────────────────────────

    /**
     * Считает суммарную оставшуюся прочность по 4 слотам брони.
     * Возвращает -1 если ни одного слота с бронёй нет.
     */
    private int calcRemainingDurability(LivingEntity target) {
        EquipmentSlot[] armorSlots = {
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        };

        int total   = 0;
        boolean any = false;

        for (EquipmentSlot slot : armorSlots) {
            ItemStack stack = target.getEquippedStack(slot);
            if (stack.isEmpty()) continue;
            // Фикс v1.2.1: maxDamage=0 означает предмет без прочности (нельзя сломать)
            // Кожа (55), железо (165), алмаз (363), незерит (407) — все > 0, учитываем
            if (stack.getMaxDamage() <= 0) continue;

            int remaining = stack.getMaxDamage() - stack.getDamage();
            total += remaining;
            any    = true;
        }

        return any ? total : -1;
    }
}
