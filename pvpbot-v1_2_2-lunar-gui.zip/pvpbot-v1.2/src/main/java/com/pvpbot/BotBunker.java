package com.pvpbot;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/**
 * BotBunker — v15: бот строит стену вокруг себя при низком HP.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Поведение:
 * ══════════════════════════════════════════════════════════════════
 *
 *  При HP < bunkerHpThreshold бот:
 *    1. Останавливается (навигация сбрасывается)
 *    2. Строит стену из 4 блоков вокруг себя (N/S/E/W)
 *    3. Ставит «крышу» над собой (1 блок)
 *    4. Ждёт внутри STAY_TICKS тиков или пока HP не восстановится
 *    5. Разрушает стену (убирает свои блоки) и продолжает бой
 *
 *  Материал стены: Obsidian (самый прочный)
 *  Кулдаун между бункерами: REARM_TICKS
 *
 * ══════════════════════════════════════════════════════════════════
 *  Интеграция в BotEntity.tick():
 * ══════════════════════════════════════════════════════════════════
 *
 *    if (PVPBotConfig.INSTANCE.bunkerEnabled) {
 *        if (bunker.tick()) return; // бот в бункере — не атакуем
 *    }
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class BotBunker {

    // ── Константы ─────────────────────────────────────────────────
    /** Тиков ожидания в бункере (~3 сек) */
    private static final int STAY_TICKS   = 60;
    /** Кулдаун между активациями (~10 сек) */
    private static final int REARM_TICKS  = 200;
    /** Материал стены */
    private static final Block WALL_BLOCK = Blocks.OBSIDIAN;
    /** Смещения для 4 стен (N/S/E/W) + крыша */
    private static final int[][] WALL_OFFSETS = {
        { 1, 0,  0}, {-1, 0,  0},
        { 0, 0,  1}, { 0, 0, -1},
        { 0, 1,  0}  // крыша
    };

    // ── Состояния ─────────────────────────────────────────────────
    private enum State { IDLE, BUILDING, INSIDE, DEMOLISHING }

    private State state      = State.IDLE;
    private int   stayTimer  = 0;
    private int   rearmTimer = 0;
    private int   buildStep  = 0;

    /** Позиции блоков которые мы поставили (чтобы убрать) */
    private final BlockPos[] builtBlocks = new BlockPos[WALL_OFFSETS.length];

    private final BotEntity bot;

    public BotBunker(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    //  @return true — бот в бункере (прерывать атаку)
    // ══════════════════════════════════════════════════════════════
    public boolean tick() {
        if (!(bot.level() instanceof ServerLevel sw)) return false;
        if (!PVPBotConfig.INSTANCE.bunkerEnabled)      return false;

        if (rearmTimer > 0) rearmTimer--;

        return switch (state) {
            case IDLE        -> tickIdle(sw);
            case BUILDING    -> tickBuilding(sw);
            case INSIDE      -> tickInside(sw);
            case DEMOLISHING -> tickDemolishing(sw);
        };
    }

    // ── IDLE: ждём низкого HP ─────────────────────────────────────
    private boolean tickIdle(ServerLevel sw) {
        if (rearmTimer > 0) return false;
        float hp = bot.getHealth();
        float threshold = PVPBotConfig.INSTANCE.bunkerHpThreshold;
        if (hp > threshold) return false;

        // Активируем бункер
        bot.getNavigation().stop();
        state     = State.BUILDING;
        buildStep = 0;
        java.util.Arrays.fill(builtBlocks, null);

        bot.getNotifier().send("§e🧱 Бункер! HP=" + String.format("%.0f", hp));
        return true;
    }

    // ── BUILDING: ставим блоки по одному в тик ───────────────────
    private boolean tickBuilding(ServerLevel sw) {
        if (buildStep >= WALL_OFFSETS.length) {
            // Все блоки поставлены
            state     = State.INSIDE;
            stayTimer = STAY_TICKS;
            return true;
        }

        int[] off = WALL_OFFSETS[buildStep];
        BlockPos pos = bot.getBlockPos().add(off[0], off[1], off[2]);

        // Ставим блок только если там воздух/замещаемый
        if (sw.getBlockState(pos).isReplaceable()) {
            sw.setBlockState(pos, WALL_BLOCK.getDefaultState());
            builtBlocks[buildStep] = pos;

            sw.playSound(null, pos, SoundEvents.BLOCK_STONE_PLACE,
                SoundSource.BLOCKS, 0.6f, 0.9f);
        }

        buildStep++;
        return true;
    }

    // ── INSIDE: ждём и лечимся ────────────────────────────────────
    private boolean tickInside(ServerLevel sw) {
        stayTimer--;

        // Выходим если HP восстановилось или время вышло
        boolean hpOk = bot.getHealth() >= PVPBotConfig.INSTANCE.bunkerHpThreshold + 6.0f;
        if (stayTimer <= 0 || hpOk) {
            state     = State.DEMOLISHING;
            buildStep = 0;
            bot.getNotifier().send("§a🧱 Выхожу из бункера (HP=" +
                String.format("%.0f", bot.getHealth()) + ")");
        }
        return true;
    }

    // ── DEMOLISHING: убираем блоки ────────────────────────────────
    private boolean tickDemolishing(ServerLevel sw) {
        // Убираем по одному блоку в тик
        while (buildStep < builtBlocks.length) {
            BlockPos pos = builtBlocks[buildStep];
            buildStep++;
            if (pos == null) continue;

            // Убираем только если это наш блок (никто не заменил)
            if (sw.getBlockState(pos).is(WALL_BLOCK)) {
                sw.removeBlock(pos, false);
                sw.playSound(null, pos, SoundEvents.BLOCK_STONE_BREAK,
                    SoundSource.BLOCKS, 0.5f, 1.1f);
            }
            return true; // по одному в тик
        }

        // Всё убрали
        state     = State.IDLE;
        rearmTimer = REARM_TICKS;
        return false;
    }

    // ── Геттеры для GUI/HUD ───────────────────────────────────────
    public boolean isActive()  { return state != State.IDLE; }
    public State   getState()  { return state; }

    public String getStateLabel() {
        return switch (state) {
            case IDLE        -> "";
            case BUILDING    -> "BUNKER:BUILD";
            case INSIDE      -> "BUNKER:WAIT " + stayTimer + "t";
            case DEMOLISHING -> "BUNKER:DEMO";
        };
    }
}
