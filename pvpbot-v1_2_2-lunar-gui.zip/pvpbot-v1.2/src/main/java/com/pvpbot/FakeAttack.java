package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * FakeAttack — v16: бот изображает замах (swing) но не бьёт.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Зачем:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Противник (особенно новичок) видит анимацию атаки и поднимает щит
 *  или нажимает блок. Бот в этот момент НЕ бьёт, а через 1-2 тика
 *  наносит настоящий удар — щит уже поднят впустую.
 *
 *  Также полезно против авто-блокировщиков: заставляет их
 *  «потратить» блок на пустышку.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Алгоритм:
 * ══════════════════════════════════════════════════════════════════
 *
 *  1. С вероятностью FAKE_CHANCE бот решает сделать фейк вместо удара.
 *  2. Отправляет swingHand-анимацию и звук свиста меча.
 *  3. Ждёт PAUSE_TICKS тиков (противник поднимает щит).
 *  4. Наносит настоящий удар.
 *
 *  Использование в SwordLogic / атакующей логике:
 *
 *    if (fakeAttack.shouldFake(target)) {
 *        fakeAttack.startFake(target);   // вместо обычной атаки
 *        return;
 *    }
 *    // обычная атака
 *
 *  В каждом тике:
 *    fakeAttack.tick(target)  — вернёт true если фейк ещё идёт
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class FakeAttack {

    // ── Константы ─────────────────────────────────────────────────
    /** Вероятность фейк-атаки (0..1) */
    private static final float FAKE_CHANCE   = 0.18f;
    /** Тиков паузы между замахом и реальным ударом */
    private static final int   PAUSE_TICKS   = 3;
    /** Минимальный кулдаун между фейками */
    private static final int   FAKE_COOLDOWN = 40;
    /** Не делаем фейк если цель дальше этой дистанции */
    private static final double MAX_RANGE    = 4.5;

    // ── Состояние ─────────────────────────────────────────────────
    private boolean active        = false;
    private int     pauseTimer    = 0;
    private int     fakeCooldown  = 0;
    private LivingEntity fakeTarget = null;

    private final BotEntity bot;

    public FakeAttack(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Проверка — стоит ли делать фейк прямо сейчас
    // ══════════════════════════════════════════════════════════════
    public boolean shouldFake(LivingEntity target) {
        if (!PVPBotConfig.INSTANCE.fakeAttackEnabled) return false;
        if (active)                                    return false;
        if (fakeCooldown > 0)                          return false;
        if (target == null || !target.isAlive())       return false;
        if (bot.distanceTo(target) > MAX_RANGE)        return false;

        return Math.random() < FAKE_CHANCE;
    }

    // ══════════════════════════════════════════════════════════════
    //  Запуск фейка
    // ══════════════════════════════════════════════════════════════
    public void startFake(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        active      = true;
        pauseTimer  = PAUSE_TICKS;
        fakeTarget  = target;

        // Анимация замаха (без урона)
        bot.swingHand(net.minecraft.util.InteractionHand.MAIN_HAND);

        // Звук свиста меча (чтобы противник слышал)
        sw.playSound(null, bot.getX(), bot.getY(), bot.getZ(),
            SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
            SoundSource.PLAYERS, 0.6f, 1.0f);
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик — вызывать каждый тик атакующей логики
    //  @return true если сейчас в процессе фейка (не атакуем)
    // ══════════════════════════════════════════════════════════════
    public boolean tick(LivingEntity target) {
        if (fakeCooldown > 0) fakeCooldown--;
        if (!active) return false;

        pauseTimer--;

        if (pauseTimer <= 0) {
            // Пауза истекла — теперь настоящий удар
            active = false;
            fakeCooldown = FAKE_COOLDOWN;

            LivingEntity realTarget = (fakeTarget != null && fakeTarget.isAlive())
                ? fakeTarget : target;

            if (realTarget != null && bot.distanceTo(realTarget) <= MAX_RANGE) {
                bot.tryAttack(realTarget);

                if (bot.level() instanceof ServerLevel sw) {
                    sw.playSound(null, bot.getX(), bot.getY(), bot.getZ(),
                        SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                        SoundSource.PLAYERS, 0.9f, 1.0f);
                }
            }

            fakeTarget = null;
            return false; // после удара — не блокируем следующий тик
        }

        return true; // пауза ещё идёт
    }

    // ── Геттеры ───────────────────────────────────────────────────
    public boolean isActive()  { return active; }
    public int  getCooldown()  { return fakeCooldown; }
}
