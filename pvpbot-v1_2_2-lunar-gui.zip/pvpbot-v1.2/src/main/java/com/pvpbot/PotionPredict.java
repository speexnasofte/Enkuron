package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * PotionPredict — v1.2: детектирует момент когда враг пьёт зелье.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Механика:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В 1.21.11 target.isUsingItem() == true пока игрок держит кнопку
 *  использования предмета (зелье, еда, лук и т.д.).
 *  getItemUseTimeLeft() убывает от 32 до 0 (зелья занимают 32 тика).
 *
 *  При питье зелья враг:
 *   - не может атаковать
 *   - не может блокировать щитом
 *   - движется медленнее (держит правую кнопку)
 *
 *  Окно уязвимости ≈ 30-40 тиков — сигналим атакующей логике.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Использование:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В BotDifficultyAI.tick() / PVPBotLogic.tick():
 *
 *    if (potionPredict.isDrinking(target)) {
 *        // rush-атака: сближаемся и бьём сразу без прыжка-крита
 *        attackNow(target);
 *    }
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class PotionPredict {

    // ── Константы ─────────────────────────────────────════════════
    /** Тиков после окончания питья, когда всё ещё атакуем (враг ещё медленный) */
    private static final int GRACE_TICKS = 8;
    /** Тиков кулдауна между rush-атаками (чтобы не спамить) */
    private static final int RUSH_CD     = 20;

    // ── Состояние ─────────────────────────────────────────────────
    private boolean wasUsingItem  = false;
    private int     graceTimer    = 0;
    private int     rushCooldown  = 0;

    private final BotEntity bot;

    public PotionPredict(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик. Вызывать каждый тик из BotDifficultyAI.
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (rushCooldown > 0) rushCooldown--;
        if (graceTimer   > 0) graceTimer--;

        boolean using = isUsingPotion(target);

        // Момент начала питья — запускаем graceTimer
        // Фикс v1.2.1: используем реальное время через getItemUseTimeLeft()
        if (using && !wasUsingItem) {
            int useTimeLeft = target.getItemUseTimeLeft();
            graceTimer = GRACE_TICKS + Math.max(useTimeLeft, 8);
        }

        // Момент окончания питья — grace-период
        if (!using && wasUsingItem && graceTimer <= 0) {
            graceTimer = GRACE_TICKS;
        }

        wasUsingItem = using;
    }

    /**
     * @return true если враг прямо сейчас в уязвимом состоянии
     *         (пьёт зелье или только что допил).
     */
    public boolean isVulnerable() {
        return (wasUsingItem || graceTimer > 0) && rushCooldown <= 0;
    }

    /**
     * Вызывать когда совершили rush-атаку — запускает кулдаун
     * чтобы не атаковать спамом.
     */
    public void onRushAttack() {
        rushCooldown = RUSH_CD;
    }

    // ── Внутренние ───────────────────────────────────────────────

    /**
     * Определяем — пьёт ли враг именно зелье (не ест, не тянет лук).
     * В 1.21.11: isUsingItem() + проверяем предмет в активной руке.
     */
    private boolean isUsingPotion(LivingEntity target) {
        if (!target.isUsingItem()) return false;

        ItemStack active = target.getActiveItem();
        if (active.isEmpty()) return false;

        return active.is(Items.POTION)
            || active.is(Items.SPLASH_POTION)
            || active.is(Items.LINGERING_POTION);
    }
}
