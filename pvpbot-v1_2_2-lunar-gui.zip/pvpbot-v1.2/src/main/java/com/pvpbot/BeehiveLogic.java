package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

import java.util.List;

/**
 * BeehiveLogic — v14: режим BEEHIVE.
 *
 * Механика:
 *   1. Бот держит Beehive (Honey Bottle) в оффхенде для регена HP.
 *   2. Периодически "призывает" ближайших пчёл в радиусе и направляет к цели.
 *   3. Если пчёл нет — атакует сам мечом пока пчёлы не появятся.
 *   4. При HP < порога — выпивает Honey Bottle (рег через эффект насыщения).
 *
 * Совместимость: 1.21.11
 */
public class BeehiveLogic {

    private static final double BEE_SEARCH_RADIUS  = 20.0;
    private static final int    HONEY_USE_COOLDOWN  = 80;   // тиков
    private static final float  HONEY_HP_THRESHOLD  = 12.0f;
    private static final int    ATTACK_COOLDOWN     = 8;

    private int honeyCooldown  = 0;
    private int attackCooldown = 0;

    private final BotEntity bot;

    public BeehiveLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (honeyCooldown > 0)  honeyCooldown--;
        if (attackCooldown > 0) attackCooldown--;

        equipBeehiveKit();

        // Рег мёдом при низком HP
        if (bot.getHealth() < HONEY_HP_THRESHOLD && honeyCooldown <= 0) {
            useHoney(sw);
        }

        // Найти пчёл рядом и направить к цели
        int beesSent = sendBeesToTarget(sw, target);

        // Если пчёл мало — самостоятельно атакуем мечом
        if (beesSent < 2 && attackCooldown <= 0 && bot.distanceTo(target) < 3.5) {
            target.hurt(sw, sw.getDamageSources().mobAttack(bot), 6.0f);
            bot.swingHand(net.minecraft.util.InteractionHand.MAIN_HAND);
            attackCooldown = ATTACK_COOLDOWN;
        }

        // Двигаемся к цели
        if (bot.distanceTo(target) > 4.0) {
            bot.getNavigation().moveTo(target, 1.1);
        }
    }

    private int sendBeesToTarget(ServerLevel sw, LivingEntity target) {
        Box searchBox = bot.getBoundingBox().expand(BEE_SEARCH_RADIUS);
        List<Bee> bees = sw.getEntitiesByClass(Bee.class, searchBox,
            b -> !b.isRemoved() && b.isAlive());

        int count = 0;
        for (Bee bee : bees) {
            if (count >= 5) break; // максимум 5 пчёл
            bee.setTarget(target);
            bee.setAngerTime(400);
            bee.setAngryAt(target.getUUID());
            // Направить пчелу к цели
            Vec3 dir = target.position().subtract(bee.position()).normalize().scale(0.5);
            bee.setVelocity(dir);
            bee.velocityModified = true;
            count++;
        }

        if (count > 0) {
            // Эффект "улья"
            sw.spawnParticles(ParticleTypes.WAX_ON,
                bot.getX(), bot.getY() + 1, bot.getZ(),
                5, 0.3, 0.3, 0.3, 0.05);
        }

        return count;
    }

    private void useHoney(ServerLevel sw) {
        // Симулируем выпивание мёда (даём эффект насыщения)
        bot.heal(4.0f);
        sw.spawnParticles(ParticleTypes.ITEM_SLIME,
            bot.getX(), bot.getY() + 1, bot.getZ(),
            8, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(SoundEvents.ITEM_HONEY_BOTTLE_DRINK, 1.0f, 1.0f);
        honeyCooldown = HONEY_USE_COOLDOWN;
    }

    private void equipBeehiveKit() {
        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (main.isEmpty() || main.is(Items.AIR)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        }
        ItemStack off = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (off.isEmpty() || off.is(Items.AIR)) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.HONEY_BOTTLE));
        }
    }
}
