package com.pvpbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;

/**
 * AutoArmor  — автоматически экипирует лучшую броню из инвентаря.
 * AutoTotem  — держит тотем бессмертия в левой (offhand) руке.
 *
 * ✅ FIX: API зачарований исправлен для 1.21 (DataComponentTypes.ENCHANTMENTS).
 */
public class AutoArmorTotem {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int checkTimer = 0;

    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        checkTimer--;
        if (checkTimer > 0) return;
        checkTimer = 20;

        if (cfg.autoTotem) equipTotem(mc.player);
        if (cfg.autoArmor) equipBestArmor(mc.player);
    }

    // ── Авто-тотем ──────────────────────────────────────────────
    private void equipTotem(PlayerEntity player) {
        ItemStack offhand = player.getOffHandStack();
        if (offhand.isOf(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                player.getInventory().offHand.set(0, stack.copy());
                player.getInventory().removeStack(i, 1);
                return;
            }
        }
    }

    // ── Авто-броня ──────────────────────────────────────────────
    private void equipBestArmor(PlayerEntity player) {
        tryEquipSlot(player, EquipmentSlot.HEAD,  ArmorItem.Type.HELMET);
        tryEquipSlot(player, EquipmentSlot.CHEST, ArmorItem.Type.CHESTPLATE);
        tryEquipSlot(player, EquipmentSlot.LEGS,  ArmorItem.Type.LEGGINGS);
        tryEquipSlot(player, EquipmentSlot.FEET,  ArmorItem.Type.BOOTS);
    }

    private void tryEquipSlot(PlayerEntity player, EquipmentSlot slot, ArmorItem.Type armorType) {
        ItemStack current = player.getEquippedStack(slot);
        int currentProt = armorProtection(current);

        int bestSlot = -1;
        int bestProt = currentProt;

        for (int i = 0; i < player.getInventory().main.size(); i++) {
            ItemStack stack = player.getInventory().main.get(i);
            if (stack.getItem() instanceof ArmorItem ai && ai.getType() == armorType) {
                int prot = armorProtection(stack);
                if (prot > bestProt) {
                    bestProt = prot;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != -1) {
            ItemStack best = player.getInventory().main.get(bestSlot).copy();
            player.getInventory().main.set(bestSlot, current.isEmpty() ? ItemStack.EMPTY : current.copy());
            player.equipStack(slot, best);
        }
    }

    /**
     * ✅ FIX: Используем DataComponentTypes.ENCHANTMENTS (правильный API для 1.21).
     * Старый код stack.getEnchantments().getEnchantments().stream() не компилируется.
     */
    private int armorProtection(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem ai)) return 0;

        int base = ai.getProtection();

        // Компонент зачарований (новый API компонентов 1.20.5+)
        var enchComp = stack.get(DataComponentTypes.ENCHANTMENTS);
        if (enchComp == null) return base;

        int enchBonus = 0;
        for (var enchEntry : enchComp.getEnchantments()) {
            // Protection даёт +4 за уровень к нашей оценке
            String enchId = enchEntry.getIdAsString();
            if (enchId.contains("protection")) {
                enchBonus += enchComp.getLevel(enchEntry) * 4;
            }
        }
        return base + enchBonus;
    }
}
