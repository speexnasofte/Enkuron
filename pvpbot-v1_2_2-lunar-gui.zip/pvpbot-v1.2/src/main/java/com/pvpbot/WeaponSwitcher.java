package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * WeaponSwitcher — авто-смена оружия бота в зависимости от дистанции и ситуации (v12).
 *
 * Логика:
 *   dist > BOW_RANGE      → лук (дальний бой)
 *   dist > AXE_RANGE      → кристалл если режим CRYSTAL/TPC
 *   dist <= AXE_RANGE     → топор если режим AXE/TPC, иначе меч
 *   цель с щитом + топор  → бот выбирает топор (снимает блок)
 *
 * Вызывается из BotDifficultyAI каждый тик.
 */
public class WeaponSwitcher {

    // ── Дистанции переключения ────────────────────────────────────
    private static final double BOW_RANGE     = 12.0;
    private static final double AXE_RANGE     = 4.0;
    private static final double CRYSTAL_RANGE = 8.0;

    // ── Cooldown смены оружия (не менять каждый тик) ──────────────
    private static final int SWITCH_COOLDOWN = 10; // тиков
    private int switchTimer = 0;

    private final BotEntity bot;
    // v1.2: ArmorTracker
    private final ArmorTracker armorTracker;

    public WeaponSwitcher(BotEntity bot) {
        this.bot = bot;
        this.armorTracker = new ArmorTracker(bot);
    }

    public ArmorTracker getArmorTracker() { return armorTracker; }

    /**
     * Главный тик. Автоматически меняет оружие под ситуацию.
     */
    public void tick(LivingEntity target) {
        if (switchTimer > 0) { switchTimer--; return; }

        double dist = bot.distanceTo(target);
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;

        // v1.2: обновляем ArmorTracker
        armorTracker.tick(target);

        // Определяем нужное оружие
        Item desired = chooseWeapon(dist, mode, target);
        ItemStack current = bot.getEquippedStack(EquipmentSlot.MAINHAND);

        if (!isItem(current, desired)) {
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(desired));
            switchTimer = SWITCH_COOLDOWN;
        }
    }

    private net.minecraft.item.Item chooseWeapon(double dist, PVPBotConfig.Mode mode,
                                                  LivingEntity target) {
        // v1.2: ArmorTracker — если броня врага почти сломана, топор доломает быстрее
        if (armorTracker.shouldUseAxe() && dist <= AXE_RANGE) {
            return Items.NETHERITE_AXE;
        }

        // Режим Mace: булава в ближнем бою, лук на дальнем
        if (mode == PVPBotConfig.Mode.MACE) {
            if (dist > BOW_RANGE) return Items.BOW;
            // Mace наносит бонусный урон при падении сверху — всегда держим в руке
            return Items.MACE;
        }

        // Кристальный режим — кристаллы на средней дистанции
        if ((mode == PVPBotConfig.Mode.CRYSTAL || mode == PVPBotConfig.Mode.TPC)
                && dist <= CRYSTAL_RANGE && dist > AXE_RANGE) {
            return Items.END_CRYSTAL;
        }

        // Далеко — лук
        if (dist > BOW_RANGE) {
            return Items.BOW;
        }

        // Цель держит щит — топор чтобы снять блок
        boolean targetBlocking = isBlocking(target);
        if (targetBlocking) {
            return Items.NETHERITE_AXE;
        }

        // Режим с топором
        if (mode == PVPBotConfig.Mode.AXE || mode == PVPBotConfig.Mode.TPC) {
            return Items.NETHERITE_AXE;
        }

        // По умолчанию — меч
        return Items.NETHERITE_SWORD;
    }

    /** Проверить — цель держит щит (блокирует). */
    private boolean isBlocking(LivingEntity target) {
        ItemStack offhand = target.getEquippedStack(EquipmentSlot.OFFHAND);
        ItemStack mainhand = target.getEquippedStack(EquipmentSlot.MAINHAND);
        boolean hasShield = offhand.isOf(Items.SHIELD) || mainhand.isOf(Items.SHIELD);
        return hasShield && target.isBlocking();
    }

    private boolean isItem(ItemStack stack, net.minecraft.item.Item item) {
        return !stack.isEmpty() && stack.isOf(item);
    }
}
