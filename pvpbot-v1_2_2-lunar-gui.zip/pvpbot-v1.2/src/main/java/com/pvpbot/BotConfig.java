package com.pvpbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Сохраняет/загружает PVPBotConfig из JSON-файла.
 * Файл: .minecraft/config/pvpbot.json
 *
 * v8: добавлены W-Tap, AutoGap, DPS Meter поля.
 *     При старте также инициализирует ModuleManager.
 */
public class BotConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
        FabricLoader.getInstance().getConfigDir().resolve("pvpbot.json");

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) { save(); return; }
        try (Reader r = Files.newBufferedReader(CONFIG_PATH)) {
            PVPBotConfig loaded = GSON.fromJson(r, PVPBotConfig.class);
            if (loaded != null) copyInto(loaded, PVPBotConfig.INSTANCE);
        } catch (IOException e) {
            System.err.println("[PVPBot] Не удалось загрузить конфиг: " + e.getMessage());
        }
        // Синхронизируем ModuleManager из загруженного конфига
        syncModulesFromConfig();
    }

    public static void save() {
        // Перед сохранением синхронизируем конфиг из ModuleManager
        ModuleManager.INSTANCE.applyToConfig();
        try (Writer w = Files.newBufferedWriter(CONFIG_PATH)) {
            GSON.toJson(PVPBotConfig.INSTANCE, w);
        } catch (IOException e) {
            System.err.println("[PVPBot] Не удалось сохранить конфиг: " + e.getMessage());
        }
    }

    /**
     * Синхронизирует состояния модулей из PVPBotConfig в ModuleManager.
     * Вызывается после загрузки конфига, чтобы ModuleManager отражал
     * сохранённые значения.
     */
    private static void syncModulesFromConfig() {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        ModuleManager m  = ModuleManager.INSTANCE;

        m.setEnabled(ModuleManager.MOD_AUTO_ATTACK,  cfg.autoAttack);
        m.setEnabled(ModuleManager.MOD_AUTO_DODGE,   cfg.autoDodge);
        m.setEnabled(ModuleManager.MOD_AUTO_HEAL,    cfg.autoHeal);
        m.setEnabled(ModuleManager.MOD_AUTO_EAT,     cfg.autoEat);
        m.setEnabled(ModuleManager.MOD_AUTO_GAP,     cfg.autoGapEnabled);
        m.setEnabled(ModuleManager.MOD_AUTO_SPRINT,  cfg.autoSprint);
        m.setEnabled(ModuleManager.MOD_AUTO_TOTEM,   cfg.autoTotem);
        m.setEnabled(ModuleManager.MOD_AUTO_ARMOR,   cfg.autoArmor);
        m.setEnabled(ModuleManager.MOD_AUTO_BOW,     cfg.autoBowEnabled);
        m.setEnabled(ModuleManager.MOD_KITE,         cfg.kiteEnabled);
        m.setEnabled(ModuleManager.MOD_W_TAP,        cfg.wTapEnabled);
        m.setEnabled(ModuleManager.MOD_S_TAP,        cfg.sTapEnabled);
        m.setEnabled(ModuleManager.MOD_ESP,          cfg.espEnabled);
        m.setEnabled(ModuleManager.MOD_RADAR,        cfg.radarEnabled);
        m.setEnabled(ModuleManager.MOD_CRYSTAL,      cfg.autoCrystal);
        m.setEnabled(ModuleManager.MOD_STATS,        cfg.statsEnabled);
        m.setEnabled(ModuleManager.MOD_HUD,          cfg.showHud);

        // Параметры AutoGap
        ModuleManager.ModuleState gap = m.get(ModuleManager.MOD_AUTO_GAP);
        if (gap != null) gap.set("hp_threshold", cfg.autoGapHpThreshold);

        // Параметры W-Tap
        ModuleManager.ModuleState wtap = m.get(ModuleManager.MOD_W_TAP);
        if (wtap != null) wtap.set("release_ticks", cfg.wTapReleaseTicks);
    }

    private static void copyInto(PVPBotConfig src, PVPBotConfig dst) {
        // ── Базовые ───────────────────────────────────────────────
        dst.enabled         = src.enabled;
        dst.mode            = src.mode           != null ? src.mode           : dst.mode;
        dst.difficulty      = src.difficulty     != null ? src.difficulty     : dst.difficulty;
        dst.autoAttack      = src.autoAttack;
        dst.attackRange     = src.attackRange    > 0 ? src.attackRange    : dst.attackRange;
        dst.attackCooldown  = src.attackCooldown > 0 ? src.attackCooldown : dst.attackCooldown;
        dst.autoDodge       = src.autoDodge;
        dst.dodgeRange      = src.dodgeRange     > 0 ? src.dodgeRange     : dst.dodgeRange;
        dst.autoHeal        = src.autoHeal;
        dst.healThreshold   = src.healThreshold  > 0 ? src.healThreshold  : dst.healThreshold;
        dst.autoEat         = src.autoEat;
        dst.eatThreshold    = src.eatThreshold   > 0 ? src.eatThreshold   : dst.eatThreshold;
        dst.autoSprint      = src.autoSprint;
        dst.autoArmor       = src.autoArmor;
        dst.autoTotem       = src.autoTotem;
        dst.autoRespawn     = src.autoRespawn;
        dst.autoCrystal     = src.autoCrystal;
        dst.crystalPlaceRange = src.crystalPlaceRange > 0 ? src.crystalPlaceRange : dst.crystalPlaceRange;
        dst.crystalCooldown = src.crystalCooldown > 0 ? src.crystalCooldown : dst.crystalCooldown;
        dst.autoRefill      = src.autoRefill;
        dst.refillCrystals  = src.refillCrystals;
        dst.refillTotems    = src.refillTotems;
        dst.refillFood      = src.refillFood;
        dst.showHud         = src.showHud;
        dst.whitelist       = src.whitelist      != null ? src.whitelist      : dst.whitelist;
        dst.whitelistEnabled = src.whitelistEnabled;
        dst.maxBots         = src.maxBots        > 0 ? src.maxBots        : dst.maxBots;
        dst.botHealThreshold = src.botHealThreshold > 0 ? src.botHealThreshold : dst.botHealThreshold;
        dst.botHealItem     = src.botHealItem    != null ? src.botHealItem    : dst.botHealItem;

        // ── v8: W-Tap / S-Tap ─────────────────────────────────────
        dst.wTapEnabled      = src.wTapEnabled;
        dst.wTapReleaseTicks = src.wTapReleaseTicks > 0 ? src.wTapReleaseTicks : dst.wTapReleaseTicks;
        dst.sTapEnabled      = src.sTapEnabled;

        // ── v8: AutoGap ───────────────────────────────────────────
        dst.autoGapEnabled     = src.autoGapEnabled;
        dst.autoGapHpThreshold = src.autoGapHpThreshold > 0 ? src.autoGapHpThreshold : dst.autoGapHpThreshold;

        // ── v8: DPS Meter ─────────────────────────────────────────
        dst.showDps = src.showDps;

        // ── Визуал ────────────────────────────────────────────────
        dst.espEnabled   = src.espEnabled;
        dst.espRange     = src.espRange     > 0 ? src.espRange     : dst.espRange;
        dst.espLineWidth = src.espLineWidth > 0 ? src.espLineWidth : dst.espLineWidth;
        dst.radarEnabled = src.radarEnabled;
        dst.radarRadius  = src.radarRadius  > 0 ? src.radarRadius  : dst.radarRadius;
        dst.radarRange   = src.radarRange   > 0 ? src.radarRange   : dst.radarRange;
        dst.statsEnabled = src.statsEnabled;
        dst.autoBowEnabled = src.autoBowEnabled;
        dst.bowRange     = src.bowRange     > 0 ? src.bowRange     : dst.bowRange;
        dst.bowCooldown  = src.bowCooldown  > 0 ? src.bowCooldown  : dst.bowCooldown;
        dst.kiteEnabled  = src.kiteEnabled;
        dst.kiteMinDist  = src.kiteMinDist  > 0 ? src.kiteMinDist  : dst.kiteMinDist;
        dst.kiteMaxDist  = src.kiteMaxDist  > 0 ? src.kiteMaxDist  : dst.kiteMaxDist;
        dst.advPathfind  = src.advPathfind;

        // ── BotDifficultyAI ───────────────────────────────────────
        dst.diffUsePearls              = src.diffUsePearls;
        dst.diffPearlThrowDist         = src.diffPearlThrowDist    > 0 ? src.diffPearlThrowDist    : dst.diffPearlThrowDist;
        dst.diffPearlCooldown          = src.diffPearlCooldown     > 0 ? src.diffPearlCooldown     : dst.diffPearlCooldown;
        dst.diffPearlEscapeHpThreshold = src.diffPearlEscapeHpThreshold > 0 ? src.diffPearlEscapeHpThreshold : dst.diffPearlEscapeHpThreshold;
        dst.diffPearlEscapeDist        = src.diffPearlEscapeDist   > 0 ? src.diffPearlEscapeDist   : dst.diffPearlEscapeDist;
        dst.diffBowSwitchRange         = src.diffBowSwitchRange    > 0 ? src.diffBowSwitchRange    : dst.diffBowSwitchRange;
        dst.diffBowCooldown            = src.diffBowCooldown       > 0 ? src.diffBowCooldown       : dst.diffBowCooldown;
        dst.diffUseCrystals            = src.diffUseCrystals;
        dst.diffCrystalPlaceRange      = src.diffCrystalPlaceRange > 0 ? src.diffCrystalPlaceRange : dst.diffCrystalPlaceRange;
        dst.diffCrystalCooldown        = src.diffCrystalCooldown   > 0 ? src.diffCrystalCooldown   : dst.diffCrystalCooldown;
        dst.diffCrystalDamage          = src.diffCrystalDamage     > 0 ? src.diffCrystalDamage     : dst.diffCrystalDamage;
        dst.diffComboLength            = src.diffComboLength       > 0 ? src.diffComboLength       : dst.diffComboLength;
        dst.diffComboPauseTicks        = src.diffComboPauseTicks   > 0 ? src.diffComboPauseTicks   : dst.diffComboPauseTicks;
        dst.diffPredictTicks           = src.diffPredictTicks      > 0 ? src.diffPredictTicks      : dst.diffPredictTicks;
    }
}
