package com.pvpbot;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;

/**
 * Регистрация типа сущности бота.
 */
public class BotEntityType {

    public static final EntityType<BotEntity> BOT_ENTITY;

    static {
        BOT_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            ResourceLocation.fromNamespaceAndPath("pvpbot", "pvp_bot"),
            FabricEntityTypeBuilder.<BotEntity>create(MobCategory.MISC, BotEntity::new)
                .dimensions(EntityDimensions.fixed(0.6f, 1.95f)) // как игрок
                .build()
        );
    }

    public static void register() {
        // Вызов этого метода инициализирует static-блок
    }
}
