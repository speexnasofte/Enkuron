package com.pvpbot;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

/**
 * Команды для управления ботом (v4):
 *   /bot spawn [count]  — заспавнить 1–N ботов рядом
 *   /bot kill           — убить всех ботов этого игрока
 *   /bot mode           — переключить режим GUARD / AGGRESSIVE / PASSIVE
 *   /bot tp             — телепортировать ботов к себе
 *   /bot equip          — выдать ботам снаряжение (netherite)
 *   /bot whitelist add <nick>
 *   /bot whitelist remove <nick>
 *   /bot whitelist on|off
 *
 * ✅ Whitelist: если включён, только перечисленные ники могут использовать /bot.
 * ✅ Multi-spawn: /bot spawn 3 спавнит 3 бота сразу (до maxBots).
 */
public class SpawnBotCommand {

    private static final Map<UUID, List<BotEntity>> playerBots = new HashMap<>();
    private static final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            registerCommands(dispatcher)
        );
    }

    private static void registerCommands(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("bot")
            // /bot spawn [count] | /bot spawn <nick> [count]
            .then(CommandManager.literal("spawn")
                .executes(ctx -> spawnBotsWithSkin(ctx.getSource(), null, 1))
                .then(CommandManager.argument("count", IntegerArgumentType.integer(1, 10))
                    .executes(ctx -> spawnBotsWithSkin(ctx.getSource(), null,
                        IntegerArgumentType.getInteger(ctx, "count"))))
                // /bot spawn <nick>  — спавн со скином игрока
                .then(CommandManager.argument("nick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> spawnBotsWithSkin(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick"), 1))
                    .then(CommandManager.argument("count2", IntegerArgumentType.integer(1, 10))
                        .executes(ctx -> spawnBotsWithSkin(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick"),
                            IntegerArgumentType.getInteger(ctx, "count2"))))
                )
            )
            .then(CommandManager.literal("kill").executes(ctx -> killBots(ctx.getSource())))
            .then(CommandManager.literal("mode").executes(ctx -> cycleMode(ctx.getSource())))
            .then(CommandManager.literal("tp").executes(ctx -> tpBot(ctx.getSource())))
            .then(CommandManager.literal("help").executes(ctx -> help(ctx.getSource())))
            // /bot formation <follow|line|flank|surround>  (v10)
            .then(CommandManager.literal("formation")
                .then(CommandManager.literal("follow")  .executes(ctx -> setFormation(ctx.getSource(), "follow")))
                .then(CommandManager.literal("line")    .executes(ctx -> setFormation(ctx.getSource(), "line")))
                .then(CommandManager.literal("flank")   .executes(ctx -> setFormation(ctx.getSource(), "flank")))
                .then(CommandManager.literal("surround").executes(ctx -> setFormation(ctx.getSource(), "surround")))
            )
            // /bot regroup [teleport|pathfind|formation]  (v10)
            .then(CommandManager.literal("regroup")
                .executes(ctx -> regroupBots(ctx.getSource(), "pathfind"))
                .then(CommandManager.literal("teleport") .executes(ctx -> regroupBots(ctx.getSource(), "teleport")))
                .then(CommandManager.literal("pathfind") .executes(ctx -> regroupBots(ctx.getSource(), "pathfind")))
                .then(CommandManager.literal("formation").executes(ctx -> regroupBots(ctx.getSource(), "formation")))
            )
            // /bot equip smart  (v10) — умная экипировка
            .then(CommandManager.literal("equip")
                .executes(ctx -> equipBot(ctx.getSource()))
                .then(CommandManager.literal("smart").executes(ctx -> equipBotSmart(ctx.getSource())))
            )
            // ── v12: /bot clone ───────────────────────────────────
            .then(CommandManager.literal("clone")
                .executes(ctx -> cloneToggle(ctx.getSource()))
                .then(CommandManager.literal("on") .executes(ctx -> cloneSet(ctx.getSource(), true)))
                .then(CommandManager.literal("off").executes(ctx -> cloneSet(ctx.getSource(), false)))
            )
            // ── v12: /bot target <priority> ───────────────────────
            .then(CommandManager.literal("target")
                .then(CommandManager.literal("nearest")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.NEAREST)))
                .then(CommandManager.literal("lowhp")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.LOWEST_HP)))
                .then(CommandManager.literal("items")
                    .executes(ctx -> setTargetPriority(ctx.getSource(), TargetPriority.PriorityMode.MOST_ITEMS)))
                .then(CommandManager.argument("forcedNick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> setForcedTarget(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "forcedNick"))))
            )
            // ── v12: /bot strafe <style> ──────────────────────────
            .then(CommandManager.literal("strafe")
                .then(CommandManager.literal("circle") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.CIRCLE)))
                .then(CommandManager.literal("random") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.RANDOM)))
                .then(CommandManager.literal("zigzag") .executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.ZIGZAG)))
                .then(CommandManager.literal("retreat").executes(ctx -> setStrafeStyle(ctx.getSource(), StrafeAI.StrafeStyle.RETREAT)))
            )
            // ── v12: /bot sync ────────────────────────────────────
            .then(CommandManager.literal("sync")
                // /bot sync attack [ник]
                .then(CommandManager.literal("attack")
                    .executes(ctx -> syncAttack(ctx.getSource(), null))
                    .then(CommandManager.argument("targetName",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> syncAttack(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "targetName"))))
                )
                // /bot sync stop
                .then(CommandManager.literal("stop")
                    .executes(ctx -> syncStop(ctx.getSource())))
                // /bot sync mode <focus|surround>
                .then(CommandManager.literal("mode")
                    .then(CommandManager.literal("focus")
                        .executes(ctx -> syncMode(ctx.getSource(), BotSyncAttack.SyncMode.FOCUS)))
                    .then(CommandManager.literal("surround")
                        .executes(ctx -> syncMode(ctx.getSource(), BotSyncAttack.SyncMode.SURROUND)))
                )
                // /bot sync auto <on|off>
                .then(CommandManager.literal("auto")
                    .then(CommandManager.literal("on")
                        .executes(ctx -> syncAuto(ctx.getSource(), true)))
                    .then(CommandManager.literal("off")
                        .executes(ctx -> syncAuto(ctx.getSource(), false)))
                )
                // /bot sync status
                .then(CommandManager.literal("status")
                    .executes(ctx -> syncStatus(ctx.getSource())))
            )
            // ── v12: /bot kit <name> ─────────────────────────────
            .then(CommandManager.literal("kit")
                .executes(ctx -> listKits(ctx.getSource()))
                .then(CommandManager.argument("kitName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> applyKit(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "kitName"))))
            )
            // ── v14: /bot pattern ────────────────────────────────
            .then(CommandManager.literal("pattern")
                .then(CommandManager.literal("on").executes(ctx -> {
                    PVPBotConfig.INSTANCE.patternAIEnabled = true;
                    PVPBotConfig.INSTANCE.antiPatternEnabled = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§aPatternAI §fвключён (обучение + антипаттерн)");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    PVPBotConfig.INSTANCE.patternAIEnabled = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7PatternAI выключен");
                    return 1;
                }))
            )
            // /bot difficulty <EASY|MEDIUM|HARD|EXPERT>
            .then(CommandManager.literal("difficulty")
                .then(CommandManager.literal("easy").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EASY)))
                .then(CommandManager.literal("medium").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.MEDIUM)))
                .then(CommandManager.literal("hard").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.HARD)))
                .then(CommandManager.literal("expert").executes(ctx ->
                    setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EXPERT)))
                .then(CommandManager.literal("status").executes(ctx ->
                    showDifficulty(ctx.getSource())))
            )
            // ── v14: /bot train [on|off] ──────────────────────────
            .then(CommandManager.literal("train")
                .executes(ctx -> trainStatus(ctx.getSource()))
                .then(CommandManager.literal("on").executes(ctx -> {
                    TrainingMode.INSTANCE.setActive(true);
                    PVPBotConfig.INSTANCE.trainingMode = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§a🎓 Обучающий режим §fвключён! Бот будет учить тебя PvP.");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    TrainingMode.INSTANCE.setActive(false);
                    PVPBotConfig.INSTANCE.trainingMode = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7Обучающий режим выключен.");
                    return 1;
                }))
            )
            // ── v14: /bot kitstats ────────────────────────────────
            .then(CommandManager.literal("kitstats")
                .executes(ctx -> showKitStats(ctx.getSource()))
                .then(CommandManager.literal("heatmap").executes(ctx -> showHeatmap(ctx.getSource())))
                .then(CommandManager.literal("reset").executes(ctx -> {
                    KitStatsTracker.INSTANCE.reset();
                    feedback(ctx.getSource(), "§eKitStats сброшены!");
                    return 1;
                }))
            )
            // /bot stats [reset]
            .then(CommandManager.literal("stats")
                .executes(ctx -> showStats(ctx.getSource()))
                .then(CommandManager.literal("reset").executes(ctx -> {
                    KillDeathTracker.reset();
                    feedback(ctx.getSource(), "§eСтатистика сброшена!");
                    return 1;
                }))
            )
            // /bot whitelist ...
            .then(CommandManager.literal("whitelist")
                .then(CommandManager.literal("on").executes(ctx -> {
                    cfg.whitelistEnabled = true;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§aWhitelist §fвключён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    cfg.whitelistEnabled = false;
                    BotConfig.save();
                    feedback(ctx.getSource(), "§7Whitelist §fвыключен");
                    return 1;
                }))
                .then(CommandManager.literal("add")
                    .then(CommandManager.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        if (!cfg.whitelist.contains(nick)) cfg.whitelist.add(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), "§a" + nick + " §fдобавлен в whitelist");
                        return 1;
                    }))
                )
                .then(CommandManager.literal("remove")
                    .then(CommandManager.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        cfg.whitelist.remove(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), "§c" + nick + " §fудалён из whitelist");
                        return 1;
                    }))
                )
                .then(CommandManager.literal("list").executes(ctx -> {
                    feedback(ctx.getSource(), "§eWhitelist (" + (cfg.whitelistEnabled ? "ВКЛ" : "ВЫКЛ") + "): §f"
                        + (cfg.whitelist.isEmpty() ? "(пусто)" : String.join(", ", cfg.whitelist)));
                    return 1;
                }))
            )
            // ── v8: /bot profile <name> ──────────────────────────────
            .then(CommandManager.literal("profile")
                .then(CommandManager.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    if (!(ctx.getSource().getEntity() instanceof ServerPlayerEntity player)) return 0;
                    boolean ok = ModuleManager.INSTANCE.loadProfile(name);
                    if (ok) {
                        BotConfig.save();
                        feedback(ctx.getSource(), "§aПрофиль §e" + name + " §aзагружен!");
                    } else {
                        feedback(ctx.getSource(), "§cПрофиль §e" + name + " §cне найден. Доступные: "
                            + String.join(", ", ModuleManager.INSTANCE.listProfiles()));
                    }
                    return ok ? 1 : 0;
                }))
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§eПрофили: §f"
                        + String.join(", ", ModuleManager.INSTANCE.listProfiles())
                        + "  §7Текущий: §e" + ModuleManager.INSTANCE.getActiveProfile());
                    return 1;
                })
            )
            // ── v8: /bot module <name> [on|off|toggle] ────────────
            .then(CommandManager.literal("module")
                .executes(ctx -> {
                    StringBuilder sb = new StringBuilder("§e§lМодули PVPBot v8:\n");
                    for (String mod : ModuleManager.INSTANCE.getModuleNames()) {
                        boolean en = ModuleManager.INSTANCE.isEnabled(mod);
                        sb.append(en ? "§a✔ " : "§c✘ ").append("§f").append(mod).append("\n");
                    }
                    if (ctx.getSource().getEntity() instanceof ServerPlayerEntity p) {
                        p.sendMessage(net.minecraft.text.Text.literal(sb.toString()), false);
                    }
                    return 1;
                })
                .then(CommandManager.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.ModuleState s = ModuleManager.INSTANCE.get(name);
                    if (s == null) {
                        feedback(ctx.getSource(), "§cМодуль §e" + name + " §cне найден.");
                        return 0;
                    }
                    feedback(ctx.getSource(), "§7Модуль §e" + name
                        + "§7: " + (s.enabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §8priority=" + s.priority);
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, true);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§a" + name + " §fвключён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, false);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§c" + name + " §fвыключён");
                    return 1;
                }))
                .then(CommandManager.literal("toggle").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.toggle(name);
                    boolean en = ModuleManager.INSTANCE.isEnabled(name);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), "§e" + name + " §f→ " + (en ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                }))
                )
            )
            // ── v11: /bot autolog [on|off|hp <val>] ──────────────
            .then(CommandManager.literal("autolog")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_AUTO_LOG))
                .then(CommandManager.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_LOG, true);
                    feedback(ctx.getSource(), "§aAutoLog §fвключён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_LOG, false);
                    feedback(ctx.getSource(), "§cAutoLog §fвыключён");
                    return 1;
                }))
                .then(CommandManager.literal("hp")
                    .then(CommandManager.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 20f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_LOG);
                        if (s != null) s.set("hp_threshold", (double) val);
                        feedback(ctx.getSource(), "§eAutoLog HP порог: §f" + val);
                        return 1;
                    }))
                )
            )
            // ── v11: /bot autopearl [on|off|mode <type>] ─────────
            .then(CommandManager.literal("autopearl")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_AUTO_PEARL))
                .then(CommandManager.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_PEARL, true);
                    feedback(ctx.getSource(), "§aAutoPearl §fвключён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_AUTO_PEARL, false);
                    feedback(ctx.getSource(), "§cAutoPearl §fвыключён");
                    return 1;
                }))
                .then(CommandManager.literal("mode")
                    .then(CommandManager.literal("gap_close").executes(ctx -> {
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_PEARL);
                        if (s != null) s.set("mode", "gap_close");
                        feedback(ctx.getSource(), "§eAutoPearl режим: §fgap_close");
                        return 1;
                    }))
                    .then(CommandManager.literal("escape").executes(ctx -> {
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_AUTO_PEARL);
                        if (s != null) s.set("mode", "escape");
                        feedback(ctx.getSource(), "§eAutoPearl режим: §fescape");
                        return 1;
                    }))
                )
            )
            // ── v11: /bot tracers [on|off|range <val>] ───────────
            .then(CommandManager.literal("tracers")
                .executes(ctx -> moduleStatus(ctx.getSource(), ModuleManager.MOD_TRACERS))
                .then(CommandManager.literal("on").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_TRACERS, true);
                    feedback(ctx.getSource(), "§aTracers §fвключены");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    ModuleManager.INSTANCE.setEnabled(ModuleManager.MOD_TRACERS, false);
                    feedback(ctx.getSource(), "§cTracers §fвыключены");
                    return 1;
                }))
                .then(CommandManager.literal("range")
                    .then(CommandManager.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(10f, 128f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(ModuleManager.MOD_TRACERS);
                        if (s != null) s.set("range", (double) val);
                        feedback(ctx.getSource(), "§eTracers радиус: §f" + val);
                        return 1;
                    }))
                )
            )
            // ── v15: /bot owner add|remove|list ───────────────────
            .then(CommandManager.literal("owner")
                .then(CommandManager.literal("add")
                    .then(CommandManager.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        if (p == null) return 0;
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        boolean ok = MultiOwner.INSTANCE.addCoOwner(
                            p.getUuid(), nick, ctx.getSource().getServer());
                        feedback(ctx.getSource(), ok
                            ? "§a✔ §f" + nick + " §aтеперь совладелец ботов"
                            : "§c✘ Игрок §f" + nick + " §cне найден онлайн");
                        return ok ? 1 : 0;
                    }))
                )
                .then(CommandManager.literal("remove")
                    .then(CommandManager.argument("nick",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        ServerPlayerEntity p = ctx.getSource().getPlayer();
                        if (p == null) return 0;
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        boolean ok = MultiOwner.INSTANCE.removeCoOwner(p.getUuid(), nick);
                        feedback(ctx.getSource(), ok
                            ? "§c✘ §f" + nick + " §cудалён из совладельцев"
                            : "§7" + nick + " не найден в совладельцах");
                        return ok ? 1 : 0;
                    }))
                )
                .then(CommandManager.literal("list").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p == null) return 0;
                    var nicks = MultiOwner.INSTANCE.getCoOwnerNicks(p.getUuid());
                    feedback(ctx.getSource(), nicks.isEmpty()
                        ? "§7Совладельцев нет"
                        : "§6Совладельцы: §f" + String.join(", ", nicks));
                    return 1;
                }))
            )
            // ── v15: /bot webconfig [on|off|port <N>] ─────────────
            .then(CommandManager.literal("webconfig")
                .executes(ctx -> {
                    boolean run = WebConfig.INSTANCE.isRunning();
                    feedback(ctx.getSource(), "§6WebConfig: §f" + (run ? "§aОН" : "§cОФФ")
                        + (run ? " §7(http://localhost:" + WebConfig.INSTANCE.getPort() + ")" : ""));
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    int port = cfg.webConfigPort;
                    boolean ok = WebConfig.INSTANCE.start(port);
                    cfg.webConfigEnabled = ok;
                    feedback(ctx.getSource(), ok
                        ? "§aWebConfig запущен §7→ §fhttp://localhost:" + port
                        : "§cОшибка запуска WebConfig (порт занят?)");
                    return ok ? 1 : 0;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    WebConfig.INSTANCE.stop();
                    cfg.webConfigEnabled = false;
                    feedback(ctx.getSource(), "§cWebConfig остановлен");
                    return 1;
                }))
                .then(CommandManager.literal("port")
                    .then(CommandManager.argument("num", IntegerArgumentType.integer(1024, 65535))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int p = IntegerArgumentType.getInteger(ctx, "num");
                        cfg.webConfigPort = p;
                        feedback(ctx.getSource(), "§eWebConfig порт: §f" + p + " §7(перезапусти /bot webconfig on)");
                        return 1;
                    }))
                )
            )
            // ── v15: /bot bunker [on|off|hp <val>] ────────────────
            .then(CommandManager.literal("bunker")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6Bunker: §f" + (cfg.bunkerEnabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §7(HP≤" + cfg.bunkerHpThreshold + ")");
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    cfg.bunkerEnabled = true;
                    feedback(ctx.getSource(), "§a🧱 Bunker Mode включён (HP≤" + cfg.bunkerHpThreshold + ")");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    cfg.bunkerEnabled = false;
                    feedback(ctx.getSource(), "§c🧱 Bunker Mode выключен");
                    return 1;
                }))
                .then(CommandManager.literal("hp")
                    .then(CommandManager.argument("val",
                        com.mojang.brigadier.arguments.FloatArgumentType.floatArg(1f, 39f))
                    .executes(ctx -> {
                        float val = com.mojang.brigadier.arguments.FloatArgumentType.getFloat(ctx, "val");
                        cfg.bunkerHpThreshold = val;
                        feedback(ctx.getSource(), "§eBunker HP порог: §f" + val);
                        return 1;
                    }))
                )
            )

            // ── v16: /bot hunt [on|off|range <N>] ─────────────────
            .then(CommandManager.literal("hunt")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6Hunt: §f" + (cfg.huntEnabled ? "§aВКЛ" : "§cВЫКЛ")
                        + " §7(радиус " + (int) cfg.huntRange + "м)");
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    cfg.huntEnabled = true;
                    feedback(ctx.getSource(), "§a🎯 Hunt Mode включён (радиус " + (int) cfg.huntRange + "м)");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    cfg.huntEnabled = false;
                    feedback(ctx.getSource(), "§c🎯 Hunt Mode выключен");
                    return 1;
                }))
                .then(CommandManager.literal("range")
                    .then(CommandManager.argument("val",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(16, 512))
                    .executes(ctx -> {
                        int val = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "val");
                        cfg.huntRange = val;
                        feedback(ctx.getSource(), "§eHunt радиус: §f" + val + "м");
                        return 1;
                    }))
                )
            )

            // ── v16: /bot fake [on|off] ────────────────────────────
            .then(CommandManager.literal("fake")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6FakeAttack: §f" + (cfg.fakeAttackEnabled ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    cfg.fakeAttackEnabled = true;
                    feedback(ctx.getSource(), "§a🎭 Fake Attack включён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    cfg.fakeAttackEnabled = false;
                    feedback(ctx.getSource(), "§c🎭 Fake Attack выключен");
                    return 1;
                }))
            )

            // ── v16: /bot adaptive [on|off] ───────────────────────
            .then(CommandManager.literal("adaptive")
                .executes(ctx -> {
                    feedback(ctx.getSource(), "§6AdaptiveCooldown: §f"
                        + (cfg.adaptiveCooldownEnabled ? "§aВКЛ" : "§cВЫКЛ"));
                    return 1;
                })
                .then(CommandManager.literal("on").executes(ctx -> {
                    cfg.adaptiveCooldownEnabled = true;
                    feedback(ctx.getSource(), "§a⚡ Adaptive Cooldown включён");
                    return 1;
                }))
                .then(CommandManager.literal("off").executes(ctx -> {
                    cfg.adaptiveCooldownEnabled = false;
                    feedback(ctx.getSource(), "§c⚡ Adaptive Cooldown выключен");
                    return 1;
                }))
            )

            // ── v16: /bot replay ──────────────────────────────────
            .then(CommandManager.literal("replay")
                .executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    net.minecraft.server.network.ServerPlayerEntity p = ctx.getSource().getPlayer();
                    if (p == null) return 0;
                    java.util.List<BotEntity> bots = getBots(ctx.getSource());
                    if (bots.isEmpty()) { feedback(ctx.getSource(), "§cНет ботов"); return 0; }
                    // Показываем replay первого бота
                    bots.get(0).getReplay().printReplayToPlayer(p);
                    return 1;
                })
            )

            // ── v16: /bot duel [start|stop|score|round] ───────────
            .then(CommandManager.literal("duel")
                .executes(ctx -> {
                    feedback(ctx.getSource(), DuelTimer.INSTANCE.getScoreText());
                    return 1;
                })
                .then(CommandManager.literal("start")
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        net.minecraft.server.network.ServerPlayerEntity p = ctx.getSource().getPlayer();
                        String name = p != null ? p.getName().getString() : "Игрок";
                        UUID ownerUUID = p != null ? p.getUuid() : null;
                        DuelTimer.INSTANCE.start(5, 3, ownerUUID, name);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §75 мин, 3 раунда");
                        return 1;
                    })
                    .then(CommandManager.argument("minutes",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 60))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int mins = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "minutes");
                        net.minecraft.server.network.ServerPlayerEntity p = ctx.getSource().getPlayer();
                        String name = p != null ? p.getName().getString() : "Игрок";
                        UUID ownerUUID = p != null ? p.getUuid() : null;
                        DuelTimer.INSTANCE.start(mins, 3, ownerUUID, name);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §f" + mins + " мин, 3 раунда");
                        return 1;
                    }))
                )
                .then(CommandManager.literal("stop").executes(ctx -> {
                    if (!checkAccess(ctx.getSource())) return 0;
                    DuelTimer.INSTANCE.stop();
                    return 1;
                }))
                .then(CommandManager.literal("score").executes(ctx -> {
                    feedback(ctx.getSource(), DuelTimer.INSTANCE.getScoreText());
                    return 1;
                }))
                .then(CommandManager.literal("round")
                    .then(CommandManager.argument("rounds",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 20))
                    .executes(ctx -> {
                        if (!checkAccess(ctx.getSource())) return 0;
                        int rounds = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "rounds");
                        net.minecraft.server.network.ServerPlayerEntity p = ctx.getSource().getPlayer();
                        String name = p != null ? p.getName().getString() : "Игрок";
                        UUID ownerUUID = p != null ? p.getUuid() : null;
                        DuelTimer.INSTANCE.start(0, rounds, ownerUUID, name);
                        feedback(ctx.getSource(), "§6⚔ Дуэль начата! §f" + rounds + " раундов (без таймера)");
                        return 1;
                    }))
                )
            )
        );
    }

    /** Выводит статус модуля в чат. */
    private static int moduleStatus(ServerCommandSource src, String modName) {
        ModuleManager.ModuleState s = ModuleManager.INSTANCE.getModule(modName);
        if (s == null) { feedback(src, "§cМодуль не найден: " + modName); return 0; }
        feedback(src, "§e" + modName + " §7→ " + (s.enabled ? "§aВКЛ" : "§cВЫКЛ")
            + " §8params=" + s.params);
        return 1;
    }

    // ── /bot spawn [count] ────────────────────────────────────────
    private static int spawnBots(ServerCommandSource src, int count) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) {
            src.sendError(Text.literal("Только игрок может спавнить бота!"));
            return 0;
        }
        if (!checkWhitelist(player, src)) return 0;

        var world = player.getServerWorld();
        List<BotEntity> existing = getActiveBots(player);

        int canSpawn = Math.max(0, cfg.maxBots - existing.size());
        int toSpawn  = Math.min(count, canSpawn);

        if (toSpawn <= 0) {
            feedback(src, "§cДостигнут лимит ботов §e(" + cfg.maxBots + ")§f. §7/bot kill — удалить.");
            return 0;
        }

        for (int i = 0; i < toSpawn; i++) {
            BotEntity bot = BotEntityType.BOT_ENTITY.create(world);
            if (bot == null) continue;

            // Спавним в кольце вокруг игрока с шагом угла
            double angle = Math.toRadians(player.getYaw() + 90 + i * (360.0 / toSpawn));
            double radius = 2.0 + i * 0.5;
            Vec3d pos = player.getPos().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            bot.setPosition(pos);
            bot.setOwner(player);
            if (skinNick != null) bot.setSkinNick(skinNick); // v9
            giveDefaultEquipment(bot);
            world.spawnEntity(bot);
            playerBots.computeIfAbsent(player.getUuid(), k -> new ArrayList<>()).add(bot);
            // v15: запоминаем глобального владельца (первый спавн)
            if (cfg.globalOwnerUUID == null) cfg.globalOwnerUUID = player.getUuid();
        }

        feedback(src, "§aЗаспавнено ботов: §e" + toSpawn
            + (toSpawn < count ? " §7(лимит: " + cfg.maxBots + ")" : "")
            + "§f. §7/bot help — команды");
        BotConfig.save(); // сохраняем состояние (whitelist, maxBots)
        return toSpawn;
    }

    // ── /bot kill ─────────────────────────────────────────────────
    private static int killBots(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = playerBots.getOrDefault(player.getUuid(), List.of());
        int count = 0;
        for (BotEntity bot : new ArrayList<>(bots)) {
            if (!bot.isRemoved()) { bot.discard(); count++; }
        }
        playerBots.remove(player.getUuid());
        feedback(src, "§cУдалено ботов: §e" + count);
        return count;
    }

    // ── /bot mode ─────────────────────────────────────────────────
    private static int cycleMode(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов! §7/bot spawn"); return 0; }
        for (BotEntity bot : bots) bot.cycleMode();

        String modeColored = switch (bots.get(0).getBotMode()) {
            case GUARD      -> "§a⚔ GUARD §7(защищает владельца)";
            case AGGRESSIVE -> "§c🗡 AGGRESSIVE §7(атакует всех игроков)";
            case PASSIVE    -> "§7☮ PASSIVE §7(не атакует)";
        };
        feedback(src, "§eРежим: " + modeColored);
        return 1;
    }

    // ── /bot tp ───────────────────────────────────────────────────
    private static int tpBot(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (int i = 0; i < bots.size(); i++) {
            bots.get(i).teleport(player.getX() + i, player.getY(), player.getZ());
        }
        feedback(src, "§aБоты телепортированы к тебе");
        return 1;
    }

    // ── /bot equip ────────────────────────────────────────────────
    private static int equipBot(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (BotEntity bot : bots) giveDefaultEquipment(bot);
        feedback(src, "§aБотам выдано снаряжение!");
        return 1;
    }

    // ── /bot stats ────────────────────────────────────────────────
    private static int showStats(ServerCommandSource src) {
        if (src.getEntity() instanceof ServerPlayerEntity player) {
            double kd = KillDeathTracker.deaths == 0
                ? KillDeathTracker.kills
                : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
            player.sendMessage(Text.literal(
                "§e§l⚔ PVP Bot — Статистика\n" +
                "§aУбийств:  §f" + KillDeathTracker.kills + "\n" +
                "§cСмертей:  §f" + KillDeathTracker.deaths + "\n" +
                "§eАссистов: §f" + KillDeathTracker.assists + "\n" +
                "§6K/D: §f" + String.format("%.2f", kd) + "\n" +
                "§7/bot stats reset — сброс"
            ), false);
        }
        return 1;
    }

    // ── /bot help ─────────────────────────────────────────────────
    private static int help(ServerCommandSource src) {
        if (src.getEntity() instanceof ServerPlayerEntity player) {
            player.sendMessage(Text.literal(
                "§e§l⚔ PVP Bot v11 — Команды\n" +
                "§f/bot spawn [ник] [N] §7— Заспавнить N ботов со скином ника\n" +
                "§f/bot kill        §7— Удалить ботов\n" +
                "§f/bot mode        §7— Сменить режим (GUARD/AGRO/PASSIVE)\n" +
                "§f/bot tp          §7— Телепортировать ботов к себе\n" +
                "§f/bot equip       §7— Выдать бронь и меч\n" +
                "§f/bot equip smart §7— Умная экипировка из инвентаря бота\n" +
                "§f/bot formation <follow|line|flank|surround> §7— Построение\n" +
                "§f/bot regroup [teleport|pathfind|formation] §7— Сбор ботов\n" +
                "§f/bot stats       §7— K/D статистика\n" +
                "§f/bot whitelist   §7— on|off|add <ник>|remove <ник>|list\n" +
                "§f/bot difficulty  §7— easy|medium|hard|expert|status\n" +
                "§f/bot profile [name] §7— загрузить профиль (pvp/pve/crystal/passive)\n" +
                "§f/bot module <name> [on|off|toggle] §7— управление модулями\n" +
                "§e§lv11 новое:\n" +
                "§f/bot autolog [on|off|hp <val>]              §7— выход при низком HP\n" +
                "§f/bot autopearl [on|off|mode <gap_close|escape>] §7— авто-перл\n" +
                "§f/bot tracers [on|off|range <val>]           §7— трассеры к сущностям\n" +
                "§e§lv12 новое:\n" +
                "§f/bot kit               §7— список китов (smp/uhc/nethpot/axe/tpc/sword/crystal)\n" +
                "§f/bot kit <название>    §7— применить кит + снаряжение + профиль AI\n" +
                "§e§lv12 синхроатака:\n" +
                "§f/bot sync attack [ник] §7— запустить синхроатаку\n" +
                "§f/bot sync stop         §7— остановить синхроатаку\n" +
                "§f/bot sync mode <focus|surround> §7— режим атаки\n" +
                "§f/bot sync auto <on|off> §7— авто-синхро\n" +
                "§f/bot sync status       §7— текущий статус\n" +
                "§e§lv12 новое (AI):\n" +
                "§f/bot clone [on|off]    §7— бот копирует твои атаки\n" +
                "§f/bot target <nearest|lowhp|items|ник> §7— приоритет цели\n" +
                "§f/bot strafe <circle|random|zigzag|retreat> §7— стиль уклонения\n" +
                "§e§lv14 новое:\n" +
                "§f/bot kit <beehive|firework|crossbow> §7— новые режимы\n" +
                "§f/bot train [on|off]         §7— обучающий режим (крит/w-tap)\n" +
                "§f/bot kitstats               §7— win/loss таблица по китам\n" +
                "§f/bot kitstats heatmap       §7— карта смертей бота\n" +
                "§f/bot kitstats reset         §7— сброс статистики\n" +
                "§f/bot pattern [on|off]       §7— AI обучение паттернам движения"
            ), false);
        }
        return 1;
    }

    // ── Whitelist проверка ─────────────────────────────────────────
    private static boolean checkWhitelist(ServerPlayerEntity player, ServerCommandSource src) {
        if (!cfg.whitelistEnabled) return true;
        if (cfg.whitelist.contains(player.getName().getString())) return true;
        src.sendError(Text.literal("§c[PVPBot] §fВы не в whitelist!"));
        return false;
    }

    // ── Вспомогательные ───────────────────────────────────────────
    public static List<BotEntity> getBotsFor(net.minecraft.server.network.ServerPlayerEntity player) { return getActiveBots(player); }

    private static List<BotEntity> getActiveBots(ServerPlayerEntity player) {
        var list = playerBots.getOrDefault(player.getUuid(), List.of());
        var alive = new ArrayList<BotEntity>();
        for (BotEntity b : list) if (!b.isRemoved()) alive.add(b);
        playerBots.put(player.getUuid(), alive);
        return alive;
    }

    // ── v12: /bot clone ───────────────────────────────────────────

    private static int cloneToggle(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotClone.INSTANCE.toggle();
        feedback(src, "§aКлон-режим: " + (BotClone.INSTANCE.isActive() ? "§aВКЛ" : "§7ВЫКЛ"));
        return 1;
    }

    private static int cloneSet(ServerCommandSource src, boolean on) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotClone.INSTANCE.setActive(on);
        feedback(src, "§aКлон-режим: " + (on ? "§aВКЛ" : "§7ВЫКЛ")
            + " §7— бот " + (on ? "копирует твои атаки" : "действует самостоятельно"));
        return 1;
    }

    // ── v12: /bot target ──────────────────────────────────────────

    private static int setTargetPriority(ServerCommandSource src, TargetPriority.PriorityMode mode) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getTargetPriority().setMode(mode);
        String name = switch (mode) {
            case NEAREST   -> "§fБлижайший";
            case LOWEST_HP -> "§cМинимум HP";
            case MOST_ITEMS -> "§6Максимум лута";
            default        -> mode.name();
        };
        feedback(src, "§aПриоритет цели: " + name);
        return 1;
    }

    private static int setForcedTarget(ServerCommandSource src, String nick) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!(src.getWorld() instanceof net.minecraft.server.world.ServerWorld sw)) return 0;
        net.minecraft.entity.player.PlayerEntity target = sw.getPlayers(
            p -> p.getName().getString().equalsIgnoreCase(nick)).stream().findFirst().orElse(null);
        if (target == null) { feedback(src, "§cИгрок не найден: §f" + nick); return 0; }
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getTargetPriority().setForcedTarget(target.getUuid());
        feedback(src, "§aПринудительная цель: §f" + nick);
        return 1;
    }

    // ── v12: /bot strafe ──────────────────────────────────────────

    private static int setStrafeStyle(ServerCommandSource src, StrafeAI.StrafeStyle style) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        var bots = getActiveBots(player);
        for (BotEntity bot : bots) bot.getStrafeAI().setStyle(style);
        String name = switch (style) {
            case CIRCLE  -> "§bКруговой";
            case RANDOM  -> "§eСлучайный";
            case ZIGZAG  -> "§aЗигзаг";
            case RETREAT -> "§6Hit-and-Run";
        };
        feedback(src, "§aСтиль стрейфа: " + name);
        return 1;
    }

    // ── v12: /bot sync ────────────────────────────────────────────

    private static int syncAttack(ServerCommandSource src, String targetName) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }

        // Найти цель по нику если указан
        net.minecraft.entity.LivingEntity target = null;
        if (targetName != null && !targetName.isEmpty() && player.getServerWorld() != null) {
            net.minecraft.server.world.ServerWorld sw = player.getServerWorld();
            target = sw.getPlayers(p -> p.getName().getString().equalsIgnoreCase(targetName))
                       .stream().findFirst().orElse(null);
            if (target == null) {
                feedback(src, "§cИгрок '§f" + targetName + "§c' не найден!");
                return 0;
            }
        }

        BotSyncAttack.INSTANCE.start(bots, target, player);
        return 1;
    }

    private static int syncStop(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotSyncAttack.INSTANCE.stop();
        feedback(src, "§7⚡ Синхроатака остановлена.");
        return 1;
    }

    private static int syncMode(ServerCommandSource src, BotSyncAttack.SyncMode mode) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotSyncAttack.INSTANCE.setMode(mode);
        String name = mode == BotSyncAttack.SyncMode.SURROUND ? "§6Окружение" : "§cФокус";
        feedback(src, "§aРежим синхроатаки: " + name);
        return 1;
    }

    private static int syncAuto(ServerCommandSource src, boolean on) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotSyncAttack.INSTANCE.setAutoSync(on);
        feedback(src, "§aАвто-синхро: " + (on ? "§aВКЛ" : "§7ВЫКЛ"));
        return 1;
    }

    private static int syncStatus(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        BotSyncAttack sync = BotSyncAttack.INSTANCE;
        String target = sync.getTarget() != null
            ? "§f" + sync.getTarget().getName().getString()
            : "§7нет";
        String mode = sync.getMode() == BotSyncAttack.SyncMode.SURROUND ? "§6Окружение" : "§cФокус";
        player.sendMessage(net.minecraft.text.Text.literal(
            "§e§l⚡ Синхроатака — Статус\n" +
            "§7Активна:   " + (sync.isActive() ? "§aДА" : "§7НЕТ") + "\n" +
            "§7Режим:     " + mode + "\n" +
            "§7Цель:      " + target + "\n" +
            "§7Авто-синхро: " + (sync.isAutoSync() ? "§aВКЛ" : "§7ВЫКЛ")
        ), false);
        return 1;
    }

    // ── v12: /bot kit ─────────────────────────────────────────────

    /** Показать список доступных китов. */
    private static int listKits(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        StringBuilder sb = new StringBuilder("§e§l⚔ PVP Bot — Киты\n");
        for (BotKit kit : BotKit.values()) {
            sb.append("§f").append(kit.id).append(" §7— ").append(kit.displayName).append("\n");
        }
        sb.append("§7Использование: §f/bot kit <название>");
        player.sendMessage(net.minecraft.text.Text.literal(sb.toString()), false);
        return 1;
    }

    /** Применить кит: сменить снаряжение ботов + загрузить профиль модулей. */
    private static int applyKit(ServerCommandSource src, String kitId) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        BotKit kit = BotKit.byId(kitId);
        if (kit == null) {
            feedback(src, "§cНеизвестный кит '§f" + kitId + "§c'! Доступные: §f" + BotKit.listIds());
            return 0;
        }

        // Применить снаряжение всем ботам
        var bots = getActiveBots(player);
        if (bots.isEmpty()) {
            feedback(src, "§cНет активных ботов!");
            return 0;
        }
        for (BotEntity bot : bots) {
            kit.equipment.applyTo(bot);
        }

        // Загрузить профиль модулей (настройки AI)
        boolean profileLoaded = ModuleManager.INSTANCE.loadProfile(kit.profileName);
        BotConfig.save();

        feedback(src, "§a✔ Кит §f" + kit.id.toUpperCase() + " §a— §7" + kit.displayName
            + (profileLoaded ? " §8[профиль загружен]" : ""));
        return 1;
    }

    private static void giveDefaultEquipment(BotEntity bot) {
        bot.equipStack(net.minecraft.entity.EquipmentSlot.MAINHAND,
            new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_SWORD));
        bot.equipStack(net.minecraft.entity.EquipmentSlot.HEAD,
            new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_HELMET));
        bot.equipStack(net.minecraft.entity.EquipmentSlot.CHEST,
            new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_CHESTPLATE));
        bot.equipStack(net.minecraft.entity.EquipmentSlot.LEGS,
            new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_LEGGINGS));
        bot.equipStack(net.minecraft.entity.EquipmentSlot.FEET,
            new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_BOOTS));
    }

    // ── /bot equip smart (v10) ────────────────────────────────────
    private static int equipBotSmart(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        if (!(src.getWorld() instanceof net.minecraft.server.world.ServerWorld sw)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }
        for (BotEntity bot : bots) SmartEquip.equip(bot, sw);
        feedback(src, "§aУмная экипировка применена!");
        return 1;
    }

    // ── /bot formation (v10) ──────────────────────────────────────
    private static int setFormation(ServerCommandSource src, String type) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        BotFormations.Formation f = BotFormations.fromString(type);
        BotFormations.INSTANCE.setCurrent(f);
        feedback(src, "§aПостроение: §f" + f.name());
        return 1;
    }

    // ── /bot regroup (v10) ────────────────────────────────────────
    private static int regroupBots(ServerCommandSource src, String modeStr) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;
        if (!(src.getWorld() instanceof net.minecraft.server.world.ServerWorld sw)) return 0;

        var bots = getActiveBots(player);
        if (bots.isEmpty()) { feedback(src, "§cНет активных ботов!"); return 0; }

        BotRegroup.RegroupMode mode = BotRegroup.fromString(modeStr);
        int count = BotRegroup.INSTANCE.regroup(bots, player, mode, sw);
        feedback(src, "§aСбор! §f" + count + " бот(ов) → " + mode.name());
        return count;
    }

    private static void feedback(ServerCommandSource src, String msg) {
        if (src.getEntity() instanceof ServerPlayerEntity p) {
            p.sendMessage(Text.literal("§e[PVPBot] §f" + msg), false);
        }
    }

    // ── /bot difficulty ───────────────────────────────────────────
    private static int setDifficulty(ServerCommandSource src, PVPBotConfig.Difficulty diff) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        if (!checkWhitelist(player, src)) return 0;

        cfg.difficulty = diff;
        cfg.applyDifficulty();
        BotConfig.save();

        String label = switch (diff) {
            case EASY   -> "§7[EASY] §f— базовая атака, без перлов/кристаллов";
            case MEDIUM -> "§e[MEDIUM] §f— лук на дистанции, стрейф";
            case HARD   -> "§c[HARD] §f— перлы, улучшенный стрейф, крит-прыжки";
            case EXPERT -> "§4§l[EXPERT] §f— кристаллы, перлы, предсказание, комбо";
        };
        feedback(src, "§eСложность бота: " + label);

        // Применяем к уже живым ботам
        var bots = getActiveBots(player);
        if (!bots.isEmpty()) {
            feedback(src, "§7Применено к §e" + bots.size() + " §7активным ботам.");
        }
        return 1;
    }

    private static int showDifficulty(ServerCommandSource src) {
        if (src.getEntity() instanceof ServerPlayerEntity player) {
            PVPBotConfig.Difficulty d = cfg.difficulty;
            String label = switch (d) {
                case EASY   -> "§7EASY";
                case MEDIUM -> "§eMEDIUM";
                case HARD   -> "§cHARD";
                case EXPERT -> "§4§lEXPERT";
            };
            player.sendMessage(Text.literal(
                "§e§l⚔ PVP Bot — Сложность бота\n" +
                "§fТекущий уровень: " + label + "\n\n" +
                "§7EASY   §f— атака, без перлов/кристаллов\n" +
                "§7MEDIUM §f— + лук на дистанции\n" +
                "§7HARD   §f— + перлы (рывок/отрыв)\n" +
                "§7EXPERT §f— + кристаллы, предсказание, комбо\n\n" +
                "§7Параметры: pearls=" + cfg.diffUsePearls +
                " crystals=" + cfg.diffUseCrystals +
                " bowRange=" + cfg.diffBowSwitchRange
            ), false);
        }
        return 1;
    }


    // ── v14: /bot train status ───────────────────────────────────
    private static int trainStatus(ServerCommandSource src) {
        boolean on = TrainingMode.INSTANCE.isActive();
        feedback(src, "§e🎓 Обучающий режим: " + (on ? "§aВКЛ" : "§7ВЫКЛ")
            + "\n§7/bot train on|off — управление");
        return 1;
    }

    // ── v14: /bot kitstats ────────────────────────────────────────
    private static int showKitStats(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        player.sendMessage(net.minecraft.text.Text.literal(KitStatsTracker.INSTANCE.formatTable()), false);
        return 1;
    }

    private static int showHeatmap(ServerCommandSource src) {
        if (!(src.getEntity() instanceof ServerPlayerEntity player)) return 0;
        player.sendMessage(net.minecraft.text.Text.literal(KitStatsTracker.INSTANCE.formatHeatmap()), false);
        return 1;
    }


}