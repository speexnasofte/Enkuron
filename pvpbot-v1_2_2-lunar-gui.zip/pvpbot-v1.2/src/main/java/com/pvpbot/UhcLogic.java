package com.pvpbot;

import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * UhcLogic — логика UHC (Ultra Hardcore) режима.
 *
 * UHC особенности:
 *   - Нет естественного регенерации HP → бот берёт золотые яблоки
 *   - Паутина (cobweb) — ключевое оружие: ловушка под ноги цели
 *   - Если цель попала в паутину — бот выливает воду под неё (смывает)
 *     чтобы освободить себя при нужде, или оставляет врага в ней
 *   - Лук — основное оружие на дальней дистанции
 *   - Лава под цель при низком HP цели (добивание)
 *   - Золотые яблоки при HP < 8
 *
 * Состояния:
 *   RANGING   → стрельба из лука + отступление
 *   TRAPPING  → бросаем паутину под цель
 *   MELEING   → ближний бой пока цель в паутине
 *   FINISHING → лава под цель (HP < 4)
 *   GAPPING   → едим золотое яблоко
 */
public class UhcLogic {

    // ── Дистанции ─────────────────────────────────────────────────
    private static final double BOW_RANGE      = 15.0;
    private static final double TRAP_RANGE     = 4.0;   // дистанция для броска паутины
    private static final double MELEE_RANGE    = 2.5;

    // ── Кулдауны (тики) ──────────────────────────────────────────
    private static final int BOW_COOLDOWN      = 20;
    private static final int TRAP_COOLDOWN     = 80;   // паутина — долгий кулдаун
    private static final int LAVA_COOLDOWN     = 100;
    private static final int GAP_COOLDOWN      = 200;  // 2× золотое яблоко
    private static final int WATER_DELAY       = 40;   // тиков через сколько смываем паутину

    private enum UhcState { RANGING, TRAPPING, MELEING, FINISHING, GAPPING }
    private UhcState state = UhcState.RANGING;

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int bowCooldown   = 0;
    private int trapCooldown  = 0;
    private int lavaCooldown  = 0;
    private int gapCooldown   = 0;
    private int waterTimer    = 0;   // обратный отсчёт до смыва паутины
    private boolean webPlaced = false; // паутина сейчас активна под целью
    private BlockPos webPos   = null;  // позиция паутины

    public UhcLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.getWorld().isClient) return;
        if (!(bot.getWorld() instanceof ServerWorld sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        // Кулдауны
        if (bowCooldown  > 0) bowCooldown--;
        if (trapCooldown > 0) trapCooldown--;
        if (lavaCooldown > 0) lavaCooldown--;
        if (gapCooldown  > 0) gapCooldown--;
        if (waterTimer   > 0) waterTimer--;

        double dist  = bot.distanceTo(target);
        float  myHp  = bot.getHealth();
        float  tgHp  = target.getHealth();

        // ── Приоритет 1: Золотое яблоко при низком HP ────────────
        if (myHp < 8.0f && gapCooldown <= 0) {
            state = UhcState.GAPPING;
        }

        // ── Приоритет 2: Добивание лавой ─────────────────────────
        if (tgHp < 4.0f && lavaCooldown <= 0 && dist < TRAP_RANGE) {
            state = UhcState.FINISHING;
        }

        // ── Приоритет 3: Паутина если рядом и кулдаун прошёл ─────
        if (dist < TRAP_RANGE && trapCooldown <= 0 && !webPlaced
                && state != UhcState.GAPPING && state != UhcState.FINISHING) {
            state = UhcState.TRAPPING;
        }

        // ── Приоритет 4: Ближний бой пока цель в паутине ─────────
        if (webPlaced && isTargetInWeb(target)) {
            state = UhcState.MELEING;
        }

        // ── Выбор оружия ─────────────────────────────────────────
        switch (state) {
            case RANGING   -> doRanging(sw, target, dist);
            case TRAPPING  -> doTrapping(sw, target);
            case MELEING   -> doMeleing(sw, target);
            case FINISHING -> doFinishing(sw, target);
            case GAPPING   -> doGapping();
        }

        // ── Смыв паутины водой (через WATER_DELAY тиков) ─────────
        handleWebWaterFlush(sw, target);
    }

    // ── RANGING: стрельба из лука + отступление ──────────────────
    private void doRanging(ServerWorld sw, LivingEntity target, double dist) {
        equipBow();

        // Отступаем если слишком близко
        if (dist < 6.0) {
            Vec3d away = bot.getPos().subtract(target.getPos()).normalize();
            bot.setVelocity(bot.getVelocity().add(away.multiply(0.25)));
            bot.velocityModified = true;
        }

        if (bowCooldown <= 0) {
            // Предсказываем позицию
            Vec3d aim = MotionPredictor.predict(target, (int)(dist / 3));
            float dmg = (float) Math.max(3.0, Math.min(9.0, 10.5 - dist * 0.35));

            sw.getEntitiesByClass(LivingEntity.class,
                new net.minecraft.util.math.Box(aim, aim).expand(1.3),
                e -> e != bot && e.isAlive()
            ).stream().findFirst().ifPresent(e ->
                e.damage(sw, sw.getDamageSources().arrow(null, bot), dmg)
            );

            sw.spawnParticles(ParticleTypes.CRIT, aim.x, aim.y + 1, aim.z,
                3, 0.2, 0.2, 0.2, 0.1);
            bowCooldown = BOW_COOLDOWN;
        }

        // Если цель подошла — переходим к ловушке
        if (dist < TRAP_RANGE && trapCooldown <= 0) {
            state = UhcState.TRAPPING;
        }
    }

    // ── TRAPPING: ставим паутину под цель ────────────────────────
    private void doTrapping(ServerWorld sw, LivingEntity target) {
        BlockPos targetFeet = BlockPos.ofFloored(target.getPos());

        // Ставим паутину под ноги цели
        if (sw.getBlockState(targetFeet).isAir()) {
            sw.setBlockState(targetFeet, Blocks.COBWEB.getDefaultState());
            webPlaced = true;
            webPos    = targetFeet;
            waterTimer = WATER_DELAY; // через N тиков смоем

            bot.playSound(SoundEvents.BLOCK_WOOL_PLACE, 1.0f, 0.8f);
            sw.spawnParticles(ParticleTypes.EFFECT,
                target.getX(), target.getY(), target.getZ(),
                8, 0.3, 0.3, 0.3, 0.05);
        }

        trapCooldown = TRAP_COOLDOWN;
        state        = UhcState.MELEING;
    }

    // ── MELEING: рубим пока враг застрял ─────────────────────────
    private void doMeleing(ServerWorld sw, LivingEntity target) {
        equipSword();

        // Подходим вплотную
        if (bot.distanceTo(target) > MELEE_RANGE) {
            Vec3d dir = target.getPos().subtract(bot.getPos()).normalize();
            bot.setVelocity(bot.getVelocity().add(dir.multiply(0.2)));
            bot.velocityModified = true;
        }

        // Атакуем
        if (bot.distanceTo(target) <= MELEE_RANGE + 0.5) {
            bot.tryAttack(sw, target);
        }

        // Если цель вышла из паутины — меняем состояние
        if (!isTargetInWeb(target)) {
            webPlaced = false;
            state     = (bot.distanceTo(target) > TRAP_RANGE)
                ? UhcState.RANGING : UhcState.TRAPPING;
        }
    }

    // ── FINISHING: льём лаву под умирающую цель ──────────────────
    private void doFinishing(ServerWorld sw, LivingEntity target) {
        BlockPos lavaPos = BlockPos.ofFloored(target.getPos());
        if (sw.getBlockState(lavaPos).isAir()) {
            sw.setBlockState(lavaPos, Blocks.LAVA.getDefaultState());
            lavaCooldown = LAVA_COOLDOWN;
        }
        // Отступаем от лавы сами
        Vec3d away = bot.getPos().subtract(target.getPos()).normalize().multiply(0.2);
        bot.setVelocity(bot.getVelocity().add(away));
        bot.velocityModified = true;

        state = UhcState.RANGING;
    }

    // ── GAPPING: едим золотое яблоко ─────────────────────────────
    private void doGapping() {
        // Даём боту эффект регена (симуляция поедания golden apple)
        bot.addStatusEffect(new StatusEffectInstance(
            StatusEffects.REGENERATION, 100, 1)); // Regen II на 5 сек
        bot.addStatusEffect(new StatusEffectInstance(
            StatusEffects.ABSORPTION, 400, 0));   // Absorption I на 20 сек

        gapCooldown = GAP_COOLDOWN;
        state       = UhcState.RANGING;
    }

    // ── Смыв паутины водой ────────────────────────────────────────
    private void handleWebWaterFlush(ServerWorld sw, LivingEntity target) {
        if (!webPlaced || webPos == null || waterTimer > 0) return;

        // Время вышло — смываем паутину водой (убираем блок)
        if (sw.getBlockState(webPos).isOf(Blocks.COBWEB)) {
            sw.setBlockState(webPos, Blocks.AIR.getDefaultState());
            sw.spawnParticles(ParticleTypes.SPLASH,
                webPos.getX() + 0.5, webPos.getY() + 0.5, webPos.getZ() + 0.5,
                12, 0.3, 0.2, 0.3, 0.1);
        }
        webPlaced = false;
        webPos    = null;
    }

    // ── Проверка — цель в паутине ─────────────────────────────────
    private boolean isTargetInWeb(LivingEntity target) {
        if (webPos == null) return false;
        BlockPos tPos = BlockPos.ofFloored(target.getPos());
        return tPos.equals(webPos) &&
               bot.getWorld().getBlockState(webPos).isOf(Blocks.COBWEB);
    }

    private void equipBow() {
        ItemStack cur = bot.getEquippedStack(EquipmentSlot.MAINHAND);
        if (!cur.isOf(Items.BOW))
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }

    private void equipSword() {
        ItemStack cur = bot.getEquippedStack(EquipmentSlot.MAINHAND);
        if (!cur.isOf(Items.DIAMOND_SWORD))
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }

    private void reset() {
        state     = UhcState.RANGING;
        webPlaced = false;
        webPos    = null;
    }
}
