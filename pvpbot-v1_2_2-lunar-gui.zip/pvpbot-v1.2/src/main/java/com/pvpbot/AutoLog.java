package com.pvpbot;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * AutoLog v11 — автоматический выход с сервера при HP ниже порога.
 *
 * Принцип: каждый клиентский тик проверяем HP игрока.
 * Если HP <= autoLogHpThreshold и модуль включён — немедленный выход.
 *
 * Параметры (ModuleManager MOD_AUTO_LOG):
 *   hp_threshold  — HP для срабатывания (по умолчанию: 6.0)
 *   cooldown_ticks — минимальный интервал между проверками (по умолчанию: 20)
 *
 * Интеграция:
 *   AutoLog.INSTANCE.register() вызывается в PVPBotMod.onInitializeClient().
 */
public class AutoLog {

    public static final AutoLog INSTANCE = new AutoLog();

    private static final String MOD = ModuleManager.MOD_AUTO_LOG;

    private int cooldownTimer = 0;

    private AutoLog() {}

    public void register() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(Minecraft client) {
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) return;
        if (client.player == null || client.level == null) return;
        if (client.getNetworkHandler() == null) return;

        // Cooldown — не проверяем каждый тик
        cooldownTimer--;
        if (cooldownTimer > 0) return;

        ModuleManager.ModuleState state = ModuleManager.INSTANCE.getModule(MOD);
        double threshold    = (state != null) ? state.getDouble("hp_threshold", 6.0) : 6.0;
        int    cooldownTick = (state != null) ? state.getInt("cooldown_ticks", 20) : 20;
        cooldownTimer = cooldownTick;

        LocalPlayer player = client.player;
        float hp = player.getHealth();

        if (hp <= (float) threshold) {
            // Отключаемся от сервера
            client.disconnect();
        }
    }
}
