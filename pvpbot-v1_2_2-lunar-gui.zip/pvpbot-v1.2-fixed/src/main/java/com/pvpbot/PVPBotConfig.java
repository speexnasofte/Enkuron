package com.pvpbot;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * PVPBotConfig — v14: 1.21.4 + новые режимы и настройки.
 */
public class PVPBotConfig {

    public boolean enabled = false;

    public enum Mode { SWORD, CRYSTAL, SMP, UHC, NETHPOT, AXE, TPC, MACE, BEEHIVE, FIREWORK, CROSSBOW, MACE_ELYTRA, TRIDENT, TOTEM, SNOWBALL }
    public Mode mode = Mode.SWORD;

    public enum Difficulty { EASY, MEDIUM, HARD, EXPERT }
    public Difficulty difficulty = Difficulty.MEDIUM;

    // Атака
    public boolean autoAttack     = true;
    public double  attackRange    = 3.5;
    public int     attackCooldown = 10;

    // Уклонение
    public boolean autoDodge  = true;
    public double  dodgeRange = 2.5;

    // Лечение
    public boolean autoHeal      = true;
    public float   healThreshold = 8.0f;

    // AutoEat
    public boolean autoEat      = true;
    public int     eatThreshold = 16;

    // AutoGap
    public boolean autoGapEnabled     = true;
    public float   autoGapHpThreshold = 10.0f;

    // W-Tap / S-Tap
    public boolean wTapEnabled      = true;
    public int     wTapReleaseTicks = 2;
    public boolean sTapEnabled      = false;

    // AutoSprint
    public boolean autoSprint = true;

    // Авто-броня / тотем / респавн
    public boolean autoArmor   = true;
    public boolean autoTotem   = true;
    public boolean autoRespawn = true;

    // Кристаллы
    public boolean autoCrystal      = true;
    public double  crystalPlaceRange = 5.0;
    public int     crystalCooldown  = 4;

    // HUD
    public boolean showHud = true;
    public boolean showDps = true;

    // Whitelist
    public boolean      whitelistEnabled = false;
    public List<String> whitelist        = new ArrayList<>();

    // Несколько ботов
    public int maxBots = 5;

    // Лечение NPC-бота
    public float  botHealThreshold = 20.0f;
    public String botHealItem      = "minecraft:golden_apple";

    // GUI
    public enum GuiTab { SETTINGS, INVENTORY, MODULES }
    public GuiTab activeTab = GuiTab.SETTINGS;

    // Визуал
    public boolean espEnabled   = true;
    public double  espRange     = 48.0;
    public float   espLineWidth = 1.5f;

    public boolean radarEnabled = true;
    public int     radarRadius  = 50;
    public double  radarRange   = 64.0;

    // Статистика
    public boolean statsEnabled = true;

    // AutoBow
    public boolean autoBowEnabled = false;
    public double  bowRange       = 24.0;
    public int     bowCooldown    = 25;

    // Кайтинг
    public boolean kiteEnabled = false;
    public double  kiteMinDist = 6.0;
    public double  kiteMaxDist = 18.0;

    // Pathfinding
    public boolean advPathfind = true;

    // BotDifficultyAI
    public boolean diffUsePearls              = true;
    public double  diffPearlThrowDist         = 12.0;
    public int     diffPearlCooldown          = 160;
    public float   diffPearlEscapeHpThreshold = 8.0f;
    public double  diffPearlEscapeDist        = 16.0;
    public double  diffBowSwitchRange         = 10.0;
    public int     diffBowCooldown            = 30;
    public boolean diffUseCrystals            = true;
    public double  diffCrystalPlaceRange      = 6.0;
    public int     diffCrystalCooldown        = 40;
    public float   diffCrystalDamage          = 14.0f;
    public int     diffComboLength            = 3;
    public int     diffComboPauseTicks        = 12;
    public int     diffPredictTicks           = 4;

    // v11
    public boolean autoLogEnabled     = false;
    public float   autoLogHpThreshold = 6.0f;
    public boolean autoPearlEnabled   = false;
    public boolean tracersEnabled     = false;

    // v14 — PatternAI
    public boolean patternAIEnabled     = true;
    public boolean antiPatternEnabled   = true;

    // v14 — TrainingMode
    public boolean trainingMode = false;

    // v14 — Авто-кит по броне врага
    public boolean autoKitSelect = false;

    // v14 — KitStats
    public boolean kitStatsEnabled = true;

    // v14 — Уведомления в чат
    public boolean notificationsEnabled = true;

    public void applyDifficulty() {
        switch (difficulty) {
            case EASY -> {
                attackCooldown     = 16;  attackRange = 3.0;
                dodgeRange         = 1.5; crystalCooldown = 8;
                diffUsePearls      = false;
                diffUseCrystals    = false;
                diffBowSwitchRange = 999;
            }
            case MEDIUM -> {
                attackCooldown     = 10;  attackRange = 3.5;
                dodgeRange         = 2.5; crystalCooldown = 4;
                diffUsePearls      = false;
                diffUseCrystals    = false;
                diffBowSwitchRange = 10.0;
                diffBowCooldown    = 30;
            }
            case HARD -> {
                attackCooldown              = 4;   attackRange = 4.5;
                dodgeRange                  = 3.5; crystalCooldown = 2;
                diffUsePearls               = true;
                diffUseCrystals             = false;
                diffPearlThrowDist          = 12.0;
                diffPearlCooldown           = 160;
                diffBowSwitchRange          = 8.0;
                diffBowCooldown             = 20;
                diffPearlEscapeHpThreshold  = 10.0f;
            }
            case EXPERT -> {
                attackCooldown              = 2;   attackRange = 5.0;
                dodgeRange                  = 4.0; crystalCooldown = 1;
                diffUsePearls               = true;
                diffUseCrystals             = true;
                diffPearlThrowDist          = 10.0;
                diffPearlCooldown           = 100;
                diffPearlEscapeHpThreshold  = 14.0f;
                diffBowSwitchRange          = 6.0;
                diffBowCooldown             = 15;
                diffCrystalCooldown         = 30;
                diffCrystalDamage           = 16.0f;
                diffComboLength             = 4;
                diffComboPauseTicks         = 8;
                diffPredictTicks            = 5;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // v15 — Multi-Owner
    // ─────────────────────────────────────────────────────────────
    /** UUID текущего «главного» владельца (заполняется при первом /bot spawn) */
    public UUID   globalOwnerUUID    = null;
    /** Ник из WebConfig для отложенного добавления совладельца */
    public String pendingCoOwnerAdd  = null;

    // ─────────────────────────────────────────────────────────────
    // v15 — WebConfig
    // ─────────────────────────────────────────────────────────────
    public boolean webConfigEnabled = false;
    public int     webConfigPort    = 7420;

    // ─────────────────────────────────────────────────────────────
    // v15 — BotBunker
    // ─────────────────────────────────────────────────────────────
    public boolean bunkerEnabled      = false;
    public float   bunkerHpThreshold  = 8.0f;

    // ─────────────────────────────────────────────────────────────
    // v16 — FakeAttack
    // ─────────────────────────────────────────────────────────────
    public boolean fakeAttackEnabled  = false;

    // ─────────────────────────────────────────────────────────────
    // v16 — BotHunt
    // ─────────────────────────────────────────────────────────────
    public boolean huntEnabled  = false;
    public double  huntRange    = 128.0;

    // ─────────────────────────────────────────────────────────────
    // v16 — AdaptiveCooldown
    // ─────────────────────────────────────────────────────────────
    public boolean adaptiveCooldownEnabled = true;

    // ─────────────────────────────────────────────────────────────
    // AutoInventory — автодополнение инвентаря
    // ─────────────────────────────────────────────────────────────
    public boolean autoRefill      = false;
    public boolean refillCrystals  = true;
    public boolean refillTotems    = true;
    public boolean refillFood      = true;

    public static final PVPBotConfig INSTANCE = new PVPBotConfig();
}
