package com.pvpbot;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * NPC-бот: PathfinderMob с AI-целями.
 * v7: интеграция BotDifficultyAI — EASY/MEDIUM/HARD/EXPERT поведение.
 */
public class BotEntity extends PathfinderMob {

    private UUID ownerUUID = null;

    // v9: ник игрока чей скин носит бот (null = дефолт)
    private String skinNick = null;

    public enum BotMode { GUARD, AGGRESSIVE, PASSIVE }
    private BotMode mode = BotMode.GUARD;

    private int  nameUpdateTimer = 0;
    private int  strafeDirTimer  = 0;
    private boolean strafeLeft   = true;

    // ── v7: AI сложности ──────────────────────────────────────────
    private final BotDifficultyAI difficultyAI = new BotDifficultyAI(this);

    // ── v12: новые системы ────────────────────────────────────────
    private final StrafeAI      strafeAI      = new StrafeAI(this);
    private final PatternAI     patternAI     = new PatternAI(this);   // v14
    private final TargetPriority targetPriority = new TargetPriority(this);
    private final AutoRetreat   autoRetreat   = new AutoRetreat(this);

    // ── v14: ComboBreaker + BotNotifier ──────────────────────────
    private final ComboBreaker  comboBreaker  = new ComboBreaker(this);
    private final BotNotifier   notifier      = BotNotifier.create(this);

    // ── v15: BotBunker ────────────────────────────────────────────
    private final BotBunker     bunker        = new BotBunker(this);

    // ── v16: AdaptiveCooldown + FakeAttack + BotHunt + BotReplay ─
    private final AdaptiveCooldown adaptiveCooldown = new AdaptiveCooldown(this);
    // ── v1.2: PVPBotLogic переписан для NPC ──────────────────────
    private final PVPBotLogic      pvpLogic         = new PVPBotLogic(this);
    private final FakeAttack       fakeAttack       = new FakeAttack(this);
    private final BotHunt          botHunt          = new BotHunt(this);
    private final BotReplay        replay           = new BotReplay(this);

    public StrafeAI      getStrafeAI()      { return strafeAI; }
    public PatternAI     getPatternAI()     { return patternAI; }   // v14
    public TargetPriority getTargetPriority() { return targetPriority; }
    public AutoRetreat   getAutoRetreat()   { return autoRetreat; }
    public ComboBreaker  getComboBreaker()  { return comboBreaker; }  // v14
    public BotNotifier   getNotifier()      { return notifier; }      // v14
    public BotBunker     getBunker()        { return bunker; }        // v15
    public AdaptiveCooldown getAdaptiveCooldown() { return adaptiveCooldown; } // v16
    public PVPBotLogic     getPvpLogic()        { return pvpLogic; }         // v1.2
    public FakeAttack    getFakeAttack()    { return fakeAttack; }    // v16
    public BotHunt       getBotHunt()       { return botHunt; }       // v16
    public BotReplay     getReplay()        { return replay; }        // v16

    public BotEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
        this.setCanPickUpLoot(false);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH,          40.0)
            .add(Attributes.MOVEMENT_SPEED,       0.32)
            .add(Attributes.ATTACK_DAMAGE,        7.0)
            .add(Attributes.FOLLOW_RANGE,        24.0)
            .add(Attributes.ARMOR,                8.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 0.3);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new BotHealGoal(this));
        goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.FloatGoal(this));
        goalSelector.addGoal(2, new BotCritMeleeGoal(this, 1.2, true));
        if (PVPBotConfig.INSTANCE.advPathfind) {
            goalSelector.addGoal(3, new BotPathfindGoal(this, 1.1, 64.0f, 3.0f));
        } else {
            goalSelector.addGoal(3, new BotFollowOwnerGoal(this, 1.1, 10.0f, 3.0f));
        }
        goalSelector.addGoal(4, new net.minecraft.world.entity.ai.goal.RandomStrollGoal(this, 0.8));
        goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(6, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new BotRevengeGoal(this));
        targetSelector.addGoal(2, new BotAttackHostilesGoal(this));
        targetSelector.addGoal(3, new BotAttackPlayersGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {

            // ── Обновление имени ──────────────────────────────────
            nameUpdateTimer--;
            if (nameUpdateTimer <= 0) {
                nameUpdateTimer = 20;
                updateNameTag();
            }

            // ── v14: Тик уведомлений ──────────────────────────────
            notifier.tick();

            // ── v16: AdaptiveCooldown + Replay ────────────────────
            if (PVPBotConfig.INSTANCE.adaptiveCooldownEnabled) adaptiveCooldown.tick();
            replay.tick();

            // ── v16: BotHunt — охота на игроков ───────────────────
            if (PVPBotConfig.INSTANCE.huntEnabled && getTarget() == null) {
                botHunt.tick();
            }

            // ── v15: Pending co-owner add (из WebConfig) ──────────
            if (PVPBotConfig.INSTANCE.pendingCoOwnerAdd != null
                    && PVPBotConfig.INSTANCE.globalOwnerUUID != null
                    && level() instanceof net.minecraft.server.level.ServerLevel sw15) {
                net.minecraft.server.MinecraftServer ms = sw15.getServer();
                boolean added = MultiOwner.INSTANCE.addCoOwner(
                    PVPBotConfig.INSTANCE.globalOwnerUUID,
                    PVPBotConfig.INSTANCE.pendingCoOwnerAdd, ms);
                notifier.send(added
                    ? "§a✔ Совладелец добавлен: §f" + PVPBotConfig.INSTANCE.pendingCoOwnerAdd
                    : "§c✘ Игрок не найден: §f"    + PVPBotConfig.INSTANCE.pendingCoOwnerAdd);
                PVPBotConfig.INSTANCE.pendingCoOwnerAdd = null;
            }

            // ── v15: BotBunker ────────────────────────────────────
            if (PVPBotConfig.INSTANCE.bunkerEnabled && bunker.tick()) return;

            // ── v12: TargetPriority — умный выбор цели ───────────
            targetPriority.tick();

            // ── v14: PatternAI — обновление паттернов движения цели ──
            if (getTarget() != null && PVPBotConfig.INSTANCE.patternAIEnabled) {
                patternAI.update(getTarget());
            } else if (getTarget() == null) {
                patternAI.reset();
            }

            // ── v12: AutoRetreat ──────────────────────────────────
            boolean retreating = false;
            if (getTarget() != null) {
                retreating = autoRetreat.tick(getTarget());
            }

            // ── v12: Clone mode ───────────────────────────────────
            BotClone.INSTANCE.tick(this);

            // ── Страф + BotDifficultyAI во время боя ─────────────
            if (!retreating && getTarget() != null && getTarget().isAlive()) {
                // v14: ComboBreaker — если под комбо, прерываем атаку
                if (comboBreaker.tick(getTarget())) return;

                // v16: FakeAttack тик (если активен — блокирует атаку на PAUSE_TICKS)
                if (fakeAttack.tick(getTarget())) return;

                // v12: продвинутый StrafeAI вместо простого стрейфа
                strafeAI.tick(getTarget());

                // ── v14: TrainingMode ────────────────────────────────
                if (PVPBotConfig.INSTANCE.trainingMode) {
                    TrainingMode.INSTANCE.tick(this, getTarget());
                }

                // ── v7: тик BotDifficultyAI ───────────────────────
                difficultyAI.tick(getTarget());

                // ── v1.2: PVPBotLogic (NPC) ───────────────────────
                pvpLogic.tick();

                // ── v12: синхроатака — тик (isClient уже проверен выше) ──
                {
                    var sw = (net.minecraft.server.level.ServerLevel) level();
                    Player owner = getOwner();
                    if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
                        var bots = com.pvpbot.SpawnBotCommand.getBotsFor(sp);
                        BotSyncAttack.INSTANCE.serverTick(bots);
                    }
                }
            }
        }
    }

    private void updateNameTag() {
        int hp    = (int) getHealth();
        int maxHp = (int) getMaxHealth();
        String modeStr = switch (mode) {
            case GUARD      -> "§a[GUARD]";
            case AGGRESSIVE -> "§c[AGRO]";
            case PASSIVE    -> "§7[PASS]";
        };
        // v7: показываем уровень сложности в имени
        String diffStr = switch (PVPBotConfig.INSTANCE.difficulty) {
            case EASY   -> "§7[EASY]";
            case MEDIUM -> "§e[MED]";
            case HARD   -> "§c[HARD]";
            case EXPERT -> "§4§l[EXPERT]";
        };
        String bar = buildHpBar(hp, maxHp);
        setCustomName(Component.literal("§ePVP-Bot " + modeStr + " " + diffStr + "  " + bar + " §f" + hp + "§7/" + maxHp));
        setCustomNameVisible(true);
    }

    private String buildHpBar(int hp, int max) {
        if (max == 0) return "";
        int filled = Math.min(8, (int)(8.0 * hp / max));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i == filled) sb.append("§c");
            else if (i == 0) sb.append("§a");
            sb.append(i < filled ? "█" : "░");
        }
        return sb.toString();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag nbt) {
        super.addAdditionalSaveData(nbt);
        if (ownerUUID != null) nbt.putUUID("OwnerUUID", ownerUUID);
        nbt.putString("BotMode", mode.name());
        // v7: сохраняем сложность в NBT
        nbt.putString("BotDifficulty", PVPBotConfig.INSTANCE.difficulty.name());
        // v9: сохраняем ник скина
        if (skinNick != null) nbt.putString("SkinNick", skinNick);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag nbt) {
        super.readAdditionalSaveData(nbt);
        if (nbt.hasUUID("OwnerUUID")) ownerUUID = nbt.getUUID("OwnerUUID");
        if (nbt.contains("BotMode")) {
            try { mode = BotMode.valueOf(nbt.getString("BotMode")); }
            catch (IllegalArgumentException ignored) { mode = BotMode.GUARD; }
        }
        // v7: восстанавливаем сложность из NBT и применяем
        // v9: восстанавливаем ник скина
        if (nbt.contains("SkinNick")) skinNick = nbt.getString("SkinNick");
        if (nbt.contains("BotDifficulty")) {
            try {
                PVPBotConfig.INSTANCE.difficulty =
                    PVPBotConfig.Difficulty.valueOf(nbt.getString("BotDifficulty"));
                PVPBotConfig.INSTANCE.applyDifficulty();
            } catch (IllegalArgumentException ignored) {}
        }
    }

    // ── API ───────────────────────────────────────────────────────
    public void setOwner(Player player) { this.ownerUUID = player.getUUID(); }
    public java.util.UUID getOwnerUUID() { return ownerUUID; }

    @Nullable
    public Player getOwner() {
        if (ownerUUID == null || !(level() instanceof ServerLevel sw)) return null;
        return sw.getPlayerByUUID(ownerUUID);
    }

    public BotMode getBotMode() { return mode; }

    // v9: скин
    public String getSkinNick() { return skinNick; }
    public void setSkinNick(String nick) { this.skinNick = nick; }

    public void setBotMode(BotMode m) {
        mode = m;
        setTarget(null);
        updateNameTag();
    }

    public void cycleMode() {
        mode = switch (mode) {
            case GUARD      -> BotMode.AGGRESSIVE;
            case AGGRESSIVE -> BotMode.PASSIVE;
            case PASSIVE    -> BotMode.GUARD;
        };
        setTarget(null);
        updateNameTag();
    }

    public boolean isAlliedToCustom(net.minecraft.world.entity.Entity other) {
        if (other instanceof Player p && ownerUUID != null && p.getUUID().equals(ownerUUID)) return true;
        return super.isAlliedTo(other);
    }

    // isAffectedByDaylight removed in 1.21.4

    // ── v10: AntiKnockback ────────────────────────────────────────
    @Override
    public void knockback(double strength, double x, double z) {
        if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK)) {
            super.knockback(strength, x, z);
        } else {
            AntiKnockback.apply(this, strength, x, z);
        }
    }

    @Override
    public boolean canPickUpLoot() { return false; }

    @Override
    protected void dropEquipment(net.minecraft.server.level.ServerLevel serverLevel) {}

    // ── v14: damage override для ComboBreaker + BotNotifier ──────
    // Кастомная логика урона вызывается через Fabric Event или hurt-overide
    // В 1.21.4 hurt() - final, используем другой подход
    public void onHurtCustom(DamageSource source, float amount) {
        comboBreaker.onDamageReceived(amount);
        // Уведомление при низком HP
        if (getHealth() < 10.0f && getHealth() > 0) {
            notifier.onLowHp();
        }
    }

    @Override
    public void die(DamageSource damageSource) {
        super.die(damageSource);
        // Уведомление о смерти
        net.minecraft.world.entity.Entity killer = damageSource.getEntity();
        notifier.onDeath(killer instanceof LivingEntity le ? le : null);
    }
}
