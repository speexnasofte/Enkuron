package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * TpcLogic — логика TPC (Totem-Pot-Crystal) режима.
 *
 * TPC — гибридный режим, комбинирует:
 *   - Топор (снимает щит, высокий урон)
 *   - End Crystals (взрыв при сближении)
 *   - Тотем в оффхенде (авто-спасение при 0 HP)
 *
 * Ротация оружия:
 *   dist > 10  → лук
 *   dist 4-10  → кристаллы (взрыв)
 *   dist < 4   → топор (shield break + удары)
 *
 * Тотем:
 *   - Тотем всегда в оффхенде
 *   - При HP < 4 — уходим назад и ждём тотема
 *   - После тотема — Regen + Absorption от тотема автоматически
 *
 * Кристальный цикл:
 *   1. Размещаем кристалл рядом с целью (симуляция)
 *   2. Взрываем кристалл (урон + knockback)
 *   3. Повторяем с кулдауном
 */
public class TpcLogic {

    // ── Дистанции ─────────────────────────────────────────────────
    private static final double BOW_RANGE      = 12.0;
    private static final double CRYSTAL_RANGE  = 8.0;
    private static final double AXE_RANGE      = 4.0;
    private static final double IDEAL_AXE_DIST = 2.8;

    // ── Кулдауны ─────────────────────────────────────────────────
    private static final int CRYSTAL_CD  = 15;  // 0.75 сек
    private static final int AXE_CD      = 18;  // чуть быстрее обычного топора (TPC стиль)
    private static final int BOW_CD      = 22;
    private static final int BURST_CD    = 8;   // burst удары топором
    private static final int BURST_COUNT = 3;
    private static final int RETREAT_CD  = 80;

    private final BotEntity bot;

    private int crystalCd  = 0;
    private int axeCd      = 0;
    private int bowCd      = 0;
    private int burstCd    = 0;
    private int burstHits  = 0;
    private int retreatCd  = 0;
    private int shieldDisabled = 0;
    private boolean inBurst  = false;
    private boolean retreating = false;

    public TpcLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { retreating = false; return; }

        // Кулдауны
        if (crystalCd     > 0) crystalCd--;
        if (axeCd         > 0) axeCd--;
        if (bowCd         > 0) bowCd--;
        if (burstCd       > 0) burstCd--;
        if (retreatCd     > 0) retreatCd--;
        if (shieldDisabled > 0) shieldDisabled--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // Тотем всегда в оффхенде
        ensureTotem();

        // ── Критическое HP → отступаем ────────────────────────────
        if (myHp < 4.0f && retreatCd <= 0) {
            retreating = true;
            retreatCd  = RETREAT_CD;
        }
        if (retreating) {
            doRetreat(sw, target);
            if (myHp > 10.0f || retreatCd <= 0) retreating = false;
            return;
        }

        // ── Лук — дальняя дистанция ───────────────────────────────
        if (dist > BOW_RANGE) {
            doLongRange(sw, target, dist);
            return;
        }

        // ── Кристалл — средняя дистанция ─────────────────────────
        if (dist > AXE_RANGE && dist <= CRYSTAL_RANGE && crystalCd <= 0) {
            docrystalAttack(sw, target);
        }

        // ── Топор — ближний бой ───────────────────────────────────
        if (dist <= AXE_RANGE) {
            doAxeFight(sw, target, dist);
        }
    }

    // ── Дальний бой: лук ─────────────────────────────────────────
    private void doLongRange(ServerLevel sw, LivingEntity target, double dist) {
        equipBow();
        if (bowCd > 0) return;

        Vec3 aim = MotionPredictor.predict(target, (int)(dist / 3));
        float dmg = (float) Math.max(3.0, Math.min(9.0, 10.0 - dist * 0.35));

        sw.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(aim, aim).inflate(1.3),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.hurt(sw.damageSources().arrow(null, bot), dmg)
        );
        bot.playSound(net.minecraft.sounds.SoundEvents.ARROW_SHOOT, 0.9f, 1.0f);
        bowCd = BOW_CD;
    }

    // ── Кристальная атака ─────────────────────────────────────────
    private void docrystalAttack(ServerLevel sw, LivingEntity target) {
        // Симуляция взрыва кристалла рядом с целью
        float crystalDmg = 14.0f; // больший урон чем в BotDifficultyAI (TPC специализация)

        target.hurt(sw.damageSources().explosion(bot, bot), crystalDmg);

        // Сильный knockback вверх
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(kb.x * 1.0, 0.9, kb.z * 1.0);

        sw.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
            target.getX(), target.getY(), target.getZ(), 1, 0, 0, 0, 0);
        bot.playSound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE.value(), 0.8f, 1.0f);

        crystalCd = CRYSTAL_CD;
    }

    // ── Ближний бой топором ───────────────────────────────────────
    private void doAxeFight(ServerLevel sw, LivingEntity target, double dist) {
        equipAxe();

        // Позиционирование
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        if (dist > IDEAL_AXE_DIST + 0.4) {
            bot.setDeltaMovement(bot.getDeltaMovement().add(toTarget.scale(0.16)));
        }

        // Shield break
        boolean blocking = isBlocking(target);
        if (blocking && axeCd <= 0) {
            doAxeHit(sw, target, 9.0f);
            shieldDisabled = 100;
            inBurst        = true;
            burstHits      = 0;
            return;
        }

        // Burst combo пока щит снят
        if (shieldDisabled > 0 && inBurst && burstCd <= 0) {
            if (burstHits < BURST_COUNT) {
                doAxeHit(sw, target, 8.0f);
                burstCd  = BURST_CD;
                burstHits++;
            } else {
                inBurst   = false;
                burstHits = 0;
                axeCd     = AXE_CD;
            }
            return;
        }

        // Обычный удар
        if (!blocking && axeCd <= 0) {
            doAxeHit(sw, target, 9.0f);
        }
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, float dmg) {
        target.hurt(sw.damageSources().playerAttack(null), dmg);
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(),
            6, 0.3, 0.3, 0.3, 0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
        axeCd = AXE_CD;
    }

    // ── Отступление при низком HP ─────────────────────────────────
    private void doRetreat(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.35);
        bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0.1, away.z));
        equipAxe(); // держим топор даже при отступлении
    }

    // ── Тотем в оффхенде ─────────────────────────────────────────
    private void ensureTotem() {
        ItemStack off = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (!off.is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    private boolean isBlocking(LivingEntity target) {
        if (shieldDisabled > 0) return false;
        ItemStack off  = target.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = target.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && target.isBlocking();
    }

    private void equipAxe() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_AXE));
    }

    private void equipBow() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
    }
}
