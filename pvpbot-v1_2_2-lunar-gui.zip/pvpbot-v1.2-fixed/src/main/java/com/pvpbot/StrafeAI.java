package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * StrafeAI — продвинутое уклонение бота во время боя (v12).
 *
 * Стили:
 *   CIRCLE  — бот движется по дуге вокруг цели (классический страф)
 *   RANDOM  — случайные смены направления (непредсказуемо)
 *   ZIGZAG  — зигзаг с чередованием сторон
 *   RETREAT — отступить-атаковать-отступить (hit-and-run)
 *
 * Вызывается из BotEntity.tick() вместо простого стрейфа.
 */
public class StrafeAI {

    public enum StrafeStyle { CIRCLE, RANDOM, ZIGZAG, RETREAT }

    // ── Настройки ─────────────────────────────────────────────────
    private static final int   DIR_CHANGE_MIN  = 12;  // тиков минимум до смены
    private static final int   DIR_CHANGE_MAX  = 25;  // тиков максимум до смены
    private static final double STRAFE_SPEED   = 0.22;
    private static final double RETREAT_DIST   = 5.0;  // блоков отхода при RETREAT
    private static final int   RETREAT_TICKS   = 15;   // тиков отхода

    // ── v1.2: HighGround ──────────────────────────────────────────
    /** Разница высот ниже которой пытаемся занять высоту */
    private static final double HIGH_GROUND_Y_DIFF  = 1.2;
    /** Горизонтальный радиус поиска блока для подъёма */
    private static final double HIGH_GROUND_SEEK_R  = 2.5;
    /** Тиков между попытками занять высоту */
    private static final int    HIGH_GROUND_INTERVAL = 30;

    // ── Состояние ─────────────────────────────────────────────────
    private StrafeStyle style     = StrafeStyle.CIRCLE;
    private boolean strafeLeft    = true;
    private int     dirTimer      = 0;
    private int     retreatTimer  = 0;
    private boolean retreating    = false;

    // v1.2: HighGround
    private int     highGroundTimer = 0;

    private final BotEntity bot;

    public StrafeAI(BotEntity bot) {
        this.bot = bot;
        this.dirTimer = DIR_CHANGE_MIN + bot.level().getRandom().nextInt(DIR_CHANGE_MAX - DIR_CHANGE_MIN);
    }

    public void setStyle(StrafeStyle s) { this.style = s; }
    public StrafeStyle getStyle()       { return style; }

    /**
     * Главный тик. Применяет движение уклонения.
     * Вызывать из BotEntity.tick() когда есть цель.
     */
    public void tick(LivingEntity target) {
        dirTimer--;
        if (dirTimer <= 0) {
            strafeLeft = !strafeLeft;
            dirTimer = DIR_CHANGE_MIN + bot.level().getRandom().nextInt(DIR_CHANGE_MAX - DIR_CHANGE_MIN);
        }

        // v1.2: HighGround — пытаемся занять возвышение перед стрейфом
        tickHighGround(target);

        switch (style) {
            case CIRCLE  -> tickCircle(target);
            case RANDOM  -> tickRandom(target);
            case ZIGZAG  -> tickZigzag(target);
            case RETREAT -> tickRetreat(target);
        }
    }

    // ─────────────────────────────────────────────────────────────

    private void tickCircle(LivingEntity target) {
        // Движение по дуге вокруг цели
        double yaw = Math.toRadians(bot.getYRot() + (strafeLeft ? -90 : 90));
        applyStrafe(yaw, STRAFE_SPEED);
    }

    private void tickRandom(LivingEntity target) {
        // Полностью случайное направление каждые dirTimer тиков
        double yaw = Math.toRadians(bot.level().getRandom().nextFloat() * 360f);
        applyStrafe(yaw, STRAFE_SPEED * 0.8);
    }

    private void tickZigzag(LivingEntity target) {
        // Зигзаг: чередуем резкие смены стороны быстрее чем обычно
        double yaw = Math.toRadians(bot.getYRot() + (strafeLeft ? -70 : 70));
        applyStrafe(yaw, STRAFE_SPEED * 1.1);
    }

    private void tickRetreat(LivingEntity target) {
        double dist = bot.distanceTo(target);

        if (retreating) {
            retreatTimer--;
            // Отступаем от цели
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(STRAFE_SPEED * 1.3);
            bot.setDeltaMovement(bot.getDeltaMovement().add(away.x, 0, away.z));
            if (retreatTimer <= 0) retreating = false;
        } else {
            // Обычный круговой страф, но периодически уходим
            tickCircle(target);
            // Если получили урон (низкое HP) — отступаем
            if (bot.getHealth() < bot.getMaxHealth() * 0.5 && dist < 3.0) {
                retreating = true;
                retreatTimer = RETREAT_TICKS;
            }
        }
    }

    // ── v1.2: HighGround ─────────────────────────────────────────
    /**
     * Если бот ниже цели на HIGH_GROUND_Y_DIFF+ блоков — ищет
     * соседний блок выше и запрыгивает на него (прыжок + движение).
     * Критический удар в 1.21.4 требует падения — высота даёт
     * больше шансов атаковать во время падения.
     */
    private void tickHighGround(LivingEntity target) {
        if (highGroundTimer > 0) { highGroundTimer--; return; }
        highGroundTimer = HIGH_GROUND_INTERVAL;

        double botY    = bot.getY();
        double targetY = target.getY();

        // Уже выше или на уровне — ничего не делаем
        if (botY >= targetY - 0.5) return;

        // Ищем позицию выше вокруг бота
        net.minecraft.core.BlockPos botPos = bot.blockPosition();
        net.minecraft.world.level.Level world = bot.level();

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > HIGH_GROUND_SEEK_R) continue;

                net.minecraft.core.BlockPos check = botPos.offset(dx, 1, dz);

                // Блок должен быть твёрдым снизу и свободным сверху
                if (!world.getBlockState(check).isAir()) continue;
                if (!world.getBlockState(check.below()).isFaceSturdy(world, check.below(), net.minecraft.core.Direction.UP)) continue;
                if (!world.getBlockState(check.above()).isAir()) continue;

                // Нашли — прыгаем туда
                bot.getNavigation().moveTo(
                    botPos.getX() + dx + 0.5,
                    botPos.getY() + 1,
                    botPos.getZ() + dz + 0.5,
                    1.3
                );
                // Фикс v1.2.1: setJumping() protected — используем JumpControl
                bot.getJumpControl().jump();
                return;
            }
        }
    }

    private void applyStrafe(double yawRad, double speed) {
        double sx = Math.sin(yawRad) * speed;
        double sz = -Math.cos(yawRad) * speed;
        bot.setDeltaMovement(bot.getDeltaMovement().add(sx, 0, sz));
    }
}
