package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * PVPBotScreen — главное GUI окно мода в стиле Lunar Client.
 *
 * Вкладки:
 *   KITS      — выбор кита (карточки как в Lunar, 3 колонки)
 *   MODES     — выбор режима боя (SWORD, CRYSTAL, SMP, UHC, ...)
 *   MODULES   — переключение модулей (AutoAttack, AutoTotem, ...)
 *   SETTINGS  — числовые настройки (range, cooldown, ...)
 *   ADVANCED  — расширенные настройки AI, PatternAI, DifficultyAI
 *   WHITELIST — управление вайтлистом игроков
 *
 * Открывается по клавише G (задаётся в PVPBotMod).
 *
 * Версия: 3.0 — полный рерайт с поддержкой:
 *   • Анимированные переходы между вкладками
 *   • Поиск по модулям
 *   • Tooltip-подсказки при наведении
 *   • Цветные полоски и иконки для каждого кита/режима
 *   • Скролл карточек
 *   • Статус-бар внизу
 */
public class PVPBotScreen extends Screen {

    // ═══════════════════════════════════════════════════════════════
    //  КОНСТАНТЫ ЦВЕТОВ (ARGB)
    // ═══════════════════════════════════════════════════════════════

    // Фоны
    private static final int BG_DARK        = 0xFF0F1117;
    private static final int BG_PANEL       = 0xFF181C24;
    private static final int BG_CARD        = 0xFF1E2330;
    private static final int BG_CARD_HOV    = 0xFF252B3A;
    private static final int BG_CARD_SEL    = 0xFF1A2A1A;
    private static final int BG_CARD_DIS    = 0xFF2A1A1A;
    private static final int BG_INPUT       = 0xFF141820;
    private static final int BG_TOOLTIP     = 0xEE0F1117;
    private static final int BG_SEARCH      = 0xFF14181F;

    // Рамки
    private static final int BORDER_SEL     = 0xFF3DBA5A;
    private static final int BORDER_DEF     = 0xFF2A3040;
    private static final int BORDER_HOV     = 0xFF3A4560;
    private static final int BORDER_RED     = 0xFFBA3D3D;
    private static final int BORDER_TOOLTIP = 0xFF3A4560;

    // Акценты
    private static final int ACCENT_GREEN   = 0xFF3DBA5A;
    private static final int ACCENT_RED     = 0xFFBA3D3D;
    private static final int ACCENT_BLUE    = 0xFF3D8FBA;
    private static final int ACCENT_YELLOW  = 0xFFBAA03D;
    private static final int ACCENT_PURPLE  = 0xFF8B3DBA;
    private static final int ACCENT_ORANGE  = 0xFFBA6D3D;
    private static final int ACCENT_CYAN    = 0xFF3DBABA;

    // Вкладки
    private static final int TAB_ACTIVE     = 0xFF3DBA5A;
    private static final int TAB_INACTIVE   = 0xFF252B3A;
    private static final int TAB_HOV        = 0xFF2E3545;

    // Текст
    private static final int TEXT_WHITE     = 0xFFFFFFFF;
    private static final int TEXT_GRAY      = 0xFF8A8FA8;
    private static final int TEXT_DARK      = 0xFF4A5068;
    private static final int TEXT_GREEN     = 0xFF3DBA5A;
    private static final int TEXT_RED       = 0xFFBA3D3D;
    private static final int TEXT_YELLOW    = 0xFFBAA03D;
    private static final int TEXT_BLUE      = 0xFF3D8FBA;

    // Enabled/Disabled фоны
    private static final int ENABLED_BG     = 0xFF1A3A1A;
    private static final int DISABLED_BG    = 0xFF3A1A1A;
    private static final int ENABLED_LABEL  = 0xFF3DBA5A;
    private static final int DISABLED_LABEL = 0xFFBA3D3D;

    // Полупрозрачное затемнение
    private static final int OVERLAY        = 0xAA000000;

    // ═══════════════════════════════════════════════════════════════
    //  ENUM ВКЛАДОК
    // ═══════════════════════════════════════════════════════════════

    private enum Tab {
        KITS("KITS", "⚔"),
        MODES("MODES", "🎮"),
        MODULES("MODULES", "⚡"),
        SETTINGS("SETTINGS", "⚙"),
        ADVANCED("ADVANCED", "🔬"),
        PROFILES("PROFILES", "👤"),
        STATS("STATS", "📊"),
        WHITELIST("WHITELIST", "📋");

        final String label;
        final String icon;
        Tab(String label, String icon) {
            this.label = label;
            this.icon  = icon;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  РАЗМЕРЫ И СОСТОЯНИЕ
    // ═══════════════════════════════════════════════════════════════

    // Размеры окна
    private static final int WIN_W = 620;
    private static final int WIN_H = 420;
    private int winX, winY, winW, winH;

    // Высота заголовка, вкладок, футера
    private static final int HEADER_H  = 34;
    private static final int TABS_H    = 26;
    private static final int FOOTER_H  = 20;
    private static final int CONTENT_Y_OFFSET = HEADER_H + TABS_H + 6;

    // Состояние
    private Tab    currentTab   = Tab.KITS;
    private int    mouseX, mouseY;
    private int    scrollOffset = 0;
    private String searchQuery  = "";
    private long   openTime     = 0;

    // Анимация переключения вкладок
    private Tab    prevTab      = null;
    private float  tabAnim      = 1.0f;    // 0..1
    private long   tabAnimStart = 0;
    private static final int TAB_ANIM_MS = 120;

    // Tooltip
    private String tooltipText  = null;
    private int    tooltipX, tooltipY;

    // Конфиг
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    // Постоянные кнопки
    private Button btnClose;
    private Button[] tabButtons;

    // Whitelist ввод
    private String whitelistInput = "";
    private boolean whitelistInputFocused = false;

    // ═══════════════════════════════════════════════════════════════
    //  LUNAR-STYLE SUB-TABS ДЛЯ MODULES
    // ═══════════════════════════════════════════════════════════════

    /** Подвкладки модулей в стиле Lunar Client */
    private enum ModuleCategory {
        ALL("ALL"),
        NEW("NEW"),
        HUD("HUD"),
        SERVER("SERVER"),
        MECHANIC("MECHANIC"),
        COMBAT("COMBAT"),
        VISUAL("VISUAL"),
        UTILITY("UTILITY");

        final String label;
        ModuleCategory(String label) { this.label = label; }
    }

    private ModuleCategory moduleCategory = ModuleCategory.ALL;

    // Маппинг модулей по категориям
    private static final Map<String, ModuleCategory> MODULE_CATEGORIES = new HashMap<>();
    static {
        MODULE_CATEGORIES.put("Auto Attack",   ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Auto Dodge",    ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Auto Heal",     ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Gap",      ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Armor",    ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Totem",    ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Eat",      ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("W-Tap",         ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("S-Tap",         ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Auto Sprint",   ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Crystal",  ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Auto Bow",      ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Kite",          ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("ESP",           ModuleCategory.VISUAL);
        MODULE_CATEGORIES.put("Radar",         ModuleCategory.HUD);
        MODULE_CATEGORIES.put("Tracers",       ModuleCategory.VISUAL);
        MODULE_CATEGORIES.put("Anti KB",       ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Auto Respawn",  ModuleCategory.UTILITY);
        MODULE_CATEGORIES.put("Auto Log",      ModuleCategory.UTILITY);
        MODULE_CATEGORIES.put("Auto Pearl",    ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Show HUD",      ModuleCategory.HUD);
        MODULE_CATEGORIES.put("Show DPS",      ModuleCategory.HUD);
        MODULE_CATEGORIES.put("Stats",         ModuleCategory.HUD);
        MODULE_CATEGORIES.put("Pattern AI",    ModuleCategory.SERVER);
        MODULE_CATEGORIES.put("Anti Pattern",  ModuleCategory.SERVER);
        MODULE_CATEGORIES.put("Training Mode", ModuleCategory.UTILITY);
        MODULE_CATEGORIES.put("Auto Kit",      ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Notifications", ModuleCategory.UTILITY);
        MODULE_CATEGORIES.put("Adaptive CD",   ModuleCategory.SERVER);
        MODULE_CATEGORIES.put("Fake Attack",   ModuleCategory.COMBAT);
        MODULE_CATEGORIES.put("Bunker",        ModuleCategory.MECHANIC);
        MODULE_CATEGORIES.put("Hunt",          ModuleCategory.UTILITY);
        // NEW tag — новые модули
        MODULE_CATEGORIES.put("Pattern AI",    ModuleCategory.NEW);
        MODULE_CATEGORIES.put("Fake Attack",   ModuleCategory.NEW);
        MODULE_CATEGORIES.put("Hunt",          ModuleCategory.NEW);
    }

    // Список "новых" модулей (для вкладки NEW)
    private static final java.util.Set<String> NEW_MODULES = new java.util.HashSet<>(Arrays.asList(
        "Pattern AI", "Fake Attack", "Hunt", "Auto Crystal", "Adaptive CD"
    ));

    // ═══════════════════════════════════════════════════════════════
    //  OPTIONS PANEL — панель настроек конкретного модуля
    // ═══════════════════════════════════════════════════════════════

    /** Открытая панель опций (имя модуля или null) */
    private String optionsPanelModule = null;

    /** Позиция панели опций */
    private int optionsPanelX, optionsPanelY;

    // ═══════════════════════════════════════════════════════════════
    //  PROFILES СИСТЕМА
    // ═══════════════════════════════════════════════════════════════

    /** Профили — пресеты настроек */
    private static class BotProfile {
        String name;
        String description;
        String mode;
        String difficulty;
        int color;
        boolean isActive;
        long createdAt;

        BotProfile(String name, String description, String mode, String difficulty, int color) {
            this.name        = name;
            this.description = description;
            this.mode        = mode;
            this.difficulty  = difficulty;
            this.color       = color;
            this.isActive    = false;
            this.createdAt   = System.currentTimeMillis();
        }
    }

    private final List<BotProfile> profiles = new ArrayList<>();
    private int activeProfileIndex = 0;
    private String profileEditInput = "";
    private boolean profileInputFocused = false;

    // ═══════════════════════════════════════════════════════════════
    //  STATS СИСТЕМА — статистика боя
    // ═══════════════════════════════════════════════════════════════

    /** Запись о сессии боя */
    private static class BattleSession {
        String opponent;
        String result;   // "WIN" / "LOSS" / "DRAW"
        int    damageDone;
        int    damageTaken;
        long   durationMs;
        String mode;

        BattleSession(String opponent, String result, int dd, int dt, long dur, String mode) {
            this.opponent    = opponent;
            this.result      = result;
            this.damageDone  = dd;
            this.damageTaken = dt;
            this.durationMs  = dur;
            this.mode        = mode;
        }
    }

    private final List<BattleSession> battleHistory = new ArrayList<>();
    private int statsScrollOffset = 0;

    // Суммарная статистика (runtime-счётчики)
    private int totalKills       = 0;
    private int totalDeaths      = 0;
    private int totalDamageDone  = 0;
    private int totalDamageTaken = 0;
    private long totalFightTime  = 0L;
    private int sessionWins      = 0;
    private int sessionLosses    = 0;

    // ═══════════════════════════════════════════════════════════════
    //  ДОПОЛНИТЕЛЬНЫЕ ЦВЕТА (расширение)
    // ═══════════════════════════════════════════════════════════════

    private static final int BG_SUB_TAB      = 0xFF12161E;
    private static final int BG_SUB_TAB_ACT  = 0xFF1E2845;
    private static final int ACCENT_NEW       = 0xFF00C8FF;
    private static final int BORDER_NEW       = 0xFF00C8FF;
    private static final int BG_PROFILE_CARD  = 0xFF181E2C;
    private static final int BG_STATS_ROW     = 0xFF151922;
    private static final int ACCENT_WIN       = 0xFF22C55E;
    private static final int ACCENT_LOSS      = 0xFFEF4444;
    private static final int ACCENT_DRAW      = 0xFF94A3B8;
    private static final int BG_OPTIONS_PANEL = 0xFF0C1018;
    private static final int BG_BADGE_GREEN   = 0xFF14341A;
    private static final int BG_BADGE_RED     = 0xFF341414;
    private static final int ACCENT_TEAL      = 0xFF14B8A6;
    private static final int ACCENT_INDIGO    = 0xFF6366F1;
    private static final int BG_GRAPH_BAR     = 0xFF1E2845;
    private static final int BG_HEADER_GRAD   = 0xFF0D1117;

    // ═══════════════════════════════════════════════════════════════
    //  ДАННЫЕ МОДУЛЕЙ
    // ═══════════════════════════════════════════════════════════════

    /** Полный список модулей: { displayName, configField, tooltip } */
    private static final String[][] MODULE_LIST = {
        { "Auto Attack",   "autoAttack",           "Автоматически атакует ближайшего врага" },
        { "Auto Dodge",    "autoDodge",             "Уклоняется от атак в ближнем бою" },
        { "Auto Heal",     "autoHeal",              "Пьёт зелья лечения при низком HP" },
        { "Auto Gap",      "autoGapEnabled",        "Ест золотые яблоки при критическом HP" },
        { "Auto Armor",    "autoArmor",             "Надевает лучшую доступную броню" },
        { "Auto Totem",    "autoTotem",             "Перекладывает тотем в оффхенд автоматически" },
        { "Auto Eat",      "autoEat",               "Ест еду при голоде ниже порога" },
        { "W-Tap",         "wTapEnabled",           "Зажимает/отпускает W для сброса кулдауна" },
        { "S-Tap",         "sTapEnabled",           "Зажимает S после удара для уменьшения KB" },
        { "Auto Sprint",   "autoSprint",            "Всегда держит спринт включённым" },
        { "Auto Crystal",  "autoCrystal",           "Расставляет и взрывает End Crystal-ы" },
        { "Auto Bow",      "autoBowEnabled",        "Стреляет из лука на дальней дистанции" },
        { "Kite",          "kiteEnabled",           "Держит дистанцию и стреляет из лука" },
        { "ESP",           "espEnabled",            "Подсвечивает игроков сквозь стены" },
        { "Radar",         "radarEnabled",          "Отображает мини-карту с игроками" },
        { "Tracers",       "tracersEnabled",        "Рисует линии к ближайшим игрокам" },
        { "Anti KB",       "antiKnockbackEnabled",  "Снижает отброс от ударов" },
        { "Auto Respawn",  "autoRespawn",           "Автоматически нажимает «Возродиться»" },
        { "Auto Log",      "autoLogEnabled",        "Выходит из игры при критическом HP" },
        { "Auto Pearl",    "autoPearlEnabled",      "Бросает Эндер-жемчуг для отступления" },
        { "Show HUD",      "showHud",               "Отображает HUD с информацией о боте" },
        { "Show DPS",      "showDps",               "Показывает урон в секунду на экране" },
        { "Stats",         "statsEnabled",          "Ведёт статистику K/D и урона" },
        { "Pattern AI",    "patternAIEnabled",      "ИИ случайно меняет паттерны атаки" },
        { "Anti Pattern",  "antiPatternEnabled",    "Контрит паттерны атаки противника" },
        { "Training Mode", "trainingMode",          "Бот атакует в щадящем режиме" },
        { "Auto Kit",      "autoKitSelect",         "Автоматически выбирает кит по броне врага" },
        { "Notifications", "notificationsEnabled",  "Уведомления о событиях боя в чат" },
        { "Adaptive CD",   "adaptiveCooldownEnabled","Адаптивный кулдаун атаки под пинг" },
        { "Fake Attack",   "fakeAttackEnabled",     "Делает ложные замахи для дезориентации" },
        { "Bunker",        "bunkerEnabled",         "Прячется в укрытие при низком HP" },
        { "Hunt",          "huntEnabled",           "Ищет и преследует врагов на расстоянии" },
    };

    // ═══════════════════════════════════════════════════════════════
    //  КОНСТРУКТОР
    // ═══════════════════════════════════════════════════════════════

    public PVPBotScreen(Screen parent) {
        super(Component.literal("PVPBot GUI"));
        initProfiles();
        initSampleStats();
    }

    /** Инициализация встроенных профилей */
    private void initProfiles() {
        if (!profiles.isEmpty()) return;
        profiles.add(new BotProfile("Latest Version PvP", "Оптимально для 1.21+ серверов", "SWORD",   "HARD",   0xFF3DBA5A));
        profiles.add(new BotProfile("Lower Version PvP",  "Классический стиль 1.8-1.16",   "AXE",     "MEDIUM", 0xFF3D8FBA));
        profiles.add(new BotProfile("Crystal Fighter",    "Crystal PvP на AntiCheat серверах","CRYSTAL","EXPERT", 0xFF8B3DBA));
        profiles.add(new BotProfile("Beginner Mode",      "Лёгкий режим для тренировки",   "SMP",     "EASY",   0xFFBAA03D));
        profiles.add(new BotProfile("Main",               "Основной профиль",               "SWORD",   "HARD",   0xFFBA3D3D));
        profiles.get(0).isActive = true;
    }

    /** Инициализация демо-статистики */
    private void initSampleStats() {
        if (!battleHistory.isEmpty()) return;
        battleHistory.add(new BattleSession("Notch",     "WIN",  142, 87,  45000, "SWORD"));
        battleHistory.add(new BattleSession("Steve",     "WIN",  198, 120, 63000, "AXE"));
        battleHistory.add(new BattleSession("Herobrine", "LOSS", 67,  200, 38000, "CRYSTAL"));
        battleHistory.add(new BattleSession("Alex",      "WIN",  155, 90,  52000, "SWORD"));
        battleHistory.add(new BattleSession("Enderman",  "DRAW", 100, 100, 60000, "SMP"));
        battleHistory.add(new BattleSession("Creeper",   "WIN",  210, 45,  35000, "MACE"));
        totalKills      = 4;
        totalDeaths     = 1;
        totalDamageDone = 872;
        totalDamageTaken= 642;
        sessionWins     = 4;
        sessionLosses   = 1;
    }

    // ═══════════════════════════════════════════════════════════════
    //  ИНИЦИАЛИЗАЦИЯ
    // ═══════════════════════════════════════════════════════════════

    @Override
    protected void init() {
        openTime = System.currentTimeMillis();

        winX = (width  - WIN_W) / 2;
        winY = (height - WIN_H) / 2;
        winW = WIN_W;
        winH = WIN_H;

        // Вкладки
        Tab[] tabs = Tab.values();
        tabButtons = new Button[tabs.length];
        int tabW   = (winW - 20) / tabs.length;
        int tabH   = 18;
        int tabY   = winY + HEADER_H + 4;

        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            tabButtons[i] = addRenderableWidget(Button.builder(
                Component.literal(t.label),
                b -> switchTab(t)
            ).pos(winX + 10 + i * tabW, tabY).size(tabW - 2, tabH).build());
        }

        // Кнопка закрыть
        btnClose = addRenderableWidget(Button.builder(
            Component.literal("✕"), b -> onClose()
        ).pos(winX + winW - 24, winY + 8).size(16, 16).build());

        rebuildButtons();
    }

    /** Переключение вкладки с анимацией */
    private void switchTab(Tab t) {
        if (t == currentTab) return;
        prevTab      = currentTab;
        currentTab   = t;
        scrollOffset = 0;
        searchQuery  = "";
        tabAnim      = 0.0f;
        tabAnimStart = System.currentTimeMillis();
        rebuildButtons();
    }

    /** Пересборка динамических кнопок */
    private void rebuildButtons() {
        clearWidgets();

        // Восстановить постоянные
        Tab[] tabs = Tab.values();
        int tabW = (winW - 20) / tabs.length;
        int tabH = 18;
        int tabY = winY + HEADER_H + 4;
        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            tabButtons[i] = addRenderableWidget(Button.builder(
                Component.literal(t.label),
                b -> switchTab(t)
            ).pos(winX + 10 + i * tabW, tabY).size(tabW - 2, tabH).build());
        }
        btnClose = addRenderableWidget(Button.builder(
            Component.literal("✕"), b -> onClose()
        ).pos(winX + winW - 24, winY + 8).size(16, 16).build());

        int cx    = winX + 10;
        int cy    = winY + CONTENT_Y_OFFSET;
        int cw    = winW - 20;
        int areaH = winH - CONTENT_Y_OFFSET - FOOTER_H - 4;

        switch (currentTab) {
            case KITS      -> rebuildKitButtons    (cx, cy, cw, areaH);
            case MODES     -> rebuildModeButtons   (cx, cy, cw, areaH);
            case MODULES   -> rebuildModuleButtons (cx, cy, cw, areaH);
            case SETTINGS  -> rebuildSettingsButtons(cx, cy, cw, areaH);
            case ADVANCED  -> rebuildAdvancedButtons(cx, cy, cw, areaH);
            case PROFILES  -> rebuildProfileButtons(cx, cy, cw, areaH);
            case STATS     -> rebuildStatsButtons  (cx, cy, cw, areaH);
            case WHITELIST -> rebuildWhitelistButtons(cx, cy, cw, areaH);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — KITS
    // ═══════════════════════════════════════════════════════════════

    private void rebuildKitButtons(int cx, int cy, int cw, int areaH) {
        BotKit[] kits = BotKit.values();
        int cols  = 3;
        int cardW = (cw - (cols - 1) * 6) / cols;
        int cardH = 84;
        int gap   = 6;

        for (int i = 0; i < kits.length; i++) {
            BotKit kit = kits[i];
            int col = i % cols;
            int row = i / cols;
            int x   = cx + col * (cardW + gap);
            int y   = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH < cy || y > cy + areaH) continue;

            // OPTIONS кнопка
            addRenderableWidget(Button.builder(
                Component.literal("OPTIONS"),
                b -> { /* TODO: открыть настройки кита */ }
            ).pos(x + 4, y + cardH - 32).size(cardW - 32, 12).build());

            // ENABLED/DISABLED кнопка
            boolean active = cfg.mode != null && kit.name().equalsIgnoreCase(cfg.mode.name());
            addRenderableWidget(Button.builder(
                Component.literal(active ? "ENABLED" : "DISABLED"),
                b -> { applyKit(kit); rebuildButtons(); }
            ).pos(x + 4, y + cardH - 18).size(cardW - 8, 13).build());
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — MODES
    // ═══════════════════════════════════════════════════════════════

    private void rebuildModeButtons(int cx, int cy, int cw, int areaH) {
        PVPBotConfig.Mode[] modes = PVPBotConfig.Mode.values();
        int cols  = 4;
        int cardW = (cw - (cols - 1) * 5) / cols;
        int cardH = 58;
        int gap   = 5;

        for (int i = 0; i < modes.length; i++) {
            PVPBotConfig.Mode mode = modes[i];
            int col = i % cols;
            int row = i / cols;
            int x   = cx + col * (cardW + gap);
            int y   = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH < cy || y > cy + areaH) continue;

            addRenderableWidget(Button.builder(
                Component.literal(cfg.mode == mode ? "ACTIVE" : "SELECT"),
                b -> { cfg.mode = mode; BotConfig.save(); rebuildButtons(); }
            ).pos(x + 4, y + cardH - 16).size(cardW - 8, 12).build());
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — MODULES
    // ═══════════════════════════════════════════════════════════════

    private void rebuildModuleButtons(int cx, int cy, int cw, int areaH) {
        // ── Lunar-style sub-tabs (ALL / NEW / HUD / SERVER / MECHANIC / COMBAT / VISUAL / UTILITY)
        ModuleCategory[] cats = ModuleCategory.values();
        int subTabW = Math.max(36, (cw - (cats.length - 1) * 3) / cats.length);
        int subTabY = cy - 32;
        for (int i = 0; i < cats.length; i++) {
            final ModuleCategory cat = cats[i];
            addRenderableWidget(Button.builder(
                Component.literal(cat.label),
                b -> { moduleCategory = cat; scrollOffset = 0; optionsPanelModule = null; rebuildButtons(); }
            ).pos(cx + i * (subTabW + 3), subTabY).size(subTabW, 14).build());
        }

        // ── Поиск (иконка 🔍 уже рисуется в renderModules)

        // ── Карточки модулей
        int cols  = 3;
        int cardW = (cw - (cols - 1) * 6) / cols;
        int cardH = 52;  // увеличенная высота карточек как в Lunar
        int gap   = 5;
        int row   = 0;
        int col   = 0;

        for (String[] mod : MODULE_LIST) {
            String name  = mod[0];
            String field = mod[1];

            if (!passesModuleFilter(name)) continue;

            int x = cx + col * (cardW + gap);
            int y = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH >= cy && y <= cy + areaH) {
                // OPTIONS gear button
                addRenderableWidget(Button.builder(
                    Component.literal("OPTIONS"),
                    b -> {
                        if (name.equals(optionsPanelModule)) {
                            optionsPanelModule = null;
                        } else {
                            optionsPanelModule = name;
                            optionsPanelX = x;
                            optionsPanelY = y + cardH;
                        }
                        rebuildButtons();
                    }
                ).pos(x + 2, y + cardH - 28).size(cardW - 30, 12).build());

                // ⚙ settings cog button (small, right side)
                addRenderableWidget(Button.builder(
                    Component.literal("⚙"),
                    b -> {
                        optionsPanelModule = name.equals(optionsPanelModule) ? null : name;
                        optionsPanelX = x + cardW - 16;
                        optionsPanelY = y + cardH;
                        rebuildButtons();
                    }
                ).pos(x + cardW - 16, y + cardH - 28).size(14, 12).build());

                // ENABLED / DISABLED toggle
                boolean val = getField(field);
                addRenderableWidget(Button.builder(
                    Component.literal(val ? "ENABLED" : "DISABLED"),
                    b -> { toggleField(field); BotConfig.save(); rebuildButtons(); }
                ).pos(x + 2, y + cardH - 14).size(cardW - 4, 12).build());
            }

            col++;
            if (col >= cols) { col = 0; row++; }
        }

        // OPTIONS panel close button
        if (optionsPanelModule != null) {
            addRenderableWidget(Button.builder(
                Component.literal("✕ Закрыть"),
                b -> { optionsPanelModule = null; rebuildButtons(); }
            ).pos(winX + winW - 120, winY + CONTENT_Y_OFFSET + 2).size(108, 12).build());
        }
    }

    /** Проверка, проходит ли модуль текущий фильтр (категория + поиск) */
    private boolean passesModuleFilter(String name) {
        if (!searchQuery.isEmpty() && !name.toLowerCase().contains(searchQuery.toLowerCase()))
            return false;
        return switch (moduleCategory) {
            case ALL      -> true;
            case NEW      -> NEW_MODULES.contains(name);
            case HUD      -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.HUD;
            }
            case SERVER   -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.SERVER;
            }
            case MECHANIC -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.MECHANIC;
            }
            case COMBAT   -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.COMBAT;
            }
            case VISUAL   -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.VISUAL;
            }
            case UTILITY  -> {
                ModuleCategory c = MODULE_CATEGORIES.get(name);
                yield c == ModuleCategory.UTILITY;
            }
        };
    }

    // ─── PROFILES кнопки ───────────────────────────────────────────

    private void rebuildProfileButtons(int cx, int cy, int cw, int areaH) {
        int cardH = 56;
        int gap   = 6;
        for (int i = 0; i < profiles.size(); i++) {
            BotProfile p = profiles.get(i);
            int y = cy + i * (cardH + gap) - scrollOffset;
            if (y + cardH < cy || y > cy + areaH) continue;

            final int idx = i;
            // Activate button
            addRenderableWidget(Button.builder(
                Component.literal(p.isActive ? "§a● ACTIVE" : "ACTIVATE"),
                b -> {
                    profiles.forEach(pr -> pr.isActive = false);
                    profiles.get(idx).isActive = true;
                    activeProfileIndex = idx;
                    BotConfig.save();
                    rebuildButtons();
                }
            ).pos(cx + cw - 90, y + cardH - 26).size(86, 12).build());

            // Delete button (only for non-built-in)
            if (i >= 2) {
                addRenderableWidget(Button.builder(
                    Component.literal("§c✕"),
                    b -> {
                        if (profiles.size() > 1) {
                            profiles.remove(idx);
                            if (activeProfileIndex >= profiles.size()) activeProfileIndex = 0;
                            profiles.get(activeProfileIndex).isActive = true;
                        }
                        rebuildButtons();
                    }
                ).pos(cx + cw - 18, y + 2).size(14, 12).build());
            }

            // Edit name button
            addRenderableWidget(Button.builder(
                Component.literal("✎"),
                b -> {
                    profileEditInput = p.name;
                    profileInputFocused = true;
                    rebuildButtons();
                }
            ).pos(cx + cw - 110, y + 2).size(14, 12).build());
        }

        // Create new profile button
        addRenderableWidget(Button.builder(
            Component.literal("+ Новый профиль"),
            b -> {
                profiles.add(new BotProfile(
                    "Profile " + (profiles.size() + 1),
                    "Пользовательский профиль",
                    cfg.mode != null ? cfg.mode.name() : "SWORD",
                    cfg.difficulty.name(),
                    0xFF3D8FBA
                ));
                rebuildButtons();
            }
        ).pos(cx, cy + profiles.size() * (56 + gap) - scrollOffset).size(140, 16).build());
    }

    // ─── STATS кнопки ──────────────────────────────────────────────

    private void rebuildStatsButtons(int cx, int cy, int cw, int areaH) {
        // Reset button
        addRenderableWidget(Button.builder(
            Component.literal("§cСбросить статистику"),
            b -> {
                battleHistory.clear();
                totalKills = totalDeaths = totalDamageDone = totalDamageTaken = 0;
                sessionWins = sessionLosses = 0;
                totalFightTime = 0;
                rebuildButtons();
            }
        ).pos(cx + cw - 140, cy - 14).size(136, 12).build());

        // Export button
        addRenderableWidget(Button.builder(
            Component.literal("§7Экспорт в чат"),
            b -> {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    mc.gui.getChat().addMessage(Component.literal(
                        "§aPVPBot Stats §8| §fK: §a" + totalKills +
                        " §8| §fD: §c" + totalDeaths +
                        " §8| §fDMG: §e" + totalDamageDone
                    ));
                }
            }
        ).pos(cx, cy - 14).size(136, 12).build());
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — SETTINGS
    // ═══════════════════════════════════════════════════════════════

    private void rebuildSettingsButtons(int cx, int cy, int cw, int areaH) {
        // Сложность
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int bw = (cw - (diffs.length - 1) * 4) / diffs.length;
        for (int i = 0; i < diffs.length; i++) {
            PVPBotConfig.Difficulty d = diffs[i];
            addRenderableWidget(Button.builder(
                Component.literal(d.name()),
                b -> { cfg.difficulty = d; cfg.applyDifficulty(); BotConfig.save(); rebuildButtons(); }
            ).pos(cx + i * (bw + 4), cy).size(bw, 18).build());
        }

        // Глобальный включатель
        addRenderableWidget(Button.builder(
            Component.literal(cfg.enabled ? "§a● ВКЛЮЧЁН" : "§c● ВЫКЛЮЧЕН"),
            b -> { cfg.enabled = !cfg.enabled; BotConfig.save(); rebuildButtons(); }
        ).pos(cx, cy + 24).size(130, 18).build());

        // Whitelist переключатель
        addRenderableWidget(Button.builder(
            Component.literal(cfg.whitelistEnabled ? "Whitelist: §aON" : "Whitelist: §cOFF"),
            b -> { cfg.whitelistEnabled = !cfg.whitelistEnabled; BotConfig.save(); rebuildButtons(); }
        ).pos(cx + 136, cy + 24).size(110, 18).build());

        // WebConfig переключатель
        addRenderableWidget(Button.builder(
            Component.literal(cfg.webConfigEnabled ? "WebAPI: §aON" : "WebAPI: §cOFF"),
            b -> { cfg.webConfigEnabled = !cfg.webConfigEnabled; BotConfig.save(); rebuildButtons(); }
        ).pos(cx + 252, cy + 24).size(110, 18).build());

        // Кнопки +/- для числовых настроек
        addSettingArrows(cx, cy + 52,  cw, "attackRange",     "Attack Range",   0.5, 1.0, 10.0);
        addSettingArrows(cx, cy + 70,  cw, "attackCooldown",  "Attack CD",      1.0, 1.0, 30.0);
        addSettingArrows(cx, cy + 88,  cw, "dodgeRange",      "Dodge Range",    0.5, 1.0, 8.0);
        addSettingArrows(cx, cy + 106, cw, "healThreshold",   "Heal HP",        1.0, 4.0, 20.0);
        addSettingArrows(cx, cy + 124, cw, "autoGapHpThreshold","Gap HP",        1.0, 4.0, 20.0);
        addSettingArrows(cx, cy + 142, cw, "crystalPlaceRange","Crystal Range",  0.5, 1.0, 10.0);
        addSettingArrows(cx, cy + 160, cw, "crystalCooldown", "Crystal CD",     1.0, 1.0, 20.0);
        addSettingArrows(cx, cy + 178, cw, "wTapReleaseTicks","W-Tap Ticks",    1.0, 1.0, 10.0);
    }

    /** Добавляет кнопки − и + для числового поля */
    private void addSettingArrows(int cx, int y, int cw, String field,
                                   String label, double step, double min, double max) {
        int half = cw / 2;
        // Кнопка −
        addRenderableWidget(Button.builder(
            Component.literal("−"),
            b -> { adjustDoubleField(field, -step, min, max); BotConfig.save(); rebuildButtons(); }
        ).pos(cx + half - 30, y + 1).size(14, 12).build());
        // Кнопка +
        addRenderableWidget(Button.builder(
            Component.literal("+"),
            b -> { adjustDoubleField(field, step, min, max); BotConfig.save(); rebuildButtons(); }
        ).pos(cx + half + 16, y + 1).size(14, 12).build());
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — ADVANCED
    // ═══════════════════════════════════════════════════════════════

    private void rebuildAdvancedButtons(int cx, int cy, int cw, int areaH) {
        // Кнопки + / - для AI параметров
        addSettingArrows(cx, cy + 0,   cw, "diffPredictTicks",      "Predict Ticks",   1.0, 1.0, 10.0);
        addSettingArrows(cx, cy + 18,  cw, "diffComboLength",       "Combo Length",    1.0, 1.0, 8.0);
        addSettingArrows(cx, cy + 36,  cw, "diffComboPauseTicks",   "Combo Pause",     1.0, 4.0, 40.0);
        addSettingArrows(cx, cy + 54,  cw, "diffPearlThrowDist",    "Pearl Throw Dist",1.0, 4.0, 24.0);
        addSettingArrows(cx, cy + 72,  cw, "diffPearlCooldown",     "Pearl CD",        10.0, 40.0, 400.0);
        addSettingArrows(cx, cy + 90,  cw, "diffBowSwitchRange",    "Bow Switch Range",1.0, 4.0, 32.0);
        addSettingArrows(cx, cy + 108, cw, "diffBowCooldown",       "Bow CD",          2.0, 4.0, 60.0);
        addSettingArrows(cx, cy + 126, cw, "diffCrystalPlaceRange", "Crystal Place R", 0.5, 2.0, 10.0);
        addSettingArrows(cx, cy + 144, cw, "diffCrystalCooldown",   "Crystal AI CD",   2.0, 4.0, 80.0);
        addSettingArrows(cx, cy + 162, cw, "diffCrystalDamage",     "Crystal Dmg",     1.0, 4.0, 24.0);
        addSettingArrows(cx, cy + 180, cw, "espRange",              "ESP Range",       4.0, 16.0, 128.0);
        addSettingArrows(cx, cy + 198, cw, "radarRange",            "Radar Range",     4.0, 16.0, 128.0);
        addSettingArrows(cx, cy + 216, cw, "huntRange",             "Hunt Range",      8.0, 32.0, 256.0);
        addSettingArrows(cx, cy + 234, cw, "bunkerHpThreshold",     "Bunker HP",       1.0, 2.0, 20.0);

        // Boolean переключатели
        addRenderableWidget(Button.builder(
            Component.literal(cfg.diffUsePearls ? "Use Pearls: §aON" : "Use Pearls: §cOFF"),
            b -> { cfg.diffUsePearls = !cfg.diffUsePearls; BotConfig.save(); rebuildButtons(); }
        ).pos(cx, cy + 258).size(120, 14).build());

        addRenderableWidget(Button.builder(
            Component.literal(cfg.diffUseCrystals ? "Use Crystals: §aON" : "Use Crystals: §cOFF"),
            b -> { cfg.diffUseCrystals = !cfg.diffUseCrystals; BotConfig.save(); rebuildButtons(); }
        ).pos(cx + 128, cy + 258).size(130, 14).build());

        addRenderableWidget(Button.builder(
            Component.literal(cfg.advPathfind ? "Adv.Path: §aON" : "Adv.Path: §cOFF"),
            b -> { cfg.advPathfind = !cfg.advPathfind; BotConfig.save(); rebuildButtons(); }
        ).pos(cx + 266, cy + 258).size(110, 14).build());
    }

    // ═══════════════════════════════════════════════════════════════
    //  КНОПКИ — WHITELIST
    // ═══════════════════════════════════════════════════════════════

    private void rebuildWhitelistButtons(int cx, int cy, int cw, int areaH) {
        // Кнопка добавить (когда в поле введено имя)
        addRenderableWidget(Button.builder(
            Component.literal("+ ADD"),
            b -> {
                String name = whitelistInput.trim();
                if (!name.isEmpty() && !cfg.whitelist.contains(name)) {
                    cfg.whitelist.add(name);
                    BotConfig.save();
                }
                whitelistInput = "";
                rebuildButtons();
            }
        ).pos(cx + cw - 54, cy).size(50, 14).build());

        // Кнопки удаления для каждого игрока
        int listY = cy + 24;
        for (int i = 0; i < cfg.whitelist.size(); i++) {
            String player = cfg.whitelist.get(i);
            final int idx = i;
            int rowY = listY + i * 16 - scrollOffset;
            if (rowY < cy + 18 || rowY > cy + areaH) continue;

            addRenderableWidget(Button.builder(
                Component.literal("✕"),
                b -> { cfg.whitelist.remove(idx); BotConfig.save(); rebuildButtons(); }
            ).pos(cx + cw - 20, rowY).size(16, 12).build());
        }

        // Очистить всё
        if (!cfg.whitelist.isEmpty()) {
            addRenderableWidget(Button.builder(
                Component.literal("CLEAR ALL"),
                b -> { cfg.whitelist.clear(); BotConfig.save(); rebuildButtons(); }
            ).pos(cx, cy + areaH - 16).size(80, 13).build());
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  RENDER
    // ═══════════════════════════════════════════════════════════════

    @Override
    public void render(GuiGraphics ctx, int mx, int my, float delta) {
        this.mouseX   = mx;
        this.mouseY   = my;
        this.tooltipText = null;

        // Обновить анимацию вкладок
        if (tabAnim < 1.0f) {
            long elapsed = System.currentTimeMillis() - tabAnimStart;
            tabAnim = Math.min(1.0f, (float) elapsed / TAB_ANIM_MS);
        }

        // Фон
        renderBackground(ctx, mx, my, delta);

        // Главный контейнер
        drawRect(ctx, winX, winY, winW, winH, BG_PANEL);
        drawBorder(ctx, winX, winY, winW, winH, BORDER_DEF);

        // Тень под окном
        drawShadow(ctx, winX, winY, winW, winH);

        // Заголовок
        renderHeader(ctx);

        // Вкладки (рисуются за кнопками)
        renderTabBar(ctx);

        // Разделитель между вкладками и контентом
        drawRect(ctx, winX, winY + HEADER_H + TABS_H + 2, winW, 1, BORDER_DEF);

        // Контент
        int cx    = winX + 10;
        int cy    = winY + CONTENT_Y_OFFSET;
        int cw    = winW - 20;
        int areaH = winH - CONTENT_Y_OFFSET - FOOTER_H - 4;

        switch (currentTab) {
            case KITS      -> renderKits    (ctx, cx, cy, cw, areaH);
            case MODES     -> renderModes   (ctx, cx, cy, cw, areaH);
            case MODULES   -> renderModules (ctx, cx, cy, cw, areaH);
            case SETTINGS  -> renderSettings(ctx, cx, cy, cw, areaH);
            case ADVANCED  -> renderAdvanced(ctx, cx, cy, cw, areaH);
            case PROFILES  -> renderProfiles(ctx, cx, cy, cw, areaH);
            case STATS     -> renderStats   (ctx, cx, cy, cw, areaH);
            case WHITELIST -> renderWhitelist(ctx, cx, cy, cw, areaH);
        }

        // Футер
        renderFooter(ctx);

        // Кнопки поверх всего
        super.render(ctx, mx, my, delta);

        // Tooltip рисуем в самом конце
        if (tooltipText != null) {
            renderTooltip(ctx, tooltipText, tooltipX, tooltipY);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Заголовок
    // ─────────────────────────────────────────────────────────────

    private void renderHeader(GuiGraphics ctx) {
        // Полоса заголовка
        drawRect(ctx, winX, winY, winW, HEADER_H, BG_DARK);
        drawRect(ctx, winX, winY + HEADER_H - 1, winW, 1, BORDER_DEF);

        // Логотип
        ctx.drawString(font, Component.literal("§f⚙ §aPVPBot"), winX + 10, winY + 10, TEXT_WHITE, true);

        // Версия
        ctx.drawString(font, Component.literal("§8│ §7v1.2.2"), winX + 74, winY + 10, TEXT_GRAY, true);

        // Статус бота (вкл/выкл)
        String statusStr = cfg.enabled ? "§a● ACTIVE" : "§c● INACTIVE";
        int statusW = font.width(statusStr.replace("§a", "").replace("§c", ""));
        ctx.drawString(font, Component.literal(statusStr), winX + winW - statusW - 30, winY + 10, TEXT_WHITE, true);

        // Текущий режим
        String modeStr = "§7Mode: §f" + (cfg.mode != null ? cfg.mode.name() : "NONE");
        ctx.drawString(font, Component.literal(modeStr), winX + 160, winY + 10, TEXT_WHITE, true);
    }

    // ─────────────────────────────────────────────────────────────
    //  Панель вкладок
    // ─────────────────────────────────────────────────────────────

    private void renderTabBar(GuiGraphics ctx) {
        Tab[] tabs = Tab.values();
        int tabW = (winW - 20) / tabs.length;
        int tabH = 18;
        int tabY = winY + HEADER_H + 4;

        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            int x = winX + 10 + i * tabW;
            boolean active  = t == currentTab;
            boolean hovered = mouseX >= x && mouseX < x + tabW - 2
                           && mouseY >= tabY && mouseY < tabY + tabH;

            // Нижний акцент активной вкладки
            if (active) {
                drawRect(ctx, x, tabY + tabH - 2, tabW - 2, 2, ACCENT_GREEN);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Футер
    // ─────────────────────────────────────────────────────────────

    private void renderFooter(GuiGraphics ctx) {
        int fy = winY + winH - FOOTER_H;
        drawRect(ctx, winX, fy, winW, FOOTER_H, BG_DARK);
        drawRect(ctx, winX, fy, winW, 1, BORDER_DEF);

        String left = "§8[G] закрыть  [Scroll] прокрутка";
        ctx.drawString(font, Component.literal(left), winX + 8, fy + 6, TEXT_DARK, true);

        String right = "§7Diff: " + diffColorStr(cfg.difficulty) + cfg.difficulty.name()
                     + "  §7Bots: §f" + cfg.maxBots;
        int rw = font.width(right
            .replace("§7","").replace("§f","")
            .replace("§a","").replace("§e","")
            .replace("§c","").replace("§4",""));
        ctx.drawString(font, Component.literal(right), winX + winW - rw - 8, fy + 6, TEXT_WHITE, true);
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки KITS
    // ─────────────────────────────────────────────────────────────

    private void renderKits(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        BotKit[] kits = BotKit.values();
        int cols  = 3;
        int cardW = (cw - (cols - 1) * 6) / cols;
        int cardH = 84;
        int gap   = 6;

        for (int i = 0; i < kits.length; i++) {
            BotKit kit = kits[i];
            int col = i % cols;
            int row = i / cols;
            int x   = cx + col * (cardW + gap);
            int y   = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH < cy || y > cy + areaH) continue;

            boolean selected = cfg.mode != null && kit.name().equalsIgnoreCase(cfg.mode.name());
            boolean hovered  = isMouseIn(x, y, cardW, cardH);

            int bg  = selected ? BG_CARD_SEL : hovered ? BG_CARD_HOV : BG_CARD;
            int brd = selected ? BORDER_SEL  : hovered ? BORDER_HOV  : BORDER_DEF;

            drawRect  (ctx, x, y, cardW, cardH, bg);
            drawBorder(ctx, x, y, cardW, cardH, brd);

            // Верхняя цветная полоска
            int stripe = kitStripeColor(kit);
            drawRect(ctx, x, y, cardW, 3, stripe);

            // Иконка
            String icon = kitIcon(kit);
            ctx.drawString(font, Component.literal(icon), x + cardW / 2 - 4, y + 6, TEXT_WHITE, true);

            // Название
            ctx.drawCenteredString(font,
                Component.literal("§f" + kit.name()), x + cardW / 2, y + 22, TEXT_WHITE);

            // Описание
            String desc = kitShortDesc(kit);
            ctx.drawCenteredString(font,
                Component.literal("§8" + desc), x + cardW / 2, y + 33, TEXT_GRAY);

            // Тег стиля
            String tag = kitTag(kit);
            int tagColor = kitTagColor(kit);
            ctx.drawCenteredString(font,
                Component.literal(tag), x + cardW / 2, y + 44, tagColor);

            // Разделитель перед кнопками
            drawRect(ctx, x + 4, y + cardH - 36, cardW - 8, 1, BORDER_DEF);

            // Tooltip
            if (hovered) {
                setTooltip(kitTooltip(kit), mouseX, mouseY);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки MODES
    // ─────────────────────────────────────────────────────────────

    private void renderModes(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        PVPBotConfig.Mode[] modes = PVPBotConfig.Mode.values();
        int cols  = 4;
        int cardW = (cw - (cols - 1) * 5) / cols;
        int cardH = 58;
        int gap   = 5;

        for (int i = 0; i < modes.length; i++) {
            PVPBotConfig.Mode mode = modes[i];
            int col = i % cols;
            int row = i / cols;
            int x   = cx + col * (cardW + gap);
            int y   = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH < cy || y > cy + areaH) continue;

            boolean selected = cfg.mode == mode;
            boolean hovered  = isMouseIn(x, y, cardW, cardH);

            int bg  = selected ? BG_CARD_SEL : hovered ? BG_CARD_HOV : BG_CARD;
            int brd = selected ? BORDER_SEL  : hovered ? BORDER_HOV  : BORDER_DEF;

            drawRect  (ctx, x, y, cardW, cardH, bg);
            drawBorder(ctx, x, y, cardW, cardH, brd);

            // Полоска
            drawRect(ctx, x, y, cardW, 3, modeStripeColor(mode));

            // Иконка
            ctx.drawString(font,
                Component.literal(modeIcon(mode)), x + cardW / 2 - 4, y + 6, TEXT_WHITE, true);

            // Название
            ctx.drawCenteredString(font,
                Component.literal("§f" + mode.name()), x + cardW / 2, y + 20, TEXT_WHITE);

            // Описание
            ctx.drawCenteredString(font,
                Component.literal("§8" + modeShortDesc(mode)), x + cardW / 2, y + 30, TEXT_GRAY);

            // Разделитель
            drawRect(ctx, x + 4, y + cardH - 18, cardW - 8, 1, BORDER_DEF);

            if (hovered) {
                setTooltip("Режим: " + mode.name() + "\n" + modeShortDesc(mode), mouseX, mouseY);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки MODULES (стиль Lunar Client)
    // ─────────────────────────────────────────────────────────────

    private void renderModules(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        // ── Lunar-style sub-tab bar ──────────────────────────────
        ModuleCategory[] cats = ModuleCategory.values();
        int subTabW = Math.max(36, (cw - (cats.length - 1) * 3) / cats.length);
        int subTabY = cy - 32;

        // Фон полосы подвкладок
        drawRect(ctx, cx - 2, subTabY - 2, cw + 4, 18, BG_SUB_TAB);
        drawRect(ctx, cx - 2, subTabY + 16, cw + 4, 1, BORDER_DEF);

        for (int i = 0; i < cats.length; i++) {
            ModuleCategory cat = cats[i];
            int x = cx + i * (subTabW + 3);
            boolean active  = cat == moduleCategory;
            boolean hovered = isMouseIn(x, subTabY, subTabW, 14);

            int bg = active ? BG_SUB_TAB_ACT : hovered ? 0xFF1A2030 : BG_SUB_TAB;
            drawRect(ctx, x, subTabY, subTabW, 14, bg);

            // Нижняя линия активной подвкладки
            if (active) {
                int accent = cat == ModuleCategory.NEW ? ACCENT_NEW : ACCENT_GREEN;
                drawRect(ctx, x, subTabY + 12, subTabW, 2, accent);
            }

            // Бейдж "NEW" на подвкладке NEW
            int txtColor = active ? (cat == ModuleCategory.NEW ? ACCENT_NEW : TEXT_GREEN) : TEXT_GRAY;
            ctx.drawCenteredString(font,
                Component.literal(cat.label), x + subTabW / 2, subTabY + 3, txtColor);
        }

        // ── Строка поиска ───────────────────────────────────────
        int searchY = cy - 16;
        int searchW = cw - 80;
        drawRect  (ctx, cx, searchY, searchW, 13, BG_SEARCH);
        drawBorder(ctx, cx, searchY, searchW, 13, whitelistInputFocused ? BORDER_SEL : BORDER_DEF);
        // Иконка лупы
        ctx.drawString(font, Component.literal("§8🔍"), cx + 3, searchY + 3, TEXT_DARK, true);
        String searchDisplay = searchQuery.isEmpty()
            ? "§8  Поиск модуля..."
            : "§7  " + searchQuery + (whitelistInputFocused ? "§f|" : "");
        ctx.drawString(font, Component.literal(searchDisplay), cx + 12, searchY + 3, TEXT_GRAY, true);

        // Счётчик найденных
        long count = Arrays.stream(MODULE_LIST).filter(m -> passesModuleFilter(m[0])).count();
        ctx.drawString(font, Component.literal("§8" + count + " модулей"), cx + searchW + 4, searchY + 3, TEXT_DARK, true);

        // ── Карточки модулей (Lunar-style) ───────────────────────
        int cols  = 3;
        int cardW = (cw - (cols - 1) * 6) / cols;
        int cardH = 52;
        int gap   = 5;
        int row   = 0;
        int col   = 0;

        for (String[] mod : MODULE_LIST) {
            String name    = mod[0];
            String field   = mod[1];
            String tooltip = mod[2];

            if (!passesModuleFilter(name)) continue;

            int x = cx + col * (cardW + gap);
            int y = cy + row * (cardH + gap) - scrollOffset;

            if (y + cardH >= cy && y <= cy + areaH) {
                boolean enabled = getField(field);
                boolean hovered = isMouseIn(x, y, cardW, cardH);
                boolean optOpen = name.equals(optionsPanelModule);

                // Фон карточки
                int bg  = enabled  ? (hovered ? 0xFF1E3A22 : ENABLED_BG)
                                   : (hovered ? BG_CARD_HOV : BG_CARD);
                int brd = optOpen  ? ACCENT_BLUE
                        : enabled  ? BORDER_SEL
                        : hovered  ? BORDER_HOV
                        : BORDER_DEF;

                drawRect  (ctx, x, y, cardW, cardH, bg);
                drawBorder(ctx, x, y, cardW, cardH, brd);

                // Верхняя цветная полоска
                int stripe = enabled ? ACCENT_GREEN : TEXT_DARK;
                drawRect(ctx, x, y, cardW, 2, stripe);

                // ── Иконка модуля (слева, большая) ──────────────
                String icon = moduleIcon(name);
                ctx.drawString(font, Component.literal(icon), x + 5, y + 5, TEXT_WHITE, true);

                // ── Название ────────────────────────────────────
                ctx.drawString(font, Component.literal("§f" + name), x + 18, y + 5, TEXT_WHITE, true);

                // ── NEW бейдж ───────────────────────────────────
                if (NEW_MODULES.contains(name)) {
                    int bx = x + cardW - 26;
                    int by = y + 4;
                    drawRect  (ctx, bx, by, 24, 8, 0xFF002B3D);
                    drawBorder(ctx, bx, by, 24, 8, ACCENT_NEW);
                    ctx.drawString(font, Component.literal("§bNEW"), bx + 3, by + 1, ACCENT_NEW, true);
                }

                // ── Категория бейдж ─────────────────────────────
                ModuleCategory cat = MODULE_CATEGORIES.getOrDefault(name, ModuleCategory.ALL);
                String catLabel = cat == ModuleCategory.ALL ? "" : cat.label;
                if (!catLabel.isEmpty()) {
                    ctx.drawString(font, Component.literal("§8" + catLabel), x + 18, y + 15, TEXT_DARK, true);
                }

                // ── Разделитель ─────────────────────────────────
                drawRect(ctx, x + 2, y + cardH - 30, cardW - 4, 1, BORDER_DEF);

                // ── OPTIONS + ⚙ фон-полоска ─────────────────────
                // (кнопки добавлены в rebuildModuleButtons)
                drawRect(ctx, x + 2, y + cardH - 28, cardW - 30, 12,
                    optOpen ? 0xFF1A2A3A : 0xFF141820);
                ctx.drawString(font, Component.literal("§7OPTIONS"), x + 4, y + cardH - 25, TEXT_DARK, true);

                // ── ENABLED / DISABLED фон ───────────────────────
                int enBg  = enabled ? 0xFF1A3D1A : 0xFF3D1A1A;
                int enClr = enabled ? ENABLED_LABEL : DISABLED_LABEL;
                drawRect(ctx, x + 2, y + cardH - 14, cardW - 4, 12, enBg);
                ctx.drawCenteredString(font,
                    Component.literal(enabled ? "§aENABLED" : "§cDISABLED"),
                    x + cardW / 2, y + cardH - 11, enClr);

                if (hovered) setTooltip(name + "\n" + tooltip, mouseX, mouseY);
            }

            col++;
            if (col >= cols) { col = 0; row++; }
        }

        // ── OPTIONS PANEL (всплывающая панель настроек) ──────────
        if (optionsPanelModule != null) {
            renderOptionsPanel(ctx, cx, cy, cw, areaH);
        }
    }

    /**
     * Всплывающая панель OPTIONS для модуля — в стиле Lunar Client:
     * тёмный фон, список пунктов настройки, checkbox-переключатели.
     */
    private void renderOptionsPanel(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        String mod = optionsPanelModule;
        if (mod == null) return;

        int pw = 220;
        int ph = 160;
        // Позиционируем панель в правой части экрана чтобы не перекрывать карточки
        int px = Math.min(optionsPanelX, winX + winW - pw - 8);
        int py = Math.min(optionsPanelY, winY + winH - ph - FOOTER_H - 4);
        if (py < winY + CONTENT_Y_OFFSET) py = winY + CONTENT_Y_OFFSET;

        // Тень
        for (int i = 3; i >= 0; i--) {
            ctx.fill(px - i, py + i, px + pw + i, py + ph + i, (0x15 + i * 0x08) << 24);
        }

        // Основной фон
        drawRect  (ctx, px, py, pw, ph, BG_OPTIONS_PANEL);
        drawBorder(ctx, px, py, pw, ph, ACCENT_BLUE);

        // Заголовок панели
        drawRect(ctx, px, py, pw, 18, 0xFF0D1520);
        drawRect(ctx, px, py, pw, 2, ACCENT_BLUE);
        ctx.drawString(font, Component.literal("§b⚙ §f" + mod + " §8– Options"), px + 5, py + 5, TEXT_WHITE, true);

        // Содержимое — настройки конкретного модуля
        int oy = py + 22;
        int lh = 16;

        // Специфичные настройки по модулю
        switch (mod) {
            case "Auto Attack" -> {
                renderOptionCheckbox(ctx, px + 4, oy,      "Предсказание движения", cfg.patternAIEnabled);
                renderOptionSlider  (ctx, px + 4, oy + lh, "Дальность",  cfg.attackRange,   1.0, 10.0, pw - 8);
                renderOptionSlider  (ctx, px + 4, oy + lh*2, "Кулдаун",  cfg.attackCooldown, 1.0, 30.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh*3, "W-Tap синхрон",       cfg.wTapEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*4, "Паттерн AI",          cfg.patternAIEnabled);
                renderOptionSlider  (ctx, px + 4, oy + lh*5, "Combo length",cfg.diffComboLength,1.0,8.0, pw-8);
                renderOptionInfo    (ctx, px + 4, oy + lh*6, "§8Версия модуля: §71.2.2");
                renderOptionInfo    (ctx, px + 4, oy + lh*7, "§8Тип: §7COMBAT | Приоритет: §aВЫСОКИЙ");
            }
            case "Auto Heal" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "HP порог",  cfg.healThreshold, 1.0, 20.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh, "Splash зелья",  cfg.autoHeal);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Instant heal", cfg.autoHeal);
                renderOptionInfo    (ctx, px + 4, oy + lh*3, "§8Не лечит при Crystal PvP");
                renderOptionInfo    (ctx, px + 4, oy + lh*4, "§8Тип: §7MECHANIC");
            }
            case "ESP" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "Дальность ESP", cfg.espRange, 16.0, 128.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh, "Показывать здоровье", cfg.espEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Цвет по HP",       cfg.espEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*3, "Outline glow",     cfg.espEnabled);
                renderOptionInfo    (ctx, px + 4, oy + lh*4, "§8Тип: §7VISUAL | FPS -2");
            }
            case "Radar" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "Радиус",    cfg.radarRange, 16.0, 128.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh, "Показывать ников", cfg.radarEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Rotate with cam",  cfg.radarEnabled);
                renderOptionInfo    (ctx, px + 4, oy + lh*3, "§8Тип: §7HUD");
            }
            case "Auto Crystal" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "Place range", cfg.crystalPlaceRange, 1.0, 10.0, pw - 8);
                renderOptionSlider  (ctx, px + 4, oy + lh, "Кулдаун",    cfg.crystalCooldown,    1.0, 20.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Anti-суицид",    cfg.autoCrystal);
                renderOptionCheckbox(ctx, px + 4, oy + lh*3, "Face Place",     cfg.autoCrystal);
                renderOptionSlider  (ctx, px + 4, oy + lh*4, "Min damage", cfg.diffCrystalDamage, 4.0, 24.0, pw-8);
                renderOptionInfo    (ctx, px + 4, oy + lh*5, "§8Тип: §7COMBAT | Только 1.16+");
            }
            case "W-Tap" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "Release ticks", cfg.wTapReleaseTicks, 1.0, 10.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh, "Только при спринте", cfg.wTapEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Авто-адаптация", cfg.adaptiveCooldownEnabled);
                renderOptionInfo    (ctx, px + 4, oy + lh*3, "§8Тип: §7COMBAT | Требует 1.9+");
            }
            case "Kite" -> {
                renderOptionSlider  (ctx, px + 4, oy,      "Bow range", cfg.diffBowSwitchRange, 4.0, 32.0, pw - 8);
                renderOptionSlider  (ctx, px + 4, oy + lh, "Bow CD",    cfg.diffBowCooldown, 4.0, 60.0, pw - 8);
                renderOptionCheckbox(ctx, px + 4, oy + lh*2, "Strafing AI",   cfg.kiteEnabled);
                renderOptionCheckbox(ctx, px + 4, oy + lh*3, "Pearl escape",  cfg.autoPearlEnabled);
                renderOptionInfo    (ctx, px + 4, oy + lh*4, "§8Тип: §7COMBAT");
            }
            default -> {
                // Универсальная панель для остальных модулей
                boolean cur = getField(mod.equals("Auto Attack") ? "autoAttack" :
                    Arrays.stream(MODULE_LIST)
                        .filter(m -> m[0].equals(mod))
                        .map(m -> m[1])
                        .findFirst().orElse("autoAttack"));
                renderOptionCheckbox(ctx, px + 4, oy,      "Включён",           cur);
                renderOptionInfo    (ctx, px + 4, oy + lh, "§8" + Arrays.stream(MODULE_LIST)
                    .filter(m -> m[0].equals(mod)).map(m -> m[2]).findFirst().orElse(""));
                renderOptionInfo    (ctx, px + 4, oy + lh*2, "§8Категория: §7" +
                    MODULE_CATEGORIES.getOrDefault(mod, ModuleCategory.ALL).label);
                renderOptionInfo    (ctx, px + 4, oy + lh*3, "§8Версия: §71.2.2");
                renderOptionInfo    (ctx, px + 4, oy + lh*4, "§8Статус: " +
                    (cur ? "§aACTIVE" : "§cINACTIVE"));
            }
        }
    }

    /** Рисует строку-checkbox в OPTIONS панели */
    private void renderOptionCheckbox(GuiGraphics ctx, int x, int y, String label, boolean val) {
        int bx = x, by = y + 1;
        drawRect  (ctx, bx, by, 8, 8, val ? ENABLED_BG : BG_CARD);
        drawBorder(ctx, bx, by, 8, 8, val ? BORDER_SEL : BORDER_DEF);
        if (val) {
            ctx.drawString(font, Component.literal("§a✔"), bx + 1, by, TEXT_GREEN, true);
        }
        ctx.drawString(font, Component.literal("§7" + label), x + 12, y + 1, TEXT_GRAY, true);
    }

    /** Рисует строку-слайдер в OPTIONS панели */
    private void renderOptionSlider(GuiGraphics ctx, int x, int y, String label,
                                    double value, double min, double max, int width) {
        ctx.drawString(font, Component.literal("§7" + label + ":"), x, y + 1, TEXT_GRAY, true);
        ctx.drawString(font,
            Component.literal("§f" + (value == (int)value ? (int)value : String.format("%.1f", value))),
            x + width - 30, y + 1, TEXT_WHITE, true);
        // Track
        int trackY = y + 10;
        int trackW = width - 4;
        drawRect(ctx, x, trackY, trackW, 3, BG_CARD);
        // Fill
        double pct = Math.max(0, Math.min(1, (value - min) / (max - min)));
        drawRect(ctx, x, trackY, (int)(trackW * pct), 3, ACCENT_GREEN);
        // Thumb
        int thumbX = x + (int)(trackW * pct) - 2;
        drawRect(ctx, thumbX, trackY - 1, 5, 5, TEXT_WHITE);
    }

    /** Рисует строку информации в OPTIONS панели */
    private void renderOptionInfo(GuiGraphics ctx, int x, int y, String text) {
        ctx.drawString(font, Component.literal(text), x, y + 1, TEXT_DARK, true);
    }

    // ─────────────────────────────────────────────────────────────
    //  Иконка модуля
    // ─────────────────────────────────────────────────────────────

    private String moduleIcon(String name) {
        return switch (name) {
            case "Auto Attack"   -> "⚔";
            case "Auto Dodge"    -> "💨";
            case "Auto Heal"     -> "❤";
            case "Auto Gap"      -> "🍎";
            case "Auto Armor"    -> "🛡";
            case "Auto Totem"    -> "🗿";
            case "Auto Eat"      -> "🍗";
            case "W-Tap"         -> "⚡";
            case "S-Tap"         -> "⬇";
            case "Auto Sprint"   -> "🏃";
            case "Auto Crystal"  -> "💎";
            case "Auto Bow"      -> "🏹";
            case "Kite"          -> "🎯";
            case "ESP"           -> "👁";
            case "Radar"         -> "📡";
            case "Tracers"       -> "📍";
            case "Anti KB"       -> "🧲";
            case "Auto Respawn"  -> "♻";
            case "Auto Log"      -> "🚪";
            case "Auto Pearl"    -> "🟣";
            case "Show HUD"      -> "🖥";
            case "Show DPS"      -> "📊";
            case "Stats"         -> "📈";
            case "Pattern AI"    -> "🧠";
            case "Anti Pattern"  -> "🔀";
            case "Training Mode" -> "📚";
            case "Auto Kit"      -> "🎒";
            case "Notifications" -> "🔔";
            case "Adaptive CD"   -> "⏱";
            case "Fake Attack"   -> "👻";
            case "Bunker"        -> "🏰";
            case "Hunt"          -> "🎯";
            default              -> "●";
        };
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки PROFILES
    // ─────────────────────────────────────────────────────────────

    private void renderProfiles(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        // Заголовок
        ctx.drawString(font, Component.literal("§7Профили §8— пресеты настроек бота"), cx, cy - 14, TEXT_GRAY, true);

        int cardH = 56;
        int gap   = 6;

        for (int i = 0; i < profiles.size(); i++) {
            BotProfile p = profiles.get(i);
            int y = cy + i * (cardH + gap) - scrollOffset;
            if (y + cardH < cy || y > cy + areaH) continue;

            boolean hovered = isMouseIn(cx, y, cw, cardH);
            int bg  = p.isActive ? BG_CARD_SEL  : hovered ? BG_CARD_HOV : BG_PROFILE_CARD;
            int brd = p.isActive ? BORDER_SEL    : hovered ? BORDER_HOV  : BORDER_DEF;

            drawRect  (ctx, cx, y, cw, cardH, bg);
            drawBorder(ctx, cx, y, cw, cardH, brd);

            // Боковая цветная полоска
            drawRect(ctx, cx, y, 4, cardH, p.color);

            // Иконка профиля
            ctx.drawString(font, Component.literal("👤"), cx + 8, y + 8, TEXT_WHITE, true);

            // Название профиля
            ctx.drawString(font, Component.literal("§f" + p.name), cx + 22, y + 7, TEXT_WHITE, true);

            // Описание
            ctx.drawString(font, Component.literal("§8" + p.description), cx + 22, y + 18, TEXT_DARK, true);

            // Теги: режим и сложность
            int tagX = cx + 22;
            int tagY = y + 30;
            renderProfileTag(ctx, tagX, tagY, p.mode, modeTagColor(p.mode));
            renderProfileTag(ctx, tagX + 60, tagY, p.difficulty, diffTagColor(p.difficulty));

            // ACTIVE badge
            if (p.isActive) {
                int bx = cx + cw - 55;
                drawRect  (ctx, bx, y + 8, 52, 12, 0xFF1A3A1A);
                drawBorder(ctx, bx, y + 8, 52, 12, BORDER_SEL);
                ctx.drawCenteredString(font,
                    Component.literal("§a● ACTIVE"), bx + 26, y + 10, ACCENT_GREEN);
            }

            // Время создания
            ctx.drawString(font,
                Component.literal("§8Профиль §7#" + (i + 1)),
                cx + cw - 70, y + cardH - 14, TEXT_DARK, true);
        }

        // Кнопка создания нового профиля (рисуется под списком)
        int newBtnY = cy + profiles.size() * (cardH + gap) - scrollOffset;
        if (newBtnY <= cy + areaH) {
            drawRect  (ctx, cx, newBtnY, cw, 20, BG_CARD);
            drawBorder(ctx, cx, newBtnY, cw, 20, BORDER_DEF);
            ctx.drawCenteredString(font,
                Component.literal("§8+ §7Новый профиль"), cx + cw / 2, newBtnY + 6, TEXT_GRAY);
        }

        // Подсказка
        ctx.drawString(font, Component.literal("§8Профили сохраняются в config/pvpbot.json"), cx, cy + areaH + 4, TEXT_DARK, true);
    }

    /** Маленький цветной тег (режим / сложность) */
    private void renderProfileTag(GuiGraphics ctx, int x, int y, String label, int color) {
        int w = font.width(label) + 8;
        drawRect(ctx, x, y, w, 10, (color & 0x00FFFFFF) | 0x30000000);
        ctx.fill(x, y + 9, x + w, y + 10, color); // нижняя линия
        ctx.drawString(font,
            Component.literal("§f" + label), x + 4, y + 1,
            0xFF000000 | (color & 0xFFFFFF));
    }

    private int modeTagColor(String mode) {
        return switch (mode) {
            case "SWORD","AXE" -> ACCENT_YELLOW;
            case "CRYSTAL","TPC" -> ACCENT_CYAN;
            case "SMP"  -> ACCENT_GREEN;
            case "UHC"  -> ACCENT_RED;
            default     -> TEXT_GRAY;
        };
    }

    private int diffTagColor(String diff) {
        return switch (diff) {
            case "EASY"   -> 0xFF4ADE80;
            case "MEDIUM" -> 0xFFFACC15;
            case "HARD"   -> 0xFFF87171;
            case "EXPERT" -> 0xFFDC2626;
            default       -> TEXT_GRAY;
        };
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки STATS
    // ─────────────────────────────────────────────────────────────

    private void renderStats(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        // ── Топ-строка KDA ────────────────────────────────────────
        ctx.drawString(font, Component.literal("§7Статистика боя §8• Текущая сессия"), cx, cy - 14, TEXT_GRAY, true);

        // KDA карточки
        int statCardW = (cw - 10) / 4;
        renderStatCard(ctx, cx,                      cy, statCardW, "Kills",   String.valueOf(totalKills),   ACCENT_GREEN);
        renderStatCard(ctx, cx + statCardW + 3,       cy, statCardW, "Deaths",  String.valueOf(totalDeaths),  ACCENT_RED);
        renderStatCard(ctx, cx + (statCardW + 3) * 2, cy, statCardW, "DMG Out", String.valueOf(totalDamageDone), ACCENT_YELLOW);
        renderStatCard(ctx, cx + (statCardW + 3) * 3, cy, statCardW, "DMG In",  String.valueOf(totalDamageTaken),ACCENT_ORANGE);

        // ── KD Ratio + Win Rate ───────────────────────────────────
        int detailY = cy + 38;
        double kd = totalDeaths == 0 ? totalKills : (double)totalKills / totalDeaths;
        int total = sessionWins + sessionLosses;
        double wr = total == 0 ? 0 : (double) sessionWins / total * 100;

        renderStatDetailRow(ctx, cx, detailY, cw / 2 - 4, "K/D Ratio",
            String.format("%.2f", kd), kd >= 1.0 ? ACCENT_GREEN : ACCENT_RED);
        renderStatDetailRow(ctx, cx + cw / 2 + 2, detailY, cw / 2 - 4, "Win Rate",
            String.format("%.0f%%", wr), wr >= 50 ? ACCENT_GREEN : ACCENT_RED);

        // ── Win/Loss прогресс-бар ─────────────────────────────────
        int barY = detailY + 24;
        ctx.drawString(font, Component.literal("§7Wins / Losses"), cx, barY, TEXT_GRAY, true);
        renderWinLossBar(ctx, cx, barY + 11, cw, sessionWins, sessionLosses);

        // ── График DPS (bar chart) ────────────────────────────────
        int graphY = barY + 30;
        ctx.drawString(font, Component.literal("§7Урон по боям:"), cx, graphY - 1, TEXT_GRAY, true);
        renderDpsGraph(ctx, cx, graphY + 10, cw, 36);

        // ── История боёв ──────────────────────────────────────────
        int histY = graphY + 52;
        ctx.drawString(font,
            Component.literal("§7История §8(" + battleHistory.size() + " боёв):"),
            cx, histY - 1, TEXT_GRAY, true);

        drawRect(ctx, cx, histY + 10, cw, 1, BORDER_DEF);

        int rowH = 17;
        for (int i = 0; i < battleHistory.size(); i++) {
            BattleSession s = battleHistory.get(i);
            int ry = histY + 13 + i * rowH - statsScrollOffset;
            if (ry < histY + 10 || ry + rowH > cy + areaH + 4) continue;

            boolean hov = isMouseIn(cx, ry, cw, rowH - 1);
            drawRect(ctx, cx, ry, cw, rowH - 1, hov ? BG_CARD_HOV : (i % 2 == 0 ? BG_STATS_ROW : BG_CARD));

            // Результат бейдж
            int resColor = s.result.equals("WIN") ? ACCENT_WIN
                         : s.result.equals("LOSS") ? ACCENT_LOSS
                         : ACCENT_DRAW;
            int resBg = s.result.equals("WIN") ? 0xFF12321A
                      : s.result.equals("LOSS") ? 0xFF321212
                      : 0xFF202428;
            drawRect(ctx, cx + 2, ry + 3, 28, 10, resBg);
            ctx.drawCenteredString(font,
                Component.literal((s.result.equals("WIN") ? "§a" : s.result.equals("LOSS") ? "§c" : "§7") + s.result),
                cx + 16, ry + 5, resColor);

            // Противник
            ctx.drawString(font, Component.literal("§f" + s.opponent), cx + 34, ry + 4, TEXT_WHITE, true);

            // Режим
            ctx.drawString(font, Component.literal("§8" + s.mode), cx + 100, ry + 4, TEXT_DARK, true);

            // Урон
            ctx.drawString(font, Component.literal("§a+" + s.damageDone + "  §c-" + s.damageTaken), cx + 160, ry + 4, TEXT_WHITE, true);

            // Время
            long sec = s.durationMs / 1000;
            ctx.drawString(font, Component.literal("§8" + sec + "s"), cx + cw - 28, ry + 4, TEXT_DARK, true);

            if (hov) {
                setTooltip("Противник: " + s.opponent + "\nРежим: " + s.mode
                    + "\nUron: " + s.damageDone + "/" + s.damageTaken
                    + "\nВремя: " + sec + "s", mouseX, mouseY);
            }
        }
    }

    /** Маленькая stat карточка */
    private void renderStatCard(GuiGraphics ctx, int x, int y, int w,
                                 String label, String value, int color) {
        drawRect  (ctx, x, y, w, 32, BG_CARD);
        drawBorder(ctx, x, y, w, 32, BORDER_DEF);
        drawRect  (ctx, x, y, w, 2, color);
        ctx.drawCenteredString(font,
            Component.literal("§f" + value), x + w / 2, y + 8,  color);
        ctx.drawCenteredString(font,
            Component.literal("§8" + label), x + w / 2, y + 20, TEXT_DARK);
    }

    /** Строка с деталью статистики */
    private void renderStatDetailRow(GuiGraphics ctx, int x, int y, int w,
                                      String label, String value, int valColor) {
        drawRect  (ctx, x, y, w, 20, BG_CARD);
        drawBorder(ctx, x, y, w, 20, BORDER_DEF);
        ctx.drawString(font, Component.literal("§7" + label), x + 4, y + 3, TEXT_GRAY, true);
        ctx.drawString(font, Component.literal("§f" + value), x + w - font.width(value) - 6, y + 3, valColor, true);
    }

    /** Win/Loss горизонтальный прогресс-бар */
    private void renderWinLossBar(GuiGraphics ctx, int x, int y, int w, int wins, int losses) {
        int total = wins + losses;
        drawRect(ctx, x, y, w, 10, BG_CARD);
        if (total > 0) {
            int winW = (int)((double) wins / total * w);
            drawRect(ctx, x, y, winW, 10, ACCENT_WIN);
            drawRect(ctx, x + winW, y, w - winW, 10, ACCENT_LOSS);
        }
        drawBorder(ctx, x, y, w, 10, BORDER_DEF);
        ctx.drawString(font, Component.literal("§aW: " + wins), x + 3, y + 1, ACCENT_WIN, true);
        ctx.drawString(font, Component.literal("§cL: " + losses), x + w - font.width("L: " + losses) - 6, y + 1, ACCENT_LOSS, true);
    }

    /** Bar-chart урона по последним боям */
    private void renderDpsGraph(GuiGraphics ctx, int x, int y, int w, int h) {
        if (battleHistory.isEmpty()) return;
        int maxDmg = battleHistory.stream().mapToInt(s -> s.damageDone).max().orElse(1);
        int barW   = Math.max(4, (w - 4) / battleHistory.size() - 2);
        drawRect(ctx, x, y, w, h, BG_CARD);
        drawBorder(ctx, x, y, w, h, BORDER_DEF);
        for (int i = 0; i < battleHistory.size(); i++) {
            BattleSession s = battleHistory.get(i);
            int bh = (int)((double) s.damageDone / maxDmg * (h - 4));
            int bx = x + 2 + i * (barW + 2);
            int by = y + h - 2 - bh;
            int color = s.result.equals("WIN") ? ACCENT_WIN
                      : s.result.equals("LOSS") ? ACCENT_LOSS
                      : ACCENT_DRAW;
            drawRect(ctx, bx, by, barW, bh, color);
            if (isMouseIn(bx, by, barW, bh)) {
                setTooltip(s.opponent + ": " + s.damageDone + " dmg", mouseX, mouseY);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки SETTINGS
    // ─────────────────────────────────────────────────────────────

    private void renderSettings(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        // Заголовок секции сложности
        ctx.drawString(font, Component.literal("§7Сложность:"), cx, cy - 12, TEXT_GRAY, true);

        // Сложность
        PVPBotConfig.Difficulty[] diffs = PVPBotConfig.Difficulty.values();
        int bw = (cw - (diffs.length - 1) * 4) / diffs.length;
        for (int i = 0; i < diffs.length; i++) {
            PVPBotConfig.Difficulty d = diffs[i];
            int x   = cx + i * (bw + 4);
            boolean sel = cfg.difficulty == d;
            int brd = sel ? diffColor(d) : BORDER_DEF;
            drawRect  (ctx, x, cy, bw, 18, sel ? 0xFF1A2A1A : BG_CARD);
            drawBorder(ctx, x, cy, bw, 18, brd);
            drawRect(ctx, x, cy, bw, 2, sel ? diffColor(d) : TEXT_DARK);
            ctx.drawCenteredString(font,
                Component.literal((sel ? "§a" : "§7") + d.name()),
                x + bw / 2, cy + 5, TEXT_WHITE);
        }

        // Числовые настройки
        ctx.drawString(font, Component.literal("§7Параметры:"), cx, cy + 44, TEXT_GRAY, true);

        renderSettingRow(ctx, cx, cy + 52, cw, "Attack Range",   String.valueOf(cfg.attackRange));
        renderSettingRow(ctx, cx, cy + 70, cw, "Attack CD",      cfg.attackCooldown + " ticks");
        renderSettingRow(ctx, cx, cy + 88, cw, "Dodge Range",    String.valueOf(cfg.dodgeRange));
        renderSettingRow(ctx, cx, cy + 106, cw, "Heal HP",       String.valueOf(cfg.healThreshold));
        renderSettingRow(ctx, cx, cy + 124, cw, "Gap HP",        String.valueOf(cfg.autoGapHpThreshold));
        renderSettingRow(ctx, cx, cy + 142, cw, "Crystal Range", String.valueOf(cfg.crystalPlaceRange));
        renderSettingRow(ctx, cx, cy + 160, cw, "Crystal CD",    cfg.crystalCooldown + " ticks");
        renderSettingRow(ctx, cx, cy + 178, cw, "W-Tap Ticks",   String.valueOf(cfg.wTapReleaseTicks));
    }

    /** Одна строка числовой настройки с кнопками +/- */
    private void renderSettingRow(GuiGraphics ctx, int cx, int y, int cw,
                                   String label, String value) {
        int half = cw / 2;
        // Левая половина
        drawRect  (ctx, cx, y, half - 4, 14, BG_CARD);
        drawBorder(ctx, cx, y, half - 4, 14, BORDER_DEF);
        ctx.drawString(font, Component.literal("§7" + label), cx + 4, y + 3, TEXT_GRAY, true);

        // Правая половина — значение
        drawRect  (ctx, cx + half, y, half - 4, 14, BG_INPUT);
        drawBorder(ctx, cx + half, y, half - 4, 14, BORDER_HOV);

        // − значение + (кнопки добавлены в rebuildSettingsButtons)
        ctx.drawCenteredString(font,
            Component.literal("§f" + value),
            cx + half + (half - 4) / 2, y + 3, TEXT_WHITE);
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки ADVANCED
    // ─────────────────────────────────────────────────────────────

    private void renderAdvanced(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        ctx.drawString(font, Component.literal("§7AI / DifficultyAI параметры:"), cx, cy - 12, TEXT_GRAY, true);

        renderSettingRow(ctx, cx, cy + 0,   cw, "Predict Ticks",  String.valueOf(cfg.diffPredictTicks));
        renderSettingRow(ctx, cx, cy + 18,  cw, "Combo Length",   String.valueOf(cfg.diffComboLength));
        renderSettingRow(ctx, cx, cy + 36,  cw, "Combo Pause",    cfg.diffComboPauseTicks + " ticks");
        renderSettingRow(ctx, cx, cy + 54,  cw, "Pearl Throw",    String.valueOf(cfg.diffPearlThrowDist));
        renderSettingRow(ctx, cx, cy + 72,  cw, "Pearl CD",       cfg.diffPearlCooldown + " ticks");
        renderSettingRow(ctx, cx, cy + 90,  cw, "Bow Switch R",   String.valueOf(cfg.diffBowSwitchRange));
        renderSettingRow(ctx, cx, cy + 108, cw, "Bow CD",         cfg.diffBowCooldown + " ticks");
        renderSettingRow(ctx, cx, cy + 126, cw, "Crystal Place R",String.valueOf(cfg.diffCrystalPlaceRange));
        renderSettingRow(ctx, cx, cy + 144, cw, "Crystal AI CD",  cfg.diffCrystalCooldown + " ticks");
        renderSettingRow(ctx, cx, cy + 162, cw, "Crystal Dmg",    String.valueOf(cfg.diffCrystalDamage));
        renderSettingRow(ctx, cx, cy + 180, cw, "ESP Range",      String.valueOf(cfg.espRange));
        renderSettingRow(ctx, cx, cy + 198, cw, "Radar Range",    String.valueOf(cfg.radarRange));
        renderSettingRow(ctx, cx, cy + 216, cw, "Hunt Range",     String.valueOf(cfg.huntRange));
        renderSettingRow(ctx, cx, cy + 234, cw, "Bunker HP",      String.valueOf(cfg.bunkerHpThreshold));

        // Boolean флаги
        ctx.drawString(font, Component.literal("§7Флаги:"), cx, cy + 252, TEXT_GRAY, true);

        renderBoolBadge(ctx, cx,       cy + 264, "Use Pearls",   cfg.diffUsePearls);
        renderBoolBadge(ctx, cx + 130, cy + 264, "Use Crystals", cfg.diffUseCrystals);
        renderBoolBadge(ctx, cx + 268, cy + 264, "Adv. Path",    cfg.advPathfind);
    }

    /** Маленький бейдж-индикатор булевого значения */
    private void renderBoolBadge(GuiGraphics ctx, int x, int y, String label, boolean val) {
        int bg  = val ? ENABLED_BG  : DISABLED_BG;
        int brd = val ? BORDER_SEL  : BORDER_RED;
        drawRect  (ctx, x, y, 120, 12, bg);
        drawBorder(ctx, x, y, 120, 12, brd);
        ctx.drawString(font,
            Component.literal((val ? "§a✔ " : "§c✘ ") + "§7" + label),
            x + 4, y + 2, TEXT_WHITE, true);
    }

    // ─────────────────────────────────────────────────────────────
    //  Рендер вкладки WHITELIST
    // ─────────────────────────────────────────────────────────────

    private void renderWhitelist(GuiGraphics ctx, int cx, int cy, int cw, int areaH) {
        // Статус
        String statusStr = cfg.whitelistEnabled ? "§aВКЛЮЧЁН" : "§cВЫКЛЮЧЕН";
        ctx.drawString(font,
            Component.literal("§7Вайтлист: " + statusStr + "  §8[" + cfg.whitelist.size() + " игроков]"),
            cx, cy - 14, TEXT_GRAY, true);

        // Поле ввода
        int inputW = cw - 58;
        boolean focused = whitelistInputFocused;
        drawRect  (ctx, cx, cy, inputW, 14, BG_INPUT);
        drawBorder(ctx, cx, cy, inputW, 14, focused ? BORDER_SEL : BORDER_DEF);
        String displayInput = whitelistInput.isEmpty() ? "§8Введите ник..." : "§f" + whitelistInput;
        if (focused) displayInput += "§f|";
        ctx.drawString(font, Component.literal(displayInput), cx + 4, cy + 3, TEXT_WHITE, true);

        // Список игроков
        int listY = cy + 24;
        ctx.drawString(font, Component.literal("§7Список:"), cx, listY - 12, TEXT_GRAY, true);

        if (cfg.whitelist.isEmpty()) {
            ctx.drawCenteredString(font,
                Component.literal("§8Список пуст. Добавьте игроков выше."),
                cx + cw / 2, listY + 24, TEXT_DARK);
        } else {
            for (int i = 0; i < cfg.whitelist.size(); i++) {
                String player = cfg.whitelist.get(i);
                int rowY = listY + i * 16 - scrollOffset;
                if (rowY < cy + 18 || rowY > cy + areaH) continue;

                boolean hov = mouseX >= cx && mouseX < cx + cw - 24
                           && mouseY >= rowY && mouseY < rowY + 14;
                drawRect  (ctx, cx, rowY, cw - 24, 13, hov ? BG_CARD_HOV : BG_CARD);
                drawBorder(ctx, cx, rowY, cw - 24, 13, hov ? BORDER_HOV  : BORDER_DEF);

                ctx.drawString(font,
                    Component.literal("§7" + (i + 1) + ". §f" + player),
                    cx + 6, rowY + 3, TEXT_WHITE, true);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  TOOLTIP
    // ═══════════════════════════════════════════════════════════════

    private void setTooltip(String text, int x, int y) {
        this.tooltipText = text;
        this.tooltipX    = x;
        this.tooltipY    = y;
    }

    private void renderTooltip(GuiGraphics ctx, String text, int x, int y) {
        String[] lines = text.split("\n");
        int maxW = 0;
        for (String line : lines) {
            int w = font.width(line);
            if (w > maxW) maxW = w;
        }
        int tw = maxW + 10;
        int th = lines.length * 11 + 6;

        // Не вылезать за правый край
        if (x + tw + 12 > winX + winW) x = winX + winW - tw - 12;
        if (y + th + 12 > winY + winH) y = winY + winH - th - 12;

        int tx = x + 10;
        int ty = y - th - 4;
        if (ty < winY + 4) ty = y + 14;

        drawRect  (ctx, tx, ty, tw, th, BG_TOOLTIP);
        drawBorder(ctx, tx, ty, tw, th, BORDER_TOOLTIP);

        for (int i = 0; i < lines.length; i++) {
            ctx.drawString(font, Component.literal("§7" + lines[i]), tx + 5, ty + 4 + i * 11, TEXT_GRAY, true);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  ВСПОМОГАТЕЛЬНЫЕ РИСОВАЛКИ
    // ═══════════════════════════════════════════════════════════════

    private void drawRect(GuiGraphics ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    private void drawBorder(GuiGraphics ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x,         y,         x + w,     y + 1,     color);
        ctx.fill(x,         y + h - 1, x + w,     y + h,     color);
        ctx.fill(x,         y,         x + 1,     y + h,     color);
        ctx.fill(x + w - 1, y,         x + w,     y + h,     color);
    }

    /** Мягкая тень под окном */
    private void drawShadow(GuiGraphics ctx, int x, int y, int w, int h) {
        int[] alphas = { 0x50, 0x35, 0x20, 0x10, 0x06 };
        for (int i = 0; i < alphas.length; i++) {
            int a = alphas[i];
            int color = (a << 24);
            ctx.fill(x - i, y + i, x + w + i, y + h + i, color);
        }
    }

    private boolean isMouseIn(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    // ═══════════════════════════════════════════════════════════════
    //  СКРОЛЛ И ВВОД
    // ═══════════════════════════════════════════════════════════════

    @Override
    public boolean mouseScrolled(double mx, double my, double hScroll, double vScroll) {
        scrollOffset -= (int)(vScroll * 16);
        if (scrollOffset < 0) scrollOffset = 0;
        rebuildButtons();
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Проверка клика по полю поиска (MODULES)
        if (currentTab == Tab.MODULES) {
            int cx = winX + 10;
            int cy = winY + CONTENT_Y_OFFSET - 16;
            int cw = winW - 20;
            if (mx >= cx && mx < cx + cw && my >= cy && my < cy + 13) {
                whitelistInputFocused = true;
                return true;
            } else {
                whitelistInputFocused = false;
            }
        }
        // Поле ввода вайтлиста
        if (currentTab == Tab.WHITELIST) {
            int cx = winX + 10;
            int cy = winY + CONTENT_Y_OFFSET;
            int cw = winW - 20;
            int inputW = cw - 58;
            if (mx >= cx && mx < cx + inputW && my >= cy && my < cy + 14) {
                whitelistInputFocused = true;
                return true;
            } else {
                whitelistInputFocused = false;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (whitelistInputFocused) {
            if (keyCode == 259) { // Backspace
                if (!whitelistInput.isEmpty())
                    whitelistInput = whitelistInput.substring(0, whitelistInput.length() - 1);
                if (currentTab == Tab.MODULES) searchQuery = whitelistInput;
                rebuildButtons();
                return true;
            }
            if (keyCode == 256) { // Escape
                whitelistInputFocused = false;
                return true;
            }
            if (keyCode == 257 && currentTab == Tab.WHITELIST) { // Enter
                String name = whitelistInput.trim();
                if (!name.isEmpty() && !cfg.whitelist.contains(name)) {
                    cfg.whitelist.add(name);
                    BotConfig.save();
                }
                whitelistInput = "";
                rebuildButtons();
                return true;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (whitelistInputFocused && chr >= 32) {
            if (currentTab == Tab.WHITELIST && whitelistInput.length() < 24) {
                whitelistInput += chr;
                rebuildButtons();
                return true;
            }
            if (currentTab == Tab.MODULES) {
                searchQuery += chr;
                rebuildButtons();
                return true;
            }
        }
        return super.charTyped(chr, modifiers);
    }

    // ═══════════════════════════════════════════════════════════════
    //  РЕФЛЕКСИЯ ДЛЯ КОНФИГА
    // ═══════════════════════════════════════════════════════════════

    private boolean getField(String name) {
        try {
            return (boolean) PVPBotConfig.class.getField(name).get(cfg);
        } catch (Exception e) { return false; }
    }

    private void toggleField(String name) {
        try {
            var f = PVPBotConfig.class.getField(name);
            f.set(cfg, !(boolean) f.get(cfg));
        } catch (Exception ignored) {}
    }

    private void adjustDoubleField(String name, double delta, double min, double max) {
        try {
            var f = PVPBotConfig.class.getField(name);
            Object val = f.get(cfg);
            double cur;
            if (val instanceof Double)  cur = (Double) val;
            else if (val instanceof Float) cur = (Float) val;
            else if (val instanceof Integer) cur = (Integer) val;
            else return;

            double next = Math.max(min, Math.min(max, cur + delta));

            if (val instanceof Double)  f.set(cfg, next);
            else if (val instanceof Float) f.set(cfg, (float) next);
            else if (val instanceof Integer) f.set(cfg, (int) Math.round(next));
        } catch (Exception ignored) {}
    }

    // ═══════════════════════════════════════════════════════════════
    //  ПРИМЕНИТЬ КИТ
    // ═══════════════════════════════════════════════════════════════

    private void applyKit(BotKit kit) {
        try {
            cfg.mode = PVPBotConfig.Mode.valueOf(kit.name());
        } catch (IllegalArgumentException e) {
            cfg.mode = PVPBotConfig.Mode.SWORD;
        }
        BotConfig.save();
    }

    // ═══════════════════════════════════════════════════════════════
    //  ИКОНКИ, ЦВЕТА, ОПИСАНИЯ КИТОВ
    // ═══════════════════════════════════════════════════════════════

    private String kitIcon(BotKit kit) {
        return switch (kit) {
            case SWORD       -> "⚔";
            case CRYSTAL     -> "💎";
            case SMP         -> "🛡";
            case UHC         -> "🏹";
            case NETHPOT     -> "🧪";
            case AXE         -> "🪓";
            case TPC         -> "🔮";
            case MACE        -> "🔨";
            case MACE_ELYTRA -> "🦅";
            case BEEHIVE     -> "🐝";
            case FIREWORK    -> "🎆";
            case CROSSBOW    -> "🏹";
            case TRIDENT     -> "🔱";
            default          -> "?";
        };
    }

    private String kitShortDesc(BotKit kit) {
        return switch (kit) {
            case SWORD       -> "Netherite меч";
            case CRYSTAL     -> "End Crystal";
            case SMP         -> "Diamond + Shield";
            case UHC         -> "No regen + Bow";
            case NETHPOT     -> "Potion PvP";
            case AXE         -> "Netherite Axe";
            case TPC         -> "Axe + Totem";
            case MACE        -> "Mace 1.21+";
            case MACE_ELYTRA -> "Dive + Smash";
            case BEEHIVE     -> "Bees + Honey";
            case FIREWORK    -> "Rockets + Elytra";
            case CROSSBOW    -> "Burst Fire";
            case TRIDENT     -> "Lightning";
            default          -> "";
        };
    }

    private String kitTag(BotKit kit) {
        return switch (kit) {
            case SWORD, AXE  -> "§eMELEE";
            case CRYSTAL, TPC -> "§bCRYSTAL";
            case SMP         -> "§aSURVIVAL";
            case UHC         -> "§cHARDCORE";
            case NETHPOT     -> "§dPOTION";
            case MACE, MACE_ELYTRA -> "§6MACE";
            case BEEHIVE     -> "§eNATURE";
            case FIREWORK, CROSSBOW -> "§aRANGED";
            case TRIDENT     -> "§bTRIDENT";
            default          -> "§7MISC";
        };
    }

    private int kitTagColor(BotKit kit) {
        return switch (kit) {
            case SWORD, AXE  -> ACCENT_YELLOW;
            case CRYSTAL, TPC, TRIDENT -> ACCENT_CYAN;
            case SMP         -> ACCENT_GREEN;
            case UHC         -> ACCENT_RED;
            case NETHPOT     -> ACCENT_PURPLE;
            case MACE, MACE_ELYTRA -> ACCENT_ORANGE;
            case BEEHIVE     -> ACCENT_YELLOW;
            default          -> TEXT_GRAY;
        };
    }

    private String kitTooltip(BotKit kit) {
        return switch (kit) {
            case SWORD       -> "Стандартный ближний бой.\nNetherite меч + полный нетерит.";
            case CRYSTAL     -> "Crystal PvP.\nEnd Crystal + Netherite броня.";
            case SMP         -> "Выживач стиль.\nAlmaz + Щит.";
            case UHC         -> "UHC — без регенерации.\nМеч + лук + золотые яблоки.";
            case NETHPOT     -> "Potion PvP.\nЖелезная броня + зелья.";
            case AXE         -> "Axe PvP.\nNetherite топор + щит.";
            case TPC         -> "Totem-Pot-Crystal.\nТопор + тотем + кристаллы.";
            case MACE        -> "Mace PvP (1.21+).\nБулава + тотем.";
            case MACE_ELYTRA -> "Dive-Smash комбо.\nЭлитры + булава.";
            case BEEHIVE     -> "Пчелиный PvP.\nПчёлы + медовые бутылки.";
            case FIREWORK    -> "Фейерверки + элитры.\nМобильный PvP.";
            case CROSSBOW    -> "Арбалет burst-огонь.\nФейерверки как снаряды.";
            case TRIDENT     -> "Трезубец.\nChanneling молния + Riptide рывок.";
            default          -> kit.name();
        };
    }

    private int kitStripeColor(BotKit kit) {
        return switch (kit) {
            case SWORD       -> 0xFFC0A050;
            case CRYSTAL     -> 0xFF00CFFF;
            case SMP         -> 0xFF4ADE80;
            case UHC         -> 0xFFFACC15;
            case NETHPOT     -> 0xFFA855F7;
            case AXE         -> 0xFFFB923C;
            case TPC         -> 0xFFE879F9;
            case MACE        -> 0xFFF97316;
            case MACE_ELYTRA -> 0xFF38BDF8;
            case BEEHIVE     -> 0xFFFBBF24;
            case FIREWORK    -> 0xFFF43F5E;
            case CROSSBOW    -> 0xFF84CC16;
            case TRIDENT     -> 0xFF06B6D4;
            default          -> 0xFF888888;
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //  ИКОНКИ, ЦВЕТА, ОПИСАНИЯ РЕЖИМОВ
    // ═══════════════════════════════════════════════════════════════

    private String modeIcon(PVPBotConfig.Mode mode) {
        return switch (mode) {
            case SWORD       -> "⚔";
            case CRYSTAL     -> "💎";
            case SMP         -> "🏠";
            case UHC         -> "💀";
            case NETHPOT     -> "🧪";
            case AXE         -> "🪓";
            case TPC         -> "🔮";
            case MACE        -> "🔨";
            case BEEHIVE     -> "🐝";
            case FIREWORK    -> "🎆";
            case CROSSBOW    -> "🏹";
            case MACE_ELYTRA -> "🦅";
            case TRIDENT     -> "🔱";
            case TOTEM       -> "🗿";
            case SNOWBALL    -> "❄";
            default          -> "?";
        };
    }

    private String modeShortDesc(PVPBotConfig.Mode mode) {
        return switch (mode) {
            case SWORD       -> "Классический меч";
            case CRYSTAL     -> "Crystal PvP";
            case SMP         -> "Выживач стиль";
            case UHC         -> "Без регенерации";
            case NETHPOT     -> "Зелья";
            case AXE         -> "Axe PvP";
            case TPC         -> "Totem-Pot-Crystal";
            case MACE        -> "Булава 1.21+";
            case BEEHIVE     -> "Пчёлы";
            case FIREWORK    -> "Фейерверки";
            case CROSSBOW    -> "Арбалет";
            case MACE_ELYTRA -> "Пикирование";
            case TRIDENT     -> "Трезубец";
            case TOTEM       -> "Тотем";
            case SNOWBALL    -> "Снежки";
            default          -> "";
        };
    }

    private int modeStripeColor(PVPBotConfig.Mode mode) {
        return switch (mode) {
            case CRYSTAL, TPC     -> 0xFF00CFFF;
            case SMP              -> 0xFF4ADE80;
            case UHC              -> 0xFFDC2626;
            case NETHPOT          -> 0xFFA855F7;
            case AXE              -> 0xFFFB923C;
            case MACE, MACE_ELYTRA -> 0xFFF97316;
            case SNOWBALL         -> 0xFF94A3B8;
            case TOTEM            -> 0xFFFB923C;
            case TRIDENT          -> 0xFF06B6D4;
            case BEEHIVE          -> 0xFFFBBF24;
            case FIREWORK         -> 0xFFF43F5E;
            case CROSSBOW         -> 0xFF84CC16;
            default               -> 0xFFC0A050;
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //  ЦВЕТА СЛОЖНОСТИ
    // ═══════════════════════════════════════════════════════════════

    private int diffColor(PVPBotConfig.Difficulty d) {
        return switch (d) {
            case EASY   -> 0xFF4ADE80;
            case MEDIUM -> 0xFFFACC15;
            case HARD   -> 0xFFF87171;
            case EXPERT -> 0xFFDC2626;
        };
    }

    private String diffColorStr(PVPBotConfig.Difficulty d) {
        return switch (d) {
            case EASY   -> "§a";
            case MEDIUM -> "§e";
            case HARD   -> "§c";
            case EXPERT -> "§4";
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //  УПРАВЛЕНИЕ ОКНОМ
    // ═══════════════════════════════════════════════════════════════

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        BotConfig.save();
        super.onClose();
    }
}
