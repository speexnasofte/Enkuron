package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/**
 * SmpLogic — логика SMP (выживач) режима.
 *
 * SMP особенности:
 *   - Алмазная броня + щит (блокирование входящего урона)
 *   - Едим еду (хлеб → золотое яблоко при экстреме)
 *   - Щит поднимается при получении урона с проджектайлов
 *   - Авто-блок при атаке противника топором (снимает щит — бот отступает)
 *   - Атака мечом с правильным кулдауном (1.9 CPS)
 *   - Стрейф влево-вправо во время боя
 *
 * Поведение:
 *   FIGHTING  → основной бой: стрейф, удар, блок
 *   BLOCKING  → щит поднят (получаем урон)
 *   EATING    → едим еду при < 16 сытости
 *   RETREATING→ отступаем при < 6 HP
 */
public class SmpLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double MELEE_RANGE     = 3.0;
    private static final double RETREAT_DIST    = 8.0;
    private static final float  SHIELD_UP_HP    = 14.0f;  // HP при котором щит поднимаем
    private static final float  EAT_HP_THRESH   = 14.0f;  // HP ниже которого едим
    private static final float  RETREAT_HP      = 6.0f;
    private static final int    ATTACK_CD_TICKS = 12;     // ~0.8 атак/сек (1.9 PvP)
    private static final int    SHIELD_BLOCK_DUR= 25;     // тиков блокирования
    private static final int    STRAFE_FLIP     = 20;
    private static final int    EAT_DURATION    = 32;     // тиков поедания
    private static final int    RETREAT_CD      = 120;

    private enum SmpState { FIGHTING, BLOCKING, EATING, RETREATING }
    private SmpState state = SmpState.FIGHTING;

    private final BotEntity bot;

    private int attackCd    = 0;
    private int shieldTimer = 0;
    private int strafeTimer = 0;
    private int strafeDir   = 1;
    private int eatTimer    = 0;
    private int retreatCd   = 0;
    private float lastHp    = -1;

    public SmpLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { state = SmpState.FIGHTING; return; }

        // Кулдауны
        if (attackCd    > 0) attackCd--;
        if (shieldTimer > 0) shieldTimer--;
        if (strafeTimer > 0) strafeTimer--;
        if (eatTimer    > 0) eatTimer--;
        if (retreatCd   > 0) retreatCd--;

        float myHp = bot.getHealth();
        double dist = bot.distanceTo(target);

        // ── Детекция получения урона → поднять щит ────────────────
        if (lastHp >= 0 && myHp < lastHp) {
            shieldTimer = SHIELD_BLOCK_DUR;
            if (state != SmpState.EATING && state != SmpState.RETREATING) {
                state = SmpState.BLOCKING;
            }
        }
        lastHp = myHp;

        // ── Приоритет: отступление ────────────────────────────────
        if (myHp < RETREAT_HP && retreatCd <= 0) {
            state = SmpState.RETREATING;
        }

        // ── Приоритет: еда ────────────────────────────────────────
        if (myHp < EAT_HP_THRESH && eatTimer <= 0 && state != SmpState.RETREATING) {
            state = SmpState.EATING;
            eatTimer = EAT_DURATION;
        }

        switch (state) {
            case FIGHTING   -> doFighting(sw, target, dist);
            case BLOCKING   -> doBlocking(sw, target, dist);
            case EATING     -> doEating(sw);
            case RETREATING -> doRetreating(sw, target);
        }
    }

    // ── FIGHTING: стрейф + удар ───────────────────────────────────
    private void doFighting(ServerLevel sw, LivingEntity target, double dist) {
        equipSword();
        lowerShield();

        // Стрейф
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = STRAFE_FLIP + bot.level().getRandom().nextInt(10);
        }
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        Vec3 strafe   = new Vec3(-toTarget.z * strafeDir, 0, toTarget.x * strafeDir);
        bot.setDeltaMovement(bot.getDeltaMovement().add(strafe.scale(0.12)));

        // Приближаемся если далеко
        if (dist > MELEE_RANGE) {
            Vec3 dir = toTarget.scale(0.15);
            bot.setDeltaMovement(bot.getDeltaMovement().add(dir));
        }

        // Удар
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            bot.doHurtTarget((net.minecraft.server.level.ServerLevel)bot.level(), target);
            attackCd = ATTACK_CD_TICKS;
        }
    }

    // ── BLOCKING: держим щит ──────────────────────────────────────
    private void doBlocking(ServerLevel sw, LivingEntity target, double dist) {
        equipShield();

        // Отступаем назад пока блокируем
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.1);
        bot.setDeltaMovement(bot.getDeltaMovement().add(away));

        // Смотрит ли цель на нас (атакует ли топором)?
        boolean targetHasAxe = target.getMainHandItem().is(Items.DIAMOND_AXE)
                            || target.getMainHandItem().is(Items.NETHERITE_AXE);
        if (targetHasAxe) {
            // Топор снимет щит — лучше отступить и не блокировать
            lowerShield();
            Vec3 flee = bot.position().subtract(target.position()).normalize().scale(0.3);
            bot.setDeltaMovement(bot.getDeltaMovement().add(flee.x, 0.2, flee.z));
        }

        if (shieldTimer <= 0) {
            state = SmpState.FIGHTING;
        }
    }

    // ── EATING: регенерация едой ──────────────────────────────────
    private void doEating(ServerLevel sw) {
        if (eatTimer <= 0) {
            // Применяем регенерацию (симуляция поедания хлеба/яблока)
            float heal = (bot.getHealth() < 4.0f) ? 4.0f : 2.0f;
            bot.heal(heal);

            // При экстреме — golden apple (Absorption + Regen)
            if (bot.getHealth() < 6.0f) {
                bot.addEffect(new MobEffectInstance(
                    MobEffects.REGENERATION, 100, 1));
                bot.addEffect(new MobEffectInstance(
                    MobEffects.ABSORPTION, 400, 0));
            }
            state = SmpState.FIGHTING;
        }
    }

    // ── RETREATING: отступаем и лечимся ──────────────────────────
    private void doRetreating(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.setDeltaMovement(bot.getDeltaMovement().add(away.scale(0.35)));

        // Лечимся пока убегаем
        if (bot.getHealth() < 10.0f) {
            bot.heal(0.5f); // медленный рег
        }

        if (bot.distanceTo(target) > RETREAT_DIST || bot.getHealth() > SHIELD_UP_HP) {
            retreatCd = 80;
            state     = SmpState.FIGHTING;
        }
    }

    private void equipSword() {
        ItemStack cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!cur.is(Items.DIAMOND_SWORD))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
    }

    private void equipShield() {
        ItemStack off = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (!off.is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    private void lowerShield() {
        // Щит в оффхенде остаётся, просто не блокируем (не нужно убирать)
    }
}
