package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * MaceElytraLogic — v14: режим MACE_ELYTRA (Булава + Элитра комбо).
 *
 * ═══════════════════════════════════════════════════════════════════
 *  МЕХАНИКА КОМБО:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Фаза 1 — ASCEND (Набор высоты):
 *    Бот надевает элитры и запускает фейерверк-ускоритель,
 *    набирая высоту ASCEND_HEIGHT блоков над целью.
 *    Фейерверк даёт горизонтальный+вертикальный импульс.
 *
 *  Фаза 2 — GLIDE_AIM (Пикирование):
 *    Бот переходит в скользящий полёт на элитрах,
 *    направляя вектор скорости прямо в цель.
 *    Скорость нарастает при снижении (гравитация помогает).
 *
 *  Фаза 3 — DIVE_SMASH (Удар):
 *    При сближении с целью бот меняет элитры на нагруднике
 *    обратно (опционально) и наносит удар булавой.
 *    Урон = базовый + бонус за скорость полёта (velocity.length()).
 *    Это сильнее чем обычный Mace — скорость элитры > прыжка.
 *
 *  Фаза 4 — COOLDOWN (Откат):
 *    Бот приземляется/снижается, надевает элитры снова,
 *    ждёт кулдаун, затем повторяет.
 *
 * ═══════════════════════════════════════════════════════════════════
 *  ПАРАМЕТРЫ УРОНА:
 * ═══════════════════════════════════════════════════════════════════
 *  При скорости элитры ~1.5 блок/тик:
 *    8 (base) + 1.5 * 6.0 (скорость) = 17 урона
 *  При скорости ~2.5 (крутое пикирование):
 *    8 + 2.5 * 6.0 = 23 урона (кап 28)
 *
 *  Для сравнения: обычный MaceLogic при JUMP_HEIGHT=3.5:
 *    8 + 3.5 * 1.5 = 13.25 урона
 *
 * ═══════════════════════════════════════════════════════════════════
 *  КОМАНДЫ:
 * ═══════════════════════════════════════════════════════════════════
 *  /bot mode mace_elytra   — активировать режим
 *  /bot kit mace_elytra    — выдать снаряжение
 *
 * ═══════════════════════════════════════════════════════════════════
 */
public class MaceElytraLogic {

    // ── Константы ─────────────────────────────────────────────────
    /** Высота набора над целью перед пикированием (блоки) */
    private static final double ASCEND_HEIGHT        = 12.0;
    /** Дистанция атаки при пикировании */
    private static final double SMASH_DIST           = 3.5;
    /** Кулдаун между атаками (тики) */
    private static final int    FULL_COOLDOWN        = 50;
    /** Тики между фейерверками при подъёме */
    private static final int    FIREWORK_INTERVAL    = 20;
    /** Макс. число фейерверков на один подъём */
    private static final int    MAX_FIREWORKS        = 2;
    /** Базовый урон булавы */
    private static final float  BASE_DAMAGE          = 8.0f;
    /** Множитель урона за скорость полёта */
    private static final float  VELOCITY_DMG_MULT    = 6.0f;
    /** Кап урона */
    private static final float  MAX_DAMAGE           = 28.0f;
    /** Горизонтальная дистанция — когда начинать пикирование */
    private static final double DIVE_START_H_DIST    = 8.0;

    // ── Состояния ─────────────────────────────────────────────────
    private enum Phase {
        IDLE,       // ожидание
        ASCEND,     // набор высоты на элитрах + фейерверки
        GLIDE_AIM,  // пикирование — разгон к цели
        DIVE_SMASH, // удар булавой
        COOLDOWN    // откат
    }

    private Phase phase           = Phase.IDLE;
    private int   cooldownTimer   = 0;
    private int   fireworkTimer   = 0;
    private int   fireworksUsed   = 0;
    private int   diveTimeout     = 0;  // защита от зависания в GLIDE_AIM
    private double speedAtHit     = 0;  // скорость в момент удара (для лога)

    private final BotEntity bot;

    public MaceElytraLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) {
            phase = Phase.IDLE;
            return;
        }

        // Тикаем кулдауны
        if (cooldownTimer > 0) cooldownTimer--;
        if (fireworkTimer > 0) fireworkTimer--;

        switch (phase) {
            case IDLE       -> tickIdle(target);
            case ASCEND     -> tickAscend(sw, target);
            case GLIDE_AIM  -> tickGlideAim(sw, target);
            case DIVE_SMASH -> tickDiveSmash(sw, target);
            case COOLDOWN   -> tickCooldown();
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  IDLE — ждём готовности, экипируемся
    // ──────────────────────────────────────────────────────────────
    private void tickIdle(LivingEntity target) {
        if (cooldownTimer > 0) return;

        equipElytraKit();

        double dist = bot.distanceTo(target);

        // Если цель далеко — подбегаем сначала
        if (dist > 20.0) {
            bot.getNavigation().moveTo(target, 1.3);
            return;
        }

        // Начинаем подъём
        phase        = Phase.ASCEND;
        fireworksUsed = 0;
        fireworkTimer = 0;

        bot.getNavigation().stop();
    }

    // ──────────────────────────────────────────────────────────────
    //  ASCEND — подъём на фейерверках
    // ──────────────────────────────────────────────────────────────
    private void tickAscend(ServerLevel sw, LivingEntity target) {
        equipElytraKit();

        double targetY  = target.getY() + ASCEND_HEIGHT;
        double currentY = bot.getY();
        double heightLeft = targetY - currentY;

        // ── Запускаем фейерверк для тяги ──────────────────────────
        if (fireworkTimer <= 0 && fireworksUsed < MAX_FIREWORKS && heightLeft > 2.0) {
            launchAscendFirework(sw);
            fireworkTimer = FIREWORK_INTERVAL;
            fireworksUsed++;
        }

        // ── Вектор вверх-к-цели ───────────────────────────────────
        if (currentY < targetY - 0.5) {
            Vec3 vel    = bot.getDeltaMovement();
            Vec3 toCenterXZ = new Vec3(
                target.getX() - bot.getX(), 0, target.getZ() - bot.getZ()
            ).normalize().scale(0.3);
            // Добавляем вертикальную скорость только если элитры активны
            bot.setDeltaMovement(vel.x + toCenterXZ.x, Math.max(vel.y, 0.25), vel.z + toCenterXZ.z);
        } else {
            // Высота достигнута — переходим в пикирование
            phase       = Phase.GLIDE_AIM;
            diveTimeout = 120; // 6 секунд максимум
        }

        // ── Частицы ───────────────────────────────────────────────
        if (bot.tickCount % 5 == 0) {
            sw.sendParticles(ParticleTypes.CLOUD,
                bot.getX(), bot.getY(), bot.getZ(), 3, 0.2, 0.1, 0.2, 0.05);
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  GLIDE_AIM — пикирование на цель
    // ──────────────────────────────────────────────────────────────
    private void tickGlideAim(ServerLevel sw, LivingEntity target) {
        diveTimeout--;

        // Таймаут — что-то пошло не так, сбрасываем
        if (diveTimeout <= 0) {
            phase         = Phase.COOLDOWN;
            cooldownTimer = FULL_COOLDOWN / 2;
            return;
        }

        double dist = bot.distanceTo(target);

        // ── Вектор прямо в голову цели ────────────────────────────
        Vec3 toTarget = target.getEyePosition().subtract(bot.position()).normalize();

        // При элитра-полёте управляем через velocity напрямую:
        // Добавляем импульс в сторону цели постепенно
        Vec3 vel = bot.getDeltaMovement();
        double speed = vel.length();

        // Если скорость упала — даём небольшой толчок
        if (speed < 0.8 && diveTimeout < 100) {
            bot.setDeltaMovement(
                vel.x + toTarget.x * 0.4,
                vel.y + toTarget.y * 0.4 - 0.1, // гравитация помогает
                vel.z + toTarget.z * 0.4
            );
        }

        // Направляем взгляд на цель
        bot.getLookControl().setLookAt(target, 180, 80);

        // ── Удар при сближении ────────────────────────────────────
        if (dist <= SMASH_DIST) {
            // Меняем элитры на нагрудник булавы (нетерит) перед ударом
            equipChestForSmash();
            phase = Phase.DIVE_SMASH;
            tickDiveSmash(sw, target);
            return;
        }

        // Если залетели мимо и приземлились — переходим в откат
        if (bot.onGround() && diveTimeout < 80) {
            phase         = Phase.COOLDOWN;
            cooldownTimer = FULL_COOLDOWN;
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  DIVE_SMASH — удар булавой
    // ──────────────────────────────────────────────────────────────
    private void tickDiveSmash(ServerLevel sw, LivingEntity target) {
        // Берём текущую скорость — это наш бонус за пикирование
        Vec3 vel   = bot.getDeltaMovement();
        speedAtHit  = vel.length();

        float damage = BASE_DAMAGE + (float)(speedAtHit * VELOCITY_DMG_MULT);
        damage = Math.min(damage, MAX_DAMAGE);

        // Экипируем булаву
        equipMace();

        // Наносим урон
        target.hurt(sw.damageSources().playerAttack(null), damage);

        // ── Knockback: сильнее чем у обычного mace ────────────────
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        target.setDeltaMovement(
            kb.x * 2.0,
            1.5,          // очень сильный отброс вверх
            kb.z * 2.0
        );

        // ── Эффекты ───────────────────────────────────────────────
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(),
            20, 0.6, 0.6, 0.6, 0.3);
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
            bot.getX(), bot.getY() + 0.5, bot.getZ(),
            8, 0.5, 0.3, 0.5, 0.1);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.8f);
        bot.playSound(SoundEvents.GENERIC_EXPLODE.value(), 0.5f, 1.5f);

        // ── Тормозим бота после удара ─────────────────────────────
        bot.setDeltaMovement(bot.getDeltaMovement().multiply(0.15, 0.05, 0.15));

        // ── Сообщение в чат ───────────────────────────────────────
        notifyOwner(String.format(
            "§6[MaceElytra] §cSmash! §e%.1f dmg §7(speed: %.2f)",
            damage, speedAtHit
        ));

        // Переходим в откат, надеваем элитры обратно
        equipElytraKit();
        phase         = Phase.COOLDOWN;
        cooldownTimer = FULL_COOLDOWN;
    }

    // ──────────────────────────────────────────────────────────────
    //  COOLDOWN — ждём
    // ──────────────────────────────────────────────────────────────
    private void tickCooldown() {
        if (cooldownTimer <= 0) {
            phase = Phase.IDLE;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные методы
    // ══════════════════════════════════════════════════════════════

    /**
     * Запускает фейерверк-ускоритель вверх для набора высоты.
     */
    private void launchAscendFirework(ServerLevel sw) {
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);

        FireworkRocketEntity firework = new FireworkRocketEntity(
            sw, bot,
            bot.getX(), bot.getY(), bot.getZ(),
            rocket
        );
        // Направляем вверх с небольшим углом к цели
        firework.setDeltaMovement(0, 1.8, 0);
        sw.addFreshEntity(firework);

        sw.sendParticles(ParticleTypes.FIREWORK,
            bot.getX(), bot.getY() - 0.5, bot.getZ(),
            8, 0.3, 0.1, 0.3, 0.2);
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
    }

    /**
     * Надеваем полный кит: элитры в нагрудник, булава в руку.
     */
    private void equipElytraKit() {
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        // Тотем в оффхенд
        if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty())
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        // Булава в руку — меняем на неё только если нет
        equipMace();
    }

    /** Экипировать нагрудник нетерит перед ударом (вместо элитры). */
    private void equipChestForSmash() {
        bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
    }

    /** Экипировать булаву в основную руку. */
    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
    }

    /** Отправляем уведомление владельцу бота. */
    private void notifyOwner(String message) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer owner) {
            owner.sendSystemMessage(net.minecraft.network.chat.Component.literal(message));
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  API для HUD / Dispatcher
    // ══════════════════════════════════════════════════════════════

    /** Метка текущей фазы для HUD. */
    public String getStateLabel() {
        return switch (phase) {
            case IDLE       -> "ME:IDLE";
            case ASCEND     -> "ME:ASCEND";
            case GLIDE_AIM  -> "ME:DIVE";
            case DIVE_SMASH -> "ME:SMASH!";
            case COOLDOWN   -> "ME:CD";
        };
    }

    /** Последняя скорость в момент удара — для HUD/DPS. */
    public double getLastHitSpeed() { return speedAtHit; }

    /** Бот сейчас в активной атаке (не переключать оружие). */
    public boolean isActive() {
        return phase == Phase.GLIDE_AIM || phase == Phase.DIVE_SMASH;
    }
}
