# Kit Icons / Иконки китов

Положи PNG-файлы иконок сюда:
`assets/pvpbot/textures/gui/icons/`

## Иконки китов MCTiers

| Файл                | Кит             | Описание                        |
|---------------------|-----------------|---------------------------------|
| `kit_sword.png`     | Sword PvP       | Синий меч (как на mctiers.com)  |
| `kit_axe.png`       | Axe PvP         | Серый топор                     |
| `kit_mace.png`      | Mace PvP        | Серая булава                    |
| `kit_uhc.png`       | UHC             | Красное сердце                  |
| `kit_pot.png`       | Diamond Pot     | Фиолетовое зелье                |
| `kit_nethop.png`    | NethOP          | Зелёная сфера / шлем            |
| `kit_smp.png`       | SMP             | SMP иконка                      |
| `kit_crystal.png`   | Crystal PvP     | End Crystal                     |
| `kit_ltm.png`       | LTMs            | Скрещенные мечи                 |
| `kit_vanilla.png`   | Vanilla         | Ванильное сердце                |
| `kit_nethpot.png`   | NethPot         | Зелье                           |
| `kit_tpc.png`       | TPC             | Топор + кристалл                |
| `kit_snowball.png`  | Snowball        | Снежок                          |
| `kit_trident.png`   | Trident         | Трезубец                        |
| `kit_crossbow.png`  | Crossbow        | Арбалет                         |
| `kit_elytra.png`    | Elytra + Mace   | Элитра                          |

## Размер

Рекомендуемый размер PNG: **16×16** или **32×32** пикселей.

## Если PNG нет

`IconRenderer` автоматически использует Unicode-символы как fallback.
Модуль компилируется и работает без PNG-файлов.

## Ссылки на MCTiers иконки

Иконки можно скачать с mctiers.com или сделать свои в стиле сайта.
Иконки MCTiers используют тёмный фон с цветными символами предметов.
