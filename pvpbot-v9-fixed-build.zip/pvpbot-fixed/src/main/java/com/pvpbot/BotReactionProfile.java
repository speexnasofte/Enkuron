package com.pvpbot;

import java.util.Random;

/**
 * BotReactionProfile v1.0 — симуляция времени реакции бота по сложности.
 *
 * Проблема которую решает:
 *   На EXPERT сложности бот реагирует мгновенно (0 тиков) на любое действие игрока.
 *   Это нечеловечески быстро и читерно. BotReactionProfile вносит реалистичные задержки:
 *
 *   EASY:   250-400ms (12-20 тиков) — как новичок
 *   MEDIUM: 150-250ms (7-12 тиков) — как обычный игрок
 *   HARD:   100-180ms (5-9 тиков)  — как опытный игрок
 *   EXPERT: 80-130ms  (4-6 тиков)  — как про
 *   PLAYER: 120-200ms (6-10 тиков) — максимальная человекоподобность
 *
 * Интеграция:
 *   Вместо прямого вызова actions → оборачиваем в shouldAct():
 *     if (reactionProfile.shouldAct(REACT_DODGE)) { dodgeLogic(); }
 *
 * Это даёт:
 *   - Более честный бот на низких сложностях
 *   - Более человекоподобное поведение на PLAYER
 *   - Меньше "instant reaction" читов на EXPERT
 */
public class BotReactionProfile {

    // ── Типы реакций ──────────────────────────────────────────────
    public enum ReactionType {
        DODGE,       // уклонение от удара
        HEAL,        // начало лечения
        TARGET_SWITCH, // переключение цели
        SHIELD_UP,   // поднять щит
        PEARL,       // бросок жемчуга
        COMBO_START  // начало комбо
    }

    // ── Константы задержек (тики) по сложности ───────────────────
    private static final int[][] REACTION_RANGES = {
        // [minTicks, maxTicks] для каждой Difficulty
        {12, 20}, // EASY
        { 7, 12}, // MEDIUM
        { 5,  9}, // HARD
        { 4,  6}, // EXPERT
        { 6, 10}, // PLAYER
    };

    // Множители по типу реакции (некоторые реакции быстрее/медленнее базового)
    private static final float[] TYPE_MULTIPLIERS = {
        1.0f, // DODGE       — базовая
        1.3f, // HEAL        — медленнее (нужно осознать ситуацию)
        1.5f, // TARGET_SWITCH — самая медленная
        0.8f, // SHIELD_UP   — быстрее (рефлекс)
        1.1f, // PEARL       — чуть медленнее
        0.9f, // COMBO_START — чуть быстрее
    };

    // ── Состояние ─────────────────────────────────────────────────
    private final int[] reactionTimers = new int[ReactionType.values().length];
    private final Random rnd = new Random();
    private final BotEntity bot;

    public BotReactionProfile(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик (декремент таймеров)
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        for (int i = 0; i < reactionTimers.length; i++) {
            if (reactionTimers[i] > 0) reactionTimers[i]--;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Проверка готовности к действию
    // ══════════════════════════════════════════════════════════════

    /**
     * Проверяет, прошло ли время реакции для данного типа.
     * При первом вызове запускает таймер реакции.
     * @return true если бот «успел среагировать»
     */
    public boolean shouldAct(ReactionType type) {
        int idx = type.ordinal();
        if (reactionTimers[idx] > 0) return false;

        // Сбрасываем на следующую задержку реакции
        reactionTimers[idx] = computeDelay(type);
        return true;
    }

    /**
     * Принудительно начинает отсчёт реакции без проверки готовности.
     * Использовать когда событие произошло и нужно отложить ответ.
     */
    public void triggerReaction(ReactionType type) {
        int idx = type.ordinal();
        if (reactionTimers[idx] <= 0) {
            reactionTimers[idx] = computeDelay(type);
        }
    }

    /** Остаток тиков до готовности реакции. */
    public int getRemainingTicks(ReactionType type) {
        return reactionTimers[type.ordinal()];
    }

    // ── Вычисление задержки реакции ───────────────────────────────
    private int computeDelay(ReactionType type) {
        PVPBotConfig.Difficulty diff = bot.getEffectiveDifficulty(); // FIX: per-bot
        int diffIdx = diff.ordinal();
        if (diffIdx >= REACTION_RANGES.length) diffIdx = REACTION_RANGES.length - 1;

        int min = REACTION_RANGES[diffIdx][0];
        int max = REACTION_RANGES[diffIdx][1];
        float base = min + rnd.nextInt(max - min + 1);

        float mult = TYPE_MULTIPLIERS[type.ordinal()];
        return Math.max(1, Math.round(base * mult));
    }

    /**
     * Базовая задержка реакции в тиках для текущей сложности.
     * Используется для информационного отображения в GUI.
     */
    public int getBaseReactionTicks() {
        PVPBotConfig.Difficulty diff = bot.getEffectiveDifficulty(); // FIX: per-bot
        int idx = Math.min(diff.ordinal(), REACTION_RANGES.length - 1);
        return (REACTION_RANGES[idx][0] + REACTION_RANGES[idx][1]) / 2;
    }

    /** Базовая задержка в миллисекундах (для GUI отображения). */
    public int getBaseReactionMs() {
        return getBaseReactionTicks() * 50; // 1 тик = 50ms
    }

    /**
     * Сброс всех таймеров реакции (при смерти / ресете бота).
     * BUG FIX v2.1: без сброса таймеры могли переполняться между боями.
     */
    public void reset() {
        java.util.Arrays.fill(reactionTimers, 0);
    }

    /**
     * Проверка: готова ли реакция БЕЗ сброса таймера.
     * Полезно для peek-проверки без побочных эффектов.
     */
    public boolean isReady(ReactionType type) {
        return reactionTimers[type.ordinal()] <= 0;
    }

    /**
     * Форматированная строка для !debug ai.
     * Показывает оставшиеся тики для каждого типа реакции.
     */
    public String getDebugString() {
        StringBuilder sb = new StringBuilder("Reaction[");
        for (ReactionType t : ReactionType.values()) {
            int rem = reactionTimers[t.ordinal()];
            sb.append(t.name().charAt(0)).append(':').append(rem > 0 ? rem : "✓").append(' ');
        }
        sb.append("] base=").append(getBaseReactionMs()).append("ms");
        return sb.toString();
    }
}
