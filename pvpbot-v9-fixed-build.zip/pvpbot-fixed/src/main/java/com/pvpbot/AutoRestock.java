package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;

/**
 * AutoRestock v1.0 — уведомление владельца о низком запасе расходников.
 *
 * Отслеживает:
 *  - Зелья лечения / рефилл-зелья (splash/lingering)
 *  - Зелья регенерации
 *  - Золотые яблоки (гэпл)
 *  - Тотемы бессмертия
 *  - Стрелы / ракеты (для crossbow-кита)
 *  - Жемчуг эндера (AutoPearl)
 *
 * Оповещение в чат один раз при пересечении порога.
 * Повторное оповещение — только после пополнения выше порога.
 *
 * Интеграция:
 *   AutoRestock restock = new AutoRestock(bot);
 *   // В тике бота:
 *   restock.tick();
 */
public class AutoRestock {

    // ── Пороги (количество единиц) ────────────────────────────────
    private static final int THRESHOLD_POTS     = 8;   // зелий < 8 → предупреждение
    private static final int THRESHOLD_GAPS     = 2;   // гэплов < 2
    private static final int THRESHOLD_TOTEMS   = 1;   // тотемов < 1
    private static final int THRESHOLD_ARROWS   = 16;  // стрел < 16
    private static final int THRESHOLD_PEARLS   = 4;   // жемчуга < 4
    private static final int CHECK_INTERVAL     = 100; // тиков между проверками

    private final BotEntity bot;

    // ── Состояние предупреждений (true = уже предупредили) ────────
    private boolean warnedPots   = false;
    private boolean warnedGaps   = false;
    private boolean warnedTotems = false;
    private boolean warnedArrows = false;
    private boolean warnedPearls = false;
    private int     checkTimer   = 0;

    public AutoRestock(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик (вызывать каждый тик бота)
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        if (++checkTimer < CHECK_INTERVAL) return;
        checkTimer = 0;

        Player owner = bot.getOwner();
        if (owner == null) return;

        SimpleContainer inv = bot.getInventory();
        int pots     = countItem(inv, Items.SPLASH_POTION) + countItem(inv, Items.LINGERING_POTION);
        int gaps     = countItem(inv, Items.GOLDEN_APPLE) + countItem(inv, Items.ENCHANTED_GOLDEN_APPLE);
        int totems   = countItem(inv, Items.TOTEM_OF_UNDYING);
        int arrows   = countItem(inv, Items.ARROW) + countItem(inv, Items.TIPPED_ARROW);
        int pearls   = countItem(inv, Items.ENDER_PEARL);

        warnedPots   = checkAndNotify(owner, pots,   THRESHOLD_POTS,   warnedPots,
                        "§c⚠ Мало зелий (" + pots + ") — пополни запас!");
        warnedGaps   = checkAndNotify(owner, gaps,   THRESHOLD_GAPS,   warnedGaps,
                        "§c⚠ Мало гэплов (" + gaps + ") — пополни запас!");
        warnedTotems = checkAndNotify(owner, totems, THRESHOLD_TOTEMS, warnedTotems,
                        "§4⚠⚠ Тотемов нет! Бот под угрозой!");
        warnedArrows = checkAndNotify(owner, arrows, THRESHOLD_ARROWS, warnedArrows,
                        "§e⚠ Мало стрел (" + arrows + ") — пополни запас!");
        warnedPearls = checkAndNotify(owner, pearls, THRESHOLD_PEARLS, warnedPearls,
                        "§e⚠ Мало жемчуга (" + pearls + ") — пополни запас!");
    }

    /**
     * Проверяет количество и шлёт оповещение если нужно.
     * Сбрасывает флаг предупреждения если запас пополнен выше порога.
     * @return новое состояние флага предупреждения
     */
    private boolean checkAndNotify(Player owner, int count, int threshold,
                                    boolean alreadyWarned, String msg) {
        if (count < threshold && !alreadyWarned) {
            owner.displayClientMessage(Component.literal(
                "§7[" + bot.getName().getString() + "] " + msg), false);
            return true;  // теперь предупреждён
        }
        if (count >= threshold + 4) {
            return false;  // запас пополнен → сброс флага (гистерезис +4)
        }
        return alreadyWarned;
    }

    /** Counts total of a specific item in a SimpleContainer. */
    private static int countItem(SimpleContainer inv, Item target) {
        int total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && stack.getItem() == target)
                total += stack.getCount();
        }
        return total;
    }

        /** Полный сброс (при смерти бота / ресете). */
    public void reset() {
        warnedPots   = false;
        warnedGaps   = false;
        warnedTotems = false;
        warnedArrows = false;
        warnedPearls = false;
        checkTimer   = 0;
    }
}
