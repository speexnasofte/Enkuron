package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * ThreatAssessment v2.0 — УЛУЧШЕНО
 *
 * Исправления:
 *   - REASSESS_INTERVAL: 15 → 10 тиков (быстрее реагирует на смену цели)
 *   - Новый критерий: +20 если цель недавно нанесла урон боту (агрессор)
 *   - Новый критерий: +15 если у цели активно зелье Strength (опаснее)
 *   - Новый критерий: -20 если цель уходит от бота (спиной — не атакует)
 *   - computeThreat: бонус за низкий HP масштабируется плавно (не бинарно)
 *   - Кеш bestTarget живёт до следующего reassess — если цель умерла, сбрасываем сразу
 */
public class ThreatAssessment {

    private static final int    REASSESS_INTERVAL = 10;  // FIX: было 15
    private static final double SCAN_RANGE        = 20.0;

    private LivingEntity bestTarget    = null;
    private int          reassessTimer = 0;

    // Для бонуса "недавно бил нас"
    private UUID lastAttackerUUID  = null;
    private int  lastAttackerTicks = 0;

    private final BotEntity bot;

    public ThreatAssessment(BotEntity bot) { this.bot = bot; }

    public void onAttackedBy(LivingEntity attacker) {
        lastAttackerUUID  = attacker.getUUID();
        lastAttackerTicks = 60; // помним 3 секунды
    }

    public LivingEntity tick() {
        if (lastAttackerTicks > 0) lastAttackerTicks--;
        reassessTimer--;

        // FIX: если текущая цель умерла — сбрасываем сразу
        if (bestTarget != null && !bestTarget.isAlive()) {
            bestTarget    = null;
            reassessTimer = 0;
        }

        if (reassessTimer > 0 && bestTarget != null) return bestTarget;

        reassessTimer = REASSESS_INTERVAL;
        bestTarget    = findBestTarget();
        return bestTarget;
    }

    public LivingEntity getBestTarget() { return bestTarget; }

    private LivingEntity findBestTarget() {
        if (!(bot.level() instanceof ServerLevel sw)) return null;

        AABB box = bot.getBoundingBox().inflate(SCAN_RANGE);
        List<LivingEntity> candidates = sw.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != bot && e.isAlive() && !e.isInvisible()
              && !isOwnerOrAlly(e) && !isWhitelisted(e));

        if (candidates.isEmpty()) return null;

        LivingEntity best      = null;
        float        bestScore = Float.NEGATIVE_INFINITY;

        for (LivingEntity e : candidates) {
            float score = computeThreat(e);
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    private float computeThreat(LivingEntity e) {
        float score = 0;

        // FIX: плавный бонус за низкий HP (ближе к смерти = выгоднее добить)
        float hpRatio = e.getHealth() / Math.max(1f, e.getMaxHealth());
        score += (1.0f - hpRatio) * 50f; // 0..50 вместо бинарного +40

        // Цель смотрит на бота и близко
        double dist = bot.distanceTo(e);
        if (dist < 8.0) {
            Vec3Approx toBot = new Vec3Approx(bot.position().subtract(e.position()).normalize());
            Vec3Approx facing = new Vec3Approx(e.getLookAngle());
            double dot = toBot.dot(facing);
            if (dot > 0.7) score += 30; // цель атакует нас
        }

        // FIX: цель недавно ударила нас
        if (lastAttackerTicks > 0 && e.getUUID().equals(lastAttackerUUID)) score += 20;

        // Цель пьёт зелье
        if (e.isUsingItem()) score += 25;

        // Цель в воздухе — уязвима
        if (!e.onGround()) score += 15;

        // Цель без брони
        float armorPoints = e.getArmorValue();
        if (armorPoints < 5) score += 10;

        // Дистанция: ближе = больше угроза
        score += (float) Math.max(0, 20.0 - dist);

        // FIX: -15 если цель уходит от нас (не угрожает)
        var vel = e.getDeltaMovement();
        var toBot2 = bot.position().subtract(e.position()).normalize();
        double moveDot = vel.x * toBot2.x + vel.z * toBot2.z;
        if (moveDot < -0.3) score -= 15;

        // FIX: +15 если у цели Strength
        if (e.hasEffect(net.minecraft.world.effect.MobEffects.DAMAGE_BOOST)) score += 15;

        // Щит — менее приоритетна
        var off  = e.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND);
        var main = e.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND);
        if ((off.is(Items.SHIELD) || main.is(Items.SHIELD)) && e.isBlocking()) score -= 50;

        // Высокий HP — менее приоритетен
        if (hpRatio > 0.85f) score -= 10;

        return score;
    }

    private boolean isOwnerOrAlly(LivingEntity e) {
        if (e instanceof Player p && bot.getOwnerUUID() != null
                && p.getUUID().equals(bot.getOwnerUUID())) return true;
        return bot.isAlliedToCustom(e);
    }

    private boolean isWhitelisted(LivingEntity e) {
        if (!(e instanceof Player p)) return false;
        return PVPBotConfig.INSTANCE.whitelist.contains(p.getGameProfile().getName());
    }

    // Лёгкий Vec3 без создания объекта Vec3 для dot-product
    private static class Vec3Approx {
        final double x, y, z;
        Vec3Approx(net.minecraft.world.phys.Vec3 v) { x = v.x; y = v.y; z = v.z; }
        double dot(Vec3Approx o) { return x*o.x + y*o.y + z*o.z; }
    }
}
