package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * BotPersonality v1.0
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Зачем это нужно:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Difficulty (EASY/MEDIUM/HARD/EXPERT) определяет насколько хорошо
 *  бот играет. Personality определяет КАК он играет — стиль боя,
 *  психологическое давление, приоритеты.
 *
 *  Два бота на HARD могут иметь совершенно разный характер:
 *    - BRAWLER: лезет в лицо, не страфит, W-tap агрессивно
 *    - DUELIST: держит дистанцию, ждёт ошибки, контрит
 *    - TRICKSTER: фейки, ложные отступления, ломает ритм
 *    - CAUTIOUS: кайтит, лечится на 10HP, не рискует
 *    - BERSERKER: под 50% HP ускоряется, игнорирует урон
 *    - PATIENT: ждёт полный кулдаун, никогда не торопится
 *    - RUSHER: постоянный спринт, максимальный давление
 *    - PHANTOM: часто отступает, бьёт по одному разу
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Параметры профиля (22 штуки):
 * ═══════════════════════════════════════════════════════════════════
 *
 *  ДИСТАНЦИЯ И ДВИЖЕНИЕ
 *   preferredDist       — идеальная дистанция до цели (0.8–8.0)
 *   retreatDistTrigger  — отступать если ближе чем (0 = никогда)
 *   chaseDist           — преследовать если дальше чем (2.0–20.0)
 *   strafeStyle         — стиль страфа: CIRCLE / ZIGZAG / RANDOM / RETREAT
 *   strafeIntensity     — насколько активно страфит (0.0–1.0)
 *   sprintBias          — вероятность спринта в бою (0.0–1.0)
 *
 *  АТАКА
 *   attackCdMultiplier  — множитель кулдауна атаки (0.5 = быстрее, 2.0 = медленнее)
 *   critBias            — вероятность попытки крита (0.0–1.0)
 *   wTapBias            — вероятность W-tap после удара (0.0–1.0)
 *   sTapBias            — вероятность S-tap (0.0–1.0)
 *   comboBias           — вероятность начать комбо-серию (0.0–1.0)
 *   fakeAttackBias      — вероятность фейк-атаки (0.0–1.0)
 *
 *  ЗАЩИТА И ЛЕЧЕНИЕ
 *   shieldBias          — вероятность поднять щит при угрозе (0.0–1.0)
 *   healThresholdMult   — когда лечиться (1.0 = при стандартных HP, 0.5 = позже)
 *   retreatBias         — вероятность отступить при низком HP (0.0–1.0)
 *   dodgeBias           — вероятность уклонения от атаки (0.0–1.0)
 *
 *  ПСИХОЛОГИЧЕСКОЕ ДАВЛЕНИЕ
 *   berserkerThreshold  — при каком HP% активировать берсерк (0.0 = никогда)
 *   berserkerSpeedBonus — бонус скорости в берсерке (0.0–0.5)
 *   tauntBias           — вероятность тауна при убийстве (0.0–1.0)
 *   idlePauseBias       — вероятность случайной паузы в бою (ломает ритм, 0.0–0.3)
 *
 *  АДАПТАЦИЯ
 *   adaptSpeed          — насколько быстро меняет стиль при контр-игре (0.0–1.0)
 *   memoryDecay         — как быстро забывает паттерны врага (0.0 = помнит всегда)
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Встроенные профили:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  BRAWLER  — агрессивный ближний боец, лезет в лицо
 *  DUELIST  — техничный дуэлянт, ждёт ошибку
 *  TRICKSTER— непредсказуемый, много фейков
 *  CAUTIOUS — осторожный кайтер, не рискует
 *  BERSERKER— берсерк, опасен при низком HP
 *  PATIENT  — терпеливый, бьёт только в нужный момент
 *  RUSHER   — максимальное давление, постоянный спринт
 *  PHANTOM  — призрак, бьёт и отступает
 *  BALANCED — сбалансированный (по умолчанию)
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Интеграция:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  1. BotEntity получает поле personality (per-bot):
 *       private BotPersonality personality = BotPersonality.BALANCED;
 *       public BotPersonality getPersonality() { return personality; }
 *       public void setPersonality(BotPersonality p) { personality = p; applyPersonality(); }
 *
 *  2. BotDifficultyAI.tick() и SwordLogic.tick() читают параметры:
 *       double idealDist = bot.getPersonality().preferredDist;
 *       if (rng.nextFloat() < bot.getPersonality().critBias) { doCrit(); }
 *
 *  3. Команда: /bot personality <profile> [botIndex]
 *       → BotPersonality.handleCommand(player, bot, profileName)
 *
 *  4. applyPersonality(BotEntity) сразу обновляет StrafeAI стиль
 *     и атрибут скорости без перезапуска бота.
 */
public class BotPersonality {

    // ══════════════════════════════════════════════════════════════
    //  Параметры профиля
    // ══════════════════════════════════════════════════════════════

    public final String name;
    public final String description;
    public final String color; // Minecraft color code для GUI

    // ── Дистанция и движение ──────────────────────────────────────
    /** Идеальная дистанция до цели (блоков) */
    public final double preferredDist;
    /** Отступать если цель ближе (0 = не отступаем никогда) */
    public final double retreatDistTrigger;
    /** Преследовать если цель дальше (блоков) */
    public final double chaseDist;
    /** Стиль страфа */
    public final StrafeAI.StrafeStyle strafeStyle;
    /** Интенсивность страфа: множитель шага (0 = не страфит, 1 = максимум) */
    public final float strafeIntensity;
    /** Вероятность спринта в каждом тике боя */
    public final float sprintBias;

    // ── Атака ─────────────────────────────────────────────────────
    /** Множитель кулдауна атаки (< 1 = агрессивнее, > 1 = терпеливее) */
    public final float attackCdMultiplier;
    /** Вероятность попытки критического удара */
    public final float critBias;
    /** Вероятность W-tap после удара */
    public final float wTapBias;
    /** Вероятность S-tap перед ударом */
    public final float sTapBias;
    /** Вероятность начать комбо-серию */
    public final float comboBias;
    /** Вероятность фейк-атаки (замах без удара для провокации щита) */
    public final float fakeAttackBias;

    // ── Защита и лечение ──────────────────────────────────────────
    /** Вероятность поднять щит при входящем ударе */
    public final float shieldBias;
    /**
     * Множитель порога лечения.
     * 1.0 → лечиться при cfg.healThreshold (дефолт 8HP).
     * 1.5 → лечиться при 12HP (раньше).
     * 0.5 → лечиться при 4HP (позже, рискованнее).
     */
    public final float healThresholdMult;
    /** Вероятность активного отступления при низком HP */
    public final float retreatBias;
    /** Вероятность уклонения от подтверждённой атаки врага */
    public final float dodgeBias;

    // ── Берсерк ───────────────────────────────────────────────────
    /**
     * Порог HP% для активации берсерк-режима (0.0 = никогда).
     * Например 0.4 → при ≤40% HP бот ускоряется и игнорирует лечение.
     */
    public final float berserkerThreshold;
    /**
     * Бонус к базовой скорости в берсерке (добавляется к атрибуту).
     * 0.0 = нет бонуса, 0.05 = +0.05 к MOVEMENT_SPEED.
     */
    public final float berserkerSpeedBonus;
    /**
     * В берсерк-режиме: вероятность игнорировать healThreshold
     * (не лечиться даже на низком HP, давить дальше).
     */
    public final float berserkerIgnoreHeal;

    // ── Психологическое давление ──────────────────────────────────
    /** Вероятность тауна при убийстве */
    public final float tauntBias;
    /**
     * Вероятность случайной паузы в бою (0–3 тика простоя).
     * Ломает ритм игрока, мешает предсказывать удары.
     * Не использовать выше 0.15 — иначе бот выглядит лагающим.
     */
    public final float idlePauseBias;
    /** Вероятность "провокационного" подхода вплотную без удара */
    public final float menaceBias;

    // ── Адаптация ─────────────────────────────────────────────────
    /**
     * Скорость адаптации к контр-игре.
     * 0.0 = не адаптируется (чистый профиль).
     * 1.0 = быстро меняет стиль если паттерн читается.
     */
    public final float adaptSpeed;
    /**
     * Скорость забывания паттернов врага (0.0–1.0).
     * 0.0 = помнит паттерны вечно.
     * 1.0 = забывает каждый бой.
     */
    public final float memoryDecay;

    // ══════════════════════════════════════════════════════════════
    //  Конструктор (Builder pattern)
    // ══════════════════════════════════════════════════════════════

    private BotPersonality(Builder b) {
        this.name                = b.name;
        this.description         = b.description;
        this.color               = b.color;
        this.preferredDist       = b.preferredDist;
        this.retreatDistTrigger  = b.retreatDistTrigger;
        this.chaseDist           = b.chaseDist;
        this.strafeStyle         = b.strafeStyle;
        this.strafeIntensity     = b.strafeIntensity;
        this.sprintBias          = b.sprintBias;
        this.attackCdMultiplier  = b.attackCdMultiplier;
        this.critBias            = b.critBias;
        this.wTapBias            = b.wTapBias;
        this.sTapBias            = b.sTapBias;
        this.comboBias           = b.comboBias;
        this.fakeAttackBias      = b.fakeAttackBias;
        this.shieldBias          = b.shieldBias;
        this.healThresholdMult   = b.healThresholdMult;
        this.retreatBias         = b.retreatBias;
        this.dodgeBias           = b.dodgeBias;
        this.berserkerThreshold  = b.berserkerThreshold;
        this.berserkerSpeedBonus = b.berserkerSpeedBonus;
        this.berserkerIgnoreHeal = b.berserkerIgnoreHeal;
        this.tauntBias           = b.tauntBias;
        this.idlePauseBias       = b.idlePauseBias;
        this.menaceBias          = b.menaceBias;
        this.adaptSpeed          = b.adaptSpeed;
        this.memoryDecay         = b.memoryDecay;
    }

    public static class Builder {
        private final String name;
        private String description = "";
        private String color = "§f";
        private double preferredDist      = 2.5;
        private double retreatDistTrigger = 0.0;
        private double chaseDist          = 8.0;
        private StrafeAI.StrafeStyle strafeStyle = StrafeAI.StrafeStyle.CIRCLE;
        private float strafeIntensity    = 0.6f;
        private float sprintBias         = 0.7f;
        private float attackCdMultiplier = 1.0f;
        private float critBias           = 0.4f;
        private float wTapBias           = 0.5f;
        private float sTapBias           = 0.1f;
        private float comboBias          = 0.3f;
        private float fakeAttackBias     = 0.1f;
        private float shieldBias         = 0.5f;
        private float healThresholdMult  = 1.0f;
        private float retreatBias        = 0.3f;
        private float dodgeBias          = 0.4f;
        private float berserkerThreshold = 0.0f;
        private float berserkerSpeedBonus= 0.0f;
        private float berserkerIgnoreHeal= 0.0f;
        private float tauntBias          = 0.1f;
        private float idlePauseBias      = 0.0f;
        private float menaceBias         = 0.0f;
        private float adaptSpeed         = 0.3f;
        private float memoryDecay        = 0.3f;

        public Builder(String name) { this.name = name; }
        public Builder desc(String d)             { description = d; return this; }
        public Builder color(String c)            { color = c; return this; }
        public Builder preferredDist(double v)    { preferredDist = v; return this; }
        public Builder retreatTrigger(double v)   { retreatDistTrigger = v; return this; }
        public Builder chaseDist(double v)        { chaseDist = v; return this; }
        public Builder strafe(StrafeAI.StrafeStyle s, float intensity) {
            strafeStyle = s; strafeIntensity = intensity; return this;
        }
        public Builder sprintBias(float v)        { sprintBias = v; return this; }
        public Builder attackCd(float mult)       { attackCdMultiplier = mult; return this; }
        public Builder critBias(float v)          { critBias = v; return this; }
        public Builder wTapBias(float v)          { wTapBias = v; return this; }
        public Builder sTapBias(float v)          { sTapBias = v; return this; }
        public Builder comboBias(float v)         { comboBias = v; return this; }
        public Builder fakeBias(float v)          { fakeAttackBias = v; return this; }
        public Builder shieldBias(float v)        { shieldBias = v; return this; }
        public Builder healMult(float v)          { healThresholdMult = v; return this; }
        public Builder retreatBias(float v)       { retreatBias = v; return this; }
        public Builder dodgeBias(float v)         { dodgeBias = v; return this; }
        public Builder berserker(float threshold, float speedBonus, float ignoreHeal) {
            berserkerThreshold = threshold;
            berserkerSpeedBonus = speedBonus;
            berserkerIgnoreHeal = ignoreHeal;
            return this;
        }
        public Builder tauntBias(float v)         { tauntBias = v; return this; }
        public Builder idlePause(float v)         { idlePauseBias = v; return this; }
        public Builder menaceBias(float v)        { menaceBias = v; return this; }
        public Builder adaptSpeed(float v)        { adaptSpeed = v; return this; }
        public Builder memoryDecay(float v)       { memoryDecay = v; return this; }
        public BotPersonality build()             { return new BotPersonality(this); }
    }

    // ══════════════════════════════════════════════════════════════
    //  Встроенные профили
    // ══════════════════════════════════════════════════════════════

    /**
     * BRAWLER — грубая сила, давление в упор.
     * Лезет вплотную, игнорирует страф, бьёт быстро и часто.
     * Уязвим к кайту и контролю дистанции.
     */
    public static final BotPersonality BRAWLER = new Builder("BRAWLER")
        .desc("Давит в ближнем бою, не страфит, бьёт быстро")
        .color("§c")
        .preferredDist(1.8)
        .retreatTrigger(0.0)
        .chaseDist(20.0)
        .strafe(StrafeAI.StrafeStyle.RANDOM, 0.25f)  // минимальный страф
        .sprintBias(0.95f)
        .attackCd(0.75f)      // атакует на 25% быстрее
        .critBias(0.55f)
        .wTapBias(0.8f)
        .sTapBias(0.05f)
        .comboBias(0.6f)
        .fakeBias(0.05f)
        .shieldBias(0.2f)     // редко блокирует
        .healMult(0.7f)       // лечится поздно
        .retreatBias(0.05f)
        .dodgeBias(0.2f)
        .tauntBias(0.4f)
        .idlePause(0.0f)
        .adaptSpeed(0.1f)     // плохо адаптируется
        .memoryDecay(0.6f)
        .build();

    /**
     * DUELIST — техничный боец.
     * Держит оптимальную дистанцию, ждёт полный кулдаун, часто критует.
     * Сложно достать, но предсказуем по тайминам.
     */
    public static final BotPersonality DUELIST = new Builder("DUELIST")
        .desc("Техника и тайминги — атакует только в нужный момент")
        .color("§b")
        .preferredDist(2.6)
        .retreatTrigger(1.2)
        .chaseDist(6.0)
        .strafe(StrafeAI.StrafeStyle.CIRCLE, 0.85f)
        .sprintBias(0.65f)
        .attackCd(1.1f)       // немного терпеливее
        .critBias(0.75f)      // часто критует
        .wTapBias(0.7f)
        .sTapBias(0.3f)
        .comboBias(0.25f)
        .fakeBias(0.15f)
        .shieldBias(0.7f)     // активно блокирует
        .healMult(1.2f)       // лечится вовремя
        .retreatBias(0.4f)
        .dodgeBias(0.65f)
        .tauntBias(0.05f)
        .idlePause(0.02f)
        .adaptSpeed(0.6f)
        .memoryDecay(0.15f)
        .build();

    /**
     * TRICKSTER — непредсказуемый трикстер.
     * Много фейков, случайные паузы, менит ритм.
     * Ломает тайминги игрока, сложно читать.
     */
    public static final BotPersonality TRICKSTER = new Builder("TRICKSTER")
        .desc("Фейки и непредсказуемость — ломает ритм противника")
        .color("§d")
        .preferredDist(2.2)
        .retreatTrigger(0.8)
        .chaseDist(10.0)
        .strafe(StrafeAI.StrafeStyle.ZIGZAG, 0.9f)   // зигзаг максимальный
        .sprintBias(0.6f)
        .attackCd(1.0f)
        .critBias(0.35f)
        .wTapBias(0.4f)
        .sTapBias(0.35f)
        .comboBias(0.15f)
        .fakeBias(0.55f)      // очень часто фейкует
        .shieldBias(0.45f)
        .healMult(0.9f)
        .retreatBias(0.35f)
        .dodgeBias(0.5f)
        .menaceBias(0.3f)     // подходит вплотную без удара
        .tauntBias(0.2f)
        .idlePause(0.12f)     // случайные паузы
        .adaptSpeed(0.7f)
        .memoryDecay(0.4f)
        .build();

    /**
     * CAUTIOUS — осторожный кайтер.
     * Держится на расстоянии, лечится часто, отступает при угрозе.
     * Сложно убить, но сам наносит мало давления.
     */
    public static final BotPersonality CAUTIOUS = new Builder("CAUTIOUS")
        .desc("Осторожно кайтит, лечится при малейшей угрозе")
        .color("§a")
        .preferredDist(3.8)
        .retreatTrigger(2.0)  // отступает если цель слишком близко
        .chaseDist(5.0)       // не преследует далеко
        .strafe(StrafeAI.StrafeStyle.RETREAT, 0.7f)
        .sprintBias(0.4f)
        .attackCd(1.3f)       // атакует редко
        .critBias(0.25f)
        .wTapBias(0.2f)
        .sTapBias(0.5f)       // часто S-tap для дистанции
        .comboBias(0.1f)
        .fakeBias(0.08f)
        .shieldBias(0.85f)    // почти всегда блокирует
        .healMult(1.5f)       // лечится очень рано
        .retreatBias(0.75f)
        .dodgeBias(0.8f)
        .tauntBias(0.0f)
        .idlePause(0.05f)
        .adaptSpeed(0.5f)
        .memoryDecay(0.1f)
        .build();

    /**
     * BERSERKER — берсерк.
     * При полном HP — нормальный боец.
     * При ≤40% HP — игнорирует лечение, ускоряется, атакует безостановочно.
     */
    public static final BotPersonality BERSERKER = new Builder("BERSERKER")
        .desc("Обычный при полном HP, опасный берсерк при ≤40% HP")
        .color("§4")
        .preferredDist(2.0)
        .retreatTrigger(0.0)
        .chaseDist(15.0)
        .strafe(StrafeAI.StrafeStyle.RANDOM, 0.4f)
        .sprintBias(0.8f)
        .attackCd(0.9f)
        .critBias(0.45f)
        .wTapBias(0.6f)
        .sTapBias(0.1f)
        .comboBias(0.5f)
        .fakeBias(0.1f)
        .shieldBias(0.3f)
        .healMult(0.8f)
        .retreatBias(0.0f)
        .dodgeBias(0.3f)
        .berserker(0.40f, 0.04f, 0.8f) // ≤40% HP: +0.04 скорость, 80% шанс игнорировать лечение
        .tauntBias(0.6f)
        .idlePause(0.0f)
        .adaptSpeed(0.2f)
        .memoryDecay(0.5f)
        .build();

    /**
     * PATIENT — терпеливый снайпер ближнего боя.
     * Ждёт 100% кулдауна, всегда критует, почти не промахивается.
     * Предсказуем по тайминам, но каждый удар максимальный.
     */
    public static final BotPersonality PATIENT = new Builder("PATIENT")
        .desc("Ждёт полного кулдауна — каждый удар критический")
        .color("§e")
        .preferredDist(3.0)
        .retreatTrigger(1.5)
        .chaseDist(6.0)
        .strafe(StrafeAI.StrafeStyle.CIRCLE, 0.6f)
        .sprintBias(0.5f)
        .attackCd(1.5f)       // очень терпелив
        .critBias(0.95f)      // почти всегда крит
        .wTapBias(0.9f)
        .sTapBias(0.15f)
        .comboBias(0.05f)     // не делает комбо
        .fakeBias(0.2f)
        .shieldBias(0.6f)
        .healMult(1.1f)
        .retreatBias(0.5f)
        .dodgeBias(0.55f)
        .tauntBias(0.1f)
        .idlePause(0.08f)
        .adaptSpeed(0.4f)
        .memoryDecay(0.2f)
        .build();

    /**
     * RUSHER — постоянное давление.
     * Никогда не останавливается, спринт 100% времени, минимальный кулдаун.
     * Легко читается, но изматывает ритмичными ударами.
     */
    public static final BotPersonality RUSHER = new Builder("RUSHER")
        .desc("Постоянный спринт и давление, никогда не отступает")
        .color("§6")
        .preferredDist(1.5)
        .retreatTrigger(0.0)
        .chaseDist(25.0)
        .strafe(StrafeAI.StrafeStyle.RANDOM, 0.3f)
        .sprintBias(1.0f)     // спринт всегда
        .attackCd(0.65f)      // максимально быстрые атаки
        .critBias(0.3f)
        .wTapBias(0.95f)
        .sTapBias(0.0f)
        .comboBias(0.7f)
        .fakeBias(0.0f)
        .shieldBias(0.1f)
        .healMult(0.5f)       // лечится только при критически низком HP
        .retreatBias(0.0f)
        .dodgeBias(0.15f)
        .tauntBias(0.3f)
        .idlePause(0.0f)
        .adaptSpeed(0.05f)
        .memoryDecay(0.8f)
        .build();

    /**
     * PHANTOM — бьёт и исчезает.
     * Один удар — отступление. Использует дистанцию и скорость.
     * Раздражающий стиль, сложно поймать.
     */
    public static final BotPersonality PHANTOM = new Builder("PHANTOM")
        .desc("Один удар и отступление — держит дистанцию")
        .color("§7")
        .preferredDist(4.5)
        .retreatTrigger(3.0)
        .chaseDist(8.0)
        .strafe(StrafeAI.StrafeStyle.ZIGZAG, 0.95f)
        .sprintBias(0.85f)
        .attackCd(1.2f)
        .critBias(0.6f)
        .wTapBias(0.3f)
        .sTapBias(0.7f)       // часто S-tap для выхода
        .comboBias(0.05f)     // не делает комбо
        .fakeBias(0.25f)
        .shieldBias(0.55f)
        .healMult(1.3f)
        .retreatBias(0.9f)    // почти всегда отступает после удара
        .dodgeBias(0.7f)
        .menaceBias(0.1f)
        .tauntBias(0.15f)
        .idlePause(0.03f)
        .adaptSpeed(0.6f)
        .memoryDecay(0.25f)
        .build();

    /**
     * BALANCED — сбалансированный (по умолчанию).
     * Все параметры в норме. Хорошая основа для кастомных профилей.
     */
    public static final BotPersonality BALANCED = new Builder("BALANCED")
        .desc("Сбалансированный стиль без явных слабостей")
        .color("§f")
        .build(); // все дефолтные значения

    // ── Реестр ────────────────────────────────────────────────────
    private static final Map<String, BotPersonality> REGISTRY = new LinkedHashMap<>();

    static {
        register(BRAWLER);
        register(DUELIST);
        register(TRICKSTER);
        register(CAUTIOUS);
        register(BERSERKER);
        register(PATIENT);
        register(RUSHER);
        register(PHANTOM);
        register(BALANCED);
    }

    public static void register(BotPersonality p) {
        REGISTRY.put(p.name.toUpperCase(), p);
    }

    /** Найти профиль по имени (case-insensitive). null если не найден. */
    public static BotPersonality byName(String name) {
        return REGISTRY.get(name.toUpperCase());
    }

    /** Все зарегистрированные профили */
    public static Collection<BotPersonality> all() {
        return Collections.unmodifiableCollection(REGISTRY.values());
    }

    // ══════════════════════════════════════════════════════════════
    //  Runtime-состояние: PersonalityState (per-бот)
    // ══════════════════════════════════════════════════════════════

    /**
     * Изменяемое состояние которое живёт внутри BotEntity.
     * Профиль (BotPersonality) — неизменяем, PersonalityState — нет.
     *
     * Хранит:
     *  - текущий профиль
     *  - берсерк-флаг
     *  - счётчик idle-пауз
     *  - адаптацию (история ударов игрока)
     */
    public static class PersonalityState {

        private BotPersonality profile;
        private final Random rng = new Random();

        // ── Берсерк ───────────────────────────────────────────────
        private boolean berserkerActive = false;
        private float   berserkerSpeedApplied = 0f; // что уже применили к атрибуту

        // ── Idle-пауза ────────────────────────────────────────────
        private int idlePauseTimer = 0;

        // ── Адаптация ─────────────────────────────────────────────
        // Считаем в скольких из последних N тиков игрок наносил урон
        // (высокое значение → игрок агрессивен → нужно больше dodge/shield)
        private static final int  ADAPT_WINDOW   = 40;
        private final boolean[] dmgWindow = new boolean[ADAPT_WINDOW];
        private int  dmgWindowHead = 0;
        private int  dmgWindowCount = 0; // сколько true в окне

        // Динамические поправки (накладываются поверх базового профиля)
        private float dynDodgeBonus  = 0f;
        private float dynShieldBonus = 0f;
        private float dynCritBonus   = 0f;

        public PersonalityState(BotPersonality profile) {
            this.profile = profile;
        }

        public void setProfile(BotPersonality p) {
            this.profile = p;
            berserkerActive = false;
            berserkerSpeedApplied = 0f;
            idlePauseTimer = 0;
            Arrays.fill(dmgWindow, false);
            dmgWindowHead = 0;
            dmgWindowCount = 0;
            dynDodgeBonus = 0f;
            dynShieldBonus = 0f;
            dynCritBonus = 0f;
        }

        public BotPersonality getProfile() { return profile; }

        // ── Главный тик ───────────────────────────────────────────

        /**
         * Вызывать каждый тик из BotEntity.tick() или BotDifficultyAI.tick().
         *
         * @param bot    бот
         * @param target цель (может быть null)
         * @param takenDmgThisTick урон полученный ботом в этом тике (0 = не было)
         */
        public void tick(BotEntity bot, LivingEntity target, float takenDmgThisTick) {
            // ── Берсерк ───────────────────────────────────────────
            if (profile.berserkerThreshold > 0f) {
                float hpRatio = bot.getHealth() / Math.max(1f, bot.getMaxHealth());
                boolean shouldBerserk = hpRatio <= profile.berserkerThreshold;

                if (shouldBerserk && !berserkerActive) {
                    activateBerserker(bot);
                } else if (!shouldBerserk && berserkerActive) {
                    deactivateBerserker(bot);
                }
            }

            // ── Idle-пауза ────────────────────────────────────────
            if (idlePauseTimer > 0) idlePauseTimer--;

            // Случайно ставим новую паузу
            if (profile.idlePauseBias > 0f && target != null && target.isAlive()
                    && idlePauseTimer == 0
                    && rng.nextFloat() < profile.idlePauseBias * 0.05f) { // не каждый тик
                idlePauseTimer = 1 + rng.nextInt(3); // 1-3 тика паузы
            }

            // ── Адаптация ─────────────────────────────────────────
            if (profile.adaptSpeed > 0f) {
                boolean gotHit = takenDmgThisTick > 0f;
                if (dmgWindow[dmgWindowHead]) dmgWindowCount--;
                dmgWindow[dmgWindowHead] = gotHit;
                if (gotHit) dmgWindowCount++;
                dmgWindowHead = (dmgWindowHead + 1) % ADAPT_WINDOW;

                float aggressionRatio = (float) dmgWindowCount / ADAPT_WINDOW;
                // Если игрок часто бьёт → больше dodge и shield
                dynDodgeBonus  = aggressionRatio * profile.adaptSpeed * 0.4f;
                dynShieldBonus = aggressionRatio * profile.adaptSpeed * 0.3f;
                // Если игрок почти не атакует → больше крит-давления
                dynCritBonus   = (1f - aggressionRatio) * profile.adaptSpeed * 0.2f;
            }
        }

        // ── Геттеры с учётом динамических поправок ────────────────

        public float effectiveDodgeBias() {
            return Math.min(1f, profile.dodgeBias + dynDodgeBonus);
        }

        public float effectiveShieldBias() {
            return Math.min(1f, profile.shieldBias + dynShieldBonus);
        }

        public float effectiveCritBias() {
            return Math.min(1f, profile.critBias + dynCritBonus);
        }

        public float effectiveHealThreshold() {
            float base = PVPBotConfig.INSTANCE.healThreshold * profile.healThresholdMult;
            // В берсерке — игнорируем лечение с шансом berserkerIgnoreHeal
            if (berserkerActive && rng.nextFloat() < profile.berserkerIgnoreHeal) {
                return 0f; // не лечиться
            }
            return base;
        }

        public double effectivePreferredDist() {
            // В берсерке — давим ближе
            return berserkerActive ? Math.max(1.0, profile.preferredDist - 0.8) : profile.preferredDist;
        }

        public float effectiveAttackCdMultiplier() {
            // В берсерке — атакуем быстрее
            return berserkerActive ? Math.max(0.5f, profile.attackCdMultiplier * 0.75f) : profile.attackCdMultiplier;
        }

        /** true = бот стоит на месте (idle-пауза активна) */
        public boolean isIdlePausing() { return idlePauseTimer > 0; }

        /** true = берсерк активен */
        public boolean isBerserkerActive() { return berserkerActive; }

        /** Случайный бросок против bias */
        public boolean roll(float bias) { return rng.nextFloat() < bias; }

        // ── Берсерк: применяем атрибут скорости ──────────────────

        private void activateBerserker(BotEntity bot) {
            berserkerActive = true;
            if (profile.berserkerSpeedBonus > 0f) {
                var attr = bot.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
                if (attr != null) {
                    berserkerSpeedApplied = profile.berserkerSpeedBonus;
                    attr.setBaseValue(attr.getBaseValue() + berserkerSpeedApplied);
                }
            }
            // Уведомляем владельца
            notifyOwner(bot, "§4⚡ " + bot.getName().getString() +
                " БЕРСЕРК! HP=" + String.format("%.0f", bot.getHealth()));
        }

        private void deactivateBerserker(BotEntity bot) {
            berserkerActive = false;
            if (berserkerSpeedApplied > 0f) {
                var attr = bot.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
                if (attr != null) {
                    attr.setBaseValue(Math.max(0.0, attr.getBaseValue() - berserkerSpeedApplied));
                }
                berserkerSpeedApplied = 0f;
            }
        }

        private void notifyOwner(BotEntity bot, String msg) {
            if (!(bot.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
            UUID ownerUUID = bot.getOwnerUUID();
            if (ownerUUID == null) return;
            var pl = sw.getServer().getPlayerList().getPlayer(ownerUUID);
            if (pl != null) pl.sendSystemMessage(Component.literal(msg));
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Команда: /bot personality <profile> [или без аргумента = список]
    // ══════════════════════════════════════════════════════════════

    /**
     * Точка входа для ChatCommand / SpawnBotCommand.
     *
     * Примеры:
     *   /bot personality            — показать список + текущий профиль
     *   /bot personality brawler    — назначить BRAWLER всем ботам игрока
     *   /bot personality info       — подробная инфо о текущем профиле бота
     *   /bot personality reset      — сбросить на BALANCED
     *
     * @param player  игрок
     * @param bot     бот (ближайший / выбранный; может быть null для list)
     * @param arg     подкоманда или имя профиля
     */
    public static void handleCommand(ServerPlayer player, BotEntity bot, String arg) {

        if (arg == null || arg.isBlank()) {
            cmdList(player, bot);
            return;
        }

        switch (arg.toLowerCase()) {
            case "list"  -> cmdList(player, bot);
            case "info"  -> cmdInfo(player, bot);
            case "reset" -> cmdSet(player, bot, BALANCED);
            default -> {
                BotPersonality p = byName(arg);
                if (p == null) {
                    player.sendSystemMessage(Component.literal(
                        "§c[Personality] Профиль «" + arg + "» не найден. /bot personality list"));
                } else {
                    cmdSet(player, bot, p);
                }
            }
        }
    }

    private static void cmdList(ServerPlayer player, BotEntity bot) {
        player.sendSystemMessage(Component.literal("§6══ Профили поведения ══"));
        for (BotPersonality p : all()) {
            String marker = (bot != null
                && bot.getPersonalityState() != null
                && bot.getPersonalityState().getProfile() == p) ? " §a◄ текущий" : "";
            player.sendSystemMessage(Component.literal(
                p.color + p.name + " §7— " + p.description + marker));
        }
        player.sendSystemMessage(Component.literal(
            "§7Использование: §f/bot personality <name>"));
    }

    private static void cmdInfo(ServerPlayer player, BotEntity bot) {
        if (bot == null) {
            player.sendSystemMessage(Component.literal("§c[Personality] Бот не найден."));
            return;
        }
        PersonalityState state = bot.getPersonalityState();
        if (state == null) {
            player.sendSystemMessage(Component.literal("§c[Personality] Нет данных."));
            return;
        }
        BotPersonality p = state.getProfile();
        player.sendSystemMessage(Component.literal(p.color + "══ " + p.name + " ══"));
        player.sendSystemMessage(Component.literal("§7" + p.description));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Дистанция: §f%.1f §7| Страф: §f%s §7(%.0f%%)",
            p.preferredDist, p.strafeStyle, p.strafeIntensity * 100)));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Атака CD: §f×%.1f §7| Крит: §f%.0f%% §7| W-tap: §f%.0f%%",
            p.attackCdMultiplier, p.critBias * 100, p.wTapBias * 100)));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Щит: §f%.0f%% §7| Уклон: §f%.0f%% §7| Лечение ×%.1f",
            state.effectiveShieldBias() * 100, state.effectiveDodgeBias() * 100,
            p.healThresholdMult)));
        if (p.berserkerThreshold > 0f) {
            player.sendSystemMessage(Component.literal(String.format(
                "§4⚡ Берсерк при ≤%.0f%% HP §7(%s)",
                p.berserkerThreshold * 100,
                state.isBerserkerActive() ? "§4АКТИВЕН" : "§7неактивен")));
        }
        player.sendSystemMessage(Component.literal(String.format(
            "§7Адаптация: §f%.0f%% §7| Фейки: §f%.0f%% §7| Idle-пауза: §f%.0f%%",
            p.adaptSpeed * 100, p.fakeAttackBias * 100, p.idlePauseBias * 100)));
    }

    private static void cmdSet(ServerPlayer player, BotEntity bot, BotPersonality p) {
        if (bot == null) {
            player.sendSystemMessage(Component.literal("§c[Personality] Бот не найден."));
            return;
        }
        bot.setPersonality(p);
        player.sendSystemMessage(Component.literal(
            p.color + "[Personality] " + bot.getName().getString() +
            " → " + p.name + " §7(" + p.description + ")"));
    }

    // ══════════════════════════════════════════════════════════════
    //  applyPersonality: применить профиль к боту сразу
    // ══════════════════════════════════════════════════════════════

    /**
     * Вызывать из BotEntity.setPersonality() чтобы немедленно обновить
     * StrafeAI стиль без перезапуска бота.
     *
     * Что обновляет:
     *  - StrafeAI.setStyle()
     *  - wTapEnabled / sTapEnabled в конфиге бота (через per-bot override если появится)
     *
     * Что НЕ обновляет сразу:
     *  - Атрибут скорости — он меняется только при берсерке
     *    (базовая скорость по Difficulty остаётся)
     *  - Кулдаун атаки — читается из attackCdMultiplier каждый тик
     */
    public static void applyPersonality(BotEntity bot, BotPersonality p) {
        // Обновляем StrafeAI
        bot.getStrafeAI().setStyle(p.strafeStyle);

        // Сбрасываем PersonalityState с новым профилем
        if (bot.getPersonalityState() != null) {
            bot.getPersonalityState().setProfile(p);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  toString для дебага
    // ══════════════════════════════════════════════════════════════

    @Override
    public String toString() {
        return String.format("BotPersonality{%s, dist=%.1f, strafe=%s, atkCd=×%.1f, crit=%.0f%%, berserk@%.0f%%}",
            name, preferredDist, strafeStyle, attackCdMultiplier,
            critBias * 100, berserkerThreshold * 100);
    }
}
