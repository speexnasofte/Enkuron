package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

/**
 * TpcLogic v5.0 — PATCH
 *
 * Улучшения v5 (patch):
 *  ✦ POST_CRYSTAL_WINDOW 8→12: надёжнее combo окно топором
 *  ✦ Позиционирование для кристалла: выбираем точку MAX урона (ближе к стенам/obsidian)
 *  ✦ Авто-тотем: если тотем сработал (HP=1) — немедленный отступ + щит
 *  ✦ Shield burst: после слома щита 5 ударов топором вместо 4 (BURST_COUNT 4→5)
 *  ✦ Retreat HP 4→6: отступаем раньше
 *
 * TpcLogic v4.0 — Totem + Crystal + Axe. MAJOR REWRITE.
 *
 * Улучшения v4:
 *  ✦ Три чёткие фазы: CRYSTAL_PHASE → AXE_BURST → CRIT_FINISH
 *  ✦ Crystal spam: расстановка по двум позициям вокруг цели (maximize hits)
 *  ✦ После взрыва кристалла — мгновенный axe hit (combo окно)
 *  ✦ Burst после слома щита: 4 удара топором с meleeCd=5
 *  ✦ Bow leading shot при dist > BOW_RANGE
 *  ✦ AntiKB: если цель в воздухе (отброс кристаллом) — жмём прямо к ней
 *  ✦ Strength II + Speed II баффы всегда
 *  ✦ Zigzag retreat при HP < 4
 *  ✦ HeatMap интеграция
 */
public class TpcLogic {

    private static final double BOW_RANGE     = 14.0;
    private static final double CRYSTAL_RANGE = 9.0;
    private static final double AXE_RANGE     = 4.0;
    private static final double IDEAL_DIST    = 2.5;

    private static final int    CRYSTAL_CD    = 12;  // быстрее: v3=15
    private static final int    AXE_CD        = 15;  // быстрее: v3=18
    private static final int    BOW_CD        = 18;  // быстрее: v3=22
    private static final int    BURST_CD      = 5;
    private static final int    BURST_COUNT   = 5;   // больше: v3=3
    private static final int    RETREAT_CD    = 90;
    private static final int    STR_CD        = 400;
    private static final int    SPD_CD        = 400;
    private static final int    CRIT_EVERY    = 3;

    // Combo-окно: сколько тиков после взрыва кристалла бот атакует топором немедленно
    private static final int    POST_CRYSTAL_WINDOW = 12; // PATCH v5: было 8 — надёжнее combo

    private enum Phase { POSITIONING, CRYSTALS, AXE_BURST, CRIT_FINISH, RETREAT }
    private Phase phase = Phase.POSITIONING;

    private final BotEntity    bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;

    private int crystalCd       = 0, axeCd  = 0, bowCd  = 0;
    private int burstCd         = 0, burstHits = 0;
    private int retreatCd       = 0, shieldDis = 0;
    private int strCd           = 0, spdCd  = 0;
    private int postCrystalTicks = 0; // combo-окно после взрыва
    private int hitCount        = 0;
    private boolean inBurst     = false;
    private boolean critPending = false;
    private int zigzagTimer     = 0;
    private boolean zigzagLeft  = true;

    public TpcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        if (crystalCd       > 0) crystalCd--;
        if (axeCd           > 0) axeCd--;
        if (bowCd           > 0) bowCd--;
        if (burstCd         > 0) burstCd--;
        if (retreatCd       > 0) retreatCd--;
        if (shieldDis       > 0) shieldDis--;
        if (strCd           > 0) strCd--;
        if (spdCd           > 0) spdCd--;
        if (zigzagTimer     > 0) zigzagTimer--;
        if (postCrystalTicks > 0) postCrystalTicks--;

        // ── Всегда: тотем + баффы + вода ─────────────────────────
        ensureTotem();
        // PATCH v5: щит при входящей атаке
        if (target != null && target.isAlive()) ensureShieldIfNeeded(target, bot.distanceTo(target));
        if (strCd <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1)); strCd = STR_CD; }
        if (spdCd <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); spdCd = SPD_CD; }
        if (bot.isInWater() && !bot.onGround())
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.15, bot.getDeltaMovement().z);

        if (target == null || !target.isAlive()) { phase = Phase.POSITIONING; inBurst = false; return; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Фаза RETREAT ─────────────────────────────────────────
        if (myHp < 6.0f && retreatCd <= 0) { // PATCH v5: было 4.0
            phase = Phase.RETREAT;
            retreatCd = RETREAT_CD;
        }
        if (phase == Phase.RETREAT) {
            doRetreat(target);
            if (myHp > 12.0f || retreatCd <= 0) phase = Phase.POSITIONING;
            return;
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Лук если очень далеко ─────────────────────────────────
        if (dist > BOW_RANGE) {
            doBowShot(sw, target, dist);
            bot.getNavigation().moveTo(target, 1.15);
            return;
        }

        // ── Страф ────────────────────────────────────────────────
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive && dist < AXE_RANGE + 3.0 && cfg.strafeEnabled)
            strafe.tick(target);

        // ── Позиционирование к идеальной дистанции ───────────────
        if (!wTapActive) {
            if (dist > IDEAL_DIST + 0.8) bot.getNavigation().moveTo(target, 1.1);
            else if (dist < IDEAL_DIST - 0.5) bot.getNavigation().stop();
        }

        // ── Кристалл: spam на позиции вокруг цели ────────────────
        if (dist <= CRYSTAL_RANGE && crystalCd <= 0) {
            doCrystalHit(sw, target, dist);
        }

        // ── После взрыва кристалла — немедленный axe hit ─────────
        if (postCrystalTicks > 0 && dist <= AXE_RANGE && axeCd <= 0) {
            doAxeHit(sw, target, false);
            postCrystalTicks = 0;
        }

        // ── Топор в ближнем бою ───────────────────────────────────
        if (dist <= AXE_RANGE) {
            boolean blocking = isBlocking(target);

            // Слом щита → burst
            if (blocking && axeCd <= 0) {
                doAxeHit(sw, target, false);
                shieldDis = 100; inBurst = true; burstHits = 0;
            } else if (inBurst && burstCd <= 0 && !blocking) {
                if (burstHits < BURST_COUNT) {
                    doAxeHit(sw, target, false);
                    burstCd = BURST_CD; burstHits++;
                } else { inBurst = false; burstHits = 0; }
            } else if (!blocking && !inBurst && axeCd <= 0 && !wTapActive) {
                boolean doCrit = (hitCount % CRIT_EVERY == 0);
                if (doCrit && bot.onGround() && !critPending) {
                    bot.getJumpControl().jump(); critPending = true; axeCd = 1;
                } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                    doAxeHit(sw, target, true); critPending = false;
                } else if (!doCrit && !critPending) {
                    doAxeHit(sw, target, false);
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════
    //  Атаки
    // ════════════════════════════════════════════════════════════

    private void doCrystalHit(ServerLevel sw, LivingEntity target, double dist) {
        // PATCH v5: выбираем оптимальную позицию кристалла (ближе к стенам = больше урона)
        // Проверяем соседние блоки — если рядом твёрдый блок, урон +20%
        BlockPos tPos = BlockPos.containing(target.position());
        boolean nearSolid = false;
        for (BlockPos adj : new BlockPos[]{
            tPos.north(), tPos.south(), tPos.east(), tPos.west(),
            tPos.above(2), tPos.below()
        }) {
            if (sw.getBlockState(adj).isSolid()) { nearSolid = true; break; }
        }
        float solidBonus = nearSolid ? 1.20f : 1.0f;

        // Симулируем End Crystal взрыв: AoE урон + KB
        float dmg = (float)(Math.max(6.0, 16.0 - dist * 0.8) * solidBonus); // больше урона вблизи/у стен
        if (target.isAlive())
            target.hurt(sw.damageSources().explosion(bot, bot), dmg);

        // AoE на других в радиусе 3
        sw.getEntitiesOfClass(LivingEntity.class,
            target.getBoundingBox().inflate(3.0),
            e -> e != bot && e != target && e.isAlive()
        ).forEach(e -> e.hurt(sw.damageSources().explosion(bot, bot), dmg * 0.5f));

        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive()) target.setDeltaMovement(kb.x * 1.2, 1.1, kb.z * 1.2);

        sw.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
            target.getX(), target.getY(), target.getZ(), 1,0,0,0,0);
        bot.playSound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE.value(), 0.85f, 1.0f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        crystalCd = CRYSTAL_CD;
        postCrystalTicks = POST_CRYSTAL_WINDOW; // combo-окно
        bot.getHeatMap().recordDamageDealt(bot.position(), dmg);
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        equipAxe();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 8, 0.3,0.3,0.3,0.1);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.9f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        }
        hitCount++;
        axeCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : AXE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
        bot.getHeatMap().recordDamageDealt(bot.position(), crit ? 20f : 13f);
    }

    private void doBowShot(ServerLevel sw, LivingEntity target, double dist) {
        if (bowCd > 0) return;
        equipBow();
        // Leading shot
        float  lead     = (float)(dist / 22.0 * 20);
        Vec3   vel      = target.getDeltaMovement();
        Vec3   predicted = target.position().add(vel.scale(lead));
        bot.getLookControl().setLookAt(predicted.x, predicted.y+1, predicted.z, 60f, 60f);
        float dmg = (float) Math.max(4.0, Math.min(9.0, 10.5 - dist * 0.3));
        if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 4, 0.2,0.2,0.2,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
        bowCd = BOW_CD;
        bot.getHeatMap().recordDamageDealt(bot.position(), dmg);
    }

    private void doRetreat(LivingEntity target) {
        if (zigzagTimer <= 0) { zigzagLeft = !zigzagLeft; zigzagTimer = 5 + bot.level().getRandom().nextInt(5); }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side = zigzagLeft ? new Vec3(-away.z,0,away.x).scale(0.45)
                               : new Vec3(away.z,0,-away.x).scale(0.45);
        Vec3 dest = bot.position().add(away.scale(9)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.35);
        bot.setSprinting(true);
    }

    // ════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════

    private boolean isBlocking(LivingEntity t) {
        if (shieldDis > 0) return false;
        return (t.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD) ||
                t.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD)) && t.isBlocking();
    }

    private void ensureTotem() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    // PATCH v5: авто-щит offhand при swinging цели во время TPC
    private void ensureShieldIfNeeded(LivingEntity target, double dist) {
        if (dist < 3.5 && target.swinging && phase != Phase.RETREAT) {
            if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            bot.setShiftKeyDown(true);
        } else if (phase != Phase.AXE_BURST) {
            // Восстанавливаем тотем
            bot.setShiftKeyDown(false);
            ensureTotem();
        }
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.NETHERITE_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                    .enchant("sharpness", 5).enchant("efficiency", 5)
                    .enchant("unbreaking", 3).build());
    }

    private void equipBow() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.BOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                    .enchant("power", 5).enchant("infinity", 1).build());
    }
}
