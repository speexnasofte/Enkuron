package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;

/**
 * Бот мстит тому, кто атаковал его или его владельца.
 * FIX v1.4: бот не мстит другим ботам (дружественный огонь).
 */
public class BotRevengeGoal extends HurtByTargetGoal {

    private final BotEntity bot;

    public BotRevengeGoal(BotEntity bot) {
        super(bot);
        this.bot = bot;
    }

    @Override
    public boolean canUse() {
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;

        // Реагируем на атаку по нам — но не от другого бота
        LivingEntity attacker = bot.getLastHurtByMob();

        // PATCH: в AGGRESSIVE режиме — мстим всем, включая владельца (тренировка)
        if (bot.getBotMode() == BotEntity.BotMode.AGGRESSIVE) {
            if (attacker != null && !(attacker instanceof BotEntity)) {
                return super.canUse();
            }
        }

        if (attacker instanceof BotEntity) return false; // дружественный огонь — игнорируем

        if (super.canUse()) return true;

        // Реагируем на атаку по владельцу (только в GUARD режиме)
        if (bot.getBotMode() == BotEntity.BotMode.GUARD) {
            var owner = bot.getOwner();
            if (owner != null) {
                LivingEntity ownerAttacker = owner.getLastHurtByMob();
                if (ownerAttacker != null && ownerAttacker != bot && !(ownerAttacker instanceof BotEntity)) {
                    bot.setTarget(ownerAttacker);
                    return true;
                }
            }
        }
        return false;
    }
}
