package com.pvpbot;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

import java.util.*;

/**
 * KitSuggester v1.0 — интеллектуальный подбор кита против текущего противника.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Как работает:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Анализирует снаряжение противника (броня, оружие, offhand) и
 *  статистику KitStatsTracker, затем рекомендует лучший кит.
 *
 *  Алгоритм выбора:
 *   1. Определяем тип врага: SWORD, AXE, BOW, CRYSTAL, MACE, TRIDENT
 *   2. Из KitStatsTracker берём winRate против каждого типа
 *   3. Применяем матрицу счётчиков (вручную заданные приоритеты):
 *      CRYSTAL → TPC или POT
 *      MACE    → SWORD (уклонение) или NETHPOT
 *      AXE     → SWORD (нейтрализует преимущество топора против щита)
 *      BOW     → SWORD (сближение)
 *      SWORD   → AXE или POT
 *   4. Если winRate из статистики сильно отличается от матрицы — используем его
 *   5. Результат — одна рекомендация с объяснением в чат
 *
 *  Команда: !suggest или /bot suggest
 *  Вызов: KitSuggester.INSTANCE.suggest(player, bots, opponent)
 *
 * ══════════════════════════════════════════════════════════════════
 *  Интеграция:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В ChatCommand или SpawnBotCommand:
 *    case "suggest" -> KitSuggester.INSTANCE.suggest(player, bots, currentTarget);
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class KitSuggester {

    public static final KitSuggester INSTANCE = new KitSuggester();

    // ── Типы вражеского снаряжения ───────────────────────────────
    public enum EnemyType {
        SWORD, AXE, BOW, CROSSBOW, CRYSTAL, MACE, TRIDENT, MIXED
    }

    // ── Матрица счётчиков: EnemyType → рекомендуемые киты ────────
    // Порядок: от лучшего к худшему. Первый = главная рекомендация.
    private static final Map<EnemyType, List<BotKit>> COUNTER_MATRIX = new EnumMap<>(EnemyType.class);
    static {
        COUNTER_MATRIX.put(EnemyType.SWORD,    Arrays.asList(BotKit.AXE, BotKit.POT, BotKit.NETHPOT));
        COUNTER_MATRIX.put(EnemyType.AXE,      Arrays.asList(BotKit.SWORD, BotKit.POT, BotKit.NETHPOT));
        COUNTER_MATRIX.put(EnemyType.BOW,      Arrays.asList(BotKit.SWORD, BotKit.AXE, BotKit.UHC));
        COUNTER_MATRIX.put(EnemyType.CROSSBOW,  Arrays.asList(BotKit.SWORD, BotKit.AXE, BotKit.SMP));
        COUNTER_MATRIX.put(EnemyType.CRYSTAL,  Arrays.asList(BotKit.TPC, BotKit.POT, BotKit.NETHPOT));
        COUNTER_MATRIX.put(EnemyType.MACE,     Arrays.asList(BotKit.SWORD, BotKit.NETHPOT, BotKit.POT));
        COUNTER_MATRIX.put(EnemyType.TRIDENT,  Arrays.asList(BotKit.BOW, BotKit.SWORD, BotKit.CRYSTAL));
        COUNTER_MATRIX.put(EnemyType.MIXED,    Arrays.asList(BotKit.SMP, BotKit.POT, BotKit.NETHPOT));
    }

    // ── Минимальный winRate для доверия статистике (нужно хотя бы 3 боя) ──
    private static final int MIN_ROUNDS_FOR_STATS = 3;
    /** Если статистический winRate кита отличается от матричного на эту долю — используем статистику */
    private static final float STATS_OVERRIDE_DELTA = 0.20f; // 20%

    private KitSuggester() {}

    // ══════════════════════════════════════════════════════════════
    //  Главный метод
    // ══════════════════════════════════════════════════════════════

    /**
     * Вычислить рекомендацию и отправить игроку в чат.
     *
     * @param player   игрок-владелец ботов (получатель совета)
     * @param bots     активные боты
     * @param opponent текущий противник (может быть null)
     */
    public void suggest(ServerPlayer player, List<BotEntity> bots, net.minecraft.world.entity.LivingEntity opponent) {
        EnemyType enemyType;
        String enemyDesc;

        if (opponent != null && opponent.isAlive()) {
            enemyType = detectEnemyType(opponent);
            enemyDesc = opponent.getName().getString() + " [" + enemyType.name() + "]";
        } else {
            // Нет активного противника — даём общую рекомендацию по winRate
            enemyType = EnemyType.MIXED;
            enemyDesc = "текущей ситуации";
        }

        SuggestionResult result = computeSuggestion(enemyType);

        // Форматируем ответ
        String header = "§e§l⚔ KitSuggester §r§7→ против §f" + enemyDesc;
        String rec    = "§aРекомендую: §f§l" + result.kit.displayName
                      + " §7[winRate: §e" + formatWinRate(result.winRate) + "§7]";
        String reason = "§7Причина: §f" + result.explanation;
        String alt    = result.altKit != null
                      ? "§7Альтернатива: §f" + result.altKit.displayName : "";

        player.sendSystemMessage(Component.literal(header));
        player.sendSystemMessage(Component.literal(rec));
        player.sendSystemMessage(Component.literal(reason));
        if (!alt.isEmpty()) player.sendSystemMessage(Component.literal(alt));

        // Опционально: спросить подтвердить смену кита
        player.sendSystemMessage(Component.literal(
            "§8Напиши §f!kit " + result.kit.id + " §8чтобы применить."
        ));
    }

    // ══════════════════════════════════════════════════════════════
    //  Определение типа врага
    // ══════════════════════════════════════════════════════════════

    public EnemyType detectEnemyType(net.minecraft.world.entity.LivingEntity target) {
        ItemStack mainHand  = target.getItemBySlot(EquipmentSlot.MAINHAND);
        ItemStack offHand   = target.getItemBySlot(EquipmentSlot.OFFHAND);

        // Кристальный боец: END_CRYSTAL в руке или offhand
        if (mainHand.is(Items.END_CRYSTAL) || offHand.is(Items.END_CRYSTAL)) {
            return EnemyType.CRYSTAL;
        }
        // Mace
        if (mainHand.is(Items.MACE)) return EnemyType.MACE;
        // Трезубец
        if (mainHand.is(Items.TRIDENT)) return EnemyType.TRIDENT;
        // Арбалет
        if (mainHand.is(Items.CROSSBOW)) return EnemyType.CROSSBOW;
        // Лук
        if (mainHand.is(Items.BOW)) return EnemyType.BOW;
        // Топор (любой материал)
        if (isAxe(mainHand)) return EnemyType.AXE;
        // Меч (любой материал)
        if (isSword(mainHand)) return EnemyType.SWORD;

        return EnemyType.MIXED;
    }

    // ══════════════════════════════════════════════════════════════
    //  Расчёт рекомендации
    // ══════════════════════════════════════════════════════════════

    private SuggestionResult computeSuggestion(EnemyType enemyType) {
        List<BotKit> counterList = COUNTER_MATRIX.getOrDefault(enemyType,
            List.of(BotKit.SWORD, BotKit.POT));

        BotKit matrixKit = counterList.get(0);
        BotKit altKit    = counterList.size() > 1 ? counterList.get(1) : null;

        // Проверяем статистику — может она говорит другое?
        KitStatsTracker stats = KitStatsTracker.INSTANCE;
        BotKit statsKit = findBestKitByStats(stats, counterList);

        BotKit chosen;
        float winRate;
        String explanation;

        if (statsKit != null && statsKit != matrixKit) {
            // Статистика рекомендует другой кит — доверяем ей
            chosen = statsKit;
            KitStatsTracker.KitRecord rec = stats.getRecord(statsKit.id);
            winRate = rec != null ? rec.winRate() : 0.5f;
            explanation = buildExplanation(enemyType, statsKit, true);
        } else {
            chosen = matrixKit;
            KitStatsTracker.KitRecord rec = stats.getRecord(matrixKit.id);
            winRate = (rec != null && rec.rounds >= MIN_ROUNDS_FOR_STATS)
                    ? rec.winRate() : estimateMatrixWinRate(enemyType, matrixKit);
            explanation = buildExplanation(enemyType, matrixKit, false);
        }

        return new SuggestionResult(chosen, altKit, winRate, explanation);
    }

    /**
     * Найти кит с наибольшим winRate из статистики.
     * Возвращает null если данных недостаточно.
     */
    private BotKit findBestKitByStats(KitStatsTracker stats, List<BotKit> candidates) {
        BotKit best = null;
        float bestRate = 0f;

        for (BotKit kit : candidates) {
            KitStatsTracker.KitRecord rec = stats.getRecord(kit.id);
            if (rec == null || rec.rounds < MIN_ROUNDS_FOR_STATS) continue;
            if (rec.winRate() > bestRate) {
                bestRate = rec.winRate();
                best = kit;
            }
        }

        // Возвращаем только если отличается от первого в списке значимо
        if (best != null && best != candidates.get(0)
                && bestRate - estimateMatrixWinRate(EnemyType.MIXED, candidates.get(0)) > STATS_OVERRIDE_DELTA) {
            return best;
        }
        return null;
    }

    /** Примерный winRate из матрицы (без статистики). */
    private float estimateMatrixWinRate(EnemyType enemy, BotKit kit) {
        // Оценка на основе позиции в матрице
        List<BotKit> list = COUNTER_MATRIX.getOrDefault(enemy, List.of(kit));
        int pos = list.indexOf(kit);
        if (pos < 0) return 0.45f;
        // Первый в матрице → 0.70, второй → 0.60, третий → 0.50
        return 0.70f - pos * 0.10f;
    }

    private String buildExplanation(EnemyType enemy, BotKit kit, boolean fromStats) {
        String base = switch (enemy) {
            case SWORD   -> "меч vs топор: топор убирает щит быстрее; меч — меньше кулдаун";
            case AXE     -> "топор бьёт через щит — бери меч без щита, уклоняйся";
            case BOW     -> "дальний бой — нужно сближаться с мечом или AoE";
            case CROSSBOW -> "арбалет — атакует сериями, меч нейтрализует до перезарядки";
            case CRYSTAL -> "кристальный игрок — TPC-кит отвечает своими кристаллами";
            case MACE    -> "маса + элитра = воздушные атаки; страф и дистанция решают";
            case TRIDENT -> "трезубец на воде — лук с дистанции или быстрый меч";
            case MIXED   -> "смешанный бой — универсальный кит с хорошей выживаемостью";
        };
        String suffix = fromStats ? " §8(выбор из статистики)" : "";
        return base + suffix;
    }

    // ── Вспомогательные ─────────────────────────────────────────

    private boolean isSword(ItemStack s) {
        return s.is(Items.WOODEN_SWORD) || s.is(Items.STONE_SWORD)
            || s.is(Items.IRON_SWORD)   || s.is(Items.GOLDEN_SWORD)
            || s.is(Items.DIAMOND_SWORD)|| s.is(Items.NETHERITE_SWORD);
    }

    private boolean isAxe(ItemStack s) {
        return s.is(Items.WOODEN_AXE)  || s.is(Items.STONE_AXE)
            || s.is(Items.IRON_AXE)    || s.is(Items.GOLDEN_AXE)
            || s.is(Items.DIAMOND_AXE) || s.is(Items.NETHERITE_AXE);
    }

    private String formatWinRate(float rate) {
        return String.format("%.0f%%", rate * 100);
    }

    // ── Внутренний результат ─────────────────────────────────────

    private static class SuggestionResult {
        final BotKit kit;
        final BotKit altKit;
        final float  winRate;
        final String explanation;

        SuggestionResult(BotKit kit, BotKit altKit, float winRate, String explanation) {
            this.kit = kit;
            this.altKit = altKit;
            this.winRate = winRate;
            this.explanation = explanation;
        }
    }
}
