package com.pvpbot;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Главный класс мода v6 — добавлено:
 *   ESP хитбоксы       (EspRenderer)
 *   Radar HUD          (RadarHud)
 *   K/D статистика     (KillDeathTracker)
 *   AutoBow            (AutoBow, в PVPBotLogic)
 *   Кайтинг            (KiteLogic, в PVPBotLogic)
 *   Улучшенный pathfind (BotPathfindGoal, в BotEntity)
 */
public class PVPBotMod implements ModInitializer, ClientModInitializer {

    public static KeyMapping toggleKey;
    public static KeyMapping settingsKey;
    public static KeyMapping hudKey;

    // v1.2: PVPBotLogic теперь живёт в BotEntity, не здесь
    private final PVPBotConfig cfg        = PVPBotConfig.INSTANCE;
    private final AutoRespawn autoRespawn = new AutoRespawn();
    private final PVPBotHud pvpBotHud = new PVPBotHud();
    private final RadarHud radarHud = new RadarHud();
    private boolean hudDragActive = false;

    // ── Серверная инициализация ──────────────────────────────────
    @Override
    public void onInitialize() {
        BotConfig.load(); // загружает конфиг и синхронизирует ModuleManager
        CustomKitStore.loadAll(); // v1.4.2: загружаем кастомные киты с диска
        BotEntityType.register();
        FabricDefaultAttributeRegistry.register(
            BotEntityType.BOT_ENTITY,
            BotEntity.createAttributes()
        );
        SpawnBotCommand.register();
        ChatCommand.register(); // v17: !attack / !retreat / !stand / !flank

        // v16: DuelTimer — тикаем на сервере
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            DuelTimer.INSTANCE.tick(server);
            // OPT v8: GappleOptimizer.globalTick() перенесён сюда из BotEntity.tick()
            // — вызывается 1 раз в тик на весь сервер, а не N раз (по числу ботов)
            GappleOptimizer.INSTANCE.globalTick();
            // v1.8.0: BotTauntReact — тикаем агрессию по провокациям (один раз на сервер)
            BotTauntReact.INSTANCE.tick();
            // OPT v8: BotSyncAttack.serverTick() — тоже глобальная операция,
            // вызываем один раз для каждого онлайн-игрока (не для каждого бота)
            for (net.minecraft.server.level.ServerPlayer sp : server.getPlayerList().getPlayers()) {
                var bots = com.pvpbot.SpawnBotCommand.getBotsFor(sp);
                if (!bots.isEmpty()) {
                    BotSyncAttack.INSTANCE.serverTick(bots);
                }
            }
        });

        // ── FIX v8: onHurtCustom() теперь реально вызывается ────
        // Без этой регистрации ComboBreaker, FightAnalyzer и totem-pop были мертвы.
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DAMAGE.register(
            (entity, source, baseDamage, damage, blocked) -> {
                if (entity instanceof BotEntity bot) {
                    bot.onHurtCustom(source, damage);
                }
                // v1.6.0 — TankMode: если ударили игрока-владельца → бот мстит атакующему
                if (entity instanceof net.minecraft.server.level.ServerPlayer player) {
                    net.minecraft.world.entity.LivingEntity attacker =
                        source.getEntity() instanceof net.minecraft.world.entity.LivingEntity le ? le : null;
                    if (attacker != null) {
                        // Уведомляем TankMode о том что хозяин получил урон
                        SpawnBotCommand.getBotsFor(player).forEach(b -> {
                            if (PVPBotConfig.INSTANCE.tankModeEnabled) {
                                // FIX B: передаём per-bot state вместо обращения к синглтону
                                TankMode.INSTANCE.onOwnerHurt(b.tankState, attacker);
                            }
                        });
                    }
                }
            }
        );

        // v1.6.8 — BotLearning: per-owner тик (FIX: был глобальный INSTANCE — данные смешивались)
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (net.minecraft.server.level.ServerPlayer sp : server.getPlayerList().getPlayers()) {
                if (!SpawnBotCommand.getBotsFor(sp).isEmpty()) {
                    // FIX v1.6.8: каждый игрок имеет свой BotLearning — не смешиваем данные
                    BotLearning.forOwner(sp.getUUID()).tick(sp);
                }
            }
        });

        // FIX E + v1.6.8: обработчик отключения игрока.
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register(
            (handler, server2) -> {
                net.minecraft.server.level.ServerPlayer leaving = handler.getPlayer();
                // FIX E: WaveDefense — останавливаем режим при отключении владельца сессии.
                // Без этого вражеские боты оставались в мире навсегда.
                if (WaveDefense.INSTANCE.isOwner(leaving.getUUID())) {
                    WaveDefense.INSTANCE.stop(leaving);
                    PVPBotConfig.INSTANCE.waveDefenseActive = false;
                }
                // FIX v1.6.8: очищаем per-owner BotLearning при выходе — утечки памяти нет.
                BotLearning.removeOwner(leaving.getUUID());
            }
        );
    }

    // ── Клиентская инициализация ─────────────────────────────────
    @Override
    public void onInitializeClient() {
        // Клавиши
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.pvpbot.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.pvpbot"
        ));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.pvpbot.settings", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.pvpbot"
        ));
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.pvpbot.hud", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.pvpbot"
        ));

        // HUD (основная панель + радар)
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            pvpBotHud.onHudRender(ctx, ticker); // FIX: переиспользуем экземпляр вместо new каждый кадр
        });
        HudRenderCallback.EVENT.register((ctx, ticker) -> {
            var mc = net.minecraft.client.Minecraft.getInstance();
            radarHud.render(ctx, mc);                 // радар
        });

        // Mouse — drag HUD
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK.register(c -> {
            // Отслеживаем состояние ЛКМ для drag через GLFW напрямую
            long win = net.minecraft.client.Minecraft.getInstance().getWindow().getWindow();
            boolean lmbDown = org.lwjgl.glfw.GLFW.glfwGetMouseButton(win, org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT)
                              == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            double[] mx = new double[1], my = new double[1];
            org.lwjgl.glfw.GLFW.glfwGetCursorPos(win, mx, my);

            // Масштаб GUI
            var mc2 = net.minecraft.client.Minecraft.getInstance();
            double scale = mc2.getWindow().getGuiScale();
            double guiMx = mx[0] / scale;
            double guiMy = my[0] / scale;

            if (lmbDown && mc2.screen == null) {
                if (!hudDragActive) {
                    hudDragActive = pvpBotHud.onMousePressed(guiMx, guiMy);
                } else {
                    pvpBotHud.onMouseDragged(guiMx, guiMy);
                }
            } else if (hudDragActive) {
                pvpBotHud.onMouseReleased(guiMx, guiMy);
                hudDragActive = false;
            } else if (!lmbDown && mc2.screen == null) {
                // одиночный клик (кнопки HUD)
                // обрабатывается через onMouseReleased при hudDragActive=false
            }
        });

        // ESP — рендер в мире (сквозь стены)
        WorldRenderEvents.END.register(new EspRenderer());

        // Tracers — линии к игрокам
        Tracers.INSTANCE.register();

        // K/D трекер
        KillDeathTracker.register();
        DpsMeter.INSTANCE.register(); // v9
        BotSkinManager.INSTANCE.register(); // v9
        BattleLog.INSTANCE.init(); // v1.5.0: история боёв
        // FIX: загружаем историю боёв из JSON при старте
        FightAnalyzer.INSTANCE.init(net.minecraft.client.Minecraft.getInstance().gameDirectory.toPath());

        // Звук при подключении к серверу
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.JOIN.register(
            (handler, sender, mc) -> ClientSounds.INSTANCE.playJoin()
        );

        // Тик-цикл
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            autoRespawn.tick(client);
            HitHighlightTracker.INSTANCE.tick(); // v1.3.2: тикаем таймеры подсветки HUD

            while (toggleKey.consumeClick()) {
                cfg.enabled = !cfg.enabled;
                BotConfig.save();
                if (client.player != null) {
                    client.gui.getChat().addMessage(Component.literal(cfg.enabled ? "§a[PVPBot] §fВключён!" : "§c[PVPBot] §fВыключен!"));
                }
            }

            while (hudKey.consumeClick()) {
                cfg.showHud = !cfg.showHud;
                BotConfig.save();
                if (client.player != null) {
                    client.gui.getChat().addMessage(Component.literal(
                        cfg.showHud ? "§a[PVPBot] §fHUD включён" : "§7[PVPBot] §fHUD скрыт §8(нажми §7[H]§8 снова)"
                    ));
                }
            }

            while (settingsKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new PVPBotScreen(null));
                }
            }

            // v1.5.0 — AutoSprint для самого игрока
            if (cfg.autoSprintPlayer && client.player != null
                    && client.screen == null
                    && client.player.input.forwardImpulse > 0
                    && !client.player.isSprinting()
                    && !client.player.isUnderWater()
                    && !client.player.isCrouching()) {
                client.player.setSprinting(true);
            }

            // v1.2: логика бота тикается в BotEntity.tick() на сервере
        });
    }
}
