package com.pvpbot;

import net.minecraft.core.RegistryAccess;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Описание снаряжения кита: броня, оружие, зачарования.
 * Вынесено из BotKit для уменьшения размера файла.
 */
public class KitEquipment {
    public final Item mainhand;
    public final Item offhand;
    public final Item helmet;
    public final Item chestplate;
    public final Item leggings;
    public final Item boots;
    private final KitEnchant enchantProfile;

    public KitEquipment(Item mainhand, Item offhand,
                Item helmet, Item chestplate,
                Item leggings, Item boots,
                KitEnchant enchantProfile) {
        this.mainhand       = mainhand;
        this.offhand    = offhand;
        this.helmet     = helmet;
        this.chestplate     = chestplate;
        this.leggings       = leggings;
        this.boots      = boots;
        this.enchantProfile = enchantProfile;
    }

    public void applyTo(BotEntity bot) {
        RegistryAccess ra = bot.level().registryAccess();
        enchantProfile.apply(bot, ra, mainhand, offhand,
        helmet, chestplate, leggings, boots);
    }
}
