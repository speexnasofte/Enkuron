package com.pvpbot;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * ChatCommand v1.0 — управление ботами через чат-команды.
 *
 * Команды (пишутся в чат, без слэша):
 *   !attack [ник]   — приказать атаковать (всем или конкретного)
 *   !retreat        — отступить к игроку
 *   !stand          — стоять, ждать
 *   !flank          — фланкировать цель
 *   !follow         — следовать за мной
 *   !surround       — окружить ближайшего врага
 *   !bots           — показать статус ботов
 *   !help           — показать список команд
 *
 * Поддерживает Squad-систему: приказ идёт через CommanderAI
 * если отряд создан, иначе напрямую всем ботам.
 *
 * Интеграция:
 *   ChatCommand.register() вызывать из PVPBotMod.onInitialize()
 */
public class ChatCommand {

    private static final String PREFIX = "!";

    private ChatCommand() {}

    /** Зарегистрировать слушатель чат-сообщений. */
    public static void register() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.decoratedContent().getString().trim();
            if (text.startsWith(PREFIX)) {
                handleCommand(sender, text.substring(PREFIX.length()).trim());
            }
        });
    }

    private static void handleCommand(ServerPlayer player, String raw) {
        String[] parts = raw.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String arg = parts.length > 1 ? parts[1].trim() : null;

        List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);

        switch (cmd) {
            case "attack" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.ATTACK);
                } else {
                    PVPBotConfig.INSTANCE.standbyMode = false;
                    if (arg != null) {
                        setForcedTargetByName(player, bots, arg);
                    }
                }
                feedback(player, "§c⚔ Атаковать!");
            }
            case "retreat" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.RETREAT);
                } else {
                    for (BotEntity bot : bots) {
                        bot.setTarget(null);
                        bot.getNavigation().stop();
                    }
                    PVPBotConfig.INSTANCE.standbyMode = true;
                }
                feedback(player, "§e🏃 Отступить!");
            }
            case "stand" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.STAND);
                } else {
                    for (BotEntity bot : bots) {
                        bot.setTarget(null);
                        bot.getNavigation().stop();
                    }
                    PVPBotConfig.INSTANCE.standbyMode = true;
                    BotFormations.INSTANCE.setCurrent(BotFormations.Formation.LINE);
                }
                feedback(player, "§7🛡 Стоять!");
            }
            case "flank" -> {
                if (squad != null) {
                    SquadManager.INSTANCE.issueOrder(player, SquadManager.CommanderOrder.FLANK);
                } else {
                    feedback(player, "§c! Создай отряд: §f/bot squad create");
                    return;
                }
                feedback(player, "§b🏹 Фланкировать!");
            }
            case "follow" -> {
                PVPBotConfig.INSTANCE.standbyMode = false;
                BotFormations.INSTANCE.setCurrent(BotFormations.Formation.FOLLOW);
                for (BotEntity bot : bots) bot.setTarget(null);
                feedback(player, "§a👣 Следовать за мной!");
            }
            case "surround" -> {
                BotFormations.INSTANCE.setCurrent(BotFormations.Formation.SURROUND);
                // Найти ближайшего врага и атаковать
                net.minecraft.world.entity.LivingEntity enemy = findNearestEnemy(player, 30.0);
                if (enemy != null) {
                    PVPBotConfig.INSTANCE.standbyMode = false;
                    for (BotEntity bot : bots) {
                        bot.setTarget(enemy);
                        bot.getTargetPriority().setForcedTarget(enemy.getUUID());
                    }
                    feedback(player, "§6🔄 Окружить цель!");
                } else {
                    BotFormations.INSTANCE.setCurrent(BotFormations.Formation.SURROUND);
                    feedback(player, "§7🔄 Построение окружение (врагов нет рядом)");
                }
            }
            case "bots" -> {
                StringBuilder sb = new StringBuilder("§e§l⚔ Боты:\n");
                for (int i = 0; i < bots.size(); i++) {
                    BotEntity bot = bots.get(i);
                    boolean isCmd = squad != null && bot == squad.commander;
                    String role = isCmd ? "§c[CMD]" : "§7[PVT]";
                    sb.append(role).append(" §f#").append(i + 1)
                      .append(" HP:").append((int) bot.getHealth()).append("/").append((int) bot.getMaxHealth())
                      .append(bot.getTarget() != null ? " §cАТАКА" : " §7ожидание")
                      .append("\n");
                }
                if (squad != null) sb.append("§7Приказ: §f").append(squad.currentOrder.name());
                player.sendSystemMessage(Component.literal(sb.toString()));
            }
            case "help" -> {
                player.sendSystemMessage(Component.literal(
                    "§e§l⚔ ChatCommands (PVPBot):\n" +
                    "§f!attack [ник]  §7— атаковать (всех / конкретного)\n" +
                    "§f!retreat       §7— отступить\n" +
                    "§f!stand         §7— стоять, держать позицию\n" +
                    "§f!flank         §7— фланкировать цель\n" +
                    "§f!follow        §7— следовать за мной\n" +
                    "§f!surround      §7— окружить ближайшего врага\n" +
                    "§f!bots          §7— статус ботов\n" +
                    "§f!heal          §7— принудительно хилить всех ботов\n" +
                    "§f!tank          §7— Tank Mode (бот прёт напролом)\n" +
                    "§f!refill [bot]  §7— авторефилл инвентаря\n" +
                    "§f!swap          §7— поменять позиции с ботом #1\n" +
                    "§f!battles       §7— последние 10 боёв из истории\n" +
                    "§f!suggest       §7— подобрать кит против текущего противника\n" +
                    "§f!debug [ai|perf|target] §7— инспекция AI в реальном времени\n" +
                    "§f!ping          §7— пинг игроков (компенсация предсказания)\n" +
                    "§f!arena [on|off] §7— режим 1v1 арены с раундами\n" +
                    "§f!streak        §7— серия убийств бота\n" +
                    "§f!heatmap       §7— тепловая карта урона по зонам\n" +
                    "§f!react [сложность] §7— изменить сложность реакции\n" +
                    "§f!tpon          §7— включить мгновенный ТП бота к тебе\n" +
                    "§f!tpoff         §7— выключить ТП бота к тебе\n" +
                    "§f!agro          §7— бот атакует ВСЕХ (включая владельца — тренировка)\n" +
                    "§f!guard         §7— бот защищает владельца (обычный режим)\n" +
                    "§f!help          §7— эта справка"
                ));
            }
            case "heal" -> {
                // !heal — принудительно хилить всех ботов немедленно
                for (BotEntity bot : bots) {
                    bot.heal(bot.getMaxHealth() - bot.getHealth()); // полное восстановление
                    // Также активируем стандартный autoHeal-предмет
                    net.minecraft.world.item.ItemStack gap =
                        new net.minecraft.world.item.ItemStack(
                            net.minecraft.world.item.Items.GOLDEN_APPLE);
                    bot.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, gap);
                }
                feedback(player, "§a💊 Боты восстановлены до полного HP!");
            }
            case "tank" -> {
                boolean enabled = !PVPBotConfig.INSTANCE.tankModeEnabled;
                PVPBotConfig.INSTANCE.tankModeEnabled = enabled;
                if (!enabled) TankMode.INSTANCE.resetAll();
                // Tank mode отключает kite и retreat
                if (enabled) {
                    PVPBotConfig.INSTANCE.kiteEnabled    = false;
                    PVPBotConfig.INSTANCE.retreatEnabled = false;
                }
                feedback(player, enabled
                    ? "§c🛡 Tank Mode §aВКЛ §7— бот прёт напролом и бьёт!"
                    : "§7🛡 Tank Mode §cВЫКЛ");
            }
            case "refill" -> {
                // !refill — включить/выключить авторефилл для бота И игрока
                if (arg != null && arg.equalsIgnoreCase("bot")) {
                    boolean b = !PVPBotConfig.INSTANCE.botAutoRefill;
                    PVPBotConfig.INSTANCE.botAutoRefill = b;
                    feedback(player, b
                        ? "§a🎒 Bot AutoRefill §aВКЛ §7— бот пополняет свой инвентарь"
                        : "§7🎒 Bot AutoRefill §cВЫКЛ");
                } else {
                    boolean b = !PVPBotConfig.INSTANCE.autoRefill;
                    PVPBotConfig.INSTANCE.autoRefill = b;
                    feedback(player, b
                        ? "§a🎒 AutoRefill §aВКЛ §7— инвентарь пополняется автоматически"
                        : "§7🎒 AutoRefill §cВЫКЛ");
                }
            }
            case "kit" -> {
                // !kit [название] — сменить кит всем ботам
                if (arg == null) {
                    StringBuilder kitList = new StringBuilder("§eДоступные киты: §f");
                    for (BotKit k : BotKit.values()) kitList.append(k.id).append(" ");
                    feedback(player, kitList.toString());
                    return;
                }
                BotKit found = null;
                for (BotKit k : BotKit.values()) {
                    if (k.id.equalsIgnoreCase(arg)) { found = k; break; }
                }
                if (found == null) {
                    feedback(player, "§cНеизвестный кит: §f" + arg + "§c. Напиши §f!kit §cдля списка.");
                    return;
                }
                final BotKit kit = found;
                for (BotEntity bot : bots) bot.setKit(kit);
                feedback(player, "§a🎒 Кит §f" + kit.displayName + " §aприменён всем ботам!");
            }
            case "clone" -> {
                // !clone [ник] — скопировать снаряжение игрока всем ботам
                String targetNick = (arg != null) ? arg : player.getName().getString();
                if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
                net.minecraft.world.entity.player.Player src = sw.getPlayers(
                    p -> p.getName().getString().equalsIgnoreCase(targetNick)
                ).stream().findFirst().orElse(null);
                if (src == null) {
                    feedback(player, "§cИгрок §f" + targetNick + " §cне найден.");
                    return;
                }
                for (BotEntity bot : bots) BotClone.cloneFrom(bot, src);
                feedback(player, "§b🪞 Боты скопировали снаряжение §f" + src.getName().getString());
            }
            case "swap" -> {
                // !swap — поменять позиции бота и игрока
                if (bots.isEmpty()) {
                    feedback(player, "§cНет активных ботов.");
                    return;
                }
                BotEntity swapBot = bots.get(0); // первый доступный бот
                double px = player.getX(), py = player.getY(), pz = player.getZ();
                double bx = swapBot.getX(), by = swapBot.getY(), bz = swapBot.getZ();
                // Переместить бота на позицию игрока
                swapBot.teleportTo(px, py, pz);
                // Переместить игрока на позицию бота
                player.teleportTo(bx, by, bz);
                feedback(player, "§b🔀 Позиции обменяны с ботом #1!");
            }
            case "battles" -> {
                // !battles — последние 10 боёв из BattleLog
                java.util.List<String> entries = BattleLog.INSTANCE.getRecentEntries();
                if (entries.isEmpty()) {
                    feedback(player, "§7История боёв пуста.");
                    return;
                }
                player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§e§l⚔ Последние бои (" + entries.size() + "):"
                ));
                for (String e : entries) {
                    // Цветовая метка по типу события
                    String colored = e.contains("KILL")   ? "§a" + e
                                   : e.contains("DEATH")  ? "§c" + e
                                   : "§7" + e; // ASSIST
                    player.sendSystemMessage(
                        net.minecraft.network.chat.Component.literal(colored));
                }
            }
            case "suggest" -> {
                // !suggest — подобрать оптимальный кит против текущей цели
                if (bots.isEmpty()) { feedback(player, "§cНет активных ботов."); return; }
                net.minecraft.world.entity.LivingEntity currentTarget = null;
                BotEntity firstBot = bots.get(0);
                if (firstBot.getPvpLogic() != null) {
                    currentTarget = firstBot.getPvpLogic().getCachedEnemy();
                }
                KitSuggester.INSTANCE.suggest(player, bots, currentTarget);
            }
            case "debug" -> {
                // !debug [ai|perf|target] — инспекция состояния AI в реальном времени
                BotDebugCommand.handle(player, arg, bots);
            }
            case "ping" -> {
                // !ping — показать пинг всех игроков в зоне (для дебага предсказания)
                if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
                player.sendSystemMessage(net.minecraft.network.chat.Component.literal("§e§l📶 Пинг игроков:"));
                for (net.minecraft.server.level.ServerPlayer sp : sw.getServer().getPlayerList().getPlayers()) {
                    String pingStr = BotPingTracker.INSTANCE.formatPing(sp.getUUID());
                    int ticks = BotPingTracker.INSTANCE.getPingTicks(sp.getUUID());
                    player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        String.format("  §f%s§7: %s §7(+%d тик предсказания)",
                            sp.getName().getString(), pingStr, ticks)));
                }
            }
            case "elo" -> {
                // !elo — рейтинг ELO бота (побед/поражений)
                feedback(player, "§e" + AdaptiveDifficulty.INSTANCE.getEloString()
                    + " §7| Adaptive: §f" + (AdaptiveDifficulty.INSTANCE.isEnabled() ? "§aON" : "§7OFF"));
            }
            case "heatmap" -> {
                // !heatmap — тепловая карта боёв (урон по зонам карты)
                if (bots.isEmpty()) { feedback(player, "§cНет ботов."); break; }
                for (BotEntity bot : bots) {
                    bot.getHeatMap().sendReport(player);
                }
            }
            case "streak" -> {
                // !streak — текущая серия убийств
                if (bots.isEmpty()) { feedback(player, "§cНет ботов."); break; }
                for (BotEntity bot : bots) {
                    KillStreak ks = bot.getKillStreak();
                    feedback(player, "§f" + bot.getName().getString()
                        + " §7| Серия: §e" + ks.getCurrent()
                        + " §7| Рекорд: §6" + ks.getBest()
                        + " §7| Всего килов: §a" + ks.getTotalKills());
                }
            }
            case "arena" -> {
                // !arena [on|off|center x y z|status] — режим 1v1 арены
                if (bots.isEmpty()) { feedback(player, "§cНет ботов."); break; }
                String sub = arg != null ? arg.toLowerCase() : "status";
                for (BotEntity bot : bots) {
                    BotArenaMode arena = bot.getArenaMode();
                    if (sub.equals("off")) {
                        arena.disable();
                    } else if (sub.equals("on")) {
                        net.minecraft.world.phys.Vec3 pos = player.position();
                        arena.enable(pos, 20);
                        feedback(player, "§aArena включён с центром на вашей позиции (R=20).");
                    } else if (sub.startsWith("center")) {
                        net.minecraft.world.phys.Vec3 pos = player.position();
                        arena.enable(pos, arena.isEnabled() ? arena.getRadius() : 20);
                        feedback(player, "§aЦентр арены обновлён: " + pos);
                    } else {
                        feedback(player, arena.isEnabled()
                            ? "§aArena: ON | " + bot.getArenaMode().getBotWins() + "W/"
                              + bot.getArenaMode().getBotLosses() + "L"
                            : "§7Arena: OFF | !arena on/off");
                    }
                }
            }
            case "react" -> {
                // !react [easy|medium|hard|expert|player] — изменить сложность реакции
                // FIX: теперь ставит per-bot сложность, не глобальную
                if (arg != null) {
                    try {
                        PVPBotConfig.Difficulty d = PVPBotConfig.Difficulty.valueOf(arg.toUpperCase());
                        for (BotEntity bot : bots) {
                            bot.setPerBotDifficulty(d);
                            // applyDifficulty() работает через PVPBotConfig — для per-bot
                            // достаточно просто установить поле; BotDifficultyAI читает его через getEffectiveDifficulty()
                        }
                        feedback(player, "§aСложность изменена (per-bot): §f" + d.name());
                    } catch (IllegalArgumentException e) {
                        feedback(player, "§cНеизвестная сложность: " + arg + ". Варианты: easy medium hard expert player");
                    }
                } else {
                    BotReactionProfile rp = bots.isEmpty() ? null : bots.get(0).getReactionProfile();
                    PVPBotConfig.Difficulty curDiff = bots.isEmpty()
                        ? PVPBotConfig.INSTANCE.difficulty
                        : bots.get(0).getEffectiveDifficulty();
                    String info = rp != null
                        ? "§7текущая: §e" + curDiff.name()
                          + " §7(~" + rp.getBaseReactionMs() + "ms)"
                        : "";
                    feedback(player, "Использование: !react <easy|medium|hard|expert|player> " + info);
                }
            }
            case "tpon" -> {
                // !tpon — включить мгновенный ТП к владельцу
                PVPBotConfig.INSTANCE.tpToOwnerEnabled = true;
                feedback(player, "§aТП к владельцу: §fВКЛ. Бот мгновенно телепортируется к тебе.");
            }
            case "tpoff" -> {
                // !tpoff — выключить ТП, бот следует пешком
                PVPBotConfig.INSTANCE.tpToOwnerEnabled = false;
                feedback(player, "§cТП к владельцу: §fВЫКЛ. Бот идёт пешком.");
            }
            case "agro" -> {
                // !agro — AGGRESSIVE режим: атакует всех, включая владельца (тренировка)
                for (BotEntity bot : bots) bot.setBotMode(BotEntity.BotMode.AGGRESSIVE);
                PVPBotConfig.INSTANCE.standbyMode = false;
                feedback(player, "§c⚔ AGRO режим! Бот атакует ВСЕХ (включая тебя). §f!guard чтобы остановить.");
            }
            case "guard" -> {
                // !guard — обычный GUARD режим: защищает владельца
                for (BotEntity bot : bots) bot.setBotMode(BotEntity.BotMode.GUARD);
                feedback(player, "§a🛡 GUARD режим. Бот защищает тебя и атакует врагов.");
            }
            default -> {
                // Провокации в чат — реагируем агрессией (v1.8.0)
                // Запускаем через BotTauntReact, он сам проверит триггеры
                if (!bots.isEmpty()) {
                    BotTauntReact.INSTANCE.onPlayerMessage(player, cmd + (arg != null ? " " + arg : ""), bots);
                }
            }
        }
    }

    private static void setForcedTargetByName(ServerPlayer player, List<BotEntity> bots, String nick) {
        if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return;
        net.minecraft.world.entity.player.Player target = sw.getPlayers(
            p -> p.getName().getString().equalsIgnoreCase(nick)
        ).stream().findFirst().orElse(null);
        if (target == null) {
            feedback(player, "§cИгрок не найден: §f" + nick);
            return;
        }
        for (BotEntity bot : bots) bot.getTargetPriority().setForcedTarget(target.getUUID());
    }

    private static net.minecraft.world.entity.LivingEntity findNearestEnemy(ServerPlayer player, double range) {
        if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sw)) return null;
        return sw.getPlayers(p ->
            !p.getUUID().equals(player.getUUID()) && !p.isSpectator() && !p.isCreative()
        ).stream()
         .filter(p -> p.distanceTo(player) <= range)
         .min(java.util.Comparator.comparingDouble(p -> p.distanceTo(player)))
         .orElse(null);
    }

    private static void feedback(ServerPlayer player, String msg) {
        player.sendSystemMessage(Component.literal("§e[PVPBot] " + msg));
    }
}
