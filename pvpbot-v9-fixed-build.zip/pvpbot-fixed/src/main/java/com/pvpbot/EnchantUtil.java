package com.pvpbot;

import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * EnchantUtil — утилита для выдачи зачарованных предметов в 1.21.1.
 *
 * В 1.21.x зачарования data-driven и хранятся через RegistryAccess,
 * а не через BuiltInRegistries. Требует RegistryAccess при построении.
 *
 * Использование (из KitEnchant.apply где есть BotEntity):
 *   RegistryAccess ra = bot.level().registryAccess();
 *   ItemStack sword = EnchantUtil.of(Items.DIAMOND_SWORD, ra)
 *       .enchant("sharpness", 5)
 *       .enchant("unbreaking", 3)
 *       .build();
 */
public class EnchantUtil {

    private final ItemStack stack;
    private final RegistryAccess registryAccess;
    private final ItemEnchantments.Mutable enchants = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);

    private EnchantUtil(ItemStack stack, RegistryAccess registryAccess) {
        this.stack = stack;
        this.registryAccess = registryAccess;
    }

    /** Создать билдер для предмета. */
    public static EnchantUtil of(net.minecraft.world.item.Item item, RegistryAccess registryAccess) {
        return new EnchantUtil(new ItemStack(item), registryAccess);
    }

    /** Добавить зачарование по пути (например "protection", "sharpness"). */
    public EnchantUtil enchant(String path, int level) {
        ResourceLocation rl = ResourceLocation.withDefaultNamespace(path);
        ResourceKey<Enchantment> key = ResourceKey.create(Registries.ENCHANTMENT, rl);
        registryAccess.lookup(Registries.ENCHANTMENT)
            .flatMap(reg -> reg.get(key))
            .ifPresent(holder -> enchants.set(holder, level));
        return this;
    }

    /** Собрать готовый ItemStack с зачарованиями. */
    public ItemStack build() {
        stack.set(DataComponents.ENCHANTMENTS, enchants.toImmutable());
        return stack;
    }

    /**
     * Быстрый метод: создать стак с одним зачарованием.
     */
    public static ItemStack single(net.minecraft.world.item.Item item, String enchant, int level, RegistryAccess ra) {
        return of(item, ra).enchant(enchant, level).build();
    }
}
