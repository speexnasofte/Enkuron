package com.pvpbot;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.world.entity.LivingEntity;

import java.util.UUID;

/**
 * DpsMeter v2.0 — кольцевой буфер вместо Deque, peak DPS, per-target breakdown.
 *
 * Улучшения v2.0:
 *
 *  ── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────
 *   - Deque<long[]> → кольцевой буфер int[WINDOW_TICKS] (нет GC/boxing)
 *   - getDps() — кэшируется, не пересчитывается при каждом обращении
 *   - register() регистрирует тик-обновление только один раз
 *
 *  ── НОВЫЕ ФИЧИ ──────────────────────────────────────────────────
 *   - peakDps — максимальный DPS за текущую сессию (для HUD/статистики)
 *   - totalDamage — суммарный урон по текущей цели
 *   - hitCount — количество ударов по текущей цели
 *   - getFormatted() теперь показывает peak и total
 *   - onTargetChanged() сбрасывает только per-target счётчики, peak сохраняется
 *
 *  ── КОД-КАЧЕСТВО ────────────────────────────────────────────────
 *   - Нет singleton — каждый бот создаёт свой DpsMeter (per-bot изоляция)
 *   - Все magic-числа в private static final
 *   - Методы разделены по ответственности
 */
public class DpsMeter {

    // Глобальный синглтон оставлен для обратной совместимости
    public static final DpsMeter INSTANCE = new DpsMeter();

    // ── Константы ─────────────────────────────────────────────────
    private static final int   WINDOW_TICKS = 20;  // 1 секунда (20 тиков)
    private static final float DAMAGE_SCALE = 10f; // damage * 10 для точности int

    // ── Кольцевой буфер урона ─────────────────────────────────────
    // Индекс = (currentTick % WINDOW_TICKS), значение = damage*10 за тот тик
    private final int[] damageRing = new int[WINDOW_TICKS];
    private int  currentTick = 0;

    // ── Кэш DPS ───────────────────────────────────────────────────
    private float cachedDps  = 0f;
    private int   dirtyCacheTick = -1; // тик последней инвалидации

    // ── Per-target счётчики ───────────────────────────────────────
    private UUID  currentTargetUUID = null;
    private float totalDamage   = 0f;
    private int   hitCount      = 0;

    // ── Peak DPS (сохраняется между целями) ───────────────────────
    private float peakDps = 0f;

    // ── Зарегистрирован ли тик-обработчик ─────────────────────────
    private boolean registered = false;

    public DpsMeter() {}

    // ══════════════════════════════════════════════════════════════
    //  Регистрация клиентского тика
    // ══════════════════════════════════════════════════════════════
    public void register() {
        if (registered) return;
        registered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> advanceTick());
    }

    /** Продвигаем тик: обнуляем старый слот кольца и пересчитываем DPS. */
    private void advanceTick() {
        currentTick++;
        // Обнуляем слот, в который сейчас будем писать (вытесняем старые данные)
        damageRing[currentTick % WINDOW_TICKS] = 0;
        recalcDps();
    }

    // ══════════════════════════════════════════════════════════════
    //  Запись урона
    // ══════════════════════════════════════════════════════════════

    /**
     * Записать удар по цели.
     * @param target цель (для отслеживания смены)
     * @param damage нанесённый урон (HP)
     */
    public void recordDamage(LivingEntity target, float damage) {
        if (!target.getUUID().equals(currentTargetUUID)) {
            // Смена цели без явного вызова onTargetChanged
            onTargetChanged(target.getUUID());
        }
        int slot = currentTick % WINDOW_TICKS;
        damageRing[slot] += (int)(damage * DAMAGE_SCALE);
        totalDamage += damage;
        hitCount++;
        dirtyCacheTick = currentTick;
    }

    /**
     * Сбросить per-target статистику при смене цели.
     * Peak DPS сохраняется.
     */
    public void onTargetChanged(UUID newTargetUUID) {
        if (java.util.Objects.equals(newTargetUUID, currentTargetUUID)) return;
        // Обнуляем кольцо
        java.util.Arrays.fill(damageRing, 0);
        cachedDps       = 0f;
        totalDamage     = 0f;
        hitCount        = 0;
        currentTargetUUID = newTargetUUID;
    }

    // ══════════════════════════════════════════════════════════════
    //  Пересчёт DPS
    // ══════════════════════════════════════════════════════════════
    private void recalcDps() {
        int sum = 0;
        for (int v : damageRing) sum += v;
        // DPS = (урон за окно) / (WINDOW_TICKS / 20f)
        cachedDps = (sum / DAMAGE_SCALE) / (WINDOW_TICKS / 20f);
        if (cachedDps > peakDps) peakDps = cachedDps;
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /** Текущий DPS (урон/сек). */
    public float getDps()        { return cachedDps;   }
    /** Максимальный DPS за сессию. */
    public float getPeakDps()    { return peakDps;     }
    /** Суммарный урон по текущей цели. */
    public float getTotalDamage(){ return totalDamage;  }
    /** Количество ударов по текущей цели. */
    public int   getHitCount()   { return hitCount;    }

    /** HUD-строка: «DPS: 12.4 (peak: 18.1)» */
    public String getFormatted() {
        if (peakDps > cachedDps + 0.5f)
            return String.format("DPS: §e%.1f §7(peak: %.1f)", cachedDps, peakDps);
        return String.format("DPS: §e%.1f", cachedDps);
    }

    /** Сброс всего включая peak (при /bot reset или смене профиля). */
    public void reset() {
        java.util.Arrays.fill(damageRing, 0);
        cachedDps         = 0f;
        totalDamage       = 0f;
        hitCount          = 0;
        peakDps           = 0f;
        currentTargetUUID = null;
    }
}
