package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * TankMode — v1.6.1
 *
 * Режим «Танк»: бот игнорирует кайтинг и retreat, прёт напрямую к врагу,
 * атакует любого, кто ударил владельца или стоит ближе всего.
 *
 * Поведение:
 *   1. Находим ближайшего врага (приоритет — кто ударил хозяина)
 *   2. Спринт + навигация прямо на врага
 *   3. Кайтинг, retreat, dodge — принудительно отключены пока tankMode активен
 *   4. Включается/выключается: !tank или через GUI
 *
 * Вызов: TankMode.INSTANCE.tick(bot) из BotEntity.tick() ПЕРЕД PVPBotLogic.tick()
 *
 * FIX B (v1.6.1): priorityTargetUUID, priorityTicks и wasActive были полями
 * синглтона → шарились между всеми ботами. Первый бот сбрасывал приоритет
 * для всех остальных. Состояние перенесено в per-bot BotTankState.
 */
public class TankMode {

    public static final TankMode INSTANCE = new TankMode();

    private static final double SEARCH_RANGE = 32.0;
    private static final double SPRINT_RANGE  = 20.0;

    private TankMode() {}

    // ── Per-bot состояние ─────────────────────────────────────────
    // Ранее эти поля были в синглтоне — первый бот, вызвавший tick(),
    // сбрасывал priorityTicks и wasActive для всех остальных.

    /** Изолированное состояние TankMode для одного бота. */
    public static class BotTankState {
        UUID priorityTargetUUID = null;
        int  priorityTicks      = 0;
        boolean wasActive       = false;
    }

    // ── API для BotEntity ─────────────────────────────────────────

    /**
     * Сообщить что хозяин получил урон от entity.
     * Вызывать из события LivingDamageEvent / hurt игрока.
     * @param state per-bot состояние из BotEntity.tankState
     */
    public void onOwnerHurt(BotTankState state, LivingEntity attacker) {
        if (attacker == null) return;
        state.priorityTargetUUID = attacker.getUUID();
        state.priorityTicks = 200; // держим приоритет 10 секунд
    }

    /**
     * Главный тик TankMode.
     * Вызывать из BotEntity.tick() когда cfg.tankModeEnabled == true.
     * Возвращает true если режим взял управление (PVPBotLogic.tick() пропустить).
     * @param state per-bot состояние из BotEntity.tankState
     */
    public boolean tick(BotEntity bot, BotTankState state) {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (!cfg.tankModeEnabled) { state.wasActive = false; return false; }
        if (!(bot.level() instanceof ServerLevel sw)) return false;

        // FIX #8: AutoChat при первом тике Tank Mode (per-bot)
        if (!state.wasActive) {
            state.wasActive = true;
            AutoChatTaunts.INSTANCE.onTankModeActivated(bot);
        }

        // Уменьшаем таймер приоритета
        if (state.priorityTicks > 0) state.priorityTicks--;
        if (state.priorityTicks <= 0) state.priorityTargetUUID = null;

        // Ищем цель
        LivingEntity target = findTarget(sw, bot, state);

        if (target == null) {
            // Нет врагов — идём к хозяину
            if (bot.getOwner() != null) {
                double distToOwner = bot.distanceTo(bot.getOwner());
                if (distToOwner > 4.0) {
                    bot.getNavigation().moveTo(bot.getOwner(), 1.2);
                } else {
                    bot.getNavigation().stop();
                }
            }
            return true;
        }

        // Устанавливаем цель бота
        bot.setTarget(target);

        double dist = bot.distanceTo(target);

        // Принудительный спринт
        if (!bot.isSprinting() && dist > 2.5) {
            bot.setSprinting(true);
        }

        // Навигация прямо на врага — без страфа, без уклонений
        if (dist > cfg.attackRange) {
            bot.getNavigation().moveTo(target, 1.3);
        } else {
            bot.getNavigation().stop();
            // Атака через стандартный механизм (doHurtTarget)
            bot.doHurtTarget(sw, target);
        }

        return true; // PVPBotLogic.tick() не вызывать
    }

    private LivingEntity findTarget(ServerLevel sw, BotEntity bot, BotTankState state) {
        Player owner = bot.getOwner();

        // Сначала проверяем приоритетную цель (кто ударил хозяина)
        if (state.priorityTargetUUID != null) {
            LivingEntity priority = sw.getEntitiesOfClass(
                LivingEntity.class,
                bot.getBoundingBox().inflate(SEARCH_RANGE),
                e -> e.getUUID().equals(state.priorityTargetUUID) && e.isAlive()
            ).stream().findFirst().orElse(null);
            if (priority != null) return priority;
            // Цель пропала — сбрасываем приоритет
            state.priorityTargetUUID = null;
        }

        // Иначе — ближайший враг в радиусе
        AABB box = bot.getBoundingBox().inflate(SEARCH_RANGE);
        List<LivingEntity> candidates = sw.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != bot
                && e.isAlive()
                && !e.isInvisible()
                // не атакуем хозяина
                && !(owner != null && e instanceof Player p
                     && p.getUUID().equals(owner.getUUID()))
                // не атакуем других ботов того же хозяина
                && !(e instanceof BotEntity other
                     && owner != null
                     && owner.getUUID().equals(
                         other.getOwner() != null ? other.getOwner().getUUID() : null))
        );

        return candidates.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);
    }

    /** Сбросить per-bot состояние (например при смене режима). */
    public void reset(BotTankState state) {
        state.priorityTargetUUID = null;
        state.priorityTicks = 0;
        state.wasActive = false;
    }

    /**
     * FIX B: сброс состояния для ВСЕХ активных ботов.
     * Вызывается при глобальном отключении TankMode (команда, GUI).
     * Заменяет старый no-arg reset() который ничего не делал.
     */
    public void resetAll() {
        com.pvpbot.SpawnBotCommand.getAllBots().forEach(b -> reset(b.tankState));
    }
}
