package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

import java.util.*;

/**
 * BotTauntReact v1.0 — бот реагирует на таунты игроков в чате.
 *
 * Когда игрок говорит "ez", "skill issue", "noob" и т.п. — бот
 * меняет стратегию боя (становится агрессивнее, использует BAIT_STOP
 * чаще, увеличивает DPS) и посылает ответ в чат.
 *
 * Поведение:
 *  - Пассивное: бот молчит и играет нормально
 *  - Triggered (после тaunта): +15% агрессии, более частые W-tap,
 *    усиленный страф, ответ в чат
 *  - Cooldown между реакциями: 60 секунд
 *
 * Интеграция:
 *   BotTauntReact.INSTANCE.onPlayerMessage(player, message, bots);
 *   // В тике PVPBotLogic:
 *   if (BotTauntReact.INSTANCE.isTriggered(bot)) { ... усиленная логика ... }
 */
public class BotTauntReact {

    public static final BotTauntReact INSTANCE = new BotTauntReact();

    // ── Таунт-словарь ─────────────────────────────────────────────
    private static final List<String> TAUNT_TRIGGERS = List.of(
        "ez", "easy", "noob", "trash", "bot", "skill issue",
        "bad", "lmao", "cope", "ratio", "L", "loser", "clown"
    );

    // ── Ответы бота ───────────────────────────────────────────────
    private static final String[] BOT_RESPONSES = {
        "Интересно. Посмотрим кто смеётся последним.",
        "Запомни этот момент.",
        "Хорошо, я слышал тебя.",
        "Продолжай говорить.",
        "Статистика запомнит это.",
        "Адаптирую тактику.",
        ":)"
    };

    // ── Константы ─────────────────────────────────────────────────
    private static final int TRIGGERED_DURATION = 200; // тиков (~10 сек)
    private static final int REACT_COOLDOWN     = 1200; // тиков (60 сек)

    // ── Состояние ─────────────────────────────────────────────────
    private final Map<UUID, Integer> triggeredBots = new HashMap<>(); // botUUID → tiksLeft
    private int cooldownTimer = 0;
    private final Random rnd  = new Random();

    private BotTauntReact() {}

    // ══════════════════════════════════════════════════════════════
    //  Обработка сообщения в чате
    // ══════════════════════════════════════════════════════════════

    public void onPlayerMessage(ServerPlayer player, String message, List<BotEntity> bots) {
        if (cooldownTimer > 0) return;
        String lower = message.toLowerCase(Locale.ROOT);
        boolean isTaunt = TAUNT_TRIGGERS.stream().anyMatch(lower::contains);
        if (!isTaunt) return;

        // Триггерим ботов которые сейчас дерутся с этим игроком
        boolean anyTriggered = false;
        for (BotEntity bot : bots) {
            LivingEntity target = bot.getPvpLogic() != null
                ? bot.getPvpLogic().getCachedEnemy() : null;
            if (target != null && target.getUUID().equals(player.getUUID())) {
                triggeredBots.put(bot.getUUID(), TRIGGERED_DURATION);
                anyTriggered = true;
            }
        }

        if (anyTriggered) {
            cooldownTimer = REACT_COOLDOWN;
            // Один из ботов отвечает в чат (первый triggered)
            bots.stream()
                .filter(b -> triggeredBots.containsKey(b.getUUID()))
                .findFirst()
                .ifPresent(b -> {
                    String response = BOT_RESPONSES[rnd.nextInt(BOT_RESPONSES.length)];
                    b.getServer().getPlayerList().broadcastSystemMessage(
                        net.minecraft.network.chat.Component.literal(
                            "§7[" + b.getName().getString() + "] §f" + response), false);
                });
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик (вызывать из серверного тика)
    // ══════════════════════════════════════════════════════════════

    public void tick() {
        if (cooldownTimer > 0) cooldownTimer--;
        triggeredBots.replaceAll((uuid, ticks) -> ticks - 1);
        triggeredBots.entrySet().removeIf(e -> e.getValue() <= 0);
    }

    // ══════════════════════════════════════════════════════════════
    //  API для PVPBotLogic
    // ══════════════════════════════════════════════════════════════

    /** Возвращает true если бот «triggered» — усиленная агрессия. */
    public boolean isTriggered(BotEntity bot) {
        return triggeredBots.getOrDefault(bot.getUUID(), 0) > 0;
    }

    /**
     * Модификатор кулдауна атаки в triggered-режиме.
     * @return 0.85f — бот атакует на 15% чаще
     */
    public float getAttackCooldownMult(BotEntity bot) {
        return isTriggered(bot) ? 0.85f : 1.0f;
    }

    /** Получить оставшиеся тики triggered-состояния. */
    public int getTriggeredTicks(BotEntity bot) {
        return triggeredBots.getOrDefault(bot.getUUID(), 0);
    }
}
