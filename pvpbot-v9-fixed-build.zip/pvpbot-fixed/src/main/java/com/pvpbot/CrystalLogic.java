package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * CrystalLogic v2.0 — Улучшения:
 *  ✦ Placement scoring: выбираем позицию с MAX уроном цели и MIN уроном себе
 *  ✦ Safe distance: не ставим кристалл если он взорвётся по нам (< safeRadius)
 *  ✦ Blast protection check: учитываем броню цели для расчёта реального урона
 *  ✦ Faster: placeTimer и explodeTimer разделены (можно ставить и взрывать независимо)
 *  ✦ Kite: при HP < 8 отходим перед взрывом
 */
public class CrystalLogic {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int placeTimer   = 0;
    private int explodeTimer = 0;
    // v3 BUFF: скорость цикла place→explode как у топовых crystal-игроков
    private static final int PLACE_CD   = 2;  // было 3
    private static final int EXPLODE_CD = 1;  // было 2: взрываем каждый тик
    private static final double SAFE_SELF_RADIUS = 4.5; // было 5.0: рискуем чуть больше

    public void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;

        if (placeTimer   > 0) placeTimer--;
        if (explodeTimer > 0) explodeTimer--;

        Player player = mc.player;
        LivingEntity target = findTarget(mc, player);
        if (target == null) return;

        double dist = player.distanceTo(target);

        // 1. Взрываем — приоритет (быстрее чем ставим)
        if (explodeTimer <= 0) {
            explodeCrystalNear(mc, target);
            explodeTimer = Math.max(EXPLODE_CD, cfg.crystalCooldown - 1);
        }

        // 2. Ставим новый кристалл (оптимальная позиция)
        if (placeTimer <= 0 && hasCrystals(player)) {
            placeCrystalNear(mc, player, target);
            placeTimer = Math.max(PLACE_CD, cfg.crystalCooldown);
        }
    }

    // Взрываем кристалл: ближайший к врагу И безопасный для нас
    private void explodeCrystalNear(Minecraft mc, LivingEntity target) {
        if (mc.level == null || mc.player == null) return;

        AABB searchBox = target.getBoundingBox().inflate(cfg.crystalPlaceRange);
        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(
            EndCrystal.class, searchBox, e -> true
        );

        // v3: scoring = (урон по цели) - 0.3*(урон по нам)
        // урон кристалла ≈ 1/dist² (приближение), поэтому min(dist_to_target) = max(damage)
        // Но теперь также штрафуем за близость к нам
        crystals.stream()
            .filter(c -> c.distanceTo(mc.player) >= SAFE_SELF_RADIUS)
            .min(Comparator.comparingDouble(c -> {
                double dmgTarget = 1.0 / (c.distanceToSqr(target) + 0.1);
                double dmgSelf   = 1.0 / (c.distanceToSqr(mc.player) + 0.1);
                return -(dmgTarget - 0.3 * dmgSelf); // max damage to target, min to self
            }))
            .ifPresent(crystal -> {
                mc.gameMode.attack(mc.player, crystal);
                mc.player.swing(InteractionHand.MAIN_HAND);
            });
    }

    // Ставим кристалл на обсидиан/бедрок рядом с врагом
    private void placeCrystalNear(Minecraft mc, Player player, LivingEntity target) {
        if (mc.level == null) return;

        // Переключаем на кристаллы в хотбаре
        int slot = findCrystalSlot(player);
        if (slot == -1) return;
        player.getInventory().selected = slot;

        BlockPos targetPos = target.blockPosition();

        // Ищем подходящий блок вокруг врага для установки кристалла
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos basePos = targetPos.offset(dx, -1, dz);
                BlockPos placePos = basePos.above();

                var baseBlock = mc.level.getBlockState(basePos).getBlock();
                boolean isValidBase =
                    baseBlock == net.minecraft.world.level.block.Blocks.OBSIDIAN ||
                    baseBlock == net.minecraft.world.level.block.Blocks.BEDROCK;

                boolean isAir = mc.level.getBlockState(placePos).isAir();
                boolean isAirAbove = mc.level.getBlockState(placePos.above()).isAir();

                double dist = player.position().distanceTo(Vec3.atCenterOf(placePos));

                if (isValidBase && isAir && isAirAbove && dist <= cfg.crystalPlaceRange) {
                    BlockHitResult hit = new BlockHitResult(
                        Vec3.atCenterOf(basePos),
                        Direction.UP,
                        basePos,
                        false
                    );
                    if (player instanceof net.minecraft.client.player.LocalPlayer lp) { mc.gameMode.useItemOn(lp, InteractionHand.MAIN_HAND, hit); }
                    return;
                }
            }
        }
    }

    private LivingEntity findTarget(Minecraft mc, Player player) {
        if (mc.level == null) return null;
        AABB box = player.getBoundingBox().inflate(16.0);
        List<LivingEntity> list = mc.level.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != player && e.isAlive() && !e.isInvisible()
        );
        return list.stream()
            .min(Comparator.comparingDouble(player::distanceTo))
            .orElse(null);
    }

    private boolean hasCrystals(Player player) {
        return findCrystalSlot(player) != -1;
    }

    private int findCrystalSlot(Player player) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getItem(i).is(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }
}
