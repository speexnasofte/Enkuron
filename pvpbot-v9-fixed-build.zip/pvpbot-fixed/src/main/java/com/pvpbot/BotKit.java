package com.pvpbot;

import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.nbt.CompoundTag;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * BotKit v4.0 — MCTiers 1:1 точные киты.
 *
 * НОВОЕ v4.0:
 *  - applyToPlayer() — выдаёт реальные предметы игроку в инвентарь
 *  - Полные MCTiers инвентари: зелья, тотемы, кристаллы, опыт, блоки
 *  - inventory — список доп. предметов (хотбар + инвентарь)
 */
public enum BotKit {

    // ─────────────────────────────────────────────────────────────
    // SWORD — MCTiers Sword PvP
    // Броня: Diamond Prot4 Unb3 | Меч: Diamond Sharp5 Unb3
    // Инвентарь: Зелья лечения, зелья скорости, гэплы, жемчуг
    // ─────────────────────────────────────────────────────────────
    SWORD("sword", "Sword PvP",
        new KitEquipment(
            Items.DIAMOND_SWORD, null,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).build());
            }
        ),
        // Инвентарь MCTiers Sword: меч, зелья лечения×9, скорость×9, гэпл×8, жемчуг×16
        List.of(
            new InvItem(Items.DIAMOND_SWORD, 1, "sharpness:5,unbreaking:3"),
            new InvItem(Items.SPLASH_POTION, 9, "healing2"), // рядами
            new InvItem(Items.SPLASH_POTION, 9, "speed2"),
            new InvItem(Items.GOLDEN_APPLE, 8, null),
            new InvItem(Items.ENDER_PEARL, 16, null)
        ), "pvp"),

    // ─────────────────────────────────────────────────────────────
    // AXE — MCTiers Axe PvP
    // Броня: Diamond БЕЗ зачарований | Топор: Diamond Sharp5 Eff5 Unb3
    // Offhand: Щит | Инвентарь: топор, щит, лук, стрелы×5
    // ─────────────────────────────────────────────────────────────
    AXE("axe", "Axe PvP",
        new KitEquipment(
            Items.DIAMOND_AXE, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("efficiency",5).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,  new ItemStack(hel));
                bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(chest));
                bot.setItemSlot(EquipmentSlot.LEGS,  new ItemStack(legs));
                bot.setItemSlot(EquipmentSlot.FEET,  new ItemStack(bts));
            }
        ),
        List.of(
            new InvItem(Items.DIAMOND_AXE, 1, "sharpness:5,efficiency:5,unbreaking:3"),
            new InvItem(Items.SHIELD, 1, null),
            new InvItem(Items.BOW, 1, "power:5,unbreaking:3,infinity:1"),
            new InvItem(Items.ARROW, 5, null)
        ), "axe"),

    // ─────────────────────────────────────────────────────────────
    // POT — MCTiers Diamond Pot
    // Броня: Diamond Prot4 Unb3 | Меч: Diamond Sharp5 Unb3
    // Инвентарь: зелья лечения полный инвентарь (как на скрине - все красные)
    // ─────────────────────────────────────────────────────────────
    POT("pot", "Diamond Pot",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.SPLASH_POTION,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, makeSplashPotion("healing2"));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).build());
            }
        ),
        // MCTiers Pot: меч, полный инвентарь зелий лечения (красные), несколько синих (скорость)
        List.of(
            new InvItem(Items.DIAMOND_SWORD, 1, "sharpness:5,unbreaking:3"),
            new InvItem(Items.SPLASH_POTION, 18, "healing2"), // 18 зелий лечения
            new InvItem(Items.SPLASH_POTION, 9, "speed2"),    // 9 зелий скорости
            new InvItem(Items.SPLASH_POTION, 1, "strength2")  // 1 зелье силы
        ), "nethpot"),

    // ─────────────────────────────────────────────────────────────
    // UHC — MCTiers UHC
    // Броня: Diamond Prot3/2 | Меч Sharp3 | Лук Power5
    // Инвентарь: меч, гэпл×2, golden head×2, ведро, дерево×64, лук, стрелы×64
    // ─────────────────────────────────────────────────────────────
    UHC("uhc", "UHC",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.BOW,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",3).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND,
                    EnchantUtil.of(off, ra).enchant("power",5).enchant("unbreaking",3).enchant("infinity",1).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",3).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",2).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",2).enchant("unbreaking",3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",3).enchant("unbreaking",3).enchant("feather_falling",4).build());
            }
        ),
        // MCTiers UHC инвентарь (со скрина): меч, гэпл×2, golden head×2, ведро, дерево×64, лук, стрелы×64
        List.of(
            new InvItem(Items.DIAMOND_SWORD, 1, "sharpness:3,unbreaking:3"),
            new InvItem(Items.GOLDEN_APPLE, 2, null),
            new InvItem(Items.PLAYER_HEAD, 2, null),   // golden head
            new InvItem(Items.WATER_BUCKET, 1, null),
            new InvItem(Items.OAK_LOG, 64, null),
            new InvItem(Items.BOW, 1, "power:5,unbreaking:3,infinity:1"),
            new InvItem(Items.ARROW, 64, null)
        ), "uhc"),

    // ─────────────────────────────────────────────────────────────
    // NETHOP / NETHPOT — NethOP (алиасы)
    // Броня: Netherite Prot4 Unb3 Mend | Меч Sharp5 Unb3 Mend + Тотем
    // ─────────────────────────────────────────────────────────────
    NETHOP("nethop", "NethOP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.NETHERITE_SWORD, 1, "sharpness:5,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 8, null),
            new InvItem(Items.SPLASH_POTION, 9, "healing2"),
            new InvItem(Items.GOLDEN_APPLE, 4, null),
            new InvItem(Items.ENDER_PEARL, 16, null)
        ), "nethpot"),

    NETHPOT("nethpot", "NethPot",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.NETHERITE_SWORD, 1, "sharpness:5,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 8, null),
            new InvItem(Items.SPLASH_POTION, 9, "healing2"),
            new InvItem(Items.GOLDEN_APPLE, 4, null),
            new InvItem(Items.ENDER_PEARL, 16, null)
        ), "nethpot"),

    // ─────────────────────────────────────────────────────────────
    // SMP — MCTiers SMP
    // Броня: Netherite Prot4 Unb3 Mend | Меч Sharp5 KB2 FA2 + Тотем
    // ─────────────────────────────────────────────────────────────
    SMP("smp", "SMP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("knockback",2).enchant("fire_aspect",2).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.NETHERITE_SWORD, 1, "sharpness:5,knockback:2,fire_aspect:2,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 4, null),
            new InvItem(Items.GOLDEN_APPLE, 16, null),
            new InvItem(Items.ENDER_PEARL, 16, null),
            new InvItem(Items.SPLASH_POTION, 8, "healing2"),
            new InvItem(Items.OBSIDIAN, 16, null)
        ), "smp"),

    // ─────────────────────────────────────────────────────────────
    // CRYSTAL — MCTiers Crystal PvP (со скрина: зелья×16 рядами, кристаллы, тотемы)
    // Броня: Neth Prot4 шлем/нагр | BlastProt4 ноги/боты
    // Инвентарь: тотем×1 оффхенд, кристаллы×64×3 ряда, зелья×16, гэпл×64, обсидиан×64
    // ─────────────────────────────────────────────────────────────
    CRYSTAL("crystal", "Crystal PvP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("knockback",1).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("blast_protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("blast_protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        // Crystal инвентарь: кристаллы×64 ряды, тотемы, зелья, гэплы, обсидиан
        List.of(
            new InvItem(Items.NETHERITE_SWORD, 1, "sharpness:5,knockback:1,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 4, null),
            new InvItem(Items.END_CRYSTAL, 64, null),
            new InvItem(Items.END_CRYSTAL, 64, null),
            new InvItem(Items.END_CRYSTAL, 64, null),
            new InvItem(Items.OBSIDIAN, 64, null),
            new InvItem(Items.SPLASH_POTION, 16, "healing2"),
            new InvItem(Items.GOLDEN_APPLE, 64, null),
            new InvItem(Items.ENDER_PEARL, 16, null)
        ), "crystal"),

    // ─────────────────────────────────────────────────────────────
    // MACE — MCTiers Mace PvP (со скрина: опыт×64?, гэпл×64, элитры, тотем, посохи ветра×64, булава)
    // Броня: Netherite Prot4 | Нагрудник = Элитры
    // ─────────────────────────────────────────────────────────────
    MACE("mace", "Mace PvP",
        new KitEquipment(
            Items.MACE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("density",5).enchant("breach",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST, EnchantUtil.of(chest, ra).enchant("unbreaking",3).enchant("mending",1).build()); // элитры
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        // Mace инвентарь (со скрина): булава, тотемы×1 оффхенд, посохи ветра×64, гэпл×64, зелья опыта, элитры запас
        List.of(
            new InvItem(Items.MACE, 1, "density:5,breach:4,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 4, null),
            new InvItem(Items.WIND_CHARGE, 64, null),
            new InvItem(Items.WIND_CHARGE, 64, null),
            new InvItem(Items.GOLDEN_APPLE, 64, null),
            new InvItem(Items.ENDER_PEARL, 16, null),
            new InvItem(Items.EXPERIENCE_BOTTLE, 64, null),
            new InvItem(Items.NETHERITE_SWORD, 1, "sharpness:5,unbreaking:3,mending:1"),
            new InvItem(Items.ELYTRA, 1, "mending:1,unbreaking:3")
        ), "mace"),

    // ─────────────────────────────────────────────────────────────
    // MACE_ELYTRA — отдельный стиль (нагрудник = элитры, летающий стиль)
    // ─────────────────────────────────────────────────────────────
    MACE_ELYTRA("mace_elytra", "Mace+Elytra",
        new KitEquipment(
            Items.MACE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("density",5).enchant("breach",4).enchant("unbreaking",3).enchant("wind_burst",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.MACE, 1, "density:5,breach:4,unbreaking:3,wind_burst:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 4, null),
            new InvItem(Items.WIND_CHARGE, 64, null),
            new InvItem(Items.WIND_CHARGE, 64, null),
            new InvItem(Items.GOLDEN_APPLE, 64, null),
            new InvItem(Items.ENDER_PEARL, 16, null)
        ), "mace"),

    // ─────────────────────────────────────────────────────────────
    // TPC — TPC (Totem/Pearl/Crystal)
    // Netherite Prot4 + Netherite Axe Sharp5 + Tot + Crystal
    // ─────────────────────────────────────────────────────────────
    TPC("tpc", "TPC",
        new KitEquipment(
            Items.NETHERITE_AXE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("efficiency",5).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("blast_protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("blast_protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.NETHERITE_AXE, 1, "sharpness:5,efficiency:5,unbreaking:3,mending:1"),
            new InvItem(Items.TOTEM_OF_UNDYING, 4, null),
            new InvItem(Items.END_CRYSTAL, 64, null),
            new InvItem(Items.END_CRYSTAL, 64, null),
            new InvItem(Items.OBSIDIAN, 64, null),
            new InvItem(Items.ENDER_PEARL, 16, null),
            new InvItem(Items.GOLDEN_APPLE, 16, null)
        ), "crystal"),

    // ─────────────────────────────────────────────────────────────
    // SNOWBALL — Snowball Kit
    // ─────────────────────────────────────────────────────────────
    SNOWBALL("snowball", "Snowball",
        new KitEquipment(
            Items.SNOWBALL, null,
            Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE,
            Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(main, 16));
                bot.setItemSlot(EquipmentSlot.HEAD,  new ItemStack(hel));
                bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(chest));
                bot.setItemSlot(EquipmentSlot.LEGS,  new ItemStack(legs));
                bot.setItemSlot(EquipmentSlot.FEET,  new ItemStack(bts));
            }
        ),
        List.of(new InvItem(Items.SNOWBALL, 64, null), new InvItem(Items.SNOWBALL, 64, null)),
        "pvp"),

    TOTEM("totem", "Totem",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(new InvItem(Items.TOTEM_OF_UNDYING, 16, null), new InvItem(Items.GOLDEN_APPLE, 8, null)),
        "nethpot"),

    TRIDENT("trident", "Trident",
        new KitEquipment(
            Items.TRIDENT, null,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("riptide",3).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(new InvItem(Items.TRIDENT, 1, "riptide:3,unbreaking:3,mending:1")),
        "pvp"),

    BEEHIVE("beehive", "Beehive",
        new KitEquipment(
            Items.NETHERITE_SWORD, null,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("sharpness",5).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(new InvItem(Items.BEE_SPAWN_EGG, 16, null), new InvItem(Items.BEEHIVE, 8, null)),
        "pvp"),

    FIREWORK("firework", "Firework",
        new KitEquipment(
            Items.CROSSBOW, Items.FIREWORK_ROCKET,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("quick_charge",3).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.FIREWORK_ROCKET, 64));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(Items.ELYTRA, ra).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.CROSSBOW, 1, "quick_charge:3,unbreaking:3,mending:1"),
            new InvItem(Items.FIREWORK_ROCKET, 64, null),
            new InvItem(Items.FIREWORK_ROCKET, 64, null)
        ), "pvp"),

    CROSSBOW("crossbow", "Crossbow",
        new KitEquipment(
            Items.CROSSBOW, null,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra).enchant("quick_charge",3).enchant("multishot",1).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());
            }
        ),
        List.of(
            new InvItem(Items.CROSSBOW, 1, "quick_charge:3,multishot:1,unbreaking:3,mending:1"),
            new InvItem(Items.ARROW, 64, null)
        ), "pvp");

    // ─────────────────────────────────────────────────────────────
    //  ПОЛЯ
    // ─────────────────────────────────────────────────────────────
    public final String id;
    public final String displayName;
    public final KitEquipment equipment;
    public final List<InvItem> inventory;
    public final String profileName;

    BotKit(String id, String displayName, KitEquipment equipment, List<InvItem> inventory, String profileName) {
        this.id          = id;
        this.displayName = displayName;
        this.equipment   = equipment;
        this.inventory   = inventory;
        this.profileName = profileName;
    }

    public static BotKit byId(String id) {
        for (BotKit kit : values())
            if (kit.id.equalsIgnoreCase(id)) return kit;
        return null;
    }

    public static String listIds() {
        StringBuilder sb = new StringBuilder();
        for (BotKit kit : values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(kit.id);
        }
        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────
    //  Применить кит к ИГРОКУ — даём броню + инвентарь
    // ─────────────────────────────────────────────────────────────
    public void applyToPlayer(ServerPlayer player) {
        RegistryAccess ra = player.level().registryAccess();
        // Очищаем инвентарь и броню
        player.getInventory().clearContent();

        // Броня — та же что у бота
        if (equipment.helmet != null)
            player.setItemSlot(EquipmentSlot.HEAD,
                EnchantUtil.of(equipment.helmet, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (equipment.chestplate != null) {
            if (equipment.chestplate == Items.ELYTRA)
                player.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(Items.ELYTRA, ra).enchant("unbreaking",3).enchant("mending",1).build());
            else
                player.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(equipment.chestplate, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        }
        if (equipment.leggings != null)
            player.setItemSlot(EquipmentSlot.LEGS,
                EnchantUtil.of(equipment.leggings, ra).enchant("protection",4).enchant("unbreaking",3).enchant("mending",1).build());
        if (equipment.boots != null)
            player.setItemSlot(EquipmentSlot.FEET,
                EnchantUtil.of(equipment.boots, ra).enchant("protection",4).enchant("unbreaking",3).enchant("feather_falling",4).enchant("mending",1).build());

        // Предметы инвентаря — раскладываем по хотбару и инвентарю
        int slot = 0;
        for (InvItem item : inventory) {
            if (slot >= 36) break; // инвентарь полный
            ItemStack stack = buildInvStack(item, ra);
            // Раскладываем стаки по 64 в несколько слотов если нужно
            int remaining = item.count;
            while (remaining > 0 && slot < 36) {
                int stackSize = Math.min(remaining, stack.getItem().getDefaultMaxStackSize());
                ItemStack s = stack.copyWithCount(stackSize);
                player.getInventory().setItem(slot, s);
                remaining -= stackSize;
                slot++;
            }
        }

        // Оффхенд
        if (equipment.offhand != null)
            // Offhand: зелья выдаём правильно через PotionContents
            if (equipment.offhand == Items.SPLASH_POTION)
                player.setItemSlot(EquipmentSlot.OFFHAND, makeSplashPotion("healing2"));
            else
                player.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(equipment.offhand));

        // Эффект сытости
        player.getFoodData().eat(20, 20f);

        // ── PvP-бафы по типу кита ──────────────────────────────────
        applyKitEffects(player);
    }

    /**
     * Накладывает активные PvP-эффекты на игрока в зависимости от кита.
     * Все эффекты длятся 5 минут и не видны на экране (ambient=true).
     */
    private void applyKitEffects(ServerPlayer player) {
        // Убираем старые бафы перед выдачей новых
        player.removeEffect(MobEffects.MOVEMENT_SPEED);
        player.removeEffect(MobEffects.DAMAGE_BOOST);
        player.removeEffect(MobEffects.REGENERATION);
        player.removeEffect(MobEffects.ABSORPTION);
        player.removeEffect(MobEffects.FIRE_RESISTANCE);

        int duration = 6000; // 5 минут в тиках

        switch (this) {
            case SWORD -> {
                // Sword: Скорость I для лучшего W-tap
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
            }
            case AXE -> {
                // Axe: Скорость I
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
            }
            case POT -> {
                // Pot: Скорость II + Огнестойкость
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case UHC -> {
                // UHC: нет активных зелий (пьёт гэплы)
            }
            case NETHOP, NETHPOT -> {
                // NethOP/NethPot: Скорость II + Огнестойкость + Регенерация
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 0, true, false));
            }
            case SMP -> {
                // SMP: Скорость I + Огнестойкость
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case CRYSTAL -> {
                // Crystal: Скорость II + Огнестойкость (нужна для кристального PvP)
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case SNOWBALL -> {
                // Snowball: Скорость II (нужно быстро бегать и кидать)
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
            }
            case TOTEM -> {
                // Totem: Огнестойкость + Поглощение
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, duration, 1, true, false));
            }
            case TRIDENT -> {
                // Trident: Скорость I + Огнестойкость
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case MACE, MACE_ELYTRA -> {
                // Mace: Огнестойкость (прыжки с элитрой)
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case BEEHIVE -> {
                // Beehive: Скорость I
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
            }
            case FIREWORK -> {
                // Firework: Скорость II (мобильный кит)
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
            }
            case CROSSBOW -> {
                // Crossbow: Скорость I + Огнестойкость
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
            }
            case TPC -> {
                // TPC: Скорость II + Огнестойкость + Регенерация
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, duration, 0, true, false));
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 0, true, false));
            }
            default -> {
                // Для кастомных китов — Скорость I базово
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 0, true, false));
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Создать ItemStack для зелья через PotionContents (MC 1.21.4)
    // ─────────────────────────────────────────────────────────────
    public static ItemStack makeSplashPotion(String potionId) {
        ItemStack stack = new ItemStack(Items.SPLASH_POTION, 1);
        PotionContents contents = switch (potionId) {
            case "healing2"  -> new PotionContents(Optional.of(Potions.STRONG_HEALING), Optional.empty(), List.of(), Optional.empty());
            case "healing"   -> new PotionContents(Optional.of(Potions.HEALING), Optional.empty(), List.of(), Optional.empty());
            case "speed2"    -> new PotionContents(Optional.of(Potions.STRONG_SWIFTNESS), Optional.empty(), List.of(), Optional.empty());
            case "speed"     -> new PotionContents(Optional.of(Potions.SWIFTNESS), Optional.empty(), List.of(), Optional.empty());
            case "strength2" -> new PotionContents(Optional.of(Potions.STRONG_STRENGTH), Optional.empty(), List.of(), Optional.empty());
            case "strength"  -> new PotionContents(Optional.of(Potions.STRENGTH), Optional.empty(), List.of(), Optional.empty());
            case "regen2"    -> new PotionContents(Optional.of(Potions.STRONG_REGENERATION), Optional.empty(), List.of(), Optional.empty());
            case "regen"     -> new PotionContents(Optional.of(Potions.REGENERATION), Optional.empty(), List.of(), Optional.empty());
            case "poison2"   -> new PotionContents(Optional.of(Potions.STRONG_POISON), Optional.empty(), List.of(), Optional.empty());
            case "slowness"  -> new PotionContents(Optional.of(Potions.SLOWNESS), Optional.empty(), List.of(), Optional.empty());
            case "weakness"  -> new PotionContents(Optional.of(Potions.WEAKNESS), Optional.empty(), List.of(), Optional.empty());
            default          -> new PotionContents(Optional.of(Potions.HEALING), Optional.empty(), List.of(), Optional.empty());
        };
        stack.set(DataComponents.POTION_CONTENTS, contents);
        return stack;
    }

    private ItemStack buildInvStack(InvItem item, RegistryAccess ra) {
        if (item.enchants == null || item.enchants.isEmpty())
            return new ItemStack(item.item, Math.min(item.count, item.item.getDefaultMaxStackSize()));

        // Зелья — правильно через PotionContents (MC 1.21.4)
        if (item.item == Items.SPLASH_POTION || item.item == Items.POTION || item.item == Items.LINGERING_POTION) {
            return makeSplashPotion(item.enchants);
        }

        // Предметы с зачарованиями
        var b = EnchantUtil.of(item.item, ra);
        for (String part : item.enchants.split(",")) {
            String[] kv = part.split(":");
            if (kv.length == 2) {
                try { b.enchant(kv[0].trim(), Integer.parseInt(kv[1].trim())); }
                catch (Exception ignored) {}
            }
        }
        return b.build();
    }

    // ─────────────────────────────────────────────────────────────
    //  KitEquipment
    // KitEquipment, InvItem, KitEnchant — вынесены в отдельные файлы
}
