package com.pvpbot.cmd;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.pvpbot.*;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * /bot kit ... — управление китами ботов.
 * Вынесено из SpawnBotCommand.
 */
public final class BotKitCommands {

    private BotKitCommands() {}

    /** Кастомные киты: ключ "ownerUUID:kitName" → snapshot инвентаря. */
    private static final java.util.Map<String, List<ItemStack>> customKits = new java.util.HashMap<>();

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("kit")
            .executes(ctx -> listKits(ctx.getSource()))
            .then(Commands.literal("save")
                .then(Commands.argument("saveName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> saveCustomKit(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "saveName"))))
                .executes(ctx -> saveCustomKit(ctx.getSource(), "mykit"))
            )
            .then(Commands.literal("load")
                .then(Commands.argument("loadName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> loadCustomKit(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "loadName"))))
            )
            .then(Commands.literal("list").executes(ctx -> listCustomKits(ctx.getSource())))
            .then(Commands.literal("delete")
                .then(Commands.argument("delName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> deleteCustomKit(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "delName"))))
            )
            .then(Commands.literal("rename")
                .then(Commands.argument("oldName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .then(Commands.argument("newName",
                        com.mojang.brigadier.arguments.StringArgumentType.word())
                        .executes(ctx -> renameCustomKit(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "oldName"),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "newName")))))
            )
            .then(Commands.literal("setdefault")
                .then(Commands.argument("defaultKitName",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String kn = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "defaultKitName");
                        PVPBotConfig.INSTANCE.spawnDefaultKit = kn;
                        BotConfig.save();
                        feedback(ctx.getSource(), "Спавн-кит: " + kn);
                        return 1;
                    }))
                .executes(ctx -> {
                    PVPBotConfig.INSTANCE.spawnDefaultKit = "";
                    BotConfig.save();
                    feedback(ctx.getSource(), "Спавн-кит сброшен.");
                    return 1;
                })
            )
            .then(Commands.argument("kitName",
                com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> applyKit(ctx.getSource(),
                    com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "kitName")))
            );
    }

    // ── Публичные методы для SpawnBotCommand ────────────────────

    /** Применить кастомный кит к боту при спавне (используется из SpawnBotCommand). */
    public static void applyCustomKitToBotEntity(BotEntity bot, List<ItemStack> snapshot,
                                                  net.minecraft.core.RegistryAccess ra) {
        if (snapshot.size() > 36) bot.setItemSlot(EquipmentSlot.HEAD,    snapshot.get(36).copy());
        if (snapshot.size() > 37) bot.setItemSlot(EquipmentSlot.CHEST,   snapshot.get(37).copy());
        if (snapshot.size() > 38) bot.setItemSlot(EquipmentSlot.LEGS,    snapshot.get(38).copy());
        if (snapshot.size() > 39) bot.setItemSlot(EquipmentSlot.FEET,    snapshot.get(39).copy());
        if (snapshot.size() > 40) bot.setItemSlot(EquipmentSlot.OFFHAND, snapshot.get(40).copy());
        for (int i = 0; i < Math.min(9, snapshot.size()); i++) {
            if (!snapshot.get(i).isEmpty()) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, snapshot.get(i).copy());
                break;
            }
        }
    }

    /** Получить in-memory map кастомных китов (для совместимости со SpawnBotCommand). */
    public static java.util.Map<String, List<ItemStack>> getCustomKits() { return customKits; }

    // ── Реализации ────────────────────────────────────────────────

    private static int listKits(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        StringBuilder sb = new StringBuilder("Встроенные киты:\n");
        for (BotKit kit : BotKit.values())
            sb.append(kit.id).append(" — ").append(kit.displayName).append("\n");
        sb.append("Использование: /bot kit <название>\n\n");
        String prefix = player.getUUID() + ":";
        List<String> custom = new ArrayList<>();
        customKits.keySet().stream().filter(k -> k.startsWith(prefix))
                  .forEach(k -> custom.add(k.substring(prefix.length())));
        if (!custom.isEmpty())
            sb.append("Твои кастомные киты: ").append(String.join(", ", custom)).append("\n");
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    private static int applyKit(CommandSourceStack src, String kitId) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        BotKit kit = BotKit.byId(kitId);
        if (kit == null) {
            feedback(src, "Неизвестный кит '" + kitId + "'! Доступные: " + BotKit.listIds());
            return 0;
        }
        List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        if (bots.isEmpty()) { feedback(src, "Нет активных ботов!"); return 0; }
        SpawnBotCommand.setLastUsedKit(kit);
        for (BotEntity bot : bots) bot.setKit(kit);
        kit.applyToPlayer(player);
        boolean profileLoaded = ModuleManager.INSTANCE.loadProfile(kit.profileName);
        BotConfig.save();
        feedback(src, "Кит " + kit.id.toUpperCase() + " — " + kit.displayName
            + " (выдан боту и тебе)" + (profileLoaded ? " [профиль загружен]" : ""));
        return 1;
    }

    private static int saveCustomKit(CommandSourceStack src, String kitName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        var inv = player.getInventory();
        List<ItemStack> snapshot = new ArrayList<>(41);
        for (int i = 0; i < 36; i++) snapshot.add(inv.getItem(i).copy());
        snapshot.add(player.getItemBySlot(EquipmentSlot.HEAD).copy());
        snapshot.add(player.getItemBySlot(EquipmentSlot.CHEST).copy());
        snapshot.add(player.getItemBySlot(EquipmentSlot.LEGS).copy());
        snapshot.add(player.getItemBySlot(EquipmentSlot.FEET).copy());
        snapshot.add(player.getItemBySlot(EquipmentSlot.OFFHAND).copy());
        String key = player.getUUID() + ":" + kitName.toLowerCase();
        customKits.put(key, snapshot);
        CustomKitStore.save(player.getUUID(), kitName.toLowerCase(), snapshot, player.level().registryAccess());
        long filled = snapshot.stream().filter(s -> !s.isEmpty()).count();
        feedback(src, "Кит '" + kitName + "' сохранён! (" + filled + " предметов). /bot kit load " + kitName);
        return 1;
    }

    private static int loadCustomKit(CommandSourceStack src, String kitName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        String key = player.getUUID() + ":" + kitName.toLowerCase();
        List<ItemStack> snapshot = CustomKitStore.loadWithRegistry(
            player.getUUID(), kitName.toLowerCase(), player.level().registryAccess());
        if (snapshot == null) snapshot = customKits.get(key);
        if (snapshot == null) {
            feedback(src, "Кит '" + kitName + "' не найден! /bot kit list");
            return 0;
        }
        var inv = player.getInventory();
        player.getInventory().clearContent();
        for (int i = 0; i < Math.min(36, snapshot.size()); i++) inv.setItem(i, snapshot.get(i).copy());
        if (snapshot.size() > 36) player.setItemSlot(EquipmentSlot.HEAD,    snapshot.get(36).copy());
        if (snapshot.size() > 37) player.setItemSlot(EquipmentSlot.CHEST,   snapshot.get(37).copy());
        if (snapshot.size() > 38) player.setItemSlot(EquipmentSlot.LEGS,    snapshot.get(38).copy());
        if (snapshot.size() > 39) player.setItemSlot(EquipmentSlot.FEET,    snapshot.get(39).copy());
        if (snapshot.size() > 40) player.setItemSlot(EquipmentSlot.OFFHAND, snapshot.get(40).copy());
        List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        if (!bots.isEmpty()) {
            for (BotEntity bot : bots) applyCustomKitToBotEntity(bot, snapshot, player.level().registryAccess());
            feedback(src, "Кит '" + kitName + "' выдан тебе и " + bots.size() + " ботам!");
        } else {
            feedback(src, "Кит '" + kitName + "' выдан! (Ботов нет — /bot spawn)");
        }
        return 1;
    }

    private static int listCustomKits(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        String prefix = player.getUUID() + ":";
        List<String> names = new ArrayList<>();
        customKits.keySet().stream().filter(k -> k.startsWith(prefix))
                  .forEach(k -> names.add(k.substring(prefix.length())));
        feedback(src, names.isEmpty()
            ? "Нет кастомных китов. /bot kit save [имя]"
            : "Твои киты: " + String.join(", ", names));
        return 1;
    }

    private static int deleteCustomKit(CommandSourceStack src, String kitName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        List<String> kits = CustomKitStore.list(player.getUUID());
        String lower = kitName.toLowerCase();
        if (!kits.contains(lower)) {
            feedback(src, "Кит '" + kitName + "' не найден! " + (kits.isEmpty() ? "нет китов" : String.join(", ", kits)));
            return 0;
        }
        CustomKitStore.delete(player.getUUID(), lower);
        customKits.remove(player.getUUID() + ":" + lower);
        feedback(src, "Кит '" + kitName + "' удалён.");
        return 1;
    }

    private static int renameCustomKit(CommandSourceStack src, String oldName, String newName) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        var ra = player.level().registryAccess();
        List<String> kits = CustomKitStore.list(player.getUUID());
        if (!kits.contains(oldName.toLowerCase())) { feedback(src, "Кит '" + oldName + "' не найден!"); return 0; }
        if (kits.contains(newName.toLowerCase())) { feedback(src, "Кит '" + newName + "' уже существует!"); return 0; }
        boolean ok = CustomKitStore.rename(player.getUUID(), oldName, newName, ra);
        String oldKey = player.getUUID() + ":" + oldName.toLowerCase();
        String newKey = player.getUUID() + ":" + newName.toLowerCase();
        var snapshot = customKits.remove(oldKey);
        if (snapshot != null) customKits.put(newKey, snapshot);
        feedback(src, ok ? "Кит '" + oldName + "' переименован в '" + newName + "'" : "Ошибка переименования.");
        return ok ? 1 : 0;
    }

    static void feedback(CommandSourceStack src, String msg) {
        if (src.getEntity() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal("[PVPBot] " + msg));
    }
}
