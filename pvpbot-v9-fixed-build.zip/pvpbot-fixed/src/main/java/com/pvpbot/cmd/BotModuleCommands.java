package com.pvpbot.cmd;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.pvpbot.*;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;

/**
 * /bot module, /bot difficulty, /bot whitelist, /bot profile — управление конфигом.
 * Вынесено из SpawnBotCommand.
 */
public final class BotModuleCommands {

    private BotModuleCommands() {}

    public static LiteralArgumentBuilder<CommandSourceStack> buildModule() {
        return Commands.literal("module")
            .executes(ctx -> {
                StringBuilder sb = new StringBuilder("Модули PVPBot:\n");
                for (String mod : ModuleManager.INSTANCE.getModuleNames()) {
                    boolean en = ModuleManager.INSTANCE.isEnabled(mod);
                    sb.append(en ? "[ON] " : "[OFF] ").append(mod).append("\n");
                }
                if (ctx.getSource().getEntity() instanceof ServerPlayer p)
                    p.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
                return 1;
            })
            .then(Commands.argument("name",
                com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.ModuleState s = ModuleManager.INSTANCE.get(name);
                    if (s == null) { feedback(ctx.getSource(), "Модуль " + name + " не найден."); return 0; }
                    feedback(ctx.getSource(), name + ": " + (s.enabled ? "ВКЛ" : "ВЫКЛ") + " priority=" + s.priority);
                    return 1;
                })
                .then(Commands.literal("on").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, true);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), name + " включён");
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.setEnabled(name, false);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), name + " выключен");
                    return 1;
                }))
                .then(Commands.literal("toggle").executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    ModuleManager.INSTANCE.toggle(name);
                    boolean en = ModuleManager.INSTANCE.isEnabled(name);
                    ModuleManager.INSTANCE.applyToConfig(); BotConfig.save();
                    feedback(ctx.getSource(), name + " → " + (en ? "ВКЛ" : "ВЫКЛ"));
                    return 1;
                }))
            );
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildWhitelist() {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        return Commands.literal("whitelist")
            .then(Commands.literal("on").executes(ctx -> {
                cfg.whitelistEnabled = true; BotConfig.save();
                feedback(ctx.getSource(), "Whitelist включён"); return 1;
            }))
            .then(Commands.literal("off").executes(ctx -> {
                cfg.whitelistEnabled = false; BotConfig.save();
                feedback(ctx.getSource(), "Whitelist выключен"); return 1;
            }))
            .then(Commands.literal("add")
                .then(Commands.argument("nick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        if (!cfg.whitelist.contains(nick)) cfg.whitelist.add(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), nick + " добавлен в whitelist");
                        return 1;
                    })))
            .then(Commands.literal("remove")
                .then(Commands.argument("nick",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> {
                        String nick = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "nick");
                        cfg.whitelist.remove(nick);
                        BotConfig.save();
                        feedback(ctx.getSource(), nick + " удалён из whitelist");
                        return 1;
                    })))
            .then(Commands.literal("list").executes(ctx -> {
                feedback(ctx.getSource(), "Whitelist (" + (cfg.whitelistEnabled ? "ВКЛ" : "ВЫКЛ") + "): "
                    + (cfg.whitelist.isEmpty() ? "(пусто)" : String.join(", ", cfg.whitelist)));
                return 1;
            }));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildDifficulty() {
        return Commands.literal("difficulty")
            .then(Commands.literal("easy")  .executes(ctx -> setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EASY)))
            .then(Commands.literal("medium").executes(ctx -> setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.MEDIUM)))
            .then(Commands.literal("hard")  .executes(ctx -> setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.HARD)))
            .then(Commands.literal("expert").executes(ctx -> setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.EXPERT)))
            .then(Commands.literal("player").executes(ctx -> setDifficulty(ctx.getSource(), PVPBotConfig.Difficulty.PLAYER)))
            .then(Commands.literal("status").executes(ctx -> showDifficulty(ctx.getSource())));
    }

    public static LiteralArgumentBuilder<CommandSourceStack> buildProfile() {
        return Commands.literal("profile")
            .then(Commands.argument("name",
                com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(ctx -> {
                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                    boolean ok = ModuleManager.INSTANCE.loadProfile(name);
                    if (ok) { BotConfig.save(); feedback(ctx.getSource(), "Профиль " + name + " загружен!"); }
                    else feedback(ctx.getSource(), "Профиль " + name + " не найден. Доступные: "
                        + String.join(", ", ModuleManager.INSTANCE.listProfiles()));
                    return ok ? 1 : 0;
                }))
            .executes(ctx -> {
                feedback(ctx.getSource(), "Профили: " + String.join(", ", ModuleManager.INSTANCE.listProfiles())
                    + "  Текущий: " + ModuleManager.INSTANCE.getActiveProfile());
                return 1;
            });
    }

    // ── Вспомогательные методы ────────────────────────────────────

    private static int setDifficulty(CommandSourceStack src, PVPBotConfig.Difficulty diff) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        PVPBotConfig.INSTANCE.difficulty = diff;
        PVPBotConfig.INSTANCE.applyDifficulty();
        BotConfig.save();
        AdaptiveDifficulty.INSTANCE.onManualDifficultyChange(diff);
        String label = switch (diff) {
            case EASY   -> "EASY — базовая атака";
            case MEDIUM -> "MEDIUM — + лук на дистанции";
            case HARD   -> "HARD — + перлы, крит-прыжки";
            case EXPERT -> "EXPERT — + кристаллы, предсказание";
            case PLAYER -> "PLAYER — неотличим от игрока";
            default -> diff.name();
        };
        feedback(src, "Сложность: " + label);
        java.util.List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        if (!bots.isEmpty()) feedback(src, "Применено к " + bots.size() + " активным ботам.");
        return 1;
    }

    private static int showDifficulty(CommandSourceStack src) {
        PVPBotConfig.Difficulty d = PVPBotConfig.INSTANCE.difficulty;
        if (src.getEntity() instanceof ServerPlayer player)
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                "Текущая сложность: " + d.name() + "\n"
                + "EASY   — атака, без перлов/кристаллов\n"
                + "MEDIUM — + лук на дистанции\n"
                + "HARD   — + перлы (рывок/отрыв)\n"
                + "EXPERT — + кристаллы, предсказание, комбо\n"
                + "PLAYER — неотличим от игрока"
            ));
        return 1;
    }

    static void feedback(CommandSourceStack src, String msg) {
        if (src.getEntity() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal("[PVPBot] " + msg));
    }
}
