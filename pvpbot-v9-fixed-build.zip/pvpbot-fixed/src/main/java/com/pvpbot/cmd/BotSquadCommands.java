package com.pvpbot.cmd;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.pvpbot.*;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * /bot squad ... — управление отрядом.
 * Вынесено из SpawnBotCommand для уменьшения размера файла.
 */
public final class BotSquadCommands {

    private BotSquadCommands() {}

    public static LiteralArgumentBuilder<CommandSourceStack> build() {
        return Commands.literal("squad")
            .executes(ctx -> squadInfo(ctx.getSource()))
            .then(Commands.literal("create")
                .executes(ctx -> squadCreate(ctx.getSource(), "Squad-1"))
                .then(Commands.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> squadCreate(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
            )
            .then(Commands.literal("disband").executes(ctx -> {
                if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
                SquadManager.INSTANCE.disband(p);
                feedback(ctx.getSource(), "Отряд расформирован.");
                return 1;
            }))
            .then(Commands.literal("commander")
                .then(Commands.literal("attack")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.ATTACK)))
                .then(Commands.literal("stand")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.STAND)))
                .then(Commands.literal("retreat")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.RETREAT)))
                .then(Commands.literal("flank")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.FLANK)))
                .then(Commands.literal("surround")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.SURROUND)))
                .then(Commands.literal("focus")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.FOCUS)))
                .then(Commands.literal("heal")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.HEAL)))
                .then(Commands.literal("cover")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.COVER)))
                .then(Commands.literal("push")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.PUSH)))
                .then(Commands.literal("bait")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.BAIT)))
                .then(Commands.literal("split")
                    .executes(ctx -> squadOrder(ctx.getSource(), SquadManager.CommanderOrder.SPLIT)))
            )
            .then(Commands.literal("info").executes(ctx -> squadInfo(ctx.getSource())))
            .then(Commands.literal("save")
                .then(Commands.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> squadSave(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
            )
            .then(Commands.literal("load")
                .then(Commands.argument("name",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .executes(ctx -> squadLoad(ctx.getSource(),
                        com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name"))))
            )
            .then(Commands.literal("presets").executes(ctx -> squadPresets(ctx.getSource())))
            .then(Commands.literal("tp").executes(ctx -> squadTp(ctx.getSource())))
            .then(Commands.literal("ambush").executes(ctx -> squadAmbush(ctx.getSource())))
            .then(Commands.literal("wavedefense")
                .then(Commands.literal("start")
                    .executes(ctx -> squadWaveDefense(ctx.getSource(), true)))
                .then(Commands.literal("stop")
                    .executes(ctx -> squadWaveDefense(ctx.getSource(), false)))
            )
            .then(Commands.literal("role")
                .then(Commands.argument("role",
                    com.mojang.brigadier.arguments.StringArgumentType.word())
                    .then(Commands.argument("value",
                        com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 100))
                        .executes(ctx -> squadSetRole(ctx.getSource(),
                            com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "role"),
                            com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "value")))))
            )
            .then(Commands.literal("roles").executes(ctx -> squadRolesInfo(ctx.getSource())))
            .then(Commands.literal("rolesauto").executes(ctx -> {
                PVPBotConfig.INSTANCE.roleConfig.resetToAuto();
                BotConfig.save();
                feedback(ctx.getSource(), "Роли сброшены на авторежим.");
                return 1;
            }));
    }

    private static int squadCreate(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        List<BotEntity> bots = SpawnBotCommand.getBotsFor(player);
        if (bots.isEmpty()) { feedback(src, "Нет ботов для отряда! /bot spawn сначала."); return 0; }
        SquadManager.INSTANCE.assignBots(player, bots);
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        StringBuilder msg = new StringBuilder("Отряд " + name + " создан!\n");
        msg.append("Командир: ").append(squad.commander != null ? "Бот #1" : "нет")
           .append(" + ").append(squad.soldiers.size()).append(" бойцов\n");
        if (squad.size() >= 20) {
            long elites  = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.ELITE).count();
            long medics  = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.MEDIC).count();
            long tankers = squad.soldiers.stream().filter(b -> b.getSquadRole() == BotRole.TANKER).count();
            msg.append("Элиты: ").append(elites)
               .append("  Танкеры: ").append(tankers)
               .append("  Медики: ").append(medics);
        }
        feedback(src, msg.toString());
        return 1;
    }

    private static int squadInfo(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "Нет отряда. /bot squad create"); return 0; }
        StringBuilder sb = new StringBuilder("Отряд — Статус\n");
        sb.append("Всего ботов: ").append(squad.size()).append("\n");
        sb.append("Приказ: ").append(squad.currentOrder.name()).append("\n");
        if (squad.size() >= 5) {
            java.util.Map<BotRole, Long> rc = new java.util.LinkedHashMap<>();
            for (BotRole r : BotRole.values()) rc.put(r, 0L);
            for (BotEntity b : squad.soldiers)
                rc.merge(b.getSquadRole() != null ? b.getSquadRole() : BotRole.SOLDIER, 1L, Long::sum);
            sb.append("Роли: ");
            rc.forEach((r, c) -> { if (c > 0) sb.append(r.displayName).append("x").append(c).append(" "); });
            sb.append("\n");
            CasualtyTracker.BattleRecord rec = CasualtyTracker.INSTANCE.getCurrent();
            if (rec != null) sb.append("Потери: ").append(rec.casualties).append("/").append(rec.initialSize).append("\n");
        }
        if (squad.commander != null)
            sb.append("[Командир] HP:").append((int) squad.commander.getHealth())
              .append(" Цель:").append(squad.commander.getTarget() != null
                  ? squad.commander.getTarget().getName().getString() : "нет").append("\n");
        for (int i = 0; i < squad.soldiers.size(); i++) {
            BotEntity s = squad.soldiers.get(i);
            sb.append("#").append(i + 1).append(" HP:").append((int) s.getHealth())
              .append(s.isAlive() ? "" : " МЁРТВ").append("\n");
        }
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    private static int squadOrder(CommandSourceStack src, SquadManager.CommanderOrder order) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        if (!SpawnBotCommand.checkAccess(src)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "Нет отряда! /bot squad create"); return 0; }
        SquadManager.INSTANCE.issueOrder(player, order);
        feedback(src, "Приказ: " + order.name());
        return 1;
    }

    private static int squadSave(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "Нет отряда для сохранения."); return 0; }
        boolean isNew = SquadPreset.INSTANCE.save(name, squad, PVPBotConfig.INSTANCE);
        BotConfig.save();
        feedback(src, (isNew ? "Новый пресет: " : "Перезаписан пресет: ") + name
            + " (" + squad.size() + " бойцов, " + PVPBotConfig.INSTANCE.mode + ")");
        return 1;
    }

    private static int squadLoad(CommandSourceStack src, String name) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadPreset.SquadSnapshot snap = SquadPreset.INSTANCE.load(name, PVPBotConfig.INSTANCE);
        if (snap == null) { feedback(src, "Пресет " + name + " не найден. /bot squad presets"); return 0; }
        BotConfig.save();
        feedback(src, "Пресет " + snap.name + " загружен! " + snap.size + " бойцов, кит " + snap.kitMode);
        return 1;
    }

    private static int squadPresets(CommandSourceStack src) {
        java.util.Set<String> names = SquadPreset.INSTANCE.listNames();
        if (names.isEmpty()) { feedback(src, "Пресетов нет. /bot squad save <имя>"); return 1; }
        StringBuilder sb = new StringBuilder("Пресеты:\n");
        for (String n : names) sb.append("  ").append(SquadPreset.INSTANCE.get(n).summary()).append("\n");
        if (src.getEntity() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    private static int squadTp(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "Нет отряда."); return 0; }
        int count = 0;
        net.minecraft.world.phys.Vec3 pos = player.position();
        for (BotEntity bot : squad.allBots())
            if (bot.isAlive()) {
                bot.teleportTo(pos.x + (Math.random() * 4 - 2), pos.y, pos.z + (Math.random() * 4 - 2));
                count++;
            }
        feedback(src, "Телепортировано " + count + " бойцов.");
        return 1;
    }

    private static int squadAmbush(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (squad == null) { feedback(src, "Нет отряда."); return 0; }
        if (CommanderAI.INSTANCE.isAmbushMode()) {
            CommanderAI.INSTANCE.disableAmbush(squad);
            feedback(src, "Засада отменена.");
        } else {
            CommanderAI.INSTANCE.enableAmbush(squad, player);
        }
        BotConfig.save();
        return 1;
    }

    private static int squadWaveDefense(CommandSourceStack src, boolean start) {
        if (!(src.getEntity() instanceof ServerPlayer player)) return 0;
        SquadManager.Squad squad = SquadManager.INSTANCE.getSquad(player);
        if (start) {
            if (squad == null) { feedback(src, "Сначала создайте отряд: /bot squad create"); return 0; }
            WaveDefense.INSTANCE.start(player, squad);
            PVPBotConfig.INSTANCE.waveDefenseActive = true;
        } else {
            WaveDefense.INSTANCE.stop(player);
            PVPBotConfig.INSTANCE.waveDefenseActive = false;
        }
        BotConfig.save();
        return 1;
    }

    private static int squadSetRole(CommandSourceStack src, String roleName, int value) {
        BotRole role;
        try { role = BotRole.valueOf(roleName.toUpperCase()); }
        catch (IllegalArgumentException e) {
            feedback(src, "Неизвестная роль: " + roleName + ". Доступны: " + java.util.Arrays.toString(BotRole.values()));
            return 0;
        }
        PVPBotConfig.INSTANCE.roleConfig.usePercent = true;
        PVPBotConfig.INSTANCE.roleConfig.roleCounts.put(role, value);
        BotConfig.save();
        feedback(src, "Роль " + role.displayName + " → " + (value == 0 ? "выкл" : value + "%"));
        return 1;
    }

    private static int squadRolesInfo(CommandSourceStack src) {
        BotRole.RoleConfig cfg = PVPBotConfig.INSTANCE.roleConfig;
        StringBuilder sb = new StringBuilder("Конфиг ролей\n");
        for (BotRole r : BotRole.values()) {
            Integer v = cfg.roleCounts.get(r);
            sb.append("  ").append(r.displayName).append(" → ")
              .append((v == null || v == -1) ? "авто" : (v == 0 ? "выкл" : v + (cfg.usePercent ? "%" : "шт"))).append("\n");
        }
        if (src.getEntity() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(sb.toString()));
        return 1;
    }

    static void feedback(CommandSourceStack src, String msg) {
        if (src.getEntity() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal("[PVPBot] " + msg));
    }
}
