package com.pvpbot;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * UhcLogic v7.0 — PATCH
 *
 * Улучшения v7 (patch):
 *  ✦ Паутина: бросается на дистанции 5–7 без подхода вплотную (throw arc)
 *  ✦ Лава: ставится ПОД ноги (feet), а не над головой — больше попаданий
 *  ✦ buildCover: убираем блоки-укрытие после боя, не засоряем карту
 *  ✦ После паутины — стоп навигации + немедленный точный выстрел
 *  ✦ Мгновенный залп арбалета сразу после ловушки
 *
 * UhcLogic v6.0 — MCTiers UHC. MAJOR REWRITE.
 *
 * Улучшения v6:
 *  ✦ Лук с динамическим упреждением (дистанция × скорость цели)
 *  ✦ Арбалет: быстрее и точнее, используется как gap-closer
 *  ✦ Паутина x2 (под ноги + голова) + немедленный залп
 *  ✦ Лава только если цель стоит (не прыгает) — меньше промахов
 *  ✦ Меч в ближнем бою: combo крит → топор (слом щита) → меч
 *  ✦ Блок-укрытие: dirt стена из 2 блоков при HP < 8
 *  ✦ Авто-гэпл при HP < 8 (было < 6)
 *  ✦ Авто-щит: поднимаем offhand shield при входящем уроне (isTargetSwinging)
 *  ✦ Топор против щита: axe hit при isBlocking()
 *  ✦ Strafe: постоянный смена направления, не случайный таймер
 *  ✦ Kite: поддерживаем BOW_RANGE если HP < 10
 *  ✦ HeatMap + KillStreak интеграция через BotEntity
 */
public class UhcLogic {

    // ── Дальности ─────────────────────────────────────────────────
    private static final double BOW_RANGE    = 22.0;
    private static final double XBOW_RANGE   = 15.0;
    private static final double TRAP_RANGE   = 4.5;
    private static final double MELEE_RANGE  = 2.8;
    private static final double KITE_RANGE   = 8.0;  // kite distance при низком HP

    // ── Кулдауны ──────────────────────────────────────────────────
    private static final int    BOW_CD       = 16;
    private static final int    XBOW_CD      = 28;
    private static final int    TRAP_CD      = 70;
    private static final int    GAP_CD       = 200;
    private static final int    LAVA_CD      = 90;
    private static final int    SHIELD_TICKS = 30;
    private static final int    WEB_LIFE     = 60;
    private static final int    COVER_CD     = 35;
    private static final int    AXE_CD       = 14;
    private static final int    MELEE_CD     = 7;
    private static final int    BURST_CD     = 5;
    private static final int    BURST_COUNT  = 4;

    private static final int    CRIT_EVERY   = 3;
    private static final float  GAP_HP       = 8.0f;  // раньше: 6
    private static final float  KITE_HP      = 10.0f; // kite если HP < этого

    private enum State { RANGING, TRAPPING, LAVA_POUR, MELEING, GAPPING, SELF_STUCK, BUILDING }
    private State state = State.RANGING;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int bowCd   = 0, xbowCd  = 0, trapCd  = 0, gapCd  = 0;
    private int lavaCd  = 0, shieldT  = 0, webLife = 0, coverCd = 0;
    private int axeCd   = 0, meleeCd = 0, burstCd = 0, burstHits = 0;
    private int hitCount= 0, shieldDis = 0;
    private boolean webPlaced  = false, lavaPlaced = false, inBurst = false;
    private boolean critPending = false;
    private BlockPos webPos    = null, lavaPos = null;
    // PATCH v7: отслеживаем блоки укрытия чтобы убирать после боя
    private BlockPos coverPos1 = null, coverPos2 = null;
    private int zigzagTimer    = 0;
    private boolean zigzagLeft = true;

    public UhcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { resetTraps(sw); return; }

        if (bowCd    > 0) bowCd--;
        if (xbowCd   > 0) xbowCd--;
        if (trapCd   > 0) trapCd--;
        if (gapCd    > 0) gapCd--;
        if (lavaCd   > 0) lavaCd--;
        if (shieldT  > 0) shieldT--;
        if (webLife  > 0) webLife--;
        if (coverCd  > 0) coverCd--;
        if (axeCd    > 0) axeCd--;
        if (meleeCd  > 0) meleeCd--;
        if (burstCd  > 0) burstCd--;
        if (shieldDis> 0) shieldDis--;
        if (zigzagTimer > 0) zigzagTimer--;

        if (webPlaced && webLife <= 0) removeWeb(sw);
        if (lavaPlaced && lavaCd <= 0) removeLava(sw);

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Авто-гэпл ────────────────────────────────────────────
        if (myHp < GAP_HP && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 1));
            gapCd = GAP_CD;
            state = State.GAPPING;
        }

        // ── Авто-щит: если цель замахивается ─────────────────────
        if (shieldT <= 0 && dist < 3.5 && isTargetSwinging(target)) {
            equipOffhandShield();
            bot.setShiftKeyDown(true);
            shieldT = SHIELD_TICKS;
        } else if (shieldT <= 0) {
            bot.setShiftKeyDown(false);
        }

        // ── Строим укрытие при низком HP ─────────────────────────
        if (myHp < GAP_HP && coverCd <= 0 && !webPlaced) {
            buildCover(sw);
            coverCd = COVER_CD;
        }

        // ── Определяем состояние ─────────────────────────────────
        if (botInWeb(sw)) {
            state = State.SELF_STUCK;
        } else if (state != State.GAPPING && state != State.SELF_STUCK) {
            if (webPlaced && isInWeb(target) && !lavaPlaced && lavaCd <= 0)
                state = State.LAVA_POUR;
            else if (webPlaced && isInWeb(target))
                state = State.MELEING;
            // PATCH v7: увеличен диапазон ловушки (4.5→7.0) — ставим паутину с дистанции
            else if (dist < 7.0 && trapCd <= 0 && !webPlaced)
                state = State.TRAPPING;
            else
                state = State.RANGING;
        }

        switch (state) {
            case RANGING    -> doRanging(sw, target, dist, myHp);
            case TRAPPING   -> doTrapping(sw, target);
            case LAVA_POUR  -> doLavaPour(sw, target);
            case MELEING    -> doMeleing(sw, target, dist);
            case GAPPING    -> doGapping(sw, target);
            case SELF_STUCK -> doSelfStuck(sw);
            case BUILDING   -> {}
        }

        // Топор против щита — всегда
        autoAxe(sw, target, dist);
        // Страф
        doStrafe(target, dist);
    }

    // ════════════════════════════════════════════════════════════
    //  Дальний бой
    // ════════════════════════════════════════════════════════════

    private void doRanging(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Kite при низком HP
        boolean kiting = myHp < KITE_HP;
        if (kiting && dist < KITE_RANGE) {
            doZigzagRetreat(target);
        } else if (dist > BOW_RANGE) {
            bot.getNavigation().moveTo(target, 1.15);
            bot.setSprinting(dist > 14.0);
        } else {
            bot.getNavigation().moveTo(target, 1.0);
        }

        // Лук с упреждением
        if (dist <= BOW_RANGE && bowCd <= 0) {
            doLeadingBowShot(sw, target, dist);
            return;
        }

        // Арбалет на средней дистанции
        if (dist <= XBOW_RANGE && xbowCd <= 0) {
            equipXbow();
            bot.getLookControl().setLookAt(target, 60f, 60f);
            float dmg = (float) Math.max(7.0, 11.0 - dist * 0.25);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 5, 0.2,0.2,0.2,0.1);
            bot.playSound(net.minecraft.sounds.SoundEvents.ARROW_HIT_PLAYER, 1.0f, 0.9f);
            xbowCd = XBOW_CD;
            bot.getHeatMap().recordDamageDealt(bot.position(), dmg);
        }
    }

    private void doLeadingBowShot(ServerLevel sw, LivingEntity target, double dist) {
        equipBow();
        // Время полёта стрелы: ~dist/22 секунды → × 20 тиков
        float  lead     = (float)(dist / 22.0 * 20);
        Vec3   vel      = target.getDeltaMovement();
        Vec3   aimPos   = target.position().add(vel.scale(lead))
                                           .add(0, 0.85, 0); // центр тела
        double aimDist  = bot.position().distanceTo(aimPos);
        float  dmg      = (float) Math.max(5.0, 9.5 - aimDist * 0.20);

        bot.getLookControl().setLookAt(aimPos.x, aimPos.y, aimPos.z, 60f, 60f);
        if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 4, 0.3,0.3,0.3,0.1);
        bot.playSound(net.minecraft.sounds.SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        bowCd = BOW_CD;
        bot.getHeatMap().recordDamageDealt(bot.position(), dmg);
    }

    // ════════════════════════════════════════════════════════════
    //  Ловушки
    // ════════════════════════════════════════════════════════════

    private void doTrapping(ServerLevel sw, LivingEntity target) {
        BlockPos feet = BlockPos.containing(target.position());
        // PATCH v7: ставим паутину на расстоянии — не нужно подходить вплотную
        // Проверяем что блок под ногами цели твёрдый и сам блок — воздух
        if (sw.getBlockState(feet).isAir()) {
            sw.setBlock(feet,        Blocks.COBWEB.defaultBlockState(), 3);
            sw.setBlock(feet.above(), Blocks.COBWEB.defaultBlockState(), 3);
            webPlaced = true; webPos = feet; webLife = WEB_LIFE;
            bot.playSound(net.minecraft.sounds.SoundEvents.WOOL_PLACE, 1.0f, 0.8f);
            // PATCH v7: останавливаем навигацию для точного выстрела
            bot.getNavigation().stop();
            bowCd = 0;  // немедленный залп
            xbowCd = 0; // арбалет тоже готов
        }
        trapCd = TRAP_CD;
    }

    private void doLavaPour(ServerLevel sw, LivingEntity target) {
        // PATCH v7: лава ПОД ноги (feet), не над головой — меньше промахов
        if (!target.onGround()) return;
        BlockPos feet = BlockPos.containing(target.position());
        // Ставим рядом с ногами — сбоку от цели (не прямо под неё, там может быть блок)
        BlockPos lavaTarget = feet;
        // Ищем свободный блок рядом с ногами
        for (BlockPos candidate : new BlockPos[]{
            feet, feet.north(), feet.south(), feet.east(), feet.west()
        }) {
            if (sw.getBlockState(candidate).isAir()) {
                lavaTarget = candidate;
                break;
            }
        }
        if (sw.getBlockState(lavaTarget).isAir()) {
            sw.setBlock(lavaTarget, Blocks.LAVA.defaultBlockState(), 3);
            lavaPlaced = true; lavaPos = lavaTarget; lavaCd = 50;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  Ближний бой
    // ════════════════════════════════════════════════════════════

    private void doMeleing(ServerLevel sw, LivingEntity target, double dist) {
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (dist > MELEE_RANGE) { bot.getNavigation().moveTo(target, 1.1); return; }

        boolean blocking = isBlocking(target);

        if (!blocking && inBurst && burstCd <= 0) {
            if (burstHits < BURST_COUNT) {
                doSwordHit(sw, target, false); burstCd = BURST_CD; burstHits++;
            } else { inBurst = false; }
        } else if (!blocking && !inBurst && meleeCd <= 0) {
            boolean doCrit = hitCount % CRIT_EVERY == 0;
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; meleeCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doSwordHit(sw, target, true); critPending = false;
            } else if (!doCrit && !critPending) {
                doSwordHit(sw, target, false);
            }
        }
    }

    private void doSwordHit(ServerLevel sw, LivingEntity target, boolean crit) {
        equipSword();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (target.getRemainingFireTicks() <= 0) target.setRemainingFireTicks(60);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+0.8, target.getZ(), 7,0.2,0.2,0.2,0.1);
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        critPending = false;
        meleeCd = cfg().adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : MELEE_CD;
        bot.getHeatMap().recordDamageDealt(bot.position(), crit ? 13f : 8f);
    }

    // ════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ════════════════════════════════════════════════════════════

    private void autoAxe(ServerLevel sw, LivingEntity target, double dist) {
        if (dist > MELEE_RANGE + 0.5 || axeCd > 0 || shieldDis > 0) return;
        if (!isBlocking(target)) return;
        equipAxe();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY()+1, target.getZ(), 4,0.3,0.2,0.3,0.05);
        bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        shieldDis = 100; axeCd = AXE_CD;
        inBurst = true; burstHits = 0;
        bot.getHeatMap().recordDamageDealt(bot.position(), 13f);
    }

    private void doStrafe(LivingEntity target, double dist) {
        if (dist < MELEE_RANGE + 3.5 && cfg().strafeEnabled) strafe.tick(target);
    }

    private void doZigzagRetreat(LivingEntity target) {
        if (zigzagTimer <= 0) { zigzagLeft = !zigzagLeft; zigzagTimer = 4 + bot.level().getRandom().nextInt(5); }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side = zigzagLeft ? new Vec3(-away.z,0,away.x).scale(0.5)
                               : new Vec3(away.z,0,-away.x).scale(0.5);
        Vec3 dest = bot.position().add(away.scale(8)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.25);
        bot.setSprinting(true);
    }

    private void doGapping(ServerLevel sw, LivingEntity target) {
        doZigzagRetreat(target);
        if (bot.getHealth() > GAP_HP + 3) state = State.RANGING;
    }

    private void doSelfStuck(ServerLevel sw) {
        // Убираем паутину под собой
        BlockPos feet = BlockPos.containing(bot.position());
        if (sw.getBlockState(feet).is(Blocks.COBWEB)) sw.removeBlock(feet, false);
        if (sw.getBlockState(feet.above()).is(Blocks.COBWEB)) sw.removeBlock(feet.above(), false);
        bot.setSprinting(true);
        state = State.RANGING;
    }

    private void buildCover(ServerLevel sw) {
        // PATCH v7: запоминаем позиции чтобы убрать после боя
        Vec3  look  = bot.getLookAngle().scale(-1).normalize();
        BlockPos b1 = BlockPos.containing(bot.position().add(look.scale(1)));
        BlockPos b2 = b1.above();
        if (sw.getBlockState(b1).isAir()) {
            sw.setBlock(b1, Blocks.DIRT.defaultBlockState(), 3);
            coverPos1 = b1;
        }
        if (sw.getBlockState(b2).isAir()) {
            sw.setBlock(b2, Blocks.DIRT.defaultBlockState(), 3);
            coverPos2 = b2;
        }
    }

    // PATCH v7: убираем укрытие после боя
    private void removeCover(ServerLevel sw) {
        if (coverPos1 != null && sw.getBlockState(coverPos1).is(Blocks.DIRT)) {
            sw.removeBlock(coverPos1, false); coverPos1 = null;
        }
        if (coverPos2 != null && sw.getBlockState(coverPos2).is(Blocks.DIRT)) {
            sw.removeBlock(coverPos2, false); coverPos2 = null;
        }
    }

    private void removeWeb(ServerLevel sw) {
        if (webPos == null) return;
        if (sw.getBlockState(webPos).is(Blocks.COBWEB))        sw.removeBlock(webPos, false);
        if (sw.getBlockState(webPos.above()).is(Blocks.COBWEB)) sw.removeBlock(webPos.above(), false);
        webPlaced = false; webPos = null;
    }

    private void removeLava(ServerLevel sw) {
        if (lavaPos != null && sw.getBlockState(lavaPos).is(Blocks.LAVA))
            sw.removeBlock(lavaPos, false);
        lavaPlaced = false; lavaPos = null;
    }

    private void resetTraps(ServerLevel sw) {
        removeWeb(sw); removeLava(sw); removeCover(sw); state = State.RANGING;
    }

    private boolean botInWeb(ServerLevel sw) {
        return sw.getBlockState(BlockPos.containing(bot.position())).is(Blocks.COBWEB);
    }

    private boolean isInWeb(LivingEntity e) {
        return webPos != null && (
            BlockPos.containing(e.position()).equals(webPos) ||
            BlockPos.containing(e.position()).equals(webPos.above()));
    }

    private boolean isBlocking(LivingEntity t) {
        if (shieldDis > 0) return false;
        return (t.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD) ||
                t.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.SHIELD)) && t.isBlocking();
    }

    private boolean isTargetSwinging(LivingEntity t) {
        return t.swinging;
    }

    private void equipOffhandShield() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    private void equipSword() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.DIAMOND_SWORD, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("fire_aspect", 2).build());
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.DIAMOND_AXE, bot.level().registryAccess())
                    .enchant("sharpness", 5).build());
    }

    private void equipBow() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                .enchant("power", 5).enchant("punch", 2).enchant("infinity", 1).build());
    }

    private void equipXbow() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.CROSSBOW))
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.CROSSBOW, bot.level().registryAccess())
                    .enchant("quick_charge", 3).enchant("piercing", 4).build());
    }

    private PVPBotConfig cfg() { return PVPBotConfig.INSTANCE; }
}
