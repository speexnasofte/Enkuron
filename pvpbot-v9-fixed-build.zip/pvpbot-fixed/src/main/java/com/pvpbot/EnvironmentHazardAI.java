package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * EnvironmentHazardAI v1.0 — защита бота от опасностей окружающей среды.
 *
 * Что отслеживается:
 *   FIRE        — бот горит → немедленно ищет воду / заливаем fire resistance
 *   LAVA        — бот в лаве → выбраться (прыжок + навигация из лавы)
 *   VOID_EDGE   — бот на краю обрыва ≥ VOID_DROP блоков → отступить
 *   CACTUS_ZONE — рядом кактус → обойти
 *   SUFFOCATION — бот застрял в блоке → телепорт на поверхность
 *
 * Интеграция:
 *   В BotEntity.tick() или PVPBotLogic.tick() после основной логики:
 *
 *     hazardAI.tick(sw);
 *     if (hazardAI.isInDanger()) return; // приостановить боевую логику
 *
 * Приоритет выше боевой логики — бот не будет атаковать пока горит.
 */
public class EnvironmentHazardAI {

    // ── Параметры ──────────────────────────────────────────────────
    private static final int    VOID_DROP_MIN    = 5;    // блоков обрыва → опасно
    private static final double EDGE_SCAN_RADIUS = 2.0;  // блоков от бота → проверяем край
    private static final int    EVAL_INTERVAL    = 5;    // тиков между полными проверками
    private static final int    FLEE_COOLDOWN    = 20;   // тиков после избегания опасности
    private static final double SAFE_ESCAPE_DIST = 4.0;  // блоков отступа от края

    // ── Состояние ──────────────────────────────────────────────────
    private boolean inDanger      = false;
    private HazardType activeHazard = HazardType.NONE;
    private int       evalTimer   = 0;
    private int       fleeCooldown = 0;

    // Для VOID_EDGE: направление отступа
    private Vec3 fleeDirection = null;

    private final BotEntity bot;

    public enum HazardType {
        NONE,
        FIRE,          // бот горит
        LAVA,          // бот в лаве
        VOID_EDGE,     // рядом обрыв
        SUFFOCATION    // застрял в блоке
    }

    public EnvironmentHazardAI(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════

    /**
     * @return true если обнаружена опасность и бот выполняет escape — боевую логику нужно паузить.
     */
    public boolean tick(ServerLevel sw) {
        if (fleeCooldown > 0) fleeCooldown--;

        // Критические опасности — проверяем КАЖДЫЙ тик (огонь, лава, удушье)
        if (checkCritical(sw)) {
            inDanger = true;
            handleActiveHazard(sw);
            return true;
        }

        // Менее срочные (края) — раз в EVAL_INTERVAL тиков
        if (evalTimer > 0) {
            evalTimer--;
            return inDanger && fleeCooldown > 0;
        }
        evalTimer = EVAL_INTERVAL;

        if (checkVoidEdge(sw)) {
            inDanger = true;
            handleVoidEdge(sw);
            return true;
        }

        inDanger = false;
        activeHazard = HazardType.NONE;
        fleeDirection = null;
        return false;
    }

    /** true если бот сейчас в опасной ситуации */
    public boolean isInDanger() { return inDanger; }
    public HazardType getActiveHazard() { return activeHazard; }

    // ══════════════════════════════════════════════════════════════
    //  Проверки
    // ══════════════════════════════════════════════════════════════

    /** Критические проверки (каждый тик). */
    private boolean checkCritical(ServerLevel sw) {
        // Удушение: голова в блоке (не воздух, не жидкость)
        BlockPos headPos = BlockPos.containing(bot.getX(), bot.getY() + bot.getEyeHeight(), bot.getZ());
        if (!sw.getBlockState(headPos).isAir()
                && sw.getBlockState(headPos).isSuffocating(sw, headPos)) {
            activeHazard = HazardType.SUFFOCATION;
            return true;
        }

        // Лава под ногами или вокруг
        BlockPos feetPos = bot.blockPosition();
        if (sw.getFluidState(feetPos).is(Fluids.LAVA)
                || sw.getFluidState(feetPos).is(Fluids.FLOWING_LAVA)) {
            activeHazard = HazardType.LAVA;
            return true;
        }

        // Огонь (isOnFire() = также от лавы, огня, /effect fire)
        if (bot.isOnFire() && !bot.hasEffect(MobEffects.FIRE_RESISTANCE)) {
            activeHazard = HazardType.FIRE;
            return true;
        }

        return false;
    }

    /**
     * Проверка края обрыва в радиусе EDGE_SCAN_RADIUS.
     * Возвращает true если в любом из 8 направлений есть обрыв ≥ VOID_DROP_MIN.
     */
    private boolean checkVoidEdge(ServerLevel sw) {
        Vec3 pos = bot.position();
        int[] dx = {1, -1, 0, 0, 1, -1, 1, -1};
        int[] dz = {0, 0, 1, -1, 1, 1, -1, -1};

        for (int i = 0; i < 8; i++) {
            double checkX = pos.x + dx[i] * EDGE_SCAN_RADIUS;
            double checkZ = pos.z + dz[i] * EDGE_SCAN_RADIUS;
            int drop = measureDrop(sw, checkX, pos.y, checkZ);

            if (drop >= VOID_DROP_MIN) {
                // Направление отступа — противоположное от края
                fleeDirection = new Vec3(-dx[i], 0, -dz[i]).normalize();
                activeHazard = HazardType.VOID_EDGE;
                return true;
            }
        }
        return false;
    }

    /** Измерить глубину обрыва (количество воздушных блоков вниз). */
    private int measureDrop(ServerLevel sw, double x, double startY, double z) {
        int drop = 0;
        for (int y = (int) startY - 1; y > (int) startY - 20; y--) {
            BlockPos check = BlockPos.containing(x, y, z);
            if (sw.getBlockState(check).isAir()
                    || sw.getFluidState(check).is(Fluids.WATER)) {
                drop++;
            } else {
                break;
            }
        }
        return drop;
    }

    // ══════════════════════════════════════════════════════════════
    //  Обработчики
    // ══════════════════════════════════════════════════════════════

    private void handleActiveHazard(ServerLevel sw) {
        switch (activeHazard) {
            case LAVA       -> escapeLava(sw);
            case FIRE       -> escapeFire(sw);
            case SUFFOCATION -> escapeSuffocation(sw);
            default -> {}
        }
    }

    /**
     * Выбраться из лавы: прыжок + навигация к ближайшему безопасному блоку.
     */
    private void escapeLava(ServerLevel sw) {
        // Прыгаем всё время пока в лаве
        bot.setJumping(true);
        bot.setSprinting(false);

        // Ищем твёрдый блок рядом на том же уровне или выше
        Vec3 safe = findSafeBlock(sw, 6);
        if (safe != null) {
            bot.getNavigation().moveTo(safe.x, safe.y, safe.z, 1.3);
        } else {
            // Никуда не уйти — хотя бы прыгать вверх
            Vec3 pos = bot.position();
            bot.getNavigation().moveTo(pos.x, pos.y + 3, pos.z, 1.0);
        }
        fleeCooldown = FLEE_COOLDOWN;
    }

    /**
     * Спастись от огня: найти воду рядом или просто убежать.
     */
    private void escapeFire(ServerLevel sw) {
        // Ищем воду в радиусе 10 блоков
        Vec3 water = findWaterBlock(sw, 10);
        if (water != null) {
            bot.getNavigation().moveTo(water.x, water.y, water.z, 1.3);
        } else {
            // Воды нет — просто бежим в рандомном направлении (сбиваем огонь)
            Vec3 pos = bot.position();
            double angle = bot.level().getRandom().nextDouble() * Math.PI * 2;
            bot.getNavigation().moveTo(
                pos.x + Math.cos(angle) * 8,
                pos.y,
                pos.z + Math.sin(angle) * 8,
                1.2
            );
        }
        fleeCooldown = FLEE_COOLDOWN;
    }

    /**
     * Выбраться из застревания в блоке: двигаемся вверх.
     */
    private void escapeSuffocation(ServerLevel sw) {
        Vec3 pos = bot.position();
        // Ищем свободный блок над нами
        for (int dy = 1; dy <= 5; dy++) {
            BlockPos above = BlockPos.containing(pos.x, pos.y + dy, pos.z);
            if (sw.getBlockState(above).isAir()) {
                bot.getNavigation().moveTo(pos.x, pos.y + dy, pos.z, 1.0);
                break;
            }
        }
        bot.setJumping(true);
        fleeCooldown = FLEE_COOLDOWN;
    }

    /**
     * Отступить от края обрыва.
     */
    private void handleVoidEdge(ServerLevel sw) {
        if (fleeDirection == null) return;

        Vec3 pos   = bot.position();
        Vec3 goal  = pos.add(fleeDirection.scale(SAFE_ESCAPE_DIST));

        // Убедимся что цель не ведёт в другой обрыв
        int targetDrop = measureDrop(sw, goal.x, goal.y, goal.z);
        if (targetDrop < VOID_DROP_MIN) {
            bot.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.1);
        } else {
            // Оба направления ведут к обрыву — стоим на месте
            bot.getNavigation().stop();
        }
        fleeCooldown = FLEE_COOLDOWN;
    }

    // ══════════════════════════════════════════════════════════════
    //  Поиск безопасных блоков
    // ══════════════════════════════════════════════════════════════

    /**
     * Найти ближайший твёрдый блок, не лаву, в радиусе radius.
     */
    private Vec3 findSafeBlock(ServerLevel sw, int radius) {
        Vec3 pos = bot.position();
        double bestDist = Double.MAX_VALUE;
        Vec3 best = null;

        for (int dx = -radius; dx <= radius; dx += 2) {
            for (int dz = -radius; dz <= radius; dz += 2) {
                for (int dy = -1; dy <= 3; dy++) {
                    int x = (int) pos.x + dx;
                    int y = (int) pos.y + dy;
                    int z = (int) pos.z + dz;
                    BlockPos bp = new BlockPos(x, y, z);
                    BlockPos bpAbove = bp.above();

                    boolean solidFloor = !sw.getBlockState(bp).isAir()
                        && !sw.getFluidState(bp).is(Fluids.LAVA)
                        && !sw.getFluidState(bp).is(Fluids.FLOWING_LAVA)
                        && !sw.getBlockState(bp).is(Blocks.FIRE)
                        && !sw.getBlockState(bp).is(Blocks.CACTUS);
                    boolean freeAbove = sw.getBlockState(bpAbove).isAir();

                    if (solidFloor && freeAbove) {
                        double d = pos.distanceTo(new Vec3(x, y + 1, z));
                        if (d < bestDist) {
                            bestDist = d;
                            best = new Vec3(x + 0.5, y + 1, z + 0.5);
                        }
                    }
                }
            }
        }
        return best;
    }

    /**
     * Найти ближайший блок воды в радиусе radius.
     */
    private Vec3 findWaterBlock(ServerLevel sw, int radius) {
        Vec3 pos = bot.position();
        double bestDist = Double.MAX_VALUE;
        Vec3 best = null;

        for (int dx = -radius; dx <= radius; dx += 2) {
            for (int dz = -radius; dz <= radius; dz += 2) {
                for (int dy = -2; dy <= 2; dy++) {
                    BlockPos bp = BlockPos.containing(pos.x + dx, pos.y + dy, pos.z + dz);
                    if (sw.getFluidState(bp).is(Fluids.WATER)
                            || sw.getFluidState(bp).is(Fluids.FLOWING_WATER)) {
                        double d = pos.distanceTo(new Vec3(bp.getX(), bp.getY(), bp.getZ()));
                        if (d < bestDist) {
                            bestDist = d;
                            best = new Vec3(bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5);
                        }
                    }
                }
            }
        }
        return best;
    }
}
