package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * BotDebugCommand v1.0 — /bot debug: инспекция состояния AI в реальном времени.
 *
 * Команды:
 *   !debug         — краткий статус всех ботов (HP, цель, кит, DPS)
 *   !debug ai      — подробный AI-статус (паттерн, страф, ките, cooldown)
 *   !debug perf    — производительность (TPS, lag penalty, cache hit rate)
 *   !debug target  — детали текущей цели (HP, пинг, предсказуемость)
 *
 * Интеграция: вызывать из ChatCommand.handleCommand() в case "debug".
 */
public class BotDebugCommand {

    private BotDebugCommand() {}

    // ══════════════════════════════════════════════════════════════
    //  Точка входа
    // ══════════════════════════════════════════════════════════════
    public static void handle(ServerPlayer player, String subCmd,
                               List<BotEntity> bots) {
        if (bots.isEmpty()) {
            send(player, "§cНет активных ботов.");
            return;
        }

        switch (subCmd == null ? "" : subCmd.toLowerCase()) {
            case "ai"     -> debugAI(player, bots);
            case "perf"   -> debugPerf(player, bots);
            case "target" -> debugTarget(player, bots);
            default       -> debugBasic(player, bots);
        }
    }

    // ── Краткий статус ───────────────────────────────────────────
    private static void debugBasic(ServerPlayer player, List<BotEntity> bots) {
        send(player, "§e§l⚔ Bot Debug (basic) — " + bots.size() + " бот(ов):");
        for (int i = 0; i < bots.size(); i++) {
            BotEntity bot = bots.get(i);
            LivingEntity target = bot.getPvpLogic() != null
                ? bot.getPvpLogic().getCachedEnemy() : null;

            String kitName = bot.getCurrentKit() != null
                ? bot.getCurrentKit().displayName : "§7нет";
            String targetName = target != null
                ? "§c" + target.getName().getString()
                  + " §7(" + String.format("%.1f", target.getHealth()) + "HP)"
                : "§7нет цели";
            String hp = String.format("§aHP:%.1f/%.1f", bot.getHealth(), bot.getMaxHealth());
            String dps = String.format("§eDPS:%.1f", bot.getDpsMeter().getDps());

            send(player, String.format("  §7#%d §f%s %s %s Цель:%s Kit:%s",
                i + 1, bot.getName().getString(), hp, dps, targetName, kitName));
        }
    }

    // ── AI детали ────────────────────────────────────────────────
    private static void debugAI(ServerPlayer player, List<BotEntity> bots) {
        send(player, "§b§l⚙ Bot Debug (AI):");
        for (BotEntity bot : bots) {
            String pattern = bot.getPatternAI() != null
                ? bot.getPatternAI().getActiveCounter().name() : "?";
            String strafe = bot.getStrafeAI() != null
                ? bot.getStrafeAI().getStyle().name() : "?";
            float pred = bot.getPatternAI() != null
                ? bot.getPatternAI().getEnemyPredictability() : 0;
            String diff = PVPBotConfig.INSTANCE.difficulty.name();
            int reactMs = bot.getReactionProfile() != null
                ? bot.getReactionProfile().getBaseReactionMs() : 0;

            // v2.1.0: реакции
            String reactDbg = bot.getReactionProfile() != null
                ? bot.getReactionProfile().getDebugString() : "";
            // ArenaMode status
            String arenaStr = bot.getArenaMode().isEnabled()
                ? " §eArena:" + bot.getArenaMode().getBotWins() + "W/" + bot.getArenaMode().getBotLosses() + "L"
                : "";
            send(player, String.format(
                "  §f%s§7: diff=§e%s §7react=§e%dms §7pattern=§b%s §7strafe=§d%s §7pred=§6%.0f%%%s",
                bot.getName().getString(), diff, reactMs, pattern, strafe, pred * 100, arenaStr));
            if (!reactDbg.isEmpty()) send(player, "    §7" + reactDbg);
        }
    }

    // ── Производительность ───────────────────────────────────────
    private static void debugPerf(ServerPlayer player, List<BotEntity> bots) {
        send(player, "§a§l⏱ Bot Debug (performance):");
        for (BotEntity bot : bots) {
            AdaptiveCooldown acd = bot.getAdaptiveCooldown();
            String tpsInfo = acd != null
                ? String.format("TPS=§e%.1f §7lag=§c+%dt §7jit=§6+%dt",
                    acd.getSmoothedTPS(), acd.getLagPenalty(), acd.getJitterPenalty())
                : "§7N/A";
            int botCount = BotEntity.getBotCount();
            String throttle = "§7bots=" + botCount;
            String optMode = PVPBotConfig.INSTANCE.optimizeMode ? "§aON" : "§7OFF";

            send(player, String.format("  §f%s§7: %s %s OptMode=%s",
                bot.getName().getString(), tpsInfo, throttle, optMode));
        }
    }

    // ── Детали цели ──────────────────────────────────────────────
    private static void debugTarget(ServerPlayer player, List<BotEntity> bots) {
        send(player, "§c§l🎯 Bot Debug (target):");
        for (BotEntity bot : bots) {
            if (bot.getPvpLogic() == null) continue;
            LivingEntity target = bot.getPvpLogic().getCachedEnemy();
            if (target == null) {
                send(player, "  §f" + bot.getName().getString() + "§7: §7нет цели");
                continue;
            }

            float hpRatio = target.getHealth() / Math.max(1f, target.getMaxHealth());
            String hpBar  = makeHpBar(hpRatio);
            float pred = bot.getPatternAI() != null
                ? bot.getPatternAI().getEnemyPredictability() : 0;
            int pingTicks = BotPingTracker.INSTANCE.getPingTicks(target);
            String pingStr = BotPingTracker.INSTANCE.formatPing(target.getUUID());
            double dist = bot.distanceTo(target);
            boolean los = !target.isInvisible(); // упрощённо

            send(player, String.format(
                "  §f%s→%s§7: %s §7dist=§e%.1fm §7pred=§6%.0f%% §7ping=%s §7+%dtick",
                bot.getName().getString(), target.getName().getString(),
                hpBar, dist, pred * 100, pingStr, pingTicks));
        }
    }

    // ── Вспомогательные ─────────────────────────────────────────
    private static String makeHpBar(float ratio) {
        int filled = Math.round(ratio * 10);
        StringBuilder sb = new StringBuilder("§7[");
        for (int i = 0; i < 10; i++) {
            if (i < filled) sb.append(ratio > 0.5f ? "§a" : ratio > 0.25f ? "§e" : "§c").append("█");
            else sb.append("§8░");
        }
        sb.append("§7]§f ").append(String.format("%.1f", ratio * 100)).append("%");
        return sb.toString();
    }

    private static void send(ServerPlayer player, String msg) {
        player.sendSystemMessage(Component.literal("§7[Debug] " + msg));
    }
}
