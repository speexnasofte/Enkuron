package com.pvpbot;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * BattleLog v1.1 — история боёв в лог-файл + in-memory буфер для !battles.
 *
 * Файл: .minecraft/pvpbot_battles.log
 * Формат: [дата] EVENT | детали
 *
 * v1.1:
 *   - Кольцевой буфер последних 10 записей в памяти (getRecentEntries())
 *   - Команда !battles читает его без обращения к диску
 *   - Ленивый init: init() внутри write() если не был вызван явно
 */
public class BattleLog {

    public static final BattleLog INSTANCE = new BattleLog();

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static final int MAX_RECENT = 10;

    private Path logFile;
    // Кольцевой буфер — храним уже отформатированные строки (без \n)
    private final Deque<String> recentEntries = new ArrayDeque<>(MAX_RECENT + 1);

    private BattleLog() {}

    public void init() {
        Path mcDir = Minecraft.getInstance().gameDirectory.toPath();
        logFile = mcDir.resolve("pvpbot_battles.log");
    }

    public void logKill(String victimName, float totalDamage) {
        String kd = String.format("%.2f", KillDeathTracker.getKD());
        write(String.format("KILL   | victim=%-16s dmg=%.1f  K/D=%s  [K:%d D:%d A:%d]",
            victimName, totalDamage, kd,
            KillDeathTracker.kills, KillDeathTracker.deaths, KillDeathTracker.assists));
    }

    public void logDeath() {
        write(String.format("DEATH  | K/D=%.2f  [K:%d D:%d A:%d]",
            KillDeathTracker.getKD(),
            KillDeathTracker.kills, KillDeathTracker.deaths, KillDeathTracker.assists));
    }

    public void logAssist(String victimName) {
        write(String.format("ASSIST | victim=%s  [assists:%d]", victimName, KillDeathTracker.assists));
    }

    /**
     * Последние N записей для !battles (от старых к новым).
     * Не читает диск — только в-памяти буфер.
     */
    public List<String> getRecentEntries() {
        return new ArrayList<>(recentEntries);
    }

    private void write(String line) {
        // Ленивый init — если init() не был вызван явно (одиночная игра)
        if (logFile == null) {
            Path mcDir = Minecraft.getInstance().gameDirectory.toPath();
            logFile = mcDir.resolve("pvpbot_battles.log");
        }
        String timestamp = "[" + LocalDateTime.now().format(FMT) + "] ";
        String entry = timestamp + line;

        // Добавить в кольцевой буфер
        recentEntries.addLast(entry);
        if (recentEntries.size() > MAX_RECENT) recentEntries.pollFirst();

        // Записать на диск
        try {
            Files.writeString(logFile, entry + "\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {}
    }
}
