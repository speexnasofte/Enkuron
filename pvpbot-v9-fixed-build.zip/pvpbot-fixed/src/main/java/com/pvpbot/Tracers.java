package com.pvpbot;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Tracers v12 — 3D линии к ближайшим игрокам/ботам.
 *
 * Использует RenderSystem + Tesselator API актуальное для 1.21.4.
 * Регистрируется через WorldRenderEvents.LAST.
 *
 * Настройки:
 *   ModuleManager.INSTANCE.isEnabled(MOD_TRACERS) — вкл/выкл
 *   tracerColor — цвет линий (ARGB int)
 *   tracerRadius — дальность отображения в блоках
 */
public class Tracers {

    public static final Tracers INSTANCE = new Tracers();
    private static final String MOD = ModuleManager.MOD_TRACERS;

    // Настройки цвета по умолчанию
    public float r = 1.0f, g = 0.2f, b = 0.2f, a = 0.8f; // красный
    public double radius = 128.0;

    private Tracers() {}

    public void register() {
        net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.LAST.register(this::onWorldRender);
    }

    public void onWorldRender(WorldRenderContext context) {
        if (!ModuleManager.INSTANCE.isEnabled(MOD)) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Camera camera = context.camera();
        Vec3 camPos = camera.getPosition();

        // Собираем список видимых игроков/ботов в радиусе
        List<LivingEntity> targets = mc.level.getEntitiesOfClass(
            LivingEntity.class,
            mc.player.getBoundingBox().inflate(radius),
            e -> e != mc.player && (e instanceof Player || e instanceof BotEntity)
        );
        if (targets.isEmpty()) return;

        // Начало отрисовки
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(1.5f);

        var poseStack = context.matrixStack();
        if (poseStack == null) return;
        poseStack.pushPose();

        // Смещаемся в координаты относительно камеры
        poseStack.translate(-camPos.x, -camPos.y, -camPos.z);
        Matrix4f matrix = poseStack.last().pose();

        var tessellator = Tesselator.getInstance();
        var buf = tessellator.begin(VertexFormat.Mode.LINES, DefaultVertexFormat.POSITION_COLOR_NORMAL);

        // Начало луча: центр нижней части экрана (от камеры вниз на 0.5)
        double sx = camPos.x;
        double sy = camPos.y - 0.5;
        double sz = camPos.z;

        for (LivingEntity e : targets) {
            // Цвет: ботам — синий, игрокам — текущий tracer цвет
            float er, eg, eb;
            if (e instanceof BotEntity) {
                er = 0.3f; eg = 0.6f; eb = 1.0f; // синий для ботов
            } else {
                er = r; eg = g; eb = b;
            }

            // Интерполированная позиция (lerp между старым и новым тиком)
            float pt = context.tickCounter().getRealtimeDeltaTicks();
            double tx = e.xo + (e.getX() - e.xo) * pt;
            double ty = e.yo + (e.getY() - e.yo) * pt + e.getBbHeight() * 0.5; // центр сущности
            double tz = e.zo + (e.getZ() - e.zo) * pt;

            // Нормаль линии (направление)
            float nx = (float)(tx - sx);
            float ny = (float)(ty - sy);
            float nz = (float)(tz - sz);
            float len = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
            if (len < 0.001f) continue;
            nx /= len; ny /= len; nz /= len;

            buf.addVertex(matrix, (float)sx, (float)sy, (float)sz)
               .setColor(er, eg, eb, a)
               .setNormal(poseStack.last(), nx, ny, nz);
            buf.addVertex(matrix, (float)tx, (float)ty, (float)tz)
               .setColor(er, eg, eb, a)
               .setNormal(poseStack.last(), nx, ny, nz);
        }

        try {
            BufferUploader.drawWithShader(buf.buildOrThrow());
        } catch (Exception ignored) {}

        poseStack.popPose();

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1.0f);
    }
}
