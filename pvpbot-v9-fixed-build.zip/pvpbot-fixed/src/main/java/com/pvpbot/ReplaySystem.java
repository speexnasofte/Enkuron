package com.pvpbot;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ReplaySystem v1.0
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Что умеет:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  ЗАПИСЬ
 *   - Кольцевой буфер на 600 тиков (30 секунд) вместо 100 в BotReplay
 *   - Записывает каждый тик: позиция бота + цели, HP оба, действие,
 *     предмет в руке, спринт/прыжок/приседание, нанесённый урон
 *   - Именованные слоты: до MAX_SAVED_REPLAYS сохранённых записей
 *     (команда /bot replay save <name>)
 *   - NBT-сериализация → можно писать на диск (hook для мода)
 *
 *  ВОСПРОИЗВЕДЕНИЕ
 *   - GhostEntity: невидимый PathfinderMob который повторяет кадры
 *     бота из записи (телепортируется покадрово, без AI)
 *   - Скорость: 0.5x / 1x / 2x (команда /bot replay speed)
 *   - Пауза / продолжение: /bot replay pause, /bot replay resume
 *   - Подсветка событий: частицы CRIT при ударе, SMOKE при уклонении
 *   - Авто-удаление GhostEntity через 5 секунд после конца реплея
 *
 *  КОМАНДЫ (регистрируются в SpawnBotCommand/ChatCommand)
 *   /bot replay start          — начать запись (сохраняет последние 30с)
 *   /bot replay stop           — остановить запись
 *   /bot replay save <name>    — сохранить текущий буфер под именем
 *   /bot replay list           — список сохранённых
 *   /bot replay play [name]    — воспроизвести (без имени = текущий буфер)
 *   /bot replay pause          — пауза
 *   /bot replay resume         — продолжить
 *   /bot replay speed <0.5|1|2>— скорость воспроизведения
 *   /bot replay delete <name>  — удалить сохранённый
 *   /bot replay info           — статистика текущего буфера
 *
 * ═══════════════════════════════════════════════════════════════════
 *  Интеграция:
 * ═══════════════════════════════════════════════════════════════════
 *
 *  1. BotEntity уже имеет getReplay() → BotReplay. ReplaySystem живёт
 *     рядом как синглтон-менеджер, управляет всеми ботами сразу.
 *
 *  2. BotEntity.tick() → ReplaySystem.INSTANCE.tickBot(bot, target, action)
 *
 *  3. SpawnBotCommand или ChatCommand → ReplaySystem.INSTANCE.handleCommand(...)
 *
 * ═══════════════════════════════════════════════════════════════════
 */
public class ReplaySystem {

    // ── Синглтон ──────────────────────────────────────────────────
    public static final ReplaySystem INSTANCE = new ReplaySystem();

    // ── Константы ─────────────────────────────────────────────────
    /** Размер кольцевого буфера (тики) */
    public static final int  BUFFER_TICKS      = 600;  // 30 секунд
    /** Максимум сохранённых реплеев на игрока */
    public static final int  MAX_SAVED_REPLAYS = 10;
    /** Тиков авто-удаления GhostEntity после конца реплея */
    private static final int GHOST_CLEANUP_TICKS = 100; // 5 сек

    // ── Кадр записи ───────────────────────────────────────────────
    public static class Frame {

        // Бот
        public final double botX, botY, botZ;
        public final float  botYaw, botPitch;
        public final float  botHp, botMaxHp;
        public final boolean botSprinting, botJumping, botSneaking, botOnGround;
        public final String  botItem;   // имя предмета в руке (пусто = воздух)

        // Цель
        public final double tgtX, tgtY, tgtZ;
        public final float  tgtHp;
        public final boolean hasTgt;

        // Событие тика
        public final String  action;      // IDLE / ATTACK / CRIT / DODGE / RETREAT / FAKE / BUNKER / TANK
        public final float   dmgDealt;    // урон нанесён в этом тике (0 = не бил)
        public final float   dmgTaken;    // урон получен в этом тике
        public final int     tick;        // порядковый номер тика от начала записи

        public Frame(
                double bx, double by, double bz, float byaw, float bpitch,
                float bhp, float bmaxhp,
                boolean sprinting, boolean jumping, boolean sneaking, boolean onGround,
                String botItem,
                double tx, double ty, double tz, float thp, boolean hasTgt,
                String action, float dmgDealt, float dmgTaken, int tick) {
            this.botX = bx; this.botY = by; this.botZ = bz;
            this.botYaw = byaw; this.botPitch = bpitch;
            this.botHp = bhp; this.botMaxHp = bmaxhp;
            this.botSprinting = sprinting; this.botJumping = jumping;
            this.botSneaking = sneaking; this.botOnGround = onGround;
            this.botItem = botItem;
            this.tgtX = tx; this.tgtY = ty; this.tgtZ = tz;
            this.tgtHp = thp; this.hasTgt = hasTgt;
            this.action = action;
            this.dmgDealt = dmgDealt; this.dmgTaken = dmgTaken;
            this.tick = tick;
        }

        // ── NBT ───────────────────────────────────────────────────
        public CompoundTag toNbt() {
            CompoundTag t = new CompoundTag();
            t.putDouble("bx", botX); t.putDouble("by", botY); t.putDouble("bz", botZ);
            t.putFloat("byaw", botYaw); t.putFloat("bpitch", botPitch);
            t.putFloat("bhp", botHp); t.putFloat("bmaxhp", botMaxHp);
            t.putBoolean("spr", botSprinting); t.putBoolean("jmp", botJumping);
            t.putBoolean("snk", botSneaking); t.putBoolean("gnd", botOnGround);
            t.putString("item", botItem);
            t.putDouble("tx", tgtX); t.putDouble("ty", tgtY); t.putDouble("tz", tgtZ);
            t.putFloat("thp", tgtHp); t.putBoolean("htgt", hasTgt);
            t.putString("act", action);
            t.putFloat("dd", dmgDealt); t.putFloat("dt", dmgTaken);
            t.putInt("tick", tick);
            return t;
        }

        public static Frame fromNbt(CompoundTag t) {
            return new Frame(
                t.getDouble("bx"), t.getDouble("by"), t.getDouble("bz"),
                t.getFloat("byaw"), t.getFloat("bpitch"),
                t.getFloat("bhp"), t.getFloat("bmaxhp"),
                t.getBoolean("spr"), t.getBoolean("jmp"),
                t.getBoolean("snk"), t.getBoolean("gnd"),
                t.getString("item"),
                t.getDouble("tx"), t.getDouble("ty"), t.getDouble("tz"),
                t.getFloat("thp"), t.getBoolean("htgt"),
                t.getString("act"),
                t.getFloat("dd"), t.getFloat("dt"),
                t.getInt("tick")
            );
        }
    }

    // ── Сохранённый реплей ────────────────────────────────────────
    public static class SavedReplay {
        public final String       name;
        public final List<Frame>  frames;
        public final long         savedAt; // System.currentTimeMillis()
        public final String       botMode; // режим бота в момент записи

        public SavedReplay(String name, List<Frame> frames, String botMode) {
            this.name    = name;
            this.frames  = Collections.unmodifiableList(new ArrayList<>(frames));
            this.savedAt = System.currentTimeMillis();
            this.botMode = botMode;
        }

        /** Статистика реплея для /bot replay list */
        public String summary() {
            if (frames.isEmpty()) return name + " §7(пусто)";
            float duration = frames.size() * 0.05f;
            float totalDmgDealt = 0, totalDmgTaken = 0;
            int attacks = 0, crits = 0;
            for (Frame f : frames) {
                totalDmgDealt += f.dmgDealt;
                totalDmgTaken += f.dmgTaken;
                if (f.dmgDealt > 0) attacks++;
                if ("CRIT".equals(f.action)) crits++;
            }
            return String.format("§e%s §7[%s, %.1fс, §c+%.0f§7dmg dealt, §4-%.0f§7dmg taken, %d hits (%d crit)]",
                name, botMode, duration, totalDmgDealt, totalDmgTaken, attacks, crits);
        }

        public CompoundTag toNbt() {
            CompoundTag tag = new CompoundTag();
            tag.putString("name", name);
            tag.putString("mode", botMode);
            tag.putLong("savedAt", savedAt);
            ListTag list = new ListTag();
            for (Frame f : frames) list.add(f.toNbt());
            tag.put("frames", list);
            return tag;
        }

        public static SavedReplay fromNbt(CompoundTag tag) {
            String name   = tag.getString("name");
            String mode   = tag.getString("mode");
            ListTag list  = tag.getList("frames", Tag.TAG_COMPOUND);
            List<Frame> frames = new ArrayList<>(list.size());
            for (int i = 0; i < list.size(); i++) {
                frames.add(Frame.fromNbt(list.getCompound(i)));
            }
            return new SavedReplay(name, frames, mode);
        }
    }

    // ── Per-бот буфер записи ──────────────────────────────────────
    private static class BotBuffer {
        /** Кольцевой буфер: массив фиксированного размера */
        private final Frame[] ring = new Frame[BUFFER_TICKS];
        private int  head    = 0;   // следующий индекс для записи
        private int  count   = 0;   // реально записано
        private int  tickSeq = 0;   // порядковый номер тика

        // Для расчёта dmgDealt/dmgTaken между тиками
        private float lastBotHp  = -1f;
        private float lastTgtHp  = -1f;

        // Записывать или нет (можно остановить командой)
        boolean recording = true;

        void record(BotEntity bot, LivingEntity target, String action) {
            if (!recording) return;
            tickSeq++;

            float botHp    = bot.getHealth();
            float botMaxHp = bot.getMaxHealth();
            boolean hasTgt = (target != null && target.isAlive());

            // Вычисляем дельты HP
            float dmgDealt = 0f, dmgTaken = 0f;
            if (lastBotHp >= 0f && botHp < lastBotHp)
                dmgTaken = lastBotHp - botHp;
            if (hasTgt && lastTgtHp >= 0f && target.getHealth() < lastTgtHp)
                dmgDealt = lastTgtHp - target.getHealth();

            lastBotHp = botHp;
            lastTgtHp = hasTgt ? target.getHealth() : -1f;

            // Имя предмета в руке
            ItemStack mainhand = bot.getItemBySlot(EquipmentSlot.MAINHAND);
            String itemName = mainhand.isEmpty() ? "" : mainhand.getItem().toString();

            // Уточняем action: если нанесли урон → CRIT или ATTACK
            String act = action;
            if (dmgDealt > 0 && "ATTACK".equals(act)) act = "ATTACK";
            if (dmgDealt > 10f) act = "CRIT";  // >10 урона за тик = крит

            double tx = 0, ty = 0, tz = 0;
            float  thp = 0;
            if (hasTgt) {
                tx = target.getX(); ty = target.getY(); tz = target.getZ();
                thp = target.getHealth();
            }

            Frame frame = new Frame(
                bot.getX(), bot.getY(), bot.getZ(),
                bot.getYRot(), bot.getXRot(),
                botHp, botMaxHp,
                bot.isSprinting(), bot.jumping, bot.isShiftKeyDown(), bot.onGround(),
                itemName,
                tx, ty, tz, thp, hasTgt,
                act, dmgDealt, dmgTaken, tickSeq
            );

            ring[head] = frame;
            head = (head + 1) % BUFFER_TICKS;
            if (count < BUFFER_TICKS) count++;
        }

        /** Снять кадры в порядке от старого к новому */
        List<Frame> snapshot() {
            List<Frame> out = new ArrayList<>(count);
            if (count == 0) return out;
            int start = count < BUFFER_TICKS ? 0 : head;
            for (int i = 0; i < count; i++) {
                Frame f = ring[(start + i) % BUFFER_TICKS];
                if (f != null) out.add(f);
            }
            return out;
        }

        void reset() {
            Arrays.fill(ring, null);
            head = 0; count = 0; tickSeq = 0;
            lastBotHp = -1f; lastTgtHp = -1f;
        }
    }

    // ── GhostEntity: призрак для воспроизведения ──────────────────
    /**
     * PathfinderMob без AI — телепортируется по кадрам записи.
     * Надевает то же оружие что было у бота. Частицы при ударах/уклонениях.
     */
    public static class GhostEntity extends PathfinderMob {

        private final List<Frame> frames;
        private final double      speedMultiplier; // 0.5 / 1.0 / 2.0
        private       int         frameIndex = 0;
        private       double      fractionalTick = 0.0;
        private       boolean     finished   = false;
        private       int         cleanupTimer = 0;
        private       boolean     paused = false;

        // Кто запросил воспроизведение (для сообщений)
        private final UUID ownerUUID;

        public GhostEntity(EntityType<? extends PathfinderMob> type, Level world,
                           List<Frame> frames, double speed, UUID ownerUUID) {
            super(type, world);
            this.frames       = frames;
            this.speedMultiplier = speed;
            this.ownerUUID    = ownerUUID;
            // Призрак не бьёт и не преследует — отключаем все цели
            this.setNoAi(true);
            this.setInvulnerable(true);
            this.setSilent(false); // звуки оставляем для эффекта
        }

        /** Вызывается из tick() каждый тик */
        @Override
        public void tick() {
            super.tick();

            if (finished) {
                cleanupTimer++;
                if (cleanupTimer >= GHOST_CLEANUP_TICKS) {
                    this.discard();
                    notifyOwner("§7[Replay] Воспроизведение завершено, призрак удалён.");
                }
                return;
            }

            if (paused) return;
            if (!(level() instanceof ServerLevel sw)) return;

            // speedMultiplier > 1 → обрабатываем несколько кадров за тик
            fractionalTick += speedMultiplier;
            while (fractionalTick >= 1.0 && frameIndex < frames.size()) {
                applyFrame(sw, frames.get(frameIndex));
                frameIndex++;
                fractionalTick -= 1.0;
            }

            if (frameIndex >= frames.size()) {
                finished = true;
                notifyOwner("§a[Replay] Конец записи (" + frames.size() + " кадров).");
            }
        }

        private void applyFrame(ServerLevel sw, Frame f) {
            // Телепортируем призрак в позицию бота из записи
            this.teleportTo(f.botX, f.botY, f.botZ);
            this.setYRot(f.botYaw);
            this.setXRot(f.botPitch);

            // Предмет в руке
            if (!f.botItem.isEmpty()) {
                // Упрощённо: узнаём тип предмета по имени и ставим ItemStack
                ItemStack item = resolveItem(f.botItem);
                this.setItemSlot(EquipmentSlot.MAINHAND, item);
            }

            // Частицы и звуки для наглядности
            switch (f.action) {
                case "ATTACK" -> {
                    if (f.dmgDealt > 0) {
                        sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                            f.tgtX, f.tgtY + 1, f.tgtZ, 4, 0.3, 0.3, 0.3, 0);
                        if (f.dmgDealt > 0)
                            this.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.6f, 1.0f);
                    }
                }
                case "CRIT" -> {
                    sw.sendParticles(ParticleTypes.CRIT,
                        f.tgtX, f.tgtY + 1, f.tgtZ, 10, 0.4, 0.4, 0.4, 0.1);
                    this.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 0.8f, 1.0f);
                }
                case "DODGE" -> {
                    sw.sendParticles(ParticleTypes.CLOUD,
                        f.botX, f.botY + 0.5, f.botZ, 5, 0.2, 0.2, 0.2, 0.05);
                }
                case "RETREAT" -> {
                    sw.sendParticles(ParticleTypes.SMOKE,
                        f.botX, f.botY + 0.5, f.botZ, 3, 0.1, 0.2, 0.1, 0.02);
                }
                case "FAKE" -> {
                    sw.sendParticles(ParticleTypes.ENCHANT,
                        f.botX, f.botY + 1, f.botZ, 6, 0.3, 0.3, 0.3, 0.5);
                }
            }

            // Если бот получил урон — красные частицы на позиции призрака
            if (f.dmgTaken > 0) {
                sw.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                    f.botX, f.botY + 1, f.botZ, 4, 0.2, 0.2, 0.2, 0.1);
            }
        }

        /** Превращаем строку-имя предмета в ItemStack */
        private ItemStack resolveItem(String itemName) {
            if (itemName.contains("netherite_sword")) return new ItemStack(Items.NETHERITE_SWORD);
            if (itemName.contains("diamond_sword"))   return new ItemStack(Items.DIAMOND_SWORD);
            if (itemName.contains("netherite_axe"))   return new ItemStack(Items.NETHERITE_AXE);
            if (itemName.contains("diamond_axe"))     return new ItemStack(Items.DIAMOND_AXE);
            if (itemName.contains("mace"))            return new ItemStack(Items.MACE);
            if (itemName.contains("bow"))             return new ItemStack(Items.BOW);
            if (itemName.contains("crossbow"))        return new ItemStack(Items.CROSSBOW);
            if (itemName.contains("trident"))         return new ItemStack(Items.TRIDENT);
            return ItemStack.EMPTY;
        }

        public void setPaused(boolean p) { this.paused = p; }
        public boolean isPaused()        { return paused; }
        public boolean isFinished()      { return finished; }

        public int  getFrameIndex()      { return frameIndex; }
        public int  getTotalFrames()     { return frames.size(); }
        public float getProgress()       { return frames.isEmpty() ? 0f : (float)frameIndex / frames.size(); }

        private void notifyOwner(String msg) {
            // Нотификация владельца — реализуется через PlayerLookup при наличии сервера
            // Здесь оставляем hook: BotEntity.level() → MinecraftServer → PlayerList
            if (level() instanceof ServerLevel sw) {
                var pl = sw.getServer().getPlayerList().getPlayer(ownerUUID);
                if (pl != null) pl.sendSystemMessage(Component.literal(msg));
            }
        }

        // PathfinderMob требует createAttributes
        public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
            return PathfinderMob.createMobAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 20.0)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.0);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Состояние системы
    // ══════════════════════════════════════════════════════════════

    /** UUID бота → его кольцевой буфер */
    private final Map<UUID, BotBuffer> buffers = new ConcurrentHashMap<>();

    /** UUID игрока → его сохранённые реплеи (упорядочены по имени) */
    private final Map<UUID, LinkedHashMap<String, SavedReplay>> saved = new ConcurrentHashMap<>();

    /** UUID игрока → активная GhostEntity (если воспроизводится) */
    private final Map<UUID, GhostEntity> activeGhosts = new ConcurrentHashMap<>();

    /** Скорость воспроизведения по умолчанию */
    private static final double DEFAULT_SPEED = 1.0;

    // ══════════════════════════════════════════════════════════════
    //  API для BotEntity.tick()
    // ══════════════════════════════════════════════════════════════

    /**
     * Вызывать из BotEntity.tick() каждый серверный тик.
     * action — текущее действие (IDLE/ATTACK/CRIT/DODGE/RETREAT/FAKE/BUNKER/TANK).
     */
    public void tickBot(BotEntity bot, LivingEntity target, String action) {
        UUID botUUID = bot.getUUID();
        BotBuffer buf = buffers.computeIfAbsent(botUUID, k -> new BotBuffer());
        buf.record(bot, target, action);
    }

    /** Вызывать при удалении бота (onBotRemoved) чтобы не копить мёртвые буферы */
    public void onBotRemoved(BotEntity bot) {
        buffers.remove(bot.getUUID());
    }

    // ══════════════════════════════════════════════════════════════
    //  Команды (/bot replay ...)
    // ══════════════════════════════════════════════════════════════

    /**
     * Точка входа из ChatCommand / SpawnBotCommand.
     *
     * @param player   игрок выдавший команду
     * @param bot      бот которого касается команда (ближайший к игроку / выбранный)
     * @param sub      подкоманда: start|stop|save|list|play|pause|resume|speed|delete|info
     * @param arg      аргумент (имя реплея, скорость и т.п.)
     */
    public void handleCommand(ServerPlayer player, BotEntity bot, String sub, String arg) {
        UUID puid = player.getUUID();
        switch (sub.toLowerCase()) {

            case "start" -> cmdStart(player, bot);
            case "stop"  -> cmdStop(player, bot);
            case "save"  -> cmdSave(player, bot, arg);
            case "list"  -> cmdList(player);
            case "play"  -> cmdPlay(player, bot, arg);
            case "pause" -> cmdPause(player);
            case "resume"-> cmdResume(player);
            case "speed" -> cmdSpeed(player, arg);
            case "delete"-> cmdDelete(player, arg);
            case "info"  -> cmdInfo(player, bot);
            default      -> player.sendSystemMessage(Component.literal(
                "§cНеизвестная подкоманда replay. Варианты: start stop save list play pause resume speed delete info"));
        }
    }

    // ── start ─────────────────────────────────────────────────────
    private void cmdStart(ServerPlayer player, BotEntity bot) {
        if (bot == null) { noBot(player); return; }
        BotBuffer buf = buffers.computeIfAbsent(bot.getUUID(), k -> new BotBuffer());
        buf.recording = true;
        buf.reset();
        player.sendSystemMessage(Component.literal(
            "§a[Replay] Запись начата для бота §f" + bot.getName().getString() +
            " §7(буфер " + BUFFER_TICKS + " тиков / 30с)"));
    }

    // ── stop ──────────────────────────────────────────────────────
    private void cmdStop(ServerPlayer player, BotEntity bot) {
        if (bot == null) { noBot(player); return; }
        BotBuffer buf = buffers.get(bot.getUUID());
        if (buf == null) {
            player.sendSystemMessage(Component.literal("§c[Replay] Нет активной записи."));
            return;
        }
        buf.recording = false;
        player.sendSystemMessage(Component.literal(
            "§e[Replay] Запись остановлена. §7Кадров в буфере: §f" + buf.count +
            " §7(~" + String.format("%.1f", buf.count * 0.05f) + "с)"));
    }

    // ── save ──────────────────────────────────────────────────────
    private void cmdSave(ServerPlayer player, BotEntity bot, String name) {
        if (bot == null) { noBot(player); return; }
        if (name == null || name.isBlank()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Укажи имя: /bot replay save <name>"));
            return;
        }

        BotBuffer buf = buffers.get(bot.getUUID());
        if (buf == null || buf.count == 0) {
            player.sendSystemMessage(Component.literal("§c[Replay] Буфер пуст. Сначала /bot replay start"));
            return;
        }

        LinkedHashMap<String, SavedReplay> playerSaved =
            saved.computeIfAbsent(player.getUUID(), k -> new LinkedHashMap<>());

        if (playerSaved.size() >= MAX_SAVED_REPLAYS && !playerSaved.containsKey(name)) {
            player.sendSystemMessage(Component.literal(
                "§c[Replay] Достигнут лимит (" + MAX_SAVED_REPLAYS + " реплеев). Удали старый: /bot replay delete <name>"));
            return;
        }

        List<Frame> snap = buf.snapshot();
        String mode = bot.getEffectiveMode() != null ? bot.getEffectiveMode().name() : "?";
        SavedReplay replay = new SavedReplay(name, snap, mode);
        playerSaved.put(name, replay);

        player.sendSystemMessage(Component.literal(
            "§a[Replay] Сохранено §e" + name + " §7(" + snap.size() + " кадров, ~" +
            String.format("%.1f", snap.size() * 0.05f) + "с)"));
    }

    // ── list ──────────────────────────────────────────────────────
    private void cmdList(ServerPlayer player) {
        LinkedHashMap<String, SavedReplay> playerSaved = saved.get(player.getUUID());
        if (playerSaved == null || playerSaved.isEmpty()) {
            player.sendSystemMessage(Component.literal("§7[Replay] Сохранённых реплеев нет."));
            return;
        }
        player.sendSystemMessage(Component.literal("§6══ Сохранённые реплеи ══"));
        int i = 1;
        for (SavedReplay r : playerSaved.values()) {
            player.sendSystemMessage(Component.literal("§8" + i++ + ". " + r.summary()));
        }
        player.sendSystemMessage(Component.literal(
            "§6════════════════════════ §7(" + playerSaved.size() + "/" + MAX_SAVED_REPLAYS + ")"));
    }

    // ── play ──────────────────────────────────────────────────────
    private void cmdPlay(ServerPlayer player, BotEntity bot, String name) {
        // Если активна старая GhostEntity — убираем
        GhostEntity old = activeGhosts.remove(player.getUUID());
        if (old != null && old.isAlive()) old.discard();

        List<Frame> frames;
        String label;

        if (name != null && !name.isBlank()) {
            // Воспроизвести сохранённый
            LinkedHashMap<String, SavedReplay> playerSaved = saved.get(player.getUUID());
            if (playerSaved == null || !playerSaved.containsKey(name)) {
                player.sendSystemMessage(Component.literal(
                    "§c[Replay] Реплей «" + name + "» не найден. /bot replay list"));
                return;
            }
            SavedReplay sr = playerSaved.get(name);
            frames = sr.frames;
            label  = name;
        } else {
            // Воспроизвести текущий буфер бота
            if (bot == null) { noBot(player); return; }
            BotBuffer buf = buffers.get(bot.getUUID());
            if (buf == null || buf.count == 0) {
                player.sendSystemMessage(Component.literal("§c[Replay] Буфер пуст."));
                return;
            }
            frames = buf.snapshot();
            label  = "текущий буфер";
        }

        if (frames.isEmpty()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Кадры не найдены."));
            return;
        }

        if (!(player.level() instanceof ServerLevel sw)) return;

        // Спавним GhostEntity рядом с игроком
        GhostEntity ghost = spawnGhost(sw, player.position(), frames, DEFAULT_SPEED, player.getUUID());
        if (ghost == null) {
            player.sendSystemMessage(Component.literal("§c[Replay] Не удалось создать призрак-сущность."));
            return;
        }
        activeGhosts.put(player.getUUID(), ghost);

        player.sendSystemMessage(Component.literal(
            "§a[Replay] Воспроизведение: §e" + label +
            " §7(" + frames.size() + " кадров, ~" +
            String.format("%.1f", frames.size() * 0.05f) + "с, скорость x" + DEFAULT_SPEED + ")"));
        player.sendSystemMessage(Component.literal(
            "§7Команды: /bot replay pause | resume | speed <0.5|1|2>"));
    }

    // ── pause ─────────────────────────────────────────────────────
    private void cmdPause(ServerPlayer player) {
        GhostEntity ghost = activeGhosts.get(player.getUUID());
        if (ghost == null || !ghost.isAlive()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Нет активного воспроизведения."));
            return;
        }
        ghost.setPaused(true);
        player.sendSystemMessage(Component.literal(
            "§e[Replay] Пауза §7(кадр " + ghost.getFrameIndex() + "/" + ghost.getTotalFrames() + ")"));
    }

    // ── resume ────────────────────────────────────────────────────
    private void cmdResume(ServerPlayer player) {
        GhostEntity ghost = activeGhosts.get(player.getUUID());
        if (ghost == null || !ghost.isAlive()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Нет активного воспроизведения."));
            return;
        }
        if (ghost.isFinished()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Воспроизведение уже завершено."));
            return;
        }
        ghost.setPaused(false);
        player.sendSystemMessage(Component.literal("§a[Replay] Воспроизведение возобновлено."));
    }

    // ── speed ─────────────────────────────────────────────────────
    private void cmdSpeed(ServerPlayer player, String arg) {
        GhostEntity ghost = activeGhosts.get(player.getUUID());
        if (ghost == null || !ghost.isAlive()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Нет активного воспроизведения."));
            return;
        }
        // GhostEntity не поддерживает изменение скорости после создания без рестарта.
        // Проще перезапустить с нужной скоростью от текущего кадра.
        double speed;
        try {
            speed = Double.parseDouble(arg);
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("§c[Replay] Укажи скорость: 0.5 / 1 / 2"));
            return;
        }
        speed = Math.max(0.25, Math.min(4.0, speed));

        // Перезапускаем с текущего кадра
        int from = ghost.getFrameIndex();
        List<Frame> remaining = ghost.frames.subList(Math.min(from, ghost.frames.size()), ghost.frames.size());
        if (!(player.level() instanceof ServerLevel sw)) return;

        ghost.discard();
        activeGhosts.remove(player.getUUID());

        if (remaining.isEmpty()) {
            player.sendSystemMessage(Component.literal("§7[Replay] Запись уже завершена."));
            return;
        }

        GhostEntity newGhost = spawnGhost(sw, player.position(), remaining, speed, player.getUUID());
        if (newGhost != null) {
            activeGhosts.put(player.getUUID(), newGhost);
            player.sendSystemMessage(Component.literal(
                "§a[Replay] Скорость x" + speed + " §7(с кадра " + from + ")"));
        }
    }

    // ── delete ────────────────────────────────────────────────────
    private void cmdDelete(ServerPlayer player, String name) {
        if (name == null || name.isBlank()) {
            player.sendSystemMessage(Component.literal("§c[Replay] Укажи имя: /bot replay delete <name>"));
            return;
        }
        LinkedHashMap<String, SavedReplay> playerSaved = saved.get(player.getUUID());
        if (playerSaved == null || !playerSaved.containsKey(name)) {
            player.sendSystemMessage(Component.literal("§c[Replay] Реплей «" + name + "» не найден."));
            return;
        }
        playerSaved.remove(name);
        player.sendSystemMessage(Component.literal("§7[Replay] Удалено: §e" + name));
    }

    // ── info ──────────────────────────────────────────────────────
    private void cmdInfo(ServerPlayer player, BotEntity bot) {
        if (bot == null) { noBot(player); return; }
        BotBuffer buf = buffers.get(bot.getUUID());
        if (buf == null || buf.count == 0) {
            player.sendSystemMessage(Component.literal("§7[Replay] Буфер пуст."));
            return;
        }
        List<Frame> snap = buf.snapshot();

        // Статистика
        float totalDmgDealt = 0, totalDmgTaken = 0, minHp = Float.MAX_VALUE, maxHp = 0;
        int attacks = 0, crits = 0, dodges = 0, retreats = 0;
        Map<String, Integer> actionCounts = new LinkedHashMap<>();

        for (Frame f : snap) {
            totalDmgDealt += f.dmgDealt;
            totalDmgTaken += f.dmgTaken;
            minHp = Math.min(minHp, f.botHp);
            maxHp = Math.max(maxHp, f.botHp);
            if (f.dmgDealt > 0) attacks++;
            actionCounts.merge(f.action, 1, Integer::sum);
            switch (f.action) {
                case "CRIT"    -> crits++;
                case "DODGE"   -> dodges++;
                case "RETREAT" -> retreats++;
            }
        }

        float duration = snap.size() * 0.05f;
        float dps = duration > 0 ? totalDmgDealt / duration : 0;

        player.sendSystemMessage(Component.literal("§6══ Replay Info: " + bot.getName().getString() + " ══"));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Буфер: §f%d§7 кадров (~§f%.1f§7с) | Запись: %s",
            snap.size(), duration, buf.recording ? "§aАКТИВНА" : "§eОСТАНОВЛЕНА")));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Урон нанесён: §c%.1f §7(DPS §c%.1f§7) | Получено: §4%.1f",
            totalDmgDealt, dps, totalDmgTaken)));
        player.sendSystemMessage(Component.literal(String.format(
            "§7Атаки: §f%d §7| Криты: §f%d §7| Уклон: §f%d §7| Отступ: §f%d",
            attacks, crits, dodges, retreats)));
        player.sendSystemMessage(Component.literal(String.format(
            "§7HP бота: мин §c%.1f §7/ макс §a%.1f", minHp, maxHp)));

        // Топ-3 действия
        actionCounts.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(3)
            .forEach(e -> player.sendSystemMessage(Component.literal(
                "§7  " + e.getKey() + ": §f" + e.getValue() + " §7тиков")));

        player.sendSystemMessage(Component.literal("§6══════════════════════════════"));
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные методы
    // ══════════════════════════════════════════════════════════════

    /**
     * Создаём GhostEntity в мире.
     * Fabric: EntityType должен быть зарегистрирован в PVPBotMod.
     * Здесь используем BotEntity как тип — призрак выглядит как бот.
     */
    private GhostEntity spawnGhost(ServerLevel sw, Vec3 pos, List<Frame> frames,
                                   double speed, UUID ownerUUID) {
        // Берём первый кадр как стартовую позицию призрака
        double sx = pos.x, sy = pos.y, sz = pos.z;
        if (!frames.isEmpty()) {
            Frame f0 = frames.get(0);
            sx = f0.botX; sy = f0.botY; sz = f0.botZ;
        }

        // GhostEntity регистрируется как отдельный EntityType в PVPBotMod.
        // Здесь мы создаём через лямбду аналогично BotEntity.
        // ВАЖНО: в реальной интеграции GhostEntity.TYPE должен быть
        // зарегистрирован в PVPBotMod.registerEntities() аналогично BOT_ENTITY.
        //
        // EntityType<GhostEntity> TYPE = EntityType.Builder
        //   .of(GhostEntity::new, MobCategory.MISC)
        //   .sized(0.6f, 1.8f).build("ghost_entity");
        //
        // До регистрации TYPE: используем BotEntity.TYPE как заглушку.
        // В production-коде: GhostEntity ghost = new GhostEntity(GhostEntity.TYPE, sw, frames, speed, ownerUUID);

        // Stub для компиляции без регистрации EntityType:
        // Реальный спавн активируется после регистрации в PVPBotMod.
        try {
            // Ищем TYPE через reflection если зарегистрирован
            var field = ReplaySystem.class.getDeclaredField("GHOST_ENTITY_TYPE");
            @SuppressWarnings("unchecked")
            EntityType<GhostEntity> type = (EntityType<GhostEntity>) field.get(null);
            GhostEntity ghost = new GhostEntity(type, sw, frames, speed, ownerUUID);
            ghost.moveTo(sx, sy, sz, 0f, 0f);
            sw.addFreshEntity(ghost);
            return ghost;
        } catch (Exception e) {
            // TYPE ещё не зарегистрирован — логируем и возвращаем null
            System.err.println("[ReplaySystem] GhostEntity.TYPE не зарегистрирован: " + e.getMessage());
            System.err.println("[ReplaySystem] Добавь в PVPBotMod.registerEntities():");
            System.err.println("  GHOST_ENTITY_TYPE = EntityType.Builder");
            System.err.println("    .of(GhostEntity::new, MobCategory.MISC)");
            System.err.println("    .sized(0.6f, 1.8f).build(\"pvpbot:ghost\");");
            return null;
        }
    }

    /** Статическое поле для EntityType — заполняется из PVPBotMod при регистрации */
    @SuppressWarnings("unused")
    public static EntityType<GhostEntity> GHOST_ENTITY_TYPE;

    private void noBot(ServerPlayer player) {
        player.sendSystemMessage(Component.literal(
            "§c[Replay] Бот не найден. Используй команду рядом с ботом."));
    }

    // ══════════════════════════════════════════════════════════════
    //  NBT-сериализация всех реплеев игрока
    // ══════════════════════════════════════════════════════════════

    /**
     * Сохранить все реплеи игрока в NBT (для записи на диск или передачи).
     * Пример: вызвать при отключении игрока → записать в PlayerData.
     */
    public CompoundTag serializePlayer(UUID playerUUID) {
        CompoundTag root = new CompoundTag();
        LinkedHashMap<String, SavedReplay> playerSaved = saved.get(playerUUID);
        if (playerSaved == null || playerSaved.isEmpty()) return root;
        ListTag list = new ListTag();
        for (SavedReplay r : playerSaved.values()) list.add(r.toNbt());
        root.put("replays", list);
        return root;
    }

    /**
     * Загрузить реплеи игрока из NBT (например, при входе на сервер).
     */
    public void deserializePlayer(UUID playerUUID, CompoundTag root) {
        if (!root.contains("replays")) return;
        ListTag list = root.getList("replays", Tag.TAG_COMPOUND);
        LinkedHashMap<String, SavedReplay> playerSaved =
            saved.computeIfAbsent(playerUUID, k -> new LinkedHashMap<>());
        for (int i = 0; i < list.size(); i++) {
            SavedReplay r = SavedReplay.fromNbt(list.getCompound(i));
            playerSaved.put(r.name, r);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Геттеры для GUI (StatsTabRenderer / ReplayTabRenderer)
    // ══════════════════════════════════════════════════════════════

    public boolean hasBuffer(BotEntity bot) {
        BotBuffer buf = buffers.get(bot.getUUID());
        return buf != null && buf.count > 0;
    }

    public int getBufferCount(BotEntity bot) {
        BotBuffer buf = buffers.get(bot.getUUID());
        return buf == null ? 0 : buf.count;
    }

    public boolean isRecording(BotEntity bot) {
        BotBuffer buf = buffers.get(bot.getUUID());
        return buf != null && buf.recording;
    }

    public boolean hasActiveGhost(ServerPlayer player) {
        GhostEntity g = activeGhosts.get(player.getUUID());
        return g != null && g.isAlive() && !g.isFinished();
    }

    public float getGhostProgress(ServerPlayer player) {
        GhostEntity g = activeGhosts.get(player.getUUID());
        return g != null ? g.getProgress() : 0f;
    }

    /** Список сохранённых реплеев игрока (для GUI). Копия чтобы не ломать ConcurrentHashMap. */
    public List<SavedReplay> getSaved(UUID playerUUID) {
        LinkedHashMap<String, SavedReplay> m = saved.get(playerUUID);
        if (m == null) return Collections.emptyList();
        return new ArrayList<>(m.values());
    }
}
