package com.pvpbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * BotPingTracker v1.0 — отслеживание пинга игроков для упреждающего предсказания.
 *
 * Зачем нужен:
 *   На высоком пинге (>100ms) бот бьёт "в прошлое" — враг уже ушёл с этой позиции.
 *   BotPingTracker корректирует предсказанную позицию (PatternAI.getPredictedPosition)
 *   на дополнительные PING_TICKS тиков вперёд.
 *
 * Интеграция:
 *   1. BotPingTracker.INSTANCE.update(serverPlayer) — в ServerPlayerMixin или TickEvent
 *   2. PatternAI.getPredictedPosition() → добавить корректировку:
 *      int extraTicks = BotPingTracker.INSTANCE.getPingTicks(target.getUUID());
 *      predictedX += emaVx * extraTicks;
 *
 * Команда: !ping — показывает пинг всех игроков в зоне (для дебага)
 */
public class BotPingTracker {

    public static final BotPingTracker INSTANCE = new BotPingTracker();

    // ── Константы ─────────────────────────────────────────────────
    private static final int   UPDATE_INTERVAL  = 20;   // раз в секунду
    private static final float EMA_ALPHA        = 0.3f; // сглаживание пинга
    private static final int   HIGH_PING_MS     = 100;  // выше → +1 тик предсказания
    private static final int   VERY_HIGH_PING   = 200;  // выше → +2 тика

    // ── Данные ────────────────────────────────────────────────────
    private final Map<UUID, Float> smoothedPing = new HashMap<>();
    private int updateTimer = 0;

    private BotPingTracker() {}

    // ══════════════════════════════════════════════════════════════
    //  Обновление (вызывать раз в тик из серверного обработчика)
    // ══════════════════════════════════════════════════════════════
    public void tickServer(net.minecraft.server.MinecraftServer server) {
        if (++updateTimer < UPDATE_INTERVAL) return;
        updateTimer = 0;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            int rawPing = player.connection.latency();
            float prev  = smoothedPing.getOrDefault(player.getUUID(), (float) rawPing);
            float ema   = EMA_ALPHA * rawPing + (1.0f - EMA_ALPHA) * prev;
            smoothedPing.put(player.getUUID(), ema);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /**
     * Получить сглаженный пинг игрока (ms).
     * @return -1 если игрок неизвестен (не ServerPlayer или не отслеживается)
     */
    public float getPingMs(UUID uuid) {
        return smoothedPing.getOrDefault(uuid, -1f);
    }

    /**
     * Количество дополнительных тиков предсказания для компенсации пинга.
     * 0  → ping < 100ms (компенсация не нужна)
     * 1  → ping 100..200ms
     * 2  → ping > 200ms
     */
    public int getPingTicks(UUID uuid) {
        float ping = getPingMs(uuid);
        if (ping < 0)              return 0;
        if (ping > VERY_HIGH_PING) return 2;
        if (ping > HIGH_PING_MS)   return 1;
        return 0;
    }

    /**
     * Удобный метод: получить коррекцию для конкретной LivingEntity.
     * Возвращает 0 если цель не ServerPlayer.
     */
    public int getPingTicks(LivingEntity target) {
        if (!(target instanceof Player)) return 0;
        return getPingTicks(target.getUUID());
    }

    /** Форматированная строка для /bot ping команды. */
    public String formatPing(UUID uuid) {
        float ping = getPingMs(uuid);
        if (ping < 0) return "§7unknown";
        String color = ping < 50 ? "§a" : ping < 100 ? "§e" : ping < 200 ? "§6" : "§c";
        return color + String.format("%.0fms", ping);
    }

    /** Удалить игрока из реестра (при дисконнекте). */
    public void removePlayer(UUID uuid) {
        smoothedPing.remove(uuid);
    }

    /** Очистить всё (при остановке сервера). */
    public void reset() {
        smoothedPing.clear();
        updateTimer = 0;
    }
}
