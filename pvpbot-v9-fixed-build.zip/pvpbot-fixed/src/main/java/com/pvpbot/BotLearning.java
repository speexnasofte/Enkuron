package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * BotLearning v2.0 — обучение бота на поведении реального игрока.
 *
 * FIX v1.6.8: Синглтон заменён на per-owner реестр.
 *   Старый INSTANCE смешивал данные всех игроков при нескольких
 *   активных пользователях /bot learn. Теперь каждый игрок (owner)
 *   имеет свой изолированный экземпляр BotLearning.
 *
 *   API-совместимость сохранена: INSTANCE остался для одиночного
 *   режима / мест где ownerUUID недоступен — указывает на «глобальный»
 *   экземпляр UUID_GLOBAL (нулевой UUID).
 *
 * Что записывает:
 *   - Паттерны движения (стрейф, zigzag, circle)
 *   - Тайминги атак (когда наносит удар, cooldown)
 *   - Использование гаплов (при каком HP)
 *   - Прыжки при атаке (крит)
 *   - Повторяющиеся последовательности (combo)
 *
 * Как использует PatternAI:
 *   - PatternAI.getLearnedPattern() → берёт топ-паттерн из BotLearning
 *   - Бот начинает повторять эти паттерны в бою
 *
 * Интеграция:
 *   1. BotLearning.forOwner(uuid).tick(player) — в серверном тике
 *   2. PatternAI берёт экземпляр через BotEntity.getOwnerUUID()
 *
 * Команды:
 *   /bot learn start  — начать запись
 *   /bot learn stop   — остановить
 *   /bot learn reset  — сбросить записанные паттерны
 *   /bot learn status — показать топ-паттерны
 */
public class BotLearning {

    // ── Per-owner реестр (FIX v1.6.8) ────────────────────────────
    private static final UUID UUID_GLOBAL = new UUID(0, 0);
    /** Глобальный синглтон для обратной совместимости (одиночный режим). */
    public static final BotLearning INSTANCE = new BotLearning(UUID_GLOBAL);

    /** Реестр: ownerUUID → экземпляр. */
    private static final Map<UUID, BotLearning> REGISTRY = new HashMap<>();

    static {
        REGISTRY.put(UUID_GLOBAL, INSTANCE);
    }

    /**
     * Получить (или создать) BotLearning для конкретного владельца бота.
     * @param ownerUUID UUID игрока-владельца; null → глобальный INSTANCE
     */
    public static BotLearning forOwner(UUID ownerUUID) {
        if (ownerUUID == null) return INSTANCE;
        return REGISTRY.computeIfAbsent(ownerUUID, BotLearning::new);
    }

    /**
     * Удалить экземпляр из реестра (например, при выходе игрока с сервера).
     * Вызывать из DISCONNECT-обработчика в PVPBotMod.
     */
    public static void removeOwner(UUID ownerUUID) {
        if (ownerUUID == null || ownerUUID.equals(UUID_GLOBAL)) return;
        REGISTRY.remove(ownerUUID);
    }

    /** @return все UUID у которых есть активная запись. */
    public static List<UUID> recordingOwners() {
        List<UUID> result = new ArrayList<>();
        for (Map.Entry<UUID, BotLearning> e : REGISTRY.entrySet()) {
            if (e.getValue().isRecording()) result.add(e.getKey());
        }
        return result;
    }

    // ── Настройки ─────────────────────────────────────────────────
    /** Максимальная длина записываемой последовательности */
    private static final int MAX_SEQUENCE_LEN = 64;
    /** Количество топ-паттернов для хранения */
    private static final int TOP_PATTERNS = 8;
    /** Минимум повторений чтобы паттерн считался "выученным" */
    private static final int MIN_REPEAT = 3;

    // ── Типы действий ─────────────────────────────────────────────
    public enum Action {
        MOVE_LEFT,   // A
        MOVE_RIGHT,  // D
        MOVE_BACK,   // S
        MOVE_FORWARD,// W
        ATTACK,      // ЛКМ
        JUMP,        // пробел
        SPRINT,      // sprint
        USE_GAPPLE,  // ПКМ гапл
        STOP         // стоит
    }

    // ── Паттерн (последовательность действий) ────────────────────
    public static class Pattern {
        public final List<Action> actions;
        public int frequency = 1;
        public double avgHpOnGapple = 0;
        public int attackCritRatio = 0; // процент критов

        public Pattern(List<Action> actions) {
            this.actions = new ArrayList<>(actions);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pattern)) return false;
            return actions.equals(((Pattern) o).actions);
        }

        @Override
        public int hashCode() { return actions.hashCode(); }
    }

    // ── Состояние экземпляра ───────────────────────────────────────
    /** UUID владельца — только для отладки/логов */
    @SuppressWarnings("unused")
    private final UUID ownerUUID;

    private boolean recording = false;
    private final List<Action> currentSequence = new ArrayList<>();
    private final Map<Pattern, Integer> patternFreq = new LinkedHashMap<>();
    private int tickCounter = 0;
    private static final int SAMPLE_INTERVAL = 2; // каждые 2 тика

    // Данные о предыдущем тике для определения действий
    private Vec3 lastPos = null;
    private float lastHp = 20.0f;
    private boolean lastOnGround = true;

    private BotLearning(UUID ownerUUID) {
        this.ownerUUID = ownerUUID;
    }

    // ── API ───────────────────────────────────────────────────────

    public boolean isRecording() { return recording; }

    public void startRecording() {
        recording = true;
        currentSequence.clear();
        lastPos = null;
    }

    public void stopRecording() {
        recording = false;
        if (!currentSequence.isEmpty()) {
            savePattern(new ArrayList<>(currentSequence));
        }
        currentSequence.clear();
    }

    public void reset() {
        patternFreq.clear();
        currentSequence.clear();
        recording = false;
    }

    /**
     * Тик — записываем действия игрока.
     * Вызывать из ServerTickHandler или аналога.
     */
    public void tick(Player player) {
        if (!recording) return;

        tickCounter++;
        if (tickCounter % SAMPLE_INTERVAL != 0) return;

        Action action = sampleAction(player);
        if (action != null) {
            currentSequence.add(action);
            if (currentSequence.size() >= MAX_SEQUENCE_LEN) {
                savePattern(new ArrayList<>(currentSequence));
                currentSequence.clear();
            }
        }

        // Трекинг использования гапла
        float currentHp = player.getHealth();
        if (currentHp > lastHp + 4.0f) {
            recordGappleHp(lastHp);
        }
        lastHp = currentHp;
        lastPos = player.position();
    }

    /** Определить действие игрока в этом тике. */
    private Action sampleAction(Player player) {
        Vec3 pos = player.position();
        if (lastPos == null) { lastPos = pos; return null; }

        Vec3 delta = pos.subtract(lastPos);
        float yaw = player.getYRot();
        double rad = Math.toRadians(yaw);
        double fwdX = -Math.sin(rad), fwdZ = Math.cos(rad);
        double rtX = Math.cos(rad),  rtZ = Math.sin(rad);

        double fwdDot = delta.x * fwdX + delta.z * fwdZ;
        double rtDot  = delta.x * rtX  + delta.z * rtZ;

        if (Math.abs(fwdDot) < 0.01 && Math.abs(rtDot) < 0.01) return Action.STOP;
        if (!player.onGround() && lastOnGround) {
            lastOnGround = false;
            return Action.JUMP;
        }
        if (rtDot > 0.05)  return Action.MOVE_RIGHT;
        if (rtDot < -0.05) return Action.MOVE_LEFT;
        if (fwdDot < -0.05) return Action.MOVE_BACK;
        if (fwdDot > 0.05)  return Action.MOVE_FORWARD;

        lastOnGround = player.onGround();
        return null;
    }

    /** Записать паттерн в частотную таблицу. */
    private void savePattern(List<Action> seq) {
        for (int len = 4; len <= Math.min(8, seq.size()); len++) {
            for (int start = 0; start + len <= seq.size(); start++) {
                Pattern pat = new Pattern(seq.subList(start, start + len));
                patternFreq.merge(pat, 1, Integer::sum);
            }
        }
        prunePatterns();
    }

    private void prunePatterns() {
        if (patternFreq.size() <= TOP_PATTERNS * 2) return;
        List<Map.Entry<Pattern, Integer>> sorted = new ArrayList<>(patternFreq.entrySet());
        sorted.sort(Map.Entry.<Pattern, Integer>comparingByValue().reversed());
        patternFreq.clear();
        sorted.stream().limit(TOP_PATTERNS).forEach(e -> patternFreq.put(e.getKey(), e.getValue()));
    }

    private void recordGappleHp(float hp) {
        GappleOptimizer.INSTANCE.recordGappleEvent(hp);
    }

    // ── PatternAI интерфейс ───────────────────────────────────────

    public List<Action> getTopPattern() {
        return patternFreq.entrySet().stream()
            .filter(e -> e.getValue() >= MIN_REPEAT)
            .max(Map.Entry.comparingByValue())
            .map(e -> e.getKey().actions)
            .orElse(null);
    }

    public List<Pattern> getTopPatterns(int n) {
        List<Pattern> result = new ArrayList<>();
        patternFreq.entrySet().stream()
            .filter(e -> e.getValue() >= MIN_REPEAT)
            .sorted(Map.Entry.<Pattern, Integer>comparingByValue().reversed())
            .limit(n)
            .forEach(e -> {
                Pattern p = e.getKey();
                p.frequency = e.getValue();
                result.add(p);
            });
        return result;
    }

    public String formatStatus() {
        List<Pattern> top = getTopPatterns(5);
        if (top.isEmpty()) return "§7BotLearning: паттернов нет. §f/bot learn start";
        StringBuilder sb = new StringBuilder("§e§lBotLearning — Топ паттерны:\n");
        for (int i = 0; i < top.size(); i++) {
            Pattern p = top.get(i);
            sb.append("§f#").append(i + 1).append(" §7[×").append(p.frequency).append("] §f");
            for (Action a : p.actions) sb.append(actionShort(a));
            sb.append("\n");
        }
        sb.append("§7Всего паттернов: §f").append(patternFreq.size());
        return sb.toString();
    }

    private String actionShort(Action a) {
        return switch (a) {
            case MOVE_LEFT    -> "←";
            case MOVE_RIGHT   -> "→";
            case MOVE_BACK    -> "↓";
            case MOVE_FORWARD -> "↑";
            case ATTACK       -> "⚔";
            case JUMP         -> "↑↑";
            case SPRINT       -> "≫";
            case USE_GAPPLE   -> "🍎";
            case STOP         -> "•";
            default     -> "?";
        };
    }

    public int getPatternCount() { return patternFreq.size(); }
}
