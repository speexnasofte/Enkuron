package com.pvpbot;

import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;

/**
 * KillStreak v1.0 — серия убийств без смерти бота.
 *
 * Отслеживает:
 *  - Текущую серию килов (currentStreak)
 *  - Рекорд серии за сессию (bestStreak)
 *  - Оповещение владельца при milestone (3, 5, 10, ...)
 *  - Специальные сообщения в чат при +5 и +10 (broadcast)
 *
 * Интеграция:
 *   bot.getKillStreak().onKill(killer);   // в KillDeathTracker или doHurtTarget
 *   bot.getKillStreak().onDeath();        // в BotEntity.die()
 *   bot.getKillStreak().getCurrent();     // для HUD
 */
public class KillStreak {

    // ── Milestone-пороги для оповещений ──────────────────────────
    private static final int[] MILESTONES        = {3, 5, 10, 15, 20};
    private static final int   BROADCAST_STREAK  = 5;  // публично в чат с 5+

    // ── Сообщения для серий ───────────────────────────────────────
    private static final String[] STREAK_MSGS = {
        "",                              // 0 - не используется
        "",                              // 1
        "",                              // 2
        "§e🔥 Triple Kill!",             // 3
        "§6🔥 Dominating! ×4",           // 4
        "§c🔥 Killing Spree! ×5",        // 5
        "", "", "", "",                  // 6-9
        "§4§l💀 UNSTOPPABLE! ×10",       // 10
        "", "", "", "", "",              // 11-14
        "§5§l⚡ GODLIKE! ×15",           // 15
        "", "", "", "", "",              // 16-19
        "§b§l★ LEGENDARY! ×20",          // 20
    };

    private final BotEntity bot;

    // ── Состояние ─────────────────────────────────────────────────
    private int currentStreak = 0;
    private int bestStreak    = 0;
    private int totalKills    = 0;

    public KillStreak(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Событие: убийство
    // ══════════════════════════════════════════════════════════════

    public void onKill(net.minecraft.world.entity.LivingEntity victim) {
        currentStreak++;
        totalKills++;
        if (currentStreak > bestStreak) bestStreak = currentStreak;

        Player owner = bot.getOwner();

        // Оповещение владельцу при любом kilе
        if (owner != null) {
            String victimName = victim != null ? victim.getName().getString() : "?";
            owner.displayClientMessage(Component.literal(
                "§7[" + bot.getName().getString() + "] §f⚔ Убил §c" + victimName
                + " §7(серия: §e" + currentStreak + "§7)"), false);
        }

        // Milestone-сообщение (владельцу)
        String streakMsg = getStreakMsg(currentStreak);
        if (!streakMsg.isEmpty() && owner != null) {
            owner.displayClientMessage(Component.literal(
                "§7[" + bot.getName().getString() + "] " + streakMsg), false);
        }

        // Broadcast при BROADCAST_STREAK+ (видно всем)
        if (currentStreak >= BROADCAST_STREAK && !streakMsg.isEmpty()
                && bot.getServer() != null) {
            bot.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("§7[PVPBot] §f" + bot.getName().getString()
                    + " " + streakMsg), false);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Событие: смерть бота
    // ══════════════════════════════════════════════════════════════

    public void onDeath() {
        if (currentStreak >= 3) {
            Player owner = bot.getOwner();
            if (owner != null) {
                owner.displayClientMessage(Component.literal(
                    "§7[" + bot.getName().getString() + "] §cСерия прервана §7("
                    + currentStreak + " килов). Рекорд: §e" + bestStreak), false);
            }
        }
        currentStreak = 0;
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    public int getCurrent()    { return currentStreak; }
    public int getBest()       { return bestStreak; }
    public int getTotalKills() { return totalKills; }

    /** Полный сброс (при /bot remove или начале новой сессии). */
    public void reset() {
        currentStreak = 0;
        bestStreak    = 0;
        totalKills    = 0;
    }

    /** Форматированная строка для HUD или !debug. */
    public String getHudString() {
        if (currentStreak == 0) return "";
        return String.format("§e×%d §7(best:§6%d§7)", currentStreak, bestStreak);
    }

    // ── Вспомогательные ───────────────────────────────────────────
    private static String getStreakMsg(int streak) {
        if (streak < STREAK_MSGS.length) return STREAK_MSGS[streak];
        if (streak >= 20 && streak % 5 == 0)
            return "§b§l★ LEGENDARY ×" + streak + "!";
        return "";
    }
}
