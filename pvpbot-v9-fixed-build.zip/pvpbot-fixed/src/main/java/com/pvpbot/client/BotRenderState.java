package com.pvpbot.client;

import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.ResourceLocation;

/**
 * Кастомный рендер-стейт для BotEntity.
 * Хранит загруженную текстуру скина, чтобы передать её в getTextureLocation().
 */
public class BotRenderState extends HumanoidRenderState {
    public ResourceLocation skinTexture = null;
}
