package com.pvpbot.client;

import com.pvpbot.BotEntity;
import com.pvpbot.BotSkinManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * BotEntityRenderer v11 — рендерит бота с моделью игрока, скином и бронёй.
 *
 * FIX v11 (скин): extractRenderState() передаёт загруженную текстуру из
 * BotSkinManager в BotRenderState.skinTexture, откуда getTextureLocation()
 * её берёт. Раньше жёстко возвращался STEVE_TEXTURE — скин игнорировался.
 *
 * FIX v10 (броня): добавлен HumanoidArmorLayer — без него броня не рендерилась.
 */
public class BotEntityRenderer extends HumanoidMobRenderer<BotEntity, BotRenderState, HumanoidModel<BotRenderState>> {

    private static final ResourceLocation STEVE_TEXTURE =
        ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/player/wide/steve.png");

    public BotEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)),
            0.5f);

        // Слой брони — рендерит шлем/нагрудник/штаны/ботинки поверх модели
        this.addLayer(new HumanoidArmorLayer<>(
            this,
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
            new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
            ctx.getEquipmentRenderer()
        ));
    }

    @Override
    public BotRenderState createRenderState() {
        return new BotRenderState();
    }

    /**
     * Заполняем render state данными из entity.
     * super.extractRenderState() заполняет броню/позу/анимации.
     * Мы дополнительно кладём текстуру скина.
     */
    @Override
    public void extractRenderState(BotEntity entity, BotRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        String nick = entity.getSkinNick();
        if (nick != null && !nick.isEmpty()) {
            // prefetch запускает загрузку если ещё не началась
            BotSkinManager.INSTANCE.prefetch(nick);
            state.skinTexture = BotSkinManager.INSTANCE.getSkinTexture(nick);
        } else {
            state.skinTexture = null;
        }
    }

    /**
     * Возвращает текстуру скина если загружена, иначе Стив как fallback.
     */
    @Override
    public ResourceLocation getTextureLocation(BotRenderState state) {
        return state.skinTexture != null ? state.skinTexture : STEVE_TEXTURE;
    }
}
