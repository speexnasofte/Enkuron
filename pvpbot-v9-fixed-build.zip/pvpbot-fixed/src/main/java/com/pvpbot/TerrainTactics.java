package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;

/**
 * TerrainTactics v1.0 — тактическое использование рельефа.
 *
 * Что делает:
 *   1. HEIGHT ADVANTAGE — бот ищет позицию выше цели (≥2 блока)
 *      и атакует сверху вниз (получает крит от высоты).
 *   2. WATER/LAVA PUSH — если рядом вода или лава,
 *      бот толкает цель туда velocity-импульсом.
 *   3. EDGE PUSH — находит край обрыва рядом с целью
 *      и толкает её к краю (knockback в сторону обрыва).
 *   4. HIGH GROUND SEEK — если бот ниже цели, ищет путь
 *      на возвышенность в радиусе SCAN_RADIUS.
 *
 * Интеграция:
 *   - TerrainTactics tactic = new TerrainTactics(bot);  // в BotDifficultyAI/SwordLogic
 *   - tactic.tick(target, sw);  // раз в EVAL_INTERVAL тиков
 *   - tactic.shouldSeekHighGround() → бот идёт на высоту вместо атаки в лоб
 *   - tactic.getPushDir()         → Vec3 для velocity-толчка (или null)
 */
public class TerrainTactics {

    // v1.6.8: глобальный INSTANCE для HUD (не привязан к конкретному боту —
    // используется только для чтения состояния тактики в renderAiStatusRow).
    // Для боевой логики создавать new TerrainTactics(bot) как раньше.
    public static final TerrainTactics INSTANCE = new TerrainTactics(null);

    /**
     * Вернуть короткий лейбл активной тактики для HUD (≤4 символа).
     * Null или пустая строка = нет активной тактики.
     */
    public String getActiveTacticLabel() {
        if (targetNearLava)  return "🔥";
        if (targetNearEdge)  return "⬇";
        if (hasHeightAdv)    return "⬆";
        if (targetNearWater) return "~";
        return null;
    }

    // ── Параметры ─────────────────────────────────────────────────
    private static final int    EVAL_INTERVAL    = 15;   // тиков между оценками рельефа
    private static final double SCAN_RADIUS      = 8.0;  // блоков — радиус поиска высоты/воды
    private static final double HEIGHT_ADV_MIN   = 2.0;  // минимальный перевес по высоте (блоков)
    private static final double PUSH_RANGE       = 4.5;  // максимальная дистанция для толчка
    private static final double PUSH_STRENGTH    = 0.55; // сила velocity-толчка
    private static final double PUSH_UP          = 0.25; // вертикальная составляющая толчка
    private static final double EDGE_DROP_MIN    = 3.0;  // минимальная высота обрыва (блоков)
    private static final int    PUSH_COOLDOWN    = 40;   // тиков между толчками

    // ── Состояние ─────────────────────────────────────────────────
    private int    evalTimer    = 0;
    private int    pushCooldown = 0;

    private boolean hasHeightAdv    = false;   // бот выше цели
    private boolean targetNearWater = false;   // вода рядом с целью
    private boolean targetNearLava  = false;   // лава рядом с целью
    private boolean targetNearEdge  = false;   // обрыв рядом с целью

    private Vec3    pushDir         = null;    // направление толчка (null = нет)
    private Vec3    highGroundPos   = null;    // позиция высокой точки для подъёма

    private final BotEntity bot;

    public TerrainTactics(BotEntity bot) {
        this.bot = bot;
    }

    // ── Главный тик ───────────────────────────────────────────────

    /**
     * Обновляет оценку рельефа. Вызывать каждый тик из SwordLogic/BotDifficultyAI.
     * Тяжёлые расчёты происходят только раз в EVAL_INTERVAL тиков.
     */
    public void tick(LivingEntity target, ServerLevel sw) {
        if (pushCooldown > 0) pushCooldown--;
        evalTimer--;
        if (evalTimer > 0) return;
        evalTimer = EVAL_INTERVAL;

        if (target == null || !target.isAlive()) {
            reset();
            return;
        }

        double botY    = bot.getY();
        double targetY = target.getY();

        // 1. Перевес по высоте
        hasHeightAdv = (botY - targetY) >= HEIGHT_ADV_MIN;

        // 2. Сканируем рельеф вокруг цели
        scanTargetSurroundings(target, sw);

        // 3. Ищем высокую точку для подъёма (если мы ниже)
        if (!hasHeightAdv) {
            highGroundPos = findHighGround(sw, target);
        } else {
            highGroundPos = null;
        }
    }

    // ── API для внешних классов ───────────────────────────────────

    /** true = у бота преимущество высоты → атака будет критом */
    public boolean hasHeightAdvantage() { return hasHeightAdv; }

    /** true = нужно подняться на высоту перед атакой */
    public boolean shouldSeekHighGround() {
        return !hasHeightAdv && highGroundPos != null
            && PVPBotConfig.INSTANCE.terrainEnabled;
    }

    /** Позиция высокой точки для навигации (null если не найдена) */
    public Vec3 getHighGroundPos() { return highGroundPos; }

    /**
     * Выполнить толчок цели в опасное место (вода/лава/край).
     * @return true если толчок был выполнен
     */
    public boolean tryPush(LivingEntity target, ServerLevel sw) {
        if (!PVPBotConfig.INSTANCE.terrainEnabled) return false;
        if (pushCooldown > 0) return false;
        if (bot.distanceTo(target) > PUSH_RANGE) return false;
        if (pushDir == null) return false;

        // Применяем velocity-импульс к цели
        Vec3 current = target.getDeltaMovement();
        target.setDeltaMovement(
            current.x + pushDir.x * PUSH_STRENGTH,
            current.y + PUSH_UP,
            current.z + pushDir.z * PUSH_STRENGTH
        );
        target.hurtMarked = true; // синхронизировать velocity на клиенте

        pushCooldown = PUSH_COOLDOWN;

        // Частицы для обратной связи
        sw.sendParticles(
            net.minecraft.core.particles.ParticleTypes.SWEEP_ATTACK,
            target.getX(), target.getY() + 0.5, target.getZ(),
            3, 0.3, 0.1, 0.3, 0.05
        );
        return true;
    }

    /** Есть ли опасное место рядом с целью (вода/лава/край) */
    public boolean hasHazardNearTarget() {
        return targetNearWater || targetNearLava || targetNearEdge;
    }

    // ── Внутренняя логика ─────────────────────────────────────────

    private void scanTargetSurroundings(LivingEntity target, ServerLevel sw) {
        targetNearWater = false;
        targetNearLava  = false;
        targetNearEdge  = false;
        pushDir         = null;

        Vec3 targetPos = target.position();
        BlockPos targetBlock = BlockPos.containing(targetPos);

        // Проверяем 8 направлений вокруг цели
        int[][] offsets = {
            {1,0}, {-1,0}, {0,1}, {0,-1},
            {1,1}, {1,-1}, {-1,1}, {-1,-1}
        };

        for (int[] off : offsets) {
            BlockPos check = targetBlock.offset(off[0], 0, off[1]);

            // Вода
            if (sw.getFluidState(check).is(Fluids.WATER)
                    || sw.getFluidState(check).is(Fluids.FLOWING_WATER)) {
                targetNearWater = true;
                // Вектор толчка ОТ бота К воде
                Vec3 toHazard = new Vec3(off[0], 0, off[1]).normalize();
                if (pushDir == null) pushDir = toHazard;
            }

            // Лава (приоритет выше воды)
            if (sw.getFluidState(check).is(Fluids.LAVA)
                    || sw.getFluidState(check).is(Fluids.FLOWING_LAVA)) {
                targetNearLava = true;
                pushDir = new Vec3(off[0], 0, off[1]).normalize();
            }

            // Обрыв: блок воздух + под ним тоже воздух ещё EDGE_DROP_MIN блоков
            if (sw.getBlockState(check).isAir()) {
                int dropDepth = 0;
                for (int dy = -1; dy >= -(int) EDGE_DROP_MIN - 1; dy--) {
                    if (sw.getBlockState(check.offset(0, dy, 0)).isAir()) dropDepth++;
                    else break;
                }
                if (dropDepth >= (int) EDGE_DROP_MIN) {
                    targetNearEdge = true;
                    Vec3 toEdge = new Vec3(off[0], 0, off[1]).normalize();
                    // Обрыв менее приоритетен чем лава — не перезаписываем лаву
                    if (!targetNearLava) pushDir = toEdge;
                }
            }
        }
    }

    /**
     * Ищет блок выше бота и цели в радиусе SCAN_RADIUS.
     * Возвращает центр верхней поверхности найденного блока.
     */
    private Vec3 findHighGround(ServerLevel sw, LivingEntity target) {
        BlockPos botBlock = BlockPos.containing(bot.position());
        double targetY = target.getY();
        double botY    = bot.getY();
        double bestY   = botY + HEIGHT_ADV_MIN - 1; // минимальная «высокая» точка
        BlockPos bestPos = null;

        int r = (int) SCAN_RADIUS;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx*dx + dz*dz > r*r) continue; // круг
                BlockPos col = botBlock.offset(dx, 0, dz);

                // Ищем поверхность (самый высокий solid блок в колонне ±8 по Y)
                for (int dy = 8; dy >= -4; dy--) {
                    BlockPos pos = col.offset(0, dy, 0);
                    BlockPos above = pos.above();
                    BlockPos above2 = pos.above(2);
                    if (sw.getBlockState(pos).isSolid()
                            && sw.getBlockState(above).isAir()
                            && sw.getBlockState(above2).isAir()) {
                        double surfaceY = pos.getY() + 1.0;
                        if (surfaceY > bestY && surfaceY > targetY + HEIGHT_ADV_MIN) {
                            bestY   = surfaceY;
                            bestPos = above;
                        }
                        break; // нашли поверхность в этой колонне
                    }
                }
            }
        }

        if (bestPos == null) return null;
        return new Vec3(bestPos.getX() + 0.5, bestPos.getY(), bestPos.getZ() + 0.5);
    }

    private void reset() {
        hasHeightAdv    = false;
        targetNearWater = false;
        targetNearLava  = false;
        targetNearEdge  = false;
        pushDir         = null;
        highGroundPos   = null;
    }
}
