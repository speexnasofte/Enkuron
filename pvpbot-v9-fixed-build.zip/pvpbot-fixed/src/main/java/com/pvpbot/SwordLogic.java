package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * SwordLogic v1.0 — полная боевая логика для меча.
 *
 * Извлечена из BotDifficultyAI и значительно расширена.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ТЕХНИКИ (по уровням сложности):
 *
 *  EASY:
 *   - Прямолинейное движение к цели
 *   - Случайные промахи (15%)
 *   - Медленный attackCooldown
 *
 *  MEDIUM:
 *   - W-tap (onAttack → WTapLogic)
 *   - Базовый страф (StrafeAI)
 *   - Крит-прыжок каждые MEDIUM_CRIT_EVERY ударов
 *   - Gap при HP < GAP_HP_MEDIUM
 *
 *  HARD:
 *   - W-tap + S-tap (смена страфа)
 *   - Крит-прыжок с fallDistance проверкой (как в HARD оригинале)
 *   - Dodge при получении урона (откат назад)
 *   - AutoGap при HP < GAP_HP_HARD
 *   - Pearl-рывок при большой дистанции
 *   - Feint: ложный замах (смотрим в сторону, потом атакуем)
 *   - ComboSystem: RHYTHM паттерн
 *
 *  EXPERT:
 *   - Всё из HARD +
 *   - Jitter-aim: микроотклонения прицела (имитирует человека)
 *   - Sprint-reset timing: сброс спринта точно перед ударом
 *   - BlockHit-predict: предсказание позиции на 2 тика вперёд
 *   - AngleHit: атака с бокового угла для максимального knockback
 *   - CPS-burst: серия быстрых ударов при открытом окне (враг в воздухе)
 *   - GappleJudge: гэпл только если враг не смотрит на нас
 *   - ComboSystem: BURST паттерн
 *
 * ══════════════════════════════════════════════════════════════════
 *  ИНТЕГРАЦИЯ с BotDifficultyAI:
 *
 *    private final SwordLogic swordLogic = new SwordLogic(bot);
 *
 *    // В tick() вместо tickEasy/Medium/Hard/Expert для SWORD режима:
 *    swordLogic.tick(target, difficulty);
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class SwordLogic {

    // ── Дистанции ──────────────────────────────────────────────────
    private static final double MELEE_RANGE         = 3.5;
    private static final double IDEAL_DIST          = 2.8;
    private static final double SPRINT_DIST         = 5.0;
    private static final double BOW_SWITCH_DIST     = 14.0;
    private static final double PEARL_THROW_DIST    = 16.0;
    private static final double ANGLE_HIT_DIST      = 3.2;

    // ── Крит-прыжок ────────────────────────────────────────────────
    private static final int    MEDIUM_CRIT_EVERY   = 4;   // каждый N-й удар
    private static final int    HARD_CRIT_EVERY     = 3;
    private static final int    EXPERT_CRIT_EVERY   = 2;   // чаще всего
    private static final float  CRIT_FALL_DIST      = 0.08f;

    // ── Cooldown атаки ─────────────────────────────────────────────
    private static final int    EASY_CD_BONUS       = 8;   // медленнее на N тиков
    private static final int    MEDIUM_CD_BONUS     = 2;
    private static final int    HARD_CD_BONUS       = 0;
    private static final int    EXPERT_CD_BONUS     = -1;  // чуть быстрее

    // ── GAP (Golden Apple) ─────────────────────────────────────────
    private static final float  GAP_HP_MEDIUM       = 8.0f;
    private static final float  GAP_HP_HARD         = 10.0f;
    private static final float  GAP_HP_EXPERT       = 12.0f;
    private static final int    GAP_CD              = 160;

    // ── Feint (ложный замах) ───────────────────────────────────────
    private static final int    FEINT_CD            = 80;
    private static final int    FEINT_LOOK_TICKS    = 4;   // тиков смотрим в сторону
    private static final double FEINT_LOOK_OFFSET   = 40.0; // градусов в сторону

    // ── CPS Burst ──────────────────────────────────────────────────
    private static final int    BURST_CD            = 40;
    private static final int    BURST_HITS          = 3;   // ударов в серии
    private static final int    BURST_HIT_INTERVAL  = 3;   // тиков между ударами

    // ── Sprint-reset ───────────────────────────────────────────────
    /** Сколько тиков ДО удара сбрасываем спринт (для knockback) */
    private static final int    SPRINT_RESET_TICKS  = 2;

    // ── AngleHit ───────────────────────────────────────────────────
    /** Угол бокового обхода для атаки (градусов) */
    private static final double ANGLE_STRAFE_DEG    = 35.0;

    // ── Jitter-aim ─────────────────────────────────────────────────
    private static final float  JITTER_MAX_DEG      = 1.8f; // макс. отклонение прицела

    // ── Dodge ──────────────────────────────────────────────────────
    private static final int    DODGE_CD            = 18;
    private static final double DODGE_FORCE         = 0.55;

    // ── Состояние ──────────────────────────────────────────────────
    private int     attackCd        = 0;
    private int     gapCd           = 0;
    private int     pearlCd         = 0;
    private int     feintCd         = 0;
    private int     feintLookTimer  = 0;
    private int     burstCd         = 0;
    private int     burstHitsLeft   = 0;
    private int     burstTimer      = 0;
    private int     critCounter     = 0;   // счётчик ударов до крита
    private boolean critPending     = false;
    private int     dodgeCd         = 0;
    private int     sprintResetTimer = 0;
    private int     jitterTimer     = 0;
    private float   jitterYaw       = 0;
    private float   jitterPitch     = 0;
    private int     easyMissTimer   = 0;
    private int     patternSyncCd   = 0;

    // Для EXPERT AngleHit
    private boolean doAngleHit      = false;
    private int     angleHitTimer   = 0;
    private double  angleHitDir     = 1.0; // +1 или -1

    private final BotEntity    bot;
    private final WTapLogic    wTap;
    private final StrafeAI     strafe;
    private final ComboSystem  combo;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public SwordLogic(BotEntity bot) {
        this.bot    = bot;
        this.wTap   = new WTapLogic(bot);
        this.strafe = new StrafeAI(bot);
        this.combo  = new ComboSystem(bot);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target, PVPBotConfig.Difficulty difficulty) {
        if (target == null || !target.isAlive()) { reset(); return; }
        if (!(bot.level() instanceof ServerLevel sw)) return;

        // Декременты
        if (attackCd      > 0) attackCd--;
        if (gapCd         > 0) gapCd--;
        if (pearlCd       > 0) pearlCd--;
        if (feintCd       > 0) feintCd--;
        if (feintLookTimer> 0) feintLookTimer--;
        if (burstCd       > 0) burstCd--;
        if (burstTimer    > 0) burstTimer--;
        if (dodgeCd       > 0) dodgeCd--;
        if (sprintResetTimer>0)sprintResetTimer--;
        if (jitterTimer   > 0) jitterTimer--;
        if (easyMissTimer > 0) easyMissTimer--;
        if (angleHitTimer > 0) angleHitTimer--;
        if (patternSyncCd > 0) patternSyncCd--;

        equipSword();

        switch (difficulty) {
            case EASY   -> tickEasy(sw, target);
            case MEDIUM -> tickMedium(sw, target);
            case HARD   -> tickHard(sw, target);
            case EXPERT -> tickExpert(sw, target);
            default     -> tickMedium(sw, target);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  EASY
    // ════════════════════════════════════════════════════════════════

    private void tickEasy(ServerLevel sw, LivingEntity target) {
        if (easyMissTimer > 0) return; // "задумался"

        double dist = bot.distanceTo(target);

        // Тупое движение к цели
        if (dist > IDEAL_DIST + 0.5) {
            bot.getNavigation().moveTo(target, 0.82);
        } else if (dist < 1.2) {
            bot.getNavigation().stop();
        }
        bot.getLookControl().setLookAt(target, 25f, 25f);

        // Атака
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            // 15% промах
            if (bot.level().getRandom().nextInt(100) < 15) {
                easyMissTimer = 10 + bot.level().getRandom().nextInt(10);
                attackCd = cfg.attackCooldown + EASY_CD_BONUS;
                return;
            }
            if (doHurt(sw, target)) {
                attackCd = cfg.attackCooldown + EASY_CD_BONUS
                    + bot.level().getRandom().nextInt(5);
            }
        }

        // Иногда "задумываемся"
        if (bot.tickCount % 90 == 0 && bot.level().getRandom().nextInt(100) < 12
                && bot.getHealth() > 10f) {
            easyMissTimer = 8 + bot.level().getRandom().nextInt(14);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  MEDIUM
    // ════════════════════════════════════════════════════════════════

    private void tickMedium(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // W-tap
        if (!wTap.tick(target)) {
            moveToward(target, dist, 1.08);
        }

        // Страф базовый
        if (cfg.strafeEnabled) {
            syncPatternAI();
            strafe.tick(target);
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Gap при низком HP
        if (bot.getHealth() < GAP_HP_MEDIUM && gapCd <= 0) {
            eatGap();
        }

        // Атака с зарядом (1.9 cooldown)
        boolean chargeReady = !cfg.use19AttackCooldown
            || bot.getAttackStrengthScale(0f) >= cfg.minAttackCharge;

        if (dist <= cfg.attackRange && attackCd <= 0 && chargeReady) {
            // Крит-прыжок каждые MEDIUM_CRIT_EVERY ударов
            if (critCounter >= MEDIUM_CRIT_EVERY && bot.onGround()) {
                bot.getJumpControl().jump();
                critPending = true;
                critCounter = 0;
            } else if (critPending && !bot.onGround()
                    && bot.getDeltaMovement().y < -0.01
                    && bot.fallDistance > CRIT_FALL_DIST) {
                // В воздухе падаем — крит!
                if (doHurt(sw, target)) {
                    spawnCritParticles(sw, target);
                    critPending = false;
                    attackCd = cfg.attackCooldown + MEDIUM_CD_BONUS;
                    wTap.onAttack();
                    critCounter = 0;
                }
            } else if (!critPending) {
                // Обычный удар
                if (doHurt(sw, target)) {
                    attackCd = cfg.attackCooldown + MEDIUM_CD_BONUS
                        + bot.level().getRandom().nextInt(3) - 1;
                    wTap.onAttack();
                    critCounter++;
                }
            } else if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
                // Прыжок не получился — обычный удар
                critPending = false;
                if (doHurt(sw, target)) {
                    attackCd = cfg.attackCooldown + MEDIUM_CD_BONUS;
                    wTap.onAttack();
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  HARD
    // ════════════════════════════════════════════════════════════════

    private void tickHard(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Pearl-рывок
        if (cfg.diffUsePearls && dist > PEARL_THROW_DIST && pearlCd <= 0) {
            throwPearlToward(sw, target);
            pearlCd = cfg.diffPearlCooldown;
        }

        // W-tap
        if (!wTap.tick(target)) {
            moveToward(target, dist, 1.12);
        }

        // Страф + PatternAI
        if (cfg.strafeEnabled) {
            syncPatternAI();
            strafe.tick(target);
        }

        // Gap
        if (bot.getHealth() < GAP_HP_HARD && gapCd <= 0) {
            eatGap();
        }

        // Feint (ложный замах)
        if (feintCd <= 0 && dist < MELEE_RANGE * 1.2
                && bot.level().getRandom().nextInt(100) < 18) {
            feintCd       = FEINT_CD;
            feintLookTimer = FEINT_LOOK_TICKS;
        }
        if (feintLookTimer > 0) {
            // Смотрим немного в сторону — как будто не атакуем
            double feintYaw = bot.getYRot() + FEINT_LOOK_OFFSET
                * (bot.level().getRandom().nextBoolean() ? 1 : -1);
            bot.getLookControl().setLookAt(
                bot.getX() + Math.sin(Math.toRadians(feintYaw)) * 5,
                target.getEyeY(),
                bot.getZ() + Math.cos(Math.toRadians(feintYaw)) * 5,
                60f, 30f);
        } else {
            bot.getLookControl().setLookAt(target, 30f, 30f);
        }

        // ComboSystem
        combo.setPattern(ComboSystem.ComboPattern.RHYTHM);
        combo.tick(target);

        // Атака
        boolean chargeReady = !cfg.use19AttackCooldown
            || bot.getAttackStrengthScale(0f) >= cfg.minAttackCharge;

        if (dist <= cfg.attackRange && attackCd <= 0 && chargeReady) {
            if (critCounter >= HARD_CRIT_EVERY && bot.onGround()) {
                bot.getJumpControl().jump();
                critPending = true;
                critCounter = 0;
            } else if (critPending && !bot.onGround()
                    && bot.getDeltaMovement().y < -0.01
                    && bot.fallDistance > CRIT_FALL_DIST) {
                if (doHurt(sw, target)) {
                    spawnCritParticles(sw, target);
                    critPending = false;
                    attackCd = Math.max(4, cfg.attackCooldown + HARD_CD_BONUS);
                    wTap.onAttack();
                    critCounter = 0;
                }
            } else if (!critPending) {
                if (doHurt(sw, target)) {
                    attackCd = Math.max(4, cfg.attackCooldown + HARD_CD_BONUS);
                    wTap.onAttack();
                    critCounter++;
                }
            } else if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
                critPending = false;
                if (doHurt(sw, target)) {
                    attackCd = Math.max(4, cfg.attackCooldown + HARD_CD_BONUS);
                    wTap.onAttack();
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  EXPERT
    // ════════════════════════════════════════════════════════════════

    private void tickExpert(ServerLevel sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // ── Pearl-рывок ────────────────────────────────────────────
        if (cfg.diffUsePearls && dist > PEARL_THROW_DIST && pearlCd <= 0) {
            // Предсказываем позицию на 4 тика
            Vec3 predicted = MotionPredictor.predict(target, 4);
            throwPearlTo(sw, predicted);
            pearlCd = cfg.diffPearlCooldown;
        }
        // Pearl-отход при низком HP
        if (cfg.diffUsePearls && bot.getHealth() < cfg.diffPearlEscapeHpThreshold
                && pearlCd <= 0) {
            throwPearlRetreat(sw, target);
            pearlCd = cfg.diffPearlCooldown;
        }

        // ── CPS-Burst: серия быстрых ударов если враг в воздухе ───
        boolean targetInAir = !target.onGround() && target.getDeltaMovement().y < 0;
        if (targetInAir && burstCd <= 0 && dist <= cfg.attackRange) {
            burstHitsLeft = BURST_HITS;
            burstTimer    = 0;
            burstCd       = BURST_CD;
        }
        if (burstHitsLeft > 0 && burstTimer <= 0 && dist <= cfg.attackRange) {
            if (doHurt(sw, target)) {
                spawnCritParticles(sw, target);
                burstHitsLeft--;
                burstTimer = BURST_HIT_INTERVAL;
                wTap.onAttack();
            }
        }

        // ── AngleHit: атака с бокового угла ───────────────────────
        // Каждые ~6 ударов — заходим сбоку для максимального knockback
        if (!doAngleHit && critCounter > 0 && critCounter % 6 == 0
                && dist < ANGLE_HIT_DIST) {
            doAngleHit    = true;
            angleHitTimer = 6;
            angleHitDir   = bot.level().getRandom().nextBoolean() ? 1.0 : -1.0;
        }
        if (doAngleHit && angleHitTimer > 0) {
            // Двигаемся по боковой дуге
            Vec3 toTarget = target.position().subtract(bot.position()).normalize();
            double perpX = -toTarget.z * angleHitDir;
            double perpZ =  toTarget.x * angleHitDir;
            bot.setDeltaMovement(
                bot.getDeltaMovement().x + perpX * 0.18,
                bot.getDeltaMovement().y,
                bot.getDeltaMovement().z + perpZ * 0.18
            );
        } else {
            doAngleHit = false;
        }

        // ── Sprint-reset точный тайминг ────────────────────────────
        // За SPRINT_RESET_TICKS тиков до удара сбрасываем спринт
        boolean chargeReady = !cfg.use19AttackCooldown
            || bot.getAttackStrengthScale(0f) >= cfg.minAttackCharge;
        if (attackCd == SPRINT_RESET_TICKS && bot.isSprinting()) {
            bot.setSprinting(false);
            sprintResetTimer = SPRINT_RESET_TICKS + 1;
        }

        // ── W-tap + движение ───────────────────────────────────────
        if (!wTap.tick(target)) {
            moveToward(target, dist, 1.18);
            if (sprintResetTimer <= 0 && dist > SPRINT_DIST * 0.6) {
                bot.setSprinting(true);
            }
        }

        // ── Страф zigzag с PatternAI ───────────────────────────────
        if (cfg.strafeEnabled) {
            strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
            syncPatternAI();
            strafe.tick(target);
        }

        // ── Jitter-aim ─────────────────────────────────────────────
        if (jitterTimer <= 0) {
            jitterYaw   = (float)(Math.random() * JITTER_MAX_DEG * 2 - JITTER_MAX_DEG);
            jitterPitch = (float)(Math.random() * JITTER_MAX_DEG * 2 - JITTER_MAX_DEG);
            jitterTimer = 2 + (int)(Math.random() * 3);
        }
        // Прицел с микро-отклонением
        double lookX = target.getX() + Math.sin(Math.toRadians(bot.getYRot() + jitterYaw)) * 0.3;
        double lookZ = target.getZ() + Math.cos(Math.toRadians(bot.getYRot() + jitterYaw)) * 0.3;
        bot.getLookControl().setLookAt(lookX, target.getEyeY() + jitterPitch * 0.02, lookZ, 60f, 45f);

        // ── Gap ────────────────────────────────────────────────────
        // Экспертный GAPPLE-судья: едим только если враг не смотрит на нас
        if (bot.getHealth() < GAP_HP_EXPERT && gapCd <= 0 && !isTargetLookingAt(target)) {
            eatGap();
        }

        // ── ComboSystem ────────────────────────────────────────────
        combo.setPattern(ComboSystem.ComboPattern.BURST);
        combo.tick(target);

        // ── Атака ──────────────────────────────────────────────────
        if (dist <= cfg.attackRange && attackCd <= 0 && chargeReady
                && burstHitsLeft <= 0) {
            // Феинт перед критом
            if (feintCd <= 0 && dist < MELEE_RANGE
                    && bot.level().getRandom().nextInt(100) < 22) {
                feintCd       = FEINT_CD;
                feintLookTimer = FEINT_LOOK_TICKS;
            }

            // Крит-прыжок
            if (critCounter >= EXPERT_CRIT_EVERY && bot.onGround()) {
                bot.getJumpControl().jump();
                critPending = true;
                critCounter = 0;
            } else if (critPending && !bot.onGround()
                    && bot.getDeltaMovement().y < -0.01
                    && bot.fallDistance > CRIT_FALL_DIST) {
                if (doHurt(sw, target)) {
                    spawnCritParticles(sw, target);
                    critPending = false;
                    attackCd = Math.max(3, cfg.attackCooldown + EXPERT_CD_BONUS);
                    wTap.onAttack();
                    critCounter = 0;
                }
            } else if (!critPending) {
                if (doHurt(sw, target)) {
                    attackCd = Math.max(3, cfg.attackCooldown + EXPERT_CD_BONUS);
                    wTap.onAttack();
                    critCounter++;
                }
            } else if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
                critPending = false;
                if (doHurt(sw, target)) {
                    attackCd = Math.max(3, cfg.attackCooldown + EXPERT_CD_BONUS);
                    wTap.onAttack();
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Вызвать когда бот получил урон (для Dodge)
    // ════════════════════════════════════════════════════════════════

    public void onDamageReceived(float amount, LivingEntity attacker) {
        if (dodgeCd > 0) return;
        PVPBotConfig.Difficulty diff = bot.getEffectiveDifficulty();
        if (diff != PVPBotConfig.Difficulty.HARD && diff != PVPBotConfig.Difficulty.EXPERT) return;
        if (amount < 2.0f) return; // не реагируем на мелкий урон

        // Импульс назад от атакующего
        Vec3 away;
        if (attacker != null) {
            away = bot.position().subtract(attacker.position()).normalize();
        } else {
            away = new Vec3(-bot.getLookAngle().x, 0, -bot.getLookAngle().z).normalize();
        }
        bot.setDeltaMovement(away.x * DODGE_FORCE, 0.3, away.z * DODGE_FORCE);
        dodgeCd = DODGE_CD;

        if (bot.level() instanceof ServerLevel sw) {
            sw.sendParticles(ParticleTypes.SMOKE,
                bot.getX(), bot.getY() + 1, bot.getZ(), 6, 0.2, 0.2, 0.2, 0.05);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    private boolean doHurt(ServerLevel sw, LivingEntity target) {
        if (!target.isAlive()) return false;
        bot.getLookControl().setLookAt(target, 30f, 30f);
        return bot.doHurtTarget(sw, target);
    }

    private void moveToward(LivingEntity target, double dist, double speed) {
        if (dist > IDEAL_DIST) {
            bot.getNavigation().moveTo(target, speed);
            if (dist > SPRINT_DIST && !bot.isSprinting()) bot.setSprinting(true);
            else if (dist < IDEAL_DIST * 1.2 && bot.isSprinting()) bot.setSprinting(false);
        } else if (dist < 1.5) {
            bot.getNavigation().stop();
        }
    }

    private void eatGap() {
        // Ищем гэпл в инвентаре (mainhand или хотбар)
        for (int i = 0; i < 9; i++) {
            ItemStack s = bot.getInventory().getItem(i);
            if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                bot.startUsingItem(net.minecraft.world.InteractionHand.MAIN_HAND);
                gapCd = GAP_CD;
                return;
            }
        }
        // Запасной вариант — выдаём гэпл
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   100, 0));
        gapCd = GAP_CD;
    }

    private void throwPearlToward(ServerLevel sw, LivingEntity target) {
        throwPearlTo(sw, target.getEyePosition());
    }

    private void throwPearlTo(ServerLevel sw, Vec3 dest) {
        Vec3 eye = bot.getEyePosition();
        Vec3 dir = dest.subtract(eye).normalize();
        double hD = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(dir.y, hD));
        var pearl = new net.minecraft.world.entity.projectile.ThrownEnderpearl(
            net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        pearl.moveTo(eye.x, eye.y, eye.z, yaw, pitch);
        pearl.shootFromRotation(bot, pitch, yaw, 0.0f, 2.5f, 0.0f);
        sw.addFreshEntity(pearl);
        bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 0.4f + (float)Math.random() * 0.4f);
    }

    private void throwPearlRetreat(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        throwPearlTo(sw, bot.getEyePosition().add(away.scale(12.0)));
    }

    private void spawnCritParticles(ServerLevel sw, LivingEntity target) {
        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY() + 1, target.getZ(), 10, 0.3, 0.3, 0.3, 0.1);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
    }

    /** Проверяет — смотрит ли цель на бота (в пределах угла 45°) */
    private boolean isTargetLookingAt(LivingEntity target) {
        Vec3 toBot = bot.position().subtract(target.position()).normalize();
        Vec3 look  = target.getLookAngle();
        return toBot.dot(look) > 0.7; // cos(45°) ≈ 0.71
    }

    private void syncPatternAI() {
        if (!cfg.patternAIEnabled || patternSyncCd > 0) { patternSyncCd--; return; }
        PatternAI pai = bot.getPatternAI();
        double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
        double neutralYaw = strafe.isStrafeLeft() ? -90.0 : 90.0;
        strafe.setAdaptedYaw((float)(absYaw - neutralYaw));
        patternSyncCd = 3;
    }

    private void equipSword() {
        // Ищем меч (netherite/diamond/iron) в mainhand, если нет — экипируем из кита
        var item = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (item.is(Items.NETHERITE_SWORD) || item.is(Items.DIAMOND_SWORD)
                || item.is(Items.IRON_SWORD)) return;
        // Пробуем восстановить из кита
        BotKit kit = bot.getCurrentKit();
        if (kit != null) kit.equipment.applyTo(bot);
    }

    public void reset() {
        attackCd = 0; gapCd = 0; pearlCd = 0;
        feintCd = 0; feintLookTimer = 0;
        burstCd = 0; burstHitsLeft = 0; burstTimer = 0;
        critCounter = 0; critPending = false;
        dodgeCd = 0; sprintResetTimer = 0;
        jitterTimer = 0; jitterYaw = 0; jitterPitch = 0;
        easyMissTimer = 0; patternSyncCd = 0;
        doAngleHit = false; angleHitTimer = 0;
        wTap.reset();
    }

    public boolean isCritPending() { return critPending; }
    public boolean isBursting()    { return burstHitsLeft > 0; }
    public WTapLogic getWTap()     { return wTap; }

    public String getStateLabel() {
        if (isBursting())   return "SWD:BURST";
        if (isCritPending()) return "SWD:CRIT!";
        return "SWD:FIGHT";
    }

}