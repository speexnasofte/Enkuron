package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * TotemLogic — v16: режим TOTEM.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Поведение:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Бот держит тотем бессмертия в левой руке и встаёт между владельцем
 *  и ближайшим врагом («агро-танк»):
 *
 *  1. POSITION — бот вычисляет точку между владельцем и целью
 *     (TANK_OFFSET блоков перед владельцем в сторону цели) и бежит туда.
 *
 *  2. AGGRO — бот помечает себя как приоритетную цель, делая W-Tap
 *     и притягивая агресcию противника — атакует цель мечом.
 *
 *  3. INTERCEPT — если цель атакует владельца (владелец под огнём),
 *     бот прыгает между ними, принимая урон на себя.
 *
 *  4. TOTEM_POP — при HP ≤ 1 (тотем должен сработать) бот
 *     отскакивает назад на 3 блока и ждёт восстановления.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Интеграция:
 * ══════════════════════════════════════════════════════════════════
 *
 *  ModeLogicDispatcher: case TOTEM -> getTotem().tick(target)
 *  BotEntity.tick(): totemLogic.ensureTotemInOffhand()
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class TotemLogic {

    // ── Константы ─────────────────────────────────────────────────
    /** Дистанция от владельца, на которой встаём (между ним и целью) */
    private static final double TANK_OFFSET   = 2.5;
    /** Дальность атаки мечом */
    private static final double MELEE_RANGE   = 3.5;
    /** Кулдаун атаки в тотем-режиме */
    private static final int    ATTACK_CD     = 12;
    /** Кулдаун после pop-тотема */
    private static final int    POP_WAIT      = 40;
    /** Тиков комбо после pop врага (враг ~0.5 сек беззащитен) */
    private static final int    ANTI_TOTEM_CD = 10;
    /** Ударов в комбо после pop врага */
    private static final int    ANTI_TOTEM_HITS = 3;
    /** Дистанция отскока после pop */
    private static final double POP_RETREAT   = 3.5;

    // ── Состояния ─────────────────────────────────────────────────
    private enum State { POSITION, AGGRO, INTERCEPT, POP_WAIT }
    private State state     = State.POSITION;
    private int   attackCd  = 0;
    private int   popTimer  = 0;

    // ── v1.2: AntiTotem ──────────────────────────────────────────
    private float targetLastHp   = -1f;
    private int   antiTotemCombo = 0;   // оставшихся ударов комбо
    private int   antiTotemCd   = 0;   // кулдаун между ударами

    private final BotEntity bot;

    public TotemLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        ensureTotemInOffhand(sw);

        if (attackCd > 0) attackCd--;
        if (antiTotemCd > 0) antiTotemCd--;

        // v1.2: AntiTotem — комбо когда у врага сработал тотем
        tickAntiTotem(sw, target);

        switch (state) {
            case POSITION  -> tickPosition(sw, target);
            case AGGRO     -> tickAggro(sw, target);
            case INTERCEPT -> tickIntercept(sw, target);
            case POP_WAIT  -> tickPopWait(sw, target);
            default -> {}
        }
    }

    // ── POSITION: встаём между владельцем и целью ─────────────────
    private void tickPosition(ServerLevel sw, LivingEntity target) {
        LivingEntity owner = getOwner(sw);
        if (owner == null) { state = State.AGGRO; return; }

        Vec3 ownerPos = owner.position();
        Vec3 targetPos = target.position();
        Vec3 dir = targetPos.subtract(ownerPos).normalize();
        Vec3 tankPos = ownerPos.add(dir.scale(TANK_OFFSET));

        double distToTank = bot.position().distanceTo(tankPos);

        if (distToTank > 1.5) {
            bot.getNavigation().moveTo(tankPos.x, tankPos.y, tankPos.z, 1.3);
        } else {
            state = State.AGGRO;
        }
    }

    // ── AGGRO: агрим цель, атакуем мечом ─────────────────────────
    private void tickAggro(ServerLevel sw, LivingEntity target) {
        LivingEntity owner = getOwner(sw);

        // Поддерживаем позицию между владельцем и целью
        if (owner != null) {
            Vec3 ownerPos = owner.position();
            Vec3 dir = target.position().subtract(ownerPos).normalize();
            Vec3 tankPos = ownerPos.add(dir.scale(TANK_OFFSET));
            double distToTank = bot.position().distanceTo(tankPos);
            if (distToTank > 2.5) {
                bot.getNavigation().moveTo(tankPos.x, tankPos.y, tankPos.z, 1.2);
                state = State.POSITION;
                return;
            }
        }

        double dist = bot.distanceTo(target);

        // Атакуем мечом
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            equipSword(sw);
            bot.doHurtTarget((net.minecraft.server.level.ServerLevel)bot.level(), target);
            attackCd = ATTACK_CD;
        } else if (dist > MELEE_RANGE) {
            // Бежим к цели — агрим
            bot.getNavigation().moveTo(target, 1.25);
        }

        // Проверяем INTERCEPT — если цель смотрит на владельца
        if (owner != null && isTargetingOwner(target, owner)) {
            state = State.INTERCEPT;
        }

        // Проверяем POP
        if (bot.getHealth() <= 1.5f) {
            state = State.POP_WAIT;
            popTimer = POP_WAIT;
            retreatFromTarget(target);
        }
    }

    // ── INTERCEPT: перехватываем атаку на владельца ───────────────
    private void tickIntercept(ServerLevel sw, LivingEntity target) {
        LivingEntity owner = getOwner(sw);
        if (owner == null) { state = State.AGGRO; return; }

        // Встаём точно между целью и владельцем
        Vec3 midpoint = target.position().add(owner.position()).scale(0.5);
        bot.getNavigation().moveTo(midpoint.x, midpoint.y, midpoint.z, 1.4);

        // Атакуем цель
        double dist = bot.distanceTo(target);
        if (dist <= MELEE_RANGE && attackCd <= 0) {
            equipSword(sw);
            bot.doHurtTarget((net.minecraft.server.level.ServerLevel)bot.level(), target);
            attackCd = ATTACK_CD;
        }

        // Назад в AGGRO если цель переключилась
        if (!isTargetingOwner(target, owner)) {
            state = State.AGGRO;
        }

        // POP-check
        if (bot.getHealth() <= 1.5f) {
            state = State.POP_WAIT;
            popTimer = POP_WAIT;
            retreatFromTarget(target);
        }
    }

    // ── POP_WAIT: ждём восстановления после тотема ────────────────
    private void tickPopWait(ServerLevel sw, LivingEntity target) {
        popTimer--;

        // Частицы тотема
        if (popTimer % 5 == 0) {
            sw.sendParticles(ParticleTypes.TOTEM_OF_UNDYING,
                bot.getX(), bot.getY() + 1.0, bot.getZ(),
                6, 0.3, 0.5, 0.3, 0.1);
        }

        if (popTimer <= 0 || bot.getHealth() > 10.0f) {
            state = State.POSITION;
        }
    }

    // ── Убедиться что тотем в левой руке ─────────────────────────
    // FIX v1.3.1: раньше проверялся только isEmpty() — если там был щит или другой
    // предмет, тотем НЕ ставился и бот умирал без тотема.
    // Теперь: заменяем ЛЮБОЙ предмет в оффхенде на тотем.
    public void ensureTotemInOffhand(ServerLevel sw) {
        ItemStack offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (offhand.is(Items.TOTEM_OF_UNDYING)) return;
        // Ставим тотем — заменяем что бы там ни было
        bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
    }

    // ── Вспомогательные ──────────────────────────────────────────

    private void equipSword(ServerLevel sw) {
        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!main.is(Items.DIAMOND_SWORD) && !main.is(Items.NETHERITE_SWORD)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
        }
    }

    private LivingEntity getOwner(ServerLevel sw) {
        if (bot.getOwnerUUID() == null) return null;
        var entity = sw.getEntity(bot.getOwnerUUID());
        return entity instanceof LivingEntity le ? le : null;
    }

    private boolean isTargetingOwner(LivingEntity target, LivingEntity owner) {
        if (!(target instanceof net.minecraft.world.entity.Mob mob)) {
            // Для игроков — проверяем дистанцию и направление взгляда
            Vec3 look = target.getViewVector(1.0f).normalize();
            Vec3 toOwner = owner.position().subtract(target.position()).normalize();
            return look.dot(toOwner) > 0.85 && target.distanceTo(owner) < 6.0;
        }
        return mob.getTarget() != null && mob.getTarget().getUUID().equals(owner.getUUID());
    }

    private void retreatFromTarget(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize().scale(POP_RETREAT);
        Vec3 dest = bot.position().add(away);
        bot.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.5);
    }

    // ── v1.2: AntiTotem ──────────────────────────────────────────
    /**
     * Детектирует pop тотема у врага (HP резко вырос с ~1 до ~1+ после смерти)
     * и запускает серию ударов пока враг беззащитен (~0.5 сек после pop).
     */
    private void tickAntiTotem(ServerLevel sw, LivingEntity target) {
        float currentHp = target.getHealth();

        // Детект pop: HP было ≤ 1 (почти смерть), теперь > 1 — тотем сработал
        if (targetLastHp > 0 && targetLastHp <= 1.2f && currentHp > 1.5f) {
            antiTotemCombo = ANTI_TOTEM_HITS;
        }

        // Выполняем комбо
        if (antiTotemCombo > 0 && antiTotemCd <= 0) {
            double dist = bot.distanceTo(target);
            if (dist <= MELEE_RANGE) {
                equipSword(sw);
                bot.doHurtTarget((net.minecraft.server.level.ServerLevel)bot.level(), target);
                antiTotemCombo--;
                antiTotemCd = ANTI_TOTEM_CD;
            } else {
                // Сближаемся быстро
                bot.getNavigation().moveTo(target, 1.6);
            }
        }

        targetLastHp = currentHp;
    }

    // ── Статус для HUD ────────────────────────────────────────────
    public String getStateLabel() {
        return switch (state) {
            case POSITION  -> "TOTEM:POS";
            case AGGRO     -> "TOTEM:TANK";
            case INTERCEPT -> "TOTEM:INTERCEPT";
            case POP_WAIT  -> "TOTEM:POP " + popTimer + "t";
            default     -> "?";
        };
    }
}
