package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.network.chat.Component;

/**
 * AutoRespawn v4 — фикс чёрного экрана после смерти.
 *
 * История проблемы:
 *   v2: respawn() и setScreen(null) через mc.execute() — безопасно для render-треда.
 *   v3: проверка mc.level != null перед вызовами; задержка 30 тиков.
 *   v4 (текущий): устранены ТРИ сценария чёрного экрана:
 *
 *   СЦЕНАРИЙ A — гонка между execute()-цепочкой и сменой измерения.
 *     Старый код: три вложенных mc.execute(). Если между ними mc.level
 *     менялся (портал, teleport), третий execute видел «новый» level,
 *     вызывал setScreen(null) — и клиент открывал пустой игровой экран
 *     пока чанки спавна ещё не загружены. Итог: чёрный экран 2–5 сек.
 *     Фикс: вместо вложенных execute используем respawnPendingTicks —
 *     счётчик-ожидание в основном тике. setScreen(null) вызывается
 *     только когда mc.player.isAlive() && !isDeadOrDying() — то есть
 *     сервер уже подтвердил респаун.
 *
 *   СЦЕНАРИЙ B — залипание флага wasDead.
 *     Старый код: ветка mc.level == null сбрасывала deathTimer/resetTimer
 *     но не wasDead. При следующей смерти doRespawn() не вызывался —
 *     игрок зависал на экране смерти навсегда.
 *     Фикс: mc.level == null теперь сбрасывает ВСЕ флаги включая wasDead.
 *
 *   СЦЕНАРИЙ C — setScreen(null) до готовности клиента.
 *     Старый код: setScreen(null) через 2 вложенных execute (≈1–2 мс),
 *     тогда как сервер подтверждает респаун через десятки мс.
 *     В окне ожидания mc.player.isDeadOrDying() == true →
 *     рендер рисовал пустой мир без HUD.
 *     Фикс: ждём isAlive() && !isDeadOrDying() до максимум 60 тиков,
 *     после чего принудительно закрываем экран (fallback).
 */
public class AutoRespawn {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int     deathTimer         = 0;  // тиков на DeathScreen
    private int     resetTimer         = 0;  // тиков после выхода с экрана смерти
    private boolean wasDead            = false;
    private int     respawnPendingTicks = 0; // >0 → ждём подтверждения респауна от сервера

    private static final int DEATH_DELAY   = 30; // тиков до отправки respawn() (1.5 сек)
    private static final int RESPAWN_TIMEOUT = 60; // макс. ожидание ответа сервера (3 сек)

    public void tick(Minecraft mc) {
        if (!cfg.autoRespawn) {
            resetAll();
            return;
        }

        // FIX B: mc.level == null → сбрасываем ВСЁ включая wasDead.
        // Без этого wasDead залипал и блокировал следующий цикл.
        if (mc.level == null) {
            resetAll();
            return;
        }

        // ── Ожидание подтверждения респауна от сервера (FIX A + C) ──
        if (respawnPendingTicks > 0) {
            respawnPendingTicks--;
            tryCloseDeathScreen(mc);
            return;
        }

        if (mc.screen instanceof DeathScreen) {
            resetTimer = 0;
            deathTimer++;

            if (deathTimer >= DEATH_DELAY && !wasDead) {
                wasDead = true;
                sendRespawn(mc);
            }
        } else {
            // Вышли с экрана смерти (вручную или через наш авто-респаун)
            if (wasDead) {
                resetTimer++;
                if (resetTimer >= 10) resetAll();
            } else {
                deathTimer = 0;
            }
        }
    }

    // ── Отправить пакет респауна ──────────────────────────────────

    private void sendRespawn(Minecraft mc) {
        mc.execute(() -> {
            if (mc.player == null || mc.level == null) return;
            if (!(mc.screen instanceof DeathScreen)) return;
            try {
                mc.player.respawn();
                // FIX A: не вызываем setScreen() сразу — ставим ожидание.
                // tryCloseDeathScreen() будет проверять готовность каждый тик.
                respawnPendingTicks = RESPAWN_TIMEOUT;
            } catch (Exception ignored) {}
        });
    }

    /**
     * Закрыть DeathScreen только когда сервер подтвердил респаун.
     * Признак готовности: mc.player жив и не в состоянии смерти.
     * FIX C: исключает чёрный экран от преждевременного setScreen(null).
     */
    private void tryCloseDeathScreen(Minecraft mc) {
        if (!(mc.screen instanceof DeathScreen)) {
            // Экран уже закрылся сам (например, сервер отправил join-пакет)
            respawnPendingTicks = 0;
            return;
        }
        if (mc.player == null || mc.level == null) return;

        boolean serverConfirmed = mc.player.isAlive() && !mc.player.isDeadOrDying();
        boolean timedOut        = respawnPendingTicks == 1; // последний тик ожидания

        if (serverConfirmed || timedOut) {
            mc.execute(() -> {
                try {
                    if (mc.screen instanceof DeathScreen) mc.setScreen(null);
                    if (mc.gui != null && mc.player != null) {
                        mc.gui.getChat().addMessage(
                            Component.literal("§a[PVPBot] §fАвто-респавн!")
                        );
                    }
                } catch (Exception ignored) {}
            });
            respawnPendingTicks = 0;
        }
    }

    private void resetAll() {
        deathTimer          = 0;
        resetTimer          = 0;
        wasDead             = false;
        respawnPendingTicks = 0;
    }
}
