package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * TargetPriority — умный выбор цели для бота (v12).
 *
 * Режимы приоритета:
 *   NEAREST    — ближайший враг (дефолт)
 *   LOWEST_HP  — у кого меньше всего HP (добить)
 *   MOST_ITEMS — у кого больше всего предметов (лут)
 *   FOCUS      — принудительная цель (задана вручную через /bot target)
 *
 * Бот пересматривает цель каждые RETARGET_INTERVAL тиков,
 * если текущая цель вышла за пределы ABANDON_RANGE блоков.
 */
public class TargetPriority {

    public enum PriorityMode { NEAREST, LOWEST_HP, MOST_ITEMS, FOCUS }

    private static final int    RETARGET_INTERVAL    = 40;  // тиков между пересмотром цели
    private static final double ABANDON_RANGE_BASE   = 32.0; // блоков — база для сброса цели
    private static final double SCAN_RANGE           = 24.0; // блоков — радиус поиска

    // IMPROVEMENT v1.3.9: dynamicAbandonRange
    // Дальность сброса цели зависит от сложности и режима:
    //   EASY:   не гоняемся далеко                  → 24 блока
    //   NORMAL: базовое значение                    → 32 блока
    //   HARD/EXPERT: преследуем агрессивно          → 48 блоков
    //   FOCUS-режим: никогда не бросаем принуд. цель → 64 блока
    private double getDynamicAbandonRange() {
        if (mode == PriorityMode.FOCUS) return 64.0;
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        return switch (bot.getEffectiveDifficulty()) { // FIX: per-bot difficulty
            case EASY   -> 24.0;
            case MEDIUM -> ABANDON_RANGE_BASE;
            case HARD   -> 48.0;
            case EXPERT -> 48.0;
            default     -> ABANDON_RANGE_BASE;
        };
    }

    private PriorityMode mode          = PriorityMode.NEAREST;
    private UUID         forcedTarget  = null;  // для режима FOCUS
    private int          retargetTimer = 0;

    private final BotEntity bot;

    public TargetPriority(BotEntity bot) {
        this.bot = bot;
    }

    public void setMode(PriorityMode m)        { this.mode = m; }
    public PriorityMode getMode()               { return mode; }
    public void setForcedTarget(UUID uuid)      { this.forcedTarget = uuid; this.mode = PriorityMode.FOCUS; }
    public void clearForcedTarget()             { this.forcedTarget = null; this.mode = PriorityMode.NEAREST; }

    /**
     * Главный тик. Возвращает лучшую цель (или null).
     * Вызывать из BotDifficultyAI / BotEntity.tick().
     */
    public LivingEntity tick() {
        retargetTimer--;

        LivingEntity current = bot.getTarget();

        // Проверяем нужно ли пересматривать
        boolean needRetarget = current == null
            || !current.isAlive()
            || bot.distanceTo(current) > getDynamicAbandonRange() // IMPROVEMENT v1.3.9: dynamic
            || retargetTimer <= 0;

        if (!needRetarget) return current;

        retargetTimer = RETARGET_INTERVAL;
        LivingEntity best = findBest();
        if (best != null && best != current) {
            bot.setTarget(best);
            // v14: уведомление о найденной цели
            bot.getNotifier().onTargetFound(best);
        }
        return best != null ? best : current;
    }

    // ─────────────────────────────────────────────────────────────

    private LivingEntity findBest() {
        if (!(bot.level() instanceof ServerLevel sw)) return null;

        // Режим FOCUS — ищем принудительную цель
        if (mode == PriorityMode.FOCUS && forcedTarget != null) {
            Player p = sw.getPlayerByUUID(forcedTarget);
            if (p != null && p.isAlive() && bot.distanceTo(p) <= SCAN_RANGE) return p;
        }

        // Получаем список кандидатов (исключаем владельца, co-владельцев, whitelist и других ботов)
        List<? extends Player> candidates = sw.getPlayers(p ->
            !p.isSpectator()
            && p.isAlive()
            && bot.distanceTo(p) <= SCAN_RANGE
            && !isOwner(p)
            && isEnemy(p)
        );
        // Убираем игроков которые являются "ботами" (BotEntity — не Player, но на всякий случай)
        // BotEntity наследует PathfinderMob, а не Player — они не попадут в список выше.

        if (candidates.isEmpty()) return null;

        return switch (mode) {
            case NEAREST   -> candidates.stream()
                .min(Comparator.comparingDouble(p -> bot.distanceToSqr(p)))
                .orElse(null);
            case LOWEST_HP -> candidates.stream()
                .min(Comparator.comparingDouble(LivingEntity::getHealth))
                .orElse(null);
            case MOST_ITEMS -> candidates.stream()
                .max(Comparator.comparingInt(p -> countItems(p)))
                .orElse(null);
            default        -> candidates.stream()
                .min(Comparator.comparingDouble(p -> bot.distanceToSqr(p)))
                .orElse(null);
        };
    }

    private boolean isOwner(Player p) {
        Player owner = bot.getOwner();
        return owner != null && owner.getUUID().equals(p.getUUID());
    }

    private boolean isEnemy(Player p) {
        // Проверяем whitelist — если включён, игроки в нём не цели
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        if (cfg.whitelistEnabled && cfg.whitelist.contains(p.getName().getString())) return false;
        // Co-владельцы не враги
        if (cfg.globalOwnerUUID != null
                && MultiOwner.INSTANCE.isCoOwner(cfg.globalOwnerUUID, p.getUUID())) return false;
        return true;
    }

    private int countItems(Player p) {
        int count = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            if (!p.getInventory().getItem(i).isEmpty()) count++;
        }
        return count;
    }
}
