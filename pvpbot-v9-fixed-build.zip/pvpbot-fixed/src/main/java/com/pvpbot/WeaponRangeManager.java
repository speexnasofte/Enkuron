package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

/**
 * WeaponRangeManager v1.0 — автоматическое переключение меч/лук по дистанции.
 *
 * Логика:
 *   dist > RANGE_TO_BOW  → переключиться на лук/арбалет (режим RANGED)
 *   dist < RANGE_TO_SWORD → переключиться на меч (режим MELEE)
 *
 * Гистерезис (RANGE_TO_BOW > RANGE_TO_SWORD) исключает мерцание при dist ≈ границе.
 *
 * Интеграция:
 *   В SwordLogic.tick() и аналогичных:
 *     WeaponMode mode = weaponRange.update(target);
 *     if (mode == WeaponRangeManager.WeaponMode.RANGED) { /* лук * / }
 *     else                                              { /* меч  * / }
 *
 * WeaponRangeManager не меняет ItemStack напрямую — это делает вызывающий код.
 * Класс только отслеживает активный режим и отдаёт события переключения.
 */
public class WeaponRangeManager {

    public enum WeaponMode { MELEE, RANGED }

    // Переключаемся на лук если дальше
    public static final double RANGE_TO_BOW   = 12.0;
    // Возвращаемся на меч если ближе (гистерезис)
    public static final double RANGE_TO_SWORD = 6.0;

    // Кулдаун смены оружия (тики) — не меняем оружие слишком часто
    private static final int SWITCH_COOLDOWN = 10;

    private WeaponMode currentMode   = WeaponMode.MELEE;
    private int        switchCooldown = 0;
    // true если режим только что изменился (один тик)
    private boolean    justSwitched   = false;

    private final BotEntity bot;

    public WeaponRangeManager(BotEntity bot) {
        this.bot = bot;
    }

    /**
     * Обновляет режим по дистанции до цели.
     * @return текущий WeaponMode после обновления
     */
    public WeaponMode update(LivingEntity target) {
        justSwitched = false;
        if (switchCooldown > 0) {
            switchCooldown--;
            return currentMode;
        }
        if (target == null || !target.isAlive()) return currentMode;

        double dist = bot.distanceTo(target);

        WeaponMode desired = currentMode; // по умолчанию не меняем
        if (currentMode == WeaponMode.MELEE  && dist > RANGE_TO_BOW)   desired = WeaponMode.RANGED;
        if (currentMode == WeaponMode.RANGED && dist < RANGE_TO_SWORD) desired = WeaponMode.MELEE;

        if (desired != currentMode) {
            currentMode   = desired;
            switchCooldown = SWITCH_COOLDOWN;
            justSwitched   = true;
            applyWeapon();
        }

        return currentMode;
    }

    /** true если режим изменился именно на этом тике */
    public boolean justSwitched() { return justSwitched; }

    public WeaponMode getMode() { return currentMode; }

    public boolean isRanged() { return currentMode == WeaponMode.RANGED; }
    public boolean isMelee()  { return currentMode == WeaponMode.MELEE;  }

    /** Принудительно переключить режим (например при смерти цели). */
    public void forceMode(WeaponMode mode) {
        if (currentMode != mode) {
            currentMode  = mode;
            justSwitched = true;
            applyWeapon();
        }
    }

    // ── Внутренняя логика ─────────────────────────────────────────

    /**
     * Ставит нужное оружие в mainhand при переключении режима.
     * Для RANGED: лук с Power V.
     * Для MELEE: алмазный меч с Sharpness V.
     * Зачарования строятся через EnchantUtil.
     */
    private void applyWeapon() {
        if (currentMode == WeaponMode.RANGED) {
            ItemStack bow = EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                .enchant("power", 5)
                .enchant("unbreaking", 3)
                .enchant("infinity", 1)
                .build();
            bot.setItemSlot(EquipmentSlot.MAINHAND, bow);
            // Убедимся что есть хоть одна стрела в инвентаре (без неё лук не стреляет)
            ensureArrow();
        } else {
            ItemStack sword = EnchantUtil.of(Items.DIAMOND_SWORD, bot.level().registryAccess())
                .enchant("sharpness", 5)
                .enchant("unbreaking", 3)
                .build();
            bot.setItemSlot(EquipmentSlot.MAINHAND, sword);
        }
    }

    /** Добавляет стрелу в инвентарь если её там нет (лук без стрел бесполезен). */
    private void ensureArrow() {
        var inv = bot.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(Items.ARROW)) return; // уже есть
        }
        // Найти первый пустой слот и положить стрелу
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).isEmpty()) {
                inv.setItem(i, new ItemStack(Items.ARROW, 64));
                return;
            }
        }
    }

    public void reset() {
        currentMode    = WeaponMode.MELEE;
        switchCooldown = 0;
        justSwitched   = false;
    }
}
