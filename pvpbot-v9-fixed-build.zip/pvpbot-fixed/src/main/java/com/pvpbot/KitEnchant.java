package com.pvpbot;

import net.minecraft.core.RegistryAccess;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Функциональный интерфейс для лямбда-зачарований кита.
 * Вынесено из BotKit для уменьшения размера файла.
 */
public interface KitEnchant {
    void apply(BotEntity bot, RegistryAccess ra,
           Item mainhand, Item offhand,
           Item helmet, Item chestplate,
           Item leggings, Item boots);
    }

