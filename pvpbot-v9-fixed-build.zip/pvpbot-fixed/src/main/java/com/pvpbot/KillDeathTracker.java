package com.pvpbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * KillDeathTracker v2.0 — K/D сохраняется в JSON между сессиями.
 *
 * Kill:   враг умер пока мы его атаковали (lastAttackedTick < 40 тиков назад)
 * Death:  наш игрок умер
 * Assist: враг умер < 100 тиков после нашего удара, но не мы финальный
 *
 * Файл: .minecraft/pvpbot_stats.json
 * Сбросить: /bot stats reset
 */
public class KillDeathTracker {

    // ── Данные (сохраняются) ─────────────────────────────────────
    public static int kills   = 0;
    public static int deaths  = 0;
    public static int assists = 0;

    // ── In-memory ────────────────────────────────────────────────
    // FIX: recordHit() вызывается с серверного треда, tick() — с клиентского
    // HashMap не потокобезопасен → ConcurrentHashMap
    private static final Map<java.util.UUID, Integer> lastHitTick = new ConcurrentHashMap<>();
    private static int gameTick = 0;
    private static boolean wasDead = false;

    // ── JSON персистентность ─────────────────────────────────────
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path saveFile;

    /** Вызывается из PVPBotMod.onInitialize() */
    public static void register() {
        // Находим путь .minecraft/pvpbot_stats.json
        Path mcDir = Minecraft.getInstance().gameDirectory.toPath();
        saveFile = mcDir.resolve("pvpbot_stats.json");
        load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.level == null) return;
            gameTick++;

            Player player = client.player;

            // Детектим смерть игрока
            if (player.isDeadOrDying() && !wasDead) {
                deaths++;
                wasDead = true;
                save();
                BattleLog.INSTANCE.logDeath();
                showMessage(client, "§c☠ Вы погибли! §7[" + deaths + " смертей]");
            }
            if (!player.isDeadOrDying()) wasDead = false;

            // Детектим убийство / ассист
            client.level.getEntitiesOfClass(
                net.minecraft.world.entity.LivingEntity.class,
                player.getBoundingBox().inflate(64.0),
                e -> e != player && e.isDeadOrDying()
            ).forEach(e -> {
                java.util.UUID uid = e.getUUID();
                if (!lastHitTick.containsKey(uid)) return;

                int hitTick = lastHitTick.remove(uid);
                int delta   = gameTick - hitTick;

                if (delta < 40) {
                    kills++;
                    String name = e.getName().getString();
                    save();
                    BattleLog.INSTANCE.logKill(name, DpsMeter.INSTANCE.getDps());
                    showMessage(client, "§a⚔ Kill! §f" + name
                        + "  §7[K:" + kills + " D:" + deaths + "]");
                    FightAnalyzer.INSTANCE.onFightEnd(name, client);
                    if (PVPBotConfig.INSTANCE.autoChatEnabled && client.getConnection() != null) {
                        client.getConnection().sendChat(PVPBotConfig.INSTANCE.chatKillMessage
                            .replace("{victim}", name));
                    }
                } else if (delta < 100) {
                    assists++;
                    save();
                    BattleLog.INSTANCE.logAssist(e.getName().getString());
                    showMessage(client, "§e✦ Assist §7[" + assists + "]");
                }
            });
        });
    }

    /** Вызывается из PVPBotLogic при каждой атаке */
    public static void recordHit(java.util.UUID targetUUID) {
        lastHitTick.put(targetUUID, gameTick);
    }

    public static void reset() {
        kills = deaths = assists = 0;
        lastHitTick.clear();
        save();
    }

    public static double getKD() {
        return deaths == 0 ? kills : (double) kills / deaths;
    }

    // ── JSON I/O ─────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public static void load() {
        if (saveFile == null || !Files.exists(saveFile)) return;
        try {
            String json = Files.readString(saveFile);
            Type type = new TypeToken<Map<String, Integer>>(){}.getType();
            Map<String, Integer> data = GSON.fromJson(json, type);
            if (data != null) {
                kills   = data.getOrDefault("kills",   0);
                deaths  = data.getOrDefault("deaths",  0);
                assists = data.getOrDefault("assists", 0);
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            // Файл повреждён — начинаем с нуля
        }
    }

    public static void save() {
        if (saveFile == null) return;
        try {
            Map<String, Integer> data = new HashMap<>();
            data.put("kills",   kills);
            data.put("deaths",  deaths);
            data.put("assists", assists);
            Files.writeString(saveFile, GSON.toJson(data));
        } catch (IOException ignored) {}
    }

    private static void showMessage(Minecraft mc, String msg) {
        if (mc.player != null) {
            mc.gui.getChat().addMessage(net.minecraft.network.chat.Component.literal("§e[PVPBot] §f" + msg));
        }
    }
}
