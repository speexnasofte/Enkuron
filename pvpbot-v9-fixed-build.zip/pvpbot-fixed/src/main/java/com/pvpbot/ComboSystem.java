package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;

/**
 * ComboSystem v13 — УЛУЧШЕНО
 *
 * Исправления:
 *   - BURST_PAUSE: 30 → 16 тиков (было 1.5 сек — слишком долго)
 *   - RHYTHM_INTERVAL: 8 → 6 тиков (чуть агрессивнее)
 *   - applyEvade: через Navigation, не setDeltaMovement (не конфликтует с StrafeAI)
 *   - tickFeint: отход через Navigation, не velocity
 *   - doAttack возвращает результат чтобы вызывающий код знал об ударе
 */
public class ComboSystem {

    public enum ComboPattern { BURST, RHYTHM, FEINT }

    private static final int BURST_HITS      = 4;
    private static final int BURST_PAUSE     = 16; // FIX: было 30 — теперь 16 тиков (~0.8 сек)
    private static final int RHYTHM_INTERVAL = 6;  // FIX: было 8
    private static final int FEINT_BACKOFF   = 8;

    private ComboPattern pattern      = ComboPattern.RHYTHM;
    private int  hitCount             = 0;
    private int  pauseTimer           = 0;
    private int  rhythmTimer          = 0;
    private boolean feintBackingOff   = false;
    private int  feintTimer           = 0;

    private final BotEntity bot;

    public ComboSystem(BotEntity bot) {
        this.bot = bot;
    }

    public void setPattern(ComboPattern p) { this.pattern = p; }
    public ComboPattern getPattern()       { return pattern; }

    public boolean tick(LivingEntity target) {
        if (pauseTimer > 0) { pauseTimer--; return false; }

        double dist = bot.distanceTo(target);
        boolean inRange = dist <= PVPBotConfig.INSTANCE.attackRange + 0.5;

        boolean shouldHit = switch (pattern) {
            case BURST  -> tickBurst(target, inRange);
            case RHYTHM -> tickRhythm(target, inRange);
            case FEINT  -> tickFeint(target, inRange);
            default     -> false;
        };

        if (shouldHit && inRange && bot.level() instanceof ServerLevel sw) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            bot.doHurtTarget(sw, target);
        }
        return shouldHit;
    }

    public void reset() {
        hitCount = 0; pauseTimer = 0; rhythmTimer = 0;
        feintBackingOff = false; feintTimer = 0;
    }

    private boolean tickBurst(LivingEntity target, boolean inRange) {
        if (!inRange) return false;
        hitCount++;
        if (hitCount >= BURST_HITS) {
            hitCount = 0;
            pauseTimer = BURST_PAUSE;
            applyEvade(target); // уклонение через Navigation
            return true;
        }
        return true;
    }

    private boolean tickRhythm(LivingEntity target, boolean inRange) {
        if (!inRange) { rhythmTimer = 0; return false; }
        rhythmTimer++;
        if (rhythmTimer >= RHYTHM_INTERVAL) { rhythmTimer = 0; return true; }
        return false;
    }

    private boolean tickFeint(LivingEntity target, boolean inRange) {
        if (feintBackingOff) {
            feintTimer--;
            // FIX: Navigation вместо setDeltaMovement
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 3, bot.getY(), bot.getZ() + away.z * 3, 1.2);
            if (feintTimer <= 0) {
                feintBackingOff = false;
                bot.getNavigation().moveTo(target, 1.5); // рывок через навигацию
            }
            return false;
        }
        if (inRange) {
            hitCount++;
            if (hitCount >= 2) {
                hitCount = 0;
                feintBackingOff = true;
                feintTimer = FEINT_BACKOFF;
            }
            return true;
        }
        return false;
    }

    // FIX: Navigation вместо прямого velocity
    private void applyEvade(LivingEntity target) {
        boolean left = bot.level().getRandom().nextBoolean();
        double yawRad = Math.toRadians(bot.getYRot() + (left ? -90 : 90));
        double sx = Math.sin(yawRad) * 3.5;
        double sz = -Math.cos(yawRad) * 3.5;
        bot.getNavigation().moveTo(bot.getX() + sx, bot.getY(), bot.getZ() + sz, 1.3);
    }
}
