package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

/**
 * BotAttackPlayersGoal v1.5 — атака игроков.
 * Уважает standbyMode: если боты в режиме ожидания — не выбирают цель.
 * FIX v1.4: боты НЕ атакуют других ботов (BotEntity) и совладельцев (coOwners).
 * PATCH v1.5: в AGGRESSIVE режиме атакуют ВСЕХ, включая владельца (для тренировки).
 *             Добавлена проверка PASSIVE — бот не атакует совсем.
 */
public class BotAttackPlayersGoal extends NearestAttackableTargetGoal<Player> {

    private final BotEntity bot;

    public BotAttackPlayersGoal(BotEntity bot) {
        super(bot, Player.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canUse() {
        // PASSIVE режим — вообще не атакуем
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        // В standby режиме не атакуем
        if (PVPBotConfig.INSTANCE.standbyMode) return false;
        if (!super.canUse()) return false;

        // PATCH: AGGRESSIVE режим — атакуем всех (в т.ч. владельца, для 1v1 тренировки)
        if (bot.getBotMode() == BotEntity.BotMode.AGGRESSIVE) return true;

        // Не атакуем владельца и co-владельцев
        if (target instanceof Player p && isFriendly(p)) return false;

        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        if (PVPBotConfig.INSTANCE.standbyMode) return false;
        // PATCH: AGGRESSIVE — продолжаем даже против владельца
        if (bot.getBotMode() == BotEntity.BotMode.AGGRESSIVE) return super.canContinueToUse();
        if (target instanceof Player p && isFriendly(p)) return false;
        return super.canContinueToUse();
    }

    /** Возвращает true если игрок — владелец или co-владелец бота. */
    private boolean isFriendly(Player p) {
        Player owner = bot.getOwner();
        if (owner != null && owner.getUUID().equals(p.getUUID())) return true;
        // Проверяем co-владельцев через MultiOwner
        if (PVPBotConfig.INSTANCE.globalOwnerUUID != null) {
            if (MultiOwner.INSTANCE.isCoOwner(PVPBotConfig.INSTANCE.globalOwnerUUID, p.getUUID())) return true;
        }
        // Whitelist
        if (PVPBotConfig.INSTANCE.whitelistEnabled
                && PVPBotConfig.INSTANCE.whitelist.contains(p.getName().getString())) return true;
        return false;
    }
}
