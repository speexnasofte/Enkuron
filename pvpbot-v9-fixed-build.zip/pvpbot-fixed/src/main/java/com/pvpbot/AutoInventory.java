package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;

/**
 * AutoInventory v1.6.0 — авторефилл для игрока И для NPC-бота.
 *
 * ┌─────────────────────────────────────────────────────────────────┐
 * │ ИГРОК (клиент)    — tickPlayer() → /give команда               │
 * │ NPC-БОТ (сервер)  — tickBot()    → itemSlot напрямую           │
 * └─────────────────────────────────────────────────────────────────┘
 *
 * Минимальное количество предметов берётся из PVPBotConfig:
 *   refillCrystalsMin, refillTotemsMin, refillFoodMin, refillPotionsMin
 *   botRefillGapplesMin, botRefillTotemsMin
 */
public class AutoInventory {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    // Таймеры проверки (раздельно для игрока и бота)
    private int playerCheckTimer = 0;
    private int botCheckTimer    = 0;

    // ══════════════════════════════════════════════════════════════
    //  ИГРОК — клиентская сторона
    // ══════════════════════════════════════════════════════════════

    public void tickPlayer(Minecraft mc) {
        if (mc.player == null || !cfg.autoRefill) return;
        if (--playerCheckTimer > 0) return;
        playerCheckTimer = 60; // раз в 3 секунды

        Player player = mc.player;

        if (cfg.refillCrystals && cfg.mode == PVPBotConfig.Mode.CRYSTAL) {
            refillPlayer(mc, Items.END_CRYSTAL, cfg.refillCrystalsMin);
        }
        if (cfg.refillTotems) {
            refillPlayer(mc, Items.TOTEM_OF_UNDYING, cfg.refillTotemsMin);
        }
        if (cfg.refillFood) {
            refillPlayer(mc, Items.GOLDEN_APPLE, cfg.refillFoodMin);
        }
        if (cfg.refillPotions) {
            // Зелья лечения — универсально для POT/NETHPOT/SMP режимов
            refillPlayerPotion(mc);
        }
        if (cfg.refillSwords) {
            refillPlayerSword(mc);
        }
    }

    private void refillPlayer(Minecraft mc, Item item, int min) {
        if (mc.player == null) return;
        int current = countPlayerItem(mc.player, item);
        if (current >= min) return;
        int need = min - current;
        String id = BuiltInRegistries.ITEM.getKey(item).toString();
        mc.player.connection.sendCommand("give @s " + id + " " + need);
    }

    private void refillPlayerPotion(Minecraft mc) {
        if (mc.player == null) return;
        // Считаем любые зелья лечения (instant health / regen)
        int count = countPlayerItem(mc.player, Items.SPLASH_POTION);
        if (count < cfg.refillPotionsMin) {
            int need = cfg.refillPotionsMin - count;
            mc.player.connection.sendCommand(
                "give @s splash_potion{Potion:\"minecraft:healing\"} " + need);
        }
    }

    private void refillPlayerSword(Minecraft mc) {
        if (mc.player == null) return;
        ItemStack main = mc.player.getMainHandItem();
        // Рефилл меча если сломан или отсутствует в руке нужный вид
        boolean needsSword = main.isEmpty()
            || (main.isDamageableItem() && main.getDamageValue() >= main.getMaxDamage() - 5);
        if (needsSword) {
            String sword = switch (cfg.mode) {
                case AXE  -> "minecraft:netherite_axe";
                case MACE -> "minecraft:mace";
                default   -> "minecraft:netherite_sword";
            };
            mc.player.connection.sendCommand("give @s " + sword);
        }
    }

    private int countPlayerItem(Player player, Item item) {
        int count = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            var stack = player.getInventory().getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    // ══════════════════════════════════════════════════════════════
    //  NPC-БОТ — серверная сторона
    //  Вызывать из BotEntity.tick() каждый тик.
    // ══════════════════════════════════════════════════════════════

    public void tickBot(BotEntity bot) {
        if (!cfg.botAutoRefill) return;
        if (--botCheckTimer > 0) return;
        botCheckTimer = 80; // раз в 4 секунды

        // FIX: используем per-bot режим
        PVPBotConfig.Mode botMode = bot.getEffectiveMode();

        if (cfg.botRefillGapples) {
            refillBotItem(bot, Items.GOLDEN_APPLE, cfg.botRefillGapplesMin);
        }
        if (cfg.botRefillTotems) {
            // Тотем — в оффхэнд
            refillBotOffhand(bot, Items.TOTEM_OF_UNDYING, cfg.botRefillTotemsMin);
        }
        if (cfg.botRefillSword) {
            refillBotSword(bot, botMode);
        }
        // v1.6.0: зелья для POT/NETHPOT-кита (per-bot режим)
        if (cfg.refillPotions && (botMode == PVPBotConfig.Mode.POT
                || botMode == PVPBotConfig.Mode.NETHPOT
                || botMode == PVPBotConfig.Mode.SMP)) {
            refillBotItem(bot, Items.SPLASH_POTION, cfg.refillPotionsMin);
        }
    }

    /**
     * Добавляет item в инвентарь бота через setItemSlot.
     * Ищет первый свободный слот хотбара (0–8).
     */
    private void refillBotItem(BotEntity bot, Item item, int min) {
        int current = countBotItem(bot, item);
        if (current >= min) return;
        int need = min - current;

        // Ищем свободный слот в хотбаре
        for (int slot = 0; slot < 9 && need > 0; slot++) {
            ItemStack stack = bot.getInventory().getItem(slot);
            if (stack.isEmpty()) {
                // Максимум 64 за стак
                int give = Math.min(need, item.getDefaultMaxStackSize());
                bot.getInventory().setItem(slot, new ItemStack(item, give));
                need -= give;
            } else if (stack.is(item) && stack.getCount() < stack.getMaxStackSize()) {
                int canAdd = stack.getMaxStackSize() - stack.getCount();
                int add = Math.min(need, canAdd);
                stack.grow(add);
                need -= add;
            }
        }
    }

    /** Рефилл предмета в оффхэнд. */
    private void refillBotOffhand(BotEntity bot, Item item, int min) {
        ItemStack offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (offhand.is(item) && offhand.getCount() >= min) return;
        bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(item, min));
    }

    /** Рефилл меча: если mainhand пустой или ItemStack — меч. */
    private void refillBotSword(BotEntity bot, PVPBotConfig.Mode botMode) {
        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        boolean broken = main.isDamageableItem()
            && main.getDamageValue() >= main.getMaxDamage() - 3;
        if (main.isEmpty() || broken) {
            // FIX: per-bot режим вместо глобального
            Item sword = (botMode == PVPBotConfig.Mode.AXE)
                ? Items.NETHERITE_AXE
                : Items.NETHERITE_SWORD;
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(sword));
        }
    }

    private int countBotItem(BotEntity bot, Item item) {
        int count = 0;
        for (int i = 0; i < bot.getInventory().getContainerSize(); i++) {
            ItemStack s = bot.getInventory().getItem(i);
            if (s.is(item)) count += s.getCount();
        }
        // Учитываем оффхэнд
        ItemStack offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
        if (offhand.is(item)) count += offhand.getCount();
        return count;
    }

    // Обратная совместимость — старый вызов tickPlayer(mc)
    /** @deprecated Use tickPlayer(mc) */
    public void tick(Minecraft mc) {
        tickPlayer(mc);
    }
}
