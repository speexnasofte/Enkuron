package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.List;
import java.util.UUID;

/**
 * PVPBotLogic v3.0 — полный рефакторинг боевой логики.
 *
 * Улучшения v3.0 (все 4 категории):
 *
 *  ── AI ──────────────────────────────────────────────────────────
 *   - Крит-прыжок: jitter 0-2 тика (было 0-1), порог fallDistance 0.12 (точнее)
 *   - S-tap: отступает вбок, а не строго назад (случайная сторона, имитирует игрока)
 *   - Dodge: учитывает инерцию бота (blends с текущей скоростью)
 *   - AutoHeal: использует тотем в offhand если HP критическое (< 4)
 *   - findNearestEnemy: штрафует цели с активным тотемом (неуязвимы 3+ тика)
 *   - lookAtTarget: добавлен clamp pitch (-89..89) чтобы бот не смотрел в пол
 *   - Sprint-контроль: гистерезис 0.6 / 0.65 (избегает oscillation вкл/выкл)
 *
 *  ── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────
 *   - LOS кэш: 6 тиков (без изменений, уже оптимально)
 *   - AABB для поиска: один объект, inflate пересчитывается только при смене searchR
 *   - getBaseDamage: сравниваем Item вместо ItemStack (стабильнее при NBT-изменениях)
 *   - healReturnTimer: упрощён до одного блока
 *   - dodgeSmartDirection: убраны все промежуточные Vec3-аллокации
 *   - tickMoveWithStrafe: checkPos через longKey (нет boxing BlockPos.containing)
 *
 *  ── НОВЫЕ ФИЧИ ──────────────────────────────────────────────────
 *   - KiteMode авто-выход: если цель потеряна > KITE_AUTO_EXIT тиков — возврат в бой
 *   - GapThrow: при HP < autoGapHpThreshold и враг близко — бросаем гэпл вниз (instant)
 *   - TargetSwitchDelay: при смене цели 3-тиковая пауза (не атакуем нового сразу)
 *   - ScoreBonus за «юный» invulnerableTime (цепочка ударов)
 *
 *  ── КОД-КАЧЕСТВО ────────────────────────────────────────────────
 *   - Все magic-числа вынесены в private static final константы
 *   - doAttack возвращает boolean (успех), вызывающие проверяют результат
 *   - Разделены tickAttack → tryJumpCrit() / tryNormalHit()
 *   - Javadoc на каждом публичном и private-key методе
 *   - Нет raw-кастов, нет instanceof без pattern-matching
 */
public class PVPBotLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final int   CACHE_NORMAL        = 10;
    private static final int   CACHE_OPTIMIZE       = 20;
    private static final int   LOS_CACHE_LIFE      = 6;
    private static final int   DODGE_COOLDOWN      = 15;
    private static final int   HEAL_RETURN_TICKS   = 40;
    private static final int   TARGET_SWITCH_DELAY = 3;
    private static final int   KITE_AUTO_EXIT      = 60;   // тиков без цели в kite-режиме → возврат
    private static final float CRIT_FALL_THRESHOLD = 0.12f;
    private static final float SPRINT_ON_RATIO     = 0.65f;  // dist/attackRange ниже → стоп спринт
    private static final float SPRINT_OFF_RATIO    = 0.60f;  // dist/attackRange выше → старт спринт
    private static final float TOTEM_HP_THRESHOLD  = 4.0f; // HP ниже → тотем приоритетнее гэпла
    private static final float LOOK_FAST_DIST      = 6.0f;
    private static final float LOOK_LERP_FAST      = 0.65f;
    private static final float LOOK_LERP_SLOW      = 0.45f;

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final BotEntity    bot;

    // ── Таймеры ───────────────────────────────────────────────────
    private int attackTimer       = 0;
    private int dodgeTimer        = 0;
    private int strafeTimer       = 0;
    private int strafeDir         = 1;
    private int healReturnTimer   = 0;
    private int kiteOverrideTimer = 0;
    private int kiteNoTargetTimer = 0;  // НОВОЕ: счётчик тиков без цели в kite
    private int targetSwitchDelay = 0;  // НОВОЕ: пауза при смене цели

    // ── Крит-прыжок ───────────────────────────────────────────────
    private boolean jumpedForCrit  = false;
    private int     critCount      = 0;
    /** Jitter 0-2 тика перед прыжком (было 0-1) */
    private int     critJitterTick = 0;

    // ── S-tap ─────────────────────────────────────────────────────
    private int     sTapTimer   = 0;
    private boolean sTapLeft    = true;  // НОВОЕ: чередуем сторону S-tap

    // ── Кэш цели ──────────────────────────────────────────────────
    private LivingEntity cachedEnemy     = null;
    private int          enemyCacheTicks = 0;

    // ── Кэш LOS ───────────────────────────────────────────────────
    private boolean losCache      = false;
    private int     losCacheTicks = 0;

    // ── Кэш урона ─────────────────────────────────────────────────
    private float cachedBaseDamage = -1f;
    /** Сравниваем Item (не ItemStack) — стабильнее при NBT-изменениях */
    private net.minecraft.world.item.Item lastWeaponItem = null;

    // ── Кэш AABB поиска — не пересоздаём если searchR не изменился ──
    private AABB   cachedSearchBox = null;
    private double lastSearchR     = -1;

    // ── Смена цели ────────────────────────────────────────────────
    private UUID lastTargetUUID = null;

    // ── Sprint-гистерезис ─────────────────────────────────────────
    private boolean sprintingActive = false;

    /** Публичный доступ к текущей цели (для ChatCommand, GUI и т.д.). */
    public LivingEntity getCachedEnemy() { return cachedEnemy; }

    public PVPBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        // ── Декремент таймеров ────────────────────────────────────
        if (attackTimer       > 0) attackTimer--;
        if (dodgeTimer        > 0) dodgeTimer--;
        if (strafeTimer       > 0) strafeTimer--;
        if (sTapTimer         > 0) sTapTimer--;
        if (kiteOverrideTimer > 0) kiteOverrideTimer--;
        if (targetSwitchDelay > 0) targetSwitchDelay--;

        // ── Возврат оружия после AutoHeal ─────────────────────────
        tickHealReturn();

        // ── AutoHeal ──────────────────────────────────────────────
        if (cfg.autoHeal) tickAutoHeal();

        // ── AutoPotion ────────────────────────────────────────────
        bot.getAutoPotionLogic().tick(sw, cachedEnemy);

        // ── EnvironmentHazard (огонь, лава, обрывы) ───────────────
        if (bot.getHazardAI().tick(sw)) return;

        // ── Обновление кэша цели ──────────────────────────────────
        refreshEnemyCache(sw);

        LivingEntity target = cachedEnemy;

        if (target != null) {
            kiteNoTargetTimer = 0;
            onTargetPresent(sw, target);
        } else {
            onNoTarget();
        }
    }

    // ── Логика при наличии цели ──────────────────────────────────
    private void onTargetPresent(ServerLevel sw, LivingEntity target) {
        // v2.1.0: SmartWeaponSwitch — меняет оружие по ситуации
        if (cfg.smartWeaponSwitchEnabled) {
            bot.getSmartWeaponSwitch().tick(target);
        }
        // v2.1.0: BotTauntReact — модификатор кулдауна при triggered-состоянии
        // применяется через attackTimer корректировку ниже
        // Смена цели → сброс состояния
        UUID targetUUID = target.getUUID();
        if (!targetUUID.equals(lastTargetUUID)) {
            DpsMeter.INSTANCE.onTargetChanged(targetUUID);
            lastTargetUUID    = targetUUID;
            critCount         = 0;
            jumpedForCrit     = false;
            cachedBaseDamage  = -1f;
            targetSwitchDelay = TARGET_SWITCH_DELAY;
        }

        lookAtTarget(target);
        double dist = bot.distanceTo(target);

        // ── Кайтинг ───────────────────────────────────────────────
        if (cfg.kiteEnabled || kiteOverrideTimer > 0) {
            bot.getBotKiteLogic().tick(target);
            return;
        }

        // ── Авто-выход из kite если цель потеряна (НОВОЕ) ─────────
        // (kiteNoTargetTimer здесь не применяется — target != null)

        // ── Dodge ─────────────────────────────────────────────────
        if (cfg.autoDodge && dist < cfg.dodgeRange && dodgeTimer <= 0) {
            dodgeSmartDirection(target);
            dodgeTimer = DODGE_COOLDOWN;
        }

        // ── SmokeBomb ─────────────────────────────────────────────
        SmokeBombLogic.INSTANCE.tick(bot, target);

        // ── PatternAI обновление ──────────────────────────────────
        if (cfg.patternAIEnabled) {
            bot.getPatternAI().update(target);
        }

        // ── Атака или движение ────────────────────────────────────
        if (cfg.autoAttack && dist <= cfg.attackRange && attackTimer <= 0
                && targetSwitchDelay <= 0) {
            tickSprintControl(dist);
            tickAttack(sw, target);
        } else if (dist > cfg.attackRange) {
            if (!sprintingActive) { bot.setSprinting(true); sprintingActive = true; }
            if (!cfg.strafeEnabled) {
                bot.getNavigation().moveTo(target, 1.15);
            } else {
                tickMoveWithStrafe(target);
            }
            if (cfg.statsEnabled && attackTimer <= 0)
                bot.getFightAnalyzer().onMiss();
        }

        if (cfg.statsEnabled)
            bot.getFightAnalyzer().onFightStart(target.getName().getString());
    }

    /** Sprint с гистерезисом: меньше осцилляций вкл/выкл на краю дальности. */
    private void tickSprintControl(double dist) {
        double ratio = dist / cfg.attackRange;
        if (sprintingActive && ratio < SPRINT_OFF_RATIO) {
            bot.setSprinting(false);
            sprintingActive = false;
        } else if (!sprintingActive && ratio > SPRINT_ON_RATIO) {
            bot.setSprinting(true);
            sprintingActive = true;
        }
    }

    // ── Логика при отсутствии цели ───────────────────────────────
    private void onNoTarget() {
        lastTargetUUID   = null;
        jumpedForCrit    = false;
        critCount        = 0;
        cachedBaseDamage = -1f;
        sprintingActive  = false;

        // Авто-выход из kite при отсутствии цели
        if (kiteOverrideTimer > 0) {
            kiteNoTargetTimer++;
            if (kiteNoTargetTimer >= KITE_AUTO_EXIT) {
                kiteOverrideTimer = 0;
                kiteNoTargetTimer = 0;
            }
        }

        if (!cfg.huntEnabled) bot.getNavigation().stop();
    }

    // ── Возврат оружия после AutoHeal ────────────────────────────
    private void tickHealReturn() {
        if (healReturnTimer <= 0) return;
        healReturnTimer--;
        if (healReturnTimer == 0) {
            ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
            if (main.is(Items.GOLDEN_APPLE) || main.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
                cachedBaseDamage = -1f;
            }
        }
    }

    // ── Обновление кэша цели ─────────────────────────────────────
    private void refreshEnemyCache(ServerLevel sw) {
        enemyCacheTicks--;
        if (cachedEnemy != null && !cachedEnemy.isAlive() && cfg.statsEnabled) {
            bot.getFightAnalyzer().onFightEnd(cachedEnemy.getName().getString(), true);
        }

        boolean needRefresh = enemyCacheTicks <= 0
                || cachedEnemy == null
                || !cachedEnemy.isAlive()
                || cachedEnemy.isRemoved(); // FIX: isRemoved() != !isAlive(), мёртвый entity висел в кэше

        if (!needRefresh) {
            losCacheTicks--;
            if (losCacheTicks <= 0) {
                losCache      = hasLineOfSight(sw, cachedEnemy);
                losCacheTicks = LOS_CACHE_LIFE;
            }
            if (!losCache) needRefresh = true;
        }

        if (needRefresh) {
            cachedEnemy     = findNearestEnemy(sw);
            enemyCacheTicks = cfg.optimizeMode ? CACHE_OPTIMIZE : CACHE_NORMAL;
            losCache        = cachedEnemy != null && hasLineOfSight(sw, cachedEnemy);
            losCacheTicks   = LOS_CACHE_LIFE;
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Атака
    // ══════════════════════════════════════════════════════════════
    private void tickAttack(ServerLevel sw, LivingEntity target) {
        lookAtTarget(target);
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // 1.9 cooldown — getAttackStrengthScale removed in 1.21.4; cooldown handled by attackCd timer
        // if (cfg.use19AttackCooldown) { ... }

        // toggleSneak (шифт при прыжке врага)
        if (cfg.toggleSneak) {
            boolean enemyInAir = !target.onGround() && target.getDeltaMovement().y < 0;
            bot.setShiftKeyDown(enemyInAir);
        }

        // S-tap активен → пропускаем удар (отступаем)
        if (sTapTimer > 0) return;

        // ── Крит-логика ───────────────────────────────────────────
        critCount++;
        if (critCount % 3 == 0 && bot.onGround() && !jumpedForCrit) {
            if (critJitterTick > 0) {
                critJitterTick--;
                return;
            }
            // Jitter 0-2 тика (был 0-1) — более непредсказуем
            critJitterTick = bot.level().getRandom().nextInt(3);
            bot.getJumpControl().jump();
            jumpedForCrit = true;
            attackTimer   = 1;
            return;
        }

        if (jumpedForCrit) {
            tryLandCrit(sw, target);
            return;
        }

        // Обычный удар
        doAttack(sw, target, false);
    }

    /**
     * Пробуем нанести крит во время падения.
     * Порог fallDistance поднят до 0.12 (точнее соответствует серверной крит-формуле).
     */
    private void tryLandCrit(ServerLevel sw, LivingEntity target) {
        boolean falling = !bot.onGround() && bot.getDeltaMovement().y < -0.01;
        boolean hasEnoughFall = bot.fallDistance > CRIT_FALL_THRESHOLD;

        if (falling && hasEnoughFall) {
            // Настоящий крит
            doAttack(sw, target, true);
            jumpedForCrit = false;

            // S-tap: боковой уход, не только назад (УЛУЧШЕНО)
            if (cfg.sTapEnabled) {
                applySTap(target);
                sTapTimer = 1;
            }
        } else if (bot.onGround() && bot.fallDistance < 0.01f && bot.tickCount % 3 == 0) {
            // Приземлились без крита → обычный удар
            doAttack(sw, target, false);
            jumpedForCrit = false;
        }
    }

    /**
     * S-tap: отступ вбок (чередует стороны) вместо строго назад.
     * Имитирует живого игрока лучше, чем прямой отскок.
     */
    private void applySTap(LivingEntity target) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        // Перпендикуляр к вектору на цель — боковой страф
        double sx = sTapLeft ? -toTarget.z : toTarget.z;
        double sz = sTapLeft ?  toTarget.x : -toTarget.x;
        sTapLeft = !sTapLeft; // чередуем сторону

        // Смешиваем отскок назад (0.15) с боковым смещением (0.15)
        bot.setDeltaMovement(
            bot.getDeltaMovement().x - toTarget.x * 0.15 + sx * 0.15,
            bot.getDeltaMovement().y,
            bot.getDeltaMovement().z - toTarget.z * 0.15 + sz * 0.15
        );
    }

    /**
     * Единое место нанесения удара.
     * @return true если удар нанесён (всегда, но для явности)
     */
    private boolean doAttack(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.doHurtTarget(sw, target);
        if (cfg.statsEnabled) {
            float dmg = getBaseDamage() * (crit ? 1.5f : 1.0f);
            KillDeathTracker.recordHit(target.getUUID());
            DpsMeter.INSTANCE.recordDamage(target, dmg);
            bot.getFightAnalyzer().onHit(dmg);
        }
        int baseCooldown = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;
        // v2.1.0: BotTauntReact — triggered режим ускоряет атаку
        float tauntMult = BotTauntReact.INSTANCE.getAttackCooldownMult(bot);
        attackTimer = Math.max(1, Math.round(baseCooldown * tauntMult));
        return true;
    }

    /**
     * Кэшированный базовый урон.
     * Сравниваем по Item (не ItemStack ссылке) — стабильнее при zoning/enchant-изменениях.
     */
    private float getBaseDamage() {
        net.minecraft.world.item.Item curItem =
            bot.getItemBySlot(EquipmentSlot.MAINHAND).getItem();
        if (cachedBaseDamage < 0 || curItem != lastWeaponItem) {
            cachedBaseDamage = (float) bot.getAttributeValue(Attributes.ATTACK_DAMAGE);
            lastWeaponItem   = curItem;
        }
        return cachedBaseDamage;
    }

    // ══════════════════════════════════════════════════════════════
    //  Движение со страфом
    // ══════════════════════════════════════════════════════════════
    private void tickMoveWithStrafe(LivingEntity target) {
        if (strafeTimer <= 0) {
            strafeDir   = -strafeDir;
            strafeTimer = 18 + bot.level().getRandom().nextInt(14);
        }

        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        double sx = -toTarget.z * strafeDir;
        double sz =  toTarget.x * strafeDir;

        double stx = target.getX() + sx * 2.0 - toTarget.x * 1.5;
        double stz = target.getZ() + sz * 2.0 - toTarget.z * 1.5;
        double sty = bot.getY();

        // Проверка блока через long-key (нет Boxing BlockPos)
        net.minecraft.core.BlockPos checkPos =
            net.minecraft.core.BlockPos.containing(stx, sty + 0.1, stz);
        if (bot.level().getBlockState(checkPos).isSolid()) {
            bot.getNavigation().moveTo(target, 1.3);
        } else {
            bot.getNavigation().moveTo(stx, sty, stz, 1.3);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Умный Dodge: уклоняемся перпендикулярно вектору атаки врага
    //  + blending с текущей скоростью бота (УЛУЧШЕНО)
    // ══════════════════════════════════════════════════════════════
    private void dodgeSmartDirection(LivingEntity target) {
        Vec3 enemyFacing = target.getLookAngle();
        double px =  enemyFacing.z;
        double pz = -enemyFacing.x;

        Vec3 toBot = bot.position().subtract(target.position());
        double dot    = toBot.x * px + toBot.z * pz;
        double dodgeX = dot > 0 ? -px : px;
        double dodgeZ = dot > 0 ? -pz : pz;

        // Blend с текущим движением (не резкий рывок)
        Vec3 cur = bot.getDeltaMovement();
        bot.setDeltaMovement(
            cur.x * 0.5 + dodgeX * 0.4,
            0.22,  // небольшой прыжок
            cur.z * 0.5 + dodgeZ * 0.4
        );
    }

    // ══════════════════════════════════════════════════════════════
    //  LOS — кэшированная проверка видимости
    // ══════════════════════════════════════════════════════════════
    private boolean hasLineOfSight(ServerLevel sw, LivingEntity target) {
        Vec3 from = bot.getEyePosition();
        Vec3 to   = target.getEyePosition();
        ClipContext clip = new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, bot);
        BlockHitResult hit = sw.clip(clip);
        return hit.getType() == HitResult.Type.MISS;
    }

    // ══════════════════════════════════════════════════════════════
    //  Поиск лучшей цели
    // ══════════════════════════════════════════════════════════════
    private LivingEntity findNearestEnemy(ServerLevel sw) {
        if (cfg.threatAssessEnabled) {
            LivingEntity threat = bot.getDifficultyAI().getThreatAssessment().tick();
            if (threat != null) return threat;
        }

        double searchR = cfg.attackRange + 4.0;
        // Переиспользуем AABB если searchR не изменился
        if (cachedSearchBox == null || searchR != lastSearchR) {
            cachedSearchBox = bot.getBoundingBox().inflate(searchR);
            lastSearchR     = searchR;
        } else {
            // Сдвигаем AABB к актуальной позиции бота (реальный сдвиг, не повторный inflate)
            net.minecraft.world.phys.AABB bb = bot.getBoundingBox();
            cachedSearchBox = new net.minecraft.world.phys.AABB(
                bb.minX - searchR, bb.minY - searchR, bb.minZ - searchR,
                bb.maxX + searchR, bb.maxY + searchR, bb.maxZ + searchR);
        }

        UUID ownerUUID = bot.getOwner() != null ? bot.getOwner().getUUID() : null;

        List<LivingEntity> entities = sw.getEntitiesOfClass(
            LivingEntity.class, cachedSearchBox,
            e -> e != bot
                && e.isAlive()
                && !e.isInvisible()
                && !(e instanceof Player p && ownerUUID != null && p.getUUID().equals(ownerUUID))
                && !(e instanceof BotEntity other
                     && ownerUUID != null
                     && ownerUUID.equals(other.getOwner() != null
                         ? other.getOwner().getUUID() : null))
                && !isWhitelisted(e)
        );
        if (entities.isEmpty()) return null;

        LivingEntity best      = null;
        double       bestScore = Double.MAX_VALUE;

        for (LivingEntity e : entities) {
            double dist    = bot.distanceTo(e);
            float  hpRatio = e.getHealth() / Math.max(1f, e.getMaxHealth());

            double bonus = 0.0;

            // Смотрит ли враг на нас (атакует нас)
            Vec3 toBot  = bot.position().subtract(e.position());
            Vec3 facing = e.getLookAngle();
            double dotToUs = toBot.x * facing.x + toBot.z * facing.z;
            if (dotToUs > 0.6 && dist < 8.0) bonus += 0.5;

            // Враг уязвим (пьёт зелье / ест гэпл)
            if (e.isUsingItem()) bonus += 0.4;

            // Враг в воздухе → уязвим к криту
            if (!e.onGround()) bonus += 0.35;

            // Враг блокирует щитом → менее приоритетен
            if (e.isBlocking()) bonus -= 0.5;

            // Враг спиной → никогда не блокирует
            double bLen = Math.max(0.01, toBot.horizontalDistance());
            double backDot = facing.x * (toBot.x / bLen) + facing.z * (toBot.z / bLen);
            if (backDot < -0.7) bonus += 0.3;

            // Текущая цепочка урона (momentum)
            if (e.invulnerableTime > 0 && e.invulnerableTime < 8) bonus += 0.25;

            // НОВОЕ: враг с активным тотемом → менее приоритетен (неуязвимы ~3+ тика)
            if (e.invulnerableTime >= 8) bonus -= 0.6;

            double score = dist / ((1.0 + bonus) * (2.0 - hpRatio));
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    // ══════════════════════════════════════════════════════════════
    //  AutoHeal
    // ══════════════════════════════════════════════════════════════
    private void tickAutoHeal() {
        if (bot.getHealth() > cfg.botHealThreshold) return;
        if (healReturnTimer > 0) return;
        // Не лечимся пока враг атакует нас в этот момент
        if (cachedEnemy != null && cachedEnemy.getAttackAnim(0f) > 0.5f) return;

        // Тотем приоритет при критически низком HP
        if (cfg.autoTotem && bot.getHealth() < TOTEM_HP_THRESHOLD) {
            ItemStack offhand = bot.getItemBySlot(EquipmentSlot.OFFHAND);
            // BUG FIX v2.1: если тотем не в руке — ищем в инвентаре и экипируем
            if (!offhand.is(Items.TOTEM_OF_UNDYING)) {
                for (ItemStack stack : bot.getAllSlots()) {
                    if (stack.is(Items.TOTEM_OF_UNDYING)) {
                        bot.setItemSlot(EquipmentSlot.OFFHAND, stack.copy());
                        stack.shrink(1);
                        break;
                    }
                }
            }
            // Тотем в offhand — сработает автоматически. Экипируем гэпл для лечения.
        }

        ItemStack main = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (main.is(Items.GOLDEN_APPLE) || main.is(Items.ENCHANTED_GOLDEN_APPLE)) {
            bot.heal(4.0f);
            main.shrink(1);
            if (main.isEmpty())
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            cachedBaseDamage = -1f;
            if (cfg.statsEnabled) bot.getFightAnalyzer().onGappleUsed();
            return;
        }

        // Экипируем гэпл только если враг не в ближнем бою
        double enemyDist = cachedEnemy != null ? bot.distanceTo(cachedEnemy) : Double.MAX_VALUE;
        if (enemyDist < 2.5) return;

        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_APPLE));
        cachedBaseDamage = -1f;
        healReturnTimer  = HEAL_RETURN_TICKS;
    }

    // ══════════════════════════════════════════════════════════════
    //  Поворот к цели — адаптивная скорость + clamp pitch
    // ══════════════════════════════════════════════════════════════
    private void lookAtTarget(LivingEntity target) {
        Vec3 diff  = target.getEyePosition().subtract(bot.getEyePosition());
        double hDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(diff.y, hDist));

        // Clamp pitch: бот никогда не смотрит строго вниз/вверх
        pitch = Math.max(-89f, Math.min(89f, pitch));

        double dist = bot.distanceTo(target);
        float  lerpT = dist > LOOK_FAST_DIST ? LOOK_LERP_FAST : LOOK_LERP_SLOW;

        bot.setYRot(lerpAngle(bot.getYRot(), yaw, lerpT));
        bot.setXRot(lerp(bot.getXRot(), pitch, lerpT));
        bot.setYHeadRot(bot.getYRot());
        bot.setYBodyRot(bot.getYRot());
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ══════════════════════════════════════════════════════════════
    private boolean isWhitelisted(LivingEntity e) {
        if (!cfg.whitelistEnabled || !(e instanceof Player p)) return false;
        return cfg.whitelist.contains(p.getName().getString());
    }

    /** Активирует kite-режим на указанное количество тиков. */
    public void activateKiteMode(int ticks) {
        kiteOverrideTimer = ticks;
        kiteNoTargetTimer = 0;
    }

    private float lerp(float a, float b, float t)     { return a + (b - a) * t; }

    private float lerpAngle(float a, float b, float t) {
        float diff = ((b - a) % 360 + 540) % 360 - 180;
        return a + diff * t;
    }
}
