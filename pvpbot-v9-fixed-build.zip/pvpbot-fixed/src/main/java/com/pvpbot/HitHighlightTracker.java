package com.pvpbot;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

/**
 * HitHighlightTracker — клиентский синглтон.
 *
 * Хранит таймер подсветки для каждого EntityID (кого бил бот).
 * После удара — таймер ставится на HIT_DURATION_TICKS (20–100 тиков = 1–5 сек).
 * HUD читает isHighlighted(entityId) и подсвечивает строку игрока.
 *
 * Вызов:
 *   Серверная сторона: HitHighlightTracker.INSTANCE.onHit(entityId)
 *   Клиентская сторона (HUD): HitHighlightTracker.INSTANCE.isHighlighted(entityId)
 *   Тик: HitHighlightTracker.INSTANCE.tick() — вызывать из ClientTickEvents
 */
public class HitHighlightTracker {

    public static final HitHighlightTracker INSTANCE = new HitHighlightTracker();

    // Длительность подсветки в тиках. 20 тиков = 1 секунда.
    // Диапазон: от 20 (1 сек) до 100 (5 сек). Дефолт: 60 тиков = 3 секунды.
    private static final int HIT_DURATION_TICKS = 60;

    // entityId -> оставшихся тиков подсветки
    private final Map<Integer, Integer> highlightTimers = new HashMap<>();

    private HitHighlightTracker() {}

    /**
     * Вызывается когда бот ударил сущность.
     * Регистрирует таймер подсветки.
     *
     * @param entityId vanilla entity id (entity.getId())
     */
    public void onHit(int entityId) {
        highlightTimers.put(entityId, HIT_DURATION_TICKS);
    }

    /**
     * Вызывается каждый клиентский тик.
     * Убывает таймеры, удаляет истёкшие.
     */
    public void tick() {
        Iterator<Map.Entry<Integer, Integer>> it = highlightTimers.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> e = it.next();
            int remaining = e.getValue() - 1;
            if (remaining <= 0) {
                it.remove();
            } else {
                e.setValue(remaining);
            }
        }
    }

    /**
     * Проверяет, нужно ли подсвечивать игрока в HUD.
     *
     * @param entityId vanilla entity id
     * @return true если недавно ударили (таймер > 0)
     */
    public boolean isHighlighted(int entityId) {
        return highlightTimers.containsKey(entityId);
    }

    /**
     * Возвращает долю оставшегося времени [0.0 .. 1.0].
     * 1.0 = только что ударили, 0.0 = время истекло.
     * Используется для fade-out анимации подсветки.
     */
    public float getHighlightAlpha(int entityId) {
        Integer remaining = highlightTimers.get(entityId);
        if (remaining == null) return 0.0f;
        return (float) remaining / HIT_DURATION_TICKS;
    }

    /** Очистить все таймеры (например, при смене мира). */
    public void clear() {
        highlightTimers.clear();
    }
}
