package com.pvpbot;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.*;

/**
 * SmartWeaponSwitch v1.0 — умное переключение оружия по ситуации.
 *
 * Логика (приоритет сверху вниз):
 *
 *  1. Цель летит на элитре → Crossbow / Snowball / Trident
 *  2. Цель ≥ 8 блоков и LOS есть → Bow / Crossbow
 *  3. Цель 3..8 блоков → основное оружие (меч/топор)
 *  4. Цель < 3 блоков и щитом блокирует → Axe (разбивает щит)
 *  5. HP бота < 8 и враг близко → держим оружие (не тратим тик на экип)
 *  6. Цель прыгает / в воздухе → Sword (лучше крит)
 *
 * Переключение с кулдауном: не чаще раза в 20 тиков.
 * Не вмешивается если кит явно диктует оружие (CrystalKit, NethPotKit и т.д.)
 *
 * Интеграция:
 *   SmartWeaponSwitch sw = bot.getSmartWeaponSwitch();
 *   sw.tick(target); // каждый тик в PVPBotLogic.onTargetPresent
 */
public class SmartWeaponSwitch {

    // ── Константы ─────────────────────────────────────────────────
    private static final int SWITCH_COOLDOWN  = 20;  // тиков между переключениями
    private static final float RANGE_RANGED   = 8.0f; // дальше → дальнобойное
    private static final float RANGE_MELEE    = 3.0f; // ближе → ближний бой

    // Биты набора доступных оружий (для быстрой проверки)
    private static final int HAS_BOW      = 1;
    private static final int HAS_CROSSBOW = 2;
    private static final int HAS_AXE      = 4;
    private static final int HAS_SWORD    = 8;
    private static final int HAS_SNOWBALL = 16;
    private static final int HAS_TRIDENT  = 32;

    private final BotEntity bot;
    private int switchCooldown = 0;
    private Item lastEquipped  = null; // кэш текущего оружия

    public SmartWeaponSwitch(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик (вызывать каждый тик из onTargetPresent)
    // ══════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (target == null) return;
        if (!PVPBotConfig.INSTANCE.smartWeaponSwitchEnabled) return;
        if (switchCooldown > 0) { switchCooldown--; return; }

        // Не вмешиваемся в kit-специфичные режимы
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;
        if (mode == PVPBotConfig.Mode.CRYSTAL || mode == PVPBotConfig.Mode.NETHPOT
                || mode == PVPBotConfig.Mode.TPC) return;

        Item desired = selectWeapon(target);
        if (desired == null) return;

        Item current = bot.getItemBySlot(EquipmentSlot.MAINHAND).getItem();
        if (current == desired || desired == lastEquipped) return;

        // Ищем нужное оружие в инвентаре и экипируем
        for (int slot = 0; slot < bot.getInventory().getContainerSize(); slot++) {
            ItemStack stack = bot.getInventory().getItem(slot);
            if (!stack.isEmpty() && stack.getItem() == desired) {
                // Меняем слоты: текущее оружие → инвентарь, нужное → mainhand
                ItemStack old = bot.getItemBySlot(EquipmentSlot.MAINHAND).copy();
                bot.setItemSlot(EquipmentSlot.MAINHAND, stack.copy());
                bot.getInventory().setItem(slot, old);
                lastEquipped = desired;
                switchCooldown = SWITCH_COOLDOWN;
                return;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Выбор оружия по ситуации
    // ══════════════════════════════════════════════════════════════

    private Item selectWeapon(LivingEntity target) {
        double dist = bot.distanceTo(target);
        int available = scanInventory();

        // 1. Цель летит на элитре → дальнобойное
        if (target.isFallFlying()) {
            if (hasFlag(available, HAS_CROSSBOW)) return Items.CROSSBOW;
            if (hasFlag(available, HAS_SNOWBALL)) return Items.SNOWBALL;
            if (hasFlag(available, HAS_BOW))      return Items.BOW;
        }

        // 2. Дальняя дистанция → дальнобойное
        if (dist >= RANGE_RANGED) {
            if (hasFlag(available, HAS_BOW))      return Items.BOW;
            if (hasFlag(available, HAS_CROSSBOW)) return Items.CROSSBOW;
            if (hasFlag(available, HAS_TRIDENT))  return Items.TRIDENT;
        }

        // 3. Цель блокирует щитом → топор
        if (dist < RANGE_MELEE + 2 && target.isBlocking()) {
            if (hasFlag(available, HAS_AXE)) return Items.NETHERITE_AXE;
        }

        // 4. Цель в воздухе → меч (лучше для крита)
        if (!target.onGround() && dist < RANGE_RANGED) {
            if (hasFlag(available, HAS_SWORD)) return Items.NETHERITE_SWORD;
        }

        // 5. Стандартный ближний бой → меч
        if (dist < RANGE_RANGED) {
            if (hasFlag(available, HAS_SWORD)) return Items.NETHERITE_SWORD;
            if (hasFlag(available, HAS_AXE))   return Items.NETHERITE_AXE;
        }

        return null; // не менять
    }

    // ── Сканирование инвентаря ────────────────────────────────────
    private int scanInventory() {
        int flags = 0;
        // Mainhand
        Item mh = bot.getItemBySlot(EquipmentSlot.MAINHAND).getItem();
        flags |= itemFlag(mh);
        // Инвентарь
        for (int i = 0; i < bot.getInventory().getContainerSize(); i++) {
            Item item = bot.getInventory().getItem(i).getItem();
            flags |= itemFlag(item);
        }
        return flags;
    }

    private static int itemFlag(Item item) {
        if (item == Items.BOW)             return HAS_BOW;
        if (item == Items.CROSSBOW)        return HAS_CROSSBOW;
        if (item == Items.NETHERITE_AXE
         || item == Items.DIAMOND_AXE
         || item == Items.IRON_AXE)       return HAS_AXE;
        if (item == Items.NETHERITE_SWORD
         || item == Items.DIAMOND_SWORD
         || item == Items.IRON_SWORD)     return HAS_SWORD;
        if (item == Items.SNOWBALL)        return HAS_SNOWBALL;
        if (item == Items.TRIDENT)         return HAS_TRIDENT;
        return 0;
    }

    private static boolean hasFlag(int available, int flag) {
        return (available & flag) != 0;
    }

    public void reset() {
        switchCooldown = 0;
        lastEquipped   = null;
    }
}
