package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;

/**
 * BotDifficultyAI v3.0 — УМНЫЙ бот.
 *
 * КЛЮЧЕВЫЕ ИСПРАВЛЕНИЯ:
 *   - Перемещение ТОЛЬКО через Navigation (не setDeltaMovement для движения к цели)
 *   - Ограничение скорости через атрибут (не через deltaMovement)
 *   - Blink/Crystal: не телепортируем как читер — реальный projectile arc
 *   - EASY: действительно медленный (атрибут скорости 0.08)
 *   - MEDIUM: 1.0 (норма игрока)
 *   - HARD: 1.1
 *   - EXPERT: 1.15
 *   - Pearl: проверяем есть ли препятствия, не летим через стены
 *   - Crystal: реальная логика ObsidianPlacer + CrystalLogic
 *   - Bow: prediction-based, не instant-hit
 */
public class BotDifficultyAI {

    private final BotEntity bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int pearlCd    = 0;
    private int bowCd      = 0;
    private int crystalCd  = 0;
    private int comboCd    = 0;
    private boolean hardCritPending = false; // FIX #9: ожидание падения для крит-удара в HARD
    private int easyMissT  = 0;
    private int medHumanT  = 0;
    private int medStrafeV    = 0;
    private int patternSyncCd = 0; // синхронизация PatternAI (обновляем yaw раз в 3 тика)
    private int adaptTick  = 0;
    private float lastTargetHp     = -1;
    private int   targetNoDmgTicks = 0;

    private Vec3 predictedPos = null;
    private int  predictCd    = 0;

    private final ComboSystem        comboSystem;
    private final WeaponSwitcher     weaponSwitcher;
    private final PotionPredict      potionPredict;
    private final MaceLogic          maceLogic;
    private final CrystalBotLogic   crystalBotLogic;
    private final StrafeAI          strafe;
    private final ThreatAssessment  threatAssessment;
    private final PlayerlikeBlockPlacer blockPlacer;
    private int playerReactionDelay = 0;

    public BotDifficultyAI(BotEntity bot) {
        this.bot             = bot;
        this.comboSystem     = new ComboSystem(bot);
        this.weaponSwitcher  = new WeaponSwitcher(bot);
        this.maceLogic       = new MaceLogic(bot);
        this.potionPredict   = new PotionPredict(bot);
        this.crystalBotLogic = new CrystalBotLogic(bot);
        this.strafe          = new StrafeAI(bot);
        this.threatAssessment = new ThreatAssessment(bot);
        this.blockPlacer      = new PlayerlikeBlockPlacer(bot);
        applySpeedAttribute();
    }

    /** Устанавливаем атрибут скорости по сложности (per-bot) */
    private void applySpeedAttribute() {
        double spd = switch (bot.getEffectiveDifficulty()) {
            case EASY   -> 0.08;
            case MEDIUM -> 0.13;
            case HARD   -> 0.135;
            case EXPERT -> 0.14;
            case PLAYER -> 0.13; // точно как у живого игрока в спринте
            default     -> 0;
        };
        var speedAttr = bot.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(spd);
    }

    public ThreatAssessment getThreatAssessment() { return threatAssessment; }

    public int getAttackCooldown() {
        return cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown()
            : cfg.attackCooldown;
    }

    public void tick(LivingEntity target) {
        if (bot.level().isClientSide) return;

        if (pearlCd          > 0) pearlCd--;
        if (bowCd            > 0) bowCd--;
        if (crystalCd        > 0) crystalCd--;
        if (comboCd          > 0) comboCd--;
        if (easyMissT        > 0) easyMissT--;
        if (medHumanT        > 0) medHumanT--;
        if (predictCd        > 0) predictCd--;

        // ThreatAssessment теперь вызывается глобально из BotEntity.tick()
        // (оставляем target как есть)

        // PotionPredict
        if (target != null && target.isAlive()) {
            potionPredict.tick(target);
            if (potionPredict.isVulnerable() && bot.distanceTo(target) < 4.0) {
                bot.getNavigation().moveTo(target, 1.2);
                if (bot.level() instanceof ServerLevel sw)
                    bot.doHurtTarget(sw, target);
                potionPredict.onRushAttack();
            }
        }

        if (target == null || !target.isAlive()) {
            if (lastTargetHp > 0) { bot.getNotifier().onKill(null); lastTargetHp = -1; }
            return;
        }

        // Адаптивный трекинг урона
        adaptTick++;
        if (adaptTick % 10 == 0) {
            float hp = target.getHealth();
            if (lastTargetHp >= 0 && hp >= lastTargetHp) targetNoDmgTicks += 10;
            else targetNoDmgTicks = 0;
            lastTargetHp = hp;
        }

        // Режим MACE
        if (cfg.mode == PVPBotConfig.Mode.MACE) {
            maceLogic.tick(target);
            if (!maceLogic.isSmashing()) { comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM); comboSystem.tick(target); }
            return;
        }

        // Диспетчер режимов (crystal, smp, uhc, etc.)
        if (bot.getModeDispatcher().tick(target)) return; // FIX: use shared dispatcher, avoid double AI

        // AutoRetreat — если бот отступает, не атакуем
        if (bot.getAutoRetreat().isRetreating()) return;

        // FIX: ThreatAssessment для ВСЕХ уровней сложности (не только HARD/EXPERT)
        // Если включён — переключаемся на самую опасную цель
        if (cfg.threatAssessEnabled) {
            LivingEntity bestThreat = threatAssessment.tick();
            if (bestThreat != null && bestThreat != target && bestThreat.isAlive()) {
                bot.setTarget(bestThreat);
                target = bestThreat;
            }
        }

        // По сложности (per-bot если задана, иначе глобальная)
        switch (bot.getEffectiveDifficulty()) {
            case EASY   -> tickEasy(target);
            case MEDIUM -> tickMedium(target);
            case HARD   -> tickHard(target);
            case EXPERT -> tickExpert(target);
            case PLAYER -> tickPlayer(target);
            default -> {}
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EASY — тупой, медленный, но всё-таки атакует
    // FIX: заменили tickCount % cd == 0 на собственный таймер,
    //      иначе при AI throttling атака пропускается полностью.
    // ════════════════════════════════════════════════════════════════
    private int easyAttackCd = 0;

    private void tickEasy(LivingEntity target) {
        if (easyMissT > 0) return; // "задумался"
        if (easyAttackCd > 0) easyAttackCd--;

        double dist = bot.distanceTo(target);

        // Движение к цели — чуть быстрее чем раньше
        if (dist > 3.0) {
            bot.getNavigation().moveTo(target, 0.85);
        } else if (dist < 1.5) {
            // Отходим если слишком близко — не стоим вплотную
            bot.getNavigation().stop();
        }

        // Смотрим на цель всегда
        bot.getLookControl().setLookAt(target, 30f, 30f);

        // Атака по собственному таймеру (не tickCount %) — надёжно работает с AI throttling
        if (dist <= 3.5 && easyAttackCd <= 0) {
            // 20% промах (EASY должен иногда мазать)
            if (bot.level().getRandom().nextInt(100) < 20) {
                easyMissT = 8;
                easyAttackCd = cfg.attackCooldown + 4;
                return;
            }
            equipSword();
            if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
            easyAttackCd = cfg.attackCooldown + bot.level().getRandom().nextInt(6); // 10-16 тиков
        }

        // Редкая "задумчивость" — только при достаточном HP
        if (bot.tickCount % 80 == 0 && bot.level().getRandom().nextInt(100) < 15
                && bot.getHealth() > 12f) {
            easyMissT = 10 + bot.level().getRandom().nextInt(15);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // MEDIUM — как обычный игрок
    // FIX: собственный таймер атаки вместо tickCount %
    // ════════════════════════════════════════════════════════════════
    private int medAttackCd = 0;

    private void tickMedium(LivingEntity target) {
        if (medAttackCd > 0) medAttackCd--;

        double dist = bot.distanceTo(target);

        // Лук только если далеко
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0 && medHumanT <= 0) {
            equipBow();
            aimAndShoot(target);
            bowCd = cfg.diffBowCooldown + bot.level().getRandom().nextInt(6);
            medHumanT = 3 + bot.level().getRandom().nextInt(3);
        } else {
            equipSword();
        }

        // Движение — Navigation, спринт при сближении
        if (dist > 2.8) {
            bot.getNavigation().moveTo(target, 1.1);
            if (dist > 5.0 && !bot.isSprinting()) bot.setSprinting(true);
        } else {
            if (bot.isSprinting()) bot.setSprinting(false);
        }

        // Страф с PatternAI если включён
        if (PVPBotConfig.INSTANCE.patternAIEnabled && patternSyncCd <= 0) {
            PatternAI pai = bot.getPatternAI();
            // FIX #5: getLearnedStrafeYaw возвращает абсолютный угол (~baseYaw±90+bias).
            // StrafeAI.doCircle() ожидает маленький OFFSET (дельту от нейтрального страфа).
            // Вычитаем нейтральный угол чтобы получить только смещение.
            double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            double neutralYaw = strafe.isStrafeLeft() ? -90.0 : 90.0;
            strafe.setAdaptedYaw((float)(absYaw - neutralYaw));
            patternSyncCd = 3;
        } else if (patternSyncCd > 0) { patternSyncCd--; }
        if (cfg.strafeEnabled) strafe.tick(target);

        // OPT v1.9: ждём заряд атаки
        boolean medChargeReady = !cfg.use19AttackCooldown
            || true; // 1.21.4: getAttackStrengthScale removed; cooldown managed by medAttackCd

        // Атака по собственному таймеру с человеческой вариацией
        if (dist <= cfg.attackRange && medAttackCd <= 0 && medChargeReady) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
            // OPT v1.9: W-tap на MEDIUM (был только на PLAYER)
            if (cfg.wTapEnabled) {
                // Имитируем остановку через navigation — сбрасываем спринт
                bot.setSprinting(false);
                bot.getNavigation().stop();
            }
            // Небольшая случайная вариация — как живой игрок
            medAttackCd = cfg.attackCooldown + bot.level().getRandom().nextInt(4) - 1;
            medAttackCd = Math.max(4, medAttackCd);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HARD — перлы, воздух-атака, кристаллы
    // ════════════════════════════════════════════════════════════════
    private void tickHard(LivingEntity target) {
        // FIX: crystal-режим — StrafeAI не применяет velocity когда активны кристаллы
        boolean hardCrystals = cfg.diffUseCrystals && bot.level() instanceof net.minecraft.server.level.ServerLevel;
        strafe.setCrystalMode(hardCrystals);
        double dist = bot.distanceTo(target);

        weaponSwitcher.tick(target);
        comboSystem.setPattern(ComboSystem.ComboPattern.RHYTHM);
        comboSystem.tick(target);

        // Страф с PatternAI на HARD
        if (PVPBotConfig.INSTANCE.patternAIEnabled && patternSyncCd <= 0) {
            PatternAI pai = bot.getPatternAI();
            // FIX #5: передаём дельту, а не абсолютный угол
            double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            double neutralYaw = strafe.isStrafeLeft() ? -90.0 : 90.0;
            strafe.setAdaptedYaw((float)(absYaw - neutralYaw));
            patternSyncCd = 3;
        } else if (patternSyncCd > 0) { patternSyncCd--; }
        if (cfg.strafeEnabled) strafe.tick(target);

        // Navigation — агрессивный спринт (FIX v1.4: снизили порог с 2.5 до 2.0)
        if (dist > 2.0) {
            bot.getNavigation().moveTo(target, 1.15); // FIX v1.4: было 1.1
            if (dist > 5.0 && !bot.isSprinting()) bot.setSprinting(true);
            else if (dist < 3.5 && bot.isSprinting()) bot.setSprinting(false);
        }

        // Перл-рывок — к предсказанной позиции если PatternAI включён
        if (cfg.diffUsePearls && dist > cfg.diffPearlThrowDist && pearlCd <= 0) {
            if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                dashTowardPos(predicted);
            } else {
                dashTowardTarget(target);
            }
            pearlCd = cfg.diffPearlCooldown;
        }
        // Перл-отход при низком HP
        if (cfg.diffUsePearls && bot.getHealth() < cfg.diffPearlEscapeHpThreshold && pearlCd <= 0) {
            retreatFromTarget(target);
            pearlCd = cfg.diffPearlCooldown;
        }

        // Кристаллы
        if (cfg.diffUseCrystals && bot.level() instanceof ServerLevel sw)
            crystalBotLogic.tick(sw, target);

        // OPT v1.9: ждём полный заряд атаки в 1.9+ (как живой игрок)
        boolean chargeReady = !cfg.use19AttackCooldown
            || true; // 1.21.4: getAttackStrengthScale removed; cooldown managed by attack timer

        // FIX #9: правильный крит-удар с проверкой fallDistance (как SwordLogic).
        // Раньше: бот прыгал и бил сразу при !onGround() → крит НЕ засчитывался,
        // т.к. ванилла требует fallDistance > 0 И движение вниз (dy < 0).
        boolean inAir = !target.onGround();
        if (dist < cfg.attackRange && comboCd <= 0 && chargeReady) {
            if (!hardCritPending) {
                // Начинаем прыжок для крита каждый 3-й удар
                if (comboCd % 3 == 0 && bot.onGround()) {
                    bot.getJumpControl().jump();
                    hardCritPending = true;
                } else if (bot.onGround()) {
                    // Обычный удар
                    bot.getLookControl().setLookAt(target, 30f, 30f);
                    if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
                    comboCd = Math.max(5, cfg.attackCooldown - 3);
                }
            } else if (!bot.onGround() && bot.getDeltaMovement().y < -0.01
                       && bot.fallDistance > 0.08f) {
                // Летим вниз с достаточным fallDistance — крит!
                bot.getLookControl().setLookAt(target, 30f, 30f);
                if (bot.level() instanceof ServerLevel sw) {
                    bot.doHurtTarget(sw, target);
                    sw.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                        target.getX(), target.getY()+0.8, target.getZ(), 8, 0.2,0.2,0.2,0.1);
                    bot.playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
                }
                hardCritPending = false;
                comboCd = Math.max(5, cfg.attackCooldown - 3);
            } else if (hardCritPending && bot.onGround() && bot.fallDistance < 0.01f) {
                // Прыжок не удался (застряли) — обычный удар
                bot.getLookControl().setLookAt(target, 30f, 30f);
                if (bot.level() instanceof ServerLevel sw) bot.doHurtTarget(sw, target);
                hardCritPending = false;
                comboCd = Math.max(5, cfg.attackCooldown - 3);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EXPERT — кристаллы, предсказание, комбо
    // ════════════════════════════════════════════════════════════════
    private void tickExpert(LivingEntity target) {
        // FIX: crystal-режим
        boolean expCrystals = cfg.diffUseCrystals && bot.level() instanceof net.minecraft.server.level.ServerLevel;
        strafe.setCrystalMode(expCrystals);
        double dist = bot.distanceTo(target);
        boolean inAir = !target.onGround();

        // Предсказание позиции каждые 3 тика
        if (predictCd <= 0) {
            predictedPos = MotionPredictor.predictForProjectile(bot, target, 1.6);
            predictCd = 3;
        }

        // Оружие
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0) {
            equipBow();
            Vec3 aim = predictedPos != null ? predictedPos : target.position();
            aimAndShootAt(aim);
            bowCd = cfg.diffBowCooldown;
        } else {
            equipSword();
        }

        // Navigation — OPT v1.9: чуть агрессивнее
        if (dist > 2.2) bot.getNavigation().moveTo(target, 1.18); // 1.1→1.18

        // Страф агрессивный — с PatternAI на EXPERT
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
        if (PVPBotConfig.INSTANCE.patternAIEnabled && patternSyncCd <= 0) {
            PatternAI pai = bot.getPatternAI();
            // FIX #5: передаём дельту, а не абсолютный угол
            double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            double neutralYaw = strafe.isStrafeLeft() ? -90.0 : 90.0;
            strafe.setAdaptedYaw((float)(absYaw - neutralYaw));
            patternSyncCd = 3;
        } else if (patternSyncCd > 0) { patternSyncCd--; }
        if (cfg.strafeEnabled) strafe.tick(target);

        // Кристаллы + обсидиан
        if (cfg.diffUseCrystals && bot.level() instanceof ServerLevel sw) {
            crystalBotLogic.tick(sw, target);
            if (inAir && crystalCd <= 0 && dist < cfg.diffCrystalPlaceRange) {
                crystalExplosion(sw, target, true);
                crystalCd = cfg.diffCrystalCooldown;
            } else if (!inAir && crystalCd <= 0 && dist < cfg.diffCrystalPlaceRange) {
                crystalExplosion(sw, target, false);
                crystalCd = cfg.diffCrystalCooldown;
            }
        }

        // Перлы
        if (cfg.diffUsePearls) {
            if (dist > cfg.diffPearlThrowDist && pearlCd <= 0) {
                if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                    Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                    dashTowardPos(predicted);
                } else {
                    dashTowardTarget(target);
                }
                pearlCd = cfg.diffPearlCooldown;
            }
            if (bot.getHealth() < cfg.diffPearlEscapeHpThreshold && pearlCd <= 0) {
                retreatFromTarget(target);
                pearlCd = cfg.diffPearlCooldown;
            }
            // Давление если цель не получает урон
            if (targetNoDmgTicks > 25 && dist > 3.0 && pearlCd <= 0) {
                if (PVPBotConfig.INSTANCE.patternAIEnabled) {
                    Vec3 predicted = bot.getPatternAI().getPredictedPosition(target);
                    dashTowardPos(predicted);
                } else {
                    dashTowardTarget(target);
                }
                pearlCd = cfg.diffPearlCooldown;
                targetNoDmgTicks = 0;
            }
        }

        // Комбо
        comboSystem.setPattern(ComboSystem.ComboPattern.BURST);
        comboSystem.tick(target);
        weaponSwitcher.tick(target);
    }

    // ── Перемещение к цели через Navigation (не телепорт) ────────
    private void dashTowardTarget(LivingEntity target) {
        dashTowardPos(target.position());
    }

    // ── Перемещение к конкретной позиции (для PatternAI-предсказания) ──
    private void dashTowardPos(Vec3 pos) {
        bot.getNavigation().moveTo(pos.x, pos.y, pos.z, 1.6);
        bot.setSprinting(true);
        if (bot.level() instanceof ServerLevel sw) {
            sw.sendParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY() + 0.5, bot.getZ(), 8, 0.2, 0.3, 0.2, 0.05);
        }
        bot.playSound(SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.2f);
    }

    // ── Отход от цели ─────────────────────────────────────────────
    private void retreatFromTarget(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 dest = bot.position().add(away.scale(cfg.diffPearlEscapeDist));
        bot.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.5);
        if (bot.level() instanceof ServerLevel sw) {
            sw.sendParticles(ParticleTypes.SMOKE,
                bot.getX(), bot.getY() + 0.5, bot.getZ(), 5, 0.1, 0.2, 0.1, 0.02);
        }
    }

    // ── Взрыв кристалла ───────────────────────────────────────────
    private void crystalExplosion(ServerLevel sw, LivingEntity target, boolean inAir) {
        float dmg = inAir ? cfg.diffCrystalDamage * 1.35f : cfg.diffCrystalDamage;
        target.hurt(sw.damageSources().explosion(bot, bot), dmg);
        Vec3 kb = target.position().subtract(bot.position()).normalize().scale(1.0);
        target.setDeltaMovement(target.getDeltaMovement().add(kb.x, 0.35, kb.z));
        sw.sendParticles(ParticleTypes.EXPLOSION,
            target.getX(), target.getY() + 0.5, target.getZ(), 1, 0, 0, 0, 0);
    }

    // ── Стрельба из лука с задержкой прицеливания ─────────────────
    private void aimAndShoot(LivingEntity target) {
        aimAndShootAt(MotionPredictor.predict(target, 4));
    }

    private void aimAndShootAt(Vec3 aimPos) {
        bot.getLookControl().setLookAt(aimPos.x, aimPos.y + 0.5, aimPos.z, 60f, 60f);
        if (!(bot.level() instanceof ServerLevel sw)) return;
        double dist = bot.position().distanceTo(aimPos);
        float dmg = (float) Math.max(1.0, 9.0 - dist * 0.22);
        sw.getEntitiesOfClass(LivingEntity.class,
            new net.minecraft.world.phys.AABB(aimPos, aimPos).inflate(1.2),
            e -> e != bot && e.isAlive()
        ).stream().findFirst().ifPresent(e ->
            e.hurt(sw.damageSources().mobAttack(bot), dmg) // FIX: arrow(null) → NPE в 1.21.x
        );
    }

    // ════════════════════════════════════════════════════════════════
    // PLAYER — неотличим от живого игрока: ставит блоки, иногда мажет,
    //          нет телепортов/кристаллов/читерских перлов
    // ════════════════════════════════════════════════════════════════
    private int playerAttackCd    = 0;
    private int playerJitterTimer = 20;
    private int playerBlockTimer  = 0;  // FIX: щитоблокирование в PLAYER-режиме

    // FIX: TerrainTactics для PLAYER-режима
    private TerrainTactics playerTerrain = null;
    private TerrainTactics getPlayerTerrain() {
        if (playerTerrain == null) playerTerrain = new TerrainTactics(bot);
        return playerTerrain;
    }

    private WTapLogic playerWTap = null;
    private WTapLogic getPlayerWTap() {
        if (playerWTap == null) playerWTap = new WTapLogic(bot);
        return playerWTap;
    }

    private void tickPlayer(LivingEntity target) {
        double dist = bot.distanceTo(target);
        var rng = bot.level().getRandom();

        if (playerAttackCd    > 0) playerAttackCd--;
        if (playerJitterTimer > 0) playerJitterTimer--;
        if (playerBlockTimer  > 0) playerBlockTimer--;

        // FIX: TerrainTactics в PLAYER-режиме
        if (bot.level() instanceof net.minecraft.server.level.ServerLevel sw) {
            getPlayerTerrain().tick(target, sw);
            // Толкаем цель в опасное место
            if (getPlayerTerrain().hasHazardNearTarget() && dist <= 4.5) {
                getPlayerTerrain().tryPush(target, sw);
            }
        }

        // 1. Реакция с «человеческой» задержкой — раз в секунду
        if (playerJitterTimer <= 0) {
            playerReactionDelay = rng.nextInt(cfg.playerReactionJitter + 1);
            playerJitterTimer = 20;
        }
        if (playerReactionDelay > 0) { playerReactionDelay--; return; }

        // W-tap тик (блокирует Navigation на 2 тика после удара)
        boolean wTapActive = cfg.wTapEnabled && getPlayerWTap().tick(target);

        // FIX: щитоблокирование — цель замахивается → блокируем (~25% шанс как у человека)
        boolean targetSwinging = target.swingTime > 0;
        if (targetSwinging && playerBlockTimer <= 0 && dist < 4.0
                && rng.nextInt(100) < 25) {
            bot.setShiftKeyDown(true);
            playerBlockTimer = 8 + rng.nextInt(6); // 8–14 тиков блока
        } else if (playerBlockTimer <= 0) {
            bot.setShiftKeyDown(false);
        }

        // 2. Движение: высокая точка или к цели
        if (!wTapActive) {
            if (getPlayerTerrain().shouldSeekHighGround() && dist > 3.0) {
                Vec3 high = getPlayerTerrain().getHighGroundPos();
                if (high != null) bot.getNavigation().moveTo(high.x, high.y, high.z, 1.0);
            } else if (dist > 2.8) {
                bot.getNavigation().moveTo(target, 1.0);
                bot.setSprinting(true);
            } else {
                bot.setSprinting(false);
            }
        }

        // 3. Страф — CIRCLE как у обычного игрока, без zigzag
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        if (cfg.patternAIEnabled) {
            // FIX #5: передаём дельту, а не абсолютный угол
            double absYaw = bot.getPatternAI()
                .getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
            double neutralYaw = strafe.isStrafeLeft() ? -90.0 : 90.0;
            strafe.setAdaptedYaw((float)(absYaw - neutralYaw));
        }
        if (cfg.strafeEnabled) strafe.tick(target);

        // 4. Лук — только если цель ОЧЕНЬ далеко, и то медленно
        if (dist > cfg.diffBowSwitchRange && bowCd <= 0) {
            equipBow();
            aimAndShoot(target);
            bowCd = cfg.diffBowCooldown + rng.nextInt(8);
        } else {
            equipSword();
        }

        // 5. Постройка блоков — как у игрока
        boolean justBuilt = false;
        if (bot.tickCount % 4 == 0) {
            blockPlacer.equipBlockTemporarily();
            justBuilt = blockPlacer.tick(target);
            blockPlacer.reequipSword();
        }

        // 6. Атака по собственному таймеру (не tickCount %)
        if (!justBuilt && !wTapActive && dist <= cfg.attackRange && playerAttackCd <= 0) {
            // Иногда промахиваемся
            if (rng.nextInt(100) < cfg.playerMissChance) {
                playerAttackCd = cfg.attackCooldown;
                return;
            }

            // Иногда делаем ложный замах перед атакой
            if (cfg.playerFakeSwing && rng.nextInt(100) < 20) {
                bot.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                playerAttackCd = cfg.attackCooldown; // следующий тик — реальный удар
                return;
            }

            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (bot.level() instanceof net.minecraft.server.level.ServerLevel sw) {
                bot.doHurtTarget(sw, target);
            }
            // Человеческая вариация ±1-2 тика
            playerAttackCd = cfg.attackCooldown + rng.nextInt(4) - 1;
            playerAttackCd = Math.max(4, playerAttackCd);

            // УЛУЧШЕНИЕ: настоящий серверный W-tap через WTapLogic (остановка + возобновление)
            if (cfg.wTapEnabled) {
                getPlayerWTap().onAttack();
            }
        }
    }

    private void equipSword() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("unbreaking", 3).build());
    }
    private void equipBow() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                .enchant("power", 5).enchant("unbreaking", 3).build());
    }
}
