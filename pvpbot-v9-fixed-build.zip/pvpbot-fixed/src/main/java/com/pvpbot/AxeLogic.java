package com.pvpbot;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * AxeLogic v6.0 — Полная переработка
 *
 * ══════════════════════════════════════════════════════════════════
 *  ЧТО НОВОГО В v6:
 *
 *  1. ФАЗОВАЯ МАШИНА СОСТОЯНИЙ
 *     IDLE → SHIELD_BREAK → BURST_SWORD → CRIT_JUMP → SWEEP → GAP → RETREAT
 *     Каждая фаза имеет свою логику, тайминги и условия перехода.
 *
 *  2. SWEEP ATTACK (круговой удар)
 *     Ванильный sweep топором задействуется когда 2+ врагов в радиусе 4 блоков.
 *     Бот разворачивается боком к группе и бьёт с анимацией sweep.
 *     Урон по всем в зоне через AABB-query.
 *
 *  3. DISARM ATTEMPT (выбивание предмета)
 *     Если у цели в руке дорогой предмет (меч/лук/мейс) — раз в DISARM_CD тиков
 *     бот делает удар снизу-вверх (kb вверх) пытаясь выбить предмет.
 *     Vanilla не поддерживает настоящий disarm, но сильный KB снизу
 *     заставляет игрока терять прицел + interrupt ability.
 *
 *  4. RANGED PHASE
 *     Дальность > RANGED_DIST:
 *       • Арбалет с firework rocket если есть (взрывной снаряд)
 *       • Иначе — обычный арбалет
 *       • При dist > 25 — ждём, не тратим предметы
 *
 *  5. SHIELD SPAM v2 (улучшен из v5.1)
 *     Считаем тики активного блока (blockingTicks).
 *     Если цель держит щит > SHIELD_PATIENCE_TICKS — переходим к
 *     FEINT: ходим кругами несколько тиков потом мгновенная атака.
 *
 *  6. AGGRO ESCALATION
 *     После каждых ESCALATE_EVERY ударов без слома щита:
 *     бот увеличивает скорость движения (+0.05 за уровень, макс +0.2)
 *     и сокращает AXE_CD на 1 тик (минимум 10).
 *
 *  7. COMBO WINDOW DETECTION
 *     Если цель только что получила KB (vy > 0.2 или vx/vz > 0.5) —
 *     немедленно burst мечом 2 удара без кулдауна (BURST_ON_KB).
 *
 *  8. DODGE УЛУЧШЕН
 *     При получении урона > 6: dash назад + strafe смена стороны.
 *     При получении урона > 12 (критический): pearl-телепорт назад.
 *
 * ══════════════════════════════════════════════════════════════════
 *  ИНТЕГРАЦИЯ:
 *    В ModeLogicDispatcher.tick(): case AXE -> { getAxe().tick(target); return true; }
 * ══════════════════════════════════════════════════════════════════
 */
public class AxeLogic {

    // ── Дистанции ──────────────────────────────────────────────────
    private static final double MELEE_RANGE        = 3.3;
    private static final double IDEAL_DIST         = 2.4;
    private static final double SWEEP_RADIUS       = 4.0;
    private static final double RANGED_DIST        = 10.0;
    private static final double FAR_DIST           = 25.0;
    private static final double DISARM_RANGE       = 2.8;

    // ── Кулдауны (тики) ────────────────────────────────────────────
    private static final int    AXE_CD_BASE        = 18;
    private static final int    AXE_CD_MIN         = 10;
    private static final int    BURST_CD           = 4;
    private static final int    BURST_COUNT        = 4;
    private static final int    SWEEP_CD           = 30;
    private static final int    XBOW_CD            = 32;
    private static final int    DASH_CD            = 55;
    private static final int    GAP_CD             = 150;
    private static final int    DISARM_CD          = 90;
    private static final int    DODGE_CD           = 20;
    private static final int    PEARL_CD           = 80;
    private static final int    FEINT_CD           = 50;
    private static final int    FEINT_LOOK_TICKS   = 5;
    private static final int    CRIT_EVERY         = 3;

    // ── Щит ────────────────────────────────────────────────────────
    private static final int    SHIELD_DIS_DUR     = 100;
    private static final int    SHIELD_SPAM_CD     = 6;
    private static final int    MAX_SHIELD_SPAM    = 8;
    private static final int    SHIELD_PATIENCE    = 40; // тиков → feint

    // ── Aggro escalation ───────────────────────────────────────────
    private static final int    ESCALATE_EVERY     = 5;  // ударов до escalation
    private static final double ESCALATE_SPEED     = 0.05;
    private static final double ESCALATE_MAX       = 0.20;

    // ── HP пороги ──────────────────────────────────────────────────
    private static final float  GAP_HP             = 10.0f;
    private static final float  DODGE_CRIT_HP      = 6.0f; // pearl-телепорт
    private static final float  PEARL_ESCAPE_HP    = 7.0f;

    // ── Фазы ───────────────────────────────────────────────────────
    private enum Phase {
        IDLE,          // нормальный бой
        SHIELD_BREAK,  // ломаем щит
        BURST_SWORD,   // серия мечом после слома
        CRIT_JUMP,     // прыжок для крита
        SWEEP,         // круговой удар
        FEINT,         // ложный замах
        RETREAT        // отход
    }

    private Phase phase          = Phase.IDLE;

    // ── Таймеры ────────────────────────────────────────────────────
    private int   attackCd       = 0;
    private int   shieldDisabled = 0;
    private int   burstHits      = 0;
    private int   burstCd        = 0;
    private int   sweepCd        = 0;
    private int   xbowCd         = 0;
    private int   dashCd         = 0;
    private int   gapCd          = 0;
    private int   disarmCd       = 0;
    private int   dodgeCd        = 0;
    private int   pearlCd        = 0;
    private int   feintCd        = 0;
    private int   feintLookTimer = 0;
    private int   blockTimer     = 0;
    private int   shieldSpamCd   = 0;
    private int   shieldSpamHits = 0;
    private int   blockingTicks  = 0;
    private int   patternSyncCd  = 0;

    // ── Счётчики ───────────────────────────────────────────────────
    private int   hitCount       = 0;
    private int   escalateLevel  = 0;
    private int   hitsWithoutBreak = 0;
    private int   critCounter    = 0;

    // ── Флаги ──────────────────────────────────────────────────────
    private boolean critPending  = false;
    private boolean inBurst      = false;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    public AxeLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    // ════════════════════════════════════════════════════════════════
    //  ГЛАВНЫЙ ТИК
    // ════════════════════════════════════════════════════════════════

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(); return; }

        // Декременты
        if (attackCd       > 0) attackCd--;
        if (shieldDisabled > 0) shieldDisabled--;
        if (burstCd        > 0) burstCd--;
        if (sweepCd        > 0) sweepCd--;
        if (xbowCd         > 0) xbowCd--;
        if (dashCd         > 0) dashCd--;
        if (gapCd          > 0) gapCd--;
        if (disarmCd       > 0) disarmCd--;
        if (dodgeCd        > 0) dodgeCd--;
        if (pearlCd        > 0) pearlCd--;
        if (feintCd        > 0) feintCd--;
        if (feintLookTimer > 0) feintLookTimer--;
        if (blockTimer     > 0) blockTimer--;
        if (shieldSpamCd   > 0) shieldSpamCd--;
        if (patternSyncCd  > 0) patternSyncCd--;

        double dist     = bot.distanceTo(target);
        boolean blocking = isTargetBlocking(target);

        // Обновляем счётчик блокирования
        blockingTicks = blocking ? blockingTicks + 1 : 0;

        // Gap при низком HP
        if (bot.getHealth() < GAP_HP && gapCd <= 0) eatGap(sw);

        // Авто-щит в оффхенд
        equipShieldOffhand();

        // ── Дальний бой ────────────────────────────────────────────
        if (dist > RANGED_DIST) {
            tickRanged(sw, target, dist);
            return;
        }

        // ── Активация щита (блок входящей атаки) ──────────────────
        tickAutoBlock(target, dist);

        // ── Выбор фазы ────────────────────────────────────────────
        updatePhase(sw, target, dist, blocking);

        // ── Движение ──────────────────────────────────────────────
        tickMovement(target, dist);

        // ── Страф ─────────────────────────────────────────────────
        boolean wTapActive = wTap.tick(target);
        if (!wTapActive && dist < MELEE_RANGE + 2.5 && cfg.strafeEnabled) {
            syncPatternAI();
            strafe.tick(target);
        }

        if (dist > MELEE_RANGE) return;

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Диспатч по фазе ───────────────────────────────────────
        switch (phase) {
            case SHIELD_BREAK -> tickShieldBreak(sw, target, blocking, wTapActive);
            case BURST_SWORD  -> tickBurstSword(sw, target, wTapActive);
            case CRIT_JUMP    -> tickCritJump(sw, target);
            case SWEEP        -> tickSweep(sw, target);
            case FEINT        -> tickFeint(sw, target);
            case RETREAT      -> tickRetreat(target);
            default           -> tickIdle(sw, target, blocking, wTapActive);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Выбор фазы
    // ════════════════════════════════════════════════════════════════

    private void updatePhase(ServerLevel sw, LivingEntity target, double dist, boolean blocking) {
        // Burst мечом активен
        if (inBurst) { phase = Phase.BURST_SWORD; return; }

        // Цель заблокирована щитом → Shield Break
        if (blocking) {
            // Слишком долго держит щит → Feint
            if (blockingTicks > SHIELD_PATIENCE && feintCd <= 0) {
                phase = Phase.FEINT;
                feintCd       = FEINT_CD;
                feintLookTimer = FEINT_LOOK_TICKS;
                return;
            }
            phase = Phase.SHIELD_BREAK;
            return;
        }

        // Sweep если 2+ врагов рядом
        if (sweepCd <= 0 && countNearbyEnemies(sw, target) >= 2) {
            phase = Phase.SWEEP;
            return;
        }

        // Крит-прыжок
        if (critCounter >= CRIT_EVERY && bot.onGround() && dist <= MELEE_RANGE) {
            phase = Phase.CRIT_JUMP;
            return;
        }
        if (critPending) { phase = Phase.CRIT_JUMP; return; }

        phase = Phase.IDLE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза IDLE — обычный бой
    // ════════════════════════════════════════════════════════════════

    private void tickIdle(ServerLevel sw, LivingEntity target, boolean blocking, boolean wTapActive) {
        if (attackCd > 0 || wTapActive) return;

        // Combo window: цель получила KB — быстрые 2 удара
        if (isTargetInKnockback(target)) {
            doAxeHit(sw, target, false);
            // Второй удар через 2 тика — не устанавливаем полный кд
            attackCd = 2;
            return;
        }

        // Disarm attempt
        if (disarmCd <= 0 && dist(target) < DISARM_RANGE && hasValuableItem(target)) {
            doDisarm(sw, target);
            disarmCd = DISARM_CD;
            return;
        }

        // Обычный удар топором
        equipAxe();
        doAxeHit(sw, target, false);
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза SHIELD_BREAK
    // ════════════════════════════════════════════════════════════════

    private void tickShieldBreak(ServerLevel sw, LivingEntity target, boolean blocking, boolean wTapActive) {
        if (!blocking) {
            // Щит только что опал — переходим в burst
            shieldSpamHits = 0;
            shieldDisabled = SHIELD_DIS_DUR;
            inBurst        = true;
            phase          = Phase.BURST_SWORD;
            hitsWithoutBreak = 0;
            escalateLevel  = 0;
            return;
        }
        if (wTapActive || shieldSpamCd > 0) return;

        // Aggro escalation: после каждых ESCALATE_EVERY ударов без слома
        if (shieldSpamHits > 0 && shieldSpamHits % ESCALATE_EVERY == 0) {
            escalateLevel = Math.min(escalateLevel + 1, 4);
        }

        // Бьём топором
        equipAxe();
        bot.doHurtTarget(sw, target);
        shieldSpamCd = Math.max(4, SHIELD_SPAM_CD - escalateLevel);
        shieldSpamHits++;
        hitsWithoutBreak++;
        hitCount++;

        // Спам-частицы
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
            target.getX(), target.getY() + 1, target.getZ(), 4, 0.4, 0.2, 0.4, 0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.95f + escalateLevel * 0.05f);

        // Если не можем сломать — отступаем
        if (shieldSpamHits >= MAX_SHIELD_SPAM) {
            shieldSpamHits = 0;
            shieldSpamCd   = AXE_CD_BASE;
            phase = Phase.RETREAT;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза BURST_SWORD
    // ════════════════════════════════════════════════════════════════

    private void tickBurstSword(ServerLevel sw, LivingEntity target, boolean wTapActive) {
        if (burstCd > 0 || wTapActive) return;

        if (burstHits < BURST_COUNT) {
            // Меч для burst (выше скорость атаки)
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                    .enchant("sharpness",5).enchant("unbreaking",3).enchant("mending",1).build());
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 3, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 0.9f, 1.1f);
            burstCd = BURST_CD;
            burstHits++;
            if (cfg.wTapEnabled) wTap.onAttack();
        } else {
            inBurst   = false;
            burstHits = 0;
            phase     = Phase.IDLE;
            attackCd  = effectiveAxeCd();
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза CRIT_JUMP
    // ════════════════════════════════════════════════════════════════

    private void tickCritJump(ServerLevel sw, LivingEntity target) {
        if (!critPending) {
            // Прыгаем
            bot.getJumpControl().jump();
            critPending = true;
            critCounter = 0;
            return;
        }

        // Летим вниз — бьём
        if (!bot.onGround() && bot.getDeltaMovement().y < -0.01
                && bot.fallDistance > 0.08f) {
            equipAxe();
            doAxeHit(sw, target, true);
            critPending = false;
            phase = Phase.IDLE;
            return;
        }

        // Прыжок не получился — обычный удар
        if (critPending && bot.onGround() && bot.fallDistance < 0.01f) {
            equipAxe();
            doAxeHit(sw, target, false);
            critPending = false;
            phase = Phase.IDLE;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза SWEEP — круговой удар по группе
    // ════════════════════════════════════════════════════════════════

    private void tickSweep(ServerLevel sw, LivingEntity target) {
        List<LivingEntity> nearby = getNearbyEnemies(sw, target);
        if (nearby.size() < 2 || sweepCd > 0) {
            phase = Phase.IDLE;
            return;
        }

        // Позиционируемся в центр группы
        Vec3 center = Vec3.ZERO;
        for (LivingEntity e : nearby) center = center.add(e.position());
        center = center.scale(1.0 / nearby.size());
        bot.getLookControl().setLookAt(center.x, center.y + 1, center.z, 60f, 30f);

        // Наносим урон всем в зоне
        equipAxe();
        for (LivingEntity enemy : nearby) {
            if (enemy.isAlive()) {
                enemy.hurt(sw.damageSources().mobAttack(bot), 8.0f);
                Vec3 kb = enemy.position().subtract(bot.position()).normalize();
                enemy.setDeltaMovement(kb.x * 1.2, 0.25, kb.z * 1.2);
            }
        }

        // Эффекты sweep
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
            bot.getX(), bot.getY() + 1, bot.getZ(), 16, 1.5, 0.3, 1.5, 0.08);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.75f);
        bot.getHeatMap().recordDamageDealt(bot.position(), 8.0f * nearby.size());

        sweepCd = SWEEP_CD;
        attackCd = effectiveAxeCd();
        phase = Phase.IDLE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза FEINT — ложный замах чтобы сбить блокирование
    // ════════════════════════════════════════════════════════════════

    private void tickFeint(ServerLevel sw, LivingEntity target) {
        if (feintLookTimer > 0) {
            // Смотрим мимо цели
            double offset = FEINT_LOOK_TICKS - feintLookTimer > 2 ? 60 : -60;
            double feintYaw = bot.getYRot() + offset;
            bot.getLookControl().setLookAt(
                bot.getX() + Math.sin(Math.toRadians(feintYaw)) * 4,
                target.getEyeY(),
                bot.getZ() + Math.cos(Math.toRadians(feintYaw)) * 4,
                60f, 30f);
            return;
        }

        // Feint завершён — мгновенный удар
        bot.getLookControl().setLookAt(target, 60f, 30f);
        if (attackCd <= 0) {
            equipAxe();
            doAxeHit(sw, target, false);
        }
        blockingTicks = 0;
        phase = Phase.IDLE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Фаза RETREAT — отход
    // ════════════════════════════════════════════════════════════════

    private void tickRetreat(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 dest = bot.position().add(away.scale(8.0));
        bot.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.3);
        // Через 1 секунду возвращаемся
        if (bot.tickCount % 20 == 0) phase = Phase.IDLE;
    }

    // ════════════════════════════════════════════════════════════════
    //  Дальний бой
    // ════════════════════════════════════════════════════════════════

    private void tickRanged(ServerLevel sw, LivingEntity target, double dist) {
        if (dist > FAR_DIST) {
            // Слишком далеко — двигаемся
            bot.getNavigation().moveTo(target, 1.2);
            return;
        }

        // Двигаемся ближе
        if (dashCd <= 0) {
            bot.getNavigation().moveTo(target, 1.35);
            bot.setSprinting(true);
            dashCd = DASH_CD;
        }

        bot.getLookControl().setLookAt(target, 60f, 60f);

        // Арбалет
        if (xbowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.CROSSBOW, bot.level().registryAccess())
                    .enchant("quick_charge", 3).enchant("unbreaking", 3).build());
            if (target.isAlive())
                target.hurt(sw.damageSources().mobAttack(bot), 9.0f);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 4, 0.2, 0.2, 0.2, 0.1);
            bot.playSound(SoundEvents.CROSSBOW_SHOOT, 1.0f, 1.0f);
            xbowCd = XBOW_CD;
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Disarm attempt
    // ════════════════════════════════════════════════════════════════

    private void doDisarm(ServerLevel sw, LivingEntity target) {
        // Удар снизу-вверх: сильный вертикальный KB
        equipAxe();
        bot.doHurtTarget(sw, target);
        // Добавляем вертикальный импульс
        target.setDeltaMovement(
            target.getDeltaMovement().x,
            target.getDeltaMovement().y + 1.8,
            target.getDeltaMovement().z
        );
        // Спецэффекты
        sw.sendParticles(ParticleTypes.ENCHANTED_HIT,
            target.getX(), target.getY() + 1, target.getZ(), 12, 0.3, 0.3, 0.3, 0.15);
        bot.playSound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.7f);
        attackCd = effectiveAxeCd();
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    // ════════════════════════════════════════════════════════════════
    //  Авто-щит
    // ════════════════════════════════════════════════════════════════

    private void tickAutoBlock(LivingEntity target, double dist) {
        boolean recentlyHit = bot.getLastHurtByMob() == target
            && bot.tickCount - bot.getLastHurtByMobTimestamp() < 5;
        boolean shouldBlock = !inBurst
            && shieldDisabled <= 0
            && dist < MELEE_RANGE + 1.0
            && (isTargetSwinging(target) || recentlyHit)
            && blockTimer <= 0;

        if (shouldBlock) {
            bot.setShiftKeyDown(true);
            blockTimer = 14;
        } else if (blockTimer <= 0) {
            bot.setShiftKeyDown(false);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Движение
    // ════════════════════════════════════════════════════════════════

    private void tickMovement(LivingEntity target, double dist) {
        double speedBonus = escalateLevel * ESCALATE_SPEED;
        double speed = Math.min(1.05 + speedBonus, 1.05 + ESCALATE_MAX);

        if (dist > IDEAL_DIST + 0.5) {
            bot.getNavigation().moveTo(target, speed);
            if (dist > 6.0 && !bot.isSprinting()) bot.setSprinting(true);
            else if (dist < IDEAL_DIST * 1.3 && bot.isSprinting()) bot.setSprinting(false);
        } else if (dist < 1.5) {
            bot.getNavigation().stop();
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  Вызвать при получении урона
    // ════════════════════════════════════════════════════════════════

    public void onDamageReceived(float amount, LivingEntity attacker) {
        if (dodgeCd > 0) return;

        if (amount > 12.0f && pearlCd <= 0 && attacker != null) {
            // Критический урон — pearl-телепорт назад
            if (bot.level() instanceof ServerLevel sw) {
                Vec3 away = bot.position().subtract(attacker.position()).normalize();
                Vec3 dest = bot.getEyePosition().add(away.scale(10.0));
                var pearl = new net.minecraft.world.entity.projectile.ThrownEnderpearl(
                    net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
                pearl.setOwner(bot);
                Vec3 dir = dest.subtract(bot.getEyePosition()).normalize();
                pearl.moveTo(bot.getEyePosition().x, bot.getEyePosition().y, bot.getEyePosition().z);
                pearl.setDeltaMovement(dir.scale(2.5));
                sw.addFreshEntity(pearl);
            }
            pearlCd = PEARL_CD;
        } else if (amount > 6.0f && attacker != null) {
            // Обычный dodge назад
            Vec3 away = bot.position().subtract(attacker.position()).normalize();
            bot.setDeltaMovement(away.x * 0.7, 0.25, away.z * 0.7);
            // Меняем страф
            strafe.flipDirection();
        }
        dodgeCd = DODGE_CD;
    }

    // ════════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════════

    private void doAxeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.setShiftKeyDown(false);
        blockTimer = 0;
        if (!target.isAlive()) return;
        bot.doHurtTarget(sw, target);

        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY() + 1, target.getZ(), 8, 0.3, 0.3, 0.3, 0.12);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.85f);
            bot.getHeatMap().recordDamageDealt(bot.position(), 22f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY() + 1, target.getZ(), 4, 0.4, 0.2, 0.4, 0.05);
            bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
            bot.getHeatMap().recordDamageDealt(bot.position(), 14f);
        }

        hitCount++;
        critCounter++;
        attackCd = effectiveAxeCd();
        if (cfg.wTapEnabled) wTap.onAttack();
    }

    private int effectiveAxeCd() {
        return Math.max(AXE_CD_MIN, AXE_CD_BASE - escalateLevel);
    }

    private void eatGap(ServerLevel sw) {
        for (int i = 0; i < 9; i++) {
            var s = bot.getInventory().getItem(i);
            if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                bot.startUsingItem(net.minecraft.world.InteractionHand.MAIN_HAND);
                gapCd = GAP_CD;
                return;
            }
        }
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 1));
        gapCd = GAP_CD;
    }

    private int countNearbyEnemies(ServerLevel sw, LivingEntity primary) {
        return sw.getEntitiesOfClass(LivingEntity.class,
            new AABB(bot.position(), bot.position()).inflate(SWEEP_RADIUS),
            e -> e != bot && e.isAlive() && e != primary).size() + 1;
    }

    private List<LivingEntity> getNearbyEnemies(ServerLevel sw, LivingEntity primary) {
        List<LivingEntity> list = sw.getEntitiesOfClass(LivingEntity.class,
            new AABB(bot.position(), bot.position()).inflate(SWEEP_RADIUS),
            e -> e != bot && e.isAlive());
        if (!list.contains(primary)) list.add(0, primary);
        return list;
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled > 0) return false;
        var off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        var main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }

    private boolean isTargetSwinging(LivingEntity t) {
        return t.swingTime > 0 || t.isUsingItem();
    }

    private boolean isTargetInKnockback(LivingEntity t) {
        Vec3 v = t.getDeltaMovement();
        return Math.abs(v.x) > 0.35 || Math.abs(v.z) > 0.35 || v.y > 0.2;
    }

    private boolean hasValuableItem(LivingEntity t) {
        var main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return main.is(Items.NETHERITE_SWORD) || main.is(Items.DIAMOND_SWORD)
            || main.is(Items.BOW) || main.is(Items.CROSSBOW)
            || main.is(Items.NETHERITE_AXE) || main.is(Items.MACE);
    }

    private double dist(LivingEntity t) { return bot.distanceTo(t); }

    private void equipAxe() {
        var cur = bot.getItemBySlot(EquipmentSlot.MAINHAND);
        if (cur.is(Items.NETHERITE_AXE)) return;
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                .enchant("sharpness",5).enchant("efficiency",5)
                .enchant("unbreaking",3).enchant("mending",1).build());
    }

    private void equipShieldOffhand() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    private void syncPatternAI() {
        if (!cfg.patternAIEnabled || patternSyncCd > 0) { patternSyncCd--; return; }
        PatternAI pai = bot.getPatternAI();
        double absYaw = pai.getLearnedStrafeYaw(bot.getYRot(), strafe.isStrafeLeft());
        double neutral = strafe.isStrafeLeft() ? -90.0 : 90.0;
        strafe.setAdaptedYaw((float)(absYaw - neutral));
        patternSyncCd = 3;
    }

    public void reset() {
        phase = Phase.IDLE;
        attackCd = 0; shieldDisabled = 0; burstHits = 0; burstCd = 0;
        sweepCd = 0; xbowCd = 0; dashCd = 0; gapCd = 0;
        disarmCd = 0; dodgeCd = 0; pearlCd = 0;
        feintCd = 0; feintLookTimer = 0; blockTimer = 0;
        shieldSpamCd = 0; shieldSpamHits = 0; blockingTicks = 0;
        hitCount = 0; escalateLevel = 0; hitsWithoutBreak = 0; critCounter = 0;
        critPending = false; inBurst = false;
        wTap.reset();
    }

    public String getStateLabel() {
        return "AXE:" + switch (phase) {
            case IDLE         -> "FIGHT";
            case SHIELD_BREAK -> "SHBRK" + (escalateLevel > 0 ? "+"+escalateLevel : "");
            case BURST_SWORD  -> "BURST";
            case CRIT_JUMP    -> "CRIT!";
            case SWEEP        -> "SWEEP";
            case FEINT        -> "FEINT";
            case RETREAT      -> "BACK";
        };
    }
}
