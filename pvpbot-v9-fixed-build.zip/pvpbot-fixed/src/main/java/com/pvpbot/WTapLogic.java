package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * WTapLogic v4.0 — реалистичный W-tap с вариативным таймингом.
 *
 * Улучшения v4.0:
 *
 *  ── AI ──────────────────────────────────────────────────────────
 *   - Длина паузы W-tap теперь варьируется ±1 тик (было фиксировано 2)
 *     → враг не может preddict точный момент следующего удара
 *   - Страф во время паузы: угол страфа зависит от дистанции до цели
 *     (больше дистанция → больший угол страфа)
 *   - FakeSprint: длина 2-4 тика вместо фиксированных 3
 *   - Смена направления страфа: каждые 2-5 атак (Random, а не фиксированные 3)
 *
 *  ── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────
 *   - Нет new Vec3 в applyWtapStrafe — inline компонентный расчёт
 *   - tick() возвращает boolean (без лишних аллокаций)
 *
 *  ── КОД-КАЧЕСТВО ────────────────────────────────────────────────
 *   - Все magic-числа в private static final
 *   - resumeMovement() выделен в отдельный метод (убрано дублирование)
 *   - Состояние reset() очищает все поля корректно
 */
public class WTapLogic {

    // ── Константы ─────────────────────────────────────────────────
    // v5 BUFF: короче пауза = выше CPS, непредсказуемее тайминг
    private static final int   WTAP_STOP_MIN    = 1;   // без изменений
    private static final int   WTAP_STOP_MAX    = 2;   // было 3: короче максимальная пауза
    private static final int   STAP_EXTRA       = 1;
    private static final int   FAKE_SPRINT_MIN  = 1;   // было 2
    private static final int   FAKE_SPRINT_MAX  = 3;   // было 4
    private static final int   FLIP_MIN         = 1;   // было 2: чаще меняем страф
    private static final int   FLIP_MAX         = 4;   // было 5
    private static final double STRAFE_SPEED    = 0.11; // было 0.09: быстрее боковое движение
    private static final double FAKE_SPRINT_BOOST = 0.15; // было 0.12

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final BotEntity    bot;

    // ── Состояние ─────────────────────────────────────────────────
    private int     stopTimer      = 0;
    private boolean wasActive      = false;
    private boolean strafeLeft     = true;
    private int     attackCount    = 0;
    private int     nextFlipAt     = FLIP_MIN; // атак до следующей смены страфа
    private int     fakeSprintTimer = 0;

    public WTapLogic(BotEntity bot) {
        this.bot = bot;
        nextFlipAt = FLIP_MIN + bot.level().getRandom().nextInt(FLIP_MAX - FLIP_MIN + 1);
    }

    // ══════════════════════════════════════════════════════════════
    //  Вызвать ПОСЛЕ успешного удара
    // ══════════════════════════════════════════════════════════════
    public void onAttack() {
        if (!cfg.wTapEnabled) return;

        // Вариативная длина паузы: ±1 тик от базовой
        int base = WTAP_STOP_MIN + bot.level().getRandom().nextInt(WTAP_STOP_MAX - WTAP_STOP_MIN + 1);
        stopTimer = cfg.sTapEnabled ? base + STAP_EXTRA : base;

        bot.setSprinting(false);
        bot.getNavigation().stop();
        wasActive = true;

        // Смена направления: случайный интервал (не фиксированный)
        attackCount++;
        if (attackCount >= nextFlipAt) {
            strafeLeft = !strafeLeft;
            attackCount = 0;
            nextFlipAt = FLIP_MIN + bot.level().getRandom().nextInt(FLIP_MAX - FLIP_MIN + 1);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Тик W-tap. Возвращает true если W-tap активен.
    // ══════════════════════════════════════════════════════════════
    public boolean tick(LivingEntity target) {
        if (!cfg.wTapEnabled) {
            if (wasActive && target != null && target.isAlive()) resumeMovement(target);
            return false;
        }

        // ── FakeSprint-рывок после паузы ─────────────────────────
        if (fakeSprintTimer > 0) {
            fakeSprintTimer--;
            if (target != null && target.isAlive()) {
                Vec3 toTarget = target.position().subtract(bot.position()).normalize();
                bot.setDeltaMovement(bot.getDeltaMovement().add(
                    toTarget.x * FAKE_SPRINT_BOOST,
                    0,
                    toTarget.z * FAKE_SPRINT_BOOST
                ));
            }
            if (fakeSprintTimer <= 0 && target != null) {
                bot.getNavigation().moveTo(target, 1.1);
                bot.setSprinting(true);
                wasActive = false;
            }
            return true;
        }

        // ── Конец паузы ───────────────────────────────────────────
        if (stopTimer <= 0) {
            if (wasActive && target != null && target.isAlive()) {
                if (cfg.fakeSprint) {
                    // Вариативный FakeSprint
                    int fsTicks = FAKE_SPRINT_MIN + bot.level().getRandom().nextInt(
                        FAKE_SPRINT_MAX - FAKE_SPRINT_MIN + 1);
                    fakeSprintTimer = fsTicks;
                    bot.setSprinting(true);
                } else {
                    resumeMovement(target);
                }
            }
            return false;
        }

        // ── Активная пауза ────────────────────────────────────────
        stopTimer--;
        bot.getNavigation().stop();

        if (cfg.wTapStrafe && target != null && target.isAlive()) {
            applyWtapStrafe(target);
        }

        return true;
    }

    /**
     * Боковое смещение во время паузы.
     * Угол страфа зависит от дистанции (дальше → сильнее уход в сторону).
     *
     * FIX #6: добавлена проверка блоков перед стрейфом.
     * Раньше бот применял velocity в сторону без проверки — при паузе у стены
     * он "вибрировал" и застревал между блоком и setDeltaMovement.
     * Теперь: если сторона заблокирована → разворачиваем страф на 180°.
     */
    private void applyWtapStrafe(LivingEntity target) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();

        // Проверяем блок сбоку (1.2 блока в сторону страфа)
        double checkSx = strafeLeft ? -toTarget.z() : toTarget.z();
        double checkSz = strafeLeft ?  toTarget.x() : -toTarget.x();
        net.minecraft.core.BlockPos sidePos = net.minecraft.core.BlockPos.containing(
            bot.getX() + checkSx * 1.2,
            bot.getY() + 0.1,
            bot.getZ() + checkSz * 1.2
        );
        boolean sideBlocked = bot.level().getBlockState(sidePos).isSolid()
                           || bot.level().getBlockState(sidePos.above()).isSolid();

        if (sideBlocked) {
            // Стена с этой стороны — разворачиваем страф
            strafeLeft = !strafeLeft;
        }

        // Перпендикуляр: влево = (-tz, 0, tx), вправо = (tz, 0, -tx)
        double sx = strafeLeft ? -toTarget.z() : toTarget.z();
        double sz = strafeLeft ?  toTarget.x() : -toTarget.x();

        // Масштаб страфа: чуть больше на дальней дистанции
        double dist  = bot.distanceTo(target);
        double scale = STRAFE_SPEED * (1.0 + Math.min(dist / 10.0, 0.5));

        bot.setDeltaMovement(bot.getDeltaMovement().add(sx * scale, 0, sz * scale));
    }

    private void resumeMovement(LivingEntity target) {
        bot.getNavigation().moveTo(target, 1.1);
        bot.setSprinting(true);
        wasActive = false;
    }

    public boolean isActive() { return stopTimer > 0 || fakeSprintTimer > 0; }

    public void reset() {
        stopTimer       = 0;
        fakeSprintTimer = 0;
        wasActive       = false;
        attackCount     = 0;
        strafeLeft      = true;  // BUG FIX: strafeLeft не сбрасывался → состояние протекало между боями
        nextFlipAt      = FLIP_MIN + bot.level().getRandom().nextInt(FLIP_MAX - FLIP_MIN + 1);
    }
}
