package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * AutoPearl v13 — Pearl Kiting при критическом HP.
 *
 * Три режима:
 *   GAP_CLOSE   — бросок к цели когда она далеко и HP >= hp_min
 *   ESCAPE      — бросок «за спину» когда HP < escape_hp
 *   PEARL_KITE  — НОВЫЙ: при HP < pearlKiteHp бросает перл
 *                  в сторону (90° от цели) чтобы сбежать и переиграть
 *                  позицию, затем включает KiteLogic
 */
public class AutoPearl {

    public static final AutoPearl INSTANCE = new AutoPearl();

    private int cooldownTimer = 0;
    // Pearl Kite: после броска блокируем повторный кайт на N тиков
    private int kiteBlockTimer = 0;
    private static final int KITE_BLOCK_TICKS = 200; // 10 секунд

    private AutoPearl() {}

    public boolean tick(BotEntity bot) {
        if (bot == null || !PVPBotConfig.INSTANCE.autoPearlEnabled) return false;
        if (!(bot.level() instanceof ServerLevel sw)) return false;

        cooldownTimer--;
        if (cooldownTimer < 0) cooldownTimer = 0;
        if (kiteBlockTimer > 0) kiteBlockTimer--;
        if (cooldownTimer > 0) return false;

        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        double gapThresh = cfg.autoPearlGapThreshold;
        double hpMin     = cfg.autoPearlHpMin;
        double escapeHp  = cfg.autoPearlEscapeHp;
        int    cooldown  = cfg.autoPearlCooldown;

        int pearlSlot = findPearlSlot(bot);
        if (pearlSlot < 0) return false;

        float hp = bot.getHealth();

        // ── Pearl Kiting: HP критический — боковой бросок + кайтинг ─
        if (cfg.pearlKiteEnabled && hp < (float) cfg.pearlKiteHp
                && kiteBlockTimer <= 0) {
            LivingEntity target = findNearestEnemy(sw, bot);
            if (target != null) {
                Vec3 kitePos = kiteDirection(bot, target);
                spawnPearl(sw, bot, kitePos);
                kiteBlockTimer = KITE_BLOCK_TICKS;
                cooldownTimer  = cooldown;
                // Включаем кайт-режим чтобы бот перегруппировался
                bot.getPvpLogic().activateKiteMode(200);
                return true;
            }
        }

        // ESCAPE: бросаем перл за спину
        if ("escape".equals(cfg.autoPearlMode) && hp < (float) escapeHp) {
            spawnPearl(sw, bot, escapeDirection(bot));
            cooldownTimer = cooldown;
            return true;
        }

        // GAP_CLOSE: бросаем к цели
        if ("gap_close".equals(cfg.autoPearlMode) && hp >= (float) hpMin) {
            LivingEntity target = findNearestEnemy(sw, bot);
            if (target != null && bot.distanceTo(target) > gapThresh) {
                spawnPearl(sw, bot, target.getEyePosition());
                cooldownTimer = cooldown;
                return true;
            }
        }

        return false;
    }

    /** Точка для pearl kite: 45° вбок от линии бот→цель + 8 блоков назад */
    private Vec3 kiteDirection(BotEntity bot, LivingEntity target) {
        Vec3 toTarget = target.position().subtract(bot.position()).normalize();
        // 45° вбок + назад
        double angle = Math.PI * 0.75; // 135° — за спину с уклоном
        Vec3 escape = new Vec3(
            toTarget.x * Math.cos(angle) - toTarget.z * Math.sin(angle),
            0,
            toTarget.x * Math.sin(angle) + toTarget.z * Math.cos(angle)
        ).normalize();
        return bot.getEyePosition().add(escape.scale(14.0));
    }

    private int findPearlSlot(BotEntity bot) {
        if (bot.getMainHandItem().is(Items.ENDER_PEARL)) return 0;
        if (bot.getOffhandItem().is(Items.ENDER_PEARL)) return 1;
        return -1;
    }

    private LivingEntity findNearestEnemy(ServerLevel sw, BotEntity bot) {
        AABB box = bot.getBoundingBox().inflate(24.0);
        List<LivingEntity> entities = sw.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != bot && e.isAlive() && e instanceof Player
        );
        return entities.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);
    }

    private void spawnPearl(ServerLevel sw, BotEntity bot, Vec3 target) {
        bot.getMainHandItem().shrink(1);
        Vec3 eye  = bot.getEyePosition();
        Vec3 dir  = target.subtract(eye).normalize();
        double hD = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(dir.y, hD));

        net.minecraft.world.entity.projectile.ThrownEnderpearl pearl =
            new net.minecraft.world.entity.projectile.ThrownEnderpearl(
                net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        pearl.moveTo(eye.x, eye.y, eye.z, yaw, pitch);
        pearl.shootFromRotation(bot, pitch, yaw, 0.0f, 2.5f, 0.0f);
        sw.addFreshEntity(pearl);
    }

    private Vec3 escapeDirection(BotEntity bot) {
        Vec3 look = bot.getViewVector(1.0f);
        return bot.getEyePosition().add(look.scale(-12.0));
    }

    public boolean isKiteBlocked() { return kiteBlockTimer > 0; }
}
