package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * AutoRetreat v13 — УЛУЧШЕНО
 *
 * Исправления:
 *   - RETURN_HP_THRESHOLD: 16 → 12 (раньше возвращаемся в бой)
 *   - tickRetreating: zigzag-уклонение при побеге (не прямая линия)
 *   - tickHealing: Regen II + Absorption II сразу, а не по очереди
 *   - startRetreat: setSprinting(true) сразу
 *   - tickReturning: setSprinting(true) при возврате
 *   - Новый метод forceRetreat() для внешнего вызова (из CrystalBotLogic)
 *   - При побеге цель НЕ сбрасываем (bot.setTarget(null) убрано) — иначе
 *     ThreatAssessment теряет цель и при возврате надо заново искать
 */
public class AutoRetreat {

    public enum RetreatPhase { FIGHTING, RETREATING, HEALING, RETURNING }

    private static final float  RETREAT_HP_THRESHOLD = 7.0f;  // OPT v1.9: 6→7 (раньше убегаем)
    private static final float  RETURN_HP_THRESHOLD  = 14.0f; // OPT v1.9: 12→14 (здоровее возвращаемся)
    private static final double RETREAT_DISTANCE     = 12.0;
    private static final double RETREAT_SPEED        = 1.55;
    private static final int    HEAL_DURATION        = 50;    // FIX: было 60 — быстрее лечимся
    private static final int    RETREAT_COOLDOWN     = 180;   // FIX: было 200

    private RetreatPhase phase      = RetreatPhase.FIGHTING;
    private int          healTimer  = 0;
    private int          cooldown   = 0;
    private int          zigzagTimer = 0;
    private boolean      zigzagLeft  = true;

    private final BotEntity bot;

    public AutoRetreat(BotEntity bot) { this.bot = bot; }

    public RetreatPhase getPhase()  { return phase; }
    public boolean isRetreating()   { return phase != RetreatPhase.FIGHTING; }

    public void forceRetreat(LivingEntity target) {
        // FIX #1: retreatEnabled должен блокировать и принудительный retreat из CrystalBotLogic
        if (!PVPBotConfig.INSTANCE.retreatEnabled) return;
        if (phase == RetreatPhase.FIGHTING) startRetreat(target);
    }

    public boolean tick(LivingEntity target) {
        // FIX #1: Tank Mode блокирует retreat — бот не уходит лечиться в режиме танка
        if (PVPBotConfig.INSTANCE.tankModeEnabled) {
            phase = RetreatPhase.FIGHTING; // сбрасываем фазу, чтобы не зависнуть в HEALING
            return false;
        }
        if (cooldown > 0) cooldown--;
        return switch (phase) {
            case FIGHTING   -> tickFighting(target);
            case RETREATING -> tickRetreating(target);
            case HEALING    -> tickHealing(target);
            case RETURNING  -> tickReturning(target);
            default         -> false;
        };
    }

    private boolean tickFighting(LivingEntity target) {
        if (cooldown <= 0 && bot.getHealth() <= RETREAT_HP_THRESHOLD) {
            startRetreat(target);
            return true;
        }
        return false;
    }

    private boolean tickRetreating(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }

        double dist = bot.distanceTo(target);

        if (dist >= RETREAT_DISTANCE) {
            phase     = RetreatPhase.HEALING;
            healTimer = HEAL_DURATION;
            bot.getNavigation().stop();
            bot.setSprinting(false);
        } else {
            // FIX: zigzag-уклонение при побеге — не прямолинейно
            zigzagTimer--;
            if (zigzagTimer <= 0) {
                zigzagLeft  = !zigzagLeft;
                zigzagTimer = 6 + bot.level().getRandom().nextInt(6);
            }
            Vec3 away = bot.position().subtract(target.position()).normalize();
            Vec3 side = zigzagLeft
                ? new Vec3(-away.z, 0, away.x).scale(0.35)
                : new Vec3(away.z, 0, -away.x).scale(0.35);
            Vec3 dest = bot.position().add(away.scale(5)).add(side);
            bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, RETREAT_SPEED);
            // FIX: цель НЕ сбрасываем
        }
        return true;
    }

    private boolean tickHealing(LivingEntity target) {
        // FIX v1.3.9: если цель умерла пока мы лечимся — прекращаем retreat сразу,
        // не тратим healTimer тиков на лечение и не идём к трупу в RETURNING
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            healTimer = 0;
            return false;
        }
        healTimer--;
        useHealItem();
        if (healTimer <= 0 || bot.getHealth() >= RETURN_HP_THRESHOLD) {
            phase = RetreatPhase.RETURNING;
        }
        return true;
    }

    private boolean tickReturning(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }
        double dist = bot.distanceTo(target);
        if (dist <= PVPBotConfig.INSTANCE.attackRange + 1.0) {
            phase    = RetreatPhase.FIGHTING;
            cooldown = RETREAT_COOLDOWN;
            return false;
        }
        // FIX: спринт при возврате
        bot.getNavigation().moveTo(target, 1.4);
        bot.setSprinting(true);
        return true;
    }

    private void startRetreat(LivingEntity target) {
        phase       = RetreatPhase.RETREATING;
        zigzagTimer = 6;
        zigzagLeft  = bot.level().getRandom().nextBoolean();
        bot.setSprinting(true); // FIX: сразу спринт
    }

    private void useHealItem() {
        for (var slot : new net.minecraft.world.entity.EquipmentSlot[]{
                net.minecraft.world.entity.EquipmentSlot.MAINHAND,
                net.minecraft.world.entity.EquipmentSlot.OFFHAND}) {
            ItemStack stack = bot.getItemBySlot(slot);
            if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                bot.heal(8.0f);
                bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   2400, 3));
                bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION,  600, 1));
                stack.shrink(1);
                return;
            }
            if (stack.is(Items.GOLDEN_APPLE)) {
                bot.heal(4.0f);
                bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   2400, 0));
                bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION,  100, 1));
                stack.shrink(1);
                return;
            }
        }
        // FIX: Regen II + Absorption II одновременно (было только passive heal)
        if (bot.level() instanceof ServerLevel sw) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80,  1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   200, 1));
            sw.sendParticles(ParticleTypes.INSTANT_EFFECT,
                bot.getX(), bot.getY()+1, bot.getZ(), 6, 0.3,0.3,0.3,0.05);
        }
        float missing = bot.getMaxHealth() - bot.getHealth();
        bot.heal(Math.min(1.5f, missing * 0.07f)); // FIX: быстрее пассивное лечение
    }
}
