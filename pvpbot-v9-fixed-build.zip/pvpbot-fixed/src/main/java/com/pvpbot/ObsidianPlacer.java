package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;

/**
 * ObsidianPlacer v3.0 — CRYSTAL FIX
 *
 * Кладёт обсидиан СБОКУ от цели (не под ногами!).
 * Боковые позиции дают максимальный урон от взрыва кристалла.
 * За один тик — один блок (реалистично).
 * Приоритет: 4 кардинальных стороны → диагонали → центр.
 */
public class ObsidianPlacer {

    private int cd = 0;
    private static final int INTERVAL = 2; // тиков между укладкой (было 4)
    private static final double MAX_DIST = 7.0;

    // ИСПРАВЛЕНО: боковые позиции ПЕРВЫМИ (кристалл сбоку = максимальный урон)
    private static final int[] DX = { 1, -1,  0,  0,  1, -1,  1, -1,  0 };
    private static final int[] DZ = { 0,  0,  1, -1,  1, -1, -1,  1,  0 };

    public void tick(ServerLevel level, LivingEntity bot, LivingEntity target) {
        if (cd-- > 0) return;
        cd = INTERVAL;

        if (bot.position().distanceTo(target.position()) > MAX_DIST) return;

        // ИСПРАВЛЕНО: на уровне ног цели, кладём основание для кристалла сбоку
        BlockPos base = target.blockPosition();

        for (int i = 0; i < DX.length; i++) {
            BlockPos pos = base.offset(DX[i], -1, DZ[i]);
            var block = level.getBlockState(pos).getBlock();

            if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) continue;

            if (level.getBlockState(pos).isAir() || level.getBlockState(pos).canBeReplaced()) {
                level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), 3);
                return;
            }
        }
    }

    public static boolean hasBase(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition();
        for (int i = 0; i < DX.length; i++) {
            BlockPos pos = base.offset(DX[i], -1, DZ[i]);
            var b = level.getBlockState(pos).getBlock();
            if (b == Blocks.OBSIDIAN || b == Blocks.BEDROCK) return true;
        }
        return false;
    }

    public static BlockPos findCrystalBase(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition();
        int[] dx = { 1, -1,  0,  0,  1, -1,  1, -1,  0 };
        int[] dz = { 0,  0,  1, -1,  1, -1, -1,  1,  0 };
        for (int i = 0; i < dx.length; i++) {
            BlockPos obsPos   = base.offset(dx[i], -1, dz[i]);
            BlockPos placePos = obsPos.above();

            var b = level.getBlockState(obsPos).getBlock();
            if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) continue;
            if (!level.getBlockState(placePos).isAir()) continue;
            if (!level.getBlockState(placePos.above()).isAir()) continue;

            return obsPos;
        }
        return null;
    }
}
