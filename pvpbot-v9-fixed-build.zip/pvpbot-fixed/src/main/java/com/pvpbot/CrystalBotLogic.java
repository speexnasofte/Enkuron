package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * CrystalBotLogic v7.0 — CRYSTAL FIX
 *
 * Исправления v7:
 *   ✦ ObsidianPlacer теперь кладёт обсидиан СБОКУ от цели (не под ногами)
 *   ✦ OBS_NEEDED = 1 — ставим кристалл при первом же блоке обсидиана
 *   ✦ Все кулдауны уменьшены вдвое — цикл быстрее
 *   ✦ tickExplode взрывает при dist <= 7.0 с масштабированием урона
 *   ✦ ORBIT_CD = 6 (было 20) — орбита обновляется плавно
 *   ✦ RETREAT при HP < 6 (было 8), возврат при HP >= 10 (было 14)
 *   ✦ Меч KB толкает цель В СТОРОНУ кристалла (не от бота)
 */
public class CrystalBotLogic {

    private enum Phase { PLACE_OBS, PLACE_CRYS, EXPLODE, RETREAT }

    private final BotEntity    bot;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private final ObsidianPlacer obsidianPlacer = new ObsidianPlacer();

    private Phase phase = Phase.PLACE_OBS;

    private int obsTimer     = 0;
    private int placeTimer   = 0;
    private int explodeTimer = 0;
    private int swordTimer   = 0;
    private int pearlCd      = 0;
    private int gapCd        = 0;
    private int speedCd      = 0;
    private int positionTimer= 0;

    private EndCrystal placedCrystal  = null;
    private EndCrystal placedCrystal2 = null;
    private float      orbitAngle     = 0f;

    private static final double PLACE_RANGE  = 5.5;
    private static final double MELEE_RANGE  = 3.0;
    private static final double PEARL_RANGE  = 12.0;
    private static final double ORBIT_RADIUS = 3.5;
    private static final int    OBS_CD       = 1; // FIX: было 3
    private static final int    PLACE_CD     = 2; // FIX: было 4
    private static final int    EXPLODE_CD   = 2; // FIX: было 3
    private static final int    SWORD_CD     = 7;
    private static final int    PEARL_CD     = 80;
    private static final int    GAP_CD       = 220;
    private static final int    SPEED_CD     = 400;
    private static final int    OBS_NEEDED   = 1; // FIX: было 2 — теперь 1 блока достаточно
    private static final int    ORBIT_CD     = 6; // FIX: было 20 — орбита плавная

    public CrystalBotLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(ServerLevel sw, LivingEntity target) {
        if (sw == null || target == null || !target.isAlive()) return;

        if (obsTimer     > 0) obsTimer--;
        if (placeTimer   > 0) placeTimer--;
        if (explodeTimer > 0) explodeTimer--;
        if (swordTimer   > 0) swordTimer--;
        if (pearlCd      > 0) pearlCd--;
        if (gapCd        > 0) gapCd--;
        if (speedCd      > 0) speedCd--;
        if (positionTimer> 0) positionTimer--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }

        // FIX: отступаем позже (6 вместо 8) — больше агрессии
        if (myHp < 6.0f) phase = Phase.RETREAT;

        switch (phase) {
            case RETREAT    -> tickRetreat(sw, target, dist, myHp);
            case PLACE_OBS  -> tickPlaceObs(sw, target, dist);
            case PLACE_CRYS -> tickPlaceCrys(sw, target);
            case EXPLODE    -> tickExplode(sw, target);
        }

        if (phase != Phase.RETREAT) updateOrbit(target, dist);

        // Меч KB1 — толкаем цель К ближайшему кристаллу
        if (dist <= MELEE_RANGE && swordTimer <= 0 && phase == Phase.EXPLODE) {
            AABB searchBox = target.getBoundingBox().inflate(8.0);
            List<EndCrystal> crystals = sw.getEntitiesOfClass(EndCrystal.class, searchBox, e -> true);
            Vec3 pushDir;
            if (!crystals.isEmpty()) {
                // FIX: толкаем К кристаллу, а не от бота
                EndCrystal nearest = crystals.stream()
                    .min(Comparator.comparingDouble(c -> c.distanceToSqr(target)))
                    .orElse(null);
                if (nearest != null) {
                    pushDir = nearest.position().subtract(target.position()).normalize();
                } else {
                    pushDir = target.position().subtract(bot.position()).normalize();
                }
            } else {
                pushDir = target.position().subtract(bot.position()).normalize();
            }
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            target.setDeltaMovement(target.getDeltaMovement().add(pushDir.x * 0.9, 0.25, pushDir.z * 0.9));
            swordTimer = SWORD_CD;
        }
    }

    private void updateOrbit(LivingEntity target, double dist) {
        if (positionTimer > 0) return;
        orbitAngle += (float)(Math.PI * 0.4);
        positionTimer = ORBIT_CD;

        if (dist > PLACE_RANGE + 0.5) {
            bot.getNavigation().moveTo(target, 1.1);
        } else if (dist < ORBIT_RADIUS - 0.5) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 3, bot.getY(), bot.getZ() + away.z * 3, 1.1);
        } else {
            double tx = target.getX() + Math.cos(orbitAngle) * ORBIT_RADIUS;
            double tz = target.getZ() + Math.sin(orbitAngle) * ORBIT_RADIUS;
            bot.getNavigation().moveTo(tx, target.getY(), tz, 1.05);
        }
    }

    private void tickRetreat(ServerLevel sw, LivingEntity target, double dist, float myHp) {
        if (gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
        }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 8, bot.getY(), bot.getZ() + away.z * 8, 1.2);
        if (dist < 5.0 && pearlCd <= 0) {
            Vec3 dest = bot.position().add(away.scale(12));
            bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.5);
            sw.sendParticles(ParticleTypes.PORTAL, bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
        }
        // FIX: возвращаемся раньше (10 вместо 14)
        if (myHp >= 10.0f) phase = Phase.PLACE_OBS;
    }

    private void tickPlaceObs(ServerLevel sw, LivingEntity target, double dist) {
        if (obsTimer > 0) return;
        if (dist > PEARL_RANGE && pearlCd <= 0) {
            bot.setSprinting(true);
            bot.getNavigation().moveTo(target, 1.6);
            sw.sendParticles(ParticleTypes.PORTAL, bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
            return;
        }
        obsidianPlacer.tick(sw, bot, target);
        obsTimer = OBS_CD;
        if (countObsidianNear(sw, target) >= OBS_NEEDED) {
            phase = Phase.PLACE_CRYS;
            log("§e[Crystal] Обсидиан готов → ставим кристалл");
        }
    }

    private void tickPlaceCrys(ServerLevel sw, LivingEntity target) {
        if (placeTimer > 0) return;
        BlockPos obsPos = ObsidianPlacer.findCrystalBase(sw, target);
        if (obsPos == null) { phase = Phase.PLACE_OBS; return; }

        EndCrystal c1 = spawnCrystal(sw, obsPos.above());
        if (c1 != null) placedCrystal = c1;

        for (BlockPos nb : new BlockPos[]{obsPos.north(), obsPos.south(), obsPos.east(), obsPos.west()}) {
            if (sw.getBlockState(nb).getBlock() == Blocks.OBSIDIAN) {
                EndCrystal c2 = spawnCrystal(sw, nb.above());
                if (c2 != null) { placedCrystal2 = c2; break; }
            }
        }

        placeTimer = PLACE_CD;
        phase = Phase.EXPLODE;
        log("§a[Crystal] Кристалл(ы) поставлены → взрываем!");
    }

    private EndCrystal spawnCrystal(ServerLevel sw, BlockPos pos) {
        if (!sw.getBlockState(pos).isAir() || !sw.getBlockState(pos.above()).isAir()) return null;
        EndCrystal c = EntityType.END_CRYSTAL.create(sw, EntitySpawnReason.TRIGGERED);
        if (c == null) return null;
        c.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        c.setBeamTarget(null);
        sw.addFreshEntity(c);
        return c;
    }

    private void tickExplode(ServerLevel sw, LivingEntity target) {
        if (explodeTimer > 0) return;

        AABB searchBox = target.getBoundingBox().inflate(cfg.crystalPlaceRange + 2.0);
        List<EndCrystal> crystals = sw.getEntitiesOfClass(EndCrystal.class, searchBox, e -> true);

        if (crystals.isEmpty()) { phase = Phase.PLACE_OBS; return; }

        EndCrystal best = crystals.stream()
            .min(Comparator.comparingDouble(c -> c.distanceToSqr(target)))
            .orElse(null);
        if (best == null) { phase = Phase.PLACE_OBS; return; }

        double crystalDist = best.distanceTo(target);

        // FIX: взрываем при dist <= 7.0 с масштабированием урона по расстоянию
        // Не ждём когда цель сама подойдёт!
        if (crystalDist <= 7.0) {
            boolean inAir  = !target.onGround();
            float   damage = (float) cfg.diffCrystalDamage * (inAir ? 1.5f : 1.0f);
            // Масштаб урона по расстоянию (ближе = больно)
            float scaledDmg = damage * (float) Math.max(0.15, (7.0 - crystalDist) / 5.5);

            if (scaledDmg > 1.0f && target.isAlive())
                target.hurt(sw.damageSources().explosion(bot, bot), scaledDmg);

            Vec3 kb = target.position().subtract(best.position()).normalize().scale(1.4);
            target.setDeltaMovement(target.getDeltaMovement().add(kb.x, 0.7, kb.z));
            best.discard();
            placedCrystal = null;

            if (placedCrystal2 != null && !placedCrystal2.isRemoved()) {
                double d2 = placedCrystal2.distanceTo(target);
                if (d2 <= 7.0 && target.isAlive()) {
                    float scaledDmg2 = damage * 0.8f * (float) Math.max(0.15, (7.0 - d2) / 5.5);
                    target.hurt(sw.damageSources().explosion(bot, bot), scaledDmg2);
                }
                placedCrystal2.discard();
                placedCrystal2 = null;
            }

            sw.sendParticles(ParticleTypes.EXPLOSION, best.getX(), best.getY(), best.getZ(), 6, 0.8,0.8,0.8,0.1);
            bot.playSound(SoundEvents.GENERIC_EXPLODE.value(), 1.5f, 1.0f);

            log(String.format("§c[Crystal] BOOM! §e%.1f урона §7(dist=%.1f, %s)",
                scaledDmg, crystalDist, inAir ? "+50% воздух" : "земля"));
        }

        explodeTimer = EXPLODE_CD;
        phase = Phase.PLACE_OBS;
    }

    private int countObsidianNear(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition();
        int count = 0;
        int[] dx = { 1, -1,  0,  0,  1, -1,  1, -1,  0 };
        int[] dz = { 0,  0,  1, -1,  1, -1, -1,  1,  0 };
        for (int i = 0; i < dx.length; i++) {
            var b = level.getBlockState(base.offset(dx[i], -1, dz[i])).getBlock();
            if (b == Blocks.OBSIDIAN || b == net.minecraft.world.level.block.Blocks.BEDROCK) count++;
        }
        return count;
    }

    private void log(String msg) {
        if (bot.getOwner() instanceof ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    public String getPhaseLabel() {
        return switch (phase) {
            case PLACE_OBS  -> "CRYS:OBS";
            case PLACE_CRYS -> "CRYS:PLACE";
            case EXPLODE    -> "CRYS:BOOM!";
            case RETREAT    -> "CRYS:FLEE";
        };
    }
}
