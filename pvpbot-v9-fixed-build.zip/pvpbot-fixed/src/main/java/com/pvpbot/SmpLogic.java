package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;

/**
 * SmpLogic v8.0 — PATCH
 *
 * Улучшения v8 (patch):
 *  ✦ Авто-щит в offhand между ударами (как SwordLogic) — блокируем при swinging цели
 *  ✦ Burst 4 удара мечом после слома щита топором
 *  ✦ RETREAT_HP 5→8: отступаем раньше, не умирая
 *  ✦ Pearl: бросаем при dist > 8 (было > 12) + настоящее упреждение PatternAI
 *  ✦ Slowness combo: при dist < 4 бросаем Slowness I перед атакой
 *
 * Улучшения v7:
 *  ✦ Три режима атаки: SWORD_DPS / AXE_SHIELD_BREAK / BOW_RANGE с плавным переходом
 *  ✦ Combo-система: 3 удара мечом → топор → 2 удара мечом → repeat
 *  ✦ Adaptive retreat: бот не бежит сразу — сначала поднимает щит и пятится
 *  ✦ Pearl predict: жемчуг бросается НА ПРЕДСКАЗАННУЮ позицию (PatternAI)
 *  ✦ Bow leading shot: упреждение с учётом скорости цели
 *  ✦ Auto-gap: гэпл при < GAP_HP, но ждёт паузы в бою (не тратит кулдаун впустую)
 *  ✦ Fire aspect: поджигаем — цель теряет концентрацию и регены
 *  ✦ Knockback стрейф: после удара страфимся AWAY от цели на 2 тика (w-tap improved)
 *  ✦ HeatMap интеграция: записываем урон по позиции
 */
public class SmpLogic {

    // ── Дальности ─────────────────────────────────────────────────
    private static final double MELEE_RANGE  = 3.0;
    private static final double AXE_RANGE    = 3.5;
    private static final double BOW_RANGE    = 9.0;
    private static final double PEARL_RANGE  = 12.0;
    private static final double IDEAL_DIST   = 2.6;
    private static final double SHIELD_DIST  = 4.5;

    // ── HP пороги ─────────────────────────────────────────────────
    private static final float  GAP_HP       = 14.0f;
    private static final float  SHIELD_HP    = 12.0f;

    // ── Кулдауны ──────────────────────────────────────────────────
    private static final int    ATTACK_CD    = 7;
    private static final int    AXE_CD       = 17;
    private static final int    BOW_CD       = 16;
    private static final int    GAP_CD       = 160;
    private static final int    PEARL_CD     = 75;
    private static final int    SPEED_CD     = 400;
    private static final int    STR_CD       = 400;
    private static final int    FIRE_RES_CD  = 600;
    private static final int    RETREAT_CD   = 80;
    private static final int    SHIELD_DUR   = 15;
    // PATCH v8: новые константы
    private static final float  RETREAT_HP   = 8.0f;   // было 5 — теперь отступаем раньше
    private static final int    BURST_COUNT  = 4;       // удары мечом после слома щита
    private static final int    BURST_CD_VAL = 5;       // тиков между burst ударами
    private static final int    SHIELD_SWING_CD = 30;   // кд авто-щита при swinging
    private static final int    SLOWNESS_CD  = 60;      // кд зелья замедления
    private static final double PEARL_THROW_RANGE = 8.0; // бросаем жемчуг раньше

    // ── Combo ─────────────────────────────────────────────────────
    private static final int    CRIT_EVERY      = 3;   // каждый N-й — крит
    private static final int    AXE_AT_COMBO    = 3;   // топор после 3 ударов мечом

    private enum State { FIGHTING, SHIELDING, RETREATING }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final WTapLogic    wTap;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd     = 0, axeCd = 0, bowCd = 0;
    private int shieldTimer  = 0, gapCd = 0, pearlCd = 0;
    private int speedCd      = 0, strCd = 0, fireResCd = 0, retreatCd = 0;
    private int hitCount     = 0, comboCount = 0;
    private boolean critPending    = false;
    private boolean shieldDisabled = false;
    private int shieldDisTimer     = 0;
    private int zigzagTimer        = 0;
    private boolean zigzagLeft     = true;
    private int tickCount          = 0;
    private float lastReceivedDmg  = 0;
    private int   lastDamageTick   = 0;
    // Knockback-страф после удара
    private int kbStrafeTimer      = 0;
    // PATCH v8: burst после слома щита
    private boolean inBurst        = false;
    private int     burstHits      = 0;
    private int     burstCd        = 0;
    // PATCH v8: авто-щит при swinging
    private int shieldSwingCd      = 0;
    // PATCH v8: зелье замедления
    private int slownessCd         = 0;

    public SmpLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        this.wTap   = new WTapLogic(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void onDamageReceived(float amount) {
        lastReceivedDmg  = amount;
        lastDamageTick   = tickCount;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        tickCount++;

        // ── Кулдауны ─────────────────────────────────────────────
        if (attackCd     > 0) attackCd--;
        if (axeCd        > 0) axeCd--;
        if (bowCd        > 0) bowCd--;
        if (shieldTimer  > 0) shieldTimer--;
        if (gapCd        > 0) gapCd--;
        if (pearlCd      > 0) pearlCd--;
        if (speedCd      > 0) speedCd--;
        if (strCd        > 0) strCd--;
        if (fireResCd    > 0) fireResCd--;
        if (retreatCd    > 0) retreatCd--;
        if (zigzagTimer  > 0) zigzagTimer--;
        if (kbStrafeTimer> 0) kbStrafeTimer--;
        if (shieldDisTimer > 0) { shieldDisTimer--; if (shieldDisTimer <= 0) shieldDisabled = false; }
        if (burstCd        > 0) burstCd--;
        if (shieldSwingCd  > 0) shieldSwingCd--;
        if (slownessCd     > 0) slownessCd--;

        // ── Тотем всегда ─────────────────────────────────────────
        ensureTotem();

        // ── Баффы всегда ─────────────────────────────────────────
        if (speedCd <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1)); speedCd = SPEED_CD; }
        if (strCd   <= 0) { bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,   800, 1)); strCd   = STR_CD; }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }
        if (bot.isInWater() && !bot.onGround())
            bot.setDeltaMovement(bot.getDeltaMovement().x, 0.12, bot.getDeltaMovement().z);

        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Гэпл: ждём паузы между ударами (не тратим впустую) ──
        if (myHp < GAP_HP && gapCd <= 0 && attackCd > 3) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 1));
            gapCd = GAP_CD;
            if (state == State.RETREATING) state = State.FIGHTING;
        }

        // ── Жемчуг: бросаем на ПРЕДСКАЗАННУЮ позицию ────────────
        if (cfg.pearlEnabled && dist > PEARL_THROW_RANGE && pearlCd <= 0) {
            Vec3 predicted = bot.getPatternAI() != null
                ? bot.getPatternAI().getPredictedPosition(target)
                : target.position();
            bot.getNavigation().moveTo(predicted.x, predicted.y, predicted.z, 1.5);
            bot.setSprinting(true);
            pearlCd = PEARL_CD;
            return;
        }

        // PATCH v8: Авто-щит при swinging цели (как SwordLogic)
        if (shieldSwingCd <= 0 && dist < 4.5 && target.swinging) {
            ensureOffhandShield();
            bot.setShiftKeyDown(true);
            shieldSwingCd = SHIELD_SWING_CD;
        } else if (shieldSwingCd <= 0 && !inBurst) {
            bot.setShiftKeyDown(false);
        }

        // PATCH v8: Зелье замедления комбо в ближнем бою
        if (slownessCd <= 0 && dist < 4.0 && state == State.FIGHTING) {
            bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
            slownessCd = SLOWNESS_CD;
        }

        // ── Переходы состояний ───────────────────────────────────
        boolean recentDmg = (tickCount - lastDamageTick) < 30;
        if (myHp < RETREAT_HP && retreatCd <= 0 && recentDmg) {
            state = State.RETREATING;
            retreatCd = RETREAT_CD;
            zigzagLeft = bot.level().getRandom().nextBoolean();
        }
        if (myHp < SHIELD_HP && myHp >= RETREAT_HP && shieldTimer <= 0 && state == State.FIGHTING) {
            state = State.SHIELDING;
            shieldTimer = SHIELD_DUR;
            strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        }
        // Быстрый выход из SHIELDING если щит цели сломан или щит истёк
        if (state == State.SHIELDING && (shieldTimer <= 0 || shieldDisabled)) {
            state = State.FIGHTING;
            strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
        }
        // Выход из RETREATING
        if (state == State.RETREATING && (dist > 10.0 || myHp > SHIELD_HP)) {
            state = State.FIGHTING;
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);

        switch (state) {
            case FIGHTING   -> tickFighting(sw, target, dist);
            case SHIELDING  -> tickShielding(sw, target);
            case RETREATING -> tickRetreating(target);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  FIGHTING — основная фаза
    // ════════════════════════════════════════════════════════════

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        boolean wTapActive = wTap.tick(target);
        boolean blocking   = isTargetBlocking(target);

        // KnockbackСтрейф: 2 тика после удара не двигаемся к цели
        if (kbStrafeTimer > 0) {
            strafe.tick(target);
            return;
        }

        // Навигация
        if (!wTapActive) {
            if (dist > IDEAL_DIST + 1.0)      bot.getNavigation().moveTo(target, 1.1);
            else if (dist < IDEAL_DIST - 0.5) bot.getNavigation().stop();
        }

        // Страф если в ближнем бою
        if (!wTapActive && dist < MELEE_RANGE + 2.5 && cfg.strafeEnabled) strafe.tick(target);

        // ── Лук на дистанции (leading shot) ─────────────────────
        if (dist > BOW_RANGE && bowCd <= 0) {
            doLeadingBowShot(sw, target, dist);
            return;
        }

        // ── Combo: 3 меча → топор ────────────────────────────────
        if (comboCount >= AXE_AT_COMBO && dist <= AXE_RANGE && axeCd <= 0 && !wTapActive) {
            doAxeHit(sw, target);
            comboCount = 0;
            return;
        }

        // ── Топор для слома щита → burst ─────────────────────────
        if (blocking && dist <= AXE_RANGE && axeCd <= 0 && !wTapActive) {
            doAxeHit(sw, target);
            // PATCH v8: сразу начинаем burst после слома щита
            inBurst = true; burstHits = 0;
            bot.setShiftKeyDown(false); // снимаем блок
            return;
        }

        // PATCH v8: burst 4 удара мечом после слома щита
        if (inBurst && burstCd <= 0 && !blocking) {
            if (burstHits < BURST_COUNT && dist <= MELEE_RANGE) {
                doSwordHit(sw, target, false);
                burstCd = BURST_CD_VAL; burstHits++;
                return;
            } else {
                inBurst = false;
            }
        }

        // ── Меч DPS с критами ─────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0 && !wTapActive) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doSwordHit(sw, target, true);
                critPending = false;
            } else if (!doCrit && !critPending) {
                doSwordHit(sw, target, false);
            }
        }
    }

    // ════════════════════════════════════════════════════════════
    //  Удары
    // ════════════════════════════════════════════════════════════

    private void doSwordHit(ServerLevel sw, LivingEntity target, boolean crit) {
        equipSword();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        if (target.getRemainingFireTicks() <= 0) target.setRemainingFireTicks(80); // Fire Aspect
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+0.8, target.getZ(), 8, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }
        hitCount++;
        comboCount++;
        attackCd = cfg.adaptiveCooldownEnabled ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
        kbStrafeTimer = 2; // KB-страф после удара
        // HeatMap
        bot.getHeatMap().recordDamageDealt(bot.position(), getBaseDmg());
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target) {
        equipAxe();
        if (target.isAlive()) bot.doHurtTarget(sw, target);
        shieldDisabled = true;
        shieldDisTimer = 100;
        sw.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY()+1, target.getZ(), 5, 0.4,0.2,0.4,0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        axeCd = AXE_CD;
        if (cfg.wTapEnabled) wTap.onAttack();
        kbStrafeTimer = 2;
        bot.getHeatMap().recordDamageDealt(bot.position(), 14f); // топор ~14 урона
    }

    /** Лук с упреждением на скорость цели. */
    private void doLeadingBowShot(ServerLevel sw, LivingEntity target, double dist) {
        // Время полёта стрелы ~0.5 сек на 9 блоков
        float flightTicks = (float)(dist / 18.0 * 20);
        Vec3  vel         = target.getDeltaMovement();
        Vec3  predicted   = target.position().add(vel.scale(flightTicks));
        double actualDist = bot.position().distanceTo(predicted);
        float  damage     = (float) Math.max(2.0, 9.5 - actualDist * 0.3);

        equipBow();
        bot.getLookControl().setLookAt(predicted.x, predicted.y + 1, predicted.z, 60f, 60f);
        if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), damage);
        sw.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY()+1, target.getZ(), 4, 0.2,0.2,0.2,0.1);
        bot.playSound(SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
        HitHighlightTracker.INSTANCE.onHit(target.getId());
        bowCd = BOW_CD;
    }

    // ════════════════════════════════════════════════════════════
    //  SHIELDING — пассивный блок + подотступление
    // ════════════════════════════════════════════════════════════

    private void tickShielding(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.SHIELD));
        double dist = bot.distanceTo(target);
        if (dist < SHIELD_DIST) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 4, bot.getY(), bot.getZ() + away.z * 4, 1.1);
        }
        if (cfg.strafeEnabled) strafe.tick(target);
    }

    // ════════════════════════════════════════════════════════════
    //  RETREATING — zigzag-побег
    // ════════════════════════════════════════════════════════════

    private void tickRetreating(LivingEntity target) {
        if (zigzagTimer <= 0) {
            zigzagLeft  = !zigzagLeft;
            zigzagTimer = 5 + bot.level().getRandom().nextInt(6);
        }
        Vec3 away = bot.position().subtract(target.position()).normalize();
        Vec3 side = zigzagLeft
            ? new Vec3(-away.z, 0, away.x).scale(0.5)
            : new Vec3( away.z, 0,-away.x).scale(0.5);
        Vec3 dest = bot.position().add(away.scale(10)).add(side);
        bot.getNavigation().moveTo(dest.x, bot.getY(), dest.z, 1.3);
        bot.setSprinting(true);
    }

    // ════════════════════════════════════════════════════════════
    //  Утилиты
    // ════════════════════════════════════════════════════════════

    private void equipSword() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_SWORD, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("knockback", 2)
                .enchant("fire_aspect", 2).enchant("unbreaking", 3).build());
    }

    private void equipAxe() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_AXE, bot.level().registryAccess())
                .enchant("sharpness", 5).enchant("efficiency", 5)
                .enchant("unbreaking", 3).build());
    }

    private void equipBow() {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.BOW, bot.level().registryAccess())
                .enchant("power", 5).enchant("infinity", 1).enchant("punch", 2).build());
    }

    private void ensureTotem() {
        // PATCH v8: если не в режиме щита — восстанавливаем тотем в offhand
        if (!bot.isShiftKeyDown() && !inBurst) {
            if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }
    }

    // PATCH v8: ставим щит в offhand для блока
    private void ensureOffhandShield() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }

    private float getBaseDmg() {
        return 9.5f; // Netherite sword + Sharpness 5
    }
}
