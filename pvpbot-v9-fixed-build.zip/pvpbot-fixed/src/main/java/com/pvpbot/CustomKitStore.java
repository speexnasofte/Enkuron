package com.pvpbot;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.world.item.ItemStack;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * CustomKitStore v1.0 — Персистентное хранение кастомных китов между перезапусками.
 *
 * Файлы: .minecraft/config/pvpbot_custom_kits/<uuid>/<kitname>.dat
 *
 * Формат: NBT-бинарные файлы (как Minecraft хранит предметы нативно).
 * Каждый кит = 41 ItemStack (36 инвентарь + 4 броня + 1 оффхенд).
 *
 * API:
 *   save(uuid, name, snapshot)  — сохранить кит на диск
 *   load(uuid, name)            — загрузить кит с диска
 *   delete(uuid, name)          — удалить кит
 *   rename(uuid, oldName, newName) — переименовать кит
 *   list(uuid)                  — список имён китов игрока
 */
public class CustomKitStore {

    private static final Path BASE_DIR =
        FabricLoader.getInstance().getConfigDir().resolve("pvpbot_custom_kits");

    // ─── In-memory cache: uuid:name → snapshot ────────────────────
    private static final Map<String, List<ItemStack>> cache = new HashMap<>();

    /** Загружает все киты с диска в кэш. Вызывать при старте сервера. */
    public static void loadAll() {
        cache.clear();
        if (!Files.exists(BASE_DIR)) return;
        try {
            Files.walk(BASE_DIR, 2)
                .filter(p -> p.toString().endsWith(".dat"))
                .forEach(p -> {
                    // Структура: BASE_DIR/<uuid>/<name>.dat
                    String uuid    = p.getParent().getFileName().toString();
                    String name    = p.getFileName().toString().replace(".dat", "");
                    String cacheKey = uuid + ":" + name;
                    try {
                        List<ItemStack> items = readFromDisk(p);
                        if (items != null) cache.put(cacheKey, items);
                    } catch (Exception e) {
                        System.err.println("[PVPBot] Не удалось загрузить кит " + cacheKey + ": " + e.getMessage());
                    }
                });
        } catch (IOException e) {
            System.err.println("[PVPBot] Ошибка загрузки кастомных китов: " + e.getMessage());
        }
    }

    /** Сохраняет кит в кэш и на диск. */
    public static boolean save(UUID playerUuid, String name, List<ItemStack> snapshot, RegistryAccess ra) {
        String key = playerUuid + ":" + name.toLowerCase();
        cache.put(key, snapshot);
        return writeToDisk(playerUuid, name.toLowerCase(), snapshot, ra);
    }

    /** Возвращает кит из кэша или null если не найден. */
    public static List<ItemStack> load(UUID playerUuid, String name) {
        return cache.get(playerUuid + ":" + name.toLowerCase());
    }

    /**
     * v1.5.0 — Поиск кита по имени среди ВСЕХ игроков (для спавн-кита по умолчанию).
     * Возвращает первый кит с таким именем или null.
     */
    public static List<ItemStack> getKit(String name) {
        String suffix = ":" + name.toLowerCase();
        return cache.entrySet().stream()
            .filter(e -> e.getKey().endsWith(suffix))
            .map(Map.Entry::getValue)
            .findFirst()
            .orElse(null);
    }

    /** Удаляет кит из кэша и с диска. */
    public static boolean delete(UUID playerUuid, String name) {
        String key = playerUuid + ":" + name.toLowerCase();
        cache.remove(key);
        Path file = kitPath(playerUuid, name.toLowerCase());
        try {
            Files.deleteIfExists(file);
            return true;
        } catch (IOException e) {
            System.err.println("[PVPBot] Не удалось удалить кит: " + e.getMessage());
            return false;
        }
    }

    /** Переименовывает кит (копирует данные под новым именем, удаляет старый). */
    public static boolean rename(UUID playerUuid, String oldName, String newName, RegistryAccess ra) {
        List<ItemStack> snapshot = load(playerUuid, oldName);
        if (snapshot == null) return false;
        if (save(playerUuid, newName, snapshot, ra)) {
            delete(playerUuid, oldName);
            return true;
        }
        return false;
    }

    /** Возвращает список имён кастомных китов игрока. */
    public static List<String> list(UUID playerUuid) {
        String prefix = playerUuid + ":";
        List<String> result = new ArrayList<>();
        for (String key : cache.keySet()) {
            if (key.startsWith(prefix)) result.add(key.substring(prefix.length()));
        }
        Collections.sort(result);
        return result;
    }

    // ─── Приватные методы ─────────────────────────────────────────

    private static Path kitPath(UUID uuid, String name) {
        return BASE_DIR.resolve(uuid.toString()).resolve(
            name.replaceAll("[^a-zA-Z0-9_\\-]", "_") + ".dat");
    }

    private static boolean writeToDisk(UUID uuid, String name, List<ItemStack> snapshot, RegistryAccess ra) {
        try {
            Path dir = BASE_DIR.resolve(uuid.toString());
            Files.createDirectories(dir);
            Path file = dir.resolve(name.replaceAll("[^a-zA-Z0-9_\\-]", "_") + ".dat");

            CompoundTag root = new CompoundTag();
            root.putInt("Version", 1);
            root.putInt("Size", snapshot.size());

            for (int i = 0; i < snapshot.size(); i++) {
                ItemStack stack = snapshot.get(i);
                if (!stack.isEmpty()) {
                    CompoundTag tag = (CompoundTag) stack.save(ra);
                    root.put("slot_" + i, tag);
                }
            }

            try (DataOutputStream dos = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(file)))) {
                NbtIo.writeCompressed(root, dos);
            }
            return true;
        } catch (Exception e) {
            System.err.println("[PVPBot] Не удалось записать кит: " + e.getMessage());
            return false;
        }
    }

    private static List<ItemStack> readFromDisk(Path file) throws Exception {
        CompoundTag root;
        try (DataInputStream dis = new DataInputStream(
                new BufferedInputStream(Files.newInputStream(file)))) {
            root = NbtIo.readCompressed(dis, NbtAccounter.unlimitedHeap());
        }
        int size = root.contains("Size") ? root.getInt("Size") : 41;
        List<ItemStack> result = new ArrayList<>(Collections.nCopies(size, ItemStack.EMPTY));
        for (int i = 0; i < size; i++) {
            String key = "slot_" + i;
            if (root.contains(key, 10)) { // 10 = TAG_Compound
                // ItemStack.parse требует RegistryAccess — откладываем до момента использования
                // Сохраняем как CompoundTag для ленивой десериализации
                // NOTE: Полная десериализация происходит при первом использовании кита
                // Здесь просто помечаем что слот не пустой (пустой ItemStack.EMPTY)
                result.set(i, ItemStack.EMPTY); // будет загружен при использовании
            }
        }
        // Возвращаем список — фактическая загрузка с ra происходит в loadWithRegistry
        return result;
    }

    /**
     * Загружает кит с диска с RegistryAccess для десериализации предметов.
     * Используется при первом применении кита.
     */
    public static List<ItemStack> loadWithRegistry(UUID playerUuid, String name, RegistryAccess ra) {
        String key = playerUuid + ":" + name.toLowerCase();
        // Если в кэше уже полные стеки (сохранены в этой сессии) — возвращаем их
        List<ItemStack> cached = cache.get(key);
        if (cached != null && cached.stream().anyMatch(s -> !s.isEmpty())) {
            return cached;
        }

        // Читаем с диска напрямую с ra
        Path file = kitPath(playerUuid, name.toLowerCase());
        if (!Files.exists(file)) return null;
        try {
            CompoundTag root;
            try (DataInputStream dis = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(file)))) {
                root = NbtIo.readCompressed(dis, NbtAccounter.unlimitedHeap());
            }
            int size = root.contains("Size") ? root.getInt("Size") : 41;
            List<ItemStack> result = new ArrayList<>(Collections.nCopies(size, ItemStack.EMPTY));
            for (int i = 0; i < size; i++) {
                String slotKey = "slot_" + i;
                if (root.contains(slotKey, 10)) {
                    ItemStack stack = ItemStack.parseOptional(ra, root.getCompound(slotKey));
                    result.set(i, stack);
                }
            }
            cache.put(key, result); // обновляем кэш полными стеками
            return result;
        } catch (Exception e) {
            System.err.println("[PVPBot] Не удалось прочитать кит " + name + ": " + e.getMessage());
            return null;
        }
    }
}
