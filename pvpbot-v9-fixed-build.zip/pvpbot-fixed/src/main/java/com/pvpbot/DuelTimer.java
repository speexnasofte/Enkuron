package com.pvpbot;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * DuelTimer v3.0 — MCTiers-стиль дуэлей.
 *
 * Команды:
 *   /bot duel start [раундов]   — начать дуэль (дефолт 10 раундов)
 *   /bot duel stop              — остановить
 *   /bot duel score             — счёт
 *
 * Цикл раунда:
 *   1. COUNTDOWN (5 сек) — бот заморожен, на экране 5..4..3..2..1
 *   2. FIGHTING          — бой, бот атакует
 *   3. ROUND_END         — кто-то умер, показываем результат 3 сек
 *   → повторяем до totalRounds
 *
 * Клиентская часть (HUD) читает:
 *   getPhase(), getCountdown(), getBotScore(), getPlayerScore(),
 *   getLastKillMsg(), getTotalRounds(), getCurrentRound()
 */
public class DuelTimer {

    public static final DuelTimer INSTANCE = new DuelTimer();

    public enum Phase { IDLE, COUNTDOWN, FIGHTING, ROUND_END, FINISHED }

    // ── Состояние ─────────────────────────────────────────────────
    private Phase   phase         = Phase.IDLE;
    private int     totalRounds   = 10;
    private int     currentRound  = 0;
    private int     botScore      = 0;
    private int     playerScore   = 0;

    // Таймеры (в тиках, 20 тиков = 1 сек)
    private int     countdownTicks = 0;   // обратный отсчёт перед раундом
    private int     roundEndTicks  = 0;   // пауза после окончания раунда

    // Фриз бота во время отсчёта
    private Vec3    frozenBotPos   = null;
    private Vec3    frozenPlayerPos = null;

    // Инфо о последнем убийстве для HUD
    private String  lastKillMsg    = "";  // напр. "0 - 4" или "3 - 3"
    private boolean lastRoundBotWon = false;

    private UUID    ownerUUID      = null;
    private String  playerName     = "Player";

    // ── Запуск ───────────────────────────────────────────────────
    public void start(int rounds, UUID ownerUUID, String playerName) {
        this.totalRounds    = Math.max(1, rounds);
        this.ownerUUID      = ownerUUID;
        this.playerName     = playerName != null ? playerName : "Player";
        this.currentRound   = 0;
        this.botScore       = 0;
        this.playerScore    = 0;
        this.lastKillMsg    = "";
        beginCountdown();
    }

    public void stop(MinecraftServer server) {
        phase = Phase.IDLE;
        broadcast(server, "§7Дуэль остановлена. §fСчёт: §c" + botScore + " §7- §a" + playerScore);
    }

    public boolean isActive() { return phase != Phase.IDLE && phase != Phase.FINISHED; }
    public boolean isFighting() { return phase == Phase.FIGHTING; }
    public boolean isCountdown() { return phase == Phase.COUNTDOWN; }

    // ── Главный тик (вызывать каждый тик сервера) ─────────────────
    public void tick(MinecraftServer server) {
        if (phase == Phase.IDLE || phase == Phase.FINISHED) return;

        switch (phase) {
            case COUNTDOWN -> tickCountdown(server);
            case FIGHTING  -> {} // бой идёт — ничего не делаем, ждём убийства
            case ROUND_END -> tickRoundEnd(server);
            default -> {}
        }
    }

    private void tickCountdown(MinecraftServer server) {
        countdownTicks--;

        // Замораживаем бота и игрока
        freezeBot(server);

        // Каждую секунду отправляем title
        int secsLeft = (countdownTicks / 20) + 1;
        if (countdownTicks % 20 == 0 && countdownTicks > 0) {
            sendCountdownTitle(server, secsLeft);
        }

        if (countdownTicks <= 0) {
            // Отсчёт кончился — FIGHT!
            phase = Phase.FIGHTING;
            sendTitle(server, "§c§lFIGHT!", "§7Раунд " + currentRound + " / " + totalRounds, 5, 15, 10);
            broadcast(server, String.format("§6⚔ Раунд %d/%d §7| Счёт §c%d §7- §a%d",
                currentRound, totalRounds, botScore, playerScore));
        }
    }

    private void tickRoundEnd(MinecraftServer server) {
        roundEndTicks--;
        if (roundEndTicks <= 0) {
            if (currentRound >= totalRounds) {
                finishDuel(server);
            } else {
                beginCountdown();
            }
        }
    }

    // ── Убийства ──────────────────────────────────────────────────

    /** Вызвать когда бот убил игрока */
    public void onBotKill(MinecraftServer server) {
        if (phase != Phase.FIGHTING) return;
        botScore++;
        lastRoundBotWon = true;
        lastKillMsg = botScore + " - " + playerScore;
        onRoundOver(server, true);
    }

    /** Вызвать когда игрок убил бота */
    public void onPlayerKill(MinecraftServer server) {
        if (phase != Phase.FIGHTING) return;
        playerScore++;
        lastRoundBotWon = false;
        lastKillMsg = botScore + " - " + playerScore;
        onRoundOver(server, false);
    }

    private void onRoundOver(MinecraftServer server, boolean botWon) {
        phase = Phase.ROUND_END;
        roundEndTicks = 60; // 3 сек паузы

        String winner  = botWon ? "§cBot" : "§a" + playerName;
        String score   = "§c" + botScore + " §7- §a" + playerScore;

        // Title в MCTiers стиле
        String subtitle = score;
        sendTitle(server,
            winner + " §fwins the round",
            subtitle,
            5, 40, 15);

        // Чат
        broadcast(server, String.format("§6Раунд %d: §f%s §6wins! §7Счёт: §c%d §7- §a%d",
            currentRound, (botWon ? "Bot" : playerName), botScore, playerScore));
    }

    // ── Конец дуэли ───────────────────────────────────────────────
    private void finishDuel(MinecraftServer server) {
        phase = Phase.FINISHED;

        boolean botWon    = botScore > playerScore;
        boolean draw      = botScore == playerScore;
        String  mainTitle;
        String  subTitle  = "§7" + botScore + " - " + playerScore;

        if (draw) {
            mainTitle = "§e§lDRAW";
        } else if (botWon) {
            mainTitle = "§c§lYOU LOSE";
        } else {
            mainTitle = "§a§lYOU WIN";
        }

        sendTitle(server, mainTitle, subTitle, 10, 60, 20);
        broadcast(server, "§6§l⚔ Дуэль окончена! §r§fСчёт: §c" + botScore + " §7- §a" + playerScore
            + "  " + (draw ? "§eНичья!" : botWon ? "§cBot победил" : "§a" + playerName + " победил"));

        // Сбрасываем через 5 сек
        new Thread(() -> {
            try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
            phase = Phase.IDLE;
        }).start();
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private void beginCountdown() {
        currentRound++;
        phase            = Phase.COUNTDOWN;
        countdownTicks   = 5 * 20; // 5 секунд
        // Сбрасываем позиции — запомним заново в первый тик freezeBot()
        frozenBotPos    = null;
        frozenPlayerPos = null;
    }

    private void freezeBot(MinecraftServer server) {
        if (server == null) return;

        // Устанавливаем глобальный флаг — BotEntity.tick() проверяет его
        // и пропускает всю логику движения/атаки когда frozen=true
        BotEntity.setGlobalFrozen(isCountdown());

        // Дополнительно: телепортируем ботов обратно на стартовую позицию
        // каждый тик чтобы AI-goals не могли их сдвинуть
        if (frozenBotPos != null) {
            for (var level : server.getAllLevels()) {
                level.getEntities(net.minecraft.world.entity.EntityType.PLAYER,
                    e -> false).forEach(e -> {}); // unused, kept for clarity

                // Итерируем все сущности уровня в поиске BotEntity
                level.getAllEntities().forEach(entity -> {
                    if (entity instanceof BotEntity bot) {
                        // Зануляем скорость и возвращаем на позицию заморозки
                        bot.setDeltaMovement(0, 0, 0);
                        bot.teleportTo(frozenBotPos.x, frozenBotPos.y, frozenBotPos.z);
                    }
                });
            }
        } else {
            // Первый тик заморозки — запоминаем позиции
            for (var level : server.getAllLevels()) {
                level.getAllEntities().forEach(entity -> {
                    if (entity instanceof BotEntity bot && frozenBotPos == null) {
                        frozenBotPos = bot.position();
                    }
                });
            }
        }

        // Замораживаем игрока-владельца (опционально — только движение)
        if (ownerUUID != null) {
            ServerPlayer owner = server.getPlayerList().getPlayer(ownerUUID);
            if (owner != null) {
                if (frozenPlayerPos == null) {
                    frozenPlayerPos = owner.position();
                } else {
                    owner.teleportTo(frozenPlayerPos.x, frozenPlayerPos.y, frozenPlayerPos.z);
                }
            }
        }
    }

    private void sendCountdownTitle(MinecraftServer server, int n) {
        String color = n <= 1 ? "§c" : n <= 2 ? "§e" : "§a";
        String sub   = "§7Раунд " + currentRound + "/" + totalRounds
                     + " §7| §c" + botScore + " §7- §a" + playerScore;
        sendTitle(server, color + "§l" + n, sub, 0, 22, 0);
    }

    private void sendTitle(MinecraftServer server, String title, String sub,
                           int fadeIn, int stay, int fadeOut) {
        if (server == null) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(
                Component.literal(title)));
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(
                Component.literal(sub)));
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(
                fadeIn, stay, fadeOut));
        }
    }

    private void broadcast(MinecraftServer server, String msg) {
        if (server == null) { System.out.println("[Duel] " + msg.replaceAll("§.", "")); return; }
        for (ServerPlayer p : server.getPlayerList().getPlayers())
            p.sendSystemMessage(Component.literal(msg));
    }

    // ── Геттеры для HUD ───────────────────────────────────────────
    public Phase  getPhase()         { return phase;           }
    public int    getCountdownSecs() { return (countdownTicks / 20) + 1; }
    public int    getBotScore()      { return botScore;         }
    public int    getPlayerScore()   { return playerScore;      }
    public int    getCurrentRound()  { return currentRound;     }
    public int    getTotalRounds()   { return totalRounds;      }
    public String getLastKillMsg()   { return lastKillMsg;      }
    public boolean lastRoundBotWon() { return lastRoundBotWon;  }
    public String getScoreText() {
        if (phase == Phase.IDLE) return "§7Дуэль не идёт. §f/bot duel start [раундов]";
        return String.format("§6Раунд §f%d§7/§f%d §7| §c%d §7- §a%d",
            currentRound, totalRounds, botScore, playerScore);
    }
}
