package com.pvpbot.gui.tab;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Рендерер вкладки ROLES — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class RolesTabRenderer {

    private RolesTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H;
        int cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);

        int sx = cx + 10, sy = cy + 8;
        BotRole.RoleConfig roleCfg = PVPBotConfig.INSTANCE.roleConfig;
        boolean pct = roleCfg.usePercent;

        g.drawString(font, "⚔  Настройка ролей отряда", sx, sy, ACCENT_BLUE);
        sy += 12;
        g.drawString(font, "Перетащи ползунок: 0=выкл, 100=все. Режим: " + (pct ? "%" : "шт."),
            sx, sy, TEXT_GRAY);
        sy += 16;

        // ── Кнопки "Авторежим" и "Режим: % / шт." ───────────────
        String[] roleBtnLabels = {"Авторежим", pct ? "Режим: %" : "Режим: шт."};
        int[] roleBtnAccents   = {ACCENT_GRAY, pct ? ACCENT_GREEN : ACCENT_YEL};
        int rbX = sx;
        for (int i = 0; i < roleBtnLabels.length; i++) {
            boolean hov = mx >= rbX && mx < rbX + 90 && my >= sy && my < sy + 16;
            float ra = AnimationUtil.tick("role_btn_" + i, hov ? 1f : 0f, 0.2f);
            RenderUtil.rounded(g, rbX, sy, 90, 16, 3,
                new Color(AnimationUtil.lerpColor(BG_CARD, (roleBtnAccents[i] & 0x00FFFFFF) | 0x25000000, ra)));
            bd(g, rbX, sy, 90, 16, AnimationUtil.lerpColor(BORDER_CARD, roleBtnAccents[i], ra));
            g.drawString(font, roleBtnLabels[i], rbX + 5, sy + 4,
                AnimationUtil.lerpColor(TEXT_GRAY, TEXT_WHITE, ra));
            rbX += 96;
        }
        sy += 22;

        BotRole[] roles = BotRole.values();
        int rowH = 22;
        int slW  = 200;

        for (int i = 0; i < roles.length; i++) {
            BotRole role = roles[i];
            Integer v    = roleCfg.roleCounts.get(role);
            int val      = (v == null || v == -1) ? -1 : v;
            int y        = sy + i * rowH;

            // Цветовой квадратик роли
            fr(g, sx, y + 4, 6, 6, 0xFF000000 | role.mapColor);
            // Название роли
            g.drawString(font, role.displayName, sx + 10, y + 3, TEXT_BRIGHT);

            // Слайдер background
            int slX = sx + 80;
            fr(g, slX, y + 4, slW, 8, 0xFF1A2035);

            // Слайдер fill
            float frac = val <= 0 ? 0f : (val / 100f);
            int fillW  = (int)(slW * frac);
            int slColor = val == 0 ? ACCENT_RED : (0xFF000000 | role.mapColor);
            if (fillW > 0) fr(g, slX, y + 4, fillW, 8, slColor);

            // Ручка
            if (fillW > 0) {
                int kx = slX + fillW - 3;
                fr(g, kx, y + 2, 6, 12, TEXT_WHITE);
            }

            // Значение
            String valStr = val == -1 ? "авто" : (val == 0 ? "выкл" : val + (pct ? "%" : " шт."));
            int valColor  = val == -1 ? TEXT_GRAY : (val == 0 ? ACCENT_RED : ACCENT_GREEN);
            g.drawString(font, valStr, slX + slW + 6, y + 3, valColor);

            // Сохраняем позицию для mouseClicked
            int base = i * 3;
            roleSliderPos[base]     = slX;
            roleSliderPos[base + 1] = y + 2;
            roleSliderPos[base + 2] = slW;
        }

        // Мини-карта отряда (справа)
        renderSquadMinimap(g, cx + cw - 100, cy + 20);
    }

    private void handleRolesTabClick(int mx, int my) {
        int sx = winX + LEFT_W + 10, sy = winY + HEADER_H + 8 + 12 + 16;
        // Кнопки "Авторежим" и "Режим: % / шт."
        if (my >= sy && my < sy + 16) {
            if (mx >= sx && mx < sx + 90) {
                sendCmd("bot squad rolesauto"); rebuild(); return;
            }
            if (mx >= sx + 96 && mx < sx + 186) {
                PVPBotConfig.INSTANCE.roleConfig.usePercent = !PVPBotConfig.INSTANCE.roleConfig.usePercent;
                BotConfig.save(); rebuild(); return;
            }
        }

        // Слайдеры ролей
        BotRole[] roles = BotRole.values();
        for (int i = 0; i < roles.length; i++) {
            int base = i * 3;
            int slX  = roleSliderPos[base];
            int slY  = roleSliderPos[base + 1];
            int slW  = roleSliderPos[base + 2];
            if (mx >= slX && mx <= slX + slW && my >= slY && my <= slY + 14) {
                float frac = (float)(mx - slX) / slW;
                int val = Math.round(frac * 100);
                PVPBotConfig.INSTANCE.roleConfig.roleCounts.put(roles[i], val);
                PVPBotConfig.INSTANCE.roleConfig.usePercent = true;
                BotConfig.save();
                sendCmd("bot squad role " + roles[i].name() + " " + val);
                return;
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  v7.0 — HISTORY TAB — история боёв
    // ═══════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════════
    //  KITS TAB — выбор кита + кнопка «Надеть на бота»
    // ═══════════════════════════════════════════════════════════════

    // Данные карточек кита: { id, displayName, iconId, акцентЦвет, строка1, строка2 }
    private static final Object[][] KIT_CARDS = {
        {"sword",      "Sword PvP",        "kit_sword",   0xFF3B82F6,
            "Diamond Prot4 Unb3",         "Sword Sharp5 Unb3"},
        {"axe",        "Axe PvP",          "kit_axe",     0xFFFB923C,
            "Diamond (без зачар!)",        "Axe Sharp5 Eff5 + Shield"},
        {"pot",        "Diamond Pot",      "kit_pot",     0xFFEC4899,
            "Diamond Prot4 Unb3",         "Sword Sharp5 + Splash Potion"},
        {"uhc",        "UHC",              "kit_uhc",     0xFFEF4444,
            "Diamond Prot3/Prot2 Unb3",   "Sword Sharp3 + Bow Power5 Inf"},
        {"nethop",     "NethOP",           "kit_nethop",  0xFF8B5CF6,
            "Netherite Prot4 Unb3 Mend",  "NethSword Sharp5 Unb3 Mend + Tot"},
        {"smp",        "SMP",              "kit_smp",     0xFF22C55E,
            "Netherite Prot4 Unb3 Mend",  "Sword Sharp5 KB2 FA2 + Totem"},
        {"crystal",    "Crystal PvP",      "kit_crystal", 0xFF06B6D4,
            "Neth Prot4 / BlastProt4",    "Sword Sharp5 KB1 + Totem"},
        {"mace",       "Mace PvP",         "kit_mace",    0xFF94A3B8,
            "Netherite Prot4 Unb3 Mend",  "Mace Density5 Breach4 + Totem"},
        {"mace_elytra","Mace + Elytra",    "kit_mace",    0xFFA855F7,
            "Netherite + Elytra нагрудник","Mace Density5 Breach4 + Totem"},
        {"tpc",        "TPC",              "kit_tpc",     0xFF60A5FA,
            "Netherite Prot4 Unb3 Mend",  "NethAxe Sharp5 Eff5 + Totem"},
        {"snowball",   "Snowball",         "kit_snowball",0xFF64748B,
            "Diamond Prot4 Unb3",         "Snowball + Shield"},
        {"trident",    "Trident PvP",      "kit_trident", 0xFF0EA5E9,
            "Diamond Prot4 Unb3",         "Trident Loyalty3 + Shield"},
        {"crossbow",   "Crossbow PvP",     "kit_sword",   0xFF84CC16,
            "Diamond Prot4 Unb3",         "Crossbow Multishot QC3 + Shield"},
    };

    private String selectedKitId = null;


}
