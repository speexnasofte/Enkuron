package com.pvpbot.gui.render;

import java.util.HashMap;
import java.util.Map;

/**
 * AnimationUtil v2.0 — анимации, RGB-цикл, pulse, spring.
 */
public class AnimationUtil {

    private static final Map<String, Float> values = new HashMap<>();

    // ── RGB cycle state ───────────────────────────────────────────
    /** Возвращает плавно циклирующий RGB-цвет (hue вращается со временем). */
    public static int rgbCycle(float speed) {
        float hue = (System.currentTimeMillis() * speed / 1000f) % 1f;
        return hsbToArgb(hue, 0.85f, 1f);
    }

    /** RGB с заданным смещением фазы (0–1). Используется для радуги по элементам. */
    public static int rgbCycleOffset(float speed, float offset) {
        float hue = ((System.currentTimeMillis() * speed / 1000f) + offset) % 1f;
        return hsbToArgb(hue, 0.85f, 1f);
    }

    /** RGB с заданной яркостью/насыщенностью. */
    public static int rgbCycleFull(float speed, float sat, float bri) {
        float hue = (System.currentTimeMillis() * speed / 1000f) % 1f;
        return hsbToArgb(hue, sat, bri);
    }

    /** Пульс: синусоидальное значение 0–1. */
    public static float pulse(float speed) {
        return (float)(0.5 + 0.5 * Math.sin(System.currentTimeMillis() * speed / 1000.0));
    }

    /** Пульс со смещением фазы. */
    public static float pulseOffset(float speed, float offset) {
        return (float)(0.5 + 0.5 * Math.sin(System.currentTimeMillis() * speed / 1000.0 + offset * Math.PI * 2));
    }

    /** Получить текущее значение (0.0 – 1.0). */
    public static float get(String key) {
        return values.getOrDefault(key, 0f);
    }

    /**
     * Плавно двигать значение к target со скоростью speed.
     * Вызывать каждый кадр (в render()).
     */
    public static float tick(String key, float target, float speed) {
        float cur = values.getOrDefault(key, 0f);
        cur += (target - cur) * speed;
        if (Math.abs(target - cur) < 0.002f) cur = target;
        values.put(key, cur);
        return cur;
    }

    /** Сбросить все анимации (при закрытии экрана). */
    public static void clear() {
        values.clear();
    }

    /** Линейная интерполяция двух ARGB цветов. */
    public static int lerpColor(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int fa = (from >> 24) & 0xFF, fr = (from >> 16) & 0xFF,
            fg = (from >> 8) & 0xFF,  fb = from & 0xFF;
        int ta = (to   >> 24) & 0xFF, tr = (to   >> 16) & 0xFF,
            tg = (to   >> 8) & 0xFF,  tb = to   & 0xFF;
        int a = (int)(fa + (ta - fa) * t);
        int r = (int)(fr + (tr - fr) * t);
        int g = (int)(fg + (tg - fg) * t);
        int b = (int)(fb + (tb - fb) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ── HSB → ARGB ────────────────────────────────────────────────
    public static int hsbToArgb(float h, float s, float b) {
        int rgb = java.awt.Color.HSBtoRGB(h, s, b);
        return (0xFF << 24) | (rgb & 0x00FFFFFF);
    }

    /** Смешивает RGB-цвет с base по весу t (0=base, 1=rgb). */
    public static int blendRgb(int base, float rgbSpeed, float t) {
        return lerpColor(base, rgbCycle(rgbSpeed), t);
    }
}
