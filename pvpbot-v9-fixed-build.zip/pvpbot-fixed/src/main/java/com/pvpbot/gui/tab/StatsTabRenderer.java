package com.pvpbot.gui.tab;

import com.pvpbot.*;
import com.pvpbot.gui.render.AnimationUtil;
import com.pvpbot.gui.render.IconRenderer;
import com.pvpbot.gui.render.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Рендерер вкладки STATS — вынесен из PVPBotScreen для уменьшения размера файла.
 * Вызывается из PVPBotScreen.render() через статический метод render().
 */
public final class StatsTabRenderer {

    private StatsTabRenderer() {}

    public static void render(GuiGraphics g, int mx, int my) {
        int cx = winX + LEFT_W + 1, cy = winY + HEADER_H, cw = WIN_W - LEFT_W - 1, ch = WIN_H - HEADER_H - FOOT_H;
        fr(g, cx, cy, cw, ch, BG_MAIN);
        int sx = cx + 10, sy = cy + 8;

        g.drawString(font, "SESSION STATISTICS", sx, sy, TEXT_WHITE);
        long secs = (System.currentTimeMillis() - sessionStart) / 1000;
        g.drawString(font, String.format("⏱ %02d:%02d", secs / 60, secs % 60), sx + 200, sy, TEXT_GRAY);
        sy += 18;

        // Big stat cards
        int[] vs = {KillDeathTracker.kills, KillDeathTracker.deaths, KillDeathTracker.assists};
        String[] ls = {"KILLS", "DEATHS", "ASSISTS"};
        int[] cs = {ACCENT_GREEN, ACCENT_RED, ACCENT_YEL};
        String[] icons = {"⚔", "💀", "🤝"};
        int sW = 104, sH = 52;
        for (int i = 0; i < 3; i++) {
            int bx = sx + i * (sW + 8);
            float a = AnimationUtil.tick("stats_card_" + i, 1f, 0.05f);
            RenderUtil.rounded(g, bx, sy, sW, sH, 6, new Color(BG_CARD));
            g.fillGradient(bx + 4, sy, bx + sW - 4, sy + 3, cs[i], (cs[i] & 0x00FFFFFF));
            bd(g, bx, sy, sW, sH, (cs[i] & 0x00FFFFFF) | 0x50000000);
            g.drawString(font, icons[i], bx + 5, sy + 6, cs[i]);
            String numStr = String.valueOf(vs[i]);
            int numW = font.width(numStr) * 2;
            g.drawCenteredString(font, numStr, bx + sW / 2, sy + 16, cs[i]);
            g.drawCenteredString(font, ls[i], bx + sW / 2, sy + 36, TEXT_GRAY);
        }

        // K/D ratio
        double kd = KillDeathTracker.deaths == 0 ? KillDeathTracker.kills : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
        int kdX = sx + 3 * (sW + 8);
        RenderUtil.rounded(g, kdX, sy, sW, sH, 6, new Color(BG_CARD));
        g.fillGradient(kdX + 4, sy, kdX + sW - 4, sy + 3, ACCENT_BLUE, (ACCENT_BLUE & 0x00FFFFFF));
        bd(g, kdX, sy, sW, sH, (ACCENT_BLUE & 0x00FFFFFF) | 0x50000000);
        g.drawString(font, "📊", kdX + 5, sy + 6, ACCENT_BLUE);
        g.drawCenteredString(font, String.format("%.2f", kd), kdX + sW / 2, sy + 16, ACCENT_BLUE);
        g.drawCenteredString(font, "K/D RATIO", kdX + sW / 2, sy + 36, TEXT_GRAY);

        sy += sH + 12;
        secTitle(g, "RECENT FIGHTS — BAR CHART", sx, sy); sy += 14;

        // bar chart
        int[] results = {1, 0, 1, 1, -1, 1, 0, 1, -1, 1};
        String[] opp   = {"Notch","Steve","Hero","Alex","Ender","Creep","P1","Ghost","B0ne","Raid"};
        int bW = 28, barH = 48, bG = 5;
        for (int i = 0; i < results.length; i++) {
            int bx = sx + i * (bW + bG);
            int bc = results[i] > 0 ? ACCENT_GREEN : (results[i] < 0 ? ACCENT_RED : TEXT_GRAY);
            int fh = results[i] > 0 ? barH : (results[i] < 0 ? barH / 2 : barH / 3);
            fr(g, bx, sy, bW, barH, 0xFF141A28);
            // animated bar fill
            float ba = AnimationUtil.tick("bar_" + i, 1f, 0.04f);
            int realFh = (int)(fh * ba);
            fr(g, bx, sy + barH - realFh, bW, realFh, (bc & 0x00FFFFFF) | 0xCC000000);
            bd(g, bx, sy, bW, barH, 0xFF1A2035);
            // result label
            String rl = results[i] > 0 ? "W" : (results[i] < 0 ? "L" : "D");
            g.drawCenteredString(font, rl, bx + bW / 2, sy + barH + 2, bc);
            // opponent name (rotated hint)
            if (i % 2 == 0) g.drawString(font, opp[i], bx - 1, sy + barH + 14, TEXT_DARK);
        }

        sy += barH + 30;
        secTitle(g, "CURRENT SESSION INFO", sx, sy); sy += 14;
        g.drawString(font, "Mode: " + cfg.mode.name(), sx, sy, TEXT_BRIGHT);
        g.drawString(font, "Difficulty: " + cfg.difficulty.name(), sx + 110, sy, diffCol(cfg.difficulty));
        g.drawString(font, cfg.standbyMode ? "⏸ STANDBY" : "⚔ ACTIVE", sx + 250, sy, cfg.standbyMode ? TEXT_GRAY : ACCENT_RED);
        g.drawString(font, "Bots: " + cfg.maxBots, sx + 380, sy, TEXT_BRIGHT);
        sy += 18;

        // ── KIT STATS ─────────────────────────────────────────────
        secTitle(g, "KIT STATS", sx, sy); sy += 14;

        java.util.Map<String, KitStatsTracker.KitRecord> allRecords = KitStatsTracker.INSTANCE.getAllRecords();
        String bestKit = KitStatsTracker.INSTANCE.getBestKit();

        if (allRecords.isEmpty()) {
            g.drawString(font, "Нет данных — начни бой с ботом", sx, sy, TEXT_GRAY);
        } else {
            // Шапка таблицы
            g.drawString(font, "Кит             Rounds  Win%    DMG↑    DMG↓", sx, sy, TEXT_GRAY); sy += 10;
            g.fill(sx, sy, cx + cw - 10, sy + 1, BORDER_SEP); sy += 4;

            int rowIdx = 0;
            for (java.util.Map.Entry<String, KitStatsTracker.KitRecord> entry : allRecords.entrySet()) {
                if (sy > cy + ch - 20) break;
                String kitId = entry.getKey();
                KitStatsTracker.KitRecord rec = entry.getValue();

                boolean isBest = kitId.equals(bestKit);
                if (rowIdx % 2 == 0) fr(g, sx - 2, sy - 1, cw - 16, 12, 0xFF0D1220);

                // Звёздочка для лучшего кита
                int nameColor = isBest ? ACCENT_YEL : TEXT_BRIGHT;
                String kitLabel = (isBest ? "★ " : "  ") + padRight(kitId, 14);
                g.drawString(font, kitLabel,                                          sx,       sy, nameColor);
                g.drawString(font, padLeft(String.valueOf(rec.rounds), 4),            sx + 116, sy, TEXT_GRAY);

                float wr = rec.winRate() * 100f;
                int wrColor = wr >= 60 ? ACCENT_GREEN : (wr >= 40 ? ACCENT_YEL : ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f%%", wr), 5),           sx + 152, sy, wrColor);
                g.drawString(font, padLeft(String.format("%.0f", rec.avgDamageDealt()), 6), sx + 192, sy, ACCENT_RED);
                g.drawString(font, padLeft(String.format("%.0f", rec.avgDamageTaken()), 6), sx + 232, sy, 0xFFFF8844);

                // Мини-полоска Win Rate
                int barW = 60;
                int barX = sx + 272;
                fr(g, barX, sy + 1, barW, 7, 0xFF1A2035);
                fr(g, barX, sy + 1, (int)(barW * rec.winRate()), 7, (wrColor & 0x00FFFFFF) | 0xAA000000);
                bd(g, barX, sy + 1, barW, 7, BORDER_CARD);

                sy += 12;
                rowIdx++;
            }

            // Кнопка сброса
            sy += 4;
            boolean hovRst = mx >= sx && mx < sx + 90 && my >= sy && my < sy + 14;
            float aRst = AnimationUtil.tick("kitstats_reset", hovRst ? 1f : 0f, 0.2f);
            fr(g, sx, sy, 90, 14, AnimationUtil.lerpColor(BG_CARD, 0x20EF4444, aRst));
            bd(g, sx, sy, 90, 14, AnimationUtil.lerpColor(BORDER_CARD, 0xFFEF4444, aRst));
            g.drawString(font, "🗑 Сбросить KitStats", sx + 4, sy + 3,
                AnimationUtil.lerpColor(TEXT_GRAY, 0xFFEF4444, aRst));
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  FOOTER
    // ═══════════════════════════════════════════════════════════════

}
