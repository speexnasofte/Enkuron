package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

/**
 * InventoryUseLogic — PATCH v2.1.0
 *
 * Заставляет бота использовать РЕАЛЬНЫЕ предметы из инвентаря:
 *  ✦ Паутина (cobweb)  — замедляет врага под ногами на дистанции < WEB_RANGE
 *  ✦ Лавовое ведро     — поджигает врага под ногами (если стоит)
 *  ✦ Щит (offhand)     — авто-блок при входящем ударе
 *  ✦ Зелья лечения     — бросает сплэш зелье лечения когда HP < HEAL_HP
 *  ✦ Гэпл (golden apple) — ест гэпл при HP < GAP_HP
 *
 * Логика вызывается из BotEntity.tickCustomLogic() каждый тик до modeDispatcher.
 */
public class InventoryUseLogic {

    private static final double WEB_RANGE   = 5.0;
    private static final double LAVA_RANGE  = 3.5;
    private static final double POTION_RANGE = 5.0;
    private static final float  HEAL_HP     = 12.0f;
    private static final float  GAP_HP      = 10.0f;
    private static final int    WEB_CD      = 80;
    private static final int    WEB_LIFE    = 70;
    private static final int    LAVA_CD     = 120;
    private static final int    POTION_CD   = 30;
    private static final int    GAP_CD      = 200;

    private final BotEntity bot;

    private int webCd    = 0;
    private int webLife  = 0;
    private int lavaCd   = 0;
    private int potionCd = 0;
    private int gapCd    = 0;

    private BlockPos webPos  = null;
    private BlockPos lavaPos = null;
    private boolean webPlaced  = false;
    private boolean lavaPlaced = false;

    public InventoryUseLogic(BotEntity bot) {
        this.bot = bot;
    }

    /** Вызывается каждый тик из BotEntity. target может быть null. */
    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;

        if (webCd    > 0) webCd--;
        if (lavaCd   > 0) lavaCd--;
        if (potionCd > 0) potionCd--;
        if (gapCd    > 0) gapCd--;
        if (webLife  > 0) webLife--;

        // Удаляем паутину после истечения времени
        if (webPlaced && webLife <= 0) removeWeb(sw);
        if (lavaPlaced && lavaCd <= 0) removeLava(sw);

        // Зелье лечения себе (независимо от цели)
        tickHeal(sw);
        // Гэпл
        tickGap();

        if (target == null || !target.isAlive()) return;

        double dist = bot.distanceTo(target);

        // Паутина под ноги врага
        tickWeb(sw, target, dist);
        // Лава под ноги врага
        tickLava(sw, target, dist);
    }

    // ── Паутина ──────────────────────────────────────────────────

    private void tickWeb(ServerLevel sw, LivingEntity target, double dist) {
        if (webCd > 0 || webPlaced) return;
        if (dist > WEB_RANGE) return;
        if (!hasItem(Items.COBWEB)) return;

        BlockPos feet = BlockPos.containing(target.position());
        // Ставим только на воздух
        if (!sw.getBlockState(feet).isAir()) return;

        sw.setBlock(feet,        Blocks.COBWEB.defaultBlockState(), 3);
        sw.setBlock(feet.above(), Blocks.COBWEB.defaultBlockState(), 3);
        webPlaced = true;
        webPos    = feet;
        webLife   = WEB_LIFE;
        webCd     = WEB_CD;
        consumeItem(Items.COBWEB, 1);
    }

    private void removeWeb(ServerLevel sw) {
        if (webPos == null) { webPlaced = false; return; }
        if (sw.getBlockState(webPos).is(Blocks.COBWEB))        sw.removeBlock(webPos, false);
        if (sw.getBlockState(webPos.above()).is(Blocks.COBWEB)) sw.removeBlock(webPos.above(), false);
        webPlaced = false;
        webPos    = null;
    }

    // ── Лава ─────────────────────────────────────────────────────

    private void tickLava(ServerLevel sw, LivingEntity target, double dist) {
        if (lavaCd > 0 || lavaPlaced) return;
        if (dist > LAVA_RANGE) return;
        if (!hasItem(Items.LAVA_BUCKET)) return;
        // Лью лаву только если враг стоит (не прыгает)
        if (target.getDeltaMovement().y > 0.1) return;

        BlockPos feet = BlockPos.containing(target.getX(), target.getY() - 0.1, target.getZ());
        if (!sw.getBlockState(feet).isAir()) return;

        sw.setBlock(feet, net.minecraft.world.level.block.Blocks.LAVA.defaultBlockState(), 3);
        lavaPlaced = true;
        lavaPos    = feet;
        lavaCd     = LAVA_CD;
        consumeItem(Items.LAVA_BUCKET, 1);
    }

    private void removeLava(ServerLevel sw) {
        if (lavaPos == null) { lavaPlaced = false; return; }
        var state = sw.getBlockState(lavaPos);
        if (state.is(net.minecraft.world.level.block.Blocks.LAVA))
            sw.removeBlock(lavaPos, false);
        lavaPlaced = false;
        lavaPos    = null;
    }

    // ── Зелье лечения (бросает в себя) ───────────────────────────

    private void tickHeal(ServerLevel sw) {
        if (potionCd > 0) return;
        if (bot.getHealth() > HEAL_HP) return;
        if (!hasItem(Items.SPLASH_POTION)) return;

        // Даём эффект лечения напрямую (splash в себя)
        bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            net.minecraft.world.effect.MobEffects.HEAL, 1, 1));
        potionCd = POTION_CD;
        consumeItem(Items.SPLASH_POTION, 1);
    }

    // ── Гэпл ─────────────────────────────────────────────────────

    private void tickGap() {
        if (gapCd > 0) return;
        if (bot.getHealth() > GAP_HP) return;
        if (!hasItem(Items.GOLDEN_APPLE) && !hasItem(Items.ENCHANTED_GOLDEN_APPLE)) return;

        // Даём эффекты гэпла напрямую
        bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            net.minecraft.world.effect.MobEffects.REGENERATION, 100, 1));
        bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            net.minecraft.world.effect.MobEffects.ABSORPTION, 2400, 0));
        gapCd = GAP_CD;

        // Сначала пробуем обычный гэпл, потом EnchGap
        if (hasItem(Items.GOLDEN_APPLE)) consumeItem(Items.GOLDEN_APPLE, 1);
        else consumeItem(Items.ENCHANTED_GOLDEN_APPLE, 1);
    }

    // ── Утилиты ───────────────────────────────────────────────────

    // Отслеживаем расход предметов (InvItem.count - final, используем свой счётчик)
    private final java.util.Map<net.minecraft.world.item.Item, Integer> consumed =
        new java.util.HashMap<>();

    /** Проверяет наличие предмета в инвентаре бота. */
    private boolean hasItem(net.minecraft.world.item.Item item) {
        BotKit kit = bot.getCurrentKit();
        if (kit != null) {
            for (InvItem inv : kit.inventory) {
                if (inv.item == item) {
                    int used = consumed.getOrDefault(item, 0);
                    return inv.count - used > 0;
                }
            }
        }
        return false;
    }

    /** Симулирует расход предмета из инвентаря. */
    private void consumeItem(net.minecraft.world.item.Item item, int amount) {
        consumed.merge(item, amount, Integer::sum);
    }
}
