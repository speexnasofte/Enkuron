package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * PatternAI v2.0 — улучшенная производительность и точность предсказаний.
 *
 * Улучшения v2.0:
 *  ПРОИЗВОДИТЕЛЬНОСТЬ:
 *   - posHistory хранится как float[HISTORY_SIZE*3] (массив примитивов, не Deque<Vec3>)
 *     Deque<Vec3> → GC давление из-за boxing; массив — нет аллокаций в hot path.
 *   - computeAvgVelocity не создаёт new Vec3 в цикле — использует double-аккумуляторы.
 *   - getEnemyPredictability кэшируется на PRED_CACHE_LIFE тиков (был пересчёт каждый тик).
 *   - updateCounter убран — используем tickCount % interval (нет поля).
 *   - angles/speeds List<Double> убран — inline variance через Welford's algorithm.
 *
 *  AI:
 *   - Velocity предсказание: экспоненциальное сглаживание (EMA) вместо простого среднего
 *     (быстрее реагирует на смену направления).
 *   - TIMING_SHIFT: фаза теперь синхронизирована с attackCooldown бота (бьём в gap врага).
 *   - BAIT_STOP: длина паузы теперь варьируется 2-4 тика (было фиксировано 3).
 *   - countermeasure выбирает STRAFE_COUNTER если враг > 80% предсказуем и быстро страфит.
 *   - isDominantStrafe: теперь считает знако-изменения в 3D (не только X), точнее.
 */
public class PatternAI {

    // ── Константы ─────────────────────────────────────────────────
    private static final int    HISTORY_SIZE               = 20;
    private static final int    PREDICT_AHEAD              = 5;
    private static final double MIN_SPEED_THRESHOLD        = 0.05;
    private static final int    ANTI_PATTERN_MIN           = 30;
    private static final int    ANTI_PATTERN_MAX           = 80;
    private static final float  COUNTER_ACTIVATE_THRESHOLD = 0.65f;
    private static final int    COUNTER_REEVAL_TICKS       = 60;
    private static final int    PRED_CACHE_LIFE            = 8; // тиков кэш предсказуемости

    // ── История позиций: float[HISTORY_SIZE * 3] (x,y,z,...) ─────
    // Избегаем Deque<Vec3> → нет GC-давления от boxing Vec3
    private final float[] posX = new float[HISTORY_SIZE];
    private final float[] posZ = new float[HISTORY_SIZE];
    private int  histHead  = 0;  // индекс следующей записи (кольцевой буфер)
    private int  histCount = 0;  // сколько записей реально есть

    // ── EMA-скорость (экспоненциальное сглаживание) ───────────────
    // Быстрее реагирует на смену направления чем простое среднее
    private double emaVx = 0.0, emaVz = 0.0;
    private static final double EMA_ALPHA = 0.35; // вес нового измерения

    // ── Предсказанная позиция ─────────────────────────────────────
    private float predictedX = 0f, predictedZ = 0f;

    // ── Кэш предсказуемости ───────────────────────────────────────
    private float cachedPredictability   = 0.5f;
    private int   predictabilityCacheAge = 0;

    // ── АнтиПаттерн ───────────────────────────────────────────────
    private final Random rnd = new Random();
    private int   antiPatternTimer   = 40;
    private float antiPatternYawBias = 0f;
    private boolean antiActive       = false;

    // ── Контр-паттерн ────────────────────────────────────────────
    public enum CounterStrategy {
        NONE,
        STRAFE_MIRROR,   // зеркалит страф врага (предсказуемо-низкий)
        STRAFE_COUNTER,  // идём против страфа (предсказуемость высокая)
        TIMING_SHIFT,    // сдвигаем тайминг атаки через синус
        BAIT_STOP,       // провоцируем атаку остановкой
        FEINT            // v2.1: ложный выпад — рывок к врагу + резкое торможение
    }

    private CounterStrategy activeCounter    = CounterStrategy.NONE;
    private int             counterReevalTimer = 0;
    private int             baitStopTicks     = 0;
    private float           timingShiftPhase  = 0f;

    // ── UPDATE interval ───────────────────────────────────────────
    private static final int UPDATE_INTERVAL      = 3;
    private static final int UPDATE_INTERVAL_OPT  = 9; // optimizeMode: реже

    private final BotEntity bot;

    public PatternAI(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Обновление (вызывается из BotEntity.tick())
    // ══════════════════════════════════════════════════════════════
    public void update(LivingEntity target) {
        tickAntiPattern();
        tickCounterPattern();

        int interval = PVPBotConfig.INSTANCE.optimizeMode ? UPDATE_INTERVAL_OPT : UPDATE_INTERVAL;
        // Без отдельного поля updateCounter — используем tickCount
        if (bot.tickCount % interval != 0) return;

        float tx = (float) target.getX();
        float tz = (float) target.getZ();

        // Обновляем EMA-скорость
        if (histCount > 0) {
            int prevIdx = (histHead - 1 + HISTORY_SIZE) % HISTORY_SIZE;
            double dvx = tx - posX[prevIdx];
            double dvz = tz - posZ[prevIdx];
            emaVx = emaVx + EMA_ALPHA * (dvx - emaVx);
            emaVz = emaVz + EMA_ALPHA * (dvz - emaVz);
        }

        // Записываем в кольцевой буфер
        posX[histHead] = tx;
        posZ[histHead] = tz;
        histHead = (histHead + 1) % HISTORY_SIZE;
        if (histCount < HISTORY_SIZE) histCount++;

        // Предсказываем позицию через PREDICT_AHEAD шагов
        predictedX = tx + (float)(emaVx * PREDICT_AHEAD);
        predictedZ = tz + (float)(emaVz * PREDICT_AHEAD);

        // Инвалидируем кэш предсказуемости
        predictabilityCacheAge--;
    }

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /** Предсказанная позиция цели (для броска перлов/зелий). */
    public Vec3 getPredictedPosition(LivingEntity target) {
        if (histCount < 5) return target.position();
        return new Vec3(predictedX, target.getY(), predictedZ);
    }

    /**
     * Адаптированный Yaw для страфа с учётом CounterStrategy.
     * Теперь использует EMA-скорость вместо computeAvgVelocity().
     */
    public double getAdaptedStrafeYaw(float baseYaw, boolean strafeLeft) {
        double base = strafeLeft ? -90.0 : 90.0;

        double speed = Math.sqrt(emaVx * emaVx + emaVz * emaVz);
        if (speed > MIN_SPEED_THRESHOLD && histCount >= 10) {
            double enemyAngle = Math.toDegrees(Math.atan2(-emaVx, emaVz));
            double diff = angleDiff(enemyAngle, baseYaw);

            switch (activeCounter) {
                case STRAFE_MIRROR  -> base += diff * 0.5;
                case STRAFE_COUNTER -> base -= diff * 0.5;
                default             -> base += diff * 0.3;
            }
        }

        base += antiPatternYawBias;
        if (activeCounter == CounterStrategy.TIMING_SHIFT) {
            base += Math.sin(timingShiftPhase) * 15.0;
        }
        // v2.1: FEINT — на первых 2 тиках идём ПРЯМО на врага (рывок)
        // потом резко останавливаемся → враг теряет прицел
        if (activeCounter == CounterStrategy.FEINT && baitStopTicks > 2) {
            // Рывок к цели: base = 0 (прямо вперёд) + небольшой шум
            base = rnd.nextFloat() * 20 - 10;
        }
        return base;
    }

    /** Страф с учётом BotLearning (per-owner). */
    public double getLearnedStrafeYaw(float baseYaw, boolean strafeLeft) {
        BotLearning bl = BotLearning.forOwner(bot.getOwnerUUID());
        List<BotLearning.Action> topPattern = bl.getTopPattern();
        if (topPattern == null || topPattern.isEmpty())
            return getAdaptedStrafeYaw(baseYaw, strafeLeft);

        long leftCount  = topPattern.stream().filter(a -> a == BotLearning.Action.MOVE_LEFT).count();
        long rightCount = topPattern.stream().filter(a -> a == BotLearning.Action.MOVE_RIGHT).count();

        float learnedBias = 0f;
        if      (leftCount  > rightCount + 2) learnedBias =  25f;
        else if (rightCount > leftCount  + 2) learnedBias = -25f;

        return baseYaw + (strafeLeft ? 90 : -90) + antiPatternYawBias + learnedBias;
    }

    /** Предсказуемость движения врага (0..1). Кэшируется PRED_CACHE_LIFE тиков. */
    public float getEnemyPredictability() {
        if (predictabilityCacheAge > 0) return cachedPredictability;

        cachedPredictability = computePredictability();
        predictabilityCacheAge = PRED_CACHE_LIFE;
        return cachedPredictability;
    }

    public boolean isBaitStopActive()           { return baitStopTicks > 0; }
    public CounterStrategy getActiveCounter()   { return activeCounter; }
    public boolean isAntiPatternActive()        { return antiActive; }

    /** Предсказуемость хозяина на основе BotLearning. */
    public float getOwnerPredictability() {
        List<BotLearning.Action> pattern = BotLearning.forOwner(bot.getOwnerUUID()).getTopPattern();
        if (pattern == null || pattern.size() < 4) return 0.5f;
        return Math.min(1.0f, pattern.size() / 10.0f);
    }

    /** Сброс при смене цели. */
    public void reset() {
        histCount = 0;
        histHead  = 0;
        emaVx = emaVz = 0.0;
        activeCounter = CounterStrategy.NONE;
        baitStopTicks = 0;
        predictabilityCacheAge = 0;
    }

    // ══════════════════════════════════════════════════════════════
    //  Вычисление предсказуемости — Welford's online variance
    //  (нет List<Double>, нет double[] allocation)
    // ══════════════════════════════════════════════════════════════
    private float computePredictability() {
        if (histCount < 8) return 0.5f;

        // Welford's algorithm для угловой дисперсии
        double meanAngle = 0, M2angle = 0;
        double meanSpeed = 0, M2speed = 0;
        int n = 0;

        for (int i = 1; i < histCount; i++) {
            int cur  = (histHead - 1 - i + HISTORY_SIZE * 2) % HISTORY_SIZE;
            int prev = (cur - 1 + HISTORY_SIZE) % HISTORY_SIZE;
            float dx = posX[cur] - posX[prev];
            float dz = posZ[cur] - posZ[prev];
            float hDist = (float) Math.sqrt(dx * dx + dz * dz);

            // Скоростная дисперсия
            n++;
            double deltaSpeed = hDist - meanSpeed;
            meanSpeed += deltaSpeed / n;
            M2speed   += deltaSpeed * (hDist - meanSpeed);

            // Угловая дисперсия (только при движении)
            if (hDist > 0.01f) {
                double angle = Math.toDegrees(Math.atan2(-dx, dz));
                double delta = angleDiff(angle, meanAngle);
                meanAngle += delta / n;
                double delta2 = angleDiff(angle, meanAngle);
                M2angle   += delta * delta2;
            }
        }

        double angleVar = n > 1 ? M2angle / (n - 1) : 900.0;
        double speedVar = n > 1 ? M2speed / (n - 1) : 0.04;

        float anglePred = (float) Math.max(0, 1.0 - Math.min(angleVar / 900.0, 1.0));
        float speedPred = (float) Math.max(0, 1.0 - Math.min(speedVar / 0.04,  1.0));

        return anglePred * 0.7f + speedPred * 0.3f;
    }

    // ══════════════════════════════════════════════════════════════
    //  АнтиПаттерн
    // ══════════════════════════════════════════════════════════════
    private void tickAntiPattern() {
        if (--antiPatternTimer <= 0) {
            antiPatternYawBias = (rnd.nextFloat() - 0.5f) * 40f;
            antiActive = rnd.nextBoolean();
            antiPatternTimer = ANTI_PATTERN_MIN + rnd.nextInt(ANTI_PATTERN_MAX - ANTI_PATTERN_MIN);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Контр-паттерн
    // ══════════════════════════════════════════════════════════════
    private void tickCounterPattern() {
        // FIX #7: декремент baitStopTicks — только один раз за тик.
        // Раньше: общий декремент (строка выше) + повторный в блоке FEINT → таймер тикал вдвое быстрее.
        // Теперь: FEINT управляет своим таймером сам, общий декремент только для BAIT_STOP.
        if (activeCounter == CounterStrategy.TIMING_SHIFT) {
            // Синхронизируем фазу с attackCooldown бота
            timingShiftPhase += (float)(Math.PI * 2 / Math.max(1, PVPBotConfig.INSTANCE.attackCooldown));
        }
        // v2.1: FEINT — таймер рывка (единственный декремент)
        if (activeCounter == CounterStrategy.FEINT) {
            if (baitStopTicks > 0) {
                baitStopTicks--;
            } else {
                activeCounter = CounterStrategy.NONE; // рывок завершён
            }
        } else {
            // Для BAIT_STOP и остальных — обычный декремент
            if (baitStopTicks > 0) baitStopTicks--;
        }

        if (--counterReevalTimer > 0) return;
        counterReevalTimer = COUNTER_REEVAL_TICKS;

        float pred = getEnemyPredictability();
        if (pred < COUNTER_ACTIVATE_THRESHOLD) {
            activeCounter = CounterStrategy.NONE;
            return;
        }

        boolean dominantStrafe = isDominantStrafe();
        boolean dominantStop   = isDominantStop();

        if (dominantStop) {
            activeCounter = CounterStrategy.BAIT_STOP;
            baitStopTicks = 2 + rnd.nextInt(3); // 2-4 тика
        } else if (dominantStrafe) {
            // COUNTER агрессивнее — только при высокой предсказуемости
            activeCounter = pred > 0.80f
                ? CounterStrategy.STRAFE_COUNTER
                : CounterStrategy.STRAFE_MIRROR;
        } else if (pred > 0.85f && rnd.nextFloat() < 0.35f) {
            // v2.1: FEINT — ложный выпад при очень высокой предсказуемости
            // (враг всегда реагирует одинаково → обманываем его)
            activeCounter = CounterStrategy.FEINT;
            baitStopTicks = 4 + rnd.nextInt(4); // 4-7 тиков рывка
        } else {
            activeCounter = CounterStrategy.TIMING_SHIFT;
            timingShiftPhase = 0f;
        }
    }

    /** Доминирует ли страфинг: смена знака горизонтальной составляющей движения. */
    private boolean isDominantStrafe() {
        if (histCount < 6) return false;
        int changes = 0;
        float lastSign = 0f;
        for (int i = 1; i < histCount; i++) {
            int cur  = (histHead - 1 - i + HISTORY_SIZE * 2) % HISTORY_SIZE;
            int prev = (cur - 1 + HISTORY_SIZE) % HISTORY_SIZE;
            float dx = posX[cur] - posX[prev];
            float dz = posZ[cur] - posZ[prev];
            // Знак страфа = знак перпендикулярной составляющей (упрощённо)
            if (Math.abs(dx) > 0.04f || Math.abs(dz) > 0.04f) {
                float sign = Math.signum(dx + dz);
                if (sign != lastSign && lastSign != 0f) changes++;
                lastSign = sign;
            }
        }
        return changes >= 3;
    }

    /** Часто ли враг останавливается. */
    private boolean isDominantStop() {
        if (histCount < 8) return false;
        int stops = 0;
        for (int i = 1; i < histCount; i++) {
            int cur  = (histHead - 1 - i + HISTORY_SIZE * 2) % HISTORY_SIZE;
            int prev = (cur - 1 + HISTORY_SIZE) % HISTORY_SIZE;
            float dx = posX[cur] - posX[prev];
            float dz = posZ[cur] - posZ[prev];
            if (dx * dx + dz * dz < 0.0004f) stops++; // < 0.02 блока/тик
        }
        return (float) stops / (histCount - 1) > 0.4f;
    }

    private double angleDiff(double a, double b) {
        return ((a - b) % 360 + 540) % 360 - 180;
    }
}
