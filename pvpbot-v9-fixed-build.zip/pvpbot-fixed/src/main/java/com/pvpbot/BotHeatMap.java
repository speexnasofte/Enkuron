package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

import java.util.*;

/**
 * BotHeatMap v1.0 — тепловая карта боёв бота.
 *
 * Зачем нужен:
 *   Показывает владельцу где именно бот берёт урон и где наносит.
 *   Помогает понять "слепые зоны" арены или где бот постоянно проигрывает.
 *
 * Данные:
 *  - damageDealt:  Map<чанк-ключ → суммарный урон нанесён>
 *  - damageTaken:  Map<чанк-ключ → суммарный урон получен>
 *  - killPositions: List<BlockPos> — позиции убийств
 *  - deathPositions: List<BlockPos> — позиции смертей
 *
 * Отображение: !heatmap команда — топ-3 горячих точки урона/смертей
 *
 * Интеграция:
 *   bot.getHeatMap().recordDamageDealt(pos, amount);
 *   bot.getHeatMap().recordDamageTaken(pos, amount);
 *   bot.getHeatMap().recordKill(pos);
 *   bot.getHeatMap().recordDeath(pos);
 */
public class BotHeatMap {

    // ── Разрешение сетки (блоков на ячейку) ──────────────────────
    private static final int GRID  = 8;   // каждые 8 блоков — отдельная ячейка
    private static final int MAX_ENTRIES = 200; // защита от OOM

    private final BotEntity bot;

    // ── Данные ────────────────────────────────────────────────────
    private final Map<Long, Float> damageDealt  = new LinkedHashMap<>();
    private final Map<Long, Float> damageTaken  = new LinkedHashMap<>();
    private final List<BlockPos>   killPos      = new ArrayList<>();
    private final List<BlockPos>   deathPos     = new ArrayList<>();

    public BotHeatMap(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Запись событий
    // ══════════════════════════════════════════════════════════════

    public void recordDamageDealt(net.minecraft.world.phys.Vec3 pos, float amount) {
        long key = gridKey(pos);
        damageDealt.merge(key, amount, Float::sum);
        trimIfNeeded(damageDealt);
    }

    public void recordDamageTaken(net.minecraft.world.phys.Vec3 pos, float amount) {
        long key = gridKey(pos);
        damageTaken.merge(key, amount, Float::sum);
        trimIfNeeded(damageTaken);
    }

    public void recordKill(net.minecraft.world.phys.Vec3 pos) {
        if (killPos.size() < MAX_ENTRIES) killPos.add(BlockPos.containing(pos));
    }

    public void recordDeath(net.minecraft.world.phys.Vec3 pos) {
        if (deathPos.size() < MAX_ENTRIES) deathPos.add(BlockPos.containing(pos));
    }

    // ══════════════════════════════════════════════════════════════
    //  Отображение (!heatmap)
    // ══════════════════════════════════════════════════════════════

    public void sendReport(ServerPlayer player) {
        send(player, "§e§l🗺 HeatMap — " + bot.getName().getString() + ":");

        // Топ-3 зоны нанесённого урона
        send(player, "§a  Топ урона (нанесено):");
        getTopEntries(damageDealt, 3).forEach((key, dmg) -> {
            BlockPos p = gridKeyToCenter(key);
            send(player, String.format("    §f(%d,%d,%d) §a+%.0f dmg", p.getX(), p.getY(), p.getZ(), dmg));
        });

        // Топ-3 зоны полученного урона
        send(player, "§c  Топ урона (получено):");
        getTopEntries(damageTaken, 3).forEach((key, dmg) -> {
            BlockPos p = gridKeyToCenter(key);
            send(player, String.format("    §f(%d,%d,%d) §c-%.0f dmg", p.getX(), p.getY(), p.getZ(), dmg));
        });

        // Убийства и смерти
        send(player, String.format("§7  Всего: §aKills=%d §cDeaths=%d",
            killPos.size(), deathPos.size()));

        if (!deathPos.isEmpty()) {
            BlockPos lastDeath = deathPos.get(deathPos.size() - 1);
            send(player, String.format("§7  Последняя смерть: §c(%d,%d,%d)",
                lastDeath.getX(), lastDeath.getY(), lastDeath.getZ()));
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Вспомогательные
    // ══════════════════════════════════════════════════════════════

    /** Сброс всех данных. */
    public void reset() {
        damageDealt.clear();
        damageTaken.clear();
        killPos.clear();
        deathPos.clear();
    }

    /** Ключ сетки: упаковываем (gx, gy, gz) в long. */
    private static long gridKey(net.minecraft.world.phys.Vec3 pos) {
        int gx = (int) Math.floor(pos.x / GRID);
        int gz = (int) Math.floor(pos.z / GRID);
        int gy = (int) Math.floor(pos.y / GRID);
        // Упаковка: 21 бит на каждую ось (достаточно для -1M..1M)
        return ((long)(gx & 0x1FFFFF)) | ((long)(gy & 0x1FFFFF) << 21) | ((long)(gz & 0x1FFFFF) << 42);
    }

    /** Центр ячейки обратно в BlockPos. */
    private static BlockPos gridKeyToCenter(long key) {
        int gx = (int)(key & 0x1FFFFF);
        int gy = (int)((key >> 21) & 0x1FFFFF);
        int gz = (int)((key >> 42) & 0x1FFFFF);
        // Восстанавливаем знак (sign extension 21-bit)
        if (gx > 0xFFFFF) gx -= 0x200000;
        if (gy > 0xFFFFF) gy -= 0x200000;
        if (gz > 0xFFFFF) gz -= 0x200000;
        return new BlockPos(gx * GRID + GRID/2, gy * GRID + GRID/2, gz * GRID + GRID/2);
    }

    /** Топ-N записей по убыванию значения. */
    private static LinkedHashMap<Long, Float> getTopEntries(Map<Long, Float> map, int n) {
        LinkedHashMap<Long, Float> result = new LinkedHashMap<>();
        map.entrySet().stream()
            .sorted(Map.Entry.<Long, Float>comparingByValue().reversed())
            .limit(n)
            .forEach(e -> result.put(e.getKey(), e.getValue()));
        return result;
    }

    /** Защита от неограниченного роста карты. */
    private static void trimIfNeeded(Map<Long, Float> map) {
        if (map.size() <= MAX_ENTRIES) return;
        // Удаляем наименее активные записи (первый элемент LinkedHashMap — самый старый)
        Iterator<Long> it = map.keySet().iterator();
        while (map.size() > MAX_ENTRIES && it.hasNext()) {
            it.next(); it.remove();
        }
    }

    private void send(ServerPlayer player, String msg) {
        player.sendSystemMessage(Component.literal(msg));
    }
}
