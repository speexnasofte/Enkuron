# PVPBot v1.9.0 — Оптимизация PvP

## ⚔️ Боевые улучшения

### Крит-механика исправлена (PVPBotLogic + SwordLogic)
- Крит засчитывается только при `fallDistance > 0.08` — как в ванилле.
  Раньше бот мог атаковать в начале прыжка (урон без крита) или до приземления.
- Логика переписана: прыжок → ждём нисходящую фазу → только тогда удар.
  Теперь каждый запрыгивающий удар — настоящий крит.

### Attack Strength Charge в HARD/EXPERT (BotDifficultyAI)
- HARD и EXPERT теперь проверяют `getAttackStrengthScale >= minAttackCharge` перед атакой.
  Раньше HARD бил без ожидания заряда — урон был занижен на ~30%.

### W-tap добавлен в MEDIUM (BotDifficultyAI)
- После каждого удара MEDIUM останавливается на 2 тика (сбрасывает knockback momentum),
  как делает нормальный игрок. Урон per-hit вырастет на ~15–20%.

### Улучшен поиск цели (PVPBotLogic)
- Цель в воздухе: бонус `+0.35` (было `+0.2`) — бот агрессивнее преследует прыгающих.
- Цель пьёт зелье: бонус `+0.4` (было `+0.3`) — атакуем уязвимых.
- Щит: штраф `-0.5` (было `-0.4`) — меньше тратим время на блокирующих.
- **Новое:** бонус `+0.3` за атаку со спины (backDot < -0.7) — бот ищет фланг.

### Оборот к цели ускорен (PVPBotLogic)
- lerp поворота: `0.35 → 0.55` — бот догоняет стрейфящего игрока глазами быстрее,
  что критично для корректного `doHurtTarget`.

## 🏃 Движение / страф (StrafeAI)

- `APPROACH_SPEED`: `1.15 → 1.25` — быстрее сближение.
- `STRAFE_SPEED`: `0.95 → 1.02` — бот сложнее читается.
- `IDEAL_DIST`: `2.6 → 2.8` — держится чуть дальше от цели, меньше получает урона.
- `MAX_HORIZ_SPEED`: `0.22 → 0.25` — агрессивнее боковое движение.
- **Новое:** отступ при `dist < IDEAL_DIST - 0.4` — бот не стоит вплотную и не получает фул-дамаг.
- Spiral approach: blend `0.35 → 0.45`, делитель `4.0 → 3.0` — быстрее занимает позицию.

## 🗡️ SwordLogic

- `IDEAL_DIST`: `2.2 → 2.8` — согласовано с StrafeAI.
- Крит: требует `fallDistance > 0.08` вместо `> 0.01`, + обработка случая когда не взлетели.

## 🛡️ AutoRetreat

- `RETREAT_HP_THRESHOLD`: `6 → 7` — убегает чуть раньше.
- `RETURN_HP_THRESHOLD`: `12 → 14` — возвращается с большим HP-запасом.

## 🔧 EXPERT навигация

- `moveTo` скорость: `1.1 → 1.18` — EXPERT чуть агрессивнее давит.

# PVPBot v1.8.0 — Changelog

## ✨ Новые файлы (3 новых класса)

### `EnvironmentHazardAI.java` — защита от опасностей окружающей среды
- **FIRE** — бот горит → ищет воду в радиусе 10 блоков и бежит туда
- **LAVA** — бот в лаве → прыжок + навигация к ближайшему безопасному блоку
- **VOID_EDGE** — сканирует 8 направлений на обрыв ≥5 блоков → отступает
- **SUFFOCATION** — голова в блоке → движется вверх
- Приоритет выше боевой логики: при опасности `PVPBotLogic.tick()` делает `return`

### `BotTauntReact.java` — реакция на провокации в чате
- Детектирует ключевые слова: `noob`, `ez`, `trash`, `нуб`, `изи`, `мусор` и 25+ других
- Пишет ответ в чат из 10 случайных фраз (RU/EN), адресованных провокатору
- Переключает `TargetPriority.setForcedTarget()` на провокатора для всех ботов на 15 сек
- Временно повышает сложность до HARD, потом возвращает обратно
- Кулдаун 30 сек между ответами
- Управляется флагом `autoChatEnabled` из конфига

### `KitSuggester.java` — умный подбор кита по команде `!suggest`
- Определяет тип врага по предметам в руках (SWORD/AXE/BOW/CRYSTAL/MACE/TRIDENT)
- Матрица счётчиков: топор→меч, кристал→TPC, маса→страф+меч
- Читает `KitStatsTracker` — если реальный winRate говорит другое, доверяет ему
- Пишет в чат: рекомендацию + winRate + объяснение + альтернативу
- Подсказывает `!kit <id>` для применения

## 🔧 Изменения в существующих файлах

### `BotEntity.java`
- Добавлены поле `hazardAI` и геттер `getHazardAI()`

### `PVPBotLogic.java`
- `hazardAI.tick(sw)` вызывается с ранним выходом при опасности
- `getCachedEnemy()` стал публичным методом (используется KitSuggester)

### `PVPBotMod.java`
- `BotTauntReact.INSTANCE.tick()` добавлен в серверный тик (один раз на сервер)

### `ChatCommand.java`
- Команда `!suggest` → `KitSuggester.INSTANCE.suggest(...)`
- Провокации в чате → `BotTauntReact.INSTANCE.onPlayerMessage(...)`
- Строка `!suggest` добавлена в `!help`

# PVPBot v1.6.8 — Changelog (улучшения от v1.6.7-improved)

## 🐛 Баги исправлены

### Fix 1: `BotLearning` — синглтон заменён на per-owner реестр
- **Файл:** `BotLearning.java`
- **Проблема:** `BotLearning.INSTANCE` был один на весь сервер. При нескольких игроках,
  использующих `/bot learn`, все паттерны смешивались в один общий пул — бот одного
  игрока учился движению другого.
- **Фикс:** Добавлен статический реестр `Map<UUID, BotLearning>`. Новый метод
  `BotLearning.forOwner(UUID)` возвращает изолированный экземпляр для каждого владельца.
  `INSTANCE` (нулевой UUID) сохранён для обратной совместимости.
- **Очистка памяти:** `BotLearning.removeOwner(uuid)` вызывается при DISCONNECT игрока
  через обновлённый обработчик в `PVPBotMod.java`.

### Fix 2: `PVPBotMod` — BotLearning.INSTANCE.tick() → per-owner tick
- **Файл:** `PVPBotMod.java`
- **Проблема:** Серверный тик вызывал `BotLearning.INSTANCE.tick(sp)` для всех игроков
  одновременно — данные писались в один глобальный экземпляр.
- **Фикс:** Заменено на `BotLearning.forOwner(sp.getUUID()).tick(sp)`.

### Fix 3: `PatternAI` — getLearnedStrafeYaw / getOwnerPredictability
- **Файл:** `PatternAI.java`
- **Проблема:** Оба метода обращались к `BotLearning.INSTANCE` напрямую — не к
  паттернам своего владельца.
- **Фикс:** Добавлен приватный метод `getBotLearning()` который достаёт правильный
  экземпляр через `bot.getOwnerUUID()`.

## ✨ Новое

### Feature 1: `PatternAI` — CounterPatternEngine (контр-паттерны)
- **Файл:** `PatternAI.java`
- **Описание:** Добавлен активный анализ поведения врага и выбор контр-стратегии.
  Каждые 60 тиков `tickCounterPattern()` переоценивает `getEnemyPredictability()` и
  выбирает одну из четырёх стратегий:
  - `STRAFE_MIRROR` — зеркалит стрейф врага (срывает его атаку)
  - `STRAFE_COUNTER` — движется в противоположную сторону (уклонение)
  - `TIMING_SHIFT` — волновое смещение угла атаки ±15° чтобы сбить тайминг врага
  - `BAIT_STOP` — 3-тиковое торможение провоцирует преждевременную атаку врага
- Активируется при предсказуемости врага ≥ 0.65. При хаотичном движении — `NONE`.
- `getEnemyPredictability()` теперь учитывает не только угловую, но и скоростную
  дисперсию (скорость изменения — тоже признак паттерна).

### Feature 2: `PVPBotHud` — строка AI-переключателей
- **Файл:** `PVPBotHud.java`
- **Описание:** Добавлен новый метод `renderAiStatusRow()` — компактная строка над
  кнопками управления с тремя цветными индикаторами:
  - `[⛰T]` TerrainTactics — серый/зелёный
  - `[☠H]` ThreatAssessment — зелёный/жёлтый/красный по уровню угрозы
  - `[◈P]` PatternAI CounterStrategy — цвет по типу: MIR/CTR/TMG/BAIT
- REC-индикатор теперь использует `BotLearning.recordingOwners()` вместо
  `INSTANCE.isRecording()` — показывает запись любого владельца, не только глобальную.

---

# PVPBot v1.3.9 — Changelog (улучшения от v1.3.8-improved)

## 🐛 Баги исправлены

### Fix 1: `AutoPearl` — полный rewrite на серверную сторону
- **Файл:** `AutoPearl.java`
- **Проблема:** AutoPearl использовал `Minecraft` client, `KeyMapping` reflection и
  `gameMode.useItem()` — клиентский код недоступен/некорректен для серверного NPC-бота.
  На dedicated сервере это вызывало `NullPointerException` (Minecraft.getInstance() = null).
- **Фикс:** Полный rewrite: удалены все client-side зависимости. Перл спавнится через
  `ThrownEnderpearl` entity на `ServerLevel`. Сигнатура изменена:
  `tick(Minecraft)` → `tick(BotEntity)`.

### Fix 2: `PatternAI` — `new Random()` каждый тик (GC waste)
- **Файл:** `PatternAI.java`
- **Проблема:** В `tickAntiPattern()` каждые 30–80 тиков создавался `new Random()` —
  короткоживущий объект без нужды. На серверах с сотнями ботов — постоянный GC pressure.
- **Фикс:** Добавлено поле `private final Random rnd = new Random()` — единственный
  экземпляр на весь жизненный цикл PatternAI.

### Fix 3: `MotionPredictor` — накопление velocity на земле
- **Файл:** `MotionPredictor.java`
- **Проблема:** В цикле предсказания `onGround` не обновлялся при приземлении цели.
  Гравитация продолжала уменьшать `vel.y` даже "под землёй" → предсказанная позиция
  уходила вниз → промахи при метании зелий/перлов.
- **Фикс:** Добавлена проверка приземления в каждой итерации: при `pos.y <= groundY`
  и `vel.y <= 0` — `vy = 0`, `onGround = true`. Трение переключается корректно.

### Fix 4: `WeaponSwitcher` — END_CRYSTAL в mainhand
- **Файл:** `WeaponSwitcher.java`
- **Проблема:** `Items.END_CRYSTAL` — это блок, не оружие. `new ItemStack(Items.END_CRYSTAL)`
  в mainhand через `setItemSlot` ломало анимацию удара, melee-логику и краш в некоторых
  серверных конфигурациях. `WeaponSwitcher` не должен управлять кристаллами.
- **Фикс:** В CRYSTAL/TPC режиме на средней дистанции WeaponSwitcher даёт `NETHERITE_SWORD`.
  Кристальной логикой управляет `CrystalBotLogic` независимо.

### Fix 5: `AutoRetreat` — лечение продолжается после смерти цели
- **Файл:** `AutoRetreat.java`
- **Проблема:** `tickHealing()` не проверял `target.isAlive()`. Если цель умирала пока
  бот лечился — healTimer доматывался до конца, потом бот шёл к трупу в RETURNING фазе.
- **Фикс:** В начале `tickHealing()` добавлена проверка: если `target == null || !isAlive()`
  → `phase = FIGHTING`, `healTimer = 0`, выход.

## ✨ Улучшения

### Improvement 1: `TargetPriority` — динамический abandon range
- **Файл:** `TargetPriority.java`
- **Было:** фиксированный `ABANDON_RANGE = 32.0` блоков для всех сложностей.
- **Стало:** `getDynamicAbandonRange()` — зависит от `cfg.difficulty`:
  - `EASY`:   24 блока (не гоняется далеко)
  - `NORMAL`: 32 блока (базовое)
  - `HARD/EXPERT`: 48 блоков (агрессивное преследование)
  - `FOCUS` режим: 64 блока (никогда не бросает принудительную цель)

### Improvement 2: `AdaptiveCooldown` — правильный подсчёт TPS
- **Файл:** `AdaptiveCooldown.java`
- **Было:** `System.nanoTime()` измерял wall clock между тиками — включал время
  обработки других сущностей → TPS был занижен → кулдаун завышен даже без лага.
- **Стало:** Используется `MinecraftServer.getAverageTickTimeNanos()` — официальный
  серверный TPS. Fallback на wall clock если API недоступно.

### Improvement 3: `FakeAttack` — умное срабатывание
- **Файл:** `FakeAttack.java`
- **Было:** фиксированный 18% шанс фейк-атаки независимо от ситуации.
- **Стало:** Учитывается контекст:
  - Цель блокирует щитом → +15% (фейк заставит убрать щит)
  - Цель с высоким HP (>15) → -5% (не спешим)
  - Цель почти мертва (<4 HP) → 0% (не тратим тик, добиваем)
  - Бот при критическом HP (<6) → 0% (нужен реальный урон или retreat)

### Check 8: `BotLearning` — `patternFreq` unbounded growth
- **Файл:** `BotLearning.java`
- **Проблема:** `prunePatterns()` содержал мёртвый код (первый `stream().forEach(e→{})`)
  и обрезал Map только до `TOP_PATTERNS * 2 = 16` записей, порог был `TOP_PATTERNS * 3 = 24`.
- **Фикс:** Удалён мёртвый stream. Порог снижен до `TOP_PATTERNS * 2 = 16`,
  обрезка до `TOP_PATTERNS = 8`. Map больше не растёт бесконечно.

### Fix 7: `FakeAttack` — небезопасный каст `ServerLevel` в `tick()`
- **Файл:** `FakeAttack.java`
- **Проблема:** В `tick()` при нанесении настоящего удара после фейка использовался прямой
  каст `(ServerLevel) bot.level()` без проверки `instanceof`. Это `ClassCastException`
  при вызове из клиентского контекста или некоторых серверных конфигураций.
  Ниже в том же блоке уже был корректный `instanceof ServerLevel sw` — каст дублировал логику
  и был опасен.
- **Фикс:** Оба вызова (`doHurtTarget` и `playSound`) объединены в одну защищённую ветку
  `if (... && bot.level() instanceof ServerLevel sw)`. Лишний `instanceof` удалён.

### Fix 8: `BotLearning` — `lastOnGround` не обновляется при JUMP (`sampleAction`)
- **Файл:** `BotLearning.java`
- **Проблема:** В `sampleAction()` после определения прыжка (`!player.onGround() && lastOnGround`)
  метод немедленно возвращал `Action.JUMP` без обновления `lastOnGround = false`.
  `lastOnGround` обновлялся только в конце метода, до которого выполнение не доходило.
  Следствие: при любом прыжке `Action.JUMP` фиксировался каждый тик пока игрок в воздухе,
  а не один раз при отрыве от земли — паттерн «переспамлен» прыжками.
- **Фикс:** `lastOnGround = false` перемещён перед `return Action.JUMP`.

## 📝 Изменённые файлы
- `AutoPearl.java` (полный rewrite)
- `PatternAI.java`
- `MotionPredictor.java`
- `WeaponSwitcher.java`
- `AutoRetreat.java`
- `TargetPriority.java`
- `AdaptiveCooldown.java`
- `FakeAttack.java`
- `BotLearning.java`

### Fix 6: `BotEntityRenderer` — броня не отображалась на модели бота
- **Файл:** `client/BotEntityRenderer.java`
- **Проблема:** `HumanoidMobRenderer` рендерит только базовую модель (тело Стива).
  Броня в MC рендерится отдельным слоем — `HumanoidArmorLayer`. Без него
  `setItemSlot(HEAD/CHEST/LEGS/FEET, ...)` работает на сервере (защита считается),
  но клиент ничего не рисует → бот всегда выглядит как голый Стив.
- **Фикс:** В конструктор добавлен `this.addLayer(new HumanoidArmorLayer(...))` с
  `PLAYER_INNER_ARMOR` и `PLAYER_OUTER_ARMOR` слоями.
