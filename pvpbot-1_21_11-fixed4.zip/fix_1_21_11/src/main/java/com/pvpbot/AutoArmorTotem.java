package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;

/**
 * AutoArmor — автоматически экипирует лучшую броню из инвентаря.
 * AutoTotem — держит тотем бессмертия в левой (offhand) руке.
 *
 * ✅ FIX 1.21.1: Убран Equippable (появился в 1.21.2), используем ArmorItem.
 */
public class AutoArmorTotem {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int checkTimer = 0;

    public void tick(Minecraft mc) {
        if (mc.player == null) return;
        checkTimer--;
        if (checkTimer > 0) return;
        checkTimer = 20;

        if (cfg.autoTotem) equipTotem(mc.player);
        if (cfg.autoArmor) equipBestArmor(mc.player);
    }

    // ── Авто-тотем ──────────────────────────────────────────────
    private void equipTotem(Player player) {
        ItemStack offhand = player.getOffhandItem();
        if (offhand.is(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(Items.TOTEM_OF_UNDYING)) {
                player.getInventory().offhand.set(0, stack.copy());
                player.getInventory().removeItem(i, 1);
                return;
            }
        }
    }

    // ── Авто-броня ──────────────────────────────────────────────
    private void equipBestArmor(Player player) {
        tryEquipSlot(player, EquipmentSlot.HEAD);
        tryEquipSlot(player, EquipmentSlot.CHEST);
        tryEquipSlot(player, EquipmentSlot.LEGS);
        tryEquipSlot(player, EquipmentSlot.FEET);
    }

    private void tryEquipSlot(Player player, EquipmentSlot slot) {
        ItemStack current = player.getItemBySlot(slot);
        int currentProt = armorProtection(current, slot);

        int bestSlot = -1;
        int bestProt = currentProt;

        for (int i = 0; i < player.getInventory().items.size(); i++) {
            ItemStack stack = player.getInventory().items.get(i);
            if (fitsSlot(stack, slot)) {
                int prot = armorProtection(stack, slot);
                if (prot > bestProt) {
                    bestProt = prot;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != -1) {
            ItemStack best = player.getInventory().items.get(bestSlot).copy();
            player.getInventory().items.set(bestSlot, current.isEmpty() ? ItemStack.EMPTY : current.copy());
            player.setItemSlot(slot, best);
        }
    }

    /** В 1.21.1 проверяем слот через ArmorItem */
    private boolean fitsSlot(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item instanceof ArmorItem armor) {
            return armor.getEquipmentSlot() == slot;
        }
        return false;
    }

    private int armorProtection(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty()) return 0;
        Item item = stack.getItem();
        if (!(item instanceof ArmorItem armor)) return 0;
        int base = armor.getDefense();

        var enchComp = stack.get(net.minecraft.core.component.DataComponents.ENCHANTMENTS);
        if (enchComp == null) return base;

        int enchBonus = 0;
        for (var enchEntry : enchComp.entrySet()) {
            String enchId = enchEntry.getKey().unwrapKey().map(k -> k.location().toString()).orElse("");
            if (enchId.contains("protection")) {
                enchBonus += enchEntry.getIntValue() * 4;
            }
        }
        return base + enchBonus;
    }
}
