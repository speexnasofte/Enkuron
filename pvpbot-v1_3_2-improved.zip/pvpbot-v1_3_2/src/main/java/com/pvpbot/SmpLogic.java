package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;

/**
 * SmpLogic v5.0 — MCTiers SMP (улучшено v1.3.2).
 *
 * Kit: Netherite полная броня (Sharp5+KB1+FA2 меч, топор Sharp5+Eff5)
 *   Эндер жемчуг 16, Golden Apple 64
 *   Зелья: Strength II, Speed II, FireResistance(long)
 *   Тотем offhand, щит Mend+Unb3
 *
 * Что улучшено в v5.0:
 *  ✅ Combo: 3 удара мечом → 1 удар топором (прерывает щит + дополнительный урон)
 *  ✅ Умная смена оружия: топор при блоке, меч для DPS, лук при дист >8
 *  ✅ W-tap реализован правильно: стоп навигации сразу после удара
 *  ✅ Retreat только при HP < RETREAT_HP И если цель агрессивная (урон недавно)
 *  ✅ Gap прерывает retreat — съедаем яблоко и сразу атакуем
 *  ✅ Страф ZIGZAG при высоком HP, CIRCLE при низком (меньше предсказуем)
 *  ✅ Прыжок-крит каждые 3 удара (не каждые 4)
 *  ✅ Лук при dist > 8 если цель не движется к нам
 *  ✅ Fire Aspect поджог: добавляем огонь через setRemainingFireTicks
 *  ✅ Тотем ВСЕГДА в оффхенд — проверяется КАЖДЫЙ тик
 */
public class SmpLogic {

    // ── Дистанции ─────────────────────────────────────────────────
    private static final double MELEE_RANGE  = 3.0;
    private static final double AXE_RANGE    = 3.5;
    private static final double BOW_RANGE    = 8.0;
    private static final double PEARL_RANGE  = 11.0;
    private static final double IDEAL_DIST   = 2.4;

    // ── HP пороги ─────────────────────────────────────────────────
    private static final float  GAP_HP       = 12.0f;   // Съедаем gapple
    private static final float  SHIELD_HP    = 14.0f;   // Начинаем блокировать
    private static final float  RETREAT_HP   = 5.0f;    // Отступаем

    // ── Кулдауны (тики) ───────────────────────────────────────────
    private static final int    ATTACK_CD    = 10;
    private static final int    AXE_CD       = 20;      // топор быстрее (было 22)
    private static final int    BOW_CD       = 18;
    private static final int    SHIELD_DUR   = 20;      // блок короче (было 25)
    private static final int    GAP_CD       = 200;     // чуть быстрее (было 220)
    private static final int    PEARL_CD     = 80;
    private static final int    SPEED_CD     = 400;
    private static final int    STR_CD       = 400;
    private static final int    FIRE_RES_CD  = 600;
    private static final int    RETREAT_CD   = 100;
    private static final int    WTAP_PAUSE   = 2;       // тики стопа для W-tap
    private static final int    CRIT_EVERY   = 3;       // крит каждые 3 удара (было 4)
    private static final int    COMBO_AXE_AT = 3;       // топор после N ударов мечом

    private enum State { FIGHTING, BLOCKING, RETREATING }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int attackCd      = 0;
    private int axeCd         = 0;
    private int bowCd         = 0;
    private int shieldTimer   = 0;
    private int gapCd         = 0;
    private int pearlCd       = 0;
    private int speedCd       = 0;
    private int strCd         = 0;
    private int fireResCd     = 0;
    private int retreatCd     = 0;
    private int wTapPause     = 0;   // пауза после удара (W-tap)
    private int hitCount      = 0;   // счётчик ударов мечом
    private int comboCount    = 0;   // счётчик combo (меч → топор)
    private boolean critPending    = false;
    private boolean shieldDisabled = false;
    private int shieldDisTimer = 0;

    // Отслеживаем входящий урон для умного retreat
    private float lastReceivedDamage = 0;
    private int   lastDamageTick     = 0;
    private int   tickCount          = 0;

    public SmpLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        // Начинаем с ZIGZAG — более агрессивный страф
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    /** Вызывается когда бот получил урон — для умного retreat */
    public void onDamageReceived(float amount) {
        lastReceivedDamage = amount;
        lastDamageTick     = tickCount;
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { strafe.tick(null); return; }

        tickCount++;

        // ── Тик кулдаунов ─────────────────────────────────────────
        if (attackCd     > 0) attackCd--;
        if (axeCd        > 0) axeCd--;
        if (bowCd        > 0) bowCd--;
        if (shieldTimer  > 0) shieldTimer--;
        if (gapCd        > 0) gapCd--;
        if (pearlCd      > 0) pearlCd--;
        if (speedCd      > 0) speedCd--;
        if (strCd        > 0) strCd--;
        if (fireResCd    > 0) fireResCd--;
        if (retreatCd    > 0) retreatCd--;
        if (wTapPause    > 0) wTapPause--;
        if (shieldDisTimer > 0) { shieldDisTimer--; if (shieldDisTimer <= 0) shieldDisabled = false; }

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── ПРИОРИТЕТ 1: Тотем в оффхенд ВСЕГДА ─────────────────
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // ── ПРИОРИТЕТ 2: Баффы ────────────────────────────────────
        if (speedCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 800, 1));
            speedCd = SPEED_CD;
        }
        if (strCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 800, 1));
            strCd = STR_CD;
        }
        if (bot.isOnFire() && fireResCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
            fireResCd = FIRE_RES_CD;
        }

        // ── ПРИОРИТЕТ 3: Золотое яблоко при низком HP ─────────────
        if (myHp < GAP_HP && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
            // После gap — выходим из retreat, сразу атакуем
            if (state == State.RETREATING) {
                state = State.FIGHTING;
            }
        }

        // ── ПРИОРИТЕТ 4: Эндер жемчуг для сближения ──────────────
        if (cfg.pearlEnabled && dist > PEARL_RANGE && pearlCd <= 0) {
            bot.setSprinting(true);
            bot.getNavigation().moveTo(target, 1.6);
            sw.sendParticles(ParticleTypes.PORTAL,
                bot.getX(), bot.getY()+1, bot.getZ(), 20, 0.5,0.5,0.5,0.3);
            bot.playSound(SoundEvents.ENDER_PEARL_THROW, 1.0f, 1.0f);
            pearlCd = PEARL_CD;
            return;
        }

        // ── Переходы состояний ────────────────────────────────────
        // Retreat только если недавно получали урон (реально опасно)
        boolean recentlyDamaged = (tickCount - lastDamageTick) < 40; // в последние 2 секунды
        if (myHp < RETREAT_HP && retreatCd <= 0 && recentlyDamaged) {
            state = State.RETREATING;
            retreatCd = RETREAT_CD;
        }
        // Переход в блок при среднем HP
        if (myHp < SHIELD_HP && myHp >= RETREAT_HP && shieldTimer <= 0 && state == State.FIGHTING) {
            state = State.BLOCKING;
            shieldTimer = SHIELD_DUR;
            // При блоке — CIRCLE страф (предсказуемее, но безопаснее)
            strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
        }
        if (state == State.BLOCKING && shieldTimer <= 0) {
            state = State.FIGHTING;
            strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
        }
        if (state == State.RETREATING && (dist > 9.0 || myHp > SHIELD_HP)) {
            state = State.FIGHTING;
        }

        switch (state) {
            case FIGHTING   -> tickFighting(sw, target, dist);
            case BLOCKING   -> tickBlocking(target);
            case RETREATING -> tickRetreating(target);
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        // Навигация
        if (dist > IDEAL_DIST + 0.8) bot.getNavigation().moveTo(target, 1.0);
        else if (dist < IDEAL_DIST - 0.4) bot.getNavigation().stop();

        // W-tap: если пауза активна — стопим движение
        if (wTapPause > 0) {
            bot.getNavigation().stop();
        }

        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (dist < MELEE_RANGE + 2.0) strafe.tick(target);

        boolean blocking = isTargetBlocking(target);

        // ── Лук на дальней дистанции ─────────────────────────────
        if (dist > BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND,
                EnchantUtil.of(Items.BOW).enchant("power", 5).enchant("infinity", 1).build());
            bot.getLookControl().setLookAt(target, 60f, 60f);
            // Симулируем выстрел: прямой урон с учётом дистанции
            float bowDmg = (float) Math.max(2.0, 9.5 - dist * 0.25);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), bowDmg);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.2f);
            // Регистрируем удар для HUD подсветки
            HitHighlightTracker.INSTANCE.onHit(target.getId());
            bowCd = BOW_CD;
            return;
        }

        // ── Combo: топор после COMBO_AXE_AT ударов мечом ─────────
        if (comboCount >= COMBO_AXE_AT && dist <= AXE_RANGE && axeCd <= 0) {
            doAxeHit(sw, target);
            comboCount = 0;
            return;
        }

        // ── Топор для слома щита ──────────────────────────────────
        if (blocking && dist <= AXE_RANGE && axeCd <= 0) {
            doAxeHit(sw, target);
            return;
        }

        // ── Меч DPS ───────────────────────────────────────────────
        if (dist <= MELEE_RANGE && attackCd <= 0 && wTapPause <= 0) {
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump();
                critPending = true;
                attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doSwordHit(sw, target, true);
                critPending = false;
            } else if (!doCrit) {
                doSwordHit(sw, target, false);
                critPending = false;
            }
        }
    }

    private void doSwordHit(ServerLevel sw, LivingEntity target, boolean crit) {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_SWORD)
                .enchant("sharpness", 5)
                .enchant("knockback", 1)
                .enchant("fire_aspect", 2)
                .build());

        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Fire Aspect: поджигаем цель вручную (дополнительная надёжность)
        if (target.getRemainingFireTicks() <= 0) {
            target.setRemainingFireTicks(80); // 4 секунды огня
        }

        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 6, 0.2,0.2,0.2,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            bot.playSound(SoundEvents.PLAYER_ATTACK_STRONG, 0.9f, 1.0f);
        }

        hitCount++;
        comboCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : ATTACK_CD;

        // W-tap: пауза чтобы knockback сработал, потом снова бежать
        if (cfg.wTapEnabled) wTapPause = WTAP_PAUSE;
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND,
            EnchantUtil.of(Items.NETHERITE_AXE)
                .enchant("sharpness", 5)
                .enchant("efficiency", 5)
                .build());

        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Топор ломает щит
        shieldDisabled = true;
        shieldDisTimer = 100;

        sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
            target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
        bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);

        // HUD подсветка (регистрируется в doHurtTarget override, но на всякий случай явно)
        HitHighlightTracker.INSTANCE.onHit(target.getId());

        axeCd = AXE_CD;
        // После топора — стоп W-tap
        if (cfg.wTapEnabled) wTapPause = WTAP_PAUSE;
    }

    private void tickBlocking(LivingEntity target) {
        // Щит в MAINHAND — тотем остаётся в offhand (проверяется в начале tick)
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.SHIELD));

        // Отходим чуть назад при слишком близкой цели
        if (bot.distanceTo(target) < 2.5) {
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(0.12);
            Vec3 cur  = bot.getDeltaMovement();
            bot.setDeltaMovement(cur.x + away.x, cur.y, cur.z + away.z);
        }
        // Страф круговой при блоке
        strafe.tick(target);
    }

    private void tickRetreating(LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 9,
            bot.getY(),
            bot.getZ() + away.z * 9,
            1.25
        );
        bot.setSprinting(true);
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }
}
