package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.network.chat.Component;

/**
 * Авто-респавн: обнаруживает экран смерти и автоматически нажимает «Respawn».
 *
 * FIX v2: исправлен краш/чёрный экран при смерти игрока.
 *  - respawn() и setScreen(null) вызываются через mc.execute() (безопасно для render-треда)
 *  - Двойная проверка mc.player != null
 *  - Delay увеличен с 20 до 30 тиков — серверы медленнее регистрируют смерть
 *  - setScreen(null) вызывается отдельным execute() после respawn()
 */
public class AutoRespawn {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int  deathTimer = 0;
    private int  resetTimer = 0;
    private boolean wasDead = false;

    public void tick(Minecraft mc) {
        if (!cfg.autoRespawn) {
            deathTimer = 0;
            resetTimer = 0;
            wasDead    = false;
            return;
        }

        // FIX v3: если нет активного соединения с миром — не трогаем DeathScreen.
        // Именно это вызывало чёрный экран и зависание: мод пытался сделать
        // setScreen(null) пока mc.level == null (переход между мирами, одиночная игра).
        if (mc.level == null) {
            deathTimer = 0;
            resetTimer = 0;
            wasDead    = false;
            return;
        }

        if (mc.screen instanceof DeathScreen) {
            resetTimer = 0;
            deathTimer++;

            // 30 тиков = 1.5 сек — ждём чтобы сервер подтвердил смерть
            if (deathTimer >= 30 && !wasDead) {
                wasDead = true;
                doRespawn(mc);
            }
        } else {
            if (wasDead) {
                resetTimer++;
                if (resetTimer >= 10) {
                    wasDead    = false;
                    deathTimer = 0;
                    resetTimer = 0;
                }
            } else {
                deathTimer = 0;
                resetTimer = 0;
            }
        }
    }

    /**
     * FIX v3: КРИТИЧЕСКИЙ фикс чёрного экрана и зависания при смерти.
     *
     * Проблема: setScreen(null) вызывался когда mc.level == null (игрок не в мире),
     * что вешало рендер-тред на ожидание соединения и давало чёрный экран.
     *
     * Решение:
     *  1. Проверяем mc.level != null перед respawn() — только если мы реально в мире
     *  2. setScreen(null) вызываем только если screen ВСЁ ЕЩЁ DeathScreen (не сменился)
     *  3. Задержка между respawn() и setScreen() увеличена до 3 execute() чтобы сервер
     *     гарантированно обработал пакет респауна до сброса экрана
     *  4. Весь код обёрнут в try-catch чтобы один краш не вешал весь клиент
     */
    private void doRespawn(Minecraft mc) {
        mc.execute(() -> {
            // КРИТИЧНО: без mc.level игрок не в мире — нельзя делать respawn()
            if (mc.player == null || mc.level == null) return;
            // Проверяем что экран смерти ещё активен
            if (!(mc.screen instanceof DeathScreen)) return;
            try {
                mc.player.respawn();
            } catch (Exception ignored) {
                // Пакет уже был отправлен или соединение нестабильно — игнорируем
            }
            // execute #2 — ждём обработки сервером
            mc.execute(() -> {
                // execute #3 — дополнительная задержка на медленных серверах
                mc.execute(() -> {
                    try {
                        // Закрываем экран смерти ТОЛЬКО если он всё ещё открыт
                        // и игрок всё ещё живой (mc.level != null значит мы в мире)
                        if (mc.screen instanceof DeathScreen && mc.level != null) {
                            mc.setScreen(null);
                        }
                        if (mc.player != null && mc.gui != null) {
                            mc.gui.getChat().addMessage(
                                Component.literal("§a[PVPBot] §fАвто-респавн!")
                            );
                        }
                    } catch (Exception ignored) {
                        // Не крашим клиент если что-то пошло не так
                    }
                });
            });
        });
    }
}
