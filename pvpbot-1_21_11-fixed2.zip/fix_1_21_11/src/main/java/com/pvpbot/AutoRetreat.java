package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * AutoRetreat — система авто-отступления бота (v12).
 *
 * Фазы:
 *   FIGHTING  → обычный бой
 *   RETREATING → HP упал ниже порога → бот убегает от цели
 *   HEALING   → бот остановился, использует зелья/еду/тотем
 *   RETURNING → HP восстановлен → бот возвращается к цели
 *
 * Триггер: HP < retreatHpThreshold (по умолчанию 6 = 3 сердца)
 * Возврат:  HP > returnHpThreshold  (по умолчанию 16 = 8 сердец)
 */
public class AutoRetreat {

    public enum RetreatPhase { FIGHTING, RETREATING, HEALING, RETURNING }

    // ── Настройки ─────────────────────────────────────────────────
    private static final float  RETREAT_HP_THRESHOLD = 6.0f;
    private static final float  RETURN_HP_THRESHOLD  = 16.0f;
    private static final double RETREAT_DISTANCE     = 12.0; // блоков от цели
    private static final double RETREAT_SPEED        = 1.5;  // множитель скорости
    private static final int    HEAL_DURATION        = 60;   // тиков лечения
    private static final int    RETREAT_COOLDOWN     = 200;  // тиков между отступлениями

    // ── Состояние ─────────────────────────────────────────────────
    private RetreatPhase phase      = RetreatPhase.FIGHTING;
    private int          healTimer  = 0;
    private int          cooldown   = 0;
    private Vec3        retreatPos = null;

    private final BotEntity bot;

    public AutoRetreat(BotEntity bot) {
        this.bot = bot;
    }

    public RetreatPhase getPhase() { return phase; }
    public boolean isRetreating()  { return phase != RetreatPhase.FIGHTING; }

    /**
     * Главный тик. Вызывается из BotDifficultyAI каждый тик.
     * Возвращает true если бот сейчас НЕ должен атаковать (отступает/лечится).
     */
    public boolean tick(LivingEntity target) {
        if (cooldown > 0) cooldown--;

        return switch (phase) {
            case FIGHTING   -> tickFighting(target);
            case RETREATING -> tickRetreating(target);
            case HEALING    -> tickHealing(target);
            case RETURNING  -> tickReturning(target);
            default     -> false;
        };
    }

    // ─────────────────────────────────────────────────────────────

    private boolean tickFighting(LivingEntity target) {
        // Проверяем нужно ли отступать
        if (cooldown <= 0 && bot.getHealth() <= RETREAT_HP_THRESHOLD) {
            startRetreat(target);
            return true;
        }
        return false;
    }

    private boolean tickRetreating(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }

        double dist = bot.distanceTo(target);

        if (dist >= RETREAT_DISTANCE) {
            // Достаточно далеко — начинаем лечиться
            phase = RetreatPhase.HEALING;
            healTimer = HEAL_DURATION;
            bot.getNavigation().stop();
        } else {
            // Бежим от цели
            Vec3 away = bot.position().subtract(target.position()).normalize().scale(RETREAT_SPEED);
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 5,
                bot.getY(),
                bot.getZ() + away.z * 5,
                1.6
            );
            // Снять цель — не атаковать во время бегства
            bot.setTarget(null);
        }
        return true;
    }

    private boolean tickHealing(LivingEntity target) {
        healTimer--;

        // Симулируем использование лечебного предмета
        useHealItem();

        if (healTimer <= 0 || bot.getHealth() >= RETURN_HP_THRESHOLD) {
            phase = RetreatPhase.RETURNING;
        }
        return true;
    }

    private boolean tickReturning(LivingEntity target) {
        if (target == null || !target.isAlive()) {
            phase = RetreatPhase.FIGHTING;
            return false;
        }

        double dist = bot.distanceTo(target);

        if (dist <= PVPBotConfig.INSTANCE.attackRange + 1.0) {
            // Вернулись к цели
            phase = RetreatPhase.FIGHTING;
            cooldown = RETREAT_COOLDOWN;
            bot.setTarget(target);
            return false;
        }

        // Идём к цели
        bot.getNavigation().moveTo(target, 1.4);
        return true;
    }

    private void startRetreat(LivingEntity target) {
        phase = RetreatPhase.RETREATING;
        Vec3 away = bot.position().subtract(target.position()).normalize();
        retreatPos = bot.position().add(away.scale(RETREAT_DISTANCE));
    }

    /** Использовать лечебный предмет из инвентаря. */
    private void useHealItem() {
        // Проверяем MAINHAND и OFFHAND
        for (net.minecraft.world.entity.EquipmentSlot slot : new net.minecraft.world.entity.EquipmentSlot[]{
                net.minecraft.world.entity.EquipmentSlot.MAINHAND,
                net.minecraft.world.entity.EquipmentSlot.OFFHAND}) {
            ItemStack stack = bot.getItemBySlot(slot);
            if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                bot.heal(8.0f);
                // Добавляем Absorption IV и Regen II как EnchGap
                bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.ABSORPTION, 2400, 3));
                bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.REGENERATION, 600, 1));
                stack.shrink(1);
                return;
            }
            if (stack.is(Items.GOLDEN_APPLE)) {
                bot.heal(4.0f);
                bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.ABSORPTION, 2400, 0));
                bot.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.REGENERATION, 100, 1));
                stack.shrink(1);
                return;
            }
        }
        // Fallback — пассивная регенерация (scaled по недостающему HP)
        float missing = bot.getMaxHealth() - bot.getHealth();
        bot.heal(Math.min(1.0f, missing * 0.05f));
    }
}
