package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;

/**
 * ModeLogicDispatcher v5.0 — MCTiers.
 *
 * Режимы: SWORD, AXE, MACE, MACE_ELYTRA, UHC, NETHOP, POT, SMP, CRYSTAL
 * Удалены нереальные MCTiers режимы: TPC, BEEHIVE, FIREWORK, CROSSBOW, TRIDENT, TOTEM, SNOWBALL
 */
public class ModeLogicDispatcher {

    private final BotEntity bot;

    private SwordLogic      swordLogic;
    private AxeLogic        axeLogic;
    private UhcLogic        uhcLogic;
    private NethPotLogic    nethPotLogic;   // используется для POT и NETHOP
    private SmpLogic        smpLogic;
    private MaceLogic       maceLogic;
    private MaceElytraLogic maceElytraLogic;
    private CrystalBotLogic crystalBotLogic;

    private PVPBotConfig.Mode lastMode = null;

    public ModeLogicDispatcher(BotEntity bot) {
        this.bot = bot;
    }

    public boolean tick(LivingEntity target) {
        PVPBotConfig.Mode mode = PVPBotConfig.INSTANCE.mode;
        if (mode == null) return false;

        if (mode != lastMode) {
            onModeChanged();
            lastMode = mode;
        }

        switch (mode) {
            case SWORD       -> getSword().tick(target);
            case AXE         -> getAxe().tick(target);
            case UHC         -> getUhc().tick(target);
            case POT, NETHOP -> getNethPot().tick(target);
            case SMP         -> getSmp().tick(target);
            case MACE        -> getMace().tick(target);
            case MACE_ELYTRA -> getMaceElytra().tick(target);
            case CRYSTAL     -> getCrystal().tick(
                (net.minecraft.server.level.ServerLevel) bot.level(), target);
            default -> {}
        }
        return true;
    }

    private SwordLogic      getSword()     { if (swordLogic      == null) swordLogic      = new SwordLogic(bot);      return swordLogic;      }
    private AxeLogic        getAxe()       { if (axeLogic        == null) axeLogic        = new AxeLogic(bot);        return axeLogic;        }
    private UhcLogic        getUhc()       { if (uhcLogic        == null) uhcLogic        = new UhcLogic(bot);        return uhcLogic;        }
    private NethPotLogic    getNethPot()   { if (nethPotLogic    == null) nethPotLogic    = new NethPotLogic(bot);    return nethPotLogic;    }
    private SmpLogic        getSmp()       { if (smpLogic        == null) smpLogic        = new SmpLogic(bot);        return smpLogic;        }
    private MaceLogic       getMace()      { if (maceLogic       == null) maceLogic       = new MaceLogic(bot);       return maceLogic;       }
    private MaceElytraLogic getMaceElytra(){ if (maceElytraLogic == null) maceElytraLogic = new MaceElytraLogic(bot); return maceElytraLogic; }
    private CrystalBotLogic getCrystal()  { if (crystalBotLogic == null) crystalBotLogic = new CrystalBotLogic(bot); return crystalBotLogic; }

    private void onModeChanged() {
        // Сбрасываем все логики при смене режима
        swordLogic      = null;
        axeLogic        = null;
        uhcLogic        = null;
        nethPotLogic    = null;
        smpLogic        = null;
        maceLogic       = null;
        maceElytraLogic = null;
        crystalBotLogic = null;
    }

    public String getStatusLabel() {
        return switch (PVPBotConfig.INSTANCE.mode) {
            case SWORD       -> "SWORD";
            case AXE         -> "AXE";
            case UHC         -> "UHC";
            case POT         -> "POT";
            case NETHOP      -> "NETHOP";
            case SMP         -> "SMP";
            case MACE        -> maceLogic != null ? getMace().getStateLabel() : "MACE:INIT";
            case MACE_ELYTRA -> maceElytraLogic != null ? getMaceElytra().getStateLabel() : "ME:INIT";
            case CRYSTAL     -> crystalBotLogic != null ? getCrystal().getPhaseLabel() : "CRYS:INIT";
            default          -> "?";
        };
    }
}
