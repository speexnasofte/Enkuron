package com.pvpbot;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/**
 * ObsidianPlacer v2.0
 *
 * Кладёт обсидиан вокруг ног цели крестом — база под кристаллы.
 * За один тик — один блок (реалистично).
 * Приоритет: сначала блок прямо под ногами, потом крест вокруг.
 */
public class ObsidianPlacer {

    private int cd = 0;
    private static final int INTERVAL = 4; // тиков между укладкой
    private static final double MAX_DIST = 7.0;

    // Крест: центр + 4 стороны + диагонали
    private static final int[] DX = { 0,  1, -1,  0,  0,  1, -1,  1, -1 };
    private static final int[] DZ = { 0,  0,  0,  1, -1,  1, -1, -1,  1 };

    public void tick(ServerLevel level, LivingEntity bot, LivingEntity target) {
        if (cd-- > 0) return;
        cd = INTERVAL;

        if (bot.position().distanceTo(target.position()) > MAX_DIST) return;

        // Слой ПОД ногами цели
        BlockPos base = target.blockPosition().below();

        for (int i = 0; i < DX.length; i++) {
            BlockPos pos = base.offset(DX[i], 0, DZ[i]);
            var block = level.getBlockState(pos).getBlock();

            // Уже хорошая база — пропускаем
            if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) continue;

            // Ставим если воздух или заменяемо
            if (level.getBlockState(pos).isAir() || level.getBlockState(pos).canBeReplaced()) {
                level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), 3);
                return; // один блок за тик
            }
        }
    }

    /** Есть ли обсидиан/бедрок рядом с целью для постановки кристалла */
    public static boolean hasBase(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition().below();
        for (int i = 0; i < DX.length; i++) {
            BlockPos pos = base.offset(DX[i], 0, DZ[i]);
            var b = level.getBlockState(pos).getBlock();
            if (b == Blocks.OBSIDIAN || b == Blocks.BEDROCK) return true;
        }
        return false;
    }

    /** Возвращает первую валидную позицию для кристалла (верх обсидиана) или null */
    public static BlockPos findCrystalBase(ServerLevel level, LivingEntity target) {
        BlockPos base = target.blockPosition().below();
        for (int i = 0; i < DX.length; i++) {
            BlockPos obsPos   = base.offset(DX[i], 0, DZ[i]);
            BlockPos placePos = obsPos.above(); // куда ставить кристалл

            var b = level.getBlockState(obsPos).getBlock();
            if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) continue;
            if (!level.getBlockState(placePos).isAir()) continue;
            if (!level.getBlockState(placePos.above()).isAir()) continue;

            return obsPos; // возвращаем позицию обсидиана (кристалл ставится .above())
        }
        return null;
    }
}
