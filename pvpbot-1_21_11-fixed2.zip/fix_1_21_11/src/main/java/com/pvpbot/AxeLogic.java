package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * AxeLogic v4.0 — MCTiers Axe PvP.
 *
 * Kit: Diamond броня БЕЗ зачар, Diamond Axe + Diamond Sword + Bow + Crossbow + Shield
 *
 * Тактика:
 *  - Топор ломает щит цели → затем бёрст мечом пока щит сломан
 *  - Арбалет/лук на дистанции если цель держит щит
 *  - Щит в оффхенд против входящих атак
 *  - Крит-прыжки каждые N ударов
 */
public class AxeLogic {

    private static final double MELEE_RANGE    = 3.2;
    private static final double IDEAL_DIST     = 2.6;
    private static final double RANGED_DIST    = 10.0;
    private static final int    AXE_CD         = 22;
    private static final int    SHIELD_DIS_DUR = 100;
    private static final int    BURST_CD       = 8;
    private static final int    BURST_COUNT    = 3;
    private static final int    DASH_CD        = 70;
    private static final int    CRIT_EVERY     = 3;
    private static final int    XBOW_CD        = 35;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int  attackCd       = 0;
    private int  dashCd         = 0;
    private int  shieldDisabled = 0;
    private int  burstHits      = 0;
    private int  burstCd        = 0;
    private int  hitCount       = 0;
    private int  xbowCd         = 0;
    private boolean inBurst     = false;
    private boolean critPending = false;

    public AxeLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.CIRCLE);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) return;

        if (attackCd       > 0) attackCd--;
        if (shieldDisabled > 0) shieldDisabled--;
        if (burstCd        > 0) burstCd--;
        if (dashCd         > 0) dashCd--;
        if (xbowCd         > 0) xbowCd--;

        double dist    = bot.distanceTo(target);
        boolean blocking = isTargetBlocking(target);

        // ── Щит в оффхенд ─────────────────────────────────────────
        equipShieldOffhand();

        // ── Дистанция: арбалет если цель держит щит или далеко ────
        if (dist > MELEE_RANGE || (blocking && shieldDisabled <= 0)) {
            if (dist <= RANGED_DIST && xbowCd <= 0 && blocking) {
                // Стреляем из арбалета пока цель закрылась
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
                bot.getLookControl().setLookAt(target, 60f, 60f);
                if (target != null && target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), 9.0f);
                sw.sendParticles(ParticleTypes.CRIT,
                    target.getX(), target.getY()+1, target.getZ(), 4, 0.2,0.2,0.2,0.1);
                xbowCd = XBOW_CD;
            } else if (dist > MELEE_RANGE) {
                // Идём к цели
                bot.getNavigation().moveTo(target, 1.05);
                if (dist > 8 && dashCd <= 0) {
                    bot.getNavigation().moveTo(target, 1.4);
                    bot.setSprinting(true);
                    dashCd = DASH_CD;
                }
            }
        }

        // ── Страф ─────────────────────────────────────────────────
        if (dist < MELEE_RANGE + 2.0) strafe.tick(target);
        if (dist > MELEE_RANGE) return;

        bot.getLookControl().setLookAt(target, 30f, 30f);

        // ── Ломаем щит топором ────────────────────────────────────
        if (blocking && attackCd <= 0) {
            equipAxe();
            doAxeHit(sw, target, false);
            shieldDisabled = SHIELD_DIS_DUR;
            inBurst = true; burstHits = 0;
        }
        // ── Бёрст мечом пока щит сломан ──────────────────────────
        else if (shieldDisabled > 0 && inBurst) {
            doBurstSword(sw, target);
        }
        // ── Обычная атака топором (крит каждые N ударов) ──────────
        else if (!blocking && attackCd <= 0) {
            equipAxe();
            boolean doCrit = (hitCount % CRIT_EVERY == 0);
            if (doCrit && bot.onGround() && !critPending) {
                bot.getJumpControl().jump(); critPending = true; attackCd = 1;
            } else if (critPending && !bot.onGround() && bot.fallDistance > 0.01f) {
                doAxeHit(sw, target, true); critPending = false;
            } else {
                doAxeHit(sw, target, false); critPending = false;
            }
        }
    }

    private void doAxeHit(ServerLevel sw, LivingEntity target, boolean crit) {
        if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
        if (crit) {
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 6, 0.3,0.3,0.3,0.1);
            bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.85f);
        } else {
            sw.sendParticles(ParticleTypes.SWEEP_ATTACK,
                target.getX(), target.getY()+1, target.getZ(), 4, 0.4,0.2,0.4,0.05);
            bot.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        }
        hitCount++;
        attackCd = cfg.adaptiveCooldownEnabled
            ? bot.getAdaptiveCooldown().getEffectiveCooldown() : AXE_CD;
    }

    // ── Бёрст мечом после слома щита ─────────────────────────────
    private void doBurstSword(ServerLevel sw, LivingEntity target) {
        if (burstCd > 0) return;
        if (burstHits < BURST_COUNT) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
            if (target != null && target.isAlive()) bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 3, 0.2,0.2,0.2,0.1);
            burstCd = BURST_CD; burstHits++;
        } else {
            inBurst = false; burstHits = 0;
        }
    }

    private boolean isTargetBlocking(LivingEntity t) {
        if (shieldDisabled > 0) return false;
        ItemStack off  = t.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack main = t.getItemBySlot(EquipmentSlot.MAINHAND);
        return (off.is(Items.SHIELD) || main.is(Items.SHIELD)) && t.isBlocking();
    }

    private void equipAxe() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.DIAMOND_AXE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_AXE));
    }

    private void equipShieldOffhand() {
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.SHIELD))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
    }
}
