package com.pvpbot;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * UhcLogic v5.0 — MCTiers UHC IMPROVED.
 *
 * Улучшения v5:
 *  ✦ Лук с правильным расчётом упреждения (leading shot)
 *  ✦ Паутина (COBWEB) под цель + немедленный лук-залп
 *  ✦ Блоки-укрытия (dirt) во время отступления — бот прячется
 *  ✦ Три фазы стрельбы: лук (дальний) / арбалет (средний) / меч (ближний)
 *  ✦ Смена позиции через стрейф — не стоит на месте
 *  ✦ Авто-щит + golden apple при < 8 HP
 *  ✦ Blocker: если цель блокирует щитом — топор для отключения
 */
public class UhcLogic {

    private static final double BOW_RANGE    = 20.0; // увеличена дальность
    private static final double XBOW_RANGE   = 14.0;
    private static final double TRAP_RANGE   = 4.5;
    private static final double MELEE_RANGE  = 2.8;
    private static final double MIN_KITE     = 7.0;  // минимальная кайтовая дистанция
    private static final int    BOW_CD       = 18;   // лук быстрее
    private static final int    XBOW_CD      = 30;
    private static final int    TRAP_CD      = 80;   // паутина чаще
    private static final int    GAP_CD       = 220;
    private static final int    LAVA_CD      = 80;
    private static final int    WATER_CD     = 60;
    private static final int    SHIELD_TICKS = 35;
    private static final int    WEB_LIFE     = 65;
    private static final int    BLOCK_CD     = 40;   // кулдаун постановки блока-укрытия
    private static final int    AXE_CD       = 15;   // топор против щита
    private static final int    STRAFE_CD    = 8;    // смена направления стрейфа

    private enum State { RANGING, TRAPPING, LAVA_POUR, MELEING, GAPPING, SELF_STUCK, BUILDING }
    private State state = State.RANGING;

    private final BotEntity bot;
    private final StrafeAI  strafe;

    private int bowCd      = 0;
    private int xbowCd     = 0;
    private int trapCd     = 0;
    private int gapCd      = 0;
    private int lavaCd     = 0;
    private int waterCd    = 0;
    private int shieldTick = 0;
    private int webLife    = 0;
    private int blockCd    = 0;
    private int axeCd      = 0;
    private int strafeCd   = 0;
    private int strafeDir  = 1; // 1 или -1

    private boolean webPlaced  = false;
    private boolean lavaPlaced = false;
    private BlockPos webPos    = null;
    private BlockPos lavaPos   = null;
    private BlockPos coverPos  = null; // позиция блока-укрытия

    public UhcLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.RETREAT);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { reset(sw); return; }

        // Tick cooldowns
        if (bowCd      > 0) bowCd--;
        if (xbowCd     > 0) xbowCd--;
        if (trapCd     > 0) trapCd--;
        if (gapCd      > 0) gapCd--;
        if (lavaCd     > 0) lavaCd--;
        if (waterCd    > 0) waterCd--;
        if (shieldTick > 0) shieldTick--;
        if (webLife    > 0) webLife--;
        if (blockCd    > 0) blockCd--;
        if (axeCd      > 0) axeCd--;
        if (strafeCd   > 0) strafeCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // Паутина истекла — убираем
        if (webPlaced && webLife <= 0) removeWeb(sw);
        // Лава тоже
        if (lavaPlaced && lavaCd <= 0) removeLava(sw);

        // ── Определяем состояние ──────────────────────────────────
        if (botInWeb(sw)) {
            state = State.SELF_STUCK;
        } else if (myHp < 8.0f && gapCd <= 0) {
            state = State.GAPPING;
        } else if (webPlaced && isInWeb(target) && !lavaPlaced && lavaCd <= 0) {
            state = State.LAVA_POUR;
        } else if (webPlaced && isInWeb(target)) {
            state = State.MELEING;
        } else if (dist < TRAP_RANGE && trapCd <= 0 && !webPlaced) {
            state = State.TRAPPING;
        } else if (state != State.GAPPING && state != State.SELF_STUCK && state != State.BUILDING) {
            state = State.RANGING;
        }

        switch (state) {
            case RANGING    -> doRanging(sw, target, dist);
            case TRAPPING   -> doTrapping(sw, target);
            case LAVA_POUR  -> doLavaPour(sw, target);
            case MELEING    -> doMeleing(sw, target);
            case GAPPING    -> doGapping(sw, target);
            case SELF_STUCK -> doSelfStuck(sw);
            case BUILDING   -> doBuilding(sw, target);
        }

        // Авто-щит при вблизи
        autoShield(target, dist);

        // Топор если цель блокирует щитом
        autoAxe(sw, target, dist);

        // Стрейф каждые N тиков
        doStrafe(target, dist);
    }

    // ── Дальний бой: лук с упреждением + арбалет ─────────────────
    private void doRanging(ServerLevel sw, LivingEntity target, double dist) {
        // Кайтовое позиционирование
        if (dist < MIN_KITE) {
            Vec3 away = bot.position().subtract(target.position()).normalize();
            bot.getNavigation().moveTo(
                bot.getX() + away.x * 8, bot.getY(), bot.getZ() + away.z * 8, 1.15
            );
        } else if (dist > BOW_RANGE) {
            bot.getNavigation().moveTo(target, 1.0);
        }

        // Лук на дальней дистанции — с упреждением
        if (dist <= BOW_RANGE && bowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));

            // Упреждение: предсказываем где будет цель через ~0.5 секунды
            Vec3 tVel   = target.getDeltaMovement();
            double lead = dist / 25.0; // время полёта (примерно)
            double aimX = target.getX() + tVel.x * lead * 20;
            double aimY = target.getY() + tVel.y * lead * 20 + 1.0; // +1 = центр тела
            double aimZ = target.getZ() + tVel.z * lead * 20;
            bot.getLookControl().setLookAt(aimX, aimY, aimZ, 60f, 60f);

            // Урон зависит от дистанции (9.5 на близко, 5.5 на макс дальности)
            float dmg = (float) Math.max(5.5, 9.5 - dist * 0.22);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), dmg);
            sw.sendParticles(ParticleTypes.CRIT,
                aimX, aimY, aimZ, 4, 0.3, 0.3, 0.3, 0.1);
            bowCd = BOW_CD;
            return;
        }

        // Арбалет на средней дистанции (более мощный)
        if (dist <= XBOW_RANGE && xbowCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
            bot.getLookControl().setLookAt(target, 60f, 60f);
            if (target.isAlive()) target.hurt(sw.damageSources().arrow(null, bot), 10.0f);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+1, target.getZ(), 5, 0.2, 0.2, 0.2, 0.1);
            xbowCd = XBOW_CD;
        }
    }

    // ── Паутина ──────────────────────────────────────────────────
    private void doTrapping(ServerLevel sw, LivingEntity target) {
        BlockPos feet  = BlockPos.containing(target.position());
        BlockPos below = feet.below();

        if (sw.getBlockState(below).isSolid() && sw.getBlockState(feet).isAir()) {
            sw.setBlock(feet, Blocks.COBWEB.defaultBlockState(), 3);
            // Двойная паутина — выше тоже
            if (sw.getBlockState(feet.above()).isAir())
                sw.setBlock(feet.above(), Blocks.COBWEB.defaultBlockState(), 3);
            webPlaced = true;
            webPos    = feet;
            webLife   = WEB_LIFE;
            bot.playSound(net.minecraft.sounds.SoundEvents.WOOL_PLACE, 1.0f, 0.8f);

            // Сразу залп из лука по зафиксированной цели
            bowCd = 0;
        }
        trapCd = TRAP_CD;
        state  = State.RANGING;
    }

    // ── Лаём лаву ────────────────────────────────────────────────
    private void doLavaPour(ServerLevel sw, LivingEntity target) {
        if (!isInWeb(target)) { state = State.RANGING; return; }

        BlockPos pourPos = webPos != null ? webPos.above(2)
            : BlockPos.containing(target.position()).above(2);

        if (sw.getBlockState(pourPos).isAir()) {
            sw.setBlock(pourPos, Blocks.LAVA.defaultBlockState(), 3);
            lavaPlaced = true;
            lavaPos    = pourPos;
            lavaCd     = LAVA_CD;
            bot.playSound(net.minecraft.sounds.SoundEvents.BUCKET_EMPTY_LAVA, 1.0f, 1.0f);
        }
        state = State.MELEING;
    }

    // ── Ближний бой ───────────────────────────────────────────────
    private void doMeleing(ServerLevel sw, LivingEntity target) {
        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));

        if (bot.distanceTo(target) > MELEE_RANGE)
            bot.getNavigation().moveTo(target, 1.1);

        if (bot.distanceTo(target) <= MELEE_RANGE + 0.5) {
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target.isAlive()) bot.doHurtTarget(sw, target);
        }

        if (!isInWeb(target)) {
            webPlaced  = false;
            lavaPlaced = false;
            removeLava(sw);
            state = State.RANGING;
        }
    }

    // ── Gapping ───────────────────────────────────────────────────
    private void doGapping(ServerLevel sw, LivingEntity target) {
        Vec3 away = bot.position().subtract(target.position()).normalize();
        bot.getNavigation().moveTo(
            bot.getX() + away.x * 7, bot.getY(), bot.getZ() + away.z * 7, 1.2
        );
        bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
        gapCd = GAP_CD;

        // Строим блок-укрытие позади себя пока отступаем
        if (blockCd <= 0) {
            doBuilding(sw, target);
        }

        state = State.RANGING;
    }

    // ── Блок-укрытие (dirt/stone) ─────────────────────────────────
    private void doBuilding(ServerLevel sw, LivingEntity target) {
        if (blockCd > 0) return;
        // Ставим блок между собой и целью
        Vec3 botPos    = bot.position();
        Vec3 toTarget  = target.position().subtract(botPos).normalize();
        // Позиция на 1 блок в сторону цели от бота (между нами)
        BlockPos placeAt = BlockPos.containing(
            botPos.x + toTarget.x * 1.5,
            botPos.y,
            botPos.z + toTarget.z * 1.5
        );
        if (sw.getBlockState(placeAt).isAir() && sw.getBlockState(placeAt.below()).isSolid()) {
            sw.setBlock(placeAt, Blocks.DIRT.defaultBlockState(), 3);
            coverPos = placeAt;
            blockCd  = BLOCK_CD;
        }
        state = State.RANGING;
    }

    // ── Бот застрял в паутине ─────────────────────────────────────
    private void doSelfStuck(ServerLevel sw) {
        if (waterCd > 0) return;
        BlockPos botPos = BlockPos.containing(bot.position());
        for (BlockPos candidate : new BlockPos[]{
            botPos, botPos.north(), botPos.south(), botPos.east(), botPos.west()
        }) {
            if (sw.getBlockState(candidate).is(Blocks.COBWEB)) {
                sw.setBlock(candidate, Blocks.WATER.defaultBlockState(), 3);
                bot.playSound(net.minecraft.sounds.SoundEvents.BUCKET_EMPTY, 1.0f, 1.0f);
                break;
            }
        }
        waterCd = WATER_CD;
        if (!botInWeb(sw)) state = State.RANGING;
    }

    // ── Авто-щит ─────────────────────────────────────────────────
    private void autoShield(LivingEntity target, double dist) {
        if (dist < 4.5 && shieldTick <= 0) {
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            shieldTick = SHIELD_TICKS;
        }
    }

    // ── Топор против щита ────────────────────────────────────────
    private void autoAxe(ServerLevel sw, LivingEntity target, double dist) {
        if (axeCd > 0 || dist > MELEE_RANGE + 0.5) return;
        // Если цель держит щит — бьём топором чтобы отключить
        ItemStack offhand = target.getItemBySlot(EquipmentSlot.OFFHAND);
        ItemStack mainhand = target.getItemBySlot(EquipmentSlot.MAINHAND);
        if (offhand.is(Items.SHIELD) || mainhand.is(Items.SHIELD)) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_AXE));
            bot.getLookControl().setLookAt(target, 30f, 30f);
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            axeCd = AXE_CD;
        }
    }

    // ── Стрейф ───────────────────────────────────────────────────
    private void doStrafe(LivingEntity target, double dist) {
        if (strafeCd > 0 || dist < 3.0 || state != State.RANGING) return;
        // Меняем направление стрейфа каждые STRAFE_CD тиков
        strafe.tick(target);
        strafeCd = STRAFE_CD + (int)(Math.random() * 4); // небольшая рандомизация
    }

    // ── Утилиты ───────────────────────────────────────────────────
    private void removeWeb(ServerLevel sw) {
        if (webPos == null) return;
        if (sw.getBlockState(webPos).is(Blocks.COBWEB))
            sw.setBlock(webPos, Blocks.AIR.defaultBlockState(), 3);
        BlockPos above = webPos.above();
        if (sw.getBlockState(above).is(Blocks.COBWEB))
            sw.setBlock(above, Blocks.AIR.defaultBlockState(), 3);
        webPlaced = false; webPos = null;
    }

    private void removeLava(ServerLevel sw) {
        if (lavaPos != null && sw.getBlockState(lavaPos).is(Blocks.LAVA))
            sw.setBlock(lavaPos, Blocks.AIR.defaultBlockState(), 3);
        lavaPlaced = false; lavaPos = null;
    }

    private boolean isInWeb(LivingEntity t) {
        if (webPos == null) return false;
        BlockPos tp = BlockPos.containing(t.position());
        for (BlockPos check : new BlockPos[]{tp, tp.below(), tp.above()}) {
            if ((check.equals(webPos) || check.equals(webPos.above()))
                    && bot.level().getBlockState(check).is(Blocks.COBWEB)) {
                return true;
            }
        }
        return false;
    }

    private boolean botInWeb(ServerLevel sw) {
        BlockPos bp = BlockPos.containing(bot.position());
        return sw.getBlockState(bp).is(Blocks.COBWEB)
            || sw.getBlockState(bp.above()).is(Blocks.COBWEB);
    }

    private void reset(ServerLevel sw) {
        state = State.RANGING;
        removeWeb(sw);
        removeLava(sw);
    }
}
