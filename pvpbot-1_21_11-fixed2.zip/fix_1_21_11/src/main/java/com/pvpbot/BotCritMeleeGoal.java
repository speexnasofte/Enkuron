package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;

/**
 * Кастомная цель ближнего боя для NPC-бота.
 * Перед атакой бот прыгает — это даёт критический урон (x1.5).
 *
 * Как работает крит в Minecraft:
 *   LivingEntity.attackLivingEntity() проверяет: !onGround && fallDistance > 0 && !climbing
 *   → если прыгнули и начали падать — следующая атака даёт крит.
 *
 * Стратегия: прыгаем за 1-2 тика до атаки, атакуем когда в воздухе.
 *
 * v18: уступаем управление ModeLogicDispatcher когда активен кит —
 *      чтобы SwordLogic/AxeLogic/MaceLogic и т.д. управляли атакой сами.
 */
public class BotCritMeleeGoal extends MeleeAttackGoal {

    private final BotEntity bot;
    private int preCritTimer = 0; // таймер подготовки к крит-атаке

    public BotCritMeleeGoal(BotEntity bot, double speed, boolean pauseWhenMobIdle) {
        super(bot, speed, pauseWhenMobIdle);
        this.bot = bot;
    }

    @Override
    public boolean canUse() {
        // Если у бота выбран кит — кит-логика управляет атакой сама
        if (bot.getCurrentKit() != null && PVPBotConfig.INSTANCE.mode != null) return false;
        return super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        if (bot.getCurrentKit() != null && PVPBotConfig.INSTANCE.mode != null) return false;
        return super.canContinueToUse();
    }

    @Override
    public void tick() {
        LivingEntity target = bot.getTarget();
        if (target == null) { super.tick(); return; }

        double dist = bot.distanceTo(target);
        double reach = 4.0; // ~2 block melee reach squared

        // Когда близко к атаке — прыгаем заранее
        if (dist * dist <= reach * 1.5 && bot.onGround()) {
            preCritTimer++;
            if (preCritTimer == 2) {
                // Прыжок: устанавливаем вертикальную скорость
                bot.setDeltaMovement(bot.getDeltaMovement().x, 0.42, bot.getDeltaMovement().z);
            }
        } else {
            preCritTimer = 0;
        }

        super.tick();
    }

    @Override
    public void stop() {
        super.stop();
        preCritTimer = 0;
    }
}
