package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

/**
 * MaceElytraLogic v4.0 — MCTiers Mace+Elytra.
 *
 * Тактика:
 *  1. ASCEND: взлетаем с помощью Wind Charge вверх (приоритет), фейерверк как резерв
 *  2. GLIDE_AIM: пикируем на элитрах к цели
 *  3. DIVE_SMASH: при дистанции <= 3.5 бьём булавой (огромный урон от скорости)
 *  4. Wind Charge в IDLE — отталкивает цель для создания дистанции под пике
 */
public class MaceElytraLogic {

    private static final double ASCEND_HEIGHT = 14.0;
    private static final double SMASH_DIST    = 3.5;
    private static final double WIND_PUSH_DIST = 5.0;
    private static final int    FULL_CD       = 55;
    private static final int    FW_INTERVAL   = 25;
    private static final int    MAX_FW        = 2;
    private static final int    WIND_CD       = 40;
    private static final float  BASE_DAMAGE   = 8.0f;
    private static final float  VEL_MULT      = 6.5f;
    private static final float  MAX_DAMAGE    = 32.0f;

    private enum Phase { IDLE, ASCEND, GLIDE_AIM, DIVE_SMASH, COOLDOWN }
    private Phase phase = Phase.IDLE;

    private int cdTimer = 0, fwTimer = 0, fwUsed = 0, diveTimeout = 0, windCd = 0;
    private double speedAtHit = 0;
    private double ascendTargetY = 0;

    private final BotEntity bot;

    public MaceElytraLogic(BotEntity bot) { this.bot = bot; }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { phase = Phase.IDLE; return; }

        if (cdTimer > 0) cdTimer--;
        if (fwTimer > 0) fwTimer--;
        if (windCd  > 0) windCd--;

        switch (phase) {
            case IDLE       -> tickIdle(sw, target);
            case ASCEND     -> tickAscend(sw, target);
            case GLIDE_AIM  -> tickGlide(sw, target);
            case DIVE_SMASH -> tickSmash(sw, target);
            case COOLDOWN   -> { if (cdTimer <= 0) phase = Phase.IDLE; }
            default -> {}
        }
    }

    private void tickIdle(ServerLevel sw, LivingEntity target) {
        if (cdTimer > 0) return;
        equipKit();

        double dist = bot.distanceTo(target);

        // Wind Charge — отталкиваем цель и создаём дистанцию для пике
        if (dist < WIND_PUSH_DIST && windCd <= 0) {
            Vec3 push = target.position().subtract(bot.position()).normalize();
            target.setDeltaMovement(push.x * 2.5, 1.8, push.z * 2.5);
            target.hurt(sw.damageSources().explosion(null, bot), 3.0f);
            sw.sendParticles(ParticleTypes.GUST,
                target.getX(), target.getY(), target.getZ(), 12, 0.5,0.5,0.5,0.2);
            bot.playSound(SoundEvents.WIND_CHARGE_THROW, 1.0f, 1.0f);
            windCd = WIND_CD;
        }

        if (dist > 22.0) { bot.getNavigation().moveTo(target, 1.2); return; }

        // Начинаем подъём
        ascendTargetY = target.getY() + ASCEND_HEIGHT;
        fwUsed = 0; fwTimer = 0;
        phase  = Phase.ASCEND;
        bot.getNavigation().stop();
    }

    private void tickAscend(ServerLevel sw, LivingEntity target) {
        equipKit();
        double y    = bot.getY();
        double left = ascendTargetY - y;

        // Фейерверк для тяги (резерв, Wind Charge уже толкнул цель)
        if (fwTimer <= 0 && fwUsed < MAX_FW && left > 2.5) {
            launchFirework(sw);
            fwTimer = FW_INTERVAL;
            fwUsed++;
        }

        if (y < ascendTargetY - 0.5) {
            Vec3 vel = bot.getDeltaMovement();
            Vec3 xz  = new Vec3(target.getX()-bot.getX(), 0, target.getZ()-bot.getZ())
                .normalize().scale(0.25);
            bot.setDeltaMovement(
                clamp(vel.x + xz.x, -0.9, 0.9),
                Math.max(vel.y, 0.25),
                clamp(vel.z + xz.z, -0.9, 0.9)
            );
        } else {
            phase = Phase.GLIDE_AIM;
            diveTimeout = 130;
        }

        if (bot.tickCount % 4 == 0)
            sw.sendParticles(ParticleTypes.CLOUD,
                bot.getX(), bot.getY(), bot.getZ(), 2, 0.2,0.1,0.2,0.04);
    }

    private void tickGlide(ServerLevel sw, LivingEntity target) {
        diveTimeout--;
        if (diveTimeout <= 0) { phase = Phase.COOLDOWN; cdTimer = FULL_CD / 2; return; }

        double dist     = bot.distanceTo(target);
        Vec3   toTarget = target.getEyePosition().subtract(bot.position()).normalize();
        Vec3   vel      = bot.getDeltaMovement();

        // Разгон к цели на элитрах
        if (vel.length() < 1.4) {
            bot.setDeltaMovement(
                clamp(vel.x + toTarget.x * 0.4, -2.8, 2.8),
                vel.y + toTarget.y * 0.4 - 0.08,
                clamp(vel.z + toTarget.z * 0.4, -2.8, 2.8)
            );
        }
        bot.getLookControl().setLookAt(target, 180, 80);

        if (dist <= SMASH_DIST) {
            // Перед ударом — переключаемся с элитр на нагрудник
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
            phase = Phase.DIVE_SMASH;
            if (target.isAlive()) tickSmash(sw, target); else { phase = Phase.COOLDOWN; cdTimer = FULL_CD; }
        } else if (bot.onGround() && diveTimeout < 80) {
            phase = Phase.COOLDOWN; cdTimer = FULL_CD;
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        if (target == null || !target.isAlive()) { phase = Phase.COOLDOWN; cdTimer = FULL_CD; return; }
        Vec3  vel = bot.getDeltaMovement();
        speedAtHit = vel.length();
        float dmg  = Math.min(MAX_DAMAGE, BASE_DAMAGE + (float)(speedAtHit * VEL_MULT));

        equipMace();
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        // Knockback от удара
        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive()) target.setDeltaMovement(kb.x * 2.2, 1.6, kb.z * 2.2);

        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 22, 0.6,0.6,0.6,0.35);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.75f);

        // Плавное гашение скорости бота
        bot.setDeltaMovement(vel.x*0.15, Math.max(vel.y*0.1, 0), vel.z*0.15);

        notifyOwner(String.format("§6[MaceElytra] §cSmash! §e%.1f dmg §7(speed: %.2f)", dmg, speedAtHit));
        equipKit();
        phase = Phase.COOLDOWN; cdTimer = FULL_CD;
    }

    // ── Wind Charge — создаём сущность ───────────────────────────
    // (в реальном API WindChargeEntity; симулируем через взрыв/KB)
    private void launchFirework(ServerLevel sw) {
        FireworkRocketEntity fw = new FireworkRocketEntity(
            sw, bot, bot.getX(), bot.getY(), bot.getZ(), new ItemStack(Items.FIREWORK_ROCKET)
        );
        fw.setDeltaMovement(0, 2.0, 0);
        sw.addFreshEntity(fw);
        sw.sendParticles(ParticleTypes.FIREWORK,
            bot.getX(), bot.getY()-0.5, bot.getZ(), 6, 0.2,0.1,0.2,0.15);
        bot.playSound(SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
    }

    // ── Снаряжение ────────────────────────────────────────────────
    private void equipKit() {
        // Элитры в нагрудник для полёта
        if (!bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA))
            bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        if (bot.getItemBySlot(EquipmentSlot.HEAD).isEmpty())
            bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getItemBySlot(EquipmentSlot.LEGS).isEmpty())
            bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getItemBySlot(EquipmentSlot.FEET).isEmpty())
            bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        equipMace();
    }

    private void equipMace() {
        if (!bot.getItemBySlot(EquipmentSlot.MAINHAND).is(Items.MACE))
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    private double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public String getStateLabel() {
        return switch (phase) {
            case IDLE       -> "ME:IDLE";
            case ASCEND     -> "ME:ASCEND";
            case GLIDE_AIM  -> "ME:DIVE";
            case DIVE_SMASH -> "ME:SMASH!";
            case COOLDOWN   -> "ME:CD";
            default         -> "?";
        };
    }
    public double getLastHitSpeed() { return speedAtHit; }
    public boolean isActive() { return phase == Phase.GLIDE_AIM || phase == Phase.DIVE_SMASH; }
}
