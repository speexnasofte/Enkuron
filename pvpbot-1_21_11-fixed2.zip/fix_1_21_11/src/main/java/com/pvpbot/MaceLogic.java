package com.pvpbot;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;

/**
 * MaceLogic v4.0 — MCTiers Mace PvP.
 *
 * Kit: Netherite Prot4, Mace (Breach4/Density5+WindBurst1)
 *   Sword Sharp5+Unb3, Axe Sharp5+Unb3
 *   Эндер жемчуг 16, Golden Apple 64, Wind Charge 64
 *   Щит Mend+Unb3, тотем offhand
 *
 * Тактика:
 *  1. IDLE: ближний бой мечом/топором, бросает Wind Charge для KB
 *  2. Каждые N ударов — прыжок + смэш булавой (JUMP_UP → FALLING → SMASH)
 *  3. Wind Charge отталкивает цель вверх → создаёт высоту для смэша
 *  4. Golden Apple при низком HP
 *  5. Тотем в оффхенд всегда
 */
public class MaceLogic {

    private static final double MELEE_RANGE   = 3.2;
    private static final double IDEAL_DIST    = 2.6;
    private static final double WIND_DIST     = 5.0;
    private static final int    SMASH_EVERY   = 5;   // каждые N ударов — смэш
    private static final int    SMASH_CD      = 30;
    private static final int    WIND_CD       = 40;
    private static final int    GAP_CD        = 220;
    private static final int    DASH_CD       = 25;
    private static final int    SWORD_CD      = 10;
    private static final float  SMASH_BASE    = 8.0f;
    private static final float  FALL_BONUS    = 1.5f;
    private static final float  MAX_DAMAGE    = 30.0f;

    private enum State { FIGHTING, JUMP_UP, FALLING, SMASH, COOLDOWN }
    private State state = State.FIGHTING;

    private final BotEntity    bot;
    private final StrafeAI     strafe;
    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;

    private int smashCd   = 0;
    private int windCd    = 0;
    private int gapCd     = 0;
    private int dashCd    = 0;
    private int swordCd   = 0;
    private int hitCount  = 0;
    private double jumpStartY = 0;
    private double peakY      = 0;

    public MaceLogic(BotEntity bot) {
        this.bot    = bot;
        this.strafe = new StrafeAI(bot);
        strafe.setStyle(StrafeAI.StrafeStyle.ZIGZAG);
    }

    public void tick(LivingEntity target) {
        if (!(bot.level() instanceof ServerLevel sw)) return;
        if (target == null || !target.isAlive()) { state = State.FIGHTING; return; }

        if (smashCd > 0) smashCd--;
        if (windCd  > 0) windCd--;
        if (gapCd   > 0) gapCd--;
        if (dashCd  > 0) dashCd--;
        if (swordCd > 0) swordCd--;

        double dist = bot.distanceTo(target);
        float  myHp = bot.getHealth();

        // ── Тотем в оффхенд всегда ────────────────────────────────
        if (!bot.getItemBySlot(EquipmentSlot.OFFHAND).is(Items.TOTEM_OF_UNDYING))
            bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));

        // ── Golden Apple при низком HP ────────────────────────────
        if (myHp < 10.0f && gapCd <= 0) {
            bot.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            bot.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   400, 0));
            gapCd = GAP_CD;
        }

        // ── Dash если цель убегает ────────────────────────────────
        if (state == State.FIGHTING && dist > 7.0 && dashCd <= 0) {
            bot.getNavigation().moveTo(target, 1.3);
            bot.setSprinting(true);
            dashCd = DASH_CD;
        }

        switch (state) {
            case FIGHTING -> tickFighting(sw, target, dist);
            case JUMP_UP  -> tickJumpUp();
            case FALLING  -> tickFalling(sw, target);
            case SMASH    -> tickSmash(sw, target);
            case COOLDOWN -> { if (smashCd <= 0) state = State.FIGHTING; }
            default -> {}
        }
    }

    private void tickFighting(ServerLevel sw, LivingEntity target, double dist) {
        // Навигация
        if (dist > IDEAL_DIST + 0.8)
            bot.getNavigation().moveTo(target, 1.05);
        else if (dist < IDEAL_DIST - 0.5)
            bot.getNavigation().stop();

        if (dist < MELEE_RANGE + 2.0) strafe.tick(target);

        bot.getLookControl().setLookAt(target, 30f, 30f);

        if (dist > MELEE_RANGE) return;

        // ── Wind Charge — отталкиваем цель вверх для смэша ───────
        if (windCd <= 0 && dist <= WIND_DIST) {
            Vec3 push = target.position().subtract(bot.position()).normalize();
            target.setDeltaMovement(push.x * 1.8, 2.2, push.z * 1.8);
            sw.sendParticles(ParticleTypes.GUST,
                target.getX(), target.getY(), target.getZ(), 14, 0.5,0.5,0.5,0.2);
            bot.playSound(SoundEvents.WIND_CHARGE_THROW, 1.0f, 1.0f);
            windCd = WIND_CD;
        }

        // ── Каждые SMASH_EVERY ударов — прыгаем со смэшем ────────
        if (hitCount > 0 && hitCount % SMASH_EVERY == 0 && smashCd <= 0 && bot.onGround()) {
            jumpStartY = bot.getY();
            peakY      = jumpStartY;
            bot.getJumpControl().jump();
            state = State.JUMP_UP;
            bot.getNavigation().stop();
            return;
        }

        // ── Меч между смэшами ─────────────────────────────────────
        if (swordCd <= 0) {
            bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
            if (target.isAlive()) bot.doHurtTarget(sw, target);
            sw.sendParticles(ParticleTypes.CRIT,
                target.getX(), target.getY()+0.8, target.getZ(), 3, 0.2,0.2,0.2,0.05);
            hitCount++;
            swordCd = cfg.adaptiveCooldownEnabled
                ? bot.getAdaptiveCooldown().getEffectiveCooldown() : SWORD_CD;
        }
    }

    private void tickJumpUp() {
        double y = bot.getY();
        if (y > peakY) peakY = y;
        // Начали падать → FALLING
        if (y < peakY - 0.15 || (!bot.onGround() && bot.getDeltaMovement().y < -0.05))
            state = State.FALLING;
    }

    private void tickFalling(ServerLevel sw, LivingEntity target) {
        double dist     = bot.distanceTo(target);
        double vertDiff = bot.getY() - target.getY();
        if (vertDiff <= 1.8 && dist <= MELEE_RANGE + 1.0) {
            state = State.SMASH; if (target.isAlive()) tickSmash(sw, target); else { state = State.COOLDOWN; smashCd = SMASH_CD; }
        } else if (bot.onGround()) {
            // Промахнулись
            state = State.COOLDOWN; smashCd = SMASH_CD / 2;
        }
    }

    private void tickSmash(ServerLevel sw, LivingEntity target) {
        if (target == null || !target.isAlive()) { state = State.COOLDOWN; smashCd = SMASH_CD; return; }
        double fallBlocks = Math.max(0, peakY - bot.getY());
        float  damage     = Math.min(MAX_DAMAGE, SMASH_BASE + (float)(fallBlocks * FALL_BONUS));

        bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.MACE));
        bot.getLookControl().setLookAt(target, 30f, 30f);
        if (target.isAlive()) bot.doHurtTarget(sw, target);

        Vec3 kb = target.position().subtract(bot.position()).normalize();
        if (target.isAlive()) target.setDeltaMovement(kb.x * 1.8, 1.4, kb.z * 1.8);

        sw.sendParticles(ParticleTypes.CRIT,
            target.getX(), target.getY()+1, target.getZ(), 18, 0.5,0.5,0.5,0.25);
        bot.playSound(SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.75f);

        // Плавное торможение
        Vec3 v = bot.getDeltaMovement();
        bot.setDeltaMovement(v.x * 0.25, Math.max(v.y, 0), v.z * 0.25);

        notifyOwner(String.format("§6[Mace] §cSmash! §e%.1f dmg §7(fall: %.1f)", damage, fallBlocks));

        smashCd = SMASH_CD;
        state   = State.COOLDOWN;
    }

    private void notifyOwner(String msg) {
        if (bot.getOwner() instanceof net.minecraft.server.level.ServerPlayer p)
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    public boolean isSmashing() {
        return state == State.JUMP_UP || state == State.FALLING || state == State.SMASH;
    }

    public String getStateLabel() {
        return switch (state) {
            case FIGHTING -> "MACE:FIGHT";
            case JUMP_UP  -> "MACE:JUMP";
            case FALLING  -> "MACE:FALL";
            case SMASH    -> "MACE:SMASH!";
            case COOLDOWN -> "MACE:CD";
            default       -> "?";
        };
    }
}
