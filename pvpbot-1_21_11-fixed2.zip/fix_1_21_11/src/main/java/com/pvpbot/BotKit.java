package com.pvpbot;

import net.minecraft.core.RegistryAccess;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;

/**
 * BotKit v3.0 — MCTiers 1:1 точные киты.
 *
 * Источник: mctiers.com/kits
 *
 * ┌─────────────┬────────────────────────────────────────────────────────────┐
 * │ KIT         │ Снаряжение (точно по MCTiers)                              │
 * ├─────────────┼────────────────────────────────────────────────────────────┤
 * │ SWORD       │ Diamond Prot4 Unb3 + Diamond Sword Sharp5 Unb3             │
 * │ AXE         │ Diamond (без зачар!) + Diamond Axe Sharp5 Eff5 Unb3 + Щит │
 * │ POT         │ Diamond Prot4 Unb3 + Diamond Sword Sharp5 Unb3 + Зелья    │
 * │ UHC         │ Diamond Prot3 Unb3 (нагр/ноги Prot2) + Sword Sharp3 + Лук │
 * │ NETHOP      │ Netherite Prot4 Unb3 Mend + NethSword Sharp5 Unb3 Mend    │
 * │ SMP         │ Netherite Prot4 Unb3 Mend + NethSword Sharp5 KB2 FA2 + Tot│
 * │ CRYSTAL     │ NethHelm/Chest Prot4, Legs/Boots BlastProt4 + Tot + Cryst  │
 * │ MACE        │ Netherite Prot4 + Mace Density5 Breach4 + Tot + Элитры    │
 * │ MACE_ELYTRA │ Netherite, нагрудник=Elytra + Mace Density5 Breach4 + Tot  │
 * │ TPC         │ Netherite Prot4 + NetheriteAxe Sharp5 Eff5 + Tot + Crystl  │
 * └─────────────┴────────────────────────────────────────────────────────────┘
 */
public enum BotKit {

    // ─────────────────────────────────────────────────────────────
    // SWORD — MCTiers Sword PvP
    // Шлем/нагр/ноги/боты: Diamond Prot4 Unb3 (боты +FF4)
    // Mainhand: Diamond Sword Sharp5 Unb3
    // Offhand: нет
    // ─────────────────────────────────────────────────────────────
    SWORD("sword", "Sword PvP",
        new KitEquipment(
            Items.DIAMOND_SWORD, null,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "pvp"),

    // ─────────────────────────────────────────────────────────────
    // AXE — MCTiers Axe PvP
    // Броня: Diamond БЕЗ зачарований (MCTiers стандарт!)
    // Mainhand: Diamond Axe Sharp5 Eff5 Unb3
    // Offhand: Shield (тоже без зачар)
    // ─────────────────────────────────────────────────────────────
    AXE("axe", "Axe PvP",
        new KitEquipment(
            Items.DIAMOND_AXE, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("efficiency", 5)
                        .enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                // Броня БЕЗ зачарований — MCTiers Axe стандарт
                bot.setItemSlot(EquipmentSlot.HEAD,  new ItemStack(hel));
                bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(chest));
                bot.setItemSlot(EquipmentSlot.LEGS,  new ItemStack(legs));
                bot.setItemSlot(EquipmentSlot.FEET,  new ItemStack(bts));
            }
        ), "axe"),

    // ─────────────────────────────────────────────────────────────
    // POT — MCTiers Diamond Pot
    // Броня: Diamond Prot4 Unb3
    // Mainhand: Diamond Sword Sharp5 Unb3
    // Offhand: Splash Potion (лечение)
    // ─────────────────────────────────────────────────────────────
    POT("pot", "Diamond Pot",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.SPLASH_POTION,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "nethpot"),

    // ─────────────────────────────────────────────────────────────
    // UHC — MCTiers UHC
    // Шлем Prot3 Unb3, Нагр Prot2 Unb3, Ноги Prot2 Unb3, Боты Prot3 Unb3
    // Mainhand: Diamond Sword Sharp3 Unb3
    // Offhand: Bow Power5 Unb3
    // ─────────────────────────────────────────────────────────────
    UHC("uhc", "UHC",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.BOW,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 3).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND,
                    EnchantUtil.of(off, ra)
                        .enchant("power", 5).enchant("unbreaking", 3)
                        .enchant("infinity", 1).build());
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 3).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 2).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 2).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 3).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "uhc"),

    // ─────────────────────────────────────────────────────────────
    // NETHOP — MCTiers NethOP / NethPot
    // Броня: Netherite Prot4 Unb3 Mending
    // Mainhand: Netherite Sword Sharp5 Unb3 Mending
    // Offhand: Totem of Undying
    // ─────────────────────────────────────────────────────────────
    NETHOP("nethop", "NethOP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "nethpot"),

    // алиас
    NETHPOT("nethpot", "NethPot (алиас NethOP)",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "nethpot"),

    // ─────────────────────────────────────────────────────────────
    // SMP — MCTiers SMP
    // Броня: Netherite Prot4 Unb3 Mending
    // Mainhand: Netherite Sword Sharp5 KB2 FireAspect2 Unb3 Mending
    // Offhand: Totem of Undying
    // ─────────────────────────────────────────────────────────────
    SMP("smp", "SMP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("knockback", 2)
                        .enchant("fire_aspect", 2).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "smp"),

    // ─────────────────────────────────────────────────────────────
    // CRYSTAL — MCTiers Crystal PvP
    // Шлем/Нагр: Netherite Prot4 Unb3 Mending
    // Ноги/Боты: Netherite BlastProt4 Unb3 Mending (защита от кристаллов!)
    // Mainhand: Netherite Sword Sharp5 KB1 Unb3 Mending
    // Offhand: Totem of Undying
    // ─────────────────────────────────────────────────────────────
    CRYSTAL("crystal", "Crystal PvP",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("knockback", 1)
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                // Ноги и боты — BLAST PROTECTION (против кристаллов)
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("blast_protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("blast_protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "crystal"),

    // ─────────────────────────────────────────────────────────────
    // MACE — MCTiers Mace PvP (1.21+)
    // Броня: Netherite Prot4 Unb3 Mending
    // Mainhand: Mace Density5 Breach4 Unb3 Mending
    // Offhand: Totem of Undying
    // ─────────────────────────────────────────────────────────────
    MACE("mace", "Mace PvP",
        new KitEquipment(
            Items.MACE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("density", 5).enchant("breach", 4)
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "pvp"),

    // ─────────────────────────────────────────────────────────────
    // MACE_ELYTRA — Mace + Elytra пике (кастомный)
    // Нагрудник = Elytra Unb3 Mending
    // Mainhand: Mace Density5 Breach4 Unb3 Mending
    // Offhand: Totem
    // ─────────────────────────────────────────────────────────────
    MACE_ELYTRA("mace_elytra", "Mace + Elytra",
        new KitEquipment(
            Items.MACE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("density", 5).enchant("breach", 4)
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra) // Elytra
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "pvp"),

    // ─────────────────────────────────────────────────────────────
    // TPC — Totem + Crystal + Axe (кастомный)
    // Броня: Netherite Prot4 Unb3 Mending
    // Mainhand: Netherite Axe Sharp5 Eff5 Unb3 Mending
    // Offhand: Totem
    // ─────────────────────────────────────────────────────────────
    TPC("tpc", "TPC (Totem+Crystal+Axe)",
        new KitEquipment(
            Items.NETHERITE_AXE, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("efficiency", 5)
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "tpc"),

    // ─────────────────────────────────────────────────────────────
    // SNOWBALL — Snowball кит (кастомный)
    // ─────────────────────────────────────────────────────────────
    SNOWBALL("snowball", "Snowball",
        new KitEquipment(
            Items.SNOWBALL, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(main));
                bot.setItemSlot(EquipmentSlot.OFFHAND,  new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "snowball"),

    // ─────────────────────────────────────────────────────────────
    // Прочие (алиасы / legacy)
    // ─────────────────────────────────────────────────────────────
    TOTEM("totem", "Totem (алиас SMP)",
        new KitEquipment(
            Items.NETHERITE_SWORD, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "pvp"),

    TRIDENT("trident", "Trident PvP",
        new KitEquipment(
            Items.TRIDENT, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("loyalty", 3).enchant("channeling", 1)
                        .enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "pvp"),

    CROSSBOW("crossbow", "Crossbow PvP",
        new KitEquipment(
            Items.CROSSBOW, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("multishot", 1).enchant("quick_charge", 3)
                        .enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "pvp"),

    BEEHIVE("beehive", "Beehive",
        new KitEquipment(
            Items.DIAMOND_SWORD, Items.SHIELD,
            Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND,
                    EnchantUtil.of(main, ra)
                        .enchant("sharpness", 5).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).build());
            }
        ), "pvp"),

    FIREWORK("firework", "Firework + Elytra",
        new KitEquipment(
            Items.FIREWORK_ROCKET, Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET, Items.ELYTRA,
            Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
            (bot, ra, main, off, hel, chest, legs, bts) -> {
                bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(main));
                bot.setItemSlot(EquipmentSlot.OFFHAND,  new ItemStack(off));
                bot.setItemSlot(EquipmentSlot.HEAD,
                    EnchantUtil.of(hel, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.CHEST,
                    EnchantUtil.of(chest, ra) // Elytra
                        .enchant("unbreaking", 3).enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.LEGS,
                    EnchantUtil.of(legs, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("mending", 1).build());
                bot.setItemSlot(EquipmentSlot.FEET,
                    EnchantUtil.of(bts, ra)
                        .enchant("protection", 4).enchant("unbreaking", 3)
                        .enchant("feather_falling", 4).enchant("mending", 1).build());
            }
        ), "pvp");

    // ─────────────────────────────────────────────────────────────
    //  Поля и конструктор
    // ─────────────────────────────────────────────────────────────
    public final String id;
    public final String displayName;
    public final KitEquipment equipment;
    public final String profileName;

    BotKit(String id, String displayName, KitEquipment equipment, String profileName) {
        this.id          = id;
        this.displayName = displayName;
        this.equipment   = equipment;
        this.profileName = profileName;
    }

    public static BotKit byId(String id) {
        for (BotKit kit : values())
            if (kit.id.equalsIgnoreCase(id)) return kit;
        return null;
    }

    public static String listIds() {
        StringBuilder sb = new StringBuilder();
        for (BotKit kit : values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(kit.id);
        }
        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────
    //  KitEquipment
    // ─────────────────────────────────────────────────────────────
    public static class KitEquipment {
        public final Item mainhand;
        public final Item offhand;
        public final Item helmet;
        public final Item chestplate;
        public final Item leggings;
        public final Item boots;
        private final KitEnchant enchantProfile;

        public KitEquipment(Item mainhand, Item offhand,
                            Item helmet, Item chestplate,
                            Item leggings, Item boots,
                            KitEnchant enchantProfile) {
            this.mainhand       = mainhand;
            this.offhand        = offhand;
            this.helmet         = helmet;
            this.chestplate     = chestplate;
            this.leggings       = leggings;
            this.boots          = boots;
            this.enchantProfile = enchantProfile;
        }

        public void applyTo(BotEntity bot) {
            RegistryAccess ra = bot.level().registryAccess();
            enchantProfile.apply(bot, ra, mainhand, offhand,
                helmet, chestplate, leggings, boots);
        }
    }

    @FunctionalInterface
    public interface KitEnchant {
        void apply(BotEntity bot, RegistryAccess ra,
                   Item mainhand, Item offhand,
                   Item helmet, Item chestplate,
                   Item leggings, Item boots);
    }
}
