package com.pvpbot;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.UUID;

/**
 * FightAnalyzer — v1.2: разбор боя после убийства цели.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Что выводит в чат после каждого боя:
 * ══════════════════════════════════════════════════════════════════
 *
 *   ⚔ [PVPBot] Анализ боя vs PlayerName
 *   ▸ Ударов нанесено:  12  пропущено: 3  точность: 80%
 *   ▸ Урон нанесён:     84.0  получено: 16.5
 *   ▸ Длительность:     6.2 сек
 *   ▸ Пик DPS:          18.4  средний: 13.6
 *   ▸ Тотем сработал:   1 раз
 *   ▸ Golden Apple:     0 шт
 *
 * ══════════════════════════════════════════════════════════════════
 *  Интеграция:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Вызывать из KillDeathTracker при kill:
 *    FightAnalyzer.INSTANCE.onFightStart(targetName);     // начало боя (первый удар)
 *    FightAnalyzer.INSTANCE.onHit(damage);                 // каждый удар
 *    FightAnalyzer.INSTANCE.onMiss();                      // промах
 *    FightAnalyzer.INSTANCE.onDamageTaken(amount);         // получили урон
 *    FightAnalyzer.INSTANCE.onTotemPop();                  // тотем сработал
 *    FightAnalyzer.INSTANCE.onGappleUsed();                // съели гэпл
 *    FightAnalyzer.INSTANCE.onFightEnd(targetName, client);// цель умерла → отчёт
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class FightAnalyzer {

    public static final FightAnalyzer INSTANCE = new FightAnalyzer();

    // ── История боёв (последние 10) ───────────────────────────────
    public static final int HISTORY_MAX = 10;

    public static class FightRecord {
        public final String  target;
        public final int     hitsLanded;
        public final int     hitsMissed;
        public final float   totalDamage;
        public final float   damageTaken;
        public final float   durationSec;
        public final float   peakDps;
        public final float   avgDps;
        public final int     totemPops;
        public final int     gapplesUsed;
        public final boolean won;           // true = мы убили цель

        FightRecord(String target, int hits, int misses, float dmg, float taken,
                    float sec, float peak, float avg, int totems, int gapples, boolean won) {
            this.target      = target;
            this.hitsLanded  = hits;
            this.hitsMissed  = misses;
            this.totalDamage = dmg;
            this.damageTaken = taken;
            this.durationSec = sec;
            this.peakDps     = peak;
            this.avgDps      = avg;
            this.totemPops   = totems;
            this.gapplesUsed = gapples;
            this.won         = won;
        }

        public int accuracy() {
            int total = hitsLanded + hitsMissed;
            return total == 0 ? 0 : (int)(hitsLanded * 100.0 / total);
        }
    }

    /** Кольцевой буфер последних боёв. */
    private final Deque<FightRecord> history = new ArrayDeque<>();

    /** Возвращает список последних боёв (новейший первый). */
    public List<FightRecord> getHistory() {
        List<FightRecord> list = new ArrayList<>(history);
        java.util.Collections.reverse(list);
        return list;
    }

    public void clearHistory() { history.clear(); }

    // ── Состояние боя ─────────────────────────────────────────────
    private boolean  active        = false;
    private String   targetName    = "";
    private long     startNanos    = 0;

    private int      hitsLanded    = 0;
    private int      hitsMissed    = 0;
    private float    totalDamage   = 0f;
    private float    damageTaken   = 0f;
    private int      totemPops     = 0;
    private int      gapplesUsed   = 0;

    // DPS tracking (по «окнам» в 1 секунду)
    private float    windowDmg     = 0f;
    private long     windowStart   = 0;
    private float    peakDps       = 0f;
    private float    avgDpsSum     = 0f;
    private int      avgDpsCount   = 0;

    private FightAnalyzer() {}

    // ══════════════════════════════════════════════════════════════
    //  API
    // ══════════════════════════════════════════════════════════════

    /** Первый удар по новой цели — стартуем сбор статистики. */
    public void onFightStart(String name) {
        if (active && targetName.equals(name)) return; // уже идём
        reset();
        active      = true;
        targetName  = name;
        startNanos  = System.nanoTime();
        windowStart = startNanos;
    }

    /** Вызывать при каждом успешном ударе бота. */
    public void onHit(float damage) {
        if (!active) return;
        hitsLanded++;
        totalDamage += damage;
        windowDmg   += damage;
        flushDpsWindow();
    }

    /** Вызывать если атака не попала / цель заблокировала. */
    public void onMiss() {
        if (!active) return;
        hitsMissed++;
    }

    /** Вызывать когда бот/игрок получил урон. */
    public void onDamageTaken(float amount) {
        if (!active) return;
        damageTaken += amount;
    }

    /** Вызывать при срабатывании тотема (у бота или игрока). */
    public void onTotemPop() {
        if (!active) return;
        totemPops++;
    }

    /** Вызывать при использовании Golden Apple. */
    public void onGappleUsed() {
        if (!active) return;
        gapplesUsed++;
    }

    /**
     * Конец боя — выводим отчёт в чат и сбрасываем счётчики.
     * @param killedName имя убитого (проверяем совпадение)
     */
    public void onFightEnd(String killedName, Minecraft mc) {
        if (!active) return;
        // Фикс v1.2.1: отчёт только если убили именно нашу цель
        if (!killedName.equals(targetName)) return;

        // Финальный DPS-window
        flushDpsWindow();

        long   elapsedNanos = System.nanoTime() - startNanos;
        double seconds      = elapsedNanos / 1_000_000_000.0;
        int    total        = hitsLanded + hitsMissed;
        int    accuracy     = total == 0 ? 0 : (int)(hitsLanded * 100.0 / total);
        float  avgDps       = avgDpsCount == 0 ? 0f : avgDpsSum / avgDpsCount;

        String sep = "§8──────────────────";
        send(mc, sep);
        send(mc, "§e⚔ Анализ боя §fvs §b" + killedName);
        send(mc, "§7▸ Ударов: §f" + hitsLanded + " §7пропущено: §f" + hitsMissed
            + "  §7точность: §a" + accuracy + "%");
        send(mc, "§7▸ Урон: §c" + f1(totalDamage)
            + "  §7получено: §c" + f1(damageTaken));
        send(mc, "§7▸ Время: §f" + f1((float)seconds) + " сек");
        send(mc, "§7▸ DPS: §fpик §e" + f1(peakDps)
            + "  §fсред §e" + f1(avgDps));
        if (totemPops > 0)
            send(mc, "§7▸ Тотем сработал: §d" + totemPops + "x");
        if (gapplesUsed > 0)
            send(mc, "§7▸ Golden Apple: §6" + gapplesUsed + " шт");
        send(mc, sep);

        // ── Сохраняем в историю ──────────────────────────────────
        FightRecord rec = new FightRecord(
            killedName, hitsLanded, hitsMissed, totalDamage, damageTaken,
            (float) seconds, peakDps, avgDps, totemPops, gapplesUsed, true
        );
        history.addLast(rec);
        if (history.size() > HISTORY_MAX) history.removeFirst();

        reset();
    }

    public boolean isActive()    { return active; }
    public String  getTarget()   { return targetName; }

    // ── Внутренние ───────────────────────────────────────────────

    private void flushDpsWindow() {
        long now = System.nanoTime();
        double windowSec = (now - windowStart) / 1_000_000_000.0;
        if (windowSec >= 1.0) {
            float dps = (float)(windowDmg / windowSec);
            if (dps > peakDps) peakDps = dps;
            avgDpsSum  += dps;
            avgDpsCount++;
            windowDmg   = 0f;
            windowStart = now;
        }
    }

    private void reset() {
        active      = false;
        targetName  = "";
        hitsLanded  = hitsMissed = totemPops = gapplesUsed = avgDpsCount = 0;
        totalDamage = damageTaken = peakDps = avgDpsSum = windowDmg = 0f;
    }

    private String f1(float v) {
        return String.format("%.1f", v);
    }

    private void send(Minecraft mc, String msg) {
        if (mc.player != null) {
            mc.gui.getChat().addMessage(Component.literal("§e[PVPBot] §f" + msg));
        }
    }
}
