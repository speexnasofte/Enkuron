package com.pvpbot;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * AutoPearl v12 — SERVER-SIDE реализация (FIX: убрана зависимость от Minecraft/client).
 *
 * Fix 1 (v1.3.9): полностью переписан на серверную сторону.
 *   - Удалён Minecraft client, KeyMapping reflection, gameMode.useItem
 *   - Бросок перла через ProjectileUtil / entity spawn на ServerLevel
 *   - Работает корректно для NPC-ботов (BotEntity extends Mob, не ClientPlayer)
 *
 * Два режима:
 *   GAP_CLOSE  — бросок к цели когда она > gapThreshold блоков и HP >= hp_min
 *   ESCAPE     — бросок «за спину» когда HP < escape_hp
 */
public class AutoPearl {

    public static final AutoPearl INSTANCE = new AutoPearl();

    private int cooldownTimer = 0;

    private AutoPearl() {}

    /**
     * Вызывается каждый серверный тик из BotEntity.tick() / PVPBotLogic.
     * bot — серверный BotEntity (не ClientPlayer).
     */
    public boolean tick(BotEntity bot) {
        if (bot == null || !PVPBotConfig.INSTANCE.autoPearlEnabled) return false;
        if (!(bot.level() instanceof ServerLevel sw)) return false;

        cooldownTimer--;
        if (cooldownTimer < 0) cooldownTimer = 0;
        if (cooldownTimer > 0) return false;

        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        double gapThresh = cfg.autoPearlGapThreshold;   // default 8.0
        double hpMin     = cfg.autoPearlHpMin;           // default 12.0
        double escapeHp  = cfg.autoPearlEscapeHp;        // default 8.0
        int    cooldown  = cfg.autoPearlCooldown;        // default 60

        // Ищем перл в hotbar (слоты 0–8)
        int pearlSlot = findPearlSlot(bot);
        if (pearlSlot < 0) return false;

        float hp = bot.getHealth();

        // ESCAPE: HP критически низкое — бросаем перл за спину
        if (cfg.autoPearlMode.equals("escape") && hp < (float) escapeHp) {
            Vec3 dest = escapeDirection(bot);
            spawnPearl(sw, bot, pearlSlot, dest);
            cooldownTimer = cooldown;
            return true;
        }

        // GAP_CLOSE: HP норм — бросаем к цели
        if (cfg.autoPearlMode.equals("gap_close") && hp >= (float) hpMin) {
            LivingEntity target = findNearestEnemy(sw, bot);
            if (target != null && bot.distanceTo(target) > gapThresh) {
                spawnPearl(sw, bot, pearlSlot, target.getEyePosition());
                cooldownTimer = cooldown;
                return true;
            }
        }

        return false;
    }

    /** Ищет Эндер-жемчуг в руках бота. */
    private int findPearlSlot(BotEntity bot) {
        if (bot.getMainHandItem().is(Items.ENDER_PEARL)) return 0;
        if (bot.getOffhandItem().is(Items.ENDER_PEARL)) return 1;
        return -1;
    }

    /** Находит ближайшего врага в радиусе 24 блоков (серверный поиск). */
    private LivingEntity findNearestEnemy(ServerLevel sw, BotEntity bot) {
        AABB box = bot.getBoundingBox().inflate(24.0);
        List<LivingEntity> entities = sw.getEntitiesOfClass(
            LivingEntity.class, box,
            e -> e != bot && e.isAlive() && e instanceof Player
        );
        return entities.stream()
            .min(Comparator.comparingDouble(bot::distanceTo))
            .orElse(null);
    }

    /**
     * Серверный спавн снаряда EnderPearl с нужным направлением.
     * Использует vanilla ThrownEnderpearl entity через ServerLevel.
     */
    private void spawnPearl(ServerLevel sw, BotEntity bot, int slot, Vec3 target) {
        // Уменьшаем стак перла
        bot.getMainHandItem().shrink(1);

        // Вычисляем направление
        Vec3 eye    = bot.getEyePosition();
        Vec3 dir    = target.subtract(eye).normalize();
        double hDist = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        float pitch = (float) Math.toDegrees(-Math.atan2(dir.y, hDist));

        // Спавним через vanilla механику
        net.minecraft.world.entity.projectile.ThrownEnderpearl pearl =
            new net.minecraft.world.entity.projectile.ThrownEnderpearl(
                net.minecraft.world.entity.EntityType.ENDER_PEARL, sw);
        pearl.setOwner(bot);
        pearl.moveTo(eye.x, eye.y, eye.z, yaw, pitch);
        pearl.shootFromRotation(bot, pitch, yaw, 0.0f, 2.5f, 0.0f); // скорость как у игрока
        sw.addFreshEntity(pearl);
    }

    /** Точка «за спиной» бота на 12 блоков от взгляда (для escape). */
    private Vec3 escapeDirection(BotEntity bot) {
        Vec3 look = bot.getViewVector(1.0f);
        return bot.getEyePosition().add(look.scale(-12.0));
    }
}
