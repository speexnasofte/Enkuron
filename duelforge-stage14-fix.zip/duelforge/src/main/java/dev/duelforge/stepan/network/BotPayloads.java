package dev.duelforge.stepan.network;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Bot-list / bot-action packets of the ported PVP Bot. Ids use the "duelforge" namespace (the original used
 * "pvp_bot_gui"), so they never clash with Stepan's own mod if both are installed.
 */
public class BotPayloads {
    static final StreamCodec<RegistryFriendlyByteBuf, List<String>> STRING_LIST =
            ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()).cast();

    private static Identifier id(String path) { return Identifier.fromNamespaceAndPath("duelforge", path); }

    public record BotListRequestPayload() implements CustomPacketPayload {
        public static final Type<BotListRequestPayload> ID = new Type<>(id("pvpbot_bot_list_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BotListRequestPayload> CODEC =
                StreamCodec.unit(new BotListRequestPayload());
        @Override public Type<BotListRequestPayload> type() { return ID; }
    }

    public record BotListResponsePayload(List<String> botNames) implements CustomPacketPayload {
        public static final Type<BotListResponsePayload> ID = new Type<>(id("pvpbot_bot_list_response"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BotListResponsePayload> CODEC =
                StreamCodec.composite(STRING_LIST, p -> new ArrayList<>(p.botNames()), BotListResponsePayload::new);
        @Override public Type<BotListResponsePayload> type() { return ID; }
    }

    public record BotActionPayload(String botName, String action) implements CustomPacketPayload {
        public static final Type<BotActionPayload> ID = new Type<>(id("pvpbot_bot_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BotActionPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.STRING_UTF8, BotActionPayload::botName,
                ByteBufCodecs.STRING_UTF8, BotActionPayload::action,
                BotActionPayload::new);
        @Override public Type<BotActionPayload> type() { return ID; }
    }
}
