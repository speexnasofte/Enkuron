package com.pvpbot;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;
import net.minecraft.client.renderer.RenderTickCounter;

/**
 * PVPBotHud — игровой HUD.
 *
 * v8 добавлено:
 *   ✅ DPS Meter — урон в секунду по текущей цели
 *   ✅ W-Tap / AutoGap индикаторы
 *   ✅ Текущий профиль ModuleManager
 *   ✅ EXPERT в switch сложности
 */
public class PVPBotHud implements HudRenderCallback {

    private final PVPBotConfig  cfg     = PVPBotConfig.INSTANCE;
    private final ModuleManager modules = ModuleManager.INSTANCE;

    @Override
    public void onHudRender(GuiGraphics ctx, net.minecraft.client.renderer.RenderTickCounter ticker) {
        if (!cfg.showHud) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.world == null) return;

        int x  = 6;
        int y  = 6;
        int lh = 10;

        boolean isCrystal = cfg.mode == PVPBotConfig.Mode.CRYSTAL;

        // Фон
        int panelH = lh * 13 + 14;
        ctx.fill(x - 3, y - 3, x + 140, y + panelH, 0x88000000);
        int topColor = isCrystal ? 0xFF00CFFF : 0xFFFFD700;
        ctx.fill(x - 3, y - 3, x + 140, y - 2, topColor);

        // Заголовок + профиль
        String modeIcon = isCrystal ? "§b💎 Crystal" : "§e⚔ Sword";
        String profile  = "§8[" + modules.getActiveProfile() + "]";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal("§fPVPBot " + modeIcon + " " + profile), x, y, 0xFFFFFF);
        y += lh + 1;

        // Статус
        String status = cfg.enabled ? "§aВКЛЮЧЁН" : "§cВЫКЛЮЧЕН";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal("§7Статус: " + status), x, y, 0xFFFFFF);
        y += lh;

        // Сложность
        String diff = switch (cfg.difficulty) {
            case EASY   -> "§a★☆☆☆ Лёгкая";
            case MEDIUM -> "§e★★☆☆ Средняя";
            case HARD   -> "§c★★★☆ Сложная";
            case EXPERT -> "§4★★★★ EXPERT";
        };
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal("§7Сложность: " + diff), x, y, 0xFFFFFF);
        y += lh;

        // Модули — строка 1: атака, уклонение, лечение
        String atk  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ATTACK))  + "§7Атк ";
        String dge  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_DODGE))   + "§7Укл ";
        String heal = icon(modules.isEnabled(ModuleManager.MOD_AUTO_HEAL))    + "§7Леч ";
        String gap  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_GAP))     + "§7Gap";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal(atk + dge + heal + gap), x, y, 0xFFFFFF);
        y += lh;

        // Строка 2: броня, тотем, еда
        String armor  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_ARMOR))  + "§7Броня ";
        String totem  = icon(modules.isEnabled(ModuleManager.MOD_AUTO_TOTEM))  + "§7Тотем ";
        String eat    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_EAT))    + "§7Еда";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal(armor + totem + eat), x, y, 0xFFFFFF);
        y += lh;

        // Строка 3: W-Tap, Sprint, ESP, Radar
        String wtap   = icon(modules.isEnabled(ModuleManager.MOD_W_TAP))       + "§7W-Tap ";
        String sprint = icon(modules.isEnabled(ModuleManager.MOD_AUTO_SPRINT)) + "§7Спр ";
        String esp    = icon(modules.isEnabled(ModuleManager.MOD_ESP))         + "§7ESP ";
        String radar  = icon(modules.isEnabled(ModuleManager.MOD_RADAR))       + "§7Radar";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal(wtap + sprint + esp + radar), x, y, 0xFFFFFF);
        y += lh;

        // Строка 4: Bow, Kite, Crystal, WL
        String bow    = icon(modules.isEnabled(ModuleManager.MOD_AUTO_BOW))    + "§7Bow ";
        String kite   = icon(modules.isEnabled(ModuleManager.MOD_KITE))        + "§7Kite ";
        String crys   = isCrystal ? icon(modules.isEnabled(ModuleManager.MOD_CRYSTAL)) + "§7Крист " : "";
        String wl     = cfg.whitelistEnabled ? "§a[WL:" + cfg.whitelist.size() + "]" : "§8[WL]";
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal(bow + kite + crys + wl), x, y, 0xFFFFFF);
        y += lh + 2;

        // Разделитель
        ctx.fill(x, y, x + 131, y + 1, 0x55FFFFFF);
        y += 4;

        // K/D статистика
        if (cfg.statsEnabled) {
            double kd = KillDeathTracker.deaths == 0
                ? KillDeathTracker.kills
                : (double) KillDeathTracker.kills / KillDeathTracker.deaths;
            ctx.drawTextWithShadow(mc.textRenderer,
                net.minecraft.text.Component.literal(
                    "§aK:§f" + KillDeathTracker.kills +
                    " §cD:§f" + KillDeathTracker.deaths +
                    " §eA:§f" + KillDeathTracker.assists +
                    " §6KD:§f" + String.format("%.1f", kd)
                ), x, y, 0xFFFFFF);
            y += lh;
        }

        // Цель
        LivingEntity target = findNearest(mc);
        if (target != null) {
            double dist = mc.player.distanceTo(target);
            String name = target.getName().getString();
            if (name.length() > 13) name = name.substring(0, 13) + "…";
            ctx.drawTextWithShadow(mc.textRenderer,
                net.minecraft.text.Component.literal("§cЦель: §f" + name), x, y, 0xFFFFFF);
            y += lh;

            int hp    = (int) target.getHealth();
            int maxHp = (int) target.getMaxHealth();

            // ── v8: DPS Meter ─────────────────────────────────────
            if (cfg.showDps) {
                ctx.drawTextWithShadow(mc.textRenderer,
                    net.minecraft.text.Component.literal(DpsMeter.INSTANCE.getFormatted()
                        + "  §cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF);
            } else {
                ctx.drawTextWithShadow(mc.textRenderer,
                    net.minecraft.text.Component.literal("§cHP §f" + hp + "/" + maxHp
                        + " §7(" + String.format("%.1f", dist) + "м)"),
                    x, y, 0xFFFFFF);
            }
            y += lh;

            // HP-бар
            int barW = 131;
            float ratio = (float) hp / maxHp;
            ctx.fill(x, y, x + barW, y + 3, 0xFF550000);
            ctx.fill(x, y, x + (int)(barW * ratio), y + 3,
                ratio > 0.5f ? 0xFF00CC44 : ratio > 0.25f ? 0xFFFFAA00 : 0xFFFF2222);
        } else {
            ctx.drawTextWithShadow(mc.textRenderer,
                net.minecraft.text.Component.literal("§7Цель: нет"), x, y, 0xFFFFFF);
            y += lh;
        }

        y += lh + 2;
        ctx.drawTextWithShadow(mc.textRenderer,
            net.minecraft.text.Component.literal("§8[R] вкл  [G] настройки  [P] профиль"), x, y, 0x888888);
    }

    private LivingEntity findNearest(Minecraft mc) {
        if (mc.player == null || mc.world == null) return null;
        Box box = mc.player.getBoundingBox().expand(16.0);
        List<LivingEntity> list = mc.world.getEntitiesByClass(
            LivingEntity.class, box,
            e -> e != mc.player && e.isAlive() && !e.isInvisible()
        );
        return list.stream()
            .min(Comparator.comparingDouble(mc.player::distanceTo))
            .orElse(null);
    }

    private String icon(boolean on) { return on ? "§a✔" : "§c✘"; }
}
